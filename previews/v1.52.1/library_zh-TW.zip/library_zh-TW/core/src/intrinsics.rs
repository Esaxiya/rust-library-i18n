//! 編譯器內在函數。
//!
//! 相應的定義在 `compiler/rustc_codegen_llvm/src/intrinsic.rs` 中。
//! 相應的 const 實現在 `compiler/rustc_mir/src/interpret/intrinsics.rs` 中
//!
//! # 常量內在函數
//!
//! Note: 對內在常數的任何更改都應與語言團隊討論。
//! 這包括常數穩定性的變化。
//!
//! 為了使內在函數在編譯時可用，需要將實現從 <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> 複製到 `compiler/rustc_mir/src/interpret/intrinsics.rs`，然後將 `#[rustc_const_unstable(feature = "foo", issue = "01234")]` 添加到內在函數。
//!
//!
//! 如果應該從具有 `rustc_const_stable` 屬性的 `const fn` 使用內部函數，則內部函數的屬性也必須為 `rustc_const_stable`。
//! 如果沒有 T-lang 諮詢，則不應進行此類更改，因為它會將語言中的一項功能烘焙到沒有編譯器支持的情況下無法在用戶代碼中復制。
//!
//! # Volatiles
//!
//! 易失性內在函數提供旨在作用於 I/O 內存的操作，並保證編譯器不會在其他易失性內在函數之間對它們進行重新排序。請參閱 [[volatile]] 上的 LLVM 文檔。
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! 原子內在函數對機器字提供常見的原子操作，並具有多種可能的存儲順序。它們遵循與 C++ 11 相同的語義。請參閱 [[atomics]] 上的 LLVM 文檔。
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! 關於內存排序的快速回顧:
//!
//! * 獲取，獲取鎖的障礙。屏障之後將進行後續的讀取和寫入。
//! * 釋放，用於釋放鎖的障礙物。之前的讀取和寫入發生在該屏障之前。
//! * 保證順序一致，順序一致的操作按順序進行。這是處理原子類型的標準模式，等效於 Java 的 `volatile`。
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// 這些導入用於簡化文檔內鏈接
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // 安全性: 請參閱 `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // 注意，這些內在函數採用原始指針，因為它們會使別名內存發生突變，這對 `&` 或 `&mut` 均無效。
    //

    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 用作 `success` 和 `failure` 參數，可以通過 `compare_exchange` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::Acquire`] 用作 `success` 和 `failure` 參數，可以通過 `compare_exchange` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `success` 和 [`Ordering::Relaxed`] 作為 `failure` 參數，可以通過 `compare_exchange` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `success` 和 [`Ordering::Acquire`] 作為 `failure` 參數，可以通過 `compare_exchange` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 用作 `success` 和 `failure` 參數，可以通過 `compare_exchange` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `success` 和 [`Ordering::Relaxed`] 作為 `failure` 參數，可以通過 `compare_exchange` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `success` 和 [`Ordering::Acquire`] 作為 `failure` 參數，可以通過 `compare_exchange` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `success` 和 [`Ordering::Relaxed`] 作為 `failure` 參數，可以通過 `compare_exchange` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `success` 和 [`Ordering::Relaxed`] 作為 `failure` 參數，可以通過 `compare_exchange` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 用作 `success` 和 `failure` 參數，可以通過 `compare_exchange_weak` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::Acquire`] 用作 `success` 和 `failure` 參數，可以通過 `compare_exchange_weak` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `success` 和 [`Ordering::Relaxed`] 作為 `failure` 參數，可以通過 `compare_exchange_weak` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `success` 和 [`Ordering::Acquire`] 作為 `failure` 參數，可以通過 `compare_exchange_weak` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 用作 `success` 和 `failure` 參數，可以通過 `compare_exchange_weak` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `success` 和 [`Ordering::Relaxed`] 作為 `failure` 參數，可以通過 `compare_exchange_weak` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `success` 和 [`Ordering::Acquire`] 作為 `failure` 參數，可以通過 `compare_exchange_weak` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `success` 和 [`Ordering::Relaxed`] 作為 `failure` 參數，可以通過 `compare_exchange_weak` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果當前值與 `old` 值相同，則存儲一個值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `success` 和 [`Ordering::Relaxed`] 作為 `failure` 參數，可以通過 `compare_exchange_weak` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// 加載指針的當前值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `load` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// 加載指針的當前值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `order` 傳遞，可以通過 `load` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// 加載指針的當前值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `load` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// 將值存儲在指定的存儲位置。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `store` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// 將值存儲在指定的存儲位置。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `store` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// 將值存儲在指定的存儲位置。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `store` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// 將值存儲在指定的內存位置，並返回舊值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `swap` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// 將值存儲在指定的內存位置，並返回舊值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `order` 傳遞，可以通過 `swap` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 將值存儲在指定的內存位置，並返回舊值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `swap` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 將值存儲在指定的內存位置，並返回舊值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `order` 傳遞，可以通過 `swap` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 將值存儲在指定的內存位置，並返回舊值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `swap` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 加到當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `fetch_add` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// 加到當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `order` 傳遞，可以通過 `fetch_add` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 加到當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `fetch_add` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 加到當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `order` 傳遞，可以通過 `fetch_add` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 加到當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `fetch_add` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 從當前值減去，返回前一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `fetch_sub` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// 從當前值減去，返回前一個值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `order` 傳遞，可以通過 `fetch_sub` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 從當前值減去，返回前一個值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `fetch_sub` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 從當前值減去，返回前一個值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `order` 傳遞，可以通過 `fetch_sub` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 從當前值減去，返回前一個值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `fetch_sub` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 按位並具有當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `fetch_and` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位並具有當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `order` 傳遞，可以通過 `fetch_and` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位並具有當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `fetch_and` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位並具有當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `order` 傳遞，可以通過 `fetch_and` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位並具有當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `fetch_and` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 當前值按位與，返回前一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `fetch_nand` 方法在 [`AtomicBool`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// 當前值按位與，返回前一個值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `order` 傳遞，可以通過 `fetch_nand` 方法在 [`AtomicBool`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 當前值按位與，返回前一個值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `fetch_nand` 方法在 [`AtomicBool`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 當前值按位與，返回前一個值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `order` 傳遞，可以通過 `fetch_nand` 方法在 [`AtomicBool`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 當前值按位與，返回前一個值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `fetch_nand` 方法在 [`AtomicBool`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 按位或具有當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `fetch_or` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位或具有當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `order` 傳遞，可以通過 `fetch_or` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位或具有當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `fetch_or` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位或具有當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `order` 傳遞，可以通過 `fetch_or` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位或具有當前值，返回前一個值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `fetch_or` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 與當前值按位異或，返回前一個值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `fetch_xor` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// 與當前值按位異或，返回前一個值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `order` 傳遞，可以通過 `fetch_xor` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 與當前值按位異或，返回前一個值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `fetch_xor` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 與當前值按位異或，返回前一個值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `order` 傳遞，可以通過 `fetch_xor` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 與當前值按位異或，返回前一個值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `fetch_xor` 方法在 [`atomic`] 類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 使用帶符號的比較將當前值設為最大值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `fetch_max` 方法在 [`atomic`] 有符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用帶符號的比較將當前值設為最大值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `order` 傳遞，可以通過 `fetch_max` 方法在 [`atomic`] 有符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用帶符號的比較將當前值設為最大值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `fetch_max` 方法在 [`atomic`] 有符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用帶符號的比較將當前值設為最大值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `order` 傳遞，可以通過 `fetch_max` 方法在 [`atomic`] 有符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 當前值的最大值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `fetch_max` 方法在 [`atomic`] 有符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 使用帶符號的比較將當前值設為最小值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `fetch_min` 方法在 [`atomic`] 有符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用帶符號的比較將當前值設為最小值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `order` 傳遞，可以通過 `fetch_min` 方法在 [`atomic`] 有符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用帶符號的比較將當前值設為最小值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `fetch_min` 方法在 [`atomic`] 有符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用帶符號的比較將當前值設為最小值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `order` 傳遞，可以通過 `fetch_min` 方法在 [`atomic`] 有符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用帶符號的比較將當前值設為最小值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `fetch_min` 方法在 [`atomic`] 有符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 使用無符號比較將當前值設為最小值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 傳遞為 `order`，可以通過 `fetch_min` 方法在 [`atomic`] 無符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用無符號比較將當前值設為最小值。
    ///
    /// 通過將 [`Ordering::Acquire`] 傳遞為 `order`，可以通過 `fetch_min` 方法在 [`atomic`] 無符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用無符號比較將當前值設為最小值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `fetch_min` 方法在 [`atomic`] 無符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用無符號比較將當前值設為最小值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `order` 傳遞，可以通過 `fetch_min` 方法在 [`atomic`] 無符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用無符號比較將當前值設為最小值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `fetch_min` 方法在 [`atomic`] 無符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 使用無符號比較將當前值設為最大值。
    ///
    /// 通過將 [`Ordering::SeqCst`] 作為 `order` 傳遞，可以通過 `fetch_max` 方法在 [`atomic`] 無符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用無符號比較將當前值設為最大值。
    ///
    /// 通過將 [`Ordering::Acquire`] 作為 `order` 傳遞，可以通過 `fetch_max` 方法在 [`atomic`] 無符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用無符號比較將當前值設為最大值。
    ///
    /// 通過將 [`Ordering::Release`] 作為 `order` 傳遞，可以通過 `fetch_max` 方法在 [`atomic`] 無符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用無符號比較將當前值設為最大值。
    ///
    /// 通過將 [`Ordering::AcqRel`] 作為 `order` 傳遞，可以通過 `fetch_max` 方法在 [`atomic`] 無符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用無符號比較將當前值設為最大值。
    ///
    /// 通過將 [`Ordering::Relaxed`] 作為 `order` 傳遞，可以通過 `fetch_max` 方法在 [`atomic`] 無符號整數類型上使用此內在函數的穩定版本。
    /// 例如， [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` 內在函數向代碼生成器提示，如果支持，則插入一個預取指令。否則，它是無操作的。
    /// 預取對程序的行為沒有影響，但可以更改其性能特徵。
    ///
    /// `locality` 參數必須是一個常量整數，並且是一個時間局部性說明符，範圍從 (0) (無局部性) 到 (3) (在緩存中非常局部地保留)。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` 內在函數向代碼生成器提示，如果支持，則插入一個預取指令。否則，它是無操作的。
    /// 預取對程序的行為沒有影響，但可以更改其性能特徵。
    ///
    /// `locality` 參數必須是一個常量整數，並且是一個時間局部性說明符，範圍從 (0) (無局部性) 到 (3) (在緩存中非常局部地保留)。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` 內在函數向代碼生成器提示，如果支持，則插入一個預取指令。否則，它是無操作的。
    /// 預取對程序的行為沒有影響，但可以更改其性能特徵。
    ///
    /// `locality` 參數必須是一個常量整數，並且是一個時間局部性說明符，範圍從 (0) (無局部性) 到 (3) (在緩存中非常局部地保留)。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` 內在函數向代碼生成器提示，如果支持，則插入一個預取指令。否則，它是無操作的。
    /// 預取對程序的行為沒有影響，但可以更改其性能特徵。
    ///
    /// `locality` 參數必須是一個常量整數，並且是一個時間局部性說明符，範圍從 (0) (無局部性) 到 (3) (在緩存中非常局部地保留)。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// 原子圍欄。
    ///
    /// 通過將 [`Ordering::SeqCst`] 傳遞為 `order`，可以在 [`atomic::fence`] 中獲得此內在函數的穩定版本。
    ///
    ///
    pub fn atomic_fence();
    /// 原子圍欄。
    ///
    /// 通過將 [`Ordering::Acquire`] 傳遞為 `order`，可以在 [`atomic::fence`] 中獲得此內在函數的穩定版本。
    ///
    ///
    pub fn atomic_fence_acq();
    /// 原子圍欄。
    ///
    /// 通過將 [`Ordering::Release`] 傳遞為 `order`，可以在 [`atomic::fence`] 中獲得此內在函數的穩定版本。
    ///
    ///
    pub fn atomic_fence_rel();
    /// 原子圍欄。
    ///
    /// 通過將 [`Ordering::AcqRel`] 傳遞為 `order`，可以在 [`atomic::fence`] 中獲得此內在函數的穩定版本。
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// 僅編譯器的內存屏障。
    ///
    /// 編譯器絕不會在此障礙上對內存訪問進行重新排序，但不會為此發出任何指令。
    /// 這適用於可能被搶占的同一線程上的操作，例如與信號處理程序進行交互時。
    ///
    /// 通過將 [`Ordering::SeqCst`] 傳遞為 `order`，可以在 [`atomic::compiler_fence`] 中獲得此內在函數的穩定版本。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// 僅編譯器的內存屏障。
    ///
    /// 編譯器絕不會在此障礙上對內存訪問進行重新排序，但不會為此發出任何指令。
    /// 這適用於可能被搶占的同一線程上的操作，例如與信號處理程序進行交互時。
    ///
    /// 通過將 [`Ordering::Acquire`] 傳遞為 `order`，可以在 [`atomic::compiler_fence`] 中獲得此內在函數的穩定版本。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// 僅編譯器的內存屏障。
    ///
    /// 編譯器絕不會在此障礙上對內存訪問進行重新排序，但不會為此發出任何指令。
    /// 這適用於可能被搶占的同一線程上的操作，例如與信號處理程序進行交互時。
    ///
    /// 通過將 [`Ordering::Release`] 傳遞為 `order`，可以在 [`atomic::compiler_fence`] 中獲得此內在函數的穩定版本。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// 僅編譯器的內存屏障。
    ///
    /// 編譯器絕不會在此障礙上對內存訪問進行重新排序，但不會為此發出任何指令。
    /// 這適用於可能被搶占的同一線程上的操作，例如與信號處理程序進行交互時。
    ///
    /// 通過將 [`Ordering::AcqRel`] 傳遞為 `order`，可以在 [`atomic::compiler_fence`] 中獲得此內在函數的穩定版本。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// 從函數附加的屬性中獲取其含義的魔術內在函數。
    ///
    /// 例如，數據流使用它來注入靜態斷言，以便 `rustc_peek(potentially_uninitialized)` 實際上會再次檢查數據流確實確實計算出該數據流在控制流中未初始化。
    ///
    ///
    /// 不應在編譯器外部使用此內在函數。
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// 中止過程的執行。
    ///
    /// [`std::process::abort`](../../std/process/fn.abort.html) 是此操作的更用戶友好和穩定的版本。
    ///
    pub fn abort() -> !;

    /// 通知優化器代碼中的這一點不可訪問，從而可以進行進一步的優化。
    ///
    /// 注意，這與 `unreachable!()` 宏有很大不同: 與執行 panics 的宏不同，訪問該功能標記的代碼是 `不確定行為`。
    ///
    ///
    /// 此內在函數的穩定版本為 [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked)。
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// 通知優化器條件始終為真。
    /// 如果條件為假，則行為是不確定的。
    ///
    /// 沒有為該內部函數生成任何代碼，但是優化器將嘗試在通過之間保留它 (及其條件)，這可能會干擾周圍代碼的優化並降低性能。
    /// 如果優化器可以自己發現不變量，或者不啟用任何重要的優化，則不應使用該變量。
    ///
    /// 此內在函數沒有穩定的對應對象。
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// 提示編譯器 branch 條件可能為真。
    /// 返回傳遞給它的值。
    ///
    /// 除與 `if` 語句一起使用外，其他任何使用都可能無效。
    ///
    /// 此內在函數沒有穩定的對應對象。
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// 提示編譯器 branch 條件可能為假。
    /// 返回傳遞給它的值。
    ///
    /// 除與 `if` 語句一起使用外，其他任何使用都可能無效。
    ///
    /// 此內在函數沒有穩定的對應對象。
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// 執行一個斷點陷阱，以供調試器檢查。
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn breakpoint();

    /// 類型的大小 (以字節為單位)。
    ///
    /// 更具體地說，這是相同類型的連續項目之間的字節偏移量，包括對齊填充。
    ///
    ///
    /// 此內在函數的穩定版本為 [`core::mem::size_of`](crate::mem::size_of)。
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// 類型的最小對齊方式。
    ///
    /// 此內在函數的穩定版本為 [`core::mem::align_of`](crate::mem::align_of)。
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// 類型的首選對齊方式。
    ///
    /// 此內在函數沒有穩定的對應對象。
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// 引用值的大小 (以字節為單位)。
    ///
    /// 此內在函數的穩定版本為 [`mem::size_of_val`]。
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// 參考值的所需對齊方式。
    ///
    /// 此內在函數的穩定版本為 [`core::mem::align_of_val`](crate::mem::align_of_val)。
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// 獲取包含類型名稱的靜態字符串切片。
    ///
    /// 此內在函數的穩定版本為 [`core::any::type_name`](crate::any::type_name)。
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// 獲取一個標識符，該標識符對於指定的類型是全局唯一的。
    /// 無論調用哪個 crate，此函數都會為類型返回相同的值。
    ///
    ///
    /// 此內在函數的穩定版本為 [`core::any::TypeId::of`](crate::any::TypeId::of)。
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// 如果 `T` 無人居住，將無法執行的不安全功能的防護措施:
    /// 這將靜態地為 panic，或者什麼也不做。
    ///
    /// 此內在函數沒有穩定的對應對象。
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// 如果 `T` 不允許零初始化，則永遠無法執行的不安全功能的防護措施: 這將靜態 panic，或者什麼也不做。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn assert_zero_valid<T>();

    /// 如果 `T` 具有無效的位模式，則永遠不能執行的不安全功能的防護措施: 這將靜態 panic，或者什麼也不做。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn assert_uninit_valid<T>();

    /// 獲取對靜態 `Location` 的引用，該引用指示在何處調用它。
    ///
    /// 考慮改用 [`core::panic::Location::caller`](crate::panic::Location::caller)。
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// 將值移出範圍，而無需運行掉落膠水。
    ///
    /// 這僅適用於 [`mem::forget_unsized`]。普通的 `forget` 改用 `ManuallyDrop`。
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// 將一種類型的值的位重新解釋為另一種類型。
    ///
    /// 兩種類型都必須具有相同的大小。
    /// [invalid value](../../nomicon/what-unsafe-does.html) 既不是原始版本，也不是結果。
    ///
    /// `transmute` 在語義上等效於從一種類型到另一種類型的按位移動。它將位從源值複製到目標值，然後忘記原始值。
    /// 就像 C00X 一樣，它等同於 C 的引擎蓋下的 `memcpy`。
    ///
    /// 由於 `transmute` 是按值運算，因此 *轉換後的值本身* 的對齊是無關緊要的。
    /// 與任何其他功能一樣，編譯器已經確保 `T` 和 `U` 都正確對齊。
    /// 但是，當轉換 *指向其他位置* 的值 (例如指針，引用，框等) 時，調用者必須確保所指向的值正確對齊。
    ///
    /// `transmute` 是 `非常` 不安全的。有很多方法可以使 [undefined behavior][ub] 具有此功能。`transmute` 應該是絕對不得已的方法。
    ///
    /// [nomicon](../../nomicon/transmutes.html) 具有其他文檔。
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` 確實有一些用途。
    ///
    /// 將指針變成函數指針。對於功能指針和數據指針具有不同大小的機器，這不是 * 可移植的。
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// 延長壽命，或縮短不變壽命。這是高級的，非常不安全的 Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// 不要失望: `transmute` 的許多用途可以通過其他方式實現。
    /// 以下是 `transmute` 的常見應用程序，可以用更安全的結構替換它。
    ///
    /// 將原始 bytes(`&[u8]`) 轉換為 `u32`，`f64` 等:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // 改用 `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // 或使用 `u32::from_le_bytes` 或 `u32::from_be_bytes` 指定字節順序
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// 將指針變成 `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // 請改用 `as` 演員表
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// 將 `*mut T` 變成 `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // 改用借入
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// 將 `&mut T` 變成 `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // 現在，將 `as` 放在一起並重新借入，請注意 `as` `as` 的鏈接不是可傳遞的
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// 將 `&str` 變成 `&[u8]`:
    ///
    /// ```
    /// // 這不是執行此操作的好方法。
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // 您可以使用 `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // 或者，如果您可以控製字符串文字，則只需使用字節字符串
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// 將 `Vec<&T>` 變成 `Vec<Option<&T>>`。
    ///
    /// 要轉換容器內容的內部類型，必須確保不違反容器的任何不變式。
    /// 對於 `Vec`，這意味著內部類型的大小 *和對齊方式* 必須匹配。
    /// 其他容器可能依賴於類型，對齊方式甚至 `TypeId` 的大小，在這種情況下，在不違反容器不變式的情況下根本不可能進行轉換。
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // 克隆 vector，因為稍後我們將重用它們
    /// let v_clone = v_orig.clone();
    ///
    /// // 使用 transmute: 這依賴於 `Vec` 的未指定數據佈局，這是一個壞主意，並可能導致未定義的行為。
    /////
    /// // 但是，它是無副本的。
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // 這是建議的安全方法。
    /// // 但是，它確實將整個 vector 複製到一個新數組中。
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // 這是 "transmuting" 和 `Vec` 的正確無復制，不安全的方式，而無需依賴數據佈局。
    /// // 我們不執行字面上的調用 `transmute`，而是執行指針強制轉換，但是就將原始內部類型 (`&i32`) 轉換為新的 (`Option<&i32>`) 而言，這具有所有相同的警告。
    /////
    /// // 除了上面提供的信息之外，還請查閱 [`from_raw_parts`] 文檔。
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME 在 vec_into_raw_parts 穩定後更新此文件。
    ///     // 確保原始 vector 沒有被丟棄。
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// 實施 `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // 有多種方法可以執行此操作，並且以下 (transmute) 方法存在多個問題。
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // 第一: 轉換不是安全類型; 它所檢查的只是 T 和
    ///         // U 的大小相同。
    ///         // 其次，在這裡，您有兩個指向相同內存的可變引用。
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // 這消除了類型安全問題; `&mut *`* 僅 *將為您提供 `&mut T` 或 `* mut T` 的 `&mut T`。
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // 但是，您仍然有兩個指向相同內存的可變引用。
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // 這就是標準庫的工作方式。
    /// // 如果您需要執行以下操作，這是最好的方法
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // 現在，它具有指向同一內存的三個可變引用。`slice`，右值 ret.0 和右值 ret.1。
    ///         // `slice` `let ptr = ...` 之後從未使用過，因此可以將其視為 "dead"，因此，您只有兩個真正的可變片。
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: 雖然這使內部 const 穩定，但在 const fn 中我們有一些自定義代碼
    // 檢查以防止其在 `const fn` 中使用。
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// 如果 `T` 給出的實際類型需要滴膠，則返回 `true`; 否則返回 `true`。如果為 `T` 提供的實際類型實現 `Copy`，則返回 `false`。
    ///
    ///
    /// 如果實際類型既不需要滴膠也不需要實現 `Copy`，則該函數的返回值未指定。
    ///
    /// 此內在函數的穩定版本為 [`mem::needs_drop`](crate::mem::needs_drop)。
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// 計算與指針的偏移量。
    ///
    /// 這被實現為內在函數，以避免與整數進行轉換，因為轉換會丟棄別名信息。
    ///
    /// # Safety
    ///
    /// 起始指針和結果指針都必須在已分配對象末尾的範圍之內或一個字節內。
    /// 如果指針超出範圍或發生算術溢出，則進一步使用返回值將導致不確定的行為。
    ///
    ///
    /// 此內在函數的穩定版本為 [`pointer::offset`]。
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// 計算指針的偏移量，可能會自動換行。
    ///
    /// 這被實現為內在函數，以避免與整數進行相互轉換，因為該轉換會禁止某些優化。
    ///
    /// # Safety
    ///
    /// 與 `offset` 內部函數不同，此內部函數不會限制結果指針指向已分配對象的末尾或指向該對象末尾一個字節，並且使用二進制補碼算法進行換行。
    /// 結果值不一定有效地用於實際訪問內存。
    ///
    /// 此內在函數的穩定版本為 [`pointer::wrapping_offset`]。
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// 等效於適當的 `llvm.memcpy.p0i8.0i8.*` 本徵，大小為 `count`*`size_of::<T>()`，對齊方式為
    ///
    /// `min_align_of::<T>()`
    ///
    /// volatile 參數設置為 `true`，因此除非大小等於零，否則不會對其進行優化。
    ///
    /// 此內在函數沒有穩定的對應對象。
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// 等效於適當的 `llvm.memmove.p0i8.0i8.*` 本徵，大小為 `count* size_of::<T>()`，對齊方式為
    ///
    /// `min_align_of::<T>()`
    ///
    /// volatile 參數設置為 `true`，因此除非大小等於零，否則不會對其進行優化。
    ///
    /// 此內在函數沒有穩定的對應對象。
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// 等效於適當的 `llvm.memset.p0i8.*` 內部函數，其大小為 `count* size_of::<T>()`，並且對齊方式為 `min_align_of::<T>()`。
    ///
    ///
    /// volatile 參數設置為 `true`，因此除非大小等於零，否則不會對其進行優化。
    ///
    /// 此內在函數沒有穩定的對應對象。
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// 從 `src` 指針執行易失性加載。
    ///
    /// 此內在函數的穩定版本為 [`core::ptr::read_volatile`](crate::ptr::read_volatile)。
    pub fn volatile_load<T>(src: *const T) -> T;
    /// 對 `dst` 指針執行易失性存儲。
    ///
    /// 此內在函數的穩定版本為 [`core::ptr::write_volatile`](crate::ptr::write_volatile)。
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// 從 `src` 指針執行易失性加載不需要將指針對齊。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// 對 `dst` 指針執行易失性存儲。
    /// 指針不需要對齊。
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// 返回 `f32` 的平方根
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// 返回 `f64` 的平方根
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// 將 `f32` 提升為整數冪。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// 將 `f64` 提升為整數冪。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// 返回 `f32` 的正弦值。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// 返回 `f64` 的正弦值。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// 返回 `f32` 的餘弦值。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// 返回 `f64` 的餘弦值。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// 將 `f32` 提升到 `f32` 的功率。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// 將 `f64` 提升到 `f64` 的功率。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// 返回 `f32` 的指數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// 返回 `f64` 的指數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// 返回 2 乘以 `f32` 的冪。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// 返回 2 乘以 `f64` 的冪。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// 返回 `f32` 的自然對數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// 返回 `f64` 的自然對數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// 返回 `f32` 的以 10 為底的對數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// 返回 `f64` 的以 10 為底的對數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// 返回 `f32` 的以 2 為底的對數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// 返回 `f64` 的以 2 為底的對數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// 為 `f32` 值返回 `a * b + c`。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// 為 `f64` 值返回 `a * b + c`。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// 返回 `f32` 的絕對值。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// 返回 `f64` 的絕對值。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// 返回兩個 `f32` 值中的最小值。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// 返回兩個 `f64` 值中的最小值。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// 返回兩個 `f32` 值的最大值。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// 返回兩個 `f64` 值的最大值。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// 將 `f32` 值的符號從 `y` 複製到 `x`。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// 將 `f64` 值的符號從 `y` 複製到 `x`。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// 返回小於或等於 `f32` 的最大整數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// 返回小於或等於 `f64` 的最大整數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// 返回大於或等於 `f32` 的最小整數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// 返回大於或等於 `f64` 的最小整數。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// 返回 `f32` 的整數部分。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// 返回 `f64` 的整數部分。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// 返回最接近 `f32` 的整數。
    /// 如果參數不是整數，則可能會引發不精確的浮點異常。
    pub fn rintf32(x: f32) -> f32;
    /// 返回最接近 `f64` 的整數。
    /// 如果參數不是整數，則可能會引發不精確的浮點異常。
    pub fn rintf64(x: f64) -> f64;

    /// 返回最接近 `f32` 的整數。
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn nearbyintf32(x: f32) -> f32;
    /// 返回最接近 `f64` 的整數。
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn nearbyintf64(x: f64) -> f64;

    /// 返回最接近 `f32` 的整數。將中途案例舍入為零。
    ///
    /// 此內在函數的穩定版本是
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// 返回最接近 `f64` 的整數。將中途案例舍入為零。
    ///
    /// 此內在函數的穩定版本是
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// 浮點數加法允許基於代數規則進行優化。
    /// 可以假設輸入是有限的。
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// 浮點減法允許基於代數規則進行優化。
    /// 可以假設輸入是有限的。
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// 浮點乘法允許基於代數規則進行優化。
    /// 可以假設輸入是有限的。
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// 浮點除法允許基於代數規則進行優化。
    /// 可以假設輸入是有限的。
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// 浮餘數允許基於代數規則進行優化。
    /// 可以假設輸入是有限的。
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// 使用 LLVM 的 fptoui/fptosi 進行轉換，對於超出範圍的值可能會返回 undef
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// 穩定為 [`f32::to_int_unchecked`] 和 [`f64::to_int_unchecked`]。
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// 返回整數類型 `T` 中設置的位數
    ///
    /// 可通過 `count_ones` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// 返回整數類型 `T` 的前導未設置位 (zeroes) 的數量。
    ///
    /// 可通過 `leading_zeros` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// 值為 `0` 的 `x` 將返回 `T` 的位寬。
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// 類似於 `ctlz`，但是非常不安全，因為當給定值 `0` 的 `x` 時，它返回 `undef`。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// 返回整數類型 `T` 的尾隨未設置位 (zeroes) 的數量。
    ///
    /// 可通過 `trailing_zeros` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// 值為 `0` 的 `x` 將返回 `T` 的位寬:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// 類似於 `cttz`，但是非常不安全，因為當給定值 `0` 的 `x` 時，它返回 `undef`。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// 反轉整數類型 `T` 中的字節。
    ///
    /// 可通過 `swap_bytes` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// 反轉整數類型 `T` 中的位。
    ///
    /// 可通過 `reverse_bits` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// 執行檢查的整數加法。
    ///
    /// 可通過 `overflowing_add` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// 執行檢查的整數減法
    ///
    /// 可通過 `overflowing_sub` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// 執行檢查的整數乘法
    ///
    /// 可通過 `overflowing_mul` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// 執行精確除法，從而導致 `x % y != 0` 或 `y == 0` 或 `x == T::MIN && y == -1` 出現不確定的行為
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// 執行未經檢查的除法，從而導致 `y == 0` 或 `x == T::MIN && y == -1` 出現不確定的行為
    ///
    ///
    /// 可通過 `checked_div` 方法在整數基元上使用此內在函數的安全包裝。
    /// 例如，
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// 返回未經檢查的除法運算的餘數，當 `y == 0` 或 `x == T::MIN && y == -1` 時導致未定義的行為
    ///
    ///
    /// 可通過 `checked_rem` 方法在整數基元上使用此內在函數的安全包裝。
    /// 例如，
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// 執行未經檢查的左移，導致 `y < 0` 或 `y >= N` 出現不確定的行為，其中 N 是 T 的寬度 (以位為單位)。
    ///
    ///
    /// 可通過 `checked_shl` 方法在整數基元上使用此內在函數的安全包裝。
    /// 例如，
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// 執行未經檢查的右移，導致 `y < 0` 或 `y >= N` 出現不確定的行為，其中 N 是 T 的寬度 (以位為單位)。
    ///
    ///
    /// 可通過 `checked_shr` 方法在整數基元上使用此內在函數的安全包裝。
    /// 例如，
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// 返回未經檢查的加法運算的結果，導致 `x + y > T::MAX` 或 `x + y < T::MIN` 出現不確定的行為。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// 返回未經檢查的減法的結果，當 `x - y > T::MAX` 或 `x - y < T::MIN` 時導致未定義的行為。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// 返回未經檢查的乘法的結果，當 `x *y > T::MAX` 或 `x* y < T::MIN` 時導致未定義的行為。
    ///
    ///
    /// 此內在函數沒有穩定的對應對象。
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// 向左旋轉。
    ///
    /// 可通過 `rotate_left` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// 向右旋轉。
    ///
    /// 可通過 `rotate_right` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// 返回 (a + b) mod 2 <sup>N</sup>，其中 N 是 T 的寬度 (以位為單位)。
    ///
    /// 可通過 `wrapping_add` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// 返回 (a，b) mod 2 <sup>N</sup>，其中 N 是 T 的寬度 (以位為單位)。
    ///
    /// 可通過 `wrapping_sub` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// 返回 (a * b) mod 2 <sup>N</sup>，其中 N 是 T 的寬度 (以位為單位)。
    ///
    /// 可通過 `wrapping_mul` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// 計算 `a + b`，在數字範圍內達到飽和。
    ///
    /// 可通過 `saturating_add` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// 計算 `a - b`，在數字範圍內達到飽和。
    ///
    /// 可通過 `saturating_sub` 方法在整數基元上使用此內在函數的穩定版本。
    /// 例如，
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 返回 'v' 中變量的判別式的值;
    /// 如果 `T` 沒有判別，則返回 `0`。
    ///
    /// 此內在函數的穩定版本為 [`core::mem::discriminant`](crate::mem::discriminant)。
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// 返回強制轉換為 `usize` 的 `T` 類型的變體的數量;
    /// 如果 `T` 沒有變體，則返回 `0`。無人居住的變種將被計算在內。
    ///
    /// 此內在函數的穩定版本為 [`mem::variant_count`]。
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust 的 "try catch" 構造使用數據指針 `data` 調用功能指針 `try_fn`。
    ///
    /// 第三個參數是如果發生 panic 則調用的函數。
    /// 此函數採用數據指針和指向已捕獲的特定於目標的異常對象的指針。
    ///
    /// 有關更多信息，請參見編譯器的源代碼以及 std 的 catch 實現。
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// 根據 LLVM 發出 `!nontemporal` 存儲 (請參閱其文檔)。
    /// 可能永遠都不會變得穩定。
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// 有關詳細信息，請參見 `<*const T>::offset_from` 的文檔。
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// 有關詳細信息，請參見 `<*const T>::guaranteed_eq` 的文檔。
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// 有關詳細信息，請參見 `<*const T>::guaranteed_ne` 的文檔。
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// 在編譯時分配。不應在運行時調用。
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// 之所以在此定義一些功能，是因為它們意外地在穩定模塊中可用。
// 請參閱 <https://github.com/rust-lang/rust/issues/15702>。
// (`transmute` 也屬於此類別，但是由於檢查 `T` 和 `U` 具有相同的大小，因此無法將其包裝。)
//

/// 檢查 `ptr` 是否相對於 `align_of::<T>()` 正確對齊。
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// 將 `count *size_of::<T>()` 字節從 `src` 複製到 `dst`。源和目標必須* 不*重疊。
///
/// 對於可能重疊的內存區域，請改用 [`copy`]。
///
/// `copy_nonoverlapping` 在語義上等效於 C 的 [`memcpy`]，但是交換了參數順序。
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `src` 必須為 [valid] 才能讀取 `count * size_of::<T>()` 字節。
///
/// * `dst` 對於寫入 `count * size_of::<T>()` 字節，必須為 [valid]。
///
/// * `src` 和 `dst` 必須正確對齊。
///
/// * 從 `src` 開始的內存區域，大小為 `count *
///   size_of: :<T> () ` 字節不得與以 `dst` 開始且大小相同的內存區域重疊。
///
/// 與 [`read`] 一樣，無論 `T` 是否為 [`Copy`]，`copy_nonoverlapping` 都會創建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，則同時使用 *兩者* 和 [violate memory safety][read-ownership] 開頭的區域中的值都可以 [violate memory safety][read-ownership]。
///
///
/// 請注意，即使有效複製的大小 (`count * size_of: :: <T> () `) 為 `0`，則指針必須為非 NULL 並正確對齊。
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// 手動實施 [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// 將 `src` 的所有元素移到 `dst`，將 `src` 留空。
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // 確保 `dst` 具有足夠的容量來容納所有 `src`。
///     dst.reserve(src_len);
///
///     unsafe {
///         // 調用 offset 始終是安全的，因為 `Vec` 分配的字節數永遠不會超過 `isize::MAX` 字節。
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // 截斷 `src` 而不刪除其內容。
///         // 我們首先執行此操作，以避免在 panics 處出現問題時避免出現問題。
///         src.set_len(0);
///
///         // 這兩個區域不能重疊，因為可變引用沒有別名，並且兩個不同的 vectors 無法擁有相同的內存。
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // 通知 `dst` 現在包含 `src` 的內容。
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: 僅在運行時執行這些檢查
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // 不要驚慌，以保持代碼生成的影響較小。
        abort();
    }*/

    // 安全: `copy_nonoverlapping` 的安全合同必須
    // 被调用者堅持。
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// 將 `count * size_of::<T>()` 字節從 `src` 複製到 `dst`。源和目標可能會重疊。
///
/// 如果源和目標永遠不會重疊，則可以改用 [`copy_nonoverlapping`]。
///
/// `copy` 在語義上等效於 C 的 [`memmove`]，但是交換了參數順序。
/// 就像將字節從 `src` 複製到臨時數組，然後從數組複製到 `dst` 一樣進行複制。
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `src` 必須為 [valid] 才能讀取 `count * size_of::<T>()` 字節。
///
/// * `dst` 對於寫入 `count * size_of::<T>()` 字節，必須為 [valid]。
///
/// * `src` 和 `dst` 必須正確對齊。
///
/// 與 [`read`] 一樣，無論 `T` 是否為 [`Copy`]，`copy` 都會創建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，則可以同時使用以 `*src` 開頭的區域和以 `* dst` 開頭的區域中的值。
///
///
/// 請注意，即使有效複製的大小 (`count * size_of: :: <T> () `) 為 `0`，則指針必須為非 NULL 並正確對齊。
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// 從不安全的緩衝區有效地創建 Rust vector:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` 必須正確對齊其類型且非零。
/// /// * `ptr` 必須對讀取 `T` 類型的 `elts` 連續元素有效。
/// /// * 除非 `T: Copy`，否則在調用此函數後不得使用這些元素。
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // 安全: 我們的前提條件是確保源頭對準並有效，
///     // `Vec::with_capacity` 確保我們有可用的空間來編寫它們。
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // 安全: 我們之前曾以這麼大的容量創建它，
///     // 並且以前的 `copy` 已經初始化了這些元素。
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: 僅在運行時執行這些檢查
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // 不要驚慌，以保持代碼生成的影響較小。
        abort();
    }*/

    // 安全: 调用者必須遵守 `copy` 的安全合同。
    unsafe { copy(src, dst, count) }
}

/// 將從 `dst` 開始的 `count * size_of::<T>()` 內存字節設置為 `val`。
///
/// `write_bytes` 與 C 的 [`memset`] 類似，但是將 `count * size_of::<T>()` 字節設置為 `val`。
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `dst` 對於寫入 `count * size_of::<T>()` 字節，必須為 [valid]。
///
/// * `dst` 必須正確對齊。
///
/// 此外，調用者必須確保將 `count * size_of::<T>()` 字節寫入給定的內存區域會導致 `T` 的有效值。
/// 使用類型為 `T` 的內存區域包含無效的 `T` 值是未定義的行為。
///
/// 請注意，即使有效複製的大小 (`count * size_of: :: <T> () `) 是 `0`，則指針必須為非 NULL 並正確對齊。
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// 創建一個無效值:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // 通過使用空指針覆蓋 `Box<T>`，洩漏先前保留的值。
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // 此時，使用或刪除 `v` 會導致未定義的行為。
/// // drop(v); // ERROR
///
/// // 即使 `v` "uses" 洩漏了它，因此也是未定義的行為。
/// // mem::forget(v); // ERROR
///
/// // 實際上，根據基本類型佈局不變式，`v` 無效，因此觸摸它的 *any* 操作是未定義的行為。
/////
/// // 令 v2 =v;// 錯誤
///
/// unsafe {
///     // 讓我們輸入一個有效值
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // 現在盒子好了
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // 安全: 调用者必須遵守 `write_bytes` 的安全合同。
    unsafe { write_bytes(dst, val, count) }
}