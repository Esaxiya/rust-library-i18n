# `rustc-std-workspace-std` crate

請參閱 `rustc-std-workspace-core` crate 的文檔。