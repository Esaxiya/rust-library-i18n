//! 單線程引用計數指針。'Rc' 代表 `參考`
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] 類型提供了在堆中分配的 `T` 類型值的共享所有權。
//! 在 [`Rc`] 上調用 [`clone`][clone] 會產生一個指向堆中相同分配的新指針。
//! 當指向給定分配的最後一個 [`Rc`] 指針被破壞時，存儲在該分配中的值 (通常稱為 "inner value") 也將被刪除。
//!
//! 默認情況下，Rust 中的共享引用不允許更改，並且 [`Rc`] 也不例外: 您通常無法獲得對 [`Rc`] 內部內容的可變引用。
//! 如果需要可變性，請將 [`Cell`] 或 [`RefCell`] 放在 [`Rc`] 內; 請參閱 [an example of mutability inside an `Rc`][mutability]。
//!
//! [`Rc`] 使用非原子引用計數。
//! 這意味著開銷非常低，但是 [`Rc`] 無法在線程之間發送，因此 [`Rc`] 無法實現 [`Send`][send]。
//! 結果，Rust 編譯器將在編譯時檢查您是否沒有在線程之間發送 [Rc]。
//! 如果需要多線程原子引用計數，請使用 [`sync::Arc`][arc]。
//!
//! [`downgrade`][downgrade] 方法可用於創建非所有者 [`Weak`] 指針。
//! [`Weak`] 指針可以被 [`upgrade`][upgrade] d 到 [`Rc`]，但是如果已經刪除了分配中存儲的值，則它將返回 [`None`]。
//! 換句話說，`Weak` 指針不會使分配內部的值保持活動狀態。但是，它們確實使分配 (內部值的後備存儲) 保持活動狀態。
//!
//! [`Rc`] 指針之間的循環將永遠不會被釋放。
//! 因此，[`Weak`] 用於中斷循環。
//! 例如，一棵樹可能具有從父節點到子節點的強 [`Rc`] 指針，以及從子節點到其父節點的 [`Weak`] 指針。
//!
//! `Rc<T>` 自動取消對 `T` 的引用 (通過 [`Deref`] trait)，因此您可以在 [`Rc<T>`][`Rc`] 類型的值上調用 `T` 的方法。
//! 為了避免與 T 方法的名稱衝突，[`Rc<T>`][`Rc`] 本身的方法是關聯的函數，使用 [fully qualified syntax] 進行調用:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `RC<T> 像 `Clone` 這樣的 traits 的實現也可以使用完全限定的語法來調用。
//! 有些人喜歡使用完全限定的語法，而另一些人則喜歡使用方法調用語法。
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // 方法調用語法
//! let rc2 = rc.clone();
//! // 完全合格的語法
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] 不會自動取消對 `T` 的引用，因為可能已經刪除了內部值。
//!
//! # 克隆參考
//!
//! 使用為 [`Rc<T>`][`Rc`] 和 [`Weak<T>`][`Weak`] 實現的 `Clone` trait，可以創建與現有引用計數指針相同的分配的新引用。
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // 以下兩種語法是等效的。
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a 和 b 都指向與 foo 相同的內存位置。
//! ```
//!
//! `Rc::clone(&from)` 語法是最常見的語法，因為它更明確地傳達了代碼的含義。
//! 在上面的示例中，使用此語法可以更輕鬆地看到此代碼正在創建新引用，而不是複制 foo 的全部內容。
//!
//! # Examples
//!
//! 考慮一個場景，其中給定的 `Owner` 擁有一組 `小工具`。
//! 我們想讓我們的 `小工具` 指向他們的 `Owner`。我們不能用唯一的所有權來做到這一點，因為一個以上的小工具可能屬於同一個 `Owner`。
//! [`Rc`] 允許我們在多個 `小工具` 之間共享 `Owner`，並且只要 `Gadget` 指向它，`Owner` 就會一直分配。
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... 其他領域
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... 其他領域
//! }
//!
//! fn main() {
//!     // 創建一個引用計數的 `Owner`。
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // 創建屬於 `gadget_owner` 的 `小工具`。
//!     // 克隆 `Rc<Owner>` 為我們提供了指向相同 `Owner` 分配的新指針，從而增加了過程中的引用計數。
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // 處理我們的局部變量 `gadget_owner`。
//!     drop(gadget_owner);
//!
//!     // 儘管刪除了 `gadget_owner`，我們仍然可以打印出 `小工具` 的 `Owner` 的名稱。
//!     // 這是因為我們只刪除了一個 `Rc<Owner>`，而不是它指向的 `Owner`。
//!     // 只要還有其他 `Rc<Owner>` 指向相同的 `Owner` 分配，它將保持活動狀態。
//!     // 字段投影 `gadget1.owner.name` 起作用是因為 `Rc<Owner>` 自動取消引用 `Owner`。
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // 在函數結束時，`gadget1` 和 `gadget2` 被銷毀，並且它們與我們的 `Owner` 的最後計數引用也被銷毀。
//!     // 小工具人現在也被摧毀。
//!     //
//! }
//! ```
//!
//! 如果我們的要求發生變化，並且還需要能夠從 `Owner` 遍歷到 `Gadget`，我們將遇到問題。
//! 從 `Owner` 到 `Gadget` 的 [`Rc`] 指針引入了一個循環。
//! 這意味著它們的引用計數永遠不會達到 0，並且分配也永遠不會被破壞:
//! 內存洩漏。為了解決這個問題，我們可以使用 [`Weak`] 指針。
//!
//! 實際上，Rust 使得在某種程度上很難產生此循環。為了最終得到兩個指向彼此的值，其中之一需要是可變的。
//! 這很困難，因為 [`Rc`] 僅通過給出對其包裝的值的共享引用來增強內存安全性，並且這些不允許直接突變。
//! 我們需要將希望突變的值的一部分包裝在 [`RefCell`] 中，它提供了 *內部可變性*: 一種通過共享引用實現可變性的方法。
//! [`RefCell`] 在運行時強制執行 Rust 的借入規則。
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... 其他領域
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... 其他領域
//! }
//!
//! fn main() {
//!     // 創建一個引用計數的 `Owner`。
//!     // 請注意，我們已將小工具的所有者的 vector 放在 `RefCell` 內，以便我們可以通過共享引用對其進行變異。
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // 和以前一樣，創建屬於 `gadget_owner` 的 `小工具`。
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // 將 `小工具` 添加到其 `Owner` 中。
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` 動態借貸到此結束。
//!     }
//!
//!     // 遍歷我們的 `小工具`，將其詳細信息打印出來。
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` 是 `Weak<Gadget>`。
//!         // 由於 `Weak` 指針不能保證分配仍然存在，因此我們需要調用 `upgrade`，它返回 `Option<Rc<Gadget>>`。
//!         //
//!         //
//!         // 在這種情況下，我們知道分配仍然存在，因此我們只用 `unwrap` 和 `Option`。
//!         // 在更複雜的程序中，可能需要適當的錯誤處理才能獲得 `None` 結果。
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // 函數結束時，`gadget_owner`，`gadget1` 和 `gadget2` 被銷毀。
//!     // 現在沒有指向該小工具的強大 (`Rc`) 指針，因此它們已被銷毀。
//!     // 這會將小工具人的參考計數歸零，因此他也將被銷毀。
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// 這是 repr(C) 到 future 的證明，可防止可能的字段重新排序，否則可能會干擾可互換內部類型的安全 [into|from]_raw()。
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// 單線程引用計數指針。'Rc' 代表 `參考`
/// Counted'.
///
/// 有關更多詳細信息，請參見 [module-level documentation](./index.html)。
///
/// `Rc` 的固有方法都是與之相關的函數，這意味著您必須將其稱為例如 [`Rc::get_mut(&mut value)`][get_mut] 而不是 `value.get_mut()`。
/// 這樣可以避免與內部類型 `T` 的方法發生衝突。
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // 這種不安全性是可以的，因為在此 Rc 處於活動狀態時，我們保證內部指針有效。
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// 構造一個新的 `Rc<T>`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // 所有強指針都擁有一個隱式的弱指針，以確保即使強指針中存儲了弱指針，弱析構函數也不會在強析構函數運行時釋放分配。
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// 使用對自身的弱引用來構造新的 `Rc<T>`。
    /// 嘗試在此函數返回之前升級弱引用將導致 `None` 值。
    ///
    /// 但是，弱參考可以自由克隆並存儲以備後用。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... 更多領域
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // 使用單個弱引用在 "uninitialized" 狀態下構造內部。
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // 重要的是我們不要放棄弱指針的所有權，否則在 `data_fn` 返回時可能會釋放內存。
        // 如果我們真的想傳遞所有權，則可以為自己創建一個額外的弱指針，但這將導致對該弱引用計數的其他更新，否則可能不需要這樣做。
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // 強引用應該共同擁有一個共享的弱引用，因此不要為我們的舊弱引用運行析構函數。
        //
        mem::forget(weak);
        strong
    }

    /// 構造一個具有未初始化內容的新 `Rc`。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // 延遲初始化:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// 構造一個具有未初始化內容的新 `Rc`，並用 `0` 字節填充內存。
    ///
    ///
    /// 有關正確和不正確使用此方法的示例，請參見 [`MaybeUninit::zeroed`][zeroed]。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// 構造一個新的 `Rc<T>`，如果分配失敗，則返回錯誤
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // 所有強指針都擁有一個隱式的弱指針，以確保即使強指針中存儲了弱指針，弱析構函數也不會在強析構函數運行時釋放分配。
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// 構造具有未初始化內容的新 `Rc`，如果分配失敗，則返回錯誤
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // 延遲初始化:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// 構造一個具有未初始化內容的新 `Rc`，並用 `0` 字節填充內存，如果分配失敗，則返回錯誤
    ///
    ///
    /// 有關正確和不正確使用此方法的示例，請參見 [`MaybeUninit::zeroed`][zeroed]。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// 構造一個新的 `Pin<Rc<T>>`。
    /// 如果 `T` 未實現 `Unpin`，則 `value` 將被固定在內存中並且無法移動。
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// 如果 `Rc` 正好具有一個強引用，則返回內部值。
    ///
    /// 否則，返回的 [`Err`] 將與傳入的 `Rc` 相同。
    ///
    ///
    /// 即使存在出色的弱引用，此操作也會成功。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // 複製包含的對象

                // 向 Weaks 表示不能通過減少強計數來提升它們，然後刪除隱式 "strong weak" 指針，同時也只能通過偽造 Weak 來處理放置邏輯。
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// 使用未初始化的內容構造一個新的引用計數切片。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // 延遲初始化:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// 構造一個具有未初始化內容的新引用計數切片，內存中填充 `0` 字節。
    ///
    ///
    /// 有關正確和不正確使用此方法的示例，請參見 [`MaybeUninit::zeroed`][zeroed]。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// 轉換為 `Rc<T>`。
    ///
    /// # Safety
    ///
    /// 與 [`MaybeUninit::assume_init`] 一樣，由調用方負責確保內部值確實處於初始化狀態。
    ///
    /// 在內容尚未完全初始化時調用此方法會立即導致未定義的行為。
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // 延遲初始化:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// 轉換為 `Rc<[T]>`。
    ///
    /// # Safety
    ///
    /// 與 [`MaybeUninit::assume_init`] 一樣，由調用方負責確保內部值確實處於初始化狀態。
    ///
    /// 在內容尚未完全初始化時調用此方法會立即導致未定義的行為。
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // 延遲初始化:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// 消耗 `Rc`，返回包裝的指針。
    ///
    /// 為避免內存洩漏，必須使用 [`Rc::from_raw`][from_raw] 將指針轉換回 `Rc`。
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// 提供指向數據的原始指針。
    ///
    /// 計數不會受到任何影響，並且不會消耗 `Rc`。
    /// 只要 `Rc` 中存在大量計數，指針就有效。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // 安全: 這不能通過 Deref::deref 或 Rc::inner，因為
        // 這是保留 raw/mut 來源所必需的，例如
        // `get_mut` 通過 `from_raw` 恢復 Rc 後，可以通過指針寫入。
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// 根據原始指針構造 `Rc<T>`。
    ///
    /// 原始指針必須事先通過調用 [`Rc<U>::into_raw`][into_raw] 返回，其中 `U` 必須具有與 `T` 相同的大小和對齊方式。
    /// 如果 `U` 是 `T`，這是很簡單的。
    /// 請注意，如果 `U` 不是 `T`，但是具有相同的大小和對齊方式，則基本上就像改變類型的引用一樣。
    /// 有關在這種情況下適用的限制的更多信息，請參見 [`mem::transmute`][transmute]。
    ///
    /// `from_raw` 的用戶必須確保 `T` 的特定值僅被刪除一次。
    ///
    /// 此功能是不安全的，因為不當使用該操作可能會導致內存不安全，即使從未訪問返回的 `Rc<T>` 也是如此。
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // 轉換回 `Rc` 以防止洩漏。
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // 進一步調用 `Rc::from_raw(x_ptr)` 將導致內存不安全。
    /// }
    ///
    /// // 當 `x` 超出上述範圍時，內存被釋放，因此 `x_ptr` 現在懸空了!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // 反轉偏移量以找到原始的 RcBox。
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// 創建一個指向該分配的新 [`Weak`] 指針。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // 確保我們不會產生懸空的弱點
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// 獲取指向該分配的 [`Weak`] 指針的數量。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// 獲取指向此分配的強 (`Rc`) 指針的數量。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// 如果沒有其他指向該分配的 `Rc` 或 [`Weak`] 指針，則返回 `true`。
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// 如果沒有其他 `Rc` 或 [`Weak`] 指向相同分配的指針，則返回給定 `Rc` 的可變引用。
    ///
    ///
    /// 否則返回 [`None`]，因為更改共享值並不安全。
    ///
    /// 另請參見 [`make_mut`][make_mut]，當有其他指針時，它將 [`clone`][clone] 內部值。
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// 將可變引用返回給定的 `Rc`，而不進行任何檢查。
    ///
    /// 另請參閱 [`get_mut`]，它是安全的並進行適當的檢查。
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// 在返回的借用期間，不得取消引用相同分配的任何其他 `Rc` 或 [`Weak`] 指針。
    ///
    /// 如果不存在這樣的指針 (例如緊接在 `Rc::new` 之後)，則情況很簡單。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // 我們小心 *不要* 創建覆蓋 "count" 字段的引用，因為這會與對引用計數的訪問產生衝突 (例如
        // 由 `Weak`)。
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// 如果兩個 Rc 指向相同的分配 (類似於 [`ptr::eq`])，則返回 `true`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// 對給定的 `Rc` 進行可變引用。
    ///
    /// 如果還有其他指向同一分配的 `Rc` 指針，則 `make_mut` 會將 [`clone`] 的內部值分配給新分配，以確保唯一的所有權。
    /// 這也稱為寫時克隆。
    ///
    /// 如果沒有其他指向該分配的 `Rc` 指針，則指向該分配的 [`Weak`] 指針將被取消關聯。
    ///
    /// 另請參見 [`get_mut`]，它將失敗而不是克隆。
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // 不會克隆任何東西
    /// let mut other_data = Rc::clone(&data);    // 不會克隆內部數據
    /// *Rc::make_mut(&mut data) += 1;        // 克隆內部數據
    /// *Rc::make_mut(&mut data) += 1;        // 不會克隆任何東西
    /// *Rc::make_mut(&mut other_data) *= 2;  // 不會克隆任何東西
    ///
    /// // 現在，`data` 和 `other_data` 指向不同的分配。
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] 指針將被取消關聯:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // 要克隆數據，還有其他 Rcs。
            // 預分配內存以允許直接寫入克隆的值。
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // 只能竊取數據，剩下的就是弱點
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // 刪除隱式的強弱引用 (無需在此處製作假的弱項 - 我們知道其他弱項也可以為我們清除)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // 這種不安全性是可以的，因為我們保證返回的指針是將永遠返回到 T 的 *only* 指針。
        // 此時我們的引用計數保證為 1，並且我們要求 `Rc<T>` 本身為 `mut`，因此我們將唯一可能的引用返回給分配。
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// 嘗試將 `Rc<dyn Any>` 轉換為具體類型。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// 為 `RcBox<T>` 分配足夠的空間，以容納可能未設置大小的內部值，其中該值具有提供的佈局。
    ///
    /// 函數 `mem_to_rcbox` 用數據指針調用，並且必須為 `RcBox<T>` 返回一個 (可能是胖的) 指針。
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // 使用給定的值佈局計算佈局。
        // 以前，在表達式 `&*(ptr as* const RcBox<T>)` 上計算佈局，但是這會創建未對齊的參考 (請參閱 #54908)。
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// 為 `RcBox<T>` 分配足夠的空間，以容納可能未設置大小的內部值 (該值具有提供的佈局)，如果分配失敗，則返回錯誤。
    ///
    ///
    /// 函數 `mem_to_rcbox` 用數據指針調用，並且必須為 `RcBox<T>` 返回一個 (可能是胖的) 指針。
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // 使用給定的值佈局計算佈局。
        // 以前，在表達式 `&*(ptr as* const RcBox<T>)` 上計算佈局，但是這會創建未對齊的參考 (請參閱 #54908)。
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // 分配佈局。
        let ptr = allocate(layout)?;

        // 初始化 RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// 為 `RcBox<T>` 分配足夠的空間以容納未調整的內部值
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // 使用給定的值分配 `RcBox<T>`。
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // 將值複製為字節
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // 釋放分配而不刪除其內容
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// 用給定的長度分配 `RcBox<[T]>`。
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// 將元素從切片複製到新分配的 Rc <\[T\]>
    ///
    /// 不安全，因為调用者必須擁有所有權或綁定 `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// 從已知為一定大小的迭代器構造 `Rc<[T]>`。
    ///
    /// 如果大小錯誤，行為是不確定的。
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic 在克隆 T 元素時進行保護。
        // 如果出現 panic，將刪除已寫入新 RcBox 的元素，然後釋放內存。
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // 指向第一個元素的指針
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // 全清。忘了守衛吧，這樣就不會釋放新的 RcBox。
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` 使用的專業化 trait。
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// 放下 `Rc`。
    ///
    /// 這將減少強引用計數。
    /// 如果強引用計數達到零，那麼僅有的其他引用 (如果有) 是 [`Weak`]，因此我們將 `drop` 作為內部值。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // 不打印任何東西
    /// drop(foo2);   // 打印 "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // 銷毀所包含的對象
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // 現在我們已經破壞了內容，請刪除隱式 "strong weak" 指針。
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// 克隆 `Rc` 指針。
    ///
    /// 這將創建另一個指向相同分配的指針，從而增加了強引用計數。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// 用 `T` 的 `Default` 值創建一個新的 `Rc<T>`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// 即使 `Eq` 有一種方法，也可以允許專門研究 `Eq`。
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// 我們在這裡進行這種專門化，而不是對 `&T` 進行更一般的優化，因為否則會增加對引用的所有相等性檢查的成本。
/// 我們假設 `Rc`s 用於存儲較大的值，這些值克隆起來較慢，但在檢查相等性時又很繁瑣，從而使此成本更容易得到回報。
///
/// 與兩個 `＆T` 相比，它更有可能具有兩個指向相同值的 `Rc` 克隆。
///
/// 僅當 `T: Eq` 作為 `PartialEq` 故意不自反時，我們才能執行此操作。
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// 兩個 Rc 相等。
    ///
    /// 即使兩個 `Rc` 的內部值相等，即使它們存儲在不同的分配中，它們也相等。
    ///
    /// 如果 `T` 還實現了 `Eq` (暗示相等的自反性)，則指向同一分配的兩個 Rc 始終相等。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// 兩個 `Rc` 的不等式。
    ///
    /// 如果兩個 `Rc` 的內部值不相等，則它們是不相等的。
    ///
    /// 如果 `T` 還實現了 `Eq` (暗示相等性的反射性)，則指向同一分配的兩個 Rc 永遠不會相等。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// 兩個 `Rc` 的部分比較。
    ///
    /// 通過調用 `partial_cmp()` 的內部值來比較兩者。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// 小於兩個 Rc 的比較。
    ///
    /// 通過調用 `<` 的內部值來比較兩者。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 兩個 `Rc` 的 `小於或等於` 比較。
    ///
    /// 通過調用 `<=` 的內部值來比較兩者。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// 大於兩個 Rc 的比較。
    ///
    /// 通過調用 `>` 的內部值來比較兩者。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 兩個 `Rc` 的 `大於或等於` 比較。
    ///
    /// 通過調用 `>=` 的內部值來比較兩者。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// 兩個 `Rc` 的比較。
    ///
    /// 通過調用 `cmp()` 的內部值來比較兩者。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// 分配參考計數的切片，並通過克隆 `v` 的項目來填充它。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// 分配參考計數的字符串切片並將 `v` 複製到其中。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// 分配參考計數的字符串切片並將 `v` 複製到其中。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// 將裝箱的對象移動到新的參考計數分配。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// 分配參考計數切片並將 v 項移入其中。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // 允許 Vec 釋放其內存，但不破壞其內容
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// 獲取 `Iterator` 中的每個元素，並將其收集到 `Rc<[T]>` 中。
    ///
    /// # 性能特點
    ///
    /// ## 一般情況
    ///
    /// 在一般情況下，首先要收集到 `Vec<T>` 中來收集到 `Rc<[T]>` 中。也就是說，編寫以下內容時:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// 這就像我們寫的那樣:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // 第一組分配在此處發生。
    ///     .into(); // `Rc<[T]>` 的第二個分配在此處進行。
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// 這將分配構造 `Vec<T>` 所需的次數，然後分配一次，以將 `Vec<T>` 轉換為 `Rc<[T]>`。
    ///
    ///
    /// ## 已知長度的迭代器
    ///
    /// 當您的 `Iterator` 實現 `TrustedLen` 且大小正確時，將為 `Rc<[T]>` 進行一次分配。例如:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // 這裡只進行一次分配。
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// 專門的 trait 用於收集到 `Rc<[T]>` 中。
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // `TrustedLen` 迭代器就是這種情況。
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // 安全: 我們需要確保迭代器具有正確的長度，並且具有正確的長度。
                Rc::from_iter_exact(self, low)
            }
        } else {
            // 退回正常實施。
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` 是 [`Rc`] 的版本，其中包含對託管分配的非所有者引用。通過調用 `Weak` 指針上的 [`upgrade`] 來訪問該分配，該指針返回一個 [`Option`]`<`[`Rc`]`<T>>`。
///
/// 由於 `Weak` 引用不計入所有權，因此它不會防止存儲在分配中的值被丟棄，並且 `Weak` 本身不保證該值仍然存在。
/// 因此，當 [`upgrade`] d 時，它可能返回 [`None`]。
/// 但是請注意，`Weak` 引用確實會阻止分配本身 (後備存儲) 被釋放。
///
/// `Weak` 指針對於保持對 [`Rc`] 管理的分配的臨時引用很有用，而又不會阻止其內部值被丟棄。
/// 它也用於防止 [`Rc`] 指針之間的循環引用，因為相互擁有的引用絕不允許丟棄 [`Rc`]。
/// 例如，一棵樹可能具有從父節點到子節點的強 [`Rc`] 指針，以及從子節點到其父節點的 `Weak` 指針。
///
/// 獲取 `Weak` 指針的典型方法是調用 [`Rc::downgrade`]。
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // 這是一個 `NonNull`，允許在枚舉中優化此類型的大小，但它不一定是有效的指針。
    //
    // `Weak::new` 將此設置為 `usize::MAX`，以便不需要在堆上分配空間。
    // 這不是真正的指針所具有的值，因為 RcBox 的對齊方式至少為 2。
    // 僅當 `T: Sized` 時才有可能。沒有尺寸的 `T` 永遠不會晃來晃去。
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// 構造一個新的 `Weak<T>`，而不分配任何內存。
    /// 在返回值上調用 [`upgrade`] 總是得到 [`None`]。
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// 幫助程序類型，允許訪問引用計數而無需對數據字段進行任何聲明。
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// 返回指向該 `Weak<T>` 指向的對象 `T` 的原始指針。
    ///
    /// 僅當有一些強引用時，該指針才有效。
    /// 指針可能懸空，未對齊，或者甚至 [`null`]。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // 兩者都指向同一個對象
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // 這裡的強項使它保持活動狀態，因此我們仍然可以訪問該對象。
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // 但是沒有更多了。
    /// // 我們可以執行 weak.as_ptr()，但是訪問指針將導致未定義的行為。
    /// // assert_eq! (`hello`，不安全 {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // 如果指針懸空，我們將直接返回哨兵。
            // 這不能是有效的有效負載地址，因為有效負載至少與 RcBox (usize) 對齊。
            ptr as *const T
        } else {
            // 安全: 如果 is_dangling 返回 false，則該指針是可取消引用的。
            // 此時可能會刪除有效負載，並且我們必須保持出處，因此請使用原始指針操作。
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// 消耗 `Weak<T>` 並將其轉換為原始指針。
    ///
    /// 這會將弱指針轉換為原始指針，同時仍保留一個弱引用的所有權 (該操作不會修改弱計數)。
    /// 可以將其轉換回帶有 [`from_raw`] 的 `Weak<T>`。
    ///
    /// 與 [`as_ptr`] 一樣，訪問指針目標的限制也適用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// 將先前由 [`into_raw`] 創建的原始指針轉換回 `Weak<T>`。
    ///
    /// 這可用於安全地獲得強引用 (稍後調用 [`upgrade`]) 或通過刪除 `Weak<T>` 來分配弱計數。
    ///
    /// 它擁有一個弱引用的所有權 ([`new`] 創建的指針除外，因為它們不擁有任何東西; 該方法仍可對它們起作用)。
    ///
    /// # Safety
    ///
    /// 指針必須源自 [`into_raw`]，並且仍必須擁有其潛在的弱引用。
    ///
    /// 調用時允許強計數為 0。
    /// 但是，這需要當前表示為原始指針的一個弱引用的所有權 (該操作不會修改弱計數)，因此必須與先前對 [`into_raw`] 的調用配對。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // 減少最後一個弱計數。
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // 有關如何派生輸入指針的上下文，請參見 Weak::as_ptr。

        let ptr = if is_dangling(ptr as *mut T) {
            // 這是懸空的弱點。
            ptr as *mut RcBox<T>
        } else {
            // 否則，我們保證指針來自無懸掛的弱。
            // 安全: data_offset 可以安全調用，因為 ptr 引用了實數 (可能已刪除)。
            let offset = unsafe { data_offset(ptr) };
            // 因此，我們反轉偏移量以獲得整個 RcBox。
            // 安全: 指針源自弱點，因此此偏移量是安全的。
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // 安全: 現在我們已經恢復了原始的弱指針，因此可以創建弱指針。
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// 嘗試將 `Weak` 指針升級到 [`Rc`]，如果成功，則延遲內部值的刪除。
    ///
    ///
    /// 如果此後已刪除內部值，則返回 [`None`]。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // 銷毀所有強指針。
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// 獲取指向該分配的強 (`Rc`) 指針的數量。
    ///
    /// 如果 `self` 是使用 [`Weak::new`] 創建的，則將返回 0。
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// 獲取指向該分配的 `Weak` 指針的數量。
    ///
    /// 如果沒有剩餘的強指針，它將返回零。
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // 減去隱含的弱點
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// 當指針懸空並且沒有分配的 `RcBox` 時 (即，當 `Weak` 由 `Weak::new` 創建時)，返回 `None`。
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // 我們小心 *不要* 創建覆蓋 "data" 字段的引用，因為該字段可能會同時發生突變 (例如，如果刪除了最後一個 `Rc`，則數據字段將被原地刪除)。
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// 如果兩個 `Weak` 指向相同的分配 (類似於 [`ptr::eq`])，或者兩個都不指向任何分配 (因為它們是用 `Weak::new()`) 創建的)，則返回 `true`。
    ///
    ///
    /// # Notes
    ///
    /// 由於這將比較指針，因此即使它們不指向任何分配，也意味著 `Weak::new()` 將彼此相等。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// 比較 `Weak::new`。
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// 刪除 `Weak` 指針。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // 不打印任何東西
    /// drop(foo);        // 打印 "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // 弱計數從 1 開始，並且只有在所有強指針都消失後才會變為零。
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// 克隆 `Weak` 指針，該指針指向相同的分配。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// 構造一個新的 `Weak<T>`，為 `T` 分配內存而不初始化它。
    /// 在返回值上調用 [`upgrade`] 總是得到 [`None`]。
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: 我們在這裡 check_add 來安全地處理 mem::forget。特別是
// 如果您使用 mem::forget Rcs (或 Weaks)，則引用計數可能會溢出，然後您可以在存在出色的 Rcs (或 Weaks) 的情況下釋放分配。
//
// 我們中止，因為這是一個簡陋的場景，我們不在乎會發生什麼 - 真正的程序都不會遇到這種情況。
//
// 這應該具有可忽略的開銷，因為由於所有權和移動語義，您實際上不需要在 Rust 中克隆太多代碼。
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // 我們希望中止而不是放棄該值。
        // 引用計數永遠不會為零。
        // 但是，我們在此處插入中止項以向 LLVM 提示進行其他優化時所錯過的優化。
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // 我們希望中止而不是放棄該值。
        // 引用計數永遠不會為零。
        // 但是，我們在此處插入中止項以向 LLVM 提示進行其他優化時所錯過的優化。
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// 獲取 `RcBox` 內指針後面的有效載荷的偏移量。
///
/// # Safety
///
/// 指針必須指向 T 的先前有效實例 (並具有有效的元數據)，但是允許刪除 T。
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // 將未調整大小的值與 RcBox 的末端對齊。
    // 由於 RcBox 是 repr(C)，因此它將始終是內存中的最後一個字段。
    // 安全: 由於唯一可能未調整大小的類型是切片，trait 對象，
    // 和外部類型，當前輸入的安全要求足以滿足 align_of_val_raw 的要求; 這是 std 之外可能不依賴的語言的實現細節。
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}