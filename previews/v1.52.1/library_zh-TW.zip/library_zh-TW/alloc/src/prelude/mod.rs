//! 分配 Prelude
//!
//! 該模塊的目的是通過在模塊頂部添加全局導入來減輕 `alloc` crate 常用項的導入:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;