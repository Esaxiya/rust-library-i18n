//! 內存分配 API

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // 這些是調用全局分配器的魔術符號。rustc 生成它們以調用 `__rg_alloc` 等。
    // 如果存在 `#[global_allocator]` 屬性 (擴展該屬性宏的代碼生成這些函數)，或調用 libstd 中的默認實現 (`__rdl_alloc` 等)。
    //
    // 在 `library/std/src/alloc.rs` 中)。
    // LLVM 的 rustc fork 還對這些函數名進行特殊處理，以便分別優化它們，例如 `malloc`，`realloc` 和 `free`。
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// 全局內存分配器。
///
/// 此類型通過將調用轉發到用 `#[global_allocator]` 屬性註冊的分配器 (如果有的話) 或 `std` crate 的默認值來實現 [`Allocator`] trait。
///
///
/// Note: 儘管此類型不穩定，但是可以通過 [free functions in `alloc`](self#functions) 訪問其提供的功能。
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// 用全局分配器分配內存。
///
/// 如果存在，此函數會將調用轉發到用 `#[global_allocator]` 屬性註冊的分配器的 [`GlobalAlloc::alloc`] 方法，或者將其默認為 `std` crate。
///
///
/// 當 [`Global`] 類型的 `alloc` 方法和 [`Allocator`] trait 變得穩定時，將不推薦使用此功能，而推薦使用 [`Global`] 類型的 `alloc` 方法。
///
/// # Safety
///
/// 請參閱 [`GlobalAlloc::alloc`]。
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// 使用全局分配器釋放內存。
///
/// 如果存在，此函數會將調用轉發到用 `#[global_allocator]` 屬性註冊的分配器的 [`GlobalAlloc::dealloc`] 方法，或者將其默認為 `std` crate。
///
///
/// 當 [`Global`] 類型的 `dealloc` 方法和 [`Allocator`] trait 變得穩定時，將不推薦使用此功能，而推薦使用 [`Global`] 類型的 `dealloc` 方法。
///
/// # Safety
///
/// 請參閱 [`GlobalAlloc::dealloc`]。
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// 使用全局分配器重新分配內存。
///
/// 如果存在，則此函數將調用轉發到使用 `#[global_allocator]` 屬性註冊的分配器的 [`GlobalAlloc::realloc`] 方法，或者默認調用 `std` crate。
///
///
/// 當 [`Global`] 類型的 `realloc` 方法和 [`Allocator`] trait 變得穩定時，將不推薦使用此功能，而推薦使用 [`Global`] 類型的 `realloc` 方法。
///
/// # Safety
///
/// 請參閱 [`GlobalAlloc::realloc`]。
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// 用全局分配器分配零初始化的內存。
///
/// 如果存在，此函數會將調用轉發到用 `#[global_allocator]` 屬性註冊的分配器的 [`GlobalAlloc::alloc_zeroed`] 方法，或者將其默認為 `std` crate。
///
///
/// 當 [`Global`] 類型的 `alloc_zeroed` 方法和 [`Allocator`] trait 變得穩定時，將不推薦使用此功能，而推薦使用 [`Global`] 類型的 `alloc_zeroed` 方法。
///
/// # Safety
///
/// 請參閱 [`GlobalAlloc::alloc_zeroed`]。
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // 安全: `layout` 的大小不為零，
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // 安全: 與 `Allocator::grow` 相同
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // 安全性: `new_size` 非零，因為 `old_size` 大於或等於 `new_size`
            // 根據安全條件的要求。调用者必須堅持其他條件
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` 大概檢查 `new_size >= old_layout.size()` 或類似的東西。
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // 安全: 由於 `new_layout.size()` 必須大於或等於 `old_size`，
            // 舊的和新的內存分配都對 `old_size` 字節的讀取和寫入有效。
            // 另外，由於尚未分配舊分配，因此它不能與 `new_ptr` 重疊。
            // 因此，對 `copy_nonoverlapping` 的調用是安全的。
            // 调用者必須遵守 `dealloc` 的安全合同。
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // 安全: `layout` 的大小不為零，
            // 调用者必須堅持其他條件
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 安全: 调用者必須堅持所有條件
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 安全: 调用者必須堅持所有條件
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // 安全: 调用者必須保持條件
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // 安全: `new_size` 不為零。调用者必須堅持其他條件
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` 大概檢查 `new_size <= old_layout.size()` 或類似的東西。
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // 安全: 由於 `new_size` 必須小於或等於 `old_layout.size()`，
            // 舊的和新的內存分配都對 `new_size` 字節的讀取和寫入有效。
            // 另外，由於尚未分配舊分配，因此它不能與 `new_ptr` 重疊。
            // 因此，對 `copy_nonoverlapping` 的調用是安全的。
            // 调用者必須遵守 `dealloc` 的安全合同。
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// 唯一指針的分配器。
// 此功能不得放鬆。如果是這樣，MIR 代碼生成將失敗。
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// 該簽名必須與 `Box` 相同，否則將發生 ICE。
// 當添加了 `Box` 的附加參數 (如 `A: Allocator`) 時，也必須在此處添加該參數。
// 例如，如果 `Box` 更改為 `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`，則此功能也必須更改為 `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`。
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # 分配錯誤處理程序

extern "Rust" {
    // 這是調用全局分配錯誤處理程序的魔術符號。
    // rustc 生成它以在存在 `#[alloc_error_handler]` 時調用 `__rg_oom`，否則在 (`__rdl_oom`) 以下調用默認實現。
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// 中止內存分配錯誤或失敗。
///
/// 鼓勵希望響應分配錯誤而中止計算的內存分配 API 調用程序調用此函數，而不是直接調用 `panic!` 或類似方法。
///
///
/// 此功能的默認行為是將消息打印為標準錯誤併中止該過程。
/// 可以用 [`set_alloc_error_hook`] 和 [`take_alloc_error_hook`] 代替。
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// 對於分配測試，可以直接使用 `std::alloc::handle_alloc_error`。
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // 通過生成的 `__rust_alloc_error_handler` 調用

    // 如果沒有 `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // 如果有 `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// 將克隆專用於預分配的未初始化內存。
/// 由 `Box::clone` 和 `Rc`/`Arc::make_mut` 使用。
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // 分配 *first* 後，優化器可以就地創建克隆的值，而跳過本地並移動。
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // 我們始終可以就地複制，而無需涉及本地值。
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}