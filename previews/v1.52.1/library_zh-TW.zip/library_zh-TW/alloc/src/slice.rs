//! 動態大小的視圖到一個連續的序列， `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! 切片是一個內存塊的視圖，表示為一個指針和一個長度。
//!
//! ```
//! // 切片 Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // 將數組強制為切片
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! 切片是可變的或共享的。
//! 共享切片類型為 `&[T]`，而可變切片類型為 `&mut [T]`，其中 `T` 表示元素類型。
//! 例如，您可以更改可變切片指向的內存塊:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! 以下是此模塊包含的一些內容:
//!
//! ## Structs
//!
//! 對於切片，有幾種有用的結構，例如 [`Iter`]，它表示切片上的迭代。
//!
//! ## Trait 實現
//!
//! 切片具有常見的 traits 的幾種實現。一些示例包括:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`]，用於元素類型為 [`Eq`] 或 [`Ord`] 的切片。
//! * [`Hash`] - 用於元素類型為 [`Hash`] 的切片。
//!
//! ## Iteration
//!
//! 切片實現 `IntoIterator`。迭代器產生對 slice 元素的引用。
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! 可變切片產生對元素的可變引用:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! 該迭代器產生對切片元素的可變引用，因此，儘管切片的元素類型為 `i32`，但迭代器的元素類型為 `&mut i32`。
//!
//!
//! * [`.iter`] [`.iter_mut`] 和 [`.iter_mut`] 是返回默認迭代器的顯式方法。
//! * 返回迭代器的其他方法是 [`.split`]，[`.splitn`]，[`.chunks`]，[`.windows`] 等。
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// 該模塊中的許多用法僅在測試配置中使用。
// 僅關閉 unused_imports 警告比解決它們更乾淨。
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// 基本切片擴展方法
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) 測試 NB 期間實現 `vec!` 宏所需的信息，請參閱此文件中的 `hack` 模塊以獲取更多詳細信息。
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) 測試 NB 期間 `Vec::clone` 的實現所需的信息，請參閱此文件中的 `hack` 模塊以獲取更多詳細信息。
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): 由於沒有 cfg(test) `impl [T]`，這三個功能實際上是 `impl [T]` 中的方法，但不是 `core::slice::SliceExt` 中的方法，我們需要為 `test_permutations` 測試提供這些功能
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // 我們不應該向此屬性添加內聯屬性，因為該屬性主要在 `vec!` 宏中使用，並且會導致性能下降。
    // 有關討論和性能結果，請參見 #71204。
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // 項目在下面的循環中被標記為已初始化
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) 是 LLVM 刪除邊界檢查所必需的，並且具有比 zip 更好的代碼生成。
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec 的分配和初始化至少達到了這個長度。
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // 在上面分配了 `s` 的容量，並在下面的 ptr::copy_to_non_overlapping 中初始化為 `s.len()`。
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// 對切片進行排序。
    ///
    /// 這種排序是穩定的 (即，不對相等的元素重新排序)，並且 *O*(*n*\*log(* n*)) 最壞的情況)。
    ///
    /// 在適用時，首選不穩定排序，因為它通常比穩定排序快，並且不分配輔助內存。
    /// 請參閱 [`sort_unstable`](slice::sort_unstable)。
    ///
    /// # 當前實施
    ///
    /// 當前的算法是一種受 [timsort](https://en.wikipedia.org/wiki/Timsort) 啟發的自適應迭代合併排序。
    /// 在切片幾乎被排序或由兩個或多個依次連接的排序序列組成的情況下，它設計得非常快。
    ///
    ///
    /// 同樣，它分配臨時存儲空間的大小是 `self` 的一半，但是對於短片，則使用非分配插入排序。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// 使用比較器功能對切片進行排序。
    ///
    /// 這種排序是穩定的 (即，不對相等的元素重新排序)，並且 *O*(*n*\*log(* n*)) 最壞的情況)。
    ///
    /// 比較器功能必須定義切片中元素的總順序。如果順序不是總計，則未指定元素的順序。
    /// 如果訂單是訂單 (對於所有 `a`，`b` 和 `c`)，則為總訂單:
    ///
    /// * 完全和反對稱的: `a < b`，`a == b` 或 `a > b` 之一正確，並且
    /// * 可傳遞的，`a < b` 和 `b < c` 表示 `a < c`。`==` 和 `>` 必須保持相同。
    ///
    /// 例如，雖然 [`f64`] 由於 `NaN != NaN` 而不實現 [`Ord`]，但是當我們知道切片不包含 `NaN` 時，可以將 `partial_cmp` 用作我們的排序函數。
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// 在適用時，首選不穩定排序，因為它通常比穩定排序快，並且不分配輔助內存。
    /// 請參閱 [`sort_unstable_by`](slice::sort_unstable_by)。
    ///
    /// # 當前實施
    ///
    /// 當前的算法是一種受 [timsort](https://en.wikipedia.org/wiki/Timsort) 啟發的自適應迭代合併排序。
    /// 在切片幾乎被排序或由兩個或多個依次連接的排序序列組成的情況下，它設計得非常快。
    ///
    /// 同樣，它分配臨時存儲空間的大小是 `self` 的一半，但是對於短片，則使用非分配插入排序。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // 反向排序
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// 使用鍵提取功能對切片進行排序。
    ///
    /// 這種排序是穩定的 (即，不對相等的元素重新排序)，並且 *O*(*m*\* * n *\* log(*n*)) 最壞的情況是，其中鍵函數是 *O*(*m*)。
    ///
    /// 對於昂貴的按鍵功能 (例如，
    /// 函數 (不是簡單的屬性訪問或基本操作)，[`sort_by_cached_key`](slice::sort_by_cached_key) 可能會顯著提高速度，因為它不會重新計算元素鍵。
    ///
    ///
    /// 在適用時，首選不穩定排序，因為它通常比穩定排序快，並且不分配輔助內存。
    /// 請參閱 [`sort_unstable_by_key`](slice::sort_unstable_by_key)。
    ///
    /// # 當前實施
    ///
    /// 當前的算法是一種受 [timsort](https://en.wikipedia.org/wiki/Timsort) 啟發的自適應迭代合併排序。
    /// 在切片幾乎被排序或由兩個或多個依次連接的排序序列組成的情況下，它設計得非常快。
    ///
    /// 同樣，它分配臨時存儲空間的大小是 `self` 的一半，但是對於短片，則使用非分配插入排序。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// 使用鍵提取功能對切片進行排序。
    ///
    /// 在排序期間，每個元素僅調用一次鍵函數。
    ///
    /// 這種排序是穩定的 (即，不對相等元素進行重新排序)，並且 *O*(*m*\* * n *+* n *\* log(*n*)) 最壞的情況是，其中鍵函數是 *O*(*m*)。
    ///
    /// 對於簡單的按鍵功能 (例如，作為屬性訪問或基本操作的功能)，[`sort_by_key`](slice::sort_by_key) 可能會更快。
    ///
    /// # 當前實施
    ///
    /// 當前算法基於 Orson Peters 的 [pattern-defeating quicksort][pdqsort]，該算法將隨機快速排序的快速平均情況與堆排序的快速最壞情況相結合，同時在具有特定模式的切片上實現了線性時間。
    /// 它使用一些隨機化來避免退化的情況，但是使用固定的 seed 來始終提供確定性的行為。
    ///
    /// 在最壞的情況下，該算法會在 `Vec<(K, usize)>` 切片長度內分配臨時存儲。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // 幫助程序宏，用於以最小的類型索引 vector，以減少分配。
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` 的元素是唯一的，因為它們已被索引，因此任何排序相對於原始切片都是穩定的。
                // 我們在這裡使用 `sort_unstable` 是因為它需要較少的內存分配。
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// 將 `self` 複製到新的 `Vec` 中。
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // 在此，`s` 和 `x` 可以獨立修改。
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// 使用分配器將 `self` 複製到新的 `Vec` 中。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // 在此，`s` 和 `x` 可以獨立修改。
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // 注意，有關更多詳細信息，請參見此文件中的 `hack` 模塊。
        hack::to_vec(self, alloc)
    }

    /// 將 `self` 轉換為 vector，而無需克隆或分配。
    ///
    /// 產生的 vector 可以通過 `Vec 轉換回一個盒子 <T>` 的 `into_boxed_slice` 方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` 由於已將其轉換為 `x`，因此無法再使用。
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // 注意，有關更多詳細信息，請參見此文件中的 `hack` 模塊。
        hack::into_vec(self)
    }

    /// 通過將切片重複 `n` 次來創建 vector。
    ///
    /// # Panics
    ///
    /// 如果容量溢出，此函數將為 panic。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// 溢出時為 panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // 如果 `n` 大於零，則可以將其拆分為 `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`。
        // `2^expn` 是 `n` 的最左 '1' 位表示的數字，而 `rem` 是 `n` 的其餘部分。
        //
        //

        // 使用 `Vec` 訪問 `set_len()`。
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` 重複是通過將 `buf` expn`- 的時間加倍來完成的。
        buf.extend(self);
        {
            let mut m = n >> 1;
            // 如果是 `m > 0`，則剩餘的位將保留到最左邊的 '1'。
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` 具有 `self.len() * n` 的容量。
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n，2 ^ expn`) 重複是通過從 `buf` 本身複製第一個 `rem` 重複來完成的。
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // 自 `2^expn > rem` 起，這是不重疊的。
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` 等於 `buf.capacity()` (`= self.len() * n`)。
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// 將 `T` 的一部分展平為單個值 `Self::Output`。
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// 將 `T` 的一部分展平為單個值 `Self::Output`，並在每個值之間放置一個給定的分隔符。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// 將 `T` 的一部分展平為單個值 `Self::Output`，並在每個值之間放置一個給定的分隔符。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// 返回一個 vector，其中包含此切片的副本，其中每個字節均映射為其等效的 ASCII 大寫形式。
    ///
    ///
    /// ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不變。
    ///
    /// 要就地將值大寫，請使用 [`make_ascii_uppercase`]。
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// 返回一個 vector，其中包含此切片的副本，其中每個字節均映射為其等效的 ASCII 小寫字母。
    ///
    ///
    /// ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不變。
    ///
    /// 要就地小寫該值，請使用 [`make_ascii_lowercase`]。
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// 擴展 traits 用於切片特定類型的數據
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`] (slice::concat) 的助手 trait。
///
/// Note: `Item` 類型參數未在此 trait 中使用，但它使 impls 更為通用。
/// 沒有它，我們將收到此錯誤:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// 這是因為可能存在具有多個 `Borrow<[_]>` 表示的 `V` 類型，因此將應用多個 `T` 類型:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// 串聯後的結果類型
    type Output;

    /// [`[T]: : concat`] (slice::concat) 的實現
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`][slice::join) 的輔助 trait
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// 串聯後的結果類型
    type Output;

    /// [`[T]: : join`] (slice::join) 的實現
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// 切片的標準 trait 實現
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // 在目標中刪除不會覆蓋的任何內容
        target.truncate(self.len());

        // target.len <= self.len 由於上面的截斷，因此這裡的切片始終是入站的。
        //
        let (init, tail) = self.split_at(target.len());

        // 重用包含的值的 allocations/resources。
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// 將 `v[0]` 插入到預排序序列 `v[1..]` 中，以便整個 `v[..]` 都被排序。
///
/// 這是插入排序的必不可少的子例程。
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // 這裡有三種實現插入的方法:
            //
            // 1. 交換相鄰的元素，直到第一個到達其最終目的地。
            //    但是，這樣一來，我們就可以復制不必要的數據。
            //    如果元素是大結構 (複製成本很高)，則此方法將很慢。
            //
            // 2. 迭代直到找到第一個元素的正確位置。
            // 然後轉移接替它的元素為其騰出空間，最後將其放入剩餘的孔中。
            // 這是一個好方法。
            //
            // 3. 將第一個元素複製到一個臨時變量中。迭代直到找到正確的位置。
            // 在進行過程中，將所有遍歷的元素複製到其前面的插槽中。
            // 最後，將數據從臨時變量複製到剩餘的孔中。
            // 這個方法很好。
            // 基準測試顯示出比第二種方法更好的性能。
            //
            // 所有方法均進行了基準測試，第 3 種方法顯示了最佳結果。因此，我們選擇了那個。
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // `hole` 始終跟踪插入過程的中間狀態，這有兩個目的:
            // 1. 從 `is_less` 中的 panics 保護 `v` 的完整性。
            // 2. 最後填充 `v` 中的剩餘孔。
            //
            // Panic 安全性:
            //
            // 如果在此過程中的任何時候 `is_less` panics 都將掉落 `hole`，並用 `tmp` 填充 `v` 中的孔，從而確保 `v` 仍將其最初持有的每個對像都保持一次。
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` 被掉落，從而將 `tmp` 複製到 `v` 的剩餘孔中。
        }
    }

    // 放下後，從 `src` 複製到 `dest`。
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// 使用 `buf` 作為臨時存儲合併非遞減運行 `v[..mid]` 和 `v[mid..]`，並將結果存儲到 `v[..]` 中。
///
/// # Safety
///
/// 這兩個片必須是非空的，並且 `mid` 必須在範圍之內。
/// 緩衝區 `buf` 必須足夠長才能容納較短切片的副本。
/// 另外，`T` 不能為零大小類型。
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // 合併過程首先將較短的運行複製到 `buf` 中。
    // 然後，它將跟踪新復制的運行，以及向前運行 (或向後運行) 的較長運行，比較它們的下一個未消耗元素，並將較小 (或較大) 的運行複製到 `v` 中。
    //
    // 一旦較短的運行時間被完全用盡，該過程就完成了。如果較長的運行首先被消耗，那麼我們必須將較短的運行剩下的任何內容複製到 `v` 的剩餘孔中。
    //
    // `hole` 始終跟踪過程的中間狀態，這有兩個目的:
    // 1. 從 `is_less` 中的 panics 保護 `v` 的完整性。
    // 2. 如果較長時間的運行首先被消耗，則填充 `v` 中的剩餘孔。
    //
    // Panic 安全性:
    //
    // 如果在此過程中的任何時候 `is_less` panics，`hole` 都會掉落，並用 `buf` 中的未消耗範圍填充 `v` 中的孔，從而確保 `v` 仍將其最初持有的每個對像都保持一次。
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // 左行程較短。
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // 最初，這些指針指向其數組的開頭。
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // 消耗較小的一面。
            // 如果相等，則選擇左旋以保持穩定性。
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // 正確的行程較短。
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // 最初，這些指針指向其數組的兩端。
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // 消耗更大的一面。
            // 如果相等，則選擇正確的行程以保持穩定性。
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // 最後，`hole` 被丟棄。
    // 如果較短的運行未完全耗盡，則其剩餘的任何內容現在都將被複製到 `v` 的孔中。

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // 放下後，將範圍 `start..end` 複製到 `dest..`。
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` 不是零大小的類型，因此可以將其除以大小。
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// 這種合併排序借鑒了 TimSort 的一些 (但不是全部) 想法，這在 [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) 中有詳細描述。
///
///
/// 該算法識別嚴格降序和非降序的子序列，這些子序列稱為自然行程。有待合併的待處理運行堆棧。
/// 將每個新發現的運行推入堆棧，然後合併幾對相鄰的運行，直到滿足這兩個不變量:
///
/// 1. 對於 `1..runs.len()` 中的每個 `i`: `runs[i - 1].len > runs[i].len`
/// 2. 對於 `2..runs.len()` 中的每個 `i`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// 不變量確保總運行時間為 *O*(*n*\*log(* n*)) 最壞的情況。
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // 長度不超過此長度的切片將使用插入排序進行排序。
    const MAX_INSERTION: usize = 20;
    // 使用插入排序可擴展非常短的運行時間，以至少涵蓋這麼多的元素。
    const MIN_RUN: usize = 10;

    // 零大小類型的排序沒有有意義的行為。
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // 短數組通過插入排序進行就地排序，以避免分配。
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // 分配緩衝區以用作暫存器。我們將長度保持為 0，這樣就可以在其中保留 `v` 內容的淺表副本，而不會冒 `is_less` panics 在副本上運行 dtor 的風險。
    //
    // 合併兩個已排序的運行時，此緩衝區將保存一個較短運行的副本，該副本的長度始終最多為 `len / 2`。
    //
    let mut buf = Vec::with_capacity(len / 2);

    // 為了識別 `v` 中的自然行程，我們將其向後移動。
    // 這看起來似乎是一個奇怪的決定，但請考慮以下事實: 合併更多是朝相反的方向 (forwards) 進行。
    // 根據基準，向前合併比向後合併要快一些。
    // 總而言之，通過向後遍歷來識別運行可提高性能。
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // 找到下一個自然行程，如果嚴格下降，則將其反轉。
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // 如果過短，請在運行中插入更多元素。
        // 插入排序比短序列上的合併排序要快，因此可以顯著提高性能。
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // 將此運行推入堆棧。
        runs.push(Run { start, len: end - start });
        end = start;

        // 合併一些相鄰的運行對以滿足不變性。
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // 最後，必須在堆棧中僅保留一次運行。
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // 檢查運行堆棧，並確定要合併的下一對運行。
    // 更具體地說，如果返回 `Some(r)`，則意味著接下來必須合併 `runs[r]` 和 `runs[r + 1]`。
    // 如果算法應繼續構建新的運行，則返回 `None`。
    //
    // TimSort 因其錯誤的實現而臭名昭著，如下所述:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // 故事的要旨是: 我們必須在堆棧的前四個運行中強制執行不變式。
    // 僅在前三名上強制執行它們不足以確保不變式在堆棧中的所有 `運行` 中仍然成立。
    //
    // 此函數正確檢查前四次運行的不變量。
    // 另外，如果最高運行從索引 0 開始，它將始終要求合併操作，直到堆棧完全折疊為止，以完成排序。
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}