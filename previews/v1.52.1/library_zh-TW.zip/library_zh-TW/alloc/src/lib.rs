//! # Rust 核心分配和集合庫
//!
//! 該庫提供用於管理堆分配值的智能指針和集合。
//!
//! 與 libcore 一樣，該庫通常不需要直接使用，因為其內容已重新導出到 [`std` crate](../std/index.html) 中。
//! 但是，使用 `#![no_std]` 屬性的 Crates 通常不依賴於 `std`，因此他們會改用此 crate。
//!
//! ## 裝箱價值
//!
//! [`Box`] 類型是智能指針類型。[`Box`] 只能有一個所有者，所有者可以決定對內容進行突變，這些內容存在於堆中。
//!
//! 由於 `Box` 值的大小與指針的大小相同，因此可以在線程之間高效地發送此類型。
//! 由於每個節點通常只有一個所有者 (即父節點)，因此通常使用框來構建樹狀數據結構。
//!
//! ## 參考計數指針
//!
//! [`Rc`] 類型是一種非線程安全的引用計數指針類型，旨在共享線程內的內存。
//! [`Rc`] 指針包裝類型 `T`，並且僅允許訪問共享引用 `&T`。
//!
//! 當繼承的可變性 (例如使用 [`Box`]) 對於應用程序而言過於受限時，此類型非常有用，並且通常與 [`Cell`] 或 [`RefCell`] 類型配對以允許進行突變。
//!
//!
//! ## 原子引用計數指針
//!
//! [`Arc`] 類型是 [`Rc`] 類型的線程安全等效項。它提供 [`Rc`] 的所有相同功能，不同之處在於它要求包含的 `T` 類型是可共享的。
//! 此外，[`Arc<T>`][`Arc`] 本身可發送，而 [`Rc<T>`][`Rc`] 不可發送。
//!
//! 這種類型允許共享訪問所包含的數據，並且通常與同步原語 (例如互斥鎖) 配對以允許共享資源的變異。
//!
//! ## Collections
//!
//! 該庫中定義了最通用的通用數據結構的實現。它們通過 [standard collections library](../std/collections/index.html) 重新導出。
//!
//! ## 堆接口
//!
//! [`alloc`](alloc/index.html) 模塊定義了默認全局分配器的低級接口。它與 libc 分配器 API 不兼容。
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// 從技術上講，這是 rustdoc 中的錯誤: rustdoc 看到 `#[lang = slice_alloc]` 塊上的文檔是針對 `&[T]` 的，而 `&[T]` 上也具有使用此功能的文檔，並為未啟用功能門而發狂。
// 理想情況下，它不會檢查來自其他 crates 的文檔的功能門，但是由於只能出現在 lang 項目中，因此似乎不值得修復。
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// 允許測試該庫

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// 具有其他模塊使用的內部宏的模塊 (需要在其他模塊之前包含)。
#[macro_use]
mod macros;

// 為低級分配策略提供的堆

pub mod alloc;

// 使用上面的堆的原始類型

// 需要在 `boxed.rs` 中有條件地定義 mod，以免在構建測試 cfg 時重複生成 lang-items; 但還需要允許代碼具有 `use boxed::Box;` 聲明。
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}