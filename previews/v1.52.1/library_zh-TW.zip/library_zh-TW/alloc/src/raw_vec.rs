#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// 新存儲器的內容未初始化。
    Uninitialized,
    /// 確保將新內存清零。
    Zeroed,
}

/// 一個低級實用程序，用於更符合人體工程學的方式在堆上分配，重新分配和取消分配內存緩衝區，而不必擔心所涉及的所有極端情況。
///
/// 此類型非常適合構建自己的數據結構，例如 Vec 和 VecDeque。
/// 特別是:
///
/// * 在零大小類型上生成 `Unique::dangling()`。
/// * 在零長度分配上產生 `Unique::dangling()`。
/// * 避免釋放 `Unique::dangling()`。
/// * 捕獲容量計算中的所有溢出 (將它們提升為 "capacity overflow" panics)。
/// * 防止分配超過 isize::MAX 字節的 32 位系統。
/// * 防止溢出您的長度。
/// * 調用 `handle_alloc_error` 進行錯誤分配。
/// * 包含 `ptr::Unique`，因此為用戶提供了所有相關的好處。
/// * 使用分配器返回的多餘資源來使用最大可用容量。
///
/// 無論如何，此類型不會檢查它管理的內存。刪除後，它會 *釋放其內存，但不會* 嘗試刪除其內容。
/// `RawVec` 的用戶可以處理 `RawVec` 內部 `存儲` 的實際內容。
///
/// 注意，零大小類型的餘量始終是無限的，因此 `capacity()` 始終返回 `usize::MAX`。
/// 這意味著與 `Box<[T]>` 進行雙向交互時需要小心，因為 `capacity()` 不會產生長度。
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): 之所以存在，是因為 `#[unstable]` const fn` 不需要符合 `min_const_fn`，因此它們也不能在 `min_const_fn`s 中被調用。
    ///
    /// 如果更改 `RawVec<T>::new` 或依賴項，請注意不要引入任何確實違反 `min_const_fn` 的內容。
    ///
    /// NOTE: 我們可以避免這種黑客攻擊，並檢查 `#[rustc_force_min_const_fn]` 屬性的符合性，而 `#[rustc_force_min_const_fn]` 屬性要求與 `min_const_fn` 相符合，但不一定允許使用 `stable(...) const fn` 來調用它 / 如果存在 `#[rustc_const_unstable(feature = "foo", issue = "01234")]`，則用戶代碼不會啟用 `foo`。
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// 創建最大的 `RawVec` (在系統堆上) 而不分配。
    /// 如果 `T` 的大小為正，則表示 `RawVec` 的容量為 `0`。
    /// 如果 `T` 的尺寸為零，則它製成容量為 `usize::MAX` 的 `RawVec`。
    /// 對於實施延遲分配很有用。
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// 創建 `RawVec` (在系統堆上)，該 `RawVec` 具有 `[T; capacity]` 的確切容量和對齊要求。
    /// 這等效於 `capacity` 為 `0` 或 `T` 為零大小時調用 `RawVec::new`。
    /// 請注意，如果 `T` 的大小為零，這意味著您將 *不會* 獲得具有所需容量的 `RawVec`。
    ///
    /// # Panics
    ///
    /// 如果請求的容量超過 `isize::MAX` 字節，則為 Panics。
    ///
    /// # Aborts
    ///
    /// 中止 OOM。
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// 類似於 `with_capacity`，但保證緩衝區為零。
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// 通過指針和容量重構 `RawVec`。
    ///
    /// # Safety
    ///
    /// 必須分配 `ptr` (在系統堆上) 並使用給定的 `capacity`。
    /// 對於尺寸類型，`capacity` 不能超過 `isize::MAX`。(僅與 32 位系統有關)。
    /// ZST vectors 的容量最多為 `usize::MAX`。
    /// 如果 `ptr` 和 `capacity` 來自 `RawVec`，則可以保證。
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // 微小的 Vecs 是愚蠢的。跳至:
    // - 如果元素大小為 1，則為 8，因為任何堆分配器都可能會將少於 8 個字節的請求舍入為至少 8 個字節。
    //
    // - 如果元素大小適中 (<=1 KiB)，則為 4。
    // - 否則為 1，以避免在很短的 Vecs 上浪費過多的空間。
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// 類似於 `new`，但通過參數選擇返回 `RawVec` 的分配器。
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` 表示 "unallocated"。零大小的類型將被忽略。
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// 類似於 `with_capacity`，但通過參數選擇返回 `RawVec` 的分配器。
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// 類似於 `with_capacity_zeroed`，但通過參數選擇返回 `RawVec` 的分配器。
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// 將 `Box<[T]>` 轉換為 `RawVec<T>`。
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// 使用指定的 `len` 將整個緩衝區轉換為 `Box<[MaybeUninit<T>]>`。
    ///
    /// 請注意，這將正確地重構可能已執行的所有 `cap` 更改。(有關詳細信息，請參見類型說明。)
    ///
    /// # Safety
    ///
    /// * `len` 必須大於或等於最近請求的容量，並且
    /// * `len` 必須小於或等於 `self.capacity()`。
    ///
    /// 請注意，請求的容量和 `self.capacity()` 可能有所不同，因為分配器可能會整合併返回比請求更大的內存塊。
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // 仔細檢查安全要求的一半 (我們不能檢查另一半)。
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // 我們在這裡避免使用 `unwrap_or_else`，因為它會使生成的 LLVM IR 數量膨脹。
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// 從指針，容量和分配器重構 `RawVec`。
    ///
    /// # Safety
    ///
    /// 必須通過給定的 `capacity` 分配 `ptr` (通過給定的分配器 `alloc`)。
    /// 對於尺寸類型，`capacity` 不能超過 `isize::MAX`。
    /// (僅與 32 位系統有關)。
    /// ZST vectors 的容量最多為 `usize::MAX`。
    /// 如果 `ptr` 和 `capacity` 來自通過 `alloc` 創建的 `RawVec`，則可以保證。
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// 獲取指向分配開始的原始指針。
    /// 請注意，如果 `capacity == 0` 或 `T` 的大小為零，則為 `Unique::dangling()`。
    /// 在前一種情況下，您必須小心。
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// 獲取分配的容量。
    ///
    /// 如果 `T` 的大小為零，則它將始終為 `usize::MAX`。
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// 返回對支持此 `RawVec` 的分配器的共享引用。
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // 我們有一塊已分配的內存，因此我們可以繞過運行時檢查來獲取當前的佈局。
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// 確保緩衝區至少包含足夠的空間來容納 `len + additional` 元素。
    /// 如果還沒有足夠的容量，則將重新分配足夠的空間以及舒適的鬆弛空間，以攤銷 *O*(1) 行為。
    ///
    /// 如果會不必要地使其自身成為 panic，則將限制此行為。
    ///
    /// 如果 `len` 超過 `self.capacity()`，則可能無法實際分配請求的空間。
    /// 這並不是真正不安全的，但是依賴於此功能的行為的不安全代碼 *you* 可能會破壞。
    ///
    /// 這是實現 `extend` 之類的批量推送操作的理想選擇。
    ///
    /// # Panics
    ///
    /// 如果新容量超過 `isize::MAX` 字節，則為 Panics。
    ///
    /// # Aborts
    ///
    /// 中止 OOM。
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // 如果 len 超過 `isize::MAX`，則儲備金將中止或恐慌，因此現在可以安全地取消選中該複選框。
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// 與 `reserve` 相同，但返回錯誤而不是驚慌或中止。
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// 確保緩衝區至少包含足夠的空間來容納 `len + additional` 元素。
    /// 如果還沒有，將重新分配所需的最小可能內存量。
    /// 通常，這恰好是必需的內存量，但是原則上分配器可以自由地提供比我們要求的更多的內存。
    ///
    ///
    /// 如果 `len` 超過 `self.capacity()`，則可能無法實際分配請求的空間。
    /// 這並不是真正不安全的，但是依賴於此功能的行為的不安全代碼 *you* 可能會破壞。
    ///
    /// # Panics
    ///
    /// 如果新容量超過 `isize::MAX` 字節，則為 Panics。
    ///
    /// # Aborts
    ///
    /// 中止 OOM。
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// 與 `reserve_exact` 相同，但返回錯誤而不是驚慌或中止。
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// 將分配縮減到指定數量。
    /// 如果給定的數量為 0，則實際上完全取消分配。
    ///
    /// # Panics
    ///
    /// Panics，如果給定的數量 `大於` 當前容量。
    ///
    /// # Aborts
    ///
    /// 中止 OOM。
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// 如果緩衝區需要增長才能滿足所需的額外容量，則返回。
    /// 主要用於無需內聯 `grow` 就可以進行內聯預留调用。
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // 此方法通常實例化很多次。因此，我們希望它盡可能小，以縮短編譯時間。
    // 但是我們也希望它的盡可能多的內容是靜態可計算的，以使生成的代碼運行得更快。
    // 因此，仔細地編寫此方法，使所有依賴 `T` 的代碼都在其中，而盡可能多的不依賴 `T` 的代碼都在 `T` 上非通用的函數中。
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // 這是通過調用上下文來確保的。
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // 因為當 `elem_size` 為 X 時我們返回 `usize::MAX` 的容量
            // 0，到達此處必定意味著 `RawVec` 已滿。
            return Err(CapacityOverflow);
        }

        // 不幸的是，我們對這些檢查無能為力。
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // 這保證了指數增長。
        // 倍增不會溢出，因為 `cap <= isize::MAX` 和 `cap` 的類型是 `usize`。
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` 在 `T` 上是非通用的。
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // 此方法的約束與 `grow_amortized` 上的約束大致相同，但是此方法通常實例化的頻率較低，因此不太重要。
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // 由於我們在類型大小為時返回 `usize::MAX` 的容量
            // 0，到達此處必定意味著 `RawVec` 已滿。
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` 在 `T` 上是非通用的。
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// 該功能在 `RawVec` 外部，以最大程度地減少編譯時間。有關詳細信息，請參見 `RawVec::grow_amortized` 上方的註釋。
// (`A` 參數並不重要，因為實際上看到的不同 `A` 類型的數量比 `T` 類型的數量小得多。)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // 在此處檢查錯誤，以最小化 `RawVec::grow_*` 的大小。
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // 分配器檢查對齊是否相等
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// 釋放 `RawVec` 擁有的內存，而無需嘗試刪除其內容。
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// 儲備功能錯誤處理的中央功能。
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// 我們需要保證以下幾點:
// * 我們永遠不會分配 `> isize::MAX` 字節大小的對象。
// * 我們不會溢出 `usize::MAX`，而實際上分配得太少。
//
// 在 64 位上，我們只需要檢查溢出，因為嘗試分配 `> isize::MAX` 字節肯定會失敗。
// 在 32 位和 16 位上，我們需要為此添加一個額外的保護措施，以防我們運行在可以使用用戶空間中所有 4GB 的平台上，例如 PAE 或 x32。
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// 一個負責報告容量溢出的中心功能。
// 這將確保與這些 panics 相關的代碼生成最少，因為在整個模塊中只有一個位置 panics 而不是一堆。
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}