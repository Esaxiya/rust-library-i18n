// 當 `SetLenOnDrop` 值超出範圍時，設置 vec 的長度。
//
// 這個想法是: SetLenOnDrop 中的 length 字段是一個局部變量，優化器將看到該變量不會通過 Vec 的數據指針與任何存儲區混疊。
// 這是別名分析問題 #32155 的解決方法
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}