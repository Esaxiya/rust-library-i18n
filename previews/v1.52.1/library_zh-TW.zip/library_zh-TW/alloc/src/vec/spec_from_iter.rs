use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter 使用的專業化 trait
///
/// ## 委託圖:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // 一個常見的情況是將 vector 傳遞給一個函數，該函數立即重新收集到 vector 中。
        // 如果 IntoIter 根本沒有改進，我們可以將其短路。
        // 升級後，我們還可以重用內存並將數據移到最前面。
        // 但是，只有在生成的 Vec 沒有比通過常規 FromIterator 實現創建的未使用容量多的情況下，我們才這樣做。
        //
        // 由於故意未指定 Vec 的分配行為，因此此限制並非嚴格必要。
        // 但這是一個保守的選擇。
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // 必須委託給 spec_extend()，因為 extend() 本身委託給空空的 Vecs 的 spec_from
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// 這利用了 `iterator.as_slice().to_vec()`，因為 spec_extend 必須採取更多的步驟來推斷最終的容量 + 長度，從而進行更多的工作。
// `to_vec()` 直接分配正確的金額並準確填寫。
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): 對於 cfg(test)，此方法定義所需的固有 `[T]::to_vec` 方法不可用。
    // 而是使用僅 cfg(test) NB 可用的 `slice::to_vec` 功能，有關更多信息，請參見 slice.rs 中的 slice::hack 模塊。
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}