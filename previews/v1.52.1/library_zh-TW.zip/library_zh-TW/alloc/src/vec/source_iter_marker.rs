use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// 專業化標記，用於在重複使用源分配的同時將迭代器管道收集到 Vec 中，即
/// 執行到位的管道。
///
/// SourceIter 父級 trait 對於專門化功能訪問重用的分配是必需的。
/// 但是，使專業化有效是不夠的。
/// 請參見 impl 上的其他範圍。
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std - 內部 SourceIter/InPlaceIterable traits 僅由適配器鏈實現 <Adapter<Adapter<IntoIter>>> (均歸 core/std 所有)。
// 適配器實現上的其他限制 (`impl<I: Trait> Trait for Adapter<I>` 以外) 僅取決於已標記為特殊化 traits 的其他 traits (Copy，TrustedRandomAccess，FusedIterator)。
//
// I.e. 標記不取決於用戶提供的類型的生存期。模製 `複製` 孔，其他幾個專業已經依賴該孔。
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // 無法通過 trait bounds 表示的其他要求。我們改用 const eval:
        // a) 沒有 ZST，因為將沒有分配給重用，並且指針算術將為 panic b) 大小符合 Alloc 合約的要求 c) 對齊方式符合 Alloc 合約的要求
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // 退回到更通用的實現
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // 使用 try-fold 自
        // - 它對某些迭代器適配器的矢量化效果更好
        // - 與大多數內部迭代方法不同，它只需要一個 &mut 自
        // - 它使我們可以將寫入指針穿過其內部，最後返回
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // 迭代成功，不要丟下頭
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // 檢查 SourceIter 合同是否被維護: 如果不是，我們甚至可能無法做到這一點
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // 檢查 InPlaceIterable 合同。僅在迭代器完全提高了源指針的情況下才有可能。
        // 如果它通過 TrustedRandomAccess 使用未經檢查的訪問，則源指針將停留在其初始位置，我們不能將其用作引用
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // 在源的末尾刪除所有剩餘值，但是一旦 IntoIter 超出範圍，則防止分配本身下降，如果 panics 下降，那麼我們還將洩漏所有收集到 dst_buf 中的元素
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // 因為 try_fold 具有對源指針的唯一引用，所以我們無法在此處精確驗證 InPlaceIterable 合同，我們所能做的就是檢查它是否仍在範圍內
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}