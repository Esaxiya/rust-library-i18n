//! 具有堆已分配內容的連續可增長數組類型，寫為 `Vec<T>`。
//!
//! Vectors 具有 `O(1)` 索引，攤銷的 `O(1)` 推送 (到末尾) 和 `O(1)` 彈出 (從末尾開始)。
//!
//!
//! Vectors 確保它們分配的字節數永遠不會超過 `isize::MAX` 字節。
//!
//! # Examples
//!
//! 您可以使用 [`Vec::new`] 顯式創建 [`Vec`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... 或使用 [`vec!`] 宏:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // 十個零
//! ```
//!
//! 您可以將 [`push`] 值添加到 vector 的末尾 (這將根據需要增大 vector) :
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! 彈出值的工作方式大致相同:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors 還支持索引 (通過 [`Index`] 和 [`IndexMut`] traits) :
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// 連續的可增長數組類型，寫為 `Vec<T>`，發音為 'vector'。
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// 提供 [`vec!`] 宏可以使初始化更加方便:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// 它還可以使用給定值初始化 `Vec<T>` 的每個元素。
/// 這可能比在單獨的步驟中執行分配和初始化更為有效，尤其是在初始化零的 vector 時:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // 以下是等效的，但可能會更慢:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// 有關更多信息，請參見 [Capacity and Reallocation](#capacity-and-reallocation)。
///
/// 使用 `Vec<T>` 作為有效的堆棧:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // 打印 3、2、1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` 類型實現了 [`Index`] trait，因此允許按索引訪問值。一個例子將更加明確:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // 它將顯示 '2'
/// ```
///
/// 但是要小心: 如果您嘗試訪問 `Vec` 中沒有的索引，則您的軟件將為 panic! 你不可以做這個:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// 如果要檢查索引是否在 `Vec` 中，請使用 [`get`] 和 [`get_mut`]。
///
/// # Slicing
///
/// `Vec` 可以是可變的。另一方面，切片是只讀對象。
/// 要獲得 [slice][prim@slice]，請使用 [`&`]。例子:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... 就這樣!
/// // 您也可以這樣:
/// let u: &[usize] = &v;
/// // 或像這樣:
/// let u: &[_] = &v;
/// ```
///
/// 在 Rust 中，當您只想提供讀取訪問權限時，將切片作為參數而不是 vectors 傳遞是更常見的。[`String`] 和 [`&str`] 也是如此。
///
/// # 容量和重新分配
///
/// vector 的容量是為將添加到 vector 上的任何 future 元素分配的空間量。請勿將其與 vector 的 `長度` 混淆，後者指定 vector 中的實際元素數量。
/// 如果 vector 的長度超過其容量，則其容量將自動增加，但必須重新分配其元素。
///
/// 例如，容量為 10 且長度為 0 的 vector 將是一個空的 vector，具有 10 個以上元素的空間。將 10 個或更少的元素壓入 vector 不會改變其容量或引起重新分配。
/// 但是，如果 vector 的長度增加到 11，則必須重新分配，這可能會很慢。因此，建議盡可能使用 [`Vec::with_capacity`] 來指定 vector 希望達到的大小。
///
/// # Guarantees
///
/// 由於其不可思議的基本特性，`Vec` 為其設計提供了很多保證。這樣可以確保在一般情況下開銷盡可能小，並且可以通過不安全的代碼以原始方式正確地對其進行操作。請注意，這些保證是針對不合格的 `Vec<T>`。
/// 如果添加了其他類型參數 (例如，以支持自定義分配器)，則覆蓋其默認值可能會更改行為。
///
/// 從根本上講，`Vec` 始終是 (指針，容量，長度) 三元組。不多不少。這些字段的順序是完全不確定的，您應該使用適當的方法來修改它們。
/// 指針永遠不會為空，因此此類型是經過空指針優化的。
///
/// 但是，指針可能實際上沒有指向已分配的內存。
/// 特別是，如果您通過 [`Vec::new`]，[`vec![]`][`vec!`]，[`Vec::with_capacity(0)`][`Vec::with_capacity`] 或通過在空的 Vec 上調用 [`shrink_to_fit`] 來構造容量為 0 的 `Vec`，它將不會分配內存。同樣，如果將零大小的類型存儲在 `Vec` 內，它將不會為它們分配空間。
/// *請注意，在這種情況下，`Vec` 可能不會報告 [`capacity`] 為 0*。
/// `Vec` 僅在 [`mem: : size_of:::<T>`]` () * capacity()> 0`。
/// 通常，`Vec` 的分配細節非常微妙 - 如果您打算使用 `Vec` 分配內存並將其用於其他用途 (傳遞給不安全的代碼或構建自己的內存支持的集合)，請確保通過使用 `from_raw_parts` 恢復 `Vec` 然後刪除它來釋放該內存。
///
/// 如果 `Vec` 具有已分配的內存，則它指向的內存在堆上 (由分配器 Rust 定義為默認使用)，並且其指針按順序指向 [`len`] 初始化的連續元素 (您將做什麼) 看看是否將其強制切成薄片)，然後是 [`capacity`]`，`[`len`] 邏輯上未初始化的連續元素。
///
///
/// 包含元素 `'a'` 和 `'b'` 且容量為 4 的 vector 可以如下所示。頂部是 `Vec` 結構，它包含一個指向堆中分配的頭，長度和容量的指針。
/// 底部是堆上的分配，即連續的內存塊。
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** 代表未初始化的內存，請參閱 [`MaybeUninit`]。
/// - Note: ABI 不穩定，並且 `Vec` 不保證其內存佈局 (包括字段順序)。
///
/// `Vec` 永遠不會執行 "small optimization"，因為實際上有兩個原因會在其中將元素實際存儲在堆棧中:
///
/// * 對於不安全的代碼，正確地操縱 `Vec` 會更加困難。如果僅移動 `Vec` 的內容，它的地址就不會穩定，因此，確定 `Vec` 是否實際分配了內存將更加困難。
///
/// * 這會懲罰一般情況，每次訪問都會產生一個額外的 branch。
///
/// `Vec` 即使完全為空，也永遠不會自動收縮。這樣可以確保不會發生不必要的分配或釋放。清空 `Vec`，然後將其填充回相同的 [`len`]，不會引起對分配器的調用。如果您希望釋放未使用的內存，請使用 [`shrink_to_fit`] 或 [`shrink_to`]。
///
/// [`push`] 如果報告的容量足夠，[`insert`] 將永遠不會 (重新) 分配。如果 [`len`]`==`[`capacity`]，[`push`] 和 [`insert`] 將 * (重新) 分配。也就是說，報告的容量是完全準確的，並且可以依賴。如果需要，它甚至可以用來手動釋放 `Vec` 分配的內存。
/// 批量插入方法 *可能* 重新分配，即使在沒有必要時也是如此。
///
/// `Vec` 在完全分配或調用 [`reserve`] 時重新分配時，不能保證任何特定的增長策略。當前的策略是基本的，使用非恆定增長因子可能是合乎需要的。無論使用哪種策略，當然都可以保證 *O*(1) 攤銷 [`push`]。
///
/// `vec![x; n]`, `vec![a, b, c, d]` 和 [`Vec::with_capacity(n)`][`Vec::with_capacity`] 都將產生具有所需容量的 `Vec`。
/// 如果 [`len`]`==`[`capacity`] (如 [`vec!`] 宏的情況)，那麼 `Vec<T>` 可以與 [`Box<[T]>`][owned slice] 相互轉換，而無需重新分配或移動元素。
///
/// `Vec` 不會專門覆蓋從其中刪除的任何數據，但也不會專門保留它。它的未初始化內存是它可以使用的臨時空間。通常，它只會執行最有效或最容易實現的任何事情。為了安全起見，請勿依賴刪除的數據進行擦除。
/// 即使您刪除了 `Vec`，它的緩衝區也可以被另一個 `Vec` 簡單地重用。
/// 即使您先將 `Vec` 的內存清零，由於優化器並不認為這是必須保留的副作用，因此實際上可能不會發生。
/// 但是，有一種情況我們不會中斷: 使用 `unsafe` 代碼寫入多餘的容量，然後增加長度以匹配，始終是有效的。
///
/// 當前，`Vec` 不保證刪除元素的順序。
/// 順序過去已更改，並且可能會再次更改。
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// 固有方法
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// 構造一個新的空 `Vec<T>`。
    ///
    /// 直到將元素壓入 vector 為止，vector 才會分配。
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// 構造一個具有指定容量的新的空 `Vec<T>`。
    ///
    /// vector 將能夠準確地容納 `capacity` 元素而無需重新分配。
    /// 如果 `capacity` 為 0，則不會分配 vector。
    ///
    /// 重要的是要注意，儘管返回的 vector 具有指定的 *capacity*，但 vector 的長度為零。
    ///
    /// 有關長度和容量之間差異的說明，請參閱 *[容量和重新分配]*。
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector 不包含任何項目，即使它具有更多功能
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // 這些都無需重新分配即可完成...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... 但是這可能會使 vector 重新分配
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// 直接從另一個 vector 的原始組件創建 `Vec<T>`。
    ///
    /// # Safety
    ///
    /// 由於未檢查的不變量數量，這是非常不安全的:
    ///
    /// * `ptr` 需要事先通過 [`String`]/`Vec 分配 <T>` (至少，如果不是這樣，很可能是不正確的)。
    /// * `T` 需要具有與分配給 `ptr` 相同的大小和對齊方式。
    ///   (具有不太嚴格的對齊方式的 `T` 是不夠的，對齊方式實際上必須等於 [`dealloc`] 的要求，即必須以相同的佈局分配和釋放內存。)
    ///
    /// * `length` 必須小於或等於 `capacity`。
    /// * `capacity` 必須是分配指針的容量。
    ///
    /// 違反這些規則可能會導致諸如破壞分配器的內部數據結構之類的問題。例如，從指向長度為 `size_t` 的 C `char` 數組的指針構建 `Vec<u8>` 是不安全的。
    /// 從 `Vec<u16>` 及其長度構建一個也不安全，因為分配器關心對齊方式，並且這兩種類型具有不同的對齊方式。
    /// 緩衝區的分配是對齊 2 (對於 `u16`)，但是將其轉換為 `Vec<u8>` 後，它將以對齊 1 釋放。
    ///
    /// `ptr` 的所有權有效地轉移到 `Vec<T>`，然後 `Vec<T>` 可以隨意取消分配，重新分配或更改指針所指向的內存的內容。
    /// 調用此函數後，請確保沒有其他東西使用指針。
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME 在 vec_into_raw_parts 穩定後更新此文件。
    ///     // 防止運行 `v` 的析構函數，因此我們可以完全控制分配。
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // 拉出有關 `v` 的各種重要信息
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // 用 4、5、6 覆蓋內存
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // 將所有內容放回 Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// 構造一個新的空 `Vec<T, A>`。
    ///
    /// 直到將元素壓入 vector 為止，vector 才會分配。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// 使用提供的分配器構造具有指定容量的新的空 `Vec<T, A>`。
    ///
    /// vector 將能夠準確地容納 `capacity` 元素而無需重新分配。
    /// 如果 `capacity` 為 0，則不會分配 vector。
    ///
    /// 重要的是要注意，儘管返回的 vector 具有指定的 *capacity*，但 vector 的長度為零。
    ///
    /// 有關長度和容量之間差異的說明，請參閱 *[容量和重新分配]*。
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector 不包含任何項目，即使它具有更多功能
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // 這些都無需重新分配即可完成...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... 但是這可能會使 vector 重新分配
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// 直接從另一個 vector 的原始組件創建 `Vec<T, A>`。
    ///
    /// # Safety
    ///
    /// 由於未檢查的不變量數量，這是非常不安全的:
    ///
    /// * `ptr` 需要事先通過 [`String`]/`Vec 分配 <T>` (至少，如果不是這樣，很可能是不正確的)。
    /// * `T` 需要具有與分配給 `ptr` 相同的大小和對齊方式。
    ///   (具有不太嚴格的對齊方式的 `T` 是不夠的，對齊方式實際上必須等於 [`dealloc`] 的要求，即必須以相同的佈局分配和釋放內存。)
    ///
    /// * `length` 必須小於或等於 `capacity`。
    /// * `capacity` 必須是分配指針的容量。
    ///
    /// 違反這些規則可能會導致諸如破壞分配器的內部數據結構之類的問題。例如，從指向長度為 `size_t` 的 C `char` 數組的指針構建 `Vec<u8>` 是不安全的。
    /// 從 `Vec<u16>` 及其長度構建一個也不安全，因為分配器關心對齊方式，並且這兩種類型具有不同的對齊方式。
    /// 緩衝區的分配是對齊 2 (對於 `u16`)，但是將其轉換為 `Vec<u8>` 後，它將以對齊 1 釋放。
    ///
    /// `ptr` 的所有權有效地轉移到 `Vec<T>`，然後 `Vec<T>` 可以隨意取消分配，重新分配或更改指針所指向的內存的內容。
    /// 調用此函數後，請確保沒有其他東西使用指針。
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME 在 vec_into_raw_parts 穩定後更新此文件。
    ///     // 防止運行 `v` 的析構函數，因此我們可以完全控制分配。
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // 拉出有關 `v` 的各種重要信息
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // 用 4、5、6 覆蓋內存
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // 將所有內容放回 Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// 將 `Vec<T>` 分解為其原始組件。
    ///
    /// 返回指向基礎數據的原始指針，vector 的長度 (以元素為單位) 和數據的已分配容量 (以元素為單位)。
    /// 這些參數與 [`from_raw_parts`] 的參數順序相同。
    ///
    /// 調用此函數後，調用者將負責先前由 `Vec` 管理的內存。
    /// 唯一的方法是使用 [`from_raw_parts`] 函數將原始指針，長度和容量轉換回 `Vec`，從而允許析構函數執行清除操作。
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // 現在，我們可以對組件進行更改，例如將原始指針轉換為兼容類型。
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// 將 `Vec<T>` 分解為其原始組件。
    ///
    /// 返回指向基礎數據的原始指針，vector 的長度 (以元素為單位)，數據的已分配容量 (以元素為單位) 以及分配器。
    /// 這些參數與 [`from_raw_parts_in`] 的參數順序相同。
    ///
    /// 調用此函數後，調用者將負責先前由 `Vec` 管理的內存。
    /// 唯一的方法是使用 [`from_raw_parts_in`] 函數將原始指針，長度和容量轉換回 `Vec`，從而允許析構函數執行清除操作。
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // 現在，我們可以對組件進行更改，例如將原始指針轉換為兼容類型。
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// 返回 vector 可以保留而不重新分配的元素數。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// 為給定的 `Vec<T>` 至少保留 `additional` 個要插入的元素保留容量。
    /// 該集合可以保留更多空間，以避免頻繁的重新分配。
    /// 調用 `reserve` 後，容量將大於或等於 `self.len() + additional`。
    /// 如果容量已經足夠，則不執行任何操作。
    ///
    /// # Panics
    ///
    /// 如果新容量超過 `isize::MAX` 字節，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// 保留最小容量，以便在給定的 `Vec<T>` 中精確插入 `additional` 個元素。
    ///
    /// 調用 `reserve_exact` 後，容量將大於或等於 `self.len() + additional`。
    /// 如果容量已經足夠，則不執行任何操作。
    ///
    /// 請注意，分配器可能會給集合提供比其請求更多的空間。
    /// 因此，不能依靠容量來精確地最小化。
    /// 如果希望插入 future，則最好使用 `reserve`。
    ///
    /// # Panics
    ///
    /// 如果新容量溢出 `usize`，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// 嘗試為給 `Vec<T>` 至少插入 `additional` 個元素保留容量。
    /// 該集合可以保留更多空間，以避免頻繁的重新分配。
    /// 調用 `try_reserve` 後，容量將大於或等於 `self.len() + additional`。
    /// 如果容量已經足夠，則不執行任何操作。
    ///
    /// # Errors
    ///
    /// 如果容量溢出，或者分配器報告失敗，則返回錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // 預先保留內存，如果不能，則退出
    ///     output.try_reserve(data.len())?;
    ///
    ///     // 現在我們知道在我們複雜的工作中這不能 OOM
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // 非常複雜
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// 嘗試保留將最小 `additional` 元素插入給定 `Vec<T>` 的最小容量。
    /// 調用 `try_reserve_exact` 後，如果返回 `Ok(())`，則容量將大於或等於 `self.len() + additional`。
    ///
    /// 如果容量已經足夠，則不執行任何操作。
    ///
    /// 請注意，分配器可能會給集合提供比其請求更多的空間。
    /// 因此，不能依靠容量來精確地最小化。
    /// 如果希望插入 future，則最好使用 `reserve`。
    ///
    /// # Errors
    ///
    /// 如果容量溢出，或者分配器報告失敗，則返回錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // 預先保留內存，如果不能，則退出
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // 現在我們知道在我們複雜的工作中這不能 OOM
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // 非常複雜
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// 盡可能縮小 vector 的容量。
    ///
    /// 它將下降到盡可能接近的長度，但是分配器仍可以通知 vector，還有空間可以容納更多元素。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // 容量永遠不會小於長度，並且當它們相等時沒有任何事可做，因此我們可以通過僅以更大的容量進行調用來避免 `RawVec::shrink_to_fit` 中的 panic 情況。
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// 將 vector 的容量降低一個下限。
    ///
    /// 容量將至少保持與長度和提供的值一樣大。
    ///
    ///
    /// 如果當前容量小於下限，則為無操作。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// 將 vector 轉換為 [`Box<[T]>`][owned slice]。
    ///
    /// 請注意，這將減少任何多餘的容量。
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// 任何多餘的容量都將被刪除:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// 縮短 vector，保留前 `len` 個元素，其餘元素刪除。
    ///
    /// 如果 `len` 大於 vector 的當前長度，則無效。
    ///
    /// [`drain`] 方法可以模擬 `truncate`，但是會導致多餘的元素被返回而不是丟棄。
    ///
    ///
    /// 請注意，此方法對 vector 的已分配容量沒有影響。
    ///
    /// # Examples
    ///
    /// 將五個元素 vector 截斷為兩個元素:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// 當 `len` 大於 vector 的當前長度時，不會發生截斷:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// 在 `len == 0` 等效於調用 [`clear`] 方法時截斷。
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // 這是安全的，因為:
        //
        // * 傳遞給 `drop_in_place` 的切片是有效的; `len > self.len` 的情況避免了創建無效的分片，並且
        // * vector 的 `len` 會在調用 `drop_in_place` 之前縮小，這樣一來，如果 `drop_in_place` 一次到達 panic，則兩次值都不會丟失 (如果兩次 panics，則程序將中止)。
        //
        //
        //
        unsafe {
            // Note: 故意是 `>`，而不是 `>=`。
            //       在某些情況下，將其更改為 `>=` 會對性能產生負面影響。
            //       有關更多信息，請參見 #78884。
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// 提取包含整個 vector 的切片。
    ///
    /// 等效於 `&s[..]`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// 提取整個 vector 的可變切片。
    ///
    /// 等效於 `&mut s[..]`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// 返回指向 vector 緩衝區的原始指針。
    ///
    /// 調用者必須確保 vector 不在此函數返回的指針的作用範圍內，否則它將最終指向垃圾。
    /// 修改 vector 可能會導致重新分配其緩衝區，這還會使指向該緩衝區的任何指針無效。
    ///
    /// 調用者還必須確保指針 (non-transitively) 所指向的內存 (從 `UnsafeCell` 內部除外) 永遠不會使用此指針或從其派生的任何指針寫入。
    /// 如果需要突變切片的內容，請使用 [`as_mut_ptr`]。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // 我們對同名的 slice 方法進行了陰影處理，以避免通過 `deref` 來創建中間引用。
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// 返回指向 vector 緩衝區的不安全的可變指針。
    ///
    /// 調用者必須確保 vector 不在此函數返回的指針的作用範圍內，否則它將最終指向垃圾。
    ///
    /// 修改 vector 可能會導致重新分配其緩衝區，這還會使指向該緩衝區的任何指針無效。
    ///
    /// # Examples
    ///
    /// ```
    /// // 分配足夠大的 vector 以容納 4 個元素。
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // 通過原始指針寫入來初始化元素，然後設置長度。
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // 我們對同名的 slice 方法進行了陰影處理，以避免通過 `deref_mut` 來創建中間引用。
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// 返回對基礎分配器的引用。
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// 將 vector 的長度強制為 `new_len`。
    ///
    /// 這是一個低級操作，不保留該類型的任何普通不變式。
    /// 通常，使用安全操作之一 (例如 [`truncate`]，[`resize`]，[`extend`] 或 [`clear`]) 來更改 vector 的長度。
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` 必須小於或等於 [`capacity()`]。
    /// - `old_len..new_len` 上的元素必須初始化。
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// 當 vector 用作其他代碼的緩衝區時，尤其是在 FFI 上，此方法很有用:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // 這只是 doc 示例的基本框架;
    /// # // 不要將其用作真實庫的起點。
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // 根據 FFI 方法的文檔， "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // 安全: 當 `deflateGetDictionary` 返回 `Z_OK` 時，它認為:
    ///     // 1. `dict_length` 元素已初始化。
    ///     // 2.
    ///     // `dict_length` <= (32_768) 的容量，這使 `set_len` 可以安全地進行调用。
    ///     unsafe {
    ///         // 撥打 FFI 電話...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... 並將長度更新為已初始化的長度。
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// 雖然下面的示例是正確的，但由於 `set_len` 調用之前未釋放內部 vectors，所以存在內存洩漏:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` 為空，因此不需要初始化任何元素。
    /// // 2. `0 <= capacity` 始終保留 `capacity` 是什麼。
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// 通常，在這裡，人們將使用 [`clear`] 來正確刪除內容，因此不會洩漏內存。
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// 從 vector 中刪除一個元素並返回它。
    ///
    /// 刪除的元素被 vector 的最後一個元素替換。
    ///
    /// 這不會保留排序，但是是 O(1)。
    ///
    /// # Panics
    ///
    /// 如果 `index` 超出範圍，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // 我們用最後一個元素替換 self [index]。
            // 請注意，如果上面的邊界檢查成功，則必須有最後一個元素 (可以是 self [index] 本身)。
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// 在 vector 內的位置 `index` 處插入一個元素，並將其後的所有元素向右移動。
    ///
    ///
    /// # Panics
    ///
    /// 如果為 `index > len`，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // 新元素的空間
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // 絕對可靠的地方，可為您帶來新的價值
            //
            {
                let p = self.as_mut_ptr().add(index);
                // 轉移一切以騰出空間。
                // (將第 index 個元素複製到兩個連續的位置。)
                ptr::copy(p, p.offset(1), len - index);
                // 將其寫入，覆蓋第 index 個元素的第一個副本。
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// 刪除並返回 vector 中位置 `index` 的元素，將其後的所有元素向左移動。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `index` 超出範圍，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // 我們要去的地方。
                let ptr = self.as_mut_ptr().add(index);
                // 將其複制出來，不安全地在堆棧上和 vector 中同時擁有該值的副本。
                //
                ret = ptr::read(ptr);

                // 向下移動所有內容以填充該位置。
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// 僅保留謂詞指定的元素。
    ///
    /// 換句話說，刪除所有元素 `e`，以使 `f(&e)` 返回 `false`。
    /// 此方法在原位運行，以原始順序恰好一次訪問每個元素，並保留保留元素的順序。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// 由於按原始順序僅對元素進行過一次訪問，因此可以使用外部狀態來確定要保留哪些元素。
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // 如果不執行防卸裝置，請避免雙落，因為在此過程中我們可能會產生一些漏洞。
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <- 處理後的 len-> |^- 檢查旁邊
        //                  | <- 刪除的 cnt-> |
        //      | <-original_len-> | 保留: 謂詞在其上返回 true 的元素。
        //
        // 孔: 元素插槽已移動或掉落。
        // 未選中: 未選中的有效元素。
        //
        // 當元素的謂詞或 `drop` 發生驚慌時，將調用此下降保護。
        // 它將未經檢查的元素移動到覆蓋孔和 `set_len` 的正確長度。
        // 在謂詞和 `drop` 永遠不會驚慌的情況下，它將被優化。
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // 安全: 尾隨的未經檢查的物品必須有效，因為我們從不觸摸它們。
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // 安全性: 填充孔後，所有項目均位於連續內存中。
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // 安全: 未經檢查的元素必須有效。
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // 如果 `drop_in_place` 發生恐慌，請提前提早避免兩次下降。
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // 安全: 掉落後，我們再也不會碰這個元素。
                unsafe { ptr::drop_in_place(cur) };
                // 我們已經提前了櫃檯。
                continue;
            }
            if g.deleted_cnt > 0 {
                // 安全: `deleted_cnt`> 0，因此孔槽不得與當前元件重疊。
                // 我們使用 copy 進行移動，從此再也不會觸碰此元素。
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // 所有項目都已處理。LLVM 可以將其優化為 `set_len`。
        drop(g);
    }

    /// 刪除 vector 中除第一個連續元素之外的所有元素，這些元素都解析為相同的鍵。
    ///
    ///
    /// 如果對 vector 進行了排序，則將刪除所有重複項。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// 移除 vector 中滿足給定相等關係的所有連續元素，但第一個除外。
    ///
    /// `same_bucket` 函數傳遞了對 vector 中兩個元素的引用，並且必須確定這些元素是否相等。
    /// 元素以與切片中的順序相反的順序傳遞，因此，如果 `same_bucket(a, b)` 返回 `true`，則刪除 `a`。
    ///
    ///
    /// 如果對 vector 進行了排序，則將刪除所有重複項。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// 將元素追加到集合的後面。
    ///
    /// # Panics
    ///
    /// 如果新容量超過 `isize::MAX` 字節，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // 如果我們分配 > isize::MAX 字節，或者對於零大小的類型，長度增量將溢出，則將為 panic 或中止。
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// 從 vector 中刪除最後一個元素並返回它; 如果它為空，則返回 [`None`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// 將 `other` 的所有元素移到 `Self`，將 `other` 留空。
    ///
    /// # Panics
    ///
    /// 如果 vector 中的元素數量溢出 `usize`，則 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// 將元素從其他緩衝區追加到 `Self`。
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// 創建一個排水迭代器，該迭代器將刪除 vector 中的指定範圍並產生已刪除的項目。
    ///
    /// 刪除迭代器 ** 時，即使未完全消耗迭代器，該範圍中的所有元素也會從 vector 中刪除。
    /// 如果沒有 ** 刪除迭代器 (例如，使用 [`mem::forget`])，則不確定刪除了多少個元素。
    ///
    /// # Panics
    ///
    /// 如果起點大於終點或終點大於 vector 的長度，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // 全範圍清除 vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // 記憶安全
        //
        // 首次創建 Drain 時，它會縮短源 vector 的長度，以確保如果 Drain 的析構函數從不運行，則根本無法訪問未初始化或移出的元素。
        //
        //
        // Drain 將 ptr::read 取出要刪除的值。
        // 完成後，將 vec 的其餘尾部複製回以覆蓋孔，並將 vector 的長度恢復為新的長度。
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // 設置 self.vec 長度開始，以防萬一 Drain 洩漏
            self.set_len(start);
            // 使用 IterMut 中的借位指示整個 Drain 迭代器的借位行為 (例如 &mut T)。
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// 清除 vector，刪除所有值。
    ///
    /// 請注意，此方法對 vector 的已分配容量沒有影響。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// 返回 vector 中的元素數，也稱為 'length'。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// 如果 vector 不包含任何元素，則返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 在給定的索引處將集合拆分為兩個。
    ///
    /// 返回一個新分配的 vector，其中包含 `[at, len)` 範圍內的元素。
    /// 調用之後，將保留原始 vector，其中包含元素 `[0, at)`，其先前容量不變。
    ///
    ///
    /// # Panics
    ///
    /// 如果為 `at > len`，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // 新的 vector 可以接管原始緩衝區並避免複製
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // 不安全地 `set_len` 並將項目複製到 `other`。
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// 在適當位置調整 `Vec` 的大小，以使 `len` 等於 `new_len`。
    ///
    /// 如果 `new_len` 大於 `len`，則將 `Vec` 擴展該差值，並在每個附加的插槽中填充調用閉包 `f` 的結果。
    ///
    /// `f` 的返回值將按照生成順序返回到 `Vec`。
    ///
    /// 如果 `new_len` 小於 `len`，則將 `Vec` 截斷。
    ///
    /// 此方法使用閉包在每次推送時創建新值。如果您希望給定值 [`Clone`]，請使用 [`Vec::resize`]。
    /// 如果要使用 [`Default`] trait 生成值，則可以將 [`Default::default`] 作為第二個參數傳遞。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// 消耗並洩漏 `Vec`，返回對內容的可變引用， `&'a mut [T]`.
    /// 請注意，類型 `T` 必須超過所選的壽命 `'a`。
    /// 如果類型僅具有靜態引用，或者根本沒有靜態引用，則可以將其選擇為 `'static`。
    ///
    /// 此功能類似於 [`Box`] 上的 [`leak`][Box::leak] 功能，除了無法恢復洩漏的內存。
    ///
    ///
    /// 此功能主要用於在程序的剩餘生命期內保留的數據。
    /// 刪除返回的引用將導致內存洩漏。
    ///
    /// # Examples
    ///
    /// 簡單用法:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// 以 `MaybeUninit<T>` 的片段形式返回 vector 的剩餘備用容量。
    ///
    /// 返回的切片可用於用數據填充 vector (例如
    /// (通過從文件中讀取) )，然後將數據標記為使用 [`set_len`] 方法初始化的數據。
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 分配足夠大的 vector 以容納 10 個元素。
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // 填寫前 3 個元素。
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // 將 vector 的前 3 個元素標記為已初始化。
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // 不能使用 `split_at_spare_mut` 來實現此方法，以防止指向緩衝區的指針無效。
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// 以 `T` 的片段形式返回 vector 內容，以及以 `MaybeUninit<T>` 的片段形式返回 vector 的剩餘備用容量。
    ///
    /// 在使用 [`set_len`] 方法將數據標記為已初始化之前，返回的備用容量片可用於用數據填充 vector (例如，通過從文件讀取)。
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// 請注意，這是一個低級 API，出於優化目的應謹慎使用。
    /// 如果需要將數據附加到 `Vec`，則可以根據實際需要使用 [`push`]，[`extend`]，[`extend_from_slice`]，[`extend_from_within`]，[`insert`]，[`append`]，[`resize`] 或 [`resize_with`]。
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 保留足夠大的空間來容納 10 個元素。
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // 填寫接下來的 4 個元素。
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // 將 vector 的 4 個元素標記為已初始化。
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len 被忽略，因此永遠不變
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// 安全性: 更改返回的.2 (&mut usize) 與調用 `.set_len(_)` 相同。
    ///
    /// 此方法用於一次唯一地訪問 `extend_from_within` 中的所有 vec 零件。
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` 保證對 `len` 元素有效
        // - `spare_ptr` 指向緩衝區後的一個元素，因此它與 `initialized` 不重疊
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// 在適當位置調整 `Vec` 的大小，以使 `len` 等於 `new_len`。
    ///
    /// 如果 `new_len` 大於 `len`，則 `Vec` 會擴展此差值，每個額外的插槽都將用 `value` 填充。
    ///
    /// 如果 `new_len` 小於 `len`，則將 `Vec` 截斷。
    ///
    /// 為了能夠克隆傳遞的值，此方法需要 `T` 實現 [`Clone`]。
    /// 如果您需要更大的靈活性 (或希望依靠 [`Default`] 而不是 [`Clone`])，請使用 [`Vec::resize_with`]。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// 克隆切片中的所有元素並將其附加到 `Vec`。
    ///
    /// 遍歷切片 `other`，克隆每個元素，然後將其附加到此 `Vec`。
    /// `other` vector 按順序遍歷。
    ///
    /// 請注意，此功能與 [`extend`] 相同，只不過它專門用於切片。
    ///
    /// 如果並且當 Rust 得到專門化時，此功能可能會被棄用 (但仍然可用)。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// 將元素從 `src` 複製到 vector 的末尾。
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` 保證給定範圍對索引自身有效
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// 這段代碼概括了 `extend_with_{element,default}`。
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// 使用給定的生成器將 vector 擴展 `n` 值。
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // 使用 SetLenOnDrop 可以解決編譯器可能無法通過 `ptr` 到 self.set_len() 不別名存儲的錯誤。
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // 寫下除最後一個元素外的所有元素
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // 在 next() panics 的情況下，增加每一步的長度
                local_len.increment_len(1);
            }

            if n > 0 {
                // 我們可以直接編寫最後一個元素，而無需不必要地克隆
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // 鏡頭由護目鏡設定
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// 根據 [`PartialEq`] trait 的實現，刪除 vector 中連續的重複元素。
    ///
    ///
    /// 如果對 vector 進行了排序，則將刪除所有重複項。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// 內部方法和功能
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` 需要有效的索引
    /// - `self.capacity() - self.len()` 必須為 `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len 僅在初始化元素後才增加
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - 调用者保證 src 是有效索引
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - 元素剛剛使用 `MaybeUninit::write` 初始化，因此可以增加 len
            // - 在每個元素之後增加 len 以防止洩漏 (請參閱問題 #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - 调用者保證 `src` 是有效索引
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - 這兩個指針都是從唯一的切片引用 (＆mut [_]`) 創建的，因此它們是有效的並且不會重疊。
            //
            // - 元素是: Copy，所以可以復制它們，而不用原始值做任何事情
            // - `count` 等於 `source` 的 len，因此源對 `count` 讀取有效
            // - `.reserve(count)` 保證 `spare.len() >= count` 如此備用對 `count` 寫入有效
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - 元素剛剛由 `copy_nonoverlapping` 初始化
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec 的常見 trait 實現
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): 對於 cfg(test)，此方法定義所需的固有 `[T]::to_vec` 方法不可用。
    // 而是使用僅 cfg(test) NB 可用的 `slice::to_vec` 功能，有關更多信息，請參見 slice.rs 中的 slice::hack 模塊。
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // 刪除任何不會被覆蓋的內容
        self.truncate(other.len());

        // self.len <= other.len 由於上面的截斷，因此這裡的切片始終是入站的。
        //
        let (init, tail) = other.split_at(self.len());

        // 重用包含的值的 allocations/resources。
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// 創建一個消耗迭代器，即一個將每個值移出 vector (從開始到結束) 的迭代器。
    /// 調用此後不能使用 vector。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s 具有字符串類型，而不是 &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // 各種 SpecFrom/SpecExtend 實現在沒有進一步優化要應用時將委派給它們的葉子方法
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // 通用迭代器就是這種情況。
        //
        // 此功能在道德上應等同於:
        //
        //      用於迭代器中的項目 {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB 不會溢出，因為我們不得不分配地址空間
                self.set_len(len + 1);
            }
        }
    }

    /// 創建一個拼接迭代器，用給定的 `replace_with` 迭代器替換 vector 中的指定範圍，並生成已刪除的項目。
    ///
    /// `replace_with` 長度不必與 `range` 相同。
    ///
    /// `range` 即使直到最後都沒有使用迭代器，也將刪除該變量。
    ///
    /// 如果 `Splice` 值洩漏，則未指定從 vector 中刪除了多少個元素。
    ///
    /// 僅當 `Splice` 值下降時才使用輸入迭代器 `replace_with`。
    ///
    /// 如果滿足以下條件，則為最佳選擇
    ///
    /// * 尾部 (`range` 之後的 vector 中的元素) 為空，
    /// * 或 `replace_with` 產生的元素少於或等於 'range' 的長度
    /// * 或其 `size_hint()` 的下界是正確的。
    ///
    /// 否則，將分配一個臨時的 vector 並將尾部移動兩次。
    ///
    /// # Panics
    ///
    /// 如果起點大於終點或終點大於 vector 的長度，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// 創建一個迭代器，該迭代器使用閉包確定是否應刪除元素。
    ///
    /// 如果閉包返回 true，則元素將被刪除並屈服。
    /// 如果閉包返回 false，則該元素將保留在 vector 中，並且不會由迭代器產生。
    ///
    /// 使用此方法等效於以下代碼:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // 您的代碼在這裡
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// 但是 `drain_filter` 更易於使用。
    /// `drain_filter` 這樣做還可以提高效率，因為它可以使數組的元素大量回移。
    ///
    /// 請注意，無論選擇保留還是刪除 `drain_filter`，您都可以對過濾器閉包中的每個元素進行突變。
    ///
    ///
    /// # Examples
    ///
    /// 將數組拆分為偶數和機率，重新使用原始分配:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // 防止我們洩漏 (洩漏放大)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// 擴展將元素從引用中復制出來的實現，然後再將其推入 Vec。
///
/// 此實現專用於切片迭代器，它使用 [`copy_from_slice`] 一次附加整個切片。
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// 實現 vectors 的比較， [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// 實現 vectors 的排序， [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // 對 [T] 使用 drop 使用原始切片將 vector 的元素引用為最弱的必要類型;
            //
            // 在某些情況下可以避免有效性問題
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec 處理重新分配
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// 創建一個空的 `Vec<T>`。
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: 測試引入 libstd，這會導致錯誤
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: 測試引入 libstd，這會導致錯誤
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// 如果 `Vec<T>` 的大小與請求的數組的大小完全匹配，則以數組的形式獲取 `Vec<T>` 的全部內容。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// 如果長度不匹配，則輸入以 `Err` 返回:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// 如果只需要獲得 `Vec<T>` 的前綴就可以了，您可以先調用 [`.truncate(N)`](Vec::truncate)。
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // 安全: `.set_len(0)` 總是響亮的。
        unsafe { vec.set_len(0) };

        // 安全: `Vec` 的指針始終正確對齊，並且
        // 數組所需的對齊方式與項目相同。
        // 我們之前檢查過我們有足夠的物品。
        // `set_len` 告訴 `Vec` 也不要將其丟棄，因此這些項目將不會被兩次丟棄。
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}