use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// 從兩個升序的迭代器的並集追加所有鍵值對，並在此過程中遞增 `length` 變量。後者使调用者更容易避免在掉落處理程序出現緊急情況時發生洩漏。
    ///
    /// 如果兩個迭代器都產生相同的密鑰，則此方法將從左迭代器中刪除該對，並從右迭代器中追加該對。
    ///
    /// 如果要使樹以嚴格的升序結束 (例如 `BTreeMap`)，則兩個迭代器都應以嚴格的升序生成鍵，每個鍵都大於樹中的所有鍵，包括輸入時樹中已經存在的任何鍵。
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // 我們準備在線性時間內將 `left` 和 `right` 合併為一個排序的序列。
        let iter = MergeIter(MergeIterInner::new(left, right));

        // 同時，我們根據線性時間中的排序序列構建一棵樹。
        self.bulk_push(iter, length)
    }

    /// 將所有鍵值對推入樹的末尾，並在此過程中遞增 `length` 變量。
    /// 後者使調用者在迭代器出現緊急情況時更容易避免洩漏。
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // 遍歷所有鍵值對，將它們推入正確級別的節點。
        for (key, value) in iter {
            // 嘗試將鍵值對推入當前的葉節點。
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // 沒有剩餘空間了，往上推，往那兒推。
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // 找到一個剩餘空間的節點，將其推入此處。
                                open_node = parent;
                                break;
                            } else {
                                // 再上去
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // 我們在頂部，創建一個新的根節點並推送到那裡。
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // 推送鍵值對和新的右子樹。
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // 再次下降到最右邊的葉子。
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // 每次迭代增加長度，以確保即使前進迭代器 panick，地圖也會刪除附加的元素。
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// 用於將兩個排序的序列合併為一個的迭代器
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// 如果兩個鍵相等，則從正確的源返回鍵值對。
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}