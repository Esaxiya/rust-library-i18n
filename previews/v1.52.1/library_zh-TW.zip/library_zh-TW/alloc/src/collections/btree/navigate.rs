use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// 暫時取出另一個相同範圍的不變值。
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// 查找限定樹中指定範圍的不同葉邊緣。
    /// 將一對不同的句柄返回到同一棵樹或一對空選項。
    ///
    /// # Safety
    ///
    /// 除非 `BorrowType` 是 `Immut`，否則請勿使用重複的句柄訪問同一 KV 兩次。
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// 等效於 `(root1.first_leaf_edge()，root2.last_leaf_edge())`，但效率更高。
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// 查找在樹中劃定特定範圍的一對葉邊緣。
    ///
    /// 僅當按鍵對樹進行排序 (如 `BTreeMap` 中的樹) 時，結果才有意義。
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // 安全: 我們的借貸類型是一成不變的。
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// 查找界定整個樹的一對葉邊。
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// 將唯一引用拆分為一對界定指定範圍的葉邊緣。
    /// 結果是允許 (some) 突變的非唯一引用，必須小心使用。
    ///
    /// 僅當按鍵對樹進行排序 (如 `BTreeMap` 中的樹) 時，結果才有意義。
    ///
    ///
    /// # Safety
    /// 請勿使用重複的句柄訪問同一 KV 兩次。
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// 將唯一參考分割為一對葉子邊緣，以界定樹的整個範圍。
    /// 結果是非唯一參考，允許突變 (僅值)，因此必須小心使用。
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // 我們在這裡複製根 NodeRef - 我們將永遠不會兩次訪問同一個 KV，並且永遠不會出現重疊的值引用。
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// 將唯一參考分割為一對葉子邊緣，以界定樹的整個範圍。
    /// 結果是非唯一參考，允許大規模破壞性突變，因此必須格外小心。
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // 我們在此處複製根 NodeRef－我們將永遠不會以與從根獲得的引用重疊的方式訪問它。
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// 給定葉子 edge 句柄，將 [`Result::Ok`] 及其句柄返回到右側的相鄰 KV，該相鄰 KV 在同一葉子節點中或在祖先節點中。
    ///
    /// 如果葉子 edge 是樹中的最後一個葉子，則返回帶有根節點的 [`Result::Err`]。
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// 給定葉子 edge 句柄，將 [`Result::Ok`] 及其句柄返回到左側的相鄰 KV，該相鄰 KV 在同一葉子節點中或在祖先節點中。
    ///
    /// 如果葉子 edge 是樹中的第一個葉子，則返回帶有根節點的 [`Result::Err`]。
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// 給定一個內部 edge 句柄，將 [`Result::Ok`] 及其句柄返回到右側的相鄰 KV，該 KV 在同一內部節點中或在祖先節點中。
    ///
    /// 如果內部 edge 是樹中的最後一個，則返回帶有根節點的 [`Result::Err`]。
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// 給定一個即將死去的樹的葉子 edge 句柄，則返回右側的下一個葉子 edge，以及位於兩者之間的鍵值對，它們在同一葉節點中，在祖先節點中或不存在。
    ///
    ///
    /// 此方法還會取消分配到達末尾的所有 node(s)。
    /// 這意味著如果不存在更多的鍵 / 值對，則樹的整個其餘部分將被釋放，並且沒有剩餘可返回。
    ///
    /// # Safety
    /// 給定的 edge 一定不是先前由對方 `deallocating_next_back` 返回的。
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// 給定一個即將死去的樹的葉子 edge 句柄，則返回左側的下一個葉子 edge，並返回位於兩者之間的鍵 / 值對，它們在同一葉節點中，在祖先節點中或不存在。
    ///
    ///
    /// 此方法還會取消分配到達末尾的所有 node(s)。
    /// 這意味著如果不存在更多的鍵 / 值對，則樹的整個其餘部分將被釋放，並且沒有剩餘可返回。
    ///
    /// # Safety
    /// 給定的 edge 一定不是先前由對方 `deallocating_next` 返回的。
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// 從葉到根取消分配一堆節點。
    /// 這是在 `deallocating_next` 和 `deallocating_next_back` 一直在樹的兩邊蠶食並且擊中了相同的 edge 之後，重新分配樹的其餘部分的唯一方法。
    /// 由於僅在返回所有鍵和值後才調用它，因此不會對任何鍵或值進行清理。
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 將葉子 edge 句柄移動到下一個葉子 edge，並返回對其之間的鍵和值的引用。
    ///
    ///
    /// # Safety
    /// 行駛方向上必須有另一個 KV。
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// 將葉子 edge 句柄移動到上一個葉子 edge，並返回對其之間的鍵和值的引用。
    ///
    ///
    /// # Safety
    /// 行駛方向上必須有另一個 KV。
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 將葉子 edge 句柄移動到下一個葉子 edge，並返回對其之間的鍵和值的引用。
    ///
    ///
    /// # Safety
    /// 行駛方向上必須有另一個 KV。
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // 根據基準測試，這樣做的最後速度更快。
        kv.into_kv_valmut()
    }

    /// 將葉子 edge 句柄移動到上一個葉子，並返回對其之間的鍵和值的引用。
    ///
    ///
    /// # Safety
    /// 行駛方向上必須有另一個 KV。
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // 根據基準測試，這樣做的最後速度更快。
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// 將葉子 edge 句柄移動到下一個葉子 edge，並返回它們之間的鍵和值，重新分配留下的任何節點，同時將對應的 edge 懸置在其父節點中。
    ///
    /// # Safety
    /// - 行駛方向上必須有另一個 KV。
    /// - 對方 `next_back_unchecked` 先前未在用於遍歷樹的任何句柄副本上返回該 KV。
    ///
    /// 進行更新後的句柄的唯一安全方法是對其進行比較，刪除它，然後根據其安全條件再次調用此方法，或者根據其安全條件再次調用對應的 `next_back_unchecked`。
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// 將葉子 edge 句柄移至上一個葉子 edge，並返回其間的鍵和值，重新分配留下的任何節點，同時將其父節點中對應的 edge 懸空。
    ///
    /// # Safety
    /// - 行駛方向上必須有另一個 KV。
    /// - 對應的 `next_unchecked` 先前未在用於遍歷樹的句柄的任何副本上返回該葉 edge。
    ///
    /// 進行更新後的句柄的唯一安全方法是對其進行比較，刪除它，並根據其安全條件再次調用此方法，或根據其安全條件調用對應的 `next_unchecked`。
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// 返回節點中或節點下方的最左邊的葉子 edge，換句話說，返迴向前導航時需要的 edge (向後導航時需要的 edge)。
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// 返回節點內或節點下最右邊的葉子 edge，換句話說，向前導航時需要最後一個 edge (向後導航時需要第一個 edge)。
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// 按鍵升序訪問葉節點和內部 KV，也按深度優先順序訪問整個內部節點，這意味著內部節點先於其各個 KV 和其子節點。
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// 計算 (子) 樹中的元素數。
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// 返回最接近 KV 的葉子 edge，以進行前嚮導航。
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// 返回最接近 KV 的葉子 edge，以進行向後導航。
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}