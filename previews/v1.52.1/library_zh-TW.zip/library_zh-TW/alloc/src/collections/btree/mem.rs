use core::intrinsics;
use core::mem;
use core::ptr;

/// 這將通過調用相關函數來替換 `v` 唯一引用背後的值。
///
///
/// 如果 `change` 閉包中出現 panic，則整個過程將被中止。
#[allow(dead_code)] // 保留說明，以供 future 使用
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// 這將通過調用相關函數來替換 `v` 唯一引用背後的值，並返回沿途獲得的結果。
///
///
/// 如果 `change` 閉包中出現 panic，則整個過程將被中止。
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}