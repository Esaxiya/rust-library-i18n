use core::marker::PhantomData;
use core::ptr::NonNull;

/// 當您知道某個重新引用及其所有後代 (即從該派生而來的所有指針和引用) 在某個時候不再使用時，對某個唯一引用的重新引用進行建模。
///
///
/// 借位檢查器通常為您處理借位的這種堆積，但是完成這種堆積的某些控制流程對於編譯器而言太複雜了。
/// `DormantMutRef` 允許您檢查自己是否借用，同時仍然表示其堆疊性質，並且封裝執行此操作所需的原始指針代碼而沒有未定義的行為。
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// 捕獲唯一的借入，然後立即重新借入。
    /// 對於編譯器，新引用的生存期與原始引用的生存期相同，但是您 promise 可以將其使用更短的時間。
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // 安全: 我們通過 `_marker` 在整個 'a 處保留借入，並且我們公開
        // 僅此參考，因此它是唯一的。
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// 恢復為最初捕獲的唯一借項。
    ///
    /// # Safety
    ///
    /// 重新借用必須已經結束，即，不再可以使用 `new` 返回的引用以及從該引用派生的所有指針和引用。
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // 安全: 我們自己的安全條件暗示此參考文獻再次是唯一的。
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;