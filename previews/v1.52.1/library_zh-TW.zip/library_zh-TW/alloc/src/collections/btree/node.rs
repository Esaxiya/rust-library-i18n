// 這是遵循理想的實現的嘗試
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// 由於 Rust 實際上沒有依賴類型和多態遞歸，因此我們可以避免很多不安全因素。
//

// 該模塊的主要目的是通過將樹視為通用 (如果形狀怪異) 容器來避免複雜性，並避免處理大多數 B-Tree 不變式。
//
// 這樣，該模塊不在乎條目是否已排序，哪些節點可能不足，甚至是不足意味著什麼。但是，我們確實依賴一些不變量:
//
// - 樹木必須具有統一的 depth/height。這意味著從給定節點到葉子的每條路徑都具有完全相同的長度。
// - 長度為 `n` 的節點具有 `n` 鍵，`n` 值和 `n + 1` 邊。
//   這意味著即使一個空節點也至少具有一個 edge。
//   對於葉節點，"having an edge" 僅意味著我們可以標識節點中的位置，因為葉邊緣為空並且不需要數據表示。
// 在內部節點中，edge 既標識位置又包含指向子節點的指針。
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// 葉節點的基礎表示和內部節點的部分錶示。
struct LeafNode<K, V> {
    /// 我們希望在 `K` 和 `V` 中是協變的。
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// 該節點到父節點的 `edges` 數組的索引。
    /// `*node.parent.edges[node.parent_idx]` 應該與 `node` 相同。
    /// 僅當 `parent` 不為 null 時，才保證將其初始化。
    parent_idx: MaybeUninit<u16>,

    /// 此節點存儲的鍵和值的數量。
    len: u16,

    /// 存儲節點實際數據的數組。
    /// 每個數組中只有前 `len` 個元素被初始化並有效。
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// 就地初始化一個新的 `LeafNode`。
    unsafe fn init(this: *mut Self) {
        // 根據一般政策，如果可以的話，我們會保留未初始化的字段，因為這應該在 Valgrind 中更快，更輕鬆地進行跟踪。
        //
        unsafe {
            // parent_idx，鍵和 val 都是 MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// 創建一個新的盒裝 `LeafNode`。
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// 內部節點的基礎表示。與 `LeafNode`s 一樣，它們應該隱藏在 `BoxedNode`s 的後面，以防止丟棄未初始化的鍵和值。
/// 任何指向 `InternalNode` 的指針都可以直接轉換為指向節點的基礎 `LeafNode` 部分的指針，從而使代碼可以一般地作用於葉子節點和內部節點，而不必檢查指針所指向的是哪兩個。
///
/// 通過使用 `repr(C)` 啟用此屬性。
///
#[repr(C)]
// gdb_providers.py 使用此類型名稱進行自省。
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// 指向此節點的子代的指針。
    /// `len + 1` 這些樹中的所有樹被認為是初始化的和有效的，除了在末尾附近，雖然樹是通過借入類型 `Dying` 保留的，但是其中一些指針懸空了。
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// 創建一個新的盒裝 `InternalNode`。
    ///
    /// # Safety
    /// 內部節點的不變性是它們至少具有一個初始化且有效的 edge。
    /// 此功能未設置這樣的 edge。
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // 我們只需要初始化數據即可。邊緣是 MaybeUninit。
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// 指向節點的託管非空指針。這可以是指向 `LeafNode<K, V>` 的擁有的指針，也可以是指向 `InternalNode<K, V>` 的擁有的指針。
///
/// 但是，`BoxedNode` 不包含有關它實際包含的兩種類型的節點中的哪一種的信息，並且部分由於缺少此信息，它不是單獨的類型，也沒有析構函數。
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// 自有樹的根節點。
///
/// 請注意，它沒有析構函數，必須手動清理。
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// 返回一個新的擁有的樹，其樹的根節點最初為空。
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` 不能為零。
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// 相互借用擁有的根節點。
    /// 與 `reborrow_mut` 不同，這是安全的，因為返回值不能用於破壞根，並且不能有其他對樹的引用。
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 稍微可變地借入擁有的根節點。
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 不可逆地過渡到允許遍歷並提供破壞性方法的引用，僅此而已。
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// 添加一個新的內部節點，該節點的單個 edge 指向先前的根節點，使該新節點成為根節點，然後將其返回。
    /// 這會使高度增加 1，與 `pop_internal_level` 相反。
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, 除了我們只是忘記了我們現在是內部人員:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 使用第一個子節點作為新的根節點，刪除內部根節點。
    /// 由於僅在根節點只有一個子節點時才調用它，因此不會對任何鍵，值和其他子節點進行清理。
    ///
    /// 這會將高度降低 1，與 `push_internal_level` 相反。
    ///
    /// 需要對 `Root` 對象的獨占訪問權，而不是對根節點的獨占訪問權;
    /// 它不會使對根節點的其他句柄或引用無效。
    ///
    /// Panics，如果沒有內部級別，即根節點是葉。
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // 安全: 我們斷言是內部的。
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // 安全: 我們僅借用了 `self`，而它的借用類型是互斥的。
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // 安全性: 第一個 edge 總是被初始化。
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. 即使 `BorrowType` 是 `Mut`，`NodeRef` 在 `K` 和 `V` 中也總是協變的。
// 這在技術上是錯誤的，但是由於內部使用 `NodeRef` 不會導致任何安全隱患，因為我們在 `K` 和 `V` 上保持完全通用。
//
// 但是，每當公共類型包裝 `NodeRef` 時，請確保其具有正確的方差。
//
/// 對節點的引用。
///
/// 此類型具有許多控制其行為的參數:
/// - `BorrowType`: 一種虛擬類型，描述借用的類型並帶有生存期。
///    - 當它是 `Immut<'a>` 時，`NodeRef` 的行為大致類似於 `&'a Node`。
///    - 當這是 `ValMut<'a>` 時，就鍵和樹結構而言，`NodeRef` 的行為大致類似於 `&'a Node`，但也允許對樹中的值進行許多可變引用共存。
///    - 當這是 `Mut<'a>` 時，儘管插入方法允許指向值的可變指針共存，但 `NodeRef` 的行為大致類似於 `&'a mut Node`。
///    - 當它是 `Owned` 時，`NodeRef` 的行為大致類似於 `Box<Node>`，但沒有析構函數，必須手動清理。
///    - 當這是 `Dying` 時，`NodeRef` 的行為仍大致類似於 `Box<Node>`，但具有逐點銷毀樹的方法，並且普通方法 (雖然未標記為不安全調用) 可以在調用不正確的情況下調用 UB。
///
///   由於任何 `NodeRef` 都允許在樹中導航，因此 `BorrowType` 有效地應用於整個樹，而不僅僅是節點本身。
/// - `K` 和 `V`: 這是存儲在節點中的鍵和值的類型。
/// - `Type`: 可以是 `Leaf`，`Internal` 或 `LeafOrInternal`。
/// 當這是 `Leaf` 時，`NodeRef` 指向葉節點; 當這是 `Internal` 時，`NodeRef` 指向內部節點; 當這是 `LeafOrInternal` 時，`NodeRef` 可能指向任一類型的節點。
///   `Type` 在 `NodeRef` 以外使用時被命名為 `NodeType`。
///
/// `BorrowType` 和 `NodeType` 都限制了我們實現哪種方法以利用靜態類型安全性。我們應用此類限制的方式存在一些限制:
/// - 對於每個類型參數，我們只能通用地或針對一種特定類型定義一種方法。
/// 例如，我們不能為所有 `BorrowType` 定義一個類似 `into_kv` 的方法，也不能為所有帶有生存期的類型定義一個方法，因為我們希望它返回 `&'a` 引用。
///   因此，我們僅針對功能最弱的 `Immut<'a>` 定義它。
/// - 從 `Mut<'a>` 到 `Immut<'a>`，我們無法獲得隱式強制。
///   因此，我們必須在功能更強大的 `NodeRef` 上顯式調用 `reborrow`，以實現類似於 `into_kv` 的方法。
///
/// `NodeRef` 上所有返回某種引用的方法，或者:
/// - 按值取 `self`，並返回 `BorrowType` 攜帶的壽命。
///   有時，要調用這種方法，我們需要調用 `reborrow_mut`。
/// - 以 `self` 作為參考，(implicitly) 返回該參考的生存期，而不是 `BorrowType` 的生存期。
/// 這樣，借位檢查器保證只要使用返回的引用，`NodeRef` 就會保持借用狀態。
///   支持插入的方法通過返回原始指針 (即沒有任何生存期的引用) 來彎曲該規則。
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// 節點的級別數和葉子的級別分開，`Type` 無法完全描述該節點的常數，並且該節點本身不存儲。
    /// 我們只需要存儲根節點的高度，並從中導出所有其他節點的高度。
    /// 如果 `Type` 為 `Leaf`，則必須為零; 如果 `Type` 為 `Internal`，則必須為非零。
    ///
    ///
    height: usize,
    /// 指向葉或內部節點的指針。
    /// `InternalNode` 的定義可確保該指針有效。
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// 解壓縮打包為 `NodeRef::parent` 的節點引用。
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// 公開內部節點的數據。
    ///
    /// 返回原始 ptr，以避免使對該節點的其他引用無效。
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // 安全: 靜態節點類型為 `Internal`。
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// 借用對內部節點數據的獨占訪問權。
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// 查找節點的長度。這是鍵或值的數量。
    /// 邊數為 `len() + 1`。
    /// 請注意，儘管安全，但調用此函數可能會產生使無效代碼創建的可變引用無效的副作用。
    ///
    pub fn len(&self) -> usize {
        // 重要的是，我們僅在此處訪問 `len` 字段。
        // 如果 BorrowType 為 marker::ValMut，則可能存在對我們不能無效的值的未完成的可變引用。
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// 返回節點和葉子分開的級別數。
    /// 零高度表示節點本身就是葉。
    /// 如果您將樹的根放在頂部，則數字表示該節點出現在哪個海拔高度。
    /// 如果您在樹上畫上有葉子的樹，則數字表示樹在節點上方延伸的高度。
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// 臨時取出對同一節點的另一個不變引用。
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 暴露任何葉或內部節點的葉部分。
    ///
    /// 返回原始 ptr，以避免使對該節點的其他引用無效。
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // 該節點必須至少對 LeafNode 部分有效。
        // 這不是 NodeRef 類型的引用，因為我們不知道它應該是唯一的還是共享的。
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// 查找當前節點的父級。
    /// 如果當前節點實際上有一個父節點，則返回 `Ok(handle)`，其中 `handle` 指向指向當前節點的父節點的 edge。
    ///
    /// 如果當前節點沒有父節點，則返回 `Err(self)`，並返回原始 `NodeRef`。
    ///
    /// 方法名稱假定您在樹的根節點位於頂部。
    ///
    /// `edge.descend().ascend().unwrap()` `node.ascend().unwrap().descend()` 和 `node.ascend().unwrap().descend()` 在成功時都不應執行任何操作。
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // 我們需要使用指向節點的原始指針，因為如果 BorrowType 為 marker::ValMut，則可能存在對我們不能使之無效的值的出色的可變引用。
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// 請注意，`self` 必須為非空。
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// 請注意，`self` 必須為非空。
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// 公開不可變樹中任何葉或內部節點的葉部分。
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // 安全: 借用到 `Immut` 的樹中不能有可變引用。
        unsafe { &*ptr }
    }

    /// 將視圖借入存儲在節點中的鍵中。
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// 與 `ascend` 相似，它獲取對節點父節點的引用，但也會在流程中取消當前節點的分配。
    /// 這是不安全的，因為儘管當前節點已被釋放，但仍將可訪問。
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// 不安全地向編譯器斷言該節點是 `Leaf` 的靜態信息。
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 不安全地向編譯器斷言該節點是 `Internal` 的靜態信息。
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// 臨時取出對同一節點的另一個可變引用。請注意，由於此方法非常危險，因此請加倍注意，因為它可能不會立即看起來很危險。
    ///
    /// 因為可變指針可以在樹的任何位置漫遊，所以返回的指針可以很容易地用於使原始指針懸空，越界或在堆疊借用規則下無效。
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) 考慮向 `NodeRef` 添加另一個類型參數，該參數限制在重新借入的指針上使用導航方法，從而防止這種不安全性。
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 借用對任何葉節點或內部節點的葉部分的獨占訪問權限。
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // 安全: 我們擁有對整個節點的獨占訪問權。
        unsafe { &mut *ptr }
    }

    /// 提供對任何葉節點或內部節點的葉部分的獨占訪問權。
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // 安全: 我們擁有對整個節點的獨占訪問權。
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// 借用對密鑰存儲區元素的獨占訪問權。
    ///
    /// # Safety
    /// `index` 處於 0..CAPACITY 的範圍內
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // 安全: 調用者將無法自行調用其他方法
        // 直到鍵片參考被刪除為止，因為我們在藉閱的整個生命週期中都有唯一的訪問權限。
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// 借用對節點的值存儲區的元素或切片的獨占訪問權。
    ///
    /// # Safety
    /// `index` 處於 0..CAPACITY 的範圍內
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // 安全: 調用者將無法自行調用其他方法
        // 直到價值切片參考被刪除為止，因為我們在藉閱的整個生命週期中都具有唯一的訪問權限。
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// 借用 edge 內容對節點存儲區的元素或切片的獨占訪問權。
    ///
    /// # Safety
    /// `index` 處於 0..CAPACITY +1 的範圍內
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // 安全: 調用者將無法自行調用其他方法
        // 直到刪除 edge 切片引用為止，因為我們在藉閱的整個生命週期中都具有唯一的訪問權限。
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - 該節點具有多個 `idx` 初始化的元素。
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // 我們僅創建對我們感興趣的一個元素的引用，以避免對其他元素的突出引用 (特別是在早期迭代中返回給調用者的那些引用) 的混疊。
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // 由於 Rust 發出 #74679，我們必須強制使用未調整大小的數組指針。
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// 借用對節點長度的獨占訪問權限。
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// 將節點的鏈接設置為其父級 edge，而不會使對該節點的其他引用無效。
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// 清除根節點到其父 edge 的鏈接。
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// 將鍵值對添加到節點的末尾。
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` 返回的每個項目都是該節點的有效 edge 索引。
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// 將一個鍵 - 值對以及一個 edge 添加到該對的右側 (在該節點的末尾)。
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// 檢查節點是 `Internal` 節點還是 `Leaf` 節點。
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// 對節點中特定鍵值對或 edge 的引用。
/// `Node` 參數必須是 `NodeRef`，而 `Type` 可以是 `KV` (表示鍵值對上的句柄) 或 `Edge` (表示 edge 上的句柄)。
///
/// 請注意，即使 `Leaf` 節點也可以具有 `Edge` 句柄。
/// 它們代表鍵 - 值對之間的子指針所處的空間，而不是代表子節點的指針。
/// 例如，在一個長度為 2 的節點中，將存在 3 個可能的 edge 位置，一個在該節點的左側，一個在兩對之間，另一個在該節點的右側。
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// 我們不需要 `#[derive(Clone)]` 的全部通用性，因為 `Node` 是不可變的引用，因此 `Copy` 唯一可以被 `克隆` 的時間。
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// 檢索包含此句柄指向的 edge 或鍵值對的節點。
    pub fn into_node(self) -> Node {
        self.node
    }

    /// 返回此句柄在節點中的位置。
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// 在 `node` 中為鍵值對創建新的句柄。
    /// 不安全，因為调用者必須確保 `idx < node.len()`。
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// 可以是 PartialEq 的公共實現，但僅在此模塊中使用。
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// 暫時在同一位置取出另一個不變的句柄。
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // 我們無法使用 Handle::new_kv 或 Handle::new_edge，因為我們不知道我們的類型
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// 不安全地向編譯器斷言靜態信息，即句柄的節點是 `Leaf`。
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// 暫時在同一位置取出另一個可變的句柄。
    /// 請注意，由於此方法非常危險，因此請加倍注意，因為它可能不會立即看起來很危險。
    ///
    ///
    /// 有關詳細信息，請參見 `NodeRef::reborrow_mut`。
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // 我們無法使用 Handle::new_kv 或 Handle::new_edge，因為我們不知道我們的類型
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// 在 `node` 中為 edge 創建新的句柄。
    /// 不安全，因為调用者必須確保 `idx <= node.len()`。
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// 給定 edge 索引，我們要在其中插入到已滿容量的節點中，計算分割點的明智 KV 索引以及執行插入的位置。
///
/// 拆分點的目標是使其鍵和值最終位於父節點中。
/// 分割點左側的鍵，值和邊成為左子級;
/// 分割點右側的鍵，值和邊成為正確的子代。
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust 問題 #74834 試圖解釋這些對稱規則。
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 在此 edge 左右兩側的鍵值對之間插入新的鍵值對。
    /// 此方法假定節點中有足夠的空間來容納新的配對。
    ///
    /// 返回的指針指向插入的值。
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 在此 edge 左右兩側的鍵值對之間插入新的鍵值對。
    /// 如果沒有足夠的空間，此方法將拆分節點。
    ///
    /// 返回的指針指向插入的值。
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// 修復此 edge 鏈接到的子節點中的父指針和索引。
    /// 當邊的順序已更改時，這很有用，
    fn correct_parent_link(self) {
        // 創建後向指針，而不會使對該節點的其他引用無效。
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// 在此 edge 和此 edge 右側的鍵值對之間插入一個新的鍵值對和一個 edge，它們將位於該新對的右側。
    /// 此方法假定節點中有足夠的空間來容納新的配對。
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// 在此 edge 和此 edge 右側的鍵值對之間插入一個新的鍵值對和一個 edge，它們將位於該新對的右側。
    /// 如果沒有足夠的空間，此方法將拆分節點。
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 在此 edge 左右兩側的鍵值對之間插入新的鍵值對。
    /// 如果沒有足夠的空間，此方法將拆分節點，然後嘗試將拆分的部分遞歸插入父節點，直到到達根為止。
    ///
    ///
    /// 如果返回的結果是 `Fit`，則其句柄的節點可以是此 edge 的節點或祖先。
    /// 如果返回的結果是 `Split`，則 `left` 字段將成為根節點。
    /// 返回的指針指向插入的值。
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// 查找此 edge 指向的節點。
    ///
    /// 方法名稱假定您在樹的根節點位於頂部。
    ///
    /// `edge.descend().ascend().unwrap()` `node.ascend().unwrap().descend()` 和 `node.ascend().unwrap().descend()` 在成功時都不應執行任何操作。
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // 我們需要使用指向節點的原始指針，因為如果 BorrowType 為 marker::ValMut，則可能存在對我們不能使之無效的值的出色的可變引用。
        // 不必擔心訪問 height 字段，因為該值已被複製。
        // 當心，一旦節點指針被取消引用，我們將通過引用訪問 edges 數組 (Rust 發行 #73987)，並使任何其他對數組或數組內部的引用無效 (如果存在)。
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // 我們無法調用單獨的鍵和值方法，因為調用第二個方法會使第一個方法返回的引用無效。
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// 替換 KV 句柄引用的鍵和值。
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// 通過處理葉數據來幫助特定 `NodeType` 的 `split` 的實現。
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// 將基礎節點分為三部分:
    ///
    /// - 節點被截斷為僅包含此句柄左側的鍵 / 值對。
    /// - 提取此句柄指向的鍵和值。
    /// - 該句柄右邊的所有鍵值對都放入一個新分配的節點中。
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// 刪除此句柄指向的鍵值對，並將其與鍵值對折疊到的 edge 一起返回。
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// 將基礎節點分為三部分:
    ///
    /// - 節點被截斷為僅包含此句柄左側的邊和鍵值對。
    /// - 提取此句柄指向的鍵和值。
    /// - 此句柄右側的所有邊和鍵值對均放入新分配的節點中。
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// 代表一個會話，用於圍繞內部鍵值對評估和執行平衡操作。
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// 選擇一個涉及節點作為子節點的平衡上下文，從而在父節點中緊靠左側或右側的 KV 之間進行選擇。
    /// 如果沒有父級，則返回 `Err`。
    /// Panics，如果父級為空。
    ///
    /// 優先選擇左側，如果給定節點某種程度上未滿，則最好是左側，這意味著此處僅是其元素少於其左同級元素，也少於其右同級元素 (如果存在)。
    /// 在這種情況下，與左側同級合併更快，因為我們只需要移動節點的 N 個元素，而不是將它們向右移動並在前面移動超過 N 個元素。
    /// 從左側同級進行竊取通常也更快，因為我們只需要將節點的 N 個元素向右移，而不是將同級元素中的至少 N 個向左移。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// 返回是否可以合併，即，節點中是否有足夠的空間將中央 KV 與兩個相鄰的子節點合併。
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// 執行合併，並讓閉包確定要返回的內容。
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // 安全: 合併節點的高度比高度低一
                // 此 edge 的節點的位置，因此大於零，因此它們是內部的。
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// 將父級的鍵值對以及兩個相鄰的子節點合併到左側的子節點中，並返回縮小的父節點。
    ///
    ///
    /// 除非我們 `.can_merge()`，否則 Panics。
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// 將父級的鍵值對以及兩個相鄰的子節點合併到左側的子節點中，並返回該子節點。
    ///
    ///
    /// 除非我們 `.can_merge()`，否則 Panics。
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// 將父級的鍵值對和兩個相鄰的子節點合併到左側的子節點中，並在跟踪的子 edge 結束的那個子節點中返回 edge 句柄，
    ///
    ///
    /// 除非我們 `.can_merge()`，否則 Panics。
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// 從左側的子項中刪除鍵值對並將其放置在父級的鍵值存儲中，同時將舊的父級鍵值對推入右側的子級中。
    ///
    /// 返回右子 edge 的句柄，該句柄對應於 `track_right_edge_idx` 指定的原始 edge 的終止位置。
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// 從右側的子項中刪除鍵值對，並將其放置在父級的鍵值存儲中，同時將舊的父級鍵值對推入左側的子級。
    ///
    /// 返回 `track_left_edge_idx` 指定的左子級中 edge 的句柄，該句柄沒有移動。
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// 這確實與 `steal_left` 相似，但是會同時竊取多個元素。
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // 確保我們可以安全偷竊。
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // 移動葉數據。
            {
                // 為合適的子节点中的被盜元素騰出空間。
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // 將元素從左子元素移到右子元素。
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // 將最左邊的被盜對移到父對。
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // 將父級的鍵 / 值對移到正確的子級。
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // 為被盜的邊緣騰出空間。
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // 偷邊緣。
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` 的對稱克隆。
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // 確保我們可以安全偷竊。
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // 移動葉數據。
            {
                // 將最右邊的被盜對移到父對。
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // 將父級的鍵 / 值對移到左子級。
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // 將元素從右子元素移到左子元素。
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // 填補以前被盜元素的空白。
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // 偷邊緣。
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // 填補以前被盜邊的空白處。
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// 刪除所有斷言該節點是 `Leaf` 節點的靜態信息。
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// 刪除所有斷言該節點是 `Internal` 節點的靜態信息。
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// 檢查基礎節點是 `Internal` 節點還是 `Leaf` 節點。
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// 將 `self` 之後的後綴從一個節點移動到另一個節點。`right` 必須為空。
    /// `right` 的第一個 edge 保持不變。
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// 插入的結果，當節點需要擴展到超出其容量時。
pub struct SplitResult<'a, K, V, NodeType> {
    // 現有樹中具有屬於 `kv` 左側的元素和邊的已更改節點。
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // 拆分了一些鍵和值，將其插入其他位置。
    pub kv: (K, V),
    // 擁有的，未連接的，具有屬於 `kv` 右側的元素和邊的新節點。
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // 此借用類型的節點引用是否允許遍歷到樹中的其他節點。
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // 不需要遍歷，它使用 `borrow_mut` 的結果發生。
        // 通過禁用遍歷，並且僅創建對根的新引用，我們知道 `Owned` 類型的每個引用都是對根節點的引用。
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// 將值插入到初始化元素的切片中，然後是一個未初始化的元素。
///
/// # Safety
/// 切片具有多個 `idx` 元素。
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// 從所有初始化的元素的切片中刪除並返回一個值，而留下一個尾隨的未初始化的元素。
///
///
/// # Safety
/// 切片具有多個 `idx` 元素。
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// 將切片 `distance` 位置中的元素向左移動。
///
/// # Safety
/// 切片至少包含 `distance` 個元素。
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// 將切片 `distance` 位置中的元素向右移動。
///
/// # Safety
/// 切片至少包含 `distance` 個元素。
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// 將所有值從一片初始化的元素移動到一片未初始化的元素，將 `src` 保留為所有未初始化。
///
/// 像 `dst.copy_from_slice(src)` 一樣工作，但不需要 `T` 為 `Copy`。
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;