/// 創建一個包含參數的 [`Vec`]。
///
/// `vec!` 允許使用與數組表達式相同的語法來定義 `Vec`。
/// 此宏有兩種形式:
///
/// - 創建一個包含給定元素列表的 [`Vec`]:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - 根據給定的元素和大小創建 [`Vec`]:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// 請注意，與數組表達式不同，此語法支持實現 [`Clone`] 的所有元素，並且元素的數量不必為常數。
///
/// 這將使用 `clone` 複製表達式，因此在具有非標準 `Clone` 實現的類型上使用此表達式時應格外小心。
/// 例如，`vec![Rc::new(1); 5]` 會創建一個 vector，該 vector 包含五個引用同一裝箱整數值的引用，而不是五個引用獨立裝箱整數的引用。
///
///
/// 另外，請注意，允許使用 `vec![expr; 0]`，並產生一個空的 vector。
/// 但是，這仍將評估 `expr`，並立即降低結果值，因此請注意副作用。
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): 對於 cfg(test)，此宏定義所需的固有 `[T]::into_vec` 方法不可用。
// 而是使用僅 cfg(test) NB 可用的 `slice::into_vec` 功能，有關更多信息，請參見 slice.rs 中的 slice::hack 模塊。
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// 使用運行時表達式的插值創建 `String`。
///
/// `format!` 收到的第一個參數是格式字符串。這必須是字符串文字。格式字符串的作用是包含在 {{} 中。
///
/// 除非使用命名或位置參數，否則傳遞給 `format!` 的其他參數將以給定的順序替換格式字符串中的 {}。有關更多信息，請參見 [`std::fmt`]。
///
///
/// `format!` 的常見用法是字符串的連接和內插。
/// [`print!`] 和 [`write!`] 宏使用相同的約定，具體取決於字符串的預期目標。
///
/// 要將單個值轉換為字符串，請使用 [`to_string`] 方法。這將使用 [`Display`] 格式的 trait。
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics (如果格式化 trait 實現返回錯誤)。
/// 這表明實施不正確，因為 `fmt::Write for String` 本身從不返回錯誤。
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// 強制 AST 節點使用表達式以改善模式位置的診斷。
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}