use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // 編寫第三方分配器和 `RawVec` 之間的集成測試有點棘手，因為 `RawVec` API 不會公開容易出錯的分配方法，因此我們無法檢查分配器用盡時會發生什麼 (除了檢測到 panic 之外)。
    //
    //
    // 相反，這僅檢查 `RawVec` 方法在保留存儲空間時是否至少通過了 Allocator API。
    //
    //
    //
    //
    //

    // 一個愚蠢的分配器，在分配嘗試開始失敗之前消耗固定量的燃料。
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (導致重新分配，因此使用 50 + 150=200 單位燃料)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // 首先，`reserve` 像 `reserve_exact` 一樣進行分配。
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 大於 7 的兩倍，因此 `reserve` 應該像 `reserve_exact` 一樣工作。
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 小於 12 的一半，因此 `reserve` 必須成倍增長。
        // 在撰寫本文時，該測試的增長因子為 2，因此新容量為 24，但是，1.5 的增長因子也可以。
        //
        // 因此，`>= 18` 處於斷言狀態。
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}