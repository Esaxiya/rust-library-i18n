//! 一個 UTF-8 編碼的可增長字符串。
//!
//! 該模塊包含 [`String`] 類型，用於轉換為字符串的 [`ToString`] trait 以及使用 [`String`] 可能導致的幾種錯誤類型。
//!
//!
//! # Examples
//!
//! 有多種方法可以從字符串文字中創建新的 [`String`]:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! 您可以通過與現有的 [`String`] 串聯來創建一個新的 [`String`]。
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! 如果您有一個有效的 UTF-8 字節的 vector，則可以用它製成 [`String`]。您也可以做相反的事情。
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // 我們知道這些字節是有效的，因此我們將使用 `unwrap()`。
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// 一個 UTF-8 編碼的可增長字符串。
///
/// `String` 類型是對字符串內容擁有所有權的最常見的字符串類型。它與其借來的對等體 [`str`] 有著密切的關係。
///
/// # Examples
///
/// 您可以使用 [`String::from`] 從 [a literal string][`str`] 創建 `String`:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// 您可以使用 [`push`] 方法將 [`char`] 附加到 `String`，並使用 [`push_str`] 方法將 [`&str`] 附加:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// 如果具有 UTF-8 字節的 vector，則可以使用 [`from_utf8`] 方法從中創建一個 `String`:
///
/// ```
/// // vector 中的一些字節
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // 我們知道這些字節是有效的，因此我們將使用 `unwrap()`。
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String` 始終是有效的 UTF-8。這有一些含義，首先是如果您需要非 UTF-8 字符串，請考慮使用 [`OsString`]。它是相似的，但是沒有 UTF-8 約束。第二個含義是您不能索引到 `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// 索引旨在進行恆定時間操作，但是 UTF-8 編碼不允許我們執行此操作。此外，尚不清楚索引應返回哪種類型: 字節，代碼點或字素簇。
/// [`bytes`] 和 [`chars`] 方法分別返回前兩個迭代器。
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s 實現 [`Deref`]`<Target=str>，因此繼承了 [str 的所有方法。另外，這意味著您可以使用與號 (`&`) 將 `String` 傳遞給採用 [`&str`] 的函數:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// 這將從 `String` 創建 [`&str`] 並將其傳遞。此轉換非常便宜，因此通常，函數會接受 [`＆str`] 作為參數，除非出於某些特定原因它們需要 `String`。
///
/// 在某些情況下，Rust 沒有足夠的信息來進行此轉換，稱為 [`Deref`] 強制。在下面的示例中，字符串片 [`&'a str`][`&str`] 實現了 trait `TraitExample`，而函數 `example_func` 則採用了實現 trait 的任何東西。
/// 在這種情況下，Rust 將需要進行兩次隱式轉換，而 Rust 沒有辦法進行轉換。
/// 因此，以下示例將無法編譯。
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// 有兩種選擇可以代替。第一種方法是使用方法 [`as_str()`] 顯式提取包含字符串的字符串切片，從而將 `example_func(&example_string);` 行更改為 `example_func(example_string.as_str());`。
/// 第二種方法將 `example_func(&example_string);` 更改為 `example_func(&*example_string);`。
/// 在這種情況下，我們先將 `String` 引用到 [`str`][`&str`]，然後再將 [`str`][`&str`] 引用回到 [`&str`]。
/// 第二種方法更慣用，但是兩種方法都可以顯式地進行轉換，而不是依賴於隱式轉換。
///
/// # Representation
///
/// `String` 由三個部分組成: 指向某些字節的指針，長度和容量。指針指向 `String` 用於存儲其數據的內部緩衝區。長度是當前存儲在緩衝區中的字節數，容量是緩衝區的大小 (以字節為單位)。
///
/// 這樣，長度將始終小於或等於容量。
///
/// 此緩衝區始終存儲在堆中。
///
/// 您可以使用 [`as_ptr`]，[`len`] 和 [`capacity`] 方法查看它們:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME 在 vec_into_raw_parts 穩定後更新此文件。
/// // 防止自動刪除字符串的數據
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // 故事有十九個字節
/// assert_eq!(19, len);
///
/// // 我們可以根據 ptr，len 和容量重新構建一個 String。
/// // 這都是不安全的，因為我們有責任確保組件有效:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// 如果 `String` 具有足夠的容量，則向其添加元素將不會重新分配。例如，考慮以下程序:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// 這將輸出以下內容:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// 最初，我們根本沒有分配任何內存，但是當我們追加到字符串後，它會適當地增加其容量。如果我們改為使用 [`with_capacity`] 方法來初始分配正確的容量，請執行以下操作:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// 我們最終得到了不同的輸出:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// 在這裡，不需要在循環內分配更多的內存。
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// 從 UTF-8 字節 vector 轉換 `String` 時可能的錯誤值。
///
/// 該類型是 [`String`] 上 [`from_utf8`] 方法的錯誤類型。
/// 它的設計方式旨在避免重新分配: [`into_bytes`] 方法將返迴轉換嘗試中使用的字節 vector。
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] 提供的 [`Utf8Error`] 類型表示將 [u8] 的片段轉換為 [`&str`] 時可能發生的錯誤。
/// 從這個意義上講，它是 `FromUtf8Error` 的類似物，您可以通過 [`utf8_error`] 方法從 `FromUtf8Error` 獲得一個。
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// // vector 中的一些無效字節
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// 從 UTF-16 字節片轉換 `String` 時可能的錯誤值。
///
/// 該類型是 [`String`] 上 [`from_utf16`] 方法的錯誤類型。
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// 基本用法:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// 創建一個新的空 `String`。
    ///
    /// 由於 `String` 為空，因此不會分配任何初始緩衝區。雖然這意味著該初始操作非常便宜，但在以後添加數據時可能會導致過多的分配。
    ///
    /// 如果您對 `String` 可以容納多少數據有所了解，請考慮使用 [`with_capacity`] 方法來防止過多的重新分配。
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// 創建一個具有特定容量的新的空 `String`。
    ///
    /// `String` 有一個內部緩衝區來保存其數據。
    /// 容量是該緩衝區的長度，可以使用 [`capacity`] 方法查詢。
    /// 此方法將創建一個空的 `String`，但是它帶有一個初始緩衝區，該緩衝區可以容納 `capacity` 字節。
    /// 當您可能將大量數據附加到 `String` 時，這很有用，從而減少了它需要進行的重新分配數量。
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// 如果給定的容量為 `0`，則不會進行分配，並且此方法與 [`new`] 方法相同。
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // 字符串不包含任何字符，即使它可以容納更多字符
    /// assert_eq!(s.len(), 0);
    ///
    /// // 這些都無需重新分配即可完成...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... 但這可能會使字符串重新分配
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): 對於 cfg(test)，此方法定義所需的固有 `[T]::to_vec` 方法不可用。
    // 由於我們不需要此方法進行測試，因此我將其存根 NB 請參見 slice.rs 中的 slice::hack 模塊以獲取更多信息。
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// 將字節的 vector 轉換為 `String`。
    ///
    /// 字符串 ([`String`]) 由字節 ([`u8`]) 組成，字節 ([`Vec<u8>`]) 的 vector 由字節組成，因此此函數在兩者之間進行轉換。
    /// 並非所有字節片都是有效的 `String`，但是: `String` 要求它是有效的 UTF-8。
    /// `from_utf8()` 檢查以確保字節有效 UTF-8，然後進行轉換。
    ///
    /// 如果您確定字節片是有效的 UTF-8，並且不想招致有效性檢查的開銷，則此功能有一個不安全的版本 [`from_utf8_unchecked`]，它具有相同的行為，但是會跳過該檢查。
    ///
    ///
    /// 為了提高效率，此方法將注意不要復制 vector。
    ///
    /// 如果需要 [`&str`] 而不是 `String`，請考慮使用 [`str::from_utf8`]。
    ///
    /// 此方法的倒數是 [`into_bytes`]。
    ///
    /// # Errors
    ///
    /// 如果切片不是 UTF-8，則返回 [`Err`]，並說明為什麼提供的字節不是 UTF-8。還包括您移入的 vector。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // vector 中的一些字節
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // 我們知道這些字節是有效的，因此我們將使用 `unwrap()`。
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// 字節不正確:
    ///
    /// ```
    /// // vector 中的一些無效字節
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// 請參閱 [`FromUtf8Error`] 文檔，以獲取有關此錯誤的更多詳細信息。
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// 將字節的一部分轉換為字符串，包括無效字符。
    ///
    /// 字符串由字節 ([`u8`]) 組成，字節片 ([`&[u8]`][byteslice]) 由字節組成，因此此函數在兩者之間進行轉換。並非所有的字節片都是有效的字符串，但是: 字符串必須是有效的 UTF-8。
    /// 在此轉換過程中，`from_utf8_lossy()` 會將所有無效的 UTF-8 序列替換為 [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]，如下所示:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// 如果您確定字節片是有效的 UTF-8，並且不想增加轉換的開銷，則此函數存在一個不安全的版本 [`from_utf8_unchecked`]，它具有相同的行為，但是會跳過檢查。
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// 該函數返回一個 [`Cow<'a, str>`]。如果我們的字節片無效 UTF-8，那麼我們需要插入替換字符，這將改變字符串的大小，因此需要 `String`。
    /// 但是，如果它已經是有效的 UTF-8，則不需要新的分配。
    /// 這種返回類型使我們能夠處理兩種情況。
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // vector 中的一些字節
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// 字節不正確:
    ///
    /// ```
    /// // 一些無效的字節
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// 將 UTF-16 編碼的 vector `v` 解碼為 `String`，如果 `v` 包含任何無效數據，則返回 [`Err`]。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // 這不是通過 collect: : 完成的: <Result<_, _>> () 出於性能原因。
        // FIXME: 關閉 #48994 時，可以再次簡化該功能。
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// 將 UTF-16 編碼的切片 `v` 解碼為 `String`，將無效數據替換為 [the replacement character (`U+FFFD`)][U+FFFD]。
    ///
    /// 與 [`from_utf8_lossy`] 返回 [`Cow<'a, str>`] 不同，`from_utf16_lossy` 返回 `String`，因為 UTF-16 到 UTF-8 的轉換需要分配內存。
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// 將 `String` 分解為其原始組件。
    ///
    /// 返回指向基礎數據的原始指針，字符串的長度 (以字節為單位) 和數據的已分配容量 (以字節為單位)。
    /// 這些參數與 [`from_raw_parts`] 的參數順序相同。
    ///
    /// 調用此函數後，調用者將負責先前由 `String` 管理的內存。
    /// 唯一的方法是使用 [`from_raw_parts`] 函數將原始指針，長度和容量轉換回 `String`，從而允許析構函數執行清除操作。
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// 根據長度，容量和指針創建一個新的 `String`。
    ///
    /// # Safety
    ///
    /// 由於未檢查的不變量數量，這是非常不安全的:
    ///
    /// * `buf` 處的內存必須事先由標準庫使用的同一分配器分配，且所需的對齊方式正好為 1。
    /// * `length` 必須小於或等於 `capacity`。
    /// * `capacity` 必須是正確的值。
    /// * `buf` 的前 `length` 字節必須為有效的 UTF-8。
    ///
    /// 違反這些規則可能會導致諸如破壞分配器的內部數據結構之類的問題。
    ///
    /// `buf` 的所有權有效地轉移到 `String`，然後 `String` 可以隨意取消分配，重新分配或更改指針所指向的內存的內容。
    /// 調用此函數後，請確保沒有其他東西使用指針。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME 在 vec_into_raw_parts 穩定後更新此文件。
    ///     // 防止自動刪除字符串的數據
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// 將字節的 vector 轉換為 `String`，而無需檢查字符串是否包含有效的 UTF-8。
    ///
    /// 有關更多詳細信息，請參見安全版本 [`from_utf8`]。
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// 此功能不安全，因為它不檢查傳遞給它的字節是否為有效的 UTF-8。
    /// 如果違反了此約束，則 `String` 的 future 用戶可能會導致內存不安全問題，因為標準庫的其餘部分都假定 `String` 是有效的 UTF-8。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // vector 中的一些字節
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// 將 `String` 轉換為字節 vector。
    ///
    /// 這會消耗 `String`，因此我們不需要復制其內容。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// 提取包含整個 `String` 的字符串切片。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// 將 `String` 轉換為可變的字符串切片。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// 將給定的字符串切片附加到此 `String` 的末尾。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// 返回此 String 的容量 (以字節為單位)。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// 確保此 `字符串` 的容量至少比其長度大 `additional` 字節。
    ///
    /// 如果選擇，容量可能會增加 `additional` 字節以上，以防止頻繁重新分配。
    ///
    ///
    /// 如果您不希望這種 "at least" 行為，請參見 [`reserve_exact`] 方法。
    ///
    /// # Panics
    ///
    /// 如果新容量溢出 [`usize`]，則為 Panics。
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// 這實際上可能不會增加容量:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s 現在的長度為 2，容量為 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // 由於我們已經有 8 個額外的容量，因此稱之為...
    /// s.reserve(8);
    ///
    /// // ... 實際上並沒有增加。
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// 確保此 `字符串` 的容量比其長度大 `additional` 字節。
    ///
    /// 除非您絕對比分配器更了解，否則請考慮使用 [`reserve`] 方法。
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// 如果新容量溢出 `usize`，則為 Panics。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// 這實際上可能不會增加容量:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s 現在的長度為 2，容量為 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // 由於我們已經有 8 個額外的容量，因此稱之為...
    /// s.reserve_exact(8);
    ///
    /// // ... 實際上並沒有增加。
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// 嘗試為給 `String` 至少插入 `additional` 個元素保留容量。
    /// 該集合可以保留更多空間，以避免頻繁的重新分配。
    /// 調用 `reserve` 後，容量將大於或等於 `self.len() + additional`。
    /// 如果容量已經足夠，則不執行任何操作。
    ///
    /// # Errors
    ///
    /// 如果容量溢出，或者分配器報告失敗，則返回錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // 預先保留內存，如果不能，則退出
    ///     output.try_reserve(data.len())?;
    ///
    ///     // 現在我們知道在我們複雜的工作中這不能 OOM
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// 嘗試保留最小容量，以便在給定的 `String` 中精確插入 `additional` 個元素。
    ///
    /// 調用 `reserve_exact` 後，容量將大於或等於 `self.len() + additional`。
    /// 如果容量已經足夠，則不執行任何操作。
    ///
    /// 請注意，分配器可能會給集合提供比其請求更多的空間。
    /// 因此，不能依靠容量來精確地最小化。
    /// 如果希望插入 future，則最好使用 `reserve`。
    ///
    /// # Errors
    ///
    /// 如果容量溢出，或者分配器報告失敗，則返回錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // 預先保留內存，如果不能，則退出
    ///     output.try_reserve(data.len())?;
    ///
    ///     // 現在我們知道在我們複雜的工作中這不能 OOM
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// 縮小此 `String` 的容量以使其長度匹配。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// 降低 `String` 的容量。
    ///
    /// 容量將至少保持與長度和提供的值一樣大。
    ///
    ///
    /// 如果當前容量小於下限，則為無操作。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// 將給定的 [`char`] 追加到該 `String` 的末尾。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// 返回此 String 內容的字節片。
    ///
    /// 此方法的倒數是 [`from_utf8`]。
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// 將此 `String` 縮短為指定的長度。
    ///
    /// 如果 `new_len` 大於字符串的當前長度，則無效。
    ///
    ///
    /// 請注意，此方法對字符串的分配容量沒有影響
    ///
    /// # Panics
    ///
    /// 如果 `new_len` 不位於 [`char`] 邊界上，則為 Panics。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// 從字符串緩衝區中刪除最後一個字符並返回它。
    ///
    /// 如果 `String` 為空，則返回 [`None`]。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// 從該 `String` 的字節位置刪除 [`char`] 並將其返回。
    ///
    /// 這是 *O*(*n*) 操作，因為它需要復制緩衝區中的每個元素。
    ///
    /// # Panics
    ///
    /// 如果 `idx` 大於或等於 `String` 的長度，或者它不在 [`char`] 邊界上，則為 Panics。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// 刪除 `String` 中所有模式 `pat` 的匹配項。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// 匹配項將被檢測並迭代刪除，因此在樣式重疊的情況下，僅第一個樣式將被刪除:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // 安全: 開始和結束將在每個 utf8 字節邊界上
        // 搜索者文檔
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// 僅保留謂詞指定的字符。
    ///
    /// 換句話說，刪除所有字符 `c`，以使 `f(c)` 返回 `false`。
    /// 此方法在原地運行，以原始順序恰好一次訪問每個字符，並保留保留字符的順序。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// 確切的順序對於跟踪外部狀態 (例如索引) 可能很有用。
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // 將 idx 指向下一個字符
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// 在此 `String` 的字節位置插入一個字符。
    ///
    /// 這是 *O*(*n*) 操作，因為它需要復制緩衝區中的每個元素。
    ///
    /// # Panics
    ///
    /// 如果 `idx` 大於 `String` 的長度，或者它不在 [`char`] 邊界上，則為 Panics。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// 在此 `String` 的字節位置處插入一個字符串切片。
    ///
    /// 這是 *O*(*n*) 操作，因為它需要復制緩衝區中的每個元素。
    ///
    /// # Panics
    ///
    /// 如果 `idx` 大於 `String` 的長度，或者它不在 [`char`] 邊界上，則為 Panics。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// 返回對此 `String` 內容的可變引用。
    ///
    /// # Safety
    ///
    /// 此功能不安全，因為它不檢查傳遞給它的字節是否為有效的 UTF-8。
    /// 如果違反了此約束，則 `String` 的 future 用戶可能會導致內存不安全問題，因為標準庫的其餘部分都假定 `String` 是有效的 UTF-8。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// 返回此 `String` 的長度，以字節為單位，而不是 [`char`] s 或字素。
    /// 換句話說，可能不是人們認為弦的長度。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// 如果此 `String` 的長度為零，則返回 `true`，否則返回 `false`。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 在給定的字節索引處將字符串拆分為兩個。
    ///
    /// 返回新分配的 `String`。
    /// `self` 包含字節 `[0, at)`，返回的 `String` 包含字節 `[at, len)`。
    /// `at` 必須在 UTF-8 代碼點的邊界上。
    ///
    /// 請注意，`self` 的容量不會改變。
    ///
    /// # Panics
    ///
    /// Panics，如果 `at` 不在 `UTF-8` 代碼點邊界上，或者超出字符串的最後一個代碼點。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// 截斷此 `String`，刪除所有內容。
    ///
    /// 儘管這意味著 `String` 的長度為零，但它沒有觸及其容量。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// 創建一個排水迭代器，該迭代器將刪除 `String` 中的指定範圍並產生已刪除的 `chars`。
    ///
    ///
    /// Note: 即使直到最後都沒有使用迭代器，元素範圍也會被刪除。
    ///
    /// # Panics
    ///
    /// Panics，如果起點或終點不在 [`char`] 邊界上，或者它們超出範圍。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // 刪除範圍直到字符串中的 β
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // 全範圍清除弦
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // 記憶安全
        //
        // Drain 的字符串版本沒有 vector 版本的內存安全問題。
        // 數據只是純字節。
        // 因為範圍刪除發生在 Drop 中，所以如果 Drain 迭代器洩漏，則不會發生刪除。
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // 同時藉兩筆。
        // 在 Drop 中，直到迭代結束，才可以訪問 &mut 字符串。
        let self_ptr = self as *mut _;
        // 安全: `slice::range` 和 `is_char_boundary` 進行適當的邊界檢查。
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// 刪除字符串中的指定範圍，並將其替換為給定的字符串。
    /// 給定的字符串不必與範圍相同。
    ///
    /// # Panics
    ///
    /// Panics，如果起點或終點不在 [`char`] 邊界上，或者它們超出範圍。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // 替換範圍直到字符串中的 β
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // 記憶安全
        //
        // Replace_range 沒有 vector Splice 的內存安全問題。
        // vector 版本的版本。數據只是純字節。

        // 警告: 內聯此變量將是不正確的 (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // 警告: 內聯此變量將是不正確的 (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // 再次使用 `range` 是不正確的 (#81138) 我們假設 `range` 所報告的界限保持不變，但是在兩次通話之間可能會發生對抗性實現
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// 將此 `String` 轉換為 [`Box`]`<`[`str`]`>`。
    ///
    /// 這將減少任何多餘的容量。
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// 返回試圖轉換為 `String` 的 [u8] s 個字節的一部分。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // vector 中的一些無效字節
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// 返回嘗試轉換為 `String` 的字節。
    ///
    /// 精心構造此方法以避免分配。
    /// 它將消耗錯誤，將字節移出，因此不需要製作字節的副本。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // vector 中的一些無效字節
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// 提取 `Utf8Error` 以獲取有關轉換失敗的更多詳細信息。
    ///
    /// [`std::str`] 提供的 [`Utf8Error`] 類型表示將 [u8] 的片段轉換為 [`&str`] 時可能發生的錯誤。
    /// 從這個意義上講，它類似於 `FromUtf8Error`。
    /// 有關使用它的更多詳細信息，請參見其文檔。
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // vector 中的一些無效字節
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // 第一個字節在這裡無效
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // 因為我們要在 `String` 上進行迭代，所以可以通過從迭代器獲取第一個字符串並將所有後續字符串附加到其上來避免至少一次分配。
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // 因為我們要遍歷 CoW，所以 (potentially) 可以通過獲取第一項並將所有後續項附加到其上來避免至少一次分配。
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// 一個方便的 impl，委派給 `&str` 的 impl。
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// 創建一個空的 `String`。
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// 實現 `+` 運算符以連接兩個字符串。
///
/// 這會消耗左側的 `String`，並重新使用其緩衝區 (如有必要，請增加緩衝區)。
/// 這樣做是為了避免分配新的 `String` 並在每個操作上複製整個內容，當通過重複連接構建 *n* 字節的字符串時，這將導致 *O*(*n*^ 2) 運行時間。
///
///
/// 右側的字符串僅是藉用的。它的內容被複製到返回的 `String` 中。
///
/// # Examples
///
/// 將兩個 `String` 連接起來，第一個按值取值，第二個取值:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` 已移動，無法在此處使用。
/// ```
///
/// 如果要繼續使用第一個 `String`，則可以對其進行克隆並追加到克隆中:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` 在這裡仍然有效。
/// ```
///
/// 可以通過將第一個切片轉換為 `String` 來完成 `&str` 切片的連接:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// 實現用於附加到 `String` 的 `+=` 運算符。
///
/// 這與 [`push_str`][String::push_str] 方法具有相同的行為。
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] 的類型別名。
///
/// 存在此別名是為了向後兼容，並且最終可能會棄用該別名。
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait，用於將值轉換為 `String`。
///
/// 對於任何實現 [`Display`] trait 的類型，都會自動實現 trait。
/// 因此，不應直接實現 `ToString`:
/// [`Display`] 應該改為實施，您可以免費獲得 `ToString` 實施。
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// 將給定值轉換為 `String`。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// 在此實現中，如果 `Display` 實現返回錯誤，則 `to_string` 方法 panics。
/// 這表示 `Display` 實施不正確，因為 `fmt::Write for String` 本身從不返回錯誤。
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // 常見的準則是不內聯通用函數。
    // 但是，從此方法中刪除 `#[inline]` 會導致不可忽略的回歸。
    // 請參閱 <https://github.com/rust-lang/rust/pull/74852>，這是嘗試將其刪除的最後一次嘗試。
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// 將 `&mut str` 轉換為 `String`。
    ///
    /// 結果分配在堆上。
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: 測試引入 libstd，這會導致錯誤
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// 將給定的盒裝 `str` 切片轉換為 `String`。
    /// 值得注意的是，`str` slice 被擁有。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// 將給定的 `String` 轉換為擁有的盒裝 `str` 切片。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// 將字符串切片轉換為藉用的變體。
    /// 不執行堆分配，並且不復製字符串。
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// 將字符串轉換為擁有的變體。
    /// 不執行堆分配，並且不復製字符串。
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// 將 String 引用轉換為 Borrowed 變體。
    /// 不執行堆分配，並且不復製字符串。
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// 將給定的 `String` 轉換為保存 `u8` 類型的值的 vector `Vec`。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` 的排水迭代器。
///
/// 該結構是通過 [`String`] 上的 [`drain`] 方法創建的。
/// 有關更多信息，請參見其文檔。
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// 將在析構函數中用作＆'a mut String
    string: *mut String,
    /// 零件開始刪除
    start: usize,
    /// 零件末端去除
    end: usize,
    /// 當前剩餘範圍要刪除
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // 使用 Vec::drain。
            // "Reaffirm" 邊界檢查以避免再次插入 panic 代碼。
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// 返回此迭代器的其餘 (子) 字符串作為切片。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: 取消註釋穩定時，AsRef 表示如下。
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// 穩定 `string_drain_as_str` 時不加註釋。
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str> 對於 Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// Drain <'a> 的 impl <'a> AsRef <[u8]> {fn as_ref(&self)->＆[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}