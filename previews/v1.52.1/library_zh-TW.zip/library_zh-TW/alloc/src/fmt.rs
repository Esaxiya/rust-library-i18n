//! 用於格式化和打印 `String`s 的實用程序。
//!
//! 該模塊包含對 [`format!`] 語法擴展的運行時支持。
//! 該宏在編譯器中實現，以發出對該模塊的調用，以便在運行時將參數格式化為字符串。
//!
//! # Usage
//!
//! C 的 `printf`/`fprintf` 函數或 Python 的 `str.format` 函數使 [`format!`] 宏熟悉。
//!
//! [`format!`] 擴展的一些示例是:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" 前導零
//! ```
//!
//! 從這些中，您可以看到第一個參數是格式字符串。編譯器要求它是字符串文字。它不能是傳入的變量 (以執行有效性檢查)。
//! 然後，編譯器將解析格式字符串，並確定所提供的參數列表是否適合傳遞給該格式字符串。
//!
//! 要將單個值轉換為字符串，請使用 [`to_string`] 方法。這將使用 [`Display`] 格式的 trait。
//!
//! ## 位置參數
//!
//! 允許每個格式化參數指定其引用的值參數，如果省略，則假定為 "the next argument"。
//! 例如，格式字符串 `{} {} {}` 將帶有三個參數，並且將按照給定的順序對其進行格式化。
//! 但是，格式字符串 `{2} {1} {0}` 將以相反的順序設置參數格式。
//!
//! 一旦開始將兩種類型的位置說明符混合在一起，事情就會變得有些棘手。可以將 "next argument" 說明符視為參數的迭代器。
//! 每次看到 "next argument" 說明符時，迭代器都會前進。這導致這樣的行為:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! 在看到第一個 `{}` 時，尚未對參數進行內部迭代，因此它將打印第一個參數。然後，在到達第二個 `{}` 時，迭代器已前進到第二個參數。
//! 本質上，以位置說明符的形式顯式命名其參數的參數不會影響未命名參數的參數。
//!
//! 格式字符串是使用其所有參數所必需的，否則是編譯時錯誤。您可能在格式字符串中多次引用同一個參數。
//!
//! ## 命名參數
//!
//! Rust 本身不具有類似於 Python 的等效於函數的命名參數，但是 [`format!`] 宏是一種語法擴展，允許它利用命名參數。
//! 命名參數列在參數列表的末尾，並具有以下語法:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! 例如，以下 [`format!`] 表達式都使用命名參數:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! 將位置參數 (沒有名稱的參數) 放在具有名稱的參數之後是無效的。與位置參數一樣，提供格式字符串未使用的命名參數也是無效的。
//!
//! # 格式化參數
//!
//! 每個要格式化的參數都可以通過許多格式化參數進行轉換 (對應於 [the syntax](#syntax)) 中的 `format_spec`。這些參數會影響所格式化內容的字符串表示形式。
//!
//! ## Width
//!
//! ```
//! // 所有這些打印 "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! 這是格式應使用的 "minimum width" 的參數。
//! 如果值的字符串不能填滿這麼多字符，則 fill/alignment 指定的填充將用於佔用所需的空間 (請參見下文)。
//!
//! 通過添加後綴 `$` (表示第二個參數是指定寬度的 [`usize`])，也可以在參數列表中以 [`usize`] 的形式提供寬度值。
//!
//! 用美元語法引用參數不會影響 "next argument" 計數器，因此按位置引用參數或使用命名參數通常是一個好主意。
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! 可選的填充字符和對齊方式通常與 [`width`](#width) 參數一起提供。必須在 `width` 之前，`:` 之後定義。
//! 這表示如果要格式化的值小於 `width`，則將在其周圍打印一些額外的字符。
//! 填充具有以下針對不同對齊方式的變體:
//!
//! * `[fill]<` - 參數在 `width` 列中左對齊
//! * `[fill]^` - 參數在 `width` 列中居中對齊
//! * `[fill]>` - 該參數在 `width` 列中右對齊
//!
//! 非數字的默認 [fill/alignment](#fillalignment) 是空格，並且左對齊。數字格式器的默認值也是空格字符，但帶有右對齊。
//! 如果為數字指定了 `0` 標誌 (見下文)，則隱式填充字符為 `0`。
//!
//! 請注意，某些類型可能無法實現對齊。特別是，對於 `Debug` trait，通常不會實現該功能。
//! 確保應用填充的一種好方法是格式化輸入，然後填充此結果字符串以獲得輸出:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => `你好 Some("hi")! `
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! 這些都是更改格式化程序行為的標誌。
//!
//! * `+` - 這適用於數字類型，並指示應始終打印符號。默認情況下，從不打印正號，對於 `Signed` trait，默認情況下僅打印負號。
//! 該標誌指示應始終打印正確的符號 (`+` 或 `-`)。
//! * `-` - 目前未使用
//! * `#` - 該標誌指示應使用 "alternate" 打印形式。替代形式為:
//!     * `#?` - 漂亮打印 [`Debug`] 格式
//!     * `#x` - `0x` 在參數之前
//!     * `#X` - `0x` 在參數之前
//!     * `#b` - `0b` 在參數之前
//!     * `#o` - `0o` 在參數之前
//! * `0` - 這用於指示整數格式，到 `width` 的填充都應使用 `0` 字符完成，並且應注意符號。
//! 像 `{:08}` 這樣的格式將為整數 `1` 產生 `00000001`，而相同格式將為整數 `-1` 產生 `-0000001`。
//! 請注意，負版本的零比正版本少一。
//!         請注意，填充零總是放在符號 (如果有) 之後和數字之前。當與 `#` 標誌一起使用時，將應用類似的規則: 將填充零插入在前綴之後但在數字之前。
//!         前綴包括在總寬度中。
//!
//! ## Precision
//!
//! 對於非數字類型，可以將其視為 "maximum width"。
//! 如果結果字符串長於該寬度，則將其截斷為這麼多字符，並且如果設置了這些參數，則將使用適當的 `fill`，`alignment` 和 `width` 發出該截斷的值。
//!
//! 對於整數類型，這將被忽略。
//!
//! 對於浮點類型，這指示小數點後應打印多少位。
//!
//! 有三種可能的方法來指定所需的 `precision`:
//!
//! 1. 整數 `.N`:
//!
//!    整數 `N` 本身就是精度。
//!
//! 2. 整數或名稱後跟美元符號 `.N$`:
//!
//!    使用格式 *argument*`N` (必須為 `usize`) 作為精度。
//!
//! 3. 星號 `.*`:
//!
//!    `.*` 表示此 `{...}` 與 *兩個* 格式輸入相關聯，而不是與一個輸入相關聯: 第一個輸入保存 `usize` 精度，第二個輸入保存要打印的值。
//!    請注意，在這種情況下，如果使用格式字符串 `{<arg>:<spec>.*}`，則 `<arg>` 部分將引用* value * 進行打印，並且 `precision` 必須位於 `<arg>` 之前的輸入中。
//!
//! 例如，以下所有調用均打印相同的內容 `Hello x is 0.01000`:
//!
//! ```
//! // 你好 {arg 0 ("x")} 是 {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // 你好 {arg 1 ("x")} 是 {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // 你好 {arg 0 ("x")} 是 {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // 你好 {next arg ("x")} 是 {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // 你好 {next arg ("x")} 是 {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // 你好 {next arg ("x")} 是 {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! 雖然這些:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! 打印三個明顯不同的內容:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! 在某些編程語言中，字符串格式化功能的行為取決於操作系統的語言環境設置。
//! Rust 的標準庫提供的格式函數沒有任何語言環境的概念，並且無論用戶配置如何，在所有系統上都會產生相同的結果。
//!
//! 例如，即使系統區域設置使用小數點分隔符 (而不是點)，以下代碼也將始終打印 `1.5`。
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! 文字字符 `{` 和 `}` 可以通過在字符串之前添加相同的字符來包含在字符串中。例如，`{` 字符使用 `{{` 進行轉義，而 `}` 字符使用 `}}` 進行轉義。
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! 總結一下，您可以在這裡找到格式字符串的完整語法。
//! 所用格式語言的語法是從其他語言中提取的，因此不應太陌生。參數使用類似 Python 的語法格式化，這意味著參數被 `{}` 包圍而不是 C 一樣的 `%`。
//! 格式化語法的實際語法為:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! 在以上語法中，`text` 不得包含任何 `'{'` 或 `'}'` 字符。
//!
//! # 格式化 traits
//!
//! 當要求將參數格式化為特定類型時，實際上是在要求參數歸因於特定的 trait。
//! 這允許通過 `{:x}` 格式化多種實際類型 (例如 [`i8`] 和 [`isize`])。類型到 traits 的當前映射為:
//!
//! * *無* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] 具有小寫的十六進制整數
//! * `X?` ⇒ [`Debug`] 具有大寫的十六進制整數
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! 這意味著實現 [`fmt::Binary`][`Binary`] trait 的任何類型的參數都可以用 `{:b}` 格式化。標準庫也為許多原始類型提供了針對這些 traits 的實現。
//!
//! 如果未指定格式 (如 `{}` 或 `{:6}`)，則使用的格式 trait 為 [`Display`] trait。
//!
//! 當為您自己的類型實現格式 trait 時，您將必須實現簽名的方法:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // 我們的自定義類型
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! 您的類型將作為 `self` 的引用傳遞，然後該函數應將輸出發出到 `f.buf` 流中。正確遵守所請求的格式設置參數，取決於每種格式 trait 的實現。
//! 這些參數的值將在 [`Formatter`] 結構的字段中列出。為了解決這個問題，[`Formatter`] 結構還提供了一些輔助方法。
//!
//! 另外，該函數的返回值為 [`fmt::Result`]，它是 [`Result`]`< ()，[[std: : fmt::Error`]]> 的類型別名。
//! 格式化實現應確保它們傳播來自 [`Formatter`] 的錯誤 (例如，調用 [`write!`] 時)。
//! 但是，它們絕不能虛假地返回錯誤。
//! 也就是說，格式化實現必須並且僅在傳入的 [`Formatter`] 返回錯誤的情況下才返回錯誤。
//! 這是因為，與功能簽名可能建議的相反，字符串格式是一項可靠的操作。
//! 該函數僅返回結果，因為寫入基礎流可能會失敗，並且它必須提供一種方法來將錯誤已發生的事實傳播回堆棧。
//!
//! 實現格式 traits 的示例如下所示:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` 值實現 `Write` trait，這就是寫內容! 宏在期待。
//!         // 請注意，這種格式化將忽略為格式化字符串而提供的各種標誌。
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // 不同的 traits 允許類型的不同形式的輸出。
//! // 此格式的含義是打印 vector 的大小。
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // 通過使用 Formatter 對像上的幫助器方法 `pad_integral`，尊重格式設置標誌。
//!         // 有關詳細信息，請參見方法文檔，並且函數 `pad` 可用於填充字符串。
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` 與 `fmt::Debug`
//!
//! 這兩種格式 traits 具有不同的用途:
//!
//! - [`fmt::Display`][`Display`] 實現斷言該類型可以始終如實地表示為 UTF-8 字符串。並非所有類型都實現 [`Display`] trait。
//! - [`fmt::Debug`][`Debug`] 應該為 **所有** 公共類型實施實現。
//!   輸出通常會盡可能忠實地代表內部狀態。
//!   [`Debug`] trait 的目的是方便調試 Rust 代碼。在大多數情況下，建議使用 `#[derive(Debug)]` 就足夠了。
//!
//! traits 的輸出的一些示例:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # 相關宏
//!
//! [`format!`] 系列中有許多相關的宏。當前實現的是:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! 這和 [`writeln!`] 是兩個宏，用於將格式字符串發送到指定的流。這用於防止格式字符串的中間分配，而是直接寫入輸出。
//! 實際上，此函數實際上是在 [`std::io::Write`] trait 上定義的 [`write_fmt`] 函數。
//! 用法示例是:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! 此和 [`println!`] 將其輸出發送到 stdout。與 [`write!`] 宏類似，這些宏的目標是避免在打印輸出時進行中間分配。用法示例是:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] 和 [`eprintln!`] 宏分別與 [`print!`] 和 [`println!`] 相同，除了它們將其輸出輸出到 stderr。
//!
//! ### `format_args!`
//!
//! 這是一個奇怪的宏，用於安全地傳遞描述格式字符串的不透明對象。該對像不需要創建任何堆分配，它僅引用堆棧上的信息。
//! 在幕後，所有相關的宏都在此方面實現。
//! 首先，一些示例用法是:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! [`format_args!`] 宏的結果是 [`fmt::Arguments`] 類型的值。
//! 然後可以將此結構傳遞給該模塊內部的 [`write`] 和 [`format`] 函數，以處理格式字符串。
//! 該宏的目標是在處理格式化字符串時甚至進一步防止中間分配。
//!
//! 例如，日誌記錄庫可以使用標準格式語法，但是它將在內部傳遞此結構，直到確定輸出應該到達的位置為止。
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// `format` 函數採用 [`Arguments`] 結構，並返回所得的格式化字符串。
///
///
/// 可以使用 [`format_args!`] 宏創建 [`Arguments`] 實例。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// 請注意，使用 [`format!`] 可能更可取。
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}