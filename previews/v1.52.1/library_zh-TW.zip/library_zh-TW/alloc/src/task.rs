#![stable(feature = "wake_trait", since = "1.51.0")]
//! 類型和 Traits 用於處理異步任務。
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// 在執行程序上喚醒任務的實現。
///
/// trait 可用於創建 [`Waker`]。
/// 執行者可以定義此 trait 的實現，並使用該構造來構造 Waker 以傳遞給在該執行者上執行的任務。
///
/// trait 是構建 [`RawWaker`] 的內存安全且符合人體工程學的替代方案。
/// 它支持通用執行程序設計，其中用於喚醒任務的數據存儲在 [`Arc`] 中。
/// 某些執行程序 (尤其是嵌入式系統的執行程序) 無法使用此 API，這就是為什麼存在 [`RawWaker`] 來替代這些系統的原因。
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// 一個基本的 `block_on` 函數，它採用 future 並在當前線程上運行該函數以使其完成。
///
/// **Note:** 本示例以正確性為代價。
/// 為了防止死鎖，生產級實現也將需要處理對 `thread::unpark` 的中間調用以及嵌套調用。
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// 一個在調用時喚醒當前線程的喚醒器。
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// 在當前線程上運行 future 以完成操作。
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // 固定 future，以便可以對其進行輪詢。
///     let mut fut = Box::pin(fut);
///
///     // 創建一個要傳遞給 future 的新上下文。
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // 運行 future 完成。
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// 喚醒此任務。
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// 在不消耗喚醒程序的情況下喚醒此任務。
    ///
    /// 如果執行程序支持一種更便宜的喚醒方式而不消耗喚醒程序，則它應該重寫此方法。
    /// 默認情況下，它將克隆 [`Arc`] 並在克隆上調用 [`wake`]。
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // 安全: 這很安全，因為 raw_waker 安全地構造了
        // 來自 Arc 的 RawWaker<W>。
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: 使用此私有函數來構造 RawWaker，而不是使用
// 將其內聯到 `From<Arc<W>> for RawWaker` impl 中，以確保 `From<Arc<W>> for Waker` 的安全性不依賴於正確的 trait 調度，而是兩個 impls 直接且顯式調用此函數。
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // 增加弧的參考計數以克隆它。
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // 按值喚醒，將圓弧移到 Wake::wake 功能中
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // 通過引用喚醒，將喚醒器包裹在 ManuallyDrop 中，以避免掉落
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // 減少落弧時的參考計數
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}