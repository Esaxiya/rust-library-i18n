//! Windows SEH
//!
//! 在 Windows 上 (當前僅在 MSVC 上)，默認的異常處理機制是結構化異常處理 (SEH)。
//! 就編譯器內部而言，這與基於 Dwarf 的異常處理 (例如，其他 unix 平台使用的異常處理) 完全不同，因此要求 LLVM 對 SEH 提供大量額外支持。
//!
//! 簡而言之，這裡發生的是:
//!
//! 1. `panic` 函數調用標準 Windows 函數 `_CxxThrowException` 引發類似 C++ 的異常，從而觸發展開過程。
//! 2.
//! 編譯器生成的所有著陸墊都使用個性功能 `__CxxFrameHandler3` (CRT 中的功能)，並且 Windows 中的展開代碼將使用此個性功能來執行堆棧上的所有清理代碼。
//!
//! 3. 編譯器生成的所有對 `invoke` 的調用都將著陸區設置為 `cleanuppad` LLVM 指令，該指令指示清除例程的開始。
//! 個性 (在 CRT 中定義的步驟 2) 負責運行清除例程。
//! 4. 最終，執行 `try` 內部函數中的 "catch" 代碼 (由編譯器生成)，並指示控件應返回 Rust。
//! 這是通過 `catchswitch` 加上 LLVM IR 術語中的 `catchpad` 指令完成的，最後使用 `catchret` 指令將正常控制權返回給程序。
//!
//! 與基於 gcc 的異常處理的某些特定區別是:
//!
//! * Rust 沒有自定義個性功能，而是 *始終*`__CxxFrameHandler3`。此外，沒有執行任何額外的過濾，因此我們最終捕獲了所有碰巧看起來像我們拋出的 C++ 異常。
//! 請注意，將異常拋出到 Rust 始終是未定義的行為，因此應該沒問題。
//! * 我們已經有一些數據要在平移邊界上傳輸，特別是 `Box<dyn Any + Send>`。像 Dwarf 異常一樣，這兩個指針作為有效載荷存儲在異常本身中。
//! 但是，在 MSVC 上，不需要額外的堆分配，因為在執行過濾器功能時會保留調用堆棧。
//! 這意味著將指針直接傳遞到 `_CxxThrowException`，然後在過濾器函數中將其恢復，以將其寫入 `try` 內部函數的堆棧幀。
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // 這必須是一個 Option，因為我們通過引用捕獲異常，並且其析構函數由 C++ 運行時執行。
    // 當我們從異常中取出 Box 時，我們需要將異常保持在有效狀態，以使其析構函數能夠運行，而無需雙擊 Box。
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// 首先，介紹一堆類型定義。這裡有一些特定於平台的奇怪之處，很多都是從 LLVM 中公然複製的。所有這些目的是通過調用 `_CxxThrowException` 來實現下面的 `panic` 功能。
//
// 該函數有兩個參數。第一個是指向我們要傳遞的數據的指針，在這種情況下，它是我們的 trait 對象。很容易找到! 但是，下一個更為複雜。
// 這是指向 `_ThrowInfo` 結構的指針，通常僅用於描述所拋出的異常。
//
// 目前，[1] 類型的定義有些毛茸茸，主要的奇怪之處 (與在線文章不同) 是在 32 位上，指針是指針，而在 64 位上，指針表示為相對於 32 位偏移量。`__ImageBase` 符號。
//
// 以下模塊中的 `ptr_t` 和 `ptr!` 宏用於表達這一點。
//
// 類型定義的迷宮還密切關注 LLVM 針對此類操作發出的內容。例如，如果您在 MSVC 上編譯此 C++ 代碼並發出 LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      無效 foo() { rust_panic a = {0, 1};
//          扔}
//
// 從本質上講，這就是我們要模仿的東西。下面的大多數常量值都是從 LLVM 複製的，
//
// 無論如何，這些結構都是以類似的方式構造的，這對我們來說只是有些冗長。
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// 請注意，我們在這裡有意忽略名稱處理規則: 我們不希望 C++ 能夠通過簡單地聲明 `struct rust_panic` 來捕獲 Rust panics。
//
//
// 進行修改時，請確保類型名稱字符串與 `compiler/rustc_codegen_llvm/src/intrinsic.rs` 中使用的字符串完全匹配。
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // 這裡的前導 `\x01` 字節實際上是向 LLVM 發出的神奇信號，*不* 應用任何其他操作，例如以 `_` 字符作為前綴。
    //
    //
    // 此符號是 C++ `std::type_info` 使用的 vtable。
    // `std::type_info` 類型的對象 (類型描述符) 具有指向此表的指針。
    // 類型描述符由上面定義的 C++ EH 結構引用，並在下面構造。
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// 僅在引發異常時使用此類型描述符。
// catch 部分由 try 內部函數處理，try 內部函數生成自己的 TypeDescriptor。
//
// 這很好，因為 MSVC 運行時在類型名稱上使用字符串比較來匹配 TypeDescriptor 而不是指針相等。
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// 如果 C++ 代碼決定捕獲異常並將其丟棄而不傳播，則使用析構函數。
// try 內在函數的 catch 部分會將異常對象的第一個字設置為 0，以便析構函數將其跳過。
//
// 請注意，x86 Windows 對 C++ 成員函數使用 "thiscall" 調用約定，而不是默認的 "C" 調用約定。
//
// exception_copy 函數在這裡有點特殊: 它由 MSVC 運行時在 try/catch 塊下調用，我們在此處生成的 panic 將用作異常複製的結果。
//
// C ++ 運行時使用它來支持捕獲 std::exception_ptr 的異常，這是我們不能支持的，因為 Box<dyn Any> 不友善
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException 完全在此堆棧幀上執行，因此無需將 `data` 轉移到堆。
    // 我們只是將堆棧指針傳遞給該函數。
    //
    // 這裡需要使用 ManuallyDrop，因為我們不希望在展開時刪除 Exception。
    // 相反，它將由 C++ 運行時調用的 exception_cleanup 刪除。
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // 這……似乎令人驚訝，而且理所當然地如此。在 32 位 MSVC 上，這些結構之間的指針就是指針。
    // 但是，在 64 位 MSVC 上，結構之間的指針被表示為相對於 `__ImageBase` 的 32 位偏移量。
    //
    // 因此，在 32 位 MSVC 上，我們可以在上面的 `static` 中聲明所有這些指針。
    // 在 64 位 MSVC 上，我們將不得不在靜態變量中表示指針的減法，而 Rust 當前不允許這樣做，因此我們實際上無法做到這一點。
    //
    // 然後，第二件事是在運行時填充這些結構 (無論如何，恐慌已經是 "slow path")。
    // 因此，在這裡，我們將所有這些指針字段重新解釋為 32 位整數，然後將相關值存儲到其中 (從原子上講，因為可能發生並發 panics)。
    //
    // 從技術上講，運行時可能會以非原子方式讀取這些字段，但是從理論上講，它們永遠不會讀取 *wrong* 值，因此它應該不會太糟...
    //
    // 在任何情況下，我們基本上都需要做這樣的事情，直到我們可以在靜態變量中表達更多的操作為止 (而且我們可能永遠做不到)。
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // 此處的 NULL 負載意味著我們是從__rust_try 的 (...) 捕獲那裡到達的。
    // 當捕獲到非 Rust 外部異常時，會發生這種情況。
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// 這是編譯器必須存在的 (例如，這是一個 lang 項)，但實際上從未被編譯器調用，因為__C_specific_handler 或 _except_handler3 是始終使用的個性功能。
//
// 因此，這只是一個正在中止的存根。
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}