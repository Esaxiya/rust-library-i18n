//! 為 Miri 展開 panics。
use alloc::boxed::Box;
use core::any::Any;

// Miri 引擎通過展開為我們傳播的有效負載類型。
// 必須為指針大小。
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// 由 Miri 提供的外部函數開始展開。
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // 我們傳遞給 `miri_start_panic` 的有效負載將恰好是我們在下面的 `cleanup` 中獲得的參數。
    // 因此，我們只需將其裝箱一次，即可得到指針大小的東西。
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // 恢復基礎 `Box`。
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}