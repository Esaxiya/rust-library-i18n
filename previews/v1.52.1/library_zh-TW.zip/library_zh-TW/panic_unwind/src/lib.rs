//! 通過堆棧展開實現 panics
//!
//! crate 是 Rust 中 panics 的實現，使用的平台是 "most native" 堆棧展開機制。
//! 目前，這實際上可分為三類:
//!
//! 1. MSVC 目標在 `seh.rs` 文件中使用 SEH。
//! 2. Emscripten 在 `emcc.rs` 文件中使用 C++ 異常。
//! 3. 所有其他目標都使用 `gcc.rs` 文件中的 libunwind/libgcc。
//!
//! 有關每種實現的更多文檔可以在各自的模塊中找到。
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` 未與 Miri 一起使用，因此請保持靜音警告。
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust 運行時的啟動對象取決於這些符號，因此請將它們公開。
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // 不支持展開的目標。
        // - arch=wasm32
        // - os=none ("bare metal" 目標)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // 使用 Miri 運行時。
        // 我們還需要加載上面的正常運行時，因為 rustc 希望從中定義某些 lang 項目。
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // 使用實際的運行時。
        use real_imp as imp;
    }
}

extern "C" {
    /// 當 panic 對象放在 `catch_unwind` 之外時，libstd 中的處理程序被調用。
    ///
    fn __rust_drop_panic() -> !;

    /// 當捕獲到外部異常時，將在 libstd 中調用處理程序。
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// 引發異常的入口點，僅代表特定於平台的實現。
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}