# 為 stdarch 做貢獻

`stdarch` crate 非常願意接受捐款! 首先，您可能需要檢出存儲庫，並確保測試通過:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

其中 `<your-target-arch>` 是 `rustup` 使用的目標三元組，例如 `x86_x64-unknown-linux-gnu` (沒有任何先前的 `nightly-` 或類似物)。
還請記住，此存儲庫需要 Rust 的夜間頻道!
實際上，以上測試確實要求將每晚的 rust 設置為系統上的默認設置，以使用 `rustup default nightly` (和 `rustup default stable` 進行還原) 進行設置。

如果以上任何步驟都不起作用， [please let us know][new]!

接下來，您可以使用 [find an issue][issues] 進行幫助，我們選擇了一些帶有 [`help wanted`][help] 和 [`impl-period`][impl] 標籤的標籤，這些標籤可能特別有用。
您可能對 [#40][vendor] 最感興趣，並在 x86 上實現了所有供應商內在函數。這個問題對於從哪裡開始有一些很好的指示!

如果您有一般性問題，請隨時向 [join us on gitter][gitter] 詢問! 如有問題，請隨時 ping@BurntSushi 或 @alexcrichton。

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# 如何為 stdarch 內部函數編寫示例

為了使給定的內在函數正常工作，必須啟用一些功能，並且該示例僅在 CPU 支持該功能時才可以由 `cargo test --doc` 運行。

結果，`rustdoc` 生成的默認 `fn main` 將不起作用 (在大多數情況下)。
考慮使用以下內容作為指導，以確保您的示例按預期工作。

```rust
/// # // 我們需要 cfg_target_feature 以確保該示例僅為
/// # // 當 CPU 支持該功能時，由 `cargo test --doc` 運行
/// # #![feature(cfg_target_feature)]
/// # // 我們需要 target_feature 才能使內在函數正常工作
/// # #![feature(target_feature)]
/// #
/// # // rustdoc 默認使用 `extern crate stdarch`，但我們需要
/// # // `#[macro_use]`
/// # #[macro_use] extern crate stdarch;
/// #
/// # // 真正的主要功能
/// # fn main() {
/// #     // 僅在支持 `<target feature>` 時運行此命令
/// #     如果 cfg_feature_enabled! (`<target feature>`) {
/// #         // 創建一個 `worker` 函數，該函數僅在目標功能時才運行
/// #         // 受支持，並確保為您的工作人員啟用了 `target_feature`
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         不安全的 fn worker() {
/// // 在此處寫下您的示例。特定於功能的內在函數將在這里工作! 去野外!
///
/// #         }
///
/// #         不安全的 { worker(); }
/// #     }
/// # }
```

如果上述某些語法看起來不太熟悉，則 [Rust Book] 的 [Documentation as tests] 部分將很好地描述 `rustdoc` 語法。
與往常一樣，請隨時使用 [join us on gitter][gitter]，並詢問我們是否遇到任何障礙，並感謝您幫助改善 `stdarch` 的文檔!

# 替代測試說明

通常建議您使用 `ci/run.sh` 來運行測試。
但是，這可能對您不起作用，例如，如果您使用的是 Windows。

在這種情況下，您可以退回運行 `cargo +nightly test` 和 `cargo +nightly test --release -p core_arch` 來測試代碼生成。
請注意，這些要求每夜安裝一次工具鏈，並且 `rustc` 才能了解目標三元組及其 CPU。
特別是，您需要像設置 `ci/run.sh` 一樣設置 `TARGET` 環境變量。
另外，您需要設置 `RUSTCFLAGS` (需要 `C`) 以指示目標功能，例如 `RUSTCFLAGS="-C -target-features=+avx2"`.
如果您正在針對當前的 CPU 開發 "just"，也可以設置 `-C -target-cpu=native`。

請注意，當您使用這些替代說明時，例如 [things may go less smoothly than they would with `ci/run.sh`][ci-run-good]
指令生成測試可能會失敗，因為反彙編程序對它們的命名不同，例如
儘管它們的行為相同，但它可能會生成 `vaesenc` 而不是 `aesenc` 指令。
同樣，這些指令執行的測試少於通常執行的測試，因此當您最終請求請求時，對於此處未涵蓋的測試可能會出現一些錯誤，請不要感到驚訝。

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






