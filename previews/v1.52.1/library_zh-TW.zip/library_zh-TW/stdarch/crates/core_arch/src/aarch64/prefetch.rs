#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// 請參閱 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_READ: i32 = 0;

/// 請參閱 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_WRITE: i32 = 1;

/// 請參閱 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// 請參閱 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// 請參閱 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// 請參閱 [`prefetch`](fn._prefetch.html)。
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// 使用給定的 `rw` 和 `locality` 獲取包含地址 `p` 的緩存行。
///
/// `rw` 必須是以下之一:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): 預取正在準備讀取。
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): 預取正在準備寫操作。
///
/// `locality` 必須是以下之一:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): 流或非時間預取，用於僅使用一次的數據。
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): 提取到 3 級緩存中。
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): 提取到 2 級緩存中。
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): 提取到 1 級緩存中。
///
/// 預取存儲器指令向存儲器系統發送信號，表明從指定地址進行的存儲器訪問可能發生在 future 附近。
/// 內存系統可以通過採取某些措施來做出響應，這些措施可以在確實發生時加快內存訪問的速度，例如將指定地址預加載到一個或多個高速緩存中。
///
/// 因為這些信號只是提示，所以對於特定的 CPU，將任何或所有預取指令視為 NOP 是有效的。
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // 我們將 `llvm.prefetch` 內部使用 `cache type` =1 (數據緩存)。
    // `rw` `strategy` 和 `strategy` 基於功能參數。
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}