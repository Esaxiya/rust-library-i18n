`core::arch` - Rust 的核心庫體系結構特定的內在函數
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` 模塊實現了與體系結構相關的內在函數 (例如 SIMD)。

# Usage 

`core::arch` 可作為 `libcore` 的一部分獲得，並由 `libstd` 重新導出。與通過此 crate 相比，更喜歡通過 `core::arch` 或 `std::arch` 使用它。
不穩定的功能通常在夜間的 X0XustXZ 中通過 `feature(stdsimd)` 提供。

通過此 crate 使用 `core::arch` 需要每晚執行 Rust，並且它可能 (並且確實) 經常中斷。您應該考慮通過此 crate 使用它的唯一情況是:

* 如果您需要自己重新編譯 `core::arch`，例如，啟用了 `libcore`/`libstd` 未啟用的特定目標功能。
Note: 如果您需要針對非標準目標重新編譯它，請優先使用 `xargo` 並根據需要重新編譯 `libcore`/`libstd`，而不要使用此 crate。
  
* 使用某些即使在不穩定的 Rust 功能之後也可能無法使用的功能。我們嘗試將這些限制降至最低。
如果您需要使用其中一些功能，請打開一個問題，以便我們可以在每晚的 Rust 中公開它們，然後從那裡開始使用它們。

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` 主要根據 MIT 許可證和 Apache 許可證 (版本 2.0) 的條款進行分發，部分內容由各種類似 BSD 的許可證涵蓋。

有關詳細信息，請參見 LICENSE-APACHE 和 LICENSE-MIT。

# Contribution

除非您明確聲明，否則 Apache-2.0 許可中定義的由您有意提交以供包含在 `core_arch` 中的任何貢獻均應按照上述雙重許可方式使用，沒有任何其他條款或條件。


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












