use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // 用來告訴我們的 `#[assert_instr]` 批註，所有 simd 內部函數都可以用來測試其代碼生成，因為其中一些是封閉在當前 `#[target_feature]` 中沒有任何等效項的額外 `-Ctarget-feature=+unimplemented-simd128` 後面的。
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}