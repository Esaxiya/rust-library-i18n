use backtrace::Backtrace;

// 該測試僅在具有可正常工作的 `symbol_address` 功能的平台上工作，該功能可報告符號的起始地址。
// 結果，它僅在少數平台上啟用。
//
const ENABLED: bool = cfg!(all(
    // Windows 尚未經過真正的測試，並且 OSX 不支持實際找到封閉框架，因此請禁用此功能
    //
    target_os = "linux",
    // 在 ARM 上，找到封閉函數只是返回 ip 本身。
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}