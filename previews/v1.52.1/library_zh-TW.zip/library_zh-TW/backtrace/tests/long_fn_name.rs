use backtrace::Backtrace;

// 50 個字符的模塊名稱
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50 個字符的結構名稱
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// 長函數名稱必須截斷為 (MAX_SYM_NAME，1) 個字符。
// 僅對 msvc 運行此測試，因為 gnu 將為所有幀打印 "<no info>"。
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 結構名稱重複 10 次，因此完全限定的函數名稱至少 10 *(50 + 50)* 2=2000 個字符。
    //
    // 實際上它更長，因為它還包含 `::`，`<>` 和當前模塊的名稱
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}