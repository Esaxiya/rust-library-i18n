# backtrace-rs

[Documentation](https://docs.rs/backtrace)

一個用於在運行時獲取 Rust 的回溯的庫。
該庫旨在通過提供程序接口來增強對標準庫的支持，但它也支持輕鬆輕鬆地打印當前回溯，如 libstd 的 panics。

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

要簡單地捕獲回溯跟踪並將其推遲到以後再處理，可以使用頂級 `Backtrace` 類型。

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

但是，如果您希望對原始跟踪功能有更多的原始訪問權限，則可以直接使用 `trace` 和 `resolve` 函數。

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // 將此指令指針解析為符號名稱
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // 繼續前進到下一幀
    });
}
```

# License

該項目獲得以下任一許可

 * Apache 許可證，版本 2.0，([LICENSE-APACHE](LICENSE-APACHE) 或 http://www.apache.org/licenses/LICENSE-2.0)
 * MIT 許可證 ([LICENSE-MIT](LICENSE-MIT) 或 http://opensource.org/licenses/MIT)

由您選擇。

### Contribution

除非您明確聲明，否則 Apache-2.0 許可中定義的由您有意提交以供包含在 backtrace-rs 中的任何貢獻均應如上所述具有雙重許可，沒有任何其他條款或條件。







