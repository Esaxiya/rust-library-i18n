use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// 解析符號的地址，然後將符號傳遞給指定的閉包。
///
/// 此函數將在局部符號表，動態符號表或 DWARF 調試信息 (取決於激活的實現) 等區域中查找給定地址，以查找要產生的符號。
///
///
/// 如果無法執行解析，則可能不會調用閉包; 對於內聯函數，也可能會多次調用該閉包。
///
/// 產生的符號表示在指定的 `addr` 處的執行，並返回該地址的 file/line 對 (如果有)。
///
/// 請注意，如果您有 `Frame`，則建議使用 `resolve_frame` 功能而不是 `Frame` 功能。
///
/// # 必備功能
///
/// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
///
/// # Panics
///
/// 該功能力求永遠不要 panic，但是如果 `cb` 提供了 panics，則某些平台將強制使用雙 panic 中止該進程。
/// 某些平台使用 C 庫，該庫在內部使用無法解開的回調，因此從 `cb` 發出驚慌可能會導致進程中止。
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // 只看頂部框架
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// 將先前捕獲的幀解析為符號，然後將符號傳遞給指定的閉包。
///
/// 該函數執行與 `resolve` 相同的功能，除了它使用 `Frame` 作為參數而不是地址。
/// 例如，這可以允許回溯的某些平台實現提供更準確的符號信息或有關內聯幀的信息。
///
/// 如果可以的話，建議使用此功能。
///
/// # 必備功能
///
/// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
///
/// # Panics
///
/// 該功能力求永遠不要 panic，但是如果 `cb` 提供了 panics，則某些平台將強制使用雙 panic 中止該進程。
/// 某些平台使用 C 庫，該庫在內部使用無法解開的回調，因此從 `cb` 發出驚慌可能會導致進程中止。
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // 只看頂部框架
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// 堆棧幀中的 IP 值通常是 (always?) 指令 *實際調用後的調用*。
// 對此進行符號化表示，導致 filename/line 數字在該函數的結尾附近，如果它在函數的末尾提前一個，並且可能成為空白。
//
// 在所有平台上，似乎基本上都是這種情況，因此我們總是從已解析的 ip 中減去一個，以將其解析為上一個調用指令，而不是返回到該指令。
//
//
// 理想情況下，我們不會這樣做。
// 理想情況下，我們將要求 `resolve` API 的調用者在此處手動執行 -1，並說明他們需要 *previous* 指令 (而不是當前指令) 的位置信息。
// 理想情況下，如果我們確實是下一條指令或當前指令的地址，則也應在 `Frame` 上公開。
//
// 就目前而言，儘管這是一個非常特殊的問題，所以我們在內部始終總是減去一個。
// 消費者應該繼續努力並取得不錯的成績，所以我們應該足夠好。
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// 與 `resolve` 相同，只是不安全，因為它未同步。
///
/// 該功能沒有同步保證人，但是當未編譯此 crate 的 `std` 功能時可用。
/// 有關更多文檔和示例，請參見 `resolve` 函數。
///
/// # Panics
///
/// 有關 `cb` 恐慌的警告，請參見 `resolve` 上的信息。
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// 與 `resolve_frame` 相同，只是不安全，因為它未同步。
///
/// 該功能沒有同步保證人，但是當未編譯此 crate 的 `std` 功能時可用。
/// 有關更多文檔和示例，請參見 `resolve_frame` 函數。
///
/// # Panics
///
/// 有關 `cb` 恐慌的注意事項，請參見 `resolve_frame` 上的信息。
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait 表示文件中符號的分辨率。
///
/// trait 作為 X0X 函數給定的閉包的 trait 對像生成，並且實際上是分派的，因為未知其背後是哪個實現。
///
///
/// 符號可以提供有關功能的上下文信息，例如名稱，文件名，行號，精確地址等。
/// 並非所有信息都始終在符號中可用，因此，所有方法都返回 `Option`。
///
///
pub struct Symbol {
    // TODO: 這個生命週期的界限最終需要保留到 `Symbol`，
    // 但這是目前的重大變化。
    // 現在這是安全的，因為 `Symbol` 只能通過引用分發，不能克隆。
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// 返回此函數的名稱。
    ///
    /// 返回的結構可用於查詢有關符號名稱的各種屬性:
    ///
    ///
    /// * `Display` 的實現將打印出拆線的符號。
    /// * 可以訪問符號的原始 `str` 值 (如果它是有效的 utf-8)。
    /// * 可以訪問符號名稱的原始字節。
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// 返回此函數的起始地址。
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// 以切片形式返回原始文件名。
    /// 這主要對 `no_std` 環境有用。
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// 返回此符號當前正在執行的位置的列號。
    ///
    /// 當前只有 gimli 在此處提供一個值，即使 `filename` 返回 `Some` 也是如此，因此也要受到類似的警告。
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// 返回此符號當前正在執行的行號。
    ///
    /// 如果 `filename` 返回 `Some`，則此返回值通常為 `Some`，因此也有類似的警告。
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// 返回定義此函數的文件名。
    ///
    /// 當前僅在使用 libbacktrace 或 gimli 時才可用 (例如
    /// unix 其他平台) 以及使用 debuginfo 編譯二進製文件時。
    /// 如果這兩個條件都不滿足，則可能會返回 `None`。
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // 如果將損壞的符號解析為 Rust 失敗，則可能是解析的 C++ 符號。
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // 確保將此尺寸保持為零，以便禁用 `cpp_demangle` 功能不會產生任何費用。
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// 符號名稱周圍的包裝器，以提供符合人體工程學的訪問器來訪問已分解的名稱，原始字節，原始字符串等。
///
// 未啟用 `cpp_demangle` 功能時，請使用無效代碼。
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// 從原始基礎字節創建一個新的符號名稱。
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// 如果符號有效 utf-8，則將原始 (mangled) 符號名稱返回為 `str`。
    ///
    /// 如果需要脫膠版本，請使用 `Display` 實現。
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// 以字節列表形式返回原始符號名稱
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // 如果已取消組合的符號實際上無效，則可能會打印出來，因此請通過不向外傳播該符號來適當地處理此錯誤。
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// 嘗試回收用於表示地址的緩存內存。
///
/// 此方法將嘗試釋放任何全局數據結構，這些數據結構否則已全局緩存或在線程中緩存，這些結構通常表示已解析的 DWARF 信息或類似信息。
///
///
/// # Caveats
///
/// 儘管此功能始終可用，但實際上在大多數實現中均不執行任何操作。
/// 諸如 dbghelp 或 libbacktrace 之類的庫不提供釋放狀態和管理已分配內存的功能。
/// 目前，此 crate 的 `gimli-symbolize` 功能是該功能起作用的唯一功能。
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}