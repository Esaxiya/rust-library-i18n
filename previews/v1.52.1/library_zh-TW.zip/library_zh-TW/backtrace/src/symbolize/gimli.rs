//! 在 crates.io 上使用 `gimli` crate 支持符號化
//!
//! 這是 Rust 的默認符號實現。

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 靜態生命週期是在缺乏對自我引用結構的支持的支持下的謊言。
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // 轉換為 `靜態壽命`，因為符號僅應藉用 `map` 和 `stash`，我們將其保留在下面。
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // 要在 Windows 上加載本機庫，請參見 rust-lang/rust#71060 上有關各種策略的一些討論。
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW 庫當前不支持 ASLR (rust-lang/rust#16514)，但是 DLL 仍可以在地址空間中重新定位。
            // 如果該庫是在其 "image base" 處加載的，則調試信息中的地址似乎全部都作為該庫的 COFF 文件頭中的一個字段。
            // 由於這是 debuginfo 似乎列出的內容，因此我們解析符號表並存儲地址，就好像該庫也已在 "image base" 上加載一樣。
            //
            // 但是，該庫可能未在 "image base" 上加載。
            // (大概在那裡可能還有其他內容嗎? ) 這是 `bias` 字段起作用的地方，我們需要在這裡計算 `bias` 的值。不幸的是，儘管目前尚不清楚如何從已加載的模塊中獲取此信息。
            // 但是，我們要做的是實際的加載地址 (`modBaseAddr`)。
            //
            // 現在，作為一點補償，我們映射文件，讀取文件頭信息，然後放下 mmap。這很浪費，因為我們稍後可能會重新打開 mmap，但這現在應該已經足夠好了。
            //
            // 一旦有了 `image_base` (所需的加載位置) 和 `base_addr` (實際的加載位置)，我們就可以填寫 `bias` (實際值與期望值之差)，然後每個段的指定地址就是 `image_base`，因為這就是文件所說的。
            //
            //
            // 現在看來，與 ELF/MachO 不同，我們可以使用 `modBaseSize` 作為整個大小來處理每個庫一個段。
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS 使用 Mach-O 文件格式，並使用 DYLD 特定的 API 加載作為應用程序一部分的本機庫的列表。
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // 獲取該庫的名稱，該名稱也與加載該庫的路徑相對應。
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // 加載該庫的圖像頭並將其委託給 `object` 來解析所有加載命令，因此我們可以找出此處涉及的所有段。
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // 遍歷這些段，並為找到的段註冊已知區域。
            // 另外，記錄有關文本段的信息以供以後處理，請參閱下面的註釋。
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // 確定該庫的 "slide"，這最終是我們用來確定內存對象加載位置的偏差。
            // 但是，這是一個奇怪的計算，是在野外嘗試一些嘗試並看得出結果的結果。
            //
            // 通常的想法是，`bias` 加上段的 `stated_virtual_memory_address` 將成為該段在實際地址空間中的位置。
            // 但是，我們要依賴的另一件事是，實際地址減去 `bias` 就是要在符號表和 debuginfo 中查找的索引。
            //
            // 但是事實證明，對於系統加載的庫，這些計算是不正確的。但是，對於本機可執行文件，它似乎是正確的。
            // 從 LLDB 的源代碼中提取了一些邏輯，它對從文件偏移量 0 (非零大小) 加載的第一個 `__TEXT` 節有一些特殊的框。
            // 無論出於何種原因，出現這種情況似乎都意味著符號表僅相對於庫的 vmaddr 幻燈片。
            // 如果 *不存在*，則符號表是相對於 vmaddr 幻燈片加上段的聲明地址的。
            //
            // 為了處理這種情況，如果我們 *找不到* 文件偏移量為零的文本部分，那麼我們將增加第一個文本部分的聲明地址的偏見，並同時減少所有聲明地址的數量。
            //
            // 這樣，符號表總是相對於庫的偏差量出現。
            // 這似乎對於通過符號表進行符號化具有正確的結果。
            //
            // 老實說，我不確定這是正確的還是還有其他方法可以指示如何做到這一點。
            // 目前，儘管 (?) 看起來已經足夠好了，但如果有必要，我們應該可以隨時對其進行調整。
            //
            // 有關更多信息，請參見 #318。
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // 其他 Unix (例如
        // Linux) 平台使用 ELF 作為目標文件格式，並且通常實現稱為 `dl_iterate_phdr` 的 API 來加載本機庫。
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` 應該是一個有效的指針。
        // `vec` 應該是指向 `std::Vec` 的有效指針。
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 本身不支持調試信息，但是構建系統會將調試信息放置在路徑 `romfs:/debug_info.elf` 處。
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // 其他所有內容都應使用 ELF，但不知道如何加載本機庫。
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// 已加載的所有已知共享庫。
    libraries: Vec<Library>,

    /// 映射緩存，其中保留了解析的矮人信息。
    ///
    /// 此列表在整個提升期間具有固定的容量，永遠不會增加。
    /// 每對中的 `usize` 元素是 `libraries` 的索引，以上 `usize::max_value()` 表示當前可執行文件。
    ///
    /// `Mapping` 是相應的解析後的矮人信息。
    ///
    /// 請注意，這基本上是一個 LRU 緩存，我們將在這裡對地址進行符號化，以進行符號化。
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// 該庫的各段已加載到內存中以及它們的加載位置。
    segments: Vec<LibrarySegment>,
    /// 該庫的 "bias"，通常是它被加載到內存中的位置。
    /// 將此值添加到每個段的聲明地址中，以獲取該段加載到的實際虛擬內存地址。
    /// 另外，從實際虛擬內存地址中減去此偏差以將其索引到 debuginfo 和符號表中。
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// 在對象文件中該段的指定地址。
    /// 實際上，這不是加載該段的位置，而是在該地址加上包含庫的 `bias` 所在的位置。
    ///
    stated_virtual_memory_address: usize,
    /// 內存中 ths 段的大小。
    len: usize,
}

// 不安全，因為需要從外部進行同步
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // 不安全，因為需要從外部進行同步
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // 一個非常小，非常簡單的 LRU 緩存，用於調試信息映射。
        //
        // 命中率應該很高，因為典型的堆棧不會在許多共享庫之間交叉。
        //
        // `addr2line::Context` 結構的創建成本非常高。
        // 預期其成本將由後續的 `locate` 查詢攤銷，這些查詢將利用在構建 `addr2line: : Context`s 時構建的結構來獲得良好的加速效果。
        //
        // 如果我們沒有此緩存，則攤銷將永遠不會發生，而像徵性回溯將是 ssssllllooooowwww。
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // 首先，測試此 `lib` 是否具有包含 `addr` 的任何段 (處理重定位)。如果此檢查通過，那麼我們可以繼續下面的內容並實際翻譯地址。
                //
                // 請注意，我們在這裡使用 `wrapping_add` 以避免溢出檢查。狂野地看到 SVMA + 偏差計算會溢出。
                // 這似乎有點奇怪，但除了可能忽略這些片段，因為它們可能指向太空之外，我們對此無能為力。
                //
                // 這最初是在 rust-lang/backtrace-rs#329 中出現的。
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // 既然我們知道 `lib` 包含 `addr`，我們就可以通過偏置進行偏移以找到規定的虛擬內存地址。
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // 不變式: 此條件完成後沒有提前返回
        // 由於錯誤，此路徑的緩存條目位於索引 0。

        if let Some(idx) = idx {
            // 當映射已經在緩存中時，將其移到最前面。
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // 當映射不在高速緩存中時，請創建一個新的映射，將其插入高速緩存的前面，並在必要時逐出最舊的高速緩存條目。
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // 不要洩漏 `'static` 的使用壽命，請確保它僅限於我們自己
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // 將 `sym` 的壽命延長到 `'static`，這是很不幸的，因為我們必須這樣做，但是它永遠只作為參考，因此無論如何都不應堅持到此。
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // 最後，獲取緩存的映射或為此文件創建新的映射，並評估 DWARF 信息以查找該地址的 file/line/name。
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// 我們能夠找到該符號的框架信息，並且 `addr2line` 的框架內部具有所有細膩的細節。
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// 找不到調試信息，但是我們在 elf 可執行文件的符號表中找到了它。
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}