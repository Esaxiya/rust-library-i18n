//! 在 libbacktrace 中使用 DWARF 解析代碼的符號化策略。
//!
//! 通常與 gcc 一起分發的 libbacktrace C 庫不僅支持生成回溯 (我們實際上沒有使用過)，而且還支持回溯的符號化和處理有關內聯幀之類的東西的矮小的調試信息。
//!
//!
//! 由於這裡存在許多各種各樣的問題，所以這相對複雜，但是基本思想是:
//!
//! * 首先我們稱為 `backtrace_syminfo`。如果可以的話，這將從動態符號表中獲取符號信息。
//! * 接下來我們稱為 `backtrace_pcinfo`。這將解析 debuginfo 表 (如果有)，並允許我們恢復有關內聯框架，文件名，行號等的信息。
//!
//! 將侏儒表放入 libbacktrace 有很多技巧，但是希望它不是世界末日，並且在閱讀下面的內容時已經足夠清楚了。
//!
//! 這是非 MSVC 和非 OSX 平台的默認符號策略。儘管在 libstd 中，這是 OSX 的默認策略。
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // 如果可能的話，最好使用來自 debuginfo 的 `function` 名稱，例如對於內聯框架通常更準確。
                // 如果不存在，則退回到 `symname` 中指定的符號表名稱。
                //
                // 請注意，有時 `function` 的準確性可能會有所降低，例如，被列為 `std::panicking::try::do_call` 的 `try<i32,closure>` 代表。
                //
                // 尚不清楚原因，但總體而言 `function` 名稱似乎更準確。
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // 現在什麼也不做
}

/// 傳遞給 `syminfo_cb` 的 `data` 指針的類型
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // 當我們開始解析時，一旦從 `backtrace_syminfo` 調用了此回調，我們將進一步調用 `backtrace_pcinfo`。
    // `backtrace_pcinfo` 函數將查詢調試信息並嘗試執行諸如恢復 file/line 信息以及內聯幀之類的操作。
    // 請注意，儘管沒有調試信息，但 `backtrace_pcinfo` 可能失敗或無法執行很多操作，因此，如果發生這種情況，我們一定要使用 `syminfo_cb` 中的至少一個符號來調用回調。
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// 傳遞給 `pcinfo_cb` 的 `data` 指針的類型
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace API 支持創建狀態，但不支持銷毀狀態。
// 我個人認為這意味著一個國家將被創造，然後永遠存在。
//
// 我很想註冊一個 at_exit() 處理程序來清理此狀態，但是 libbacktrace 沒有提供這樣做的方法。
//
// 在這些約束下，此函數具有靜態緩存狀態，該狀態是在首次請求此狀態時計算的。
//
// 請記住，所有回溯都是串行發生的 (一個全局鎖)。
//
// 請注意，此處缺少同步是由於需要對 `resolve` 進行外部同步。
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // 不要使用 libbacktrace 的線程安全功能，因為我們總是以同步方式調用它。
        //
        0,
        error_cb,
        ptr::null_mut(), // 沒有多餘的數據
    );

    return STATE;

    // 請注意，要使 libbacktrace 完全起作用，它需要找到當前可執行文件的 DWARF 調試信息。它通常通過多種機制來做到這一點，包括但不限於:
    //
    // * /proc/self/exe 在支持的平台上
    // * 創建狀態時顯式傳遞的文件名
    //
    // libbacktrace 庫是一大堆 C 代碼。這自然意味著它具有內存安全漏洞，尤其是在處理格式錯誤的 debuginfo 時。
    // 從歷史上看，Libstd 已經遇到了很多這樣的情況。
    //
    // 如果使用 /proc/self/exe，則通常可以忽略這些，因為我們假設 libbacktrace 是 "mostly correct"，否則對於 "attempted to be correct" 矮調試信息不會做奇怪的事情。
    //
    //
    // 但是，如果我們傳遞文件名，則在某些平台 (例如 BSD) 上，惡意行為者可能會導致將任意文件放置在該位置，這是可能的。
    // 這意味著，如果我們告訴 libbacktrace 有關文件名的信息，那麼它可能正在使用任意文件，可能會導致段錯誤。
    // 如果我們不告訴 libbacktrace 任何東西，那麼它將在不支持 /proc/self/exe 之類的平台上不做任何事情!
    //
    // 考慮到所有這些，我們將盡最大努力 `不` 傳遞文件名，但是我們必須在根本不支持 /proc/self/exe 的平台上。
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // 請注意，理想情況下，我們將使用 `std::env::current_exe`，但此處我們不需要 `std`。
            //
            // 使用 `_NSGetExecutablePath` 將當前的可執行路徑加載到靜態區域 (如果它太小，則放棄)。
            //
            //
            // 請注意，我們非常信任這裡的 libbacktrace 不會死於損壞的可執行文件，但是它確實可以...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows 具有打開文件的模式，該文件在打開後無法刪除。
            // 總的來說，這就是我們想要的，因為我們希望確保在將可執行文件移交給 libbacktrace 之後，可執行文件不會從我們下面改變出來，希望減輕將任意數據傳遞到 libbacktrace 中的能力 (這可能會被錯誤處理)。
            //
            //
            // 鑑於我們在這裡進行了一些跳舞，試圖對自己的形像有所了解:
            //
            // * 獲取當前進程的句柄，加載其文件名。
            // * 使用正確的標誌打開一個具有該文件名的文件。
            // * 重新加載當前進程的文件名，確保它是相同的
            //
            // 如果所有這些通過了，那麼我們理論上確實已經打開了流程的文件，並且可以保證它不會改變。FWIW 從歷史上從 libstd 複製了一堆，所以這是我對正在發生的事情的最好解釋。
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // 這駐留在靜態內存中，因此我們可以將其返回。
                static mut BUF: [i8; N] = [0; N];
                // ... 並且因為它是臨時的，所以存在於堆棧中
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // 故意在這裡洩漏 `handle`，因為打開該文件會保留我們對該文件名的鎖定。
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // 我們要返回一個以 nul 結尾的切片，因此，如果所有內容都已填充並且等於總長度，則將其等同於失敗。
                //
                //
                // 否則，返回成功時，請確保在切片中包含 nul 字節。
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // 當前回溯錯誤已被掃除
    let state = init_state();
    if state.is_null() {
        return;
    }

    // 調用 `backtrace_syminfo` API (通過讀取代碼)，該 API 應該恰好一次調用 `syminfo_cb` (否則可能會因錯誤而失敗)。
    // 然後，我們在 `syminfo_cb` 中處理更多內容。
    //
    // 請注意，我們這樣做是因為 `syminfo` 將查詢符號表，即使二進製文件中沒有調試信息，也會查找符號名稱。
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}