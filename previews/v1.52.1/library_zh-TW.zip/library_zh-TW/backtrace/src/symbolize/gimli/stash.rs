// 目前僅在 Linux 上使用，因此允許在其他地方使用無效代碼
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// 一個簡單的舞台緩衝區分配器，用於字節緩衝區。
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// 分配指定大小的緩衝區並返回對其的可變引用。
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // 安全: 這是構造可變項的唯一功能
        // 參考 `self.buffers`。
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // 安全: 我們從不從 `self.buffers` 中刪除元素，因此請參考
        // 只要 `self` 保留，任何緩衝區中的數據都將保留。
        &mut buffers[i]
    }
}