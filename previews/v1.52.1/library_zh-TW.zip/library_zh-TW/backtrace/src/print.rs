#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// 回溯的格式化程序。
///
/// 不管回溯本身來自何處，都可以使用此類型來打印回溯。
/// 如果您使用的是 `Backtrace` 類型，則其 `Debug` 實現已使用此打印格式。
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// 我們可以打印的打印樣式
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// 打印一個簡短的回溯，理想情況下僅包含相關信息
    Short,
    /// 打印包含所有可能信息的回溯
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// 創建一個新的 `BacktraceFmt`，它將輸出寫入到提供的 `fmt` 中。
    ///
    /// `format` 參數將控制回溯打印的樣式，`print_path` 參數將用於打印文件名的 `BytesOrWideString` 實例。
    /// 此類型本身不執行任何文件名打印，但是需要執行此回調。
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// 打印將要打印的回溯的前導。
    ///
    /// 在某些平台上，這是必需的，以便在以後完全符號化回溯，否則，這應該只是在創建 `BacktraceFmt` 之後調用的第一個方法。
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// 將框架添加到回溯輸出。
    ///
    /// 該提交返回 `BacktraceFrameFmt` 的 RAII 實例，該實例可用於實際打印幀，並且在銷毀時它將增加幀計數器。
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// 完成回溯輸出。
    ///
    /// 目前這是一個空操作，但為實現 future 與 backtrace 格式的兼容性而添加。
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // 當前不操作 - 包括此 hook 以允許添加 future。
        Ok(())
    }
}

/// 僅用於回溯的一幀的格式化程序。
///
/// 此類型由 `BacktraceFmt::frame` 函數創建。
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// 使用此幀格式化程序打印 `BacktraceFrame`。
    ///
    /// 這將遞歸打印 `BacktraceFrame` 中的所有 `BacktraceSymbol` 實例。
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// 在 `BacktraceFrame` 中打印 `BacktraceSymbol`。
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: 這樣我們就不會打印任何東西了，這不是很好
            // 使用非 utf8 文件名。
            // 幸運的是，幾乎所有東西都是 utf8，所以這應該不太糟。
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// 通常從此 crate 的原始回調中打印原始跟踪的 `Frame` 和 `Symbol`。
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// 將原始幀添加到回溯輸出中。
    ///
    /// 與以前的方法不同，此方法採用原始參數，以防它們來自不同位置。
    /// 注意，對於一幀可以多次調用。
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// 將原始幀添加到 backtrace 輸出中，包括列信息。
    ///
    /// 與前面的方法一樣，此方法採用原始參數，以防它們來自不同位置。
    /// 注意，對於一幀可以多次調用。
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // 紫紅色無法在過程中進行符號化，因此它具有一種特殊的格式，可用於以後進行符號化。
        // 在此處打印，而不用我們自己的格式打印地址。
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // 無需打印 "null" 幀，這基本上意味著系統回溯有點渴望超遠地回溯。
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // 為了減少 Sgx 飛地中的 TCB 大小，我們不想實現符號解析功能。
        // 相反，我們可以在此處打印地址的偏移量，以後可以將其映射為正確的功能。
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // 打印框架的索引以及框架的可選指令指針。
        // 如果我們超出該幀的第一個符號，儘管我們只打印適當的空格。
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // 接下來，寫出符號名稱，如果我們有完整的回溯，請使用其他格式來獲取更多信息。
        // 在這裡，我們還處理沒有名稱的符號，
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // 最後，打印出 filename/line 編號 (如果有)。
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line 是在符號名稱下的行上打印的，因此請打印一些適當的空格以使我們自己右對齊。
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // 委託給我們的內部回調以打印文件名，然後打印出行號。
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // 添加列號 (如果有)。
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // 我們只關心框架的第一個符號
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}