use core::ffi::c_void;
use core::fmt;

/// 檢查當前的調用堆棧，將所有活動幀傳遞到提供的閉包中以計算堆棧跟踪。
///
/// 該函數是該庫在計算程序的堆棧跟踪時的主要功能。給定的閉包 `cb` 是 `Frame` 的實例，這些實例表示有關堆棧上該調用幀的信息。
/// 該閉包以自上而下的方式生成框架 (最近稱為 `函數`)。
///
/// 閉包的返回值指示回溯是否應繼續。`false` 的返回值將終止回溯並立即返回。
///
/// 一旦獲取了 `Frame`，您可能希望調用 `backtrace::resolve`，將 `ip` (指令指針) 或符號地址轉換為 `Symbol`，通過該 `Symbol` 可以了解名稱或者文件名 / 行號。
///
///
/// 請注意，這是一個相對較低級別的函數，例如，如果您想捕獲回溯以供以後檢查，則 `Backtrace` 類型可能更合適。
///
/// # 必備功能
///
/// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
///
/// # Panics
///
/// 該功能力求永遠不要 panic，但是如果 `cb` 提供了 panics，則某些平台將強制使用雙 panic 中止該進程。
/// 某些平台使用 C 庫，該庫在內部使用無法解開的回調，因此從 `cb` 發出驚慌可能會導致進程中止。
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // 繼續回溯
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// 與 `trace` 相同，只是不安全，因為它未同步。
///
/// 該功能沒有同步保證人，但是當未編譯此 crate 的 `std` 功能時可用。
/// 有關更多文檔和示例，請參見 `trace` 函數。
///
/// # Panics
///
/// 有關 `cb` 恐慌的警告，請參見 `trace` 上的信息。
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// 代表回溯的一幀的 trait 產生於該 crate 的 `trace` 函數。
///
/// 跟踪函數的關閉將產生框架，並且實際上將分派該框架，因為直到運行時才知道底層實現。
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// 返回此幀的當前指令指針。
    ///
    /// 通常，這是在框架中執行的下一條指令，但並非所有實現都以 100％的精度列出該指令 (但通常非常接近)。
    ///
    ///
    /// 建議將此值傳遞給 `backtrace::resolve`，以將其轉換為符號名稱。
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// 返回此幀的當前堆棧指針。
    ///
    /// 如果後端無法恢復該幀的堆棧指針，則返回空指針。
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// 返回此函數框架的起始符號地址。
    ///
    /// 這將嘗試將 `ip` 返回的指令指針回退到函數的開頭，並返回該值。
    ///
    /// 但是，在某些情況下，後端只會從該函數返回 `ip`。
    ///
    /// 如果 `backtrace::resolve` 在上面給定的 `ip` 上失敗，則有時可以使用返回值。
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// 返回框架所屬模塊的基地址。
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // 首先需要確保 Miri 優先於主機平台
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // 僅在 dbghelp 中使用象徵
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}