use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// 擁有和自包含的回溯的表示形式。
///
/// 此結構可用於捕獲程序中各個點的回溯，然後用於檢查當時的回溯。
///
///
/// `Backtrace` 通過其 `Debug` 實現支持回溯的漂亮打印。
///
/// # 必備功能
///
/// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // 此處的幀從堆棧的頂部到底部列出
    frames: Vec<BacktraceFrame>,
    // 我們認為索引是回溯的實際開始，省略了 `Backtrace::new` 和 `backtrace::trace` 之類的框架。
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// 回溯中幀的捕獲版本。
///
/// 從 `Backtrace::frames` 作為列表返回此類型，它表示捕獲的回溯中的一個堆棧幀。
///
/// # 必備功能
///
/// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// 回溯中捕獲的符號版本。
///
/// 此類型從 `BacktraceFrame::symbols` 作為列表返回，並表示回溯中符號的元數據。
///
/// # 必備功能
///
/// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// 在此函數的調用位置捕獲回溯，並返回一個擁有的表示形式。
    ///
    /// 此功能對於將回溯表示為 Rust 中的對像很有用。此返回值可以跨線程發送並在其他位置打印，並且該值的目的是完全獨立的。
    ///
    /// 請注意，在某些平台上，獲取完整的回溯並加以解決可能非常昂貴。
    /// 如果對您的應用程序來說成本太高，建議改用 `Backtrace::new_unresolved()`，它避免了符號解析步驟 (通常花費最長的時間)，並允許將其推遲到以後的日期。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // 要確保這裡有一個框架要刪除
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// 與 `new` 相似，除了它不解析任何符號外，它僅將回溯捕獲為地址列表。
    ///
    /// 稍後，可以調用 `resolve` 函數將回溯的符號解析為可讀的名稱。
    /// 之所以存在此功能，是因為解析過程有時會花費大量時間，而任何一條回溯線僅很少被打印出來。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // 沒有符號名稱
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // 現在顯示符號名稱
    /// ```
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    ///
    ///
    #[inline(never)] // 要確保這裡有一個框架要刪除
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// 返回捕獲此回溯時的幀。
    ///
    /// 該片的第一個條目可能是函數 `Backtrace::new`，而最後一幀則可能與此線程或主函數的啟動方式有關。
    ///
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// 如果此回溯是從 `new_unresolved` 創建的，則此函數會將回溯中的所有地址解析為其符號名稱。
    ///
    ///
    /// 如果此回溯先前已解決或通過 `new` 創建，則此功能不執行任何操作。
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// 與 `Frame::ip` 相同
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// 與 `Frame::symbol_address` 相同
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// 與 `Frame::module_base_address` 相同
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// 返回此框架對應的符號列表。
    ///
    /// 通常，每幀只有一個符號，但是有時如果將多個函數內聯到一幀中，則會返回多個符號。
    /// 列出的第一個符號是 "innermost function"，而最後一個符號是最外面的 (最後一個調用方)。
    ///
    /// 請注意，如果此框架來自未解決的回溯，則將返回一個空列表。
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// 與 `Symbol::name` 相同
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// 與 `Symbol::addr` 相同
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// 與 `Symbol::filename` 相同
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// 與 `Symbol::lineno` 相同
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// 與 `Symbol::colno` 相同
    ///
    /// # 必備功能
    ///
    /// 此功能需要啟用 `backtrace` crate 的 `std` 功能，並且默認情況下啟用 `std` 功能。
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // 在打印路徑時，我們嘗試剝離 cwd (如果存在)，否則我們僅按原樣打印路徑。
        // 請注意，我們也只對短格式執行此操作，因為如果已寫滿，則可能要打印所有內容。
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}