//! 一個有助於在 Windows 上管理 dbghelp 綁定的模塊
//!
//! Windows 上的回溯跟踪 (至少對於 MSVC) 在很大程度上通過 `dbghelp.dll` 及其包含的各種功能提供支持。
//! 這些功能當前是 `動態` 加載的，而不是靜態鏈接到 `dbghelp.dll`。
//! 目前，這是由標準庫完成的 (理論上是由標準庫完成的)，但是由於回溯通常是非常可選的，因此它旨在幫助減少庫的靜態 dll 依賴性。
//!
//! 話雖如此，`dbghelp.dll` 幾乎總是成功地加載到 Windows 上。
//!
//! 請注意，儘管由於我們是動態加載所有這些支持，所以我們實際上不能在 `winapi` 中使用原始定義，而是需要自己定義函數指針類型並使用它。
//! 我們真的不想複製 Winapi，因此我們擁有 Cargo 功能 `verify-winapi`，該功能斷言所有綁定都與 winapi 中的綁定匹配，並且此功能已在 CI 上啟用。
//!
//! 最後，您會在這裡註意到 `dbghelp.dll` 的 dll 從未卸載，這是當前故意的。
//! 我們的想法是，我們可以全局緩存它，並在調用 API 之間使用它，從而避免了昂貴的 loads/unloads。
//! 如果這對於檢漏儀或類似的設備來說是個問題，我們可以在到達那裡時過橋。
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// 解決 Winapi 本身中不存在的 `SymGetOptions` 和 `SymSetOptions` 的問題。
// 否則，僅在我們針對 winapi 再次檢查類型時使用。
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // 尚未在 winapi 中定義
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // 這是在 winapi 中定義的，但不正確 (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // 尚未在 winapi 中定義
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// 該宏用於定義 `Dbghelp` 結構，該結構內部包含我們可能加載的所有函數指針。
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` 的已加載 DLL
            dll: HMODULE,

            // 我們可能使用的每個函數的每個函數指針
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // 最初我們還沒有加載 DLL
            dll: 0 as *mut _,
            // 最初，所有函數都設置為零，以表示需要動態加載它們。
            //
            $($name: 0,)*
        };

        // 每種功能類型的便利 typedef。
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// 嘗試打開 `dbghelp.dll`。
            /// 如果成功，則返回成功; 如果 `LoadLibraryW` 失敗，則返回錯誤。
            ///
            /// Panics (如果已加載庫)。
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // 我們要使用的每種方法的功能。
            // 調用時，它將讀取緩存的函數指針或將其加載並返回加載的值。
            // 斷言負載成功。
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // 方便代理使用清理鎖來引用 dbghelp 函數。
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// 初始化從 crate 訪問 `dbghelp` API 函數所需的所有支持。
///
///
/// 請注意，此功能是 `安全的`，它在內部具有自己的同步功能。
/// 另請注意，可以安全地遞歸多次調用此函數。
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // 我們需要做的第一件事就是同步這個功能。可以從其他線程並發調用，也可以在一個線程內遞歸調用。
        // 請注意，這比這要復雜得多，因為在此過程中，我們在此使用的 `dbghelp` 還必須與所有其他調用方同步到 `dbghelp`。
        //
        // 通常，在同一過程中實際上沒有太多對 `dbghelp` 的調用，我們可以放心地假設我們是唯一訪問它的人。
        // 但是，還有一個主要的其他用戶，我們不得不擔心的是諷刺的是我們自己，但是在標準庫中。
        // Rust 標準庫依賴於此 crate 來支持回溯，並且該 crate 也存在於 crates.io 上。
        // 這意味著，如果標準庫正在打印 panic 回溯，則它可能與來自 crates.io 的 crate 競爭，從而導致段錯誤。
        //
        // 為了幫助解決此同步問題，我們在此處採用了 Windows 特有的技巧 (畢竟，這是 Windows 特有的關於同步的限制)。
        // 我們創建一個 *session-local* 名為互斥體來保護此調用。
        // 這裡的意圖是，標準庫和此 crate 不必共享 Rust 級別的 API 即可在此處進行同步，而是可以在後台進行操作以確保它們彼此同步。
        //
        // 這樣，當通過標準庫或 crates.io 調用此函數時，我們可以確保獲取了相同的互斥鎖。
        //
        // 因此，所有這些就是說，我們在這裡要做的第一件事就是原子地創建一個 `HANDLE`，它是 Windows 上的一個名為互斥體。
        // 我們與專門共享此功能的其他線程進行了一些同步，並確保該功能的每個實例僅創建一個句柄。
        // 請注意，句柄一旦存儲在全局變量中就永遠不會關閉。
        //
        // 實際執行鎖定後，我們只需獲取它，然後我們遞出的 `Init` 句柄將最終負責將其刪除。
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // 好，! 現在我們已經安全地同步了，讓我們開始處理所有內容。
        // 首先，我們需要確保在此過程中實際加載了 `dbghelp.dll`。
        // 我們動態地執行此操作以避免靜態依賴性。
        // 從歷史上講，這樣做是為了解決怪異的鏈接問題，它的目的是使二進製文件具有更高的可移植性，因為這在很大程度上只是調試實用程序。
        //
        //
        // 打開 `dbghelp.dll` 後，我們需要在其中調用一些初始化函數，下面將對其進行詳細說明。
        // 不過，我們只執行一次，因此我們有一個全局布爾值指示我們是否已經完成。
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // 確保設置了 `SYMOPT_DEFERRED_LOADS` 標誌，因為根據 MSVC 自己的文檔: "This is the fastest, most efficient way to use the symbol handler."，讓我們開始吧!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // 實際上使用 MSVC 初始化符號。請注意，這可能會失敗，但是我們將其忽略。
        // 本身並沒有很多現有技術，但是 LLVM 內部似乎忽略了這裡的返回值，並且 LLVM 中的一個消毒劑庫在失敗時會發出可怕的警告，但從長遠來看基本上會忽略它。
        //
        //
        // Rust 出現了很多情況，就是標準庫和 crates.io 上的 crate 都想競爭 `SymInitializeW`。
        // 歷史上，標準庫大多數時候都想初始化然後進行清理，但是現在它使用的是 crate，這意味著某個人將首先進行初始化，而另一個人將進行該初始化。
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}