#![feature(no_core)]
#![no_core]

// 有關為何需要此 crate 的信息，請參見 rustc-std-workspace-core。

// 重命名 crate 以避免與 liballoc 中的 alloc 模塊衝突。
extern crate alloc as foo;

pub use foo::*;