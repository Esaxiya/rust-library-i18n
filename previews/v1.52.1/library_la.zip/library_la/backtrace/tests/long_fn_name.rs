use backtrace::Backtrace;

// L-character moduli nomine
mod _234567890_234567890_234567890_234567890_234567890 {
    // L-mores efficere nominis
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Long mutilari, ut munus est nomen (MAX_SYM_NAME: I) ingenia.
// Hoc test run tantum de msvc, cum gnu procer "<no info>" omnes admittit.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // X repetitiones nominis artem efficere ut X atleast *plene qualified munus est nomen (L + L)=MM characteres diu* II.
    //
    // Est et cum iam actu includit `::`, et `<>` nomine hodiernam moduli
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}