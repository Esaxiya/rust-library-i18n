use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Quod oratio est figura propono, et transiens usque ad certum signum Agricola.
///
/// Et datis munus spectant sursum haec inscriptio in areas sicut locus typicus mensam dynamic signum mensam aut PUMILUS CIMICO info (activated fretus in implementation) ut signum cedere.
///
///
/// Et Agricola sin autem nolite vocari senatus non potuit divinae factae recteque dicitur non plus quam semel et quoque potest apud inlined ex munera.
///
/// Symbola certa `addr` ad supplicium dabat Personam gerunt: redeuntem file/line quae pairs in electronica (si available).
///
/// `Frame` Nota ut si vos have in suus et suadetur ut in unum `resolve_frame` munus in loco isto.
///
/// # requiritur features
///
/// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
///
/// # Panics
///
/// Hoc munus studeret numquam panic est, sed si tunc aliqui Vestibulum panics `cb` provisum est duplex opprimere panic processus est privata fetu suo.
/// Quidam platforms C bibliotheca uti callbacks utitur quam qui ex interiore parte per revolutaque pensa non potest esse, et potest trigger est processum `cb` TREPIDANS de privata fetu suo.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // spectare corpore summo
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// A frame ad propono ante capere symbolo traditur in symbolo transiens usque ad praefinitum Agricola.
///
/// Quia hoc idem facit functin `resolve` accipit nisi oratio pro `Frame` argumentum.
/// Hoc potest quodam suggestu de implementations backtracing providere informationes signum, vel magis accurate notitia de inline erunt in exemplum.
///
/// Suus commendatur uti potes si hoc.
///
/// # requiritur features
///
/// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
///
/// # Panics
///
/// Hoc munus studeret numquam panic est, sed si tunc aliqui Vestibulum panics `cb` provisum est duplex opprimere panic processus est privata fetu suo.
/// Quidam platforms C bibliotheca uti callbacks utitur quam qui ex interiore parte per revolutaque pensa non potest esse, et potest trigger est processum `cb` TREPIDANS de privata fetu suo.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // spectare corpore summo
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Values IP acervum tabulas ab typically es (always?) disciplinam *a* post ipsam vocationem id est acervus vestigium.
// Ct signis huius filename/line in causas supra praemisit quod unum numero est inanis, si in fortasse suus 'prope ad extremum munus.
//
// Hoc plerumque videtur esse semper in omni casu Vestibulum, IP certus est ab deme sic semper it propono est ad priorem vocationem disciplinam disciplinam loco cum rediit.
//
//
// Hoc autem non Ideally.
// Ideally nos requirere tamquam salutores ad manually `resolve` APIs hic rationem et id quod volunt facere -1 notitia location ad priorem * * disciplinam, non hodiernam.
// Ideally si volumus nos sumus exponuntur `Frame` in altera quidem ex inscriptione disciplinam aut vena.
//
// Nunc enim satis est quod iussisti, etsi de iusta sic subtrahit se ab interiori semper.
// Et custodiant questus pulchellus consumerent opus bonum praecessi, sic ut sit satis.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Ex eadem Homilia `resolve`, unsynchronized suus 'tantum ac periculum.
///
/// Hoc munus guarentees synchronization autem non habet et quod is available `std` pluma est non huius crate in castro.
/// Ecce enim in `resolve` munus magis atque documentis exempla.
///
/// # Panics
///
/// Nam videre notitia ad `resolve` caveats TREPIDANS in `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Sicut `resolve_frame` solum quia suus 'unsynchronized parum tuta.
///
/// Hoc munus guarentees synchronization autem non habet et quod is available `std` pluma est non huius crate in castro.
/// Videre enim potius munus documenta et `resolve_frame` exempla.
///
/// # Panics
///
/// Ecce enim notitia in `resolve_frame` caveats TREPIDANS in `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// A trait qui est resolutio in symbolo a lima.
///
/// Haec enim exhibuistis trait sicut object trait ad Agricola `backtrace::resolve` munus datum est, et missum est fere incognita est, ut qui eam post exsequendam est.
///
///
/// Symbolum contextual indici possit officio ut nominis name linea numero definito oratio etc.
/// Non omnis notitia semper praesto sunt in parabola autem omnes modi ut reverterentur ad `Option`.
///
///
pub struct Symbol {
    // TODO: tandem tenetur necessitatibus perstaretur `Symbol` aevum,
    // sed fractionis quod currently a mutatione.
    // `Symbol` Nunc enim quia hoc tutum non esse traditur ab referat semper, et non potest cloned.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Refert nomen huic munus.
    ///
    /// Et rediit ad structuram fieri potest query variis proprietatibus de symbolo nomen tuum:
    ///
    ///
    /// * Et in `Display` implementation demangled imprimere in speciem adsumendum.
    /// * Et rudis `str` valorem sacramenti potest accessed (utf-8 si verum est).
    /// * Quod symbolum nomen rudis bytes possunt accessed.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Et incipiens inscriptio huius refert munus.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Rudis archive refert ad scalpere ut.
    /// Hoc est maxime utile enim `no_std` ambitum mutandum.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Ubi ad hoc ventum est currently hinc est, et columna numerum refert.
    ///
    /// Gimli currently solum Hic praebet et valorem tune refert `Some` `filename` tantum; et ideo non est similis caveats et per id in.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Unde numerus figura sit amet redire versus faciendi.
    ///
    /// Hic reditus `Some` pretii sit si `filename` typically refert `Some`, et per id in caveats similis.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Refert ad hanc lima nomen eius ibi munus legeret.
    ///
    /// Est currently libbacktrace vel Gimli nisi cum praesto est usus (eg
    /// unix platforms aliis) congestum est, et cum binarii debuginfo.
    /// Neuter horum ergo verisimile redire `None` occurrit.
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Maybe a parsed C++ symbolo, si symbolum constituere quasi Rust defecit parsing perpessa maeruerit.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Fac, ut hic nullus mediocri, ut `cpp_demangle` pluma habet cum debilitatum sumptus.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// A serratus circum symbolum accessors ergonomic nomen providere in nomen demangled in bytes rudis, rudis ad filum, etc.
///
// Cum autem mortuus `cpp_demangle` factura non patitur nam codice enabled.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Nomen rudis underlying aliud symbolum quam a bytes gignit.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Refert insigne (mangled) rudis in nomine significata est, si valet pro `str` utf-8.
    ///
    /// Utere, si vis ad `Display` implementation demangled version.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Refert rudis in nomine symbolum est album of bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Et hoc ut ea typis imprimi demangled si Symbolum verum fraus non est, et hic tractamus et errore per gratiam labiorum suorum habebit in exteriorem partem non pervulgare non destitit.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Memoriam revocare conatus conditivo esse solebat symbolicate oratio.
///
/// Hanc modum curabit global notitia structurae dimittere quis globally qui secus conditivo esse aut in sequela seu notitia quod typically PUMILUS parsed similes repraesentant.
///
///
/// # Caveats
///
/// Hoc munus dum semper praesto sit, non actualiter in aliquid plus implementations.
/// Libraries similis dbghelp libbacktrace aut providere, ne facilities ad deallocate et gere statum memoriae datum est.
/// `gimli-symbolize` quia iam pluma huius crate pluma ubi hoc munus esse solus habet ullum effectum.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}