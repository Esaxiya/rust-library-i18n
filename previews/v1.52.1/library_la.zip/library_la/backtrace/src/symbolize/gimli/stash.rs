// solum usus est in dextera Linux modo sinere ut alibi codice mortuis
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// A simplex arenam allocator ad byte buffers.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Allocates ad praefinitum quiddam a mole rerum invisibilium visibiliumque ad illud redit.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // Utilitatibus consulens hoc munus solus molitur, ut semper rerum invisibilium visibiliumque
        // referiat `self.buffers` est.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // Salus: neque enim removere ab elementis `self.buffers`, ut referat de
        // si intus in notitia dummodo `self` non quasi quiddam non vivet.
        &mut buffers[i]
    }
}