//! Uti ad subsidium symbolication `gimli` crate in crates.io
//!
//! Hoc default symbolication implementation pro Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Stabilis mendacium sit vita Domini et trucidabunt circa subsidium sui indigentiam, comparativum, structs.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Issem, stabilis in signo esset solum vita post `map` mutuari et `stash` et conservandam infra erant.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Nam in Windows libraries loading patria, videatur in aliquam disputationem rust-lang/rust#71060 ad rietates hic.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Libraries currently MinGW gloriaris non ASLR (rust-lang/rust#16514) sed DLLs potest etiam oratio esse in spatio circum relocated.
            // Videtur quod haec oratio in lusione bibliotheca info omnes, ut, si esset librarum apud "image base" ejus, quae est in agro COFF file capitis.
            // Cum debuginfo hoc enim videtur, ut album et mensam parse symbolo quasi ex bibliotheca copia oratio fuit librarum apud "image base" sicut bene.
            //
            // Bibliothecam onerari non "image base" tamen.
            // (Nescio quid loaded est aliud esse potest?), Ubi haec fabula `bias` in agro est, et opus est ut instar sicco a valore `bias` hic.Infeliciter etsi quid suus 'purgare non sunt ex hoc habeas onusto modulus.
            // Quod si non habeamus autem ipsa est oratio (`modBaseAddr`) onus.
            //
            // Quia iam extra nos, ut sit aliquantulus of a cop mmap tabella, tabella header legitur notitia, tunc stillabunt in mmap.Hic youll verisimile est quod attero clausas post mmap: sed hoc operatur ut bene pro nunc satis est.
            //
            // Postquam habemus `image_base` (desideravit onus locus) et `base_addr` (etiam onus loco) non potest replete in `bias` (differentia inter ipsam et desideravit) et hoc quod dicitur oratio cuiusque segmentis dorsalibus est `image_base` ex eo est quod lima dicit.
            //
            //
            // Nunc apparet ut dissimilis ELF/MachO possumus facere cum facere per unum quodpiam bibliotheca, per quam tota magnitudo `modBaseSize`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS utitur enim Mac-o q.e. DYLD et operum specialium APIs to load a album of patria libraries, quae pars application.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Arcessere hac bibliotheca nomen Domini qui conjunctus est ei quæ viam ubi load ut bene.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Header,&delegatis ad imaginem huius bibliotheca load `object` ad parse imperium omnium onus non possumus ut instar sicco omnes partes insunt.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iterate super segmenta et rationem regiones quia segments notum esse invenimus.
            // Urbicum saepe post dispensando illud SEGMENTUM Additionally record informationem vide infra comment.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // "slide" determinare ad hanc bibliothecam, quae tandem esse studia utimur ut instar sicco qua obiecti in memoria oneratas.
            // Computation est aliquantulus fatum quamquam et de paucis quae est in solitudine quaerit propter quid, et cum haeret.
            //
            // `bias` idea communis, quod est in plus est segmentum est iens futurus `stated_virtual_memory_address` qua in re electronica spatium spatio extremo residet.
            // Et alia fidentes in nobis res est, quod etsi minus est oratio verum est index `bias` spectare sursum et in symbolo debuginfo mensam.
            //
            // Vertit sicco tamen quod haec ratio loaded libraries calculations esse falsa.Nam patria executables tamen, quod videtur verum.
            // Levantes autem quodam speciali quadam ratione ex fonte LLDB s-TEGIMENTUM in prima sectione `__TEXT` qui subveherent ex file offset 0 nonzero cum magnitudine.
            // Dum omni causa videtur quod est forma tantum ad mensam pro bibliotheca vmaddr volutpat.
            // Si ergo illud signum est praesens mensam * *, non dicitur per comparationem ad slide in vmaddr plus segmentum est scriptor statuto oratio.
            //
            // * * Nec nisi rei hic tractamus ut nos reperio a text lima in offset sectionem nullus tum proventus pondus, statuto de sectiones in textu primo decrescat oratio, et ex omni copia, quod oratio per quam bene.
            //
            // Quod ita significata semper apparet mensa moles pondus in bibliothecam, quae ad quaestionem.
            // Hic eventus videtur ad ius habent figura et per mensam designatur.
            //
            // Honeste Non omnino certus sum quod vel est vel debet esse non est aliquid aliud indicant quam ut hoc facere.
            // (?) Nunc etsi hoc videtur satis bene operari semper et non possunt ad tweak ut in hoc tempore, si necesse est.
            //
            // Pro magis notitia aliquid videatur #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Alii Unix (eg
        // Linux) uti platforms ELF formae q.e. ratione obiecti et ad effectum deducendi proprie dicitur `dl_iterate_phdr` API libraries patria turpis.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` ut validum esse indicibusque.
        // `vec` monstratorem a `std::Vec` sit valida.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 non paternus support CIMICO info: sed et aedificate ratio ponere viam ad CIMICO info `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Omne aliud ELF uti oportet, sed non scis quomodo load libraries patria.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Sciendum bibliothecis quae communia omnibus plenum.
    libraries: Vec<Library>,

    /// In quo habemus Mappings cache parsed P. notitia.
    ///
    /// Hoc album liftime quae non addat, habet determinatam proportionem ad totum.
    /// Et `usize` elementum cuiusque supra par est index `libraries` in quo `usize::max_value()` represents hodiernam exsecutabile.
    ///
    /// Quod est `Mapping` correspondentes parsed P. notitia.
    ///
    /// Nota, quod haec te potest basically LRU cache et in circuitu shifting quae significant hic ut oratio.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Haec segmenta sunt in bibliothecam loaded memoriam, ut ubi erant loaded.
    segments: Vec<LibrarySegment>,
    /// Et huius bibliotheca "bias", typically ubi suus 'loaded in memoriam.
    /// Hoc valore est additum parte unaquaque re prope memoriae scriptor est oratio ut ut oratio oneratur in parte.
    /// Additionally istud pondus, et detrahitur a virtualis realis memoria allocutionibus Index debuginfo in signum et in mensa.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Et huius stated oratio lima parte obiecti.
    /// Hoc loaded fraus non sit in spatio sed Haec bibliotheca est `bias` quibus plus in quo est invenire eam.
    ///
    stated_virtual_memory_address: usize,
    /// Magnitudo memoriae ths segmentum.
    len: usize,
}

// id quod requiritur ad esse tutum ab extra potest synchronized
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // id quod requiritur ad esse tutum ab extra potest synchronized
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // A parva valde valde simplex cache LRU ut debug info mappings.
        //
        // Uolnerati rate sit altum valde Cum autem non ACERVUS typical plures transire inter participatur libraries.
        //
        // Quod opera sint satis pretiosa `addr2line::Context` creare.
        // A subsequent `locate` ejus sumptus expectat ut amortized queries, quae eo ordine petierit leverage built ut construens: addr2line::Context`s ut speedups nice quod.
        //
        // Si non hoc cache quod nunquam futurum amortization et symbolicating backtraces ssssllllooooowwww esset.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Primum autem, quod `lib` habet, si test `addr` in quibus cuicunque (relocation tractantem).Reprehendo si manere actu transit transferre possumus oratio.
                //
                // Nota hic, quia erant 'usura `wrapping_add` ne redundantiam checks.+ SVMA quod suus 'been videatur in solitudine computation exundet favor.
                // Sed eventum rei quae videtur a frenum impar ingens moles Non possumus facere, de ea quam ipsi erant 'forsit iustus quoniam hæc segementa ignorare indicantes verisimile est in spatio.
                //
                // Hoc primum est in rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Nunc `lib` scimus `addr` continet, offset cum possimus invenire studia sua ipsa memoria virutal oratio.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Immutabiles: huius enim conditionalis complet absque postquam reversus mane
        // quod ab errore et noti cache Haec est semita ad indicem 0.

        if let Some(idx) = idx {
            // Tabularum cache cum iam movent ut ante.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Cum ad vulgare non in cache: tabularum novam partum, et inserere in conspectu de cache, et ingressum nisi necessariam rem evincere seniorem cache.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ne Leak in vita `'static` facio certus ipsi mox ut suus 'scoped
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // `sym` extendere vita misere requiritur ad `'static` quo hic iturus est sed quis unquam ita ut refertur ad hanc tabulam certe perstare debet.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Denique adepto conditivo vel tabularum novam creare hoc tabularum faciendarum file: et perpendere consectaria quae ad PUMILUS info invenire file/line/name haec inscriptio.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Nos poterant ei locate frame De hoc signo, et dicetis ei addr2line` intra frame est scriptor nitty lapidosum vocabat details omnia.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Non inveniet CIMICO notitia, sed invenimus illud in symbolo a sunt dryadalem exsecutabile mensam.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}