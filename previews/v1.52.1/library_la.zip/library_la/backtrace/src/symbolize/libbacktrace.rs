//! Symbolication belli EBULUM per parsing est in codice libbacktrace.
//!
//! De bibliotheca C libbacktrace, typically gcc distribui sunt, non solum subsidia ad backtrace generating (quam nos non utimur), sed etiam minimae tractantem ac backtrace symbolicating in lusione cum notitia de rebus tamquam simul tabulae et haberent inlined whatnot.
//!
//!
//! Hoc inter se implicatae ex variis lots of de hic autem basic idea est:
//!
//! * Primum `backtrace_syminfo` dicimus.Hoc dynamic figuram accipit significat informationem de mensa Si non possumus.
//! * Deinde vocamus `backtrace_pcinfo`.Parse debuginfo hoc patitur eas recuperare si notitia available es none tabulas filenames linea numerus etc.
//!
//! Ibi est lots non fraudis super questus pumiliones in tables libbacktrace, sed hopefully hoc non sufficit, cum legis finem mundi, et inferius patet.
//!
//! Haec belli symbolication default, et non MSVC OS suggestus, quod non.Etsi in libstd hoc est enim OS default strategy.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Si possibile est ex cuius nomine potius ad `function` debuginfo posse accurate typically exsisto magis pro inline frames exempli.
                // Si autem etsi praesens non cadere ad mensam nomen datum est in signum `symname`.
                //
                // Nota `function`, ut interdum possint sentire paulo minus accurate, exempli gratia quae enumerantur in de `try<i32,closure>` isntead `std::panicking::try::do_call`.
                //
                // Cur patet suus 'non realiter, sed altiore in nomine `function` videtur magis accurate.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // nihil enim iam
}

/// Transierunt monstratorem typus de `data` in `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Callback `backtrace_syminfo` invocatur a nobis incipere hoc olim, cum adhuc appellare `backtrace_pcinfo` solvendis itur.
    // In CIMICO `backtrace_pcinfo` consulam tibi munus recuperet file/line notitia et notitia ut haec faciam tto attemp tum inlined admittit.
    // `backtrace_pcinfo` Nota quod etsi non posse deficere, vel si non multum CIMICO info, et, si fieri, ut certus es vocare nos in callback cum quolibet signo ex `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Transierunt monstratorem type de `data` in `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Et partum nutrit statu API libbacktrace sed sustinere non interficerem flagitare.
// Ego personaliter, ad hoc quod sit status significetur ut creatus et vivet in aeternum.
//
// at_exit() quae tracto amo volo ut subcriptio in hac civitate expurgat et libbacktrace non praebet iter facere.
//
// In his angustiis print immobiliter hoc munus habet rationem status, qui est primus rogatus est dies hæc.
//
// Memento quod accidit omnibus backtracing serially (cincinno inter global).
//
// Nota propter id, quod hic est defectus synchronization `resolve` extra synchronized.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ne exercere threadsafe capabilities de libbacktrace cum eo erant semper in vocantem synchronized fashion.
        //
        0,
        error_cb,
        ptr::null_mut(), // nihil extra notitia
    );

    return STATE;

    // Libbacktrace Nota quod in omni suo actu; sed indiget ut debug info PUMILUS invenire current propter exsecutabile.Eam typice habet inter namque machinationes, quae per numerum, sed non limitatur ad:
    //
    // * /proc/self/exe confirmavit super platforms
    // * Transierunt archive expressis verbis et in quo statu creando
    //
    // Libbacktrace rusticae magna ex C codice est in bibliothecam.Memoria autem rectus est salus nuditates interpretatur hanc potissimum tractandi panosque debuginfo.
    // Libstd currere in multa verba habet historiam.
    //
    // Si igitur possumus /proc/self/exe adhibetur ut hi saepe ignorare id est libbacktrace "mostly correct" et aliud facere non fatum rebus in lusione cum P. "attempted to be correct" info.
    //
    //
    // Si enim in Filename tamen possibile aliquem tunc rostra (sicut BSDs) si steterit actor potest poni in quolibet loco lima.
    // Si enim haec quae modo dicam de libbacktrace a filename per illam sit aliquod file, potest causare segfaults.
    // Non dico quod etsi libbacktrace Si igitur non aliquid est quod non sustinere tabulata dispositis per vias rectas, sicut /proc/self/exe!
    //
    // Ut omne, quod dedit conaretur dura sicut non potest * * a filename per saltum, sed debere nos super aggeres et gloriaris non omnino /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Bene præpositum Nota, quod volumus uti `std::env::current_exe` sed nos requirere non `std` hic.
            //
            // Usus load `_NSGetExecutablePath` ad hodiernam exsecutabile iter in elit regio (quam si suus 'sicut etiam parvum cedere).
            //
            //
            // Nota erant 'quod hic non morietur in gravissime libbacktrace confidens executables corrumpere, sed praedictum est ecce enim ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows aperire files est modus quo suus postquam eam non aperuit delevit.
            // Propterea quod volumus omnino volumus ut nobis non mutatur de nobis post exsecutabile tradere ad libbacktrace, in libera facultas data in spe libbacktrace minuendam (quae coorta).
            //
            //
            // Datum hoc nobis facere conantur, ut sit aliquantulus of a choro hic generis clausum in imagine nostra,
            //
            // * Ut processum hodiernam ansam, ad load filename.
            // * File name aperire, quod est de iure cessat.
            // * Reload est scriptor current processus archive, faciens fideles suus 'idem
            //
            // Si omnis doctrina transit in nobis quidem non est processus file aperuit nobis et dubia non mutantur.Hunc fasciculum fwiw libstd historically libro octoginta trium, et hoc est optimum interpretatio, quae tum evenirent, admirari.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Vestibulum in memoriam redire possumus vivit ..
                static mut BUF: [i8; N] = [0; N];
                // ... et hujus vitam a ACERVUS quoniam suus 'tempus
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // cum eo ut servare etiani hic consulto Leak `handle` ponis quod lima nomen.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Segmentum placentae redire, volumus ut nul terminabitur: ergo si omnia impleta sunt in longitudinem totalis aequalem habebunt, et tunc comparando aequare, quae ad defectum.
                //
                //
                // Alioquin postquam reversus est de victoria, scrutare nul byte scalpere.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace scopis purgatam erroribus currently sub ea pallio
    let state = init_state();
    if state.is_null() {
        return;
    }

    // API `backtrace_syminfo` quam vocant (signum legis a) `syminfo_cb` prorsus appellare debere quondam (et praesumi error in deficere).
    // Non igitur ultra tractamus in `syminfo_cb`.
    //
    // Quia hoc `syminfo` Nota ut te consule signum mensam invenire notitia CIMICO symbolo nomen etiam si illic 'nulla in binarii.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}