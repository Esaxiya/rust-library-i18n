//! A module adiumenta suppeditabit pro administrandi de dbghelp vincula Windows
//!
//! Backtraces Windows supra (saltem pro MSVC) powered sunt late in diversis muneribus, quae continet et `dbghelp.dll`.
//! Hi munera es currently oneratus dynamically * * quam `dbghelp.dll` scripta ad immobiliter.
//! Et hoc est currently fit per vexillum bibliotheca (et est doctrina requiratur ibi), sed auxilium ad redigendum stabilis conatus est de filiabus dll bibliotheca backtraces quod typically es pulchellus libitum.
//!
//! Ut id `dbghelp.dll` fere onera in Windows tincidunt.
//!
//! Nota autem quod etsi omne firmamentum loading erant 'actu, dynamically possumus uti rudis `winapi` in definitionibus, sed opus est uti, ut et ipsi define ad munus monstratorem typus.
//! De nobis et non vere volo ut exsisto in negotio duplicatione winapi, sic nos habere pluma Cargo `verify-winapi`, quae asserit, par illi est in omnibus ligaturis sed haec factura, et winapi enabled a Cl.
//!
//! Denique te `dbghelp.dll` quod nunquam ad note hic est dll expositae de nauibus et quod suus 'currently voluntariam.
//! De cogitandi est et non possumus uti inter vocat globally cache in API, avoiding loads/unloads pretiosa.
//! Si enim hoc est quaestio, ut possint transire pontem quasi aliquid Leak detectors et cum illuc.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Opus circuitu `SymGetOptions` `SymSetOptions` et non ens winapi praesens in se.
// Alioquin si haec tantum essemus usi, tu geminus reprehendo in types winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Non tamen definitum est winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Hoc defined in winapi et falsa est (FIXME winapi#DCCLXVIII-Y)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Non tamen definitum est winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Hoc est tortor definire quae interius continet aedificium `Dbghelp` functio indicibusque ut turpis.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL ut est oneratus `dbghelp.dll`
            dll: HMODULE,

            // Munus munere uti singula singulis indicatorum
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // DLL initio non est loaded
            dll: 0 as *mut _,
            // Initiall posuit ad omnes qui munera nulla sit necesse est dicere quod dynamically loaded.
            //
            $($name: 0,)*
        };

        // Typedef commodum ad munus uniuscuiusque generis.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` aperire conatus.
            /// Si res redit error `LoadLibraryW` si non operetur.
            ///
            /// Si iam Panics bibliotheca loaded.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Ad munus uniuscuiusque modum uti volumus.
            // Et appellavit eum munus monstratorem in print aut legere aut load et revertetur pretii onusta.
            // Onera esse uehementer ammiror.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Uti procuratorem dbghelp munera commodum referat tersus comam nutrient.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialize omnes firmamentum `dbghelp` API munera accedere necesse est ex hoc crate.
///
///
/// Nota, quod iste munus tutum esse ** **, quod est intra suum synchronization.
/// Et quod dicimus necessarium munus recursively multiple vicis.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Hoc est opus primum ad facere est ut synchronize munus.Dici potest simul ex recursively intra stamina filo.
        // Nota fallacior eo quod scriptor quid erant 'usura quia etsi hic `dbghelp`:*et* omnium aliorum necessitates tamquam salutores ad `dbghelp` ut cum congruentibus in hoc processus.
        //
        // Typice non sunt realiter plures, qui vocat ad `dbghelp` in idem processus et possimus tuto supponas, ista probabiliter sumus solus ones accessing est.
        // Est autem una prima alius user habemus anxietas leva planctum super qua ipsi, sed in bibliotheca vexillum.
        // In hac Rust vexillum bibliotheca pendeat crate backtrace pro auxilio, et super crates.io crate etiam existit.
        // Hic modo, ut si a vexillum bibliotheca panic est excudendi backtrace ut genus hoc crate crates.io ex causa segfaults.
        //
        // Ad auxilium solve is forsit synchronization cautela adhibeatur in Fenestra Utilia huc (id est, post omnes, synchronization de angustia in Fenestra-propria).
        // Nos creare loci * * sessionem, nomine Mutex praesidio huius vocationem.
        // Prior enim, ut vexillum et crate bibliotheca non esse posse nisi here instead participes Rust-level opus post scaenae ut synchronize APIs fac Sunt inter se synchronum.
        //
        // Quod si ita est munus dicitur per vexillum seu bibliotheca per crates.io possimus certa, quod non est simile Mutex acquiritur.
        //
        // Ita est, quod omnes esse volumus dicere, quod primum est hie faciemus atomically `HANDLE` quod creare est ex nomine Mutex Windows.
        // Ut synchronize aliquantulus sharing id munus cum alia specie concernit, et relatorum unum tantum, vel gravioribus illis ut exempli gratia creatus per hoc munus.
        // Note ut capulus est non clausus quondam suus 'global conditur.
        //
        // Postquam clausum in nos diximus ire in actu simpliciter sibi, et nostrorum `Init` tradere tractamus enim de illa erit reus omittendae delationis eventually.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Erant synchronized securi omnes sistere illa autem, quae lets actu committitur dispensando.
        // Primum necesse est ut nos omnino `dbghelp.dll` loaded hoc processus.
        // Hoc dynamically sumus stabili ne dependentia.
        // Hoc est historically dictum est opus fit conjunctio circa fatum rebus in animo et ante facere aliquantulus magis binaries portable quod iustum est late debugging ad utilitatem.
        //
        //
        // `dbghelp.dll` aperuit habuimus aliquando in ea munera nobis necesse appellare de initialization, et inferius multo ante lobortis.
        // Non solum hoc iterum, quamquam, ut a global Comperto Boolean ostendens utrum erant 'adhuc factum aut non.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Ut in `SYMOPT_DEFERRED_LOADS` vexillum est posuit, secundum quod importat soUicitudo de hoc proprium MSVC: "This is the fastest, most efficient way to use the symbol handler." sic quod lets 'quid?
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Nam cum signo initialize MSVC.Potest deficient Nota quod, si ignore, sed non.
        // Non illic es a ton ante huic per se, sed ab interiori; LLVM videtur ignorare reditu valorem huc una ex sanitizer libraries LLVM in testimonium, si nullos FORMIDULOSUS, sed hoc incassum fit plerumque in detegere quod ignorat.
        //
        //
        // Rust est causa huius est quia unum est multus ut in bibliotheca vexillum et in isto crate crates.io et volunt Certatim pro `SymInitializeW`.
        // Vexillum et historica bibliotheca et tersus ad initialize voluit most of the time, nunc autem suus 'non significat aliquem crate usura is erit ad initialization, ut initialization primus et alter erit exciperent.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}