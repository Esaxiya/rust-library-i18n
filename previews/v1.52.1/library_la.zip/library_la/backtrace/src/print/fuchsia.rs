use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // callback dl_iterate_phdr accipit a monstratorem ad omne, quod recipere dl_phdr_info DSO qui coniunctus est in processus.
    // dl_iterate_phdr, consulit ut linker est clausum in dynamic de iteration a principio ad finem.
    // Callback si returns a non-valorem cum nulla sit iteration mane terminabitur.
    // 'data' Argumentum ad inebriaberis atque nudaberis et tertia callback ad se vocationem.
    // 'size' dat magnitudinem dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Id opus ad parse et constructum progressio et basic notitia, quae modo ut header postulo aliquantulus de amet supellectilem ex ELF sicut bene.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nunc habemus replicare, propter partem frenum in structuram et usum dl_phdr_info a genus dynamic linker Fuchsia scriptor current.
// Chromium tum etiam est terminus ABI crashpad.
// Eventully nos youd 'amo ut movere ad huiusmodi casibus Dryadalis quaerere, sed youd' postulo ut providere in SDK et tamen non esse quod factum est.
//
// Nos ita (Et) et adhæsit causat reatum habent stricta quae ad hunc modum conjunctionis cum libc Fuchsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Nos autem non est modus intelligendi non valet reprehendo, si e_phoff et e_phnum.
    // quantumcumque Libc nobis tutum curabunt hoc segmentum faciunt hic.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// LXIV frenum in reddo, Elf_Phdr ELF progressio header in scopum endianness de architectura.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr represents validum ELF progressio header et conceptum eius,.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Et habemus nullo modo reprehendo si p_addr p_memsz non est verum.
    // Scaevola parses notis libc in primis hic per quod quantumcumque sit fortis capitis.
    //
    // NoteIter non eget non eget illa interiore notitia est verum, sed verum ut fines.
    // Confidimus libc id quod certissimum est apud nos, quoniam hic.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Quod note genus ædificate pro IDs.
const NT_GNU_BUILD_ID: u32 = 3;

// Sed est contra usus Elf_Nhdr ELF nota header in endianness ad scopum.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Sed est contra usus Nota ELF note (page + header).
// Segmentum nomen relictum u8 quia nulla non reprehendo quod facile fit terminatum rust bytes eitherway compositus.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// Lets vos NoteIter terrore requiescet in repetere annotare segmentum disiungitur.
// Non primum quod terminat error occurs non sunt amplius notas.
// Si irritum est supra repetere, sicut data sit voluntas se habet notas, etsi non sunt inventi.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Est et immutabilis Dei munus monstratorem ut sint valida, et data magnitudine range of bytes qui potest omnia legere.
    // KB his contenta rata esse potest quam quod iuga tutus.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to nationis adsimilat 'x' est,-byte to' dam supposita II 'to' est potestas.
// Et hoc exemplum C, sequitur a vexillum/C ++ ELF in codice parsing (x + sunt: I)&-to adhibetur.
// Rust Non dimittam te, sic uti omnino negamus usize
// 2's conversionem complement ut reficiat, quia.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// ex take_bytes_align4 consumit Num bytes secare (if praesens) et praeterea ut, ex ultima FRUSTUM properlly est varius.
// Uel si maior numerus bytes petivisti scalpere aut parum ex reliquis deinde bytes realigned non esse, nulla mutatio est segmentum rediit.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Hoc munus invariants verum habet, non SALUTATOR est aliud quam fortasse sustinere non varius id 'bytes' debet quoniam perficientur (et ad quaedam rectitudo architectures).
// Determinatis hoc pacto valoribus in campis Elf_Nhdr Hoc munus efficit, non ut res, sed ut ineptias esse.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Dummodo sit in spatio satis tutum est hic et mox confirmata, ut superius dicitur, ut si in his non sit tutum.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Nota quod sice_of: :<Elf_Nhdr>() IV-byte varius semper.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Si enim Reprehendo venimus in finem.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Quod eiusdem est transmutare nos de nhdr scrutatus fueris: sed ut inde artem efficere.
        // Nos autem namesz aut descsz non habeat fiduciam et non faciet male fida iudiciis fundatur super genus.
        //
        // Etiamsi non est ex impetro nobis debet esse completum quisquiliarum tutum.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indicat segmentum exsecutabile.
const PERM_X: u32 = 0b00000001;
/// Indicat segmentum writable.
const PERM_W: u32 = 0b00000010;
/// Fegmentum readable indicat.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Reddo Segmentum necesse sunt dryadalem in runtime.
struct Segment {
    /// Runtime virtual dat oratio argumenta huius segmenti.
    addr: usize,
    /// Segmentum argumenta magnitudo memoriae tradidit.
    size: usize,
    /// Virtual oratio dat modulus de hoc segmentum cum ELF lima.
    mod_rel_addr: usize,
    /// ELF in dat file facultates concedere.
    /// Sed minime Runtime licentias licentias adesse istos.
    flags: Perm,
}

/// Segmenta iterate in uno ex DSO tradidit.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// DSO represents necesse sunt dryadalem (Dynamic Shared Object).
/// Hoc references the genus ipsa notitia repono in DSO facere quam exemplum suum.
struct Dso<'a> {
    /// Semper motum Linker celebremus nomen quidem vacuum nomen.
    /// In pelagus causa in nomen huius exsecutabile erit inanis.
    /// In hoc casu se communicent atque conferant object erit soname (videatur DT_SONAME).
    name: &'a str,
    /// Scaevola binaries aedificaverunt IDs fere in hoc non proprie requierment.
    /// Nulla suus 'non ut par est DSO ELF realis notitia lima cum a nobis requirere quod postea, si non est ita build_id DSO habent omnes hic.
    ///
    /// DSO est sine build_id neglecta sunt.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Item Segmenta refert an per hoc DSO iterator.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// His erroribus encode exitibus ut consurgens per parsing informationem de DSO.
///
enum Error {
    /// NameError occurrit in errorem minime, ut convertantur a style linea C in linea rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError est aedificate id, quod non invenient.
    /// Id vel hoc vel quia aedificatis segmento DSO nulla deformis est id quo constructum.
    ///
    BuildIDError,
}

/// Neque enim DSO 'error' 'dso' vocat aut coniuncta Linker incitatus in processu.
///
///
/// # Arguments
///
/// * `visitor` - Qui enim manducat DsoPrinter A una vocatur modi DSO if.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // quae ad validum et dl_iterate_phdr fit ut info.name locus.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Hoc munus Fraxinus excelsior symbolizer Markup procer ex in DSO continebat omnes informationes.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}