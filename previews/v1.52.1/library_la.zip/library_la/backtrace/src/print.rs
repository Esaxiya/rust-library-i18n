#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// A formatter ad backtraces.
///
/// Hoc potest ad genus procer backtrace id ipsum est, ubi de backtrace.
/// Si habes ergo `Backtrace` genus ejus `Debug` jam implementation printing utitur hac forma.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Ad nosmet ipsos printing et quod possint imprimere
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Prints a brevius backtrace qui idealiter pertinet solum continere informationes
    Short,
    /// Et quod contineat omnia possibilia notitia procer backtrace
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Quod output ad scribendum novum creare `BacktraceFmt` `fmt` provisum.
    ///
    /// Et `format` control ratio erit backtrace genus quod exprimitur ratio et voluntas `print_path` solebat imprimendi `BytesOrWideString` exempla filenames.
    /// Hoc genus ipsum vero non est aliqua printing filenames sed requiritur quod id callback.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Praeambula ad procer ut ut backtrace typis.
    ///
    /// Quia platforms aliquid requiritur ad hoc quod plene backtraces symbolicated postea erit; et aliter hunc modum primum oportet iustum esse autem vocatis `BacktraceFmt` post creando.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Adiungit ad backtrace replo output.
    ///
    /// Hoc sibi redeunt ad raii `BacktraceFrameFmt` ex admonitione lapidis, quae non potest esse actu typis replo, et in exitio eius erit contra frame incremento est.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Vertentis perficit cursum backtrace output.
    ///
    /// Haec sit amet neque a pro-op addidit future sed backtrace convenientiam cum forma.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Currently in nullo op-- inter hook hoc sinere future per viam additionis.
        Ok(())
    }
}

/// A formatter quia sicut unum de frame backtrace.
///
/// Hoc genus creatus est in `BacktraceFmt::frame` munus.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Prints a frame `BacktraceFrame` hoc formatter.
    ///
    /// Hoc autem totum recursively `BacktraceSymbol` exempla typis in `BacktraceFrame`.
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Nullos enim intra `BacktraceSymbol` `BacktraceFrame`.
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: tandem ut ne non aliquid excudendi
            // cum non-utf8 filenames.
            // Gratanter utf8 pene omnia ita non esse nimis.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Et investigari `Frame` clauorum `Symbol` crudum typice intra huius crate callbacks metus.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// A frame ad adiungit rudis backtrace output.
    ///
    /// Haec modum sicut in vetere, in sumit rationes rudis si ipsi erant 'ens ab alia fonte locis.
    /// Multiplex singulas horas nota dicetur.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Vir rudis adiungit frame ad backtrace output, inter columna notitia.
    ///
    /// Et hoc modo sicut prior, rationes sumit tegmina cruda si sunt, erant 'non fons ex diversis locis.
    /// Multiplex singulas horas nota dicetur.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fraxinus excelsior inter significare nequit processus ut habet speciale forma adhiberi potest significare quam post.
        // Typis excudendi, quae pro sui forma in oratio hic.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Non "null" opus ad procer corporibus utuntur, id est basically solum quod ratio backtrace erant aliquantulus longe Super reducimus student.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Ad redigendum in mole Sgx TCB enclave, et non vis resolutio ad effectum deducendi signum functionality.
        // Sed ut offset possit imprimi hie oratio est, quae posset bene mapped ad munus postea.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Imprimendi ad libitum disciplinam itemque indicem frame ad frame de regula.
        // Si sumus ultra parabola haec primo frame iustus procer Etsi oportet whitespace.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Next significata est perscribere est nomine utens alterni si formatting sumus pro magis notitia est plena backtrace.
        // Ecce nos etiam tractamus qui non habent signum nomen tuum,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Et stabit autem: procer sicco si tu filename/line numerus available.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line Sub nomine figura impressa ad lineas et figuras whitespace exstat iuris competens nos color.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Callback delegamus nostrae filum imprimendi typis name tum numerus.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Columnae numero Add si available.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Tantum curant, signum est de primo frame
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}