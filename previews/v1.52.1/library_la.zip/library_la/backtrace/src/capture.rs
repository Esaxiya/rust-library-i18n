use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Owned repraesentatio sui, et backtrace continebat.
///
/// Hanc structuram potest capere possunt a pluribus locis in backtrace progressio inspicere solebat, et post id quod fuit in illo tempore backtrace.
///
///
/// `Backtrace` sustinet satis excudendi, ex backtraces per suam `Debug` implementation.
///
/// # requiritur features
///
/// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Quoque tabulis quae enumerantur hic de summo, imo-usque in Stack
    frames: Vec<BacktraceFrame>,
    // Index credimus, quod in ipsa est initium backtrace pro pecoribus eorum et erunt sicut `Backtrace::new` `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Versio captum a frame in backtrace.
///
/// Hoc genus album is rediit ut ex uno BIBLIOTHECA frame `Backtrace::frames` nosque veluti in backtrace caperetur.
///
/// # requiritur features
///
/// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Versio capi signum in backtrace.
///
/// Hoc genus `BacktraceFrame::symbols` est de rediit ut album repraesentatur et quasi adpensum quid ob metadata in backtrace.
///
/// # requiritur features
///
/// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Et captures backtrace callsite in munus hoc, owned reversus ad suum intelligibile.
    ///
    /// Quasi repraesentans utile munus backtrace Rust obiectum.Hoc potest rediit valore misit relatorum per typis et alibi et ad valorem hujus plane est esse se continebat.
    ///
    /// Nota quod in aliquo platforms plena backtrace suscipiendam atque solvendis non potest esse maxime pretiosa.
    /// Quia si pretium non nimium suadetur ut pro suus application quod utor `Backtrace::new_unresolved()` vitat insigne gradus resolutio (quod typically longissimum accipit) et postea date ad quod concedit, addendo alios.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // fac vis hie non ad removendum a frame
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Nisi aliquam `new` quod non similes characteres propono, hoc est simpliciter captures backtrace ut album est oratio.
    ///
    /// Postea ad propono hoc `resolve` functionem possis appellare ad signum in readable backtrace scriptor nomina.
    /// Quia consilium est munus processus quis autem aliquando spatium notabile backtrace nisi raro ut procer.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // nullum nomen Signum
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // iam nunc nomen symboli
    /// ```
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    ///
    ///
    #[inline(never)] // fac vis hie non ad removendum a frame
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Ex quo capta backtrace artus redeunt.
    ///
    /// Primum est verisimile quod munus ingressum in hoc segmentum `Backtrace::new`, et ultima frame sit verisimile aliqua ut de hac filo subtegminis usque pelagus munus incipiat.
    ///
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Si backtrace creata a `new_unresolved` igitur hoc munus tibi propono in backtrace omnes inscriptiones et mysticis nominibus.
    ///
    ///
    /// Si backtrace ante certus nec creatus est in `new`, hoc munus habet quidquam.
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Sicut `Frame::ip`
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Sicut `Frame::symbol_address`
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Sicut `Frame::module_base_address`
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Anni reverso tempore frame quod album litterarum obruamur, correspondet amori.
    ///
    /// Northmanni non est nisi per unam frame figura, aliquando autem, si multis et munera multa symbola et reddidit sunt inlined in singulis tabulis supponentur.
    /// Primum symbola enumerantur est "innermost function", cum sit ultima significat principium (novissimo RECENS).
    ///
    /// Nota quod Huic igitur ex dubitabilis backtrace revertetur vacua elit.
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Sicut `Symbol::name`
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Sicut `Symbol::addr`
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Sicut `Symbol::filename`
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Sicut `Symbol::lineno`
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Sicut `Symbol::colno`
    ///
    /// # requiritur features
    ///
    /// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Ubi figere gressus cwd si detrahere velimus esse, ut non secus iter iustus procer.
        // Hoc tantum Nota, quod etiam est forma brevis, scilicet quod, si nos vis imprimere omnia plena est.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}