use core::ffi::c_void;
use core::fmt;

/// - Vocationem spectat current'acervi omnes transeuntes activae ad continendas tabulas Agricola provisum est, calculari'acervi vestigium.
///
/// Hoc workhorse munus est in hac bibliotheca et in calculo progressio ad acervum vestigia.Data est clausurae tradiderunt `cb` exempla de notitia `Frame` repraesentant invocantibus in ACERVUS artus.
/// Dedere terga summo-descendit est Agricola et in fashion (maxime nuper munera prima dicitur).
///
/// Agricola est scriptor valorem argumentum sit, an reditus backtrace debet pergo.De reditu `false` valorem A erit ad terminandum backtrace redeo.
///
/// Et verisimile est `Frame` statim acquiritur `backtrace::resolve` vocare volunt convertere `ip` (disciplinam none) seu symbolo, per quem oratio ad `Symbol` nomen et/aut name/linea numero non posse didicit.
///
///
/// Nota autem Hoc est relative humili gradu munus-et, si velis, exempli gratia,&solæ inspiciendæ postea ceperunt de backtrace, tunc magis `Backtrace` genus sit oportet.
///
/// # requiritur features
///
/// Hoc autem munus exigit `std` enabled pluma est ut `backtrace` crate et factura `std` enabled per default.
///
/// # Panics
///
/// Hoc munus studeret numquam panic est, sed si tunc aliqui Vestibulum panics `cb` provisum est duplex opprimere panic processus est privata fetu suo.
/// Quidam platforms C bibliotheca uti callbacks utitur quam qui ex interiore parte per revolutaque pensa non potest esse, et potest trigger est processum `cb` TREPIDANS de privata fetu suo.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // permanere autem backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Sicut `trace`, suus 'solum quia minus securum putavimus unsynchronized.
///
/// Hoc munus guarentees synchronization autem non habet et quod is available `std` pluma est non huius crate in castro.
/// Videre enim potius `trace` documenta et munus exempla.
///
/// # Panics
///
/// Ecce enim notitia in `trace` caveats TREPIDANS in `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// A trait representing unum frame a backtrace concesserant `trace` crate hoc munus.
///
/// Et repetens munus Agricola s quiescenti conciliari poterit tremor, quod fundamentum implementation pro mittit ferme frame quod non semper sit nota, donec runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Refert hodiernam monstratorem huius frame disciplinam.
    ///
    /// Hoc facere disciplinam tunc Northmanni denique membris, sed non omnes C% accurationem apud implementations album est (plerumque tamen suus 'pulchellus propinquus).
    ///
    ///
    /// Commendatur `backtrace::resolve` convertendi in hunc insigne pretium ejus.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Hoc refert hodiernam frame acervum regula.
    ///
    /// In causa esse potest ad recuperet backend ACERVUS frame haec regula, quod nullam a monstratorem reddidit.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Et incipiens refert insigne munus huius inscriptio est frame.
    ///
    /// Haec temptaturum ut ad disciplinam rewind munus monstratorem rediit in `ip` ad initium, quod reversus valorem.
    ///
    /// Interdum autem revertetur `ip` backends erit sicut hoc munus.
    ///
    /// Et reddidit valorem potest esse aliquando defuit nisi `backtrace::resolve` in `ip` datum desuper.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Base inscriptio Anni reverso tempore frame quod pertinet ad Dei modulus.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Hic necesse prius ut se prius exercitum Miri amet
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // in tantum significant dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}