#![feature(no_core)]
#![no_core]

// Ecce rustc-core std-ad-workspace crate cur hoc opus est.

// Secunda nomine obviare qui ponuntur in crate ne alloe module in liballoc.
extern crate alloc as foo;

pub use foo::*;