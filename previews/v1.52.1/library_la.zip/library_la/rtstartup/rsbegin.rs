// rsbegin.o et rsend.o sunt "compiler runtime startup objects" dicitur.
// Quae recte codice est non opus ad initialize compiler runtime.
//
// Cum exsecutabile est imago seu dylib coniunctum, omnes user codice libraries, et inter haec duo sint "sandwiched" object files, ut ex codice sive notitia rsbegin.o facti sunt in primis Sectionibus reddi imaginem Dei, cum de codice et data rsend.o facti sunt ultima ones.
// Hoc potest ad modum est signum seu a principio ad finem est sectionem, sicut ad inserere quid requiratur ut caput capitis aut pes.
//
// Moduli iam ingressum esse in re nota sita est in object C startup runtime (plerumque dicitur `crtX.o`), provocatque initialization tum quod runtime callbacks aliis components (descripserunt sed per imaginem sectione aliud speciale).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Beginning of marcas frame ACERVUS unwind sectione info
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Nam internus est unwinder Scratch spatii libri, diligentissime custodiatur.
    // Et hoc dicitur esse in `struct object` GCC $/unwind, dw2, fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Solvuntur info registration/deregistration consuetudines.
    // Ecce enim importat soUicitudo de libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // startup moduli a subcriptio unwind info
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // in shutdown Unregister
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Utilia MinGW init/uninit exercitatione adnotatione
    pub mod mingw_init {
        // MinGW obiecti in startup (crt0.o/dllcrt0.o) sanctificationem habebunt constructors in global .ctors et .dtors in sectiones startup et exitus.
        // DLLs in hoc autem est ac destravit DLL oneratur.
        //
        // Et quale erit in linker sectiones, callbacks quo fit ut voluntas nostra sita sunt ad finem list.
        // Errant Constructors Ex diverso ordine prima et ultima callbacks annuam ut interficerentur.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *, C initialization callbacks
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *; C termino callbacks
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}