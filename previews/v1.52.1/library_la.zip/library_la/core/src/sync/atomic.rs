//! types nuclei
//!
//! Memoria, partis rationes praebere nuclei primo colloquio fila simul et aliorum generum aedificium cuneos.
//!
//! Versions of definit cuius moduli rationem nuclei delectos priscae ac figura inter [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], etc.
//! Types res praesens nuclei, quae cum recte adhibetur, synchronize updates inter relatorum.
//!
//! Mutuo sumit [`Ordering`] repraesentans illam vim memoriae impedimentum operationis.Hæ vices [C++20 atomic orderings][1] idem sunt.Enim magis notitia videre [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Variables ad participes nuclei: pax inter relatorum ([`Sync`] ad effectum deducendi), sed ne pro se praebent ad mechanism de sharing principem et [threading model](../../../std/thread/index.html#the-threading-model) Rust.
//!
//! Sic plerumque atomicus partem ponere in [`Arc`][arc] variabilem (regula communis numeratur in atomically, referuntur).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Vestibulum types variables, ut nuclei mandentur condita vetustati, initialized in usus initializers sicut [`AtomicBool::new`] constant.Nuclei Statica saepe solebat pro global piger initialization.
//!
//! # Portability
//!
//! Per omnes nuclei types Cuius moduli, utpote quae veneranda sit [lock-free] si praesto es.Hoc est a global acquirit interne non Mutex.Insidiatur ut genera operationum atomi praestantur libero.
//! Qualem Id quod-PERMUTO `fetch_or` adimpleantur conferas cum ansa.
//!
//! Potest nuclei res implemented per lavacrum disciplinam, maius in mole Atomics.Uti eg IV tabulata de nuclei instructiones ad effectum deducendi `AtomicI8`-byte.
//! Nota ut si zelum non habere infringere ipsam notionem quam recte atque ordine imperatorem codice, suus 'iustus a res ut conscientiam.
//!
//! Cuius moduli non potest in nuclei types per omnia available in tabulatis adlevatae.Et nuclei types hic crees, omnes tamen, quod plerumque non existentium credibilis felicitatis.Insignes exceptiones Quaedam;
//!
//! * PowerPC et cum MIPS platforms XXXII bits non `AtomicU64` argumentis seu rationibus `AtomicI64`.
//! * ARM ut Vestibulum `armv5te` quae non solum providere Linux `load` `store` operationes et ne sustinere et PERMUTO (CAS) opera comparare quale `swap`, `fetch_add` etc.
//! Additionally in Linux: hi sunt CAS implemented per [operating system support] res, quam ut veniam cum perficientur damus.
//! * ARM et scuta cum `thumbv6m` `load` `store` operationes solum providere ne comparare et PERMUTO (CAS) sustinere opus quale `swap`, `fetch_add` etc.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! future platforms Nota quod qui potest et non addidit subsidium nuclei res aliqua.Maxime volo ad invigilandum est portable in codice qui sint, eadem nuclei.
//! `AtomicUsize` et `AtomicIsize` sunt fere maxime portable, sed etiam quod tunc non es available ubique.
//! Nam referat in `std` monstratorem-amplitudo Atomics bibliotheca requirit, quamvis non `core`.
//!
//! Currently `#[cfg(target_arch)]` youll 'postulo utor codice cum praesertim est in lege componat Atomics.Est etiam `#[cfg(target_has_atomic)]` instabilis, cuius erit stabilita in future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! A simplex spinlock;
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Exspecta clausum in altera fila legenda viro dimittere
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Comitem a global servare vivere relatorum;
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Inter participatur A Boolean recte possumus quam generis relatorum.
///
/// Representation est eiusdem generis haec in memoria, ut [`bool`].
///
/// ** ** Nota: hoc genus super platforms est tantum available ut nuclei support et pabula brumae ire `u8` onerat.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Initialized in sunt gignit `AtomicBool` `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Mitte ad AtomicBool implemented, implicatur.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// A monstratorem genus rudis quae potest tuto inter participatur relatorum.
///
/// Hoc est genus repraesentativum similiter in memoriam, sicut `*mut T`.
///
/// ** ** Nota: hoc genus platforms est tantum available in quibus omnis inminet et pabula brumae ire onerat nuclei indicibusque.
/// Magnitudine sua monstratorem est scriptor scopum positum in magnitudine.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// `AtomicPtr<T>` nullam a se gignit.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Memoria nuclei vices
///
/// Vices modo atomi speciem synchronise memoria memoriae operationes.
/// Apud molle [`Ordering::Relaxed`], nisi in memoria operationem directe tetigit est synchronized.
/// Contra est cellarium onere insuper et duo reliqua [`Ordering::SeqCst`] synchronise conservare res quaeque genere per omnia summa celeritate.
///
///
/// Rust in memoria [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) vices sint.
///
/// Pro magis notitia [nomicon] video.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Exigentiis ordinis non solum nuclei res.
    ///
    /// Respondet [`memory_order_relaxed`] in C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Cum coniungar autem copia omnia factus iussit in conspectu omnis res prior [`Acquire`] onus hoc valore ex (aut fortius) Hæ vices.
    ///
    /// Praesertim aestimanda sunt retro compacta, inquit, se videnda sistunt in omnibus relatorum se praestare [`Acquire`] (vel plus), onus hoc valore.
    ///
    /// Notitiam combines ut usura is ordo enim est operatio, quae ducit ad [`Relaxed`] onus onerat ciborumque horrea hoc operandi?
    ///
    /// Est modo res in hoc ordine teneri possunt praestare, quod a copia.
    ///
    /// Respondet [`memory_order_release`] in C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Ubi onus accepta cum perpetuo: Si pretii onusta scripta sunt per operationem [`Release`] reponunt (vel plus) importat studium quoddam igitur res subsequent omnia factus iussit postquam copia.
    /// In specie subsequent onerat notitia scriptum in conspectu videbis in copia.
    ///
    /// Per Notitia quod haec ordinatio est ob illam operationem combines stores leads onerat, et ad operationem [`Relaxed`] copia!
    ///
    /// Hic ordo est applicabilis ad res soli praestare possunt, qui est onus.
    ///
    /// Respondet [`memory_order_acquire`] in C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Effectis [`Acquire`] habet utrumque simul, et [`Release`]:
    /// Ad secundum dicendum quod [`Acquire`] onerat ordinem tenet.Stores [`Release`] est enim in ordinatione utitur.
    ///
    /// Notitia apud se de `compare_and_swap` est operatio fieri potest ut ne tandem aliquo faciendo inde nec illis copia [`Acquire`] iusta ordinatione.
    ///
    /// Sed `AcqRel` praestare non [`Relaxed`] febrium.
    ///
    /// Haec ratio est tantum res quae pertinet ad utramque iungentes ciborumque horrea hoc est onerat.
    ///
    /// Respondet [`memory_order_acq_rel`] in C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Like [`Acquire`]/[`Release`]/[`AcqRel`](enim onus, copia et copia-ad-onus res, respective) praestabit, ut idem continue omnes omnia vident consistent relatorum eadem est res in ordine .
    ///
    ///
    /// Respondet [`memory_order_seq_cst`] in C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] `false` initialized in sunt.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Novam gignit `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Refert ad subjectam [`bool`] mutabilem uerteretur.
    ///
    /// Polliceri se referat, quod tutum est uoluntas mutabilis alius relatorum nuclei qui sunt simul obvius notitia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // Salutem et mutabili referat praestat unique detentio.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Ut nuclei aditus ad `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // Utilitatibus consulens referat praestat unique mutabili rerum atque
        // tum membrorum dispositione sub vestibus et `bool` I `Self` est.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Sumit continebat valorem ad nuclei redit.
    ///
    /// `self` tutum est, quod transeat per valorem alius relatorum polliceri, qui sunt simul accessing nuclei sunt data.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Frumentum desiderat de valore ex bool.
    ///
    /// `load` describit rationem accipit [`Ordering`] memoriae operationem ordinari.
    /// Values possibilia sunt [`SeqCst`], et [`Acquire`] [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Aut si Panics `order` est [`Release`] [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // Salute data ulla impediuntur tribus intrinsics atomi et metus
        // Transierunt in regula, quod sit verum ex nos got ut referat.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Et addit valorem ad bool.
    ///
    /// `store` describit rationem accipit [`Ordering`] memoriae operationem ordinari.
    /// Values possibilia sunt [`SeqCst`], et [`Release`] [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Aut si Panics `order` est [`Acquire`] [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // Salute data ulla impediuntur tribus intrinsics atomi et metus
        // Transierunt in regula, quod sit verum ex nos got ut referat.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Recondit a valore ad bool, reverti ad priorem valorem.
    ///
    /// `swap` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
    /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
    ///
    ///
    /// **Note:** Hoc nuclei quibus omnis inminet super aggeres modum esse available tantum in operations `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // Salute data generis atomi intrinsics impediuntur.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Stores [`bool`] si vis praesens in valore est idem quod `current` valorem.
    ///
    /// De reditu valorem semper priorem valorem.Si aequalis `current` igitur updated pretium.
    ///
    /// `compare_and_swap` per quae describitur [`Ordering`] argumentum sumit ex memoria et ratio huius operatio.
    /// Et cum usus est Notitia [`AcqRel`] et deficient operationem Et ideo, ut in `Acquire` onus praestare, sed non `Release` semantics.
    /// Usus facit [`Acquire`] copia pars [`Relaxed`] si fieri hoc operandi, et utendi [`Release`] facit [`Relaxed`] pars onus.
    ///
    /// **Note:** Hoc nuclei quibus omnis inminet super aggeres modum esse available tantum in operations `u8`.
    ///
    /// # `compare_exchange` esse ut et `compare_exchange_weak`
    ///
    /// `compare_and_swap` nam tali `compare_exchange` tabularum vices aequiparatur;
    ///
    /// originale |victoria |defectum,
    /// -------- | ------- | -------
    /// solvit |solvit |Acquire remissa |Durum |Posside Release |release |AcqRel remissa |AcqRel |Posside SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` licet spuriously et deficere in quo sequitur, collatio, quam in compiler concedit conferre et VERTO cum codice generare meliorem ecclesiam adhibetur in loop.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Stores [`bool`] si vis praesens in valore est idem quod `current` valorem.
    ///
    /// Et reditu ostendit eventus pretii est, an pretii novum scriptum est quibus et priorem valorem.
    /// Valor aequalis rebus `current` praestatur.
    ///
    /// `compare_exchange` [`Ordering`] memoria rationum paria ordinatio describitur operatio.
    /// `success` requiratur describitur per vices legere ad mutare-quod-operationem fit, si collatio ecclesiæ scribe in `current` MISERIT.
    /// `failure` describitur onus enim requiritur dispositio ad operationem, quae est quando non est similis ratio.
    /// [`Acquire`] victoria uti pro copia pars haec ordinatio facit [`Relaxed`] operatio et usus facit [`Release`] felix [`Relaxed`] onus.
    ///
    /// Defectum ordinis tantum [`SeqCst`], aequivalere debet [`Relaxed`] [`Acquire`] aut res quam ratio an infirmior.
    ///
    /// **Note:** Hoc nuclei quibus omnis inminet super aggeres modum esse available tantum in operations `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // Salute data generis atomi intrinsics impediuntur.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Stores [`bool`] si vis praesens in valore est idem quod `current` valorem.
    ///
    /// Secus [`AtomicBool::compare_exchange`], hic munus licet spuriously deficient et cum sequitur, collatio, quam in codice aliquo potest esse in pluribus agentibus platforms.
    ///
    /// Et reditu ostendit eventus pretii est, an pretii novum scriptum est quibus et priorem valorem.
    ///
    /// `compare_exchange_weak` [`Ordering`] memoria rationum paria ordinatio describitur operatio.
    /// `success` requiratur describitur per vices legere ad mutare-quod-operationem fit, si collatio ecclesiæ scribe in `current` MISERIT.
    /// `failure` describitur onus enim requiritur dispositio ad operationem, quae est quando non est similis ratio.
    /// [`Acquire`] victoria uti pro copia pars haec ordinatio facit [`Relaxed`] operatio et usus facit [`Release`] felix [`Relaxed`] onus.
    /// Defectum ordinis tantum [`SeqCst`], aequivalere debet [`Relaxed`] [`Acquire`] aut res quam ratio an infirmior.
    ///
    /// **Note:** Hoc nuclei quibus omnis inminet super aggeres modum esse available tantum in operations `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // Salute data generis atomi intrinsics impediuntur.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logica "and" cum Boolean valorem.
    ///
    /// Logica "and" operetur operationem in praesens argumentum quod de `val`, et occidere effectus novus ad valorem.
    ///
    /// Priorem refert ad valorem.
    ///
    /// `fetch_and` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
    /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
    ///
    ///
    /// **Note:** Hoc nuclei quibus omnis inminet super aggeres modum esse available tantum in operations `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // Salute data generis atomi intrinsics impediuntur.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logica Boolean "nand" et valorem.
    ///
    /// "nand" facit rationis et ratio operandi in current valorem `val`, et occidere effectus novus ad valorem.
    ///
    /// Priorem refert ad valorem.
    ///
    /// `fetch_nand` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
    /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
    ///
    ///
    /// **Note:** Hoc nuclei quibus omnis inminet super aggeres modum esse available tantum in operations `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Facere non possumus, quod hic potest uti atomic_nand consequuntur bool scriptatur cum inrita per valorem.
        // Hoc accidit quod nuclei operatio interius fit integer et ad VIII-frenum quod posuit se in superius VII bits.
        //
        // Sic iustus utor pro fetch_xor non PERMUTO.
        if val {
            // ! (A&verae)== !x debemus invertant bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (X&falsa)==vero debemus ex posuit bool est verum.
            //
            self.swap(true, order)
        }
    }

    /// Logica "or" cum Boolean valorem.
    ///
    /// Operetur operationem rationis "or" in current valorem ratio et `val` et occidere effectus novus ad valorem.
    ///
    /// Priorem refert ad valorem.
    ///
    /// `fetch_or` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
    /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
    ///
    ///
    /// **Note:** Hoc nuclei quibus omnis inminet super aggeres modum esse available tantum in operations `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // Salute data generis atomi intrinsics impediuntur.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Cum logica "xor" Boolean valorem.
    ///
    /// "xor" operatio rationis facit ratio est vis praesens et `val`, et occidere effectus novus ad valorem.
    ///
    /// Priorem refert ad valorem.
    ///
    /// `fetch_xor` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
    /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
    ///
    ///
    /// **Note:** Hoc nuclei quibus omnis inminet super aggeres modum esse available tantum in operations `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // Salute data generis atomi intrinsics impediuntur.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Refert mutabiliter est regula ad underlying [`bool`].
    ///
    /// Facientes, non nuclei legit et scribit in notitia fit integrum potest esse genus.
    /// Et hoc maxime utilis in modum FFI, ubi munus uti signature, ut pro `*mut bool` `&AtomicBool`.
    ///
    /// Ex communi regula reddendo `*mut` atomi necessarium propter ipsam mutabilitatem nuclei intus operantur rationes.
    /// Utilitas communis in omni mutatione modificationibus atomicus quantum et quamdiu incolumis licet operationibus utuntur atomica.
    /// Aliqua regula requirit usum rediit rudis in obstructionum `unsafe` et corroboret est idem absolute: est enim res in esse nuclei.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Omnes electos valorem, et munus etiam in ea, quae redit ad libitum in novum valorem.Si autem `Ok(previous_value)` `Result` refert ad munus `Some(_)` rediit, `Err(previous_value)` aliud.
    ///
    /// Note: Glorificatum: appellare Divinum hoc munus plures temporibus ad valorem si mutata est ab alio interim relatorum, ut dum refert `Some(_)` munus, sed munus erit quondam fuisse tantum applicari ad valorem stored.
    ///
    ///
    /// `fetch_update` [`Ordering`] memoria rationum paria ordinatio describitur operatio.
    /// Primum describitur per quando requiritur dispositio requiritur ordo describitur secundus est operatio dum tandem pro onerat.
    /// Correspondent vices [`AtomicBool::compare_exchange`] successus et inopia est.
    ///
    /// [`Acquire`] usura ratio ut planto copia victoria hac parte [`Relaxed`] operandi, et utendi [`Release`] onus [`Relaxed`] felix facit extremum.
    /// In tantum (failed) onere [`SeqCst`] ordine, inferiorem [`Acquire`] vel fortuna vel aequivalens [`Relaxed`] debeat ordinare.
    ///
    /// **Note:** Hoc nuclei quibus omnis inminet super aggeres modum esse available tantum in operations `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// `AtomicPtr` novam gignit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Refert ad commutabile quae subditos eosque monstratorem.
    ///
    /// Polliceri se referat, quod tutum est uoluntas mutabilis alius relatorum nuclei qui sunt simul obvius notitia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Get aditus ad nuclei monstratorem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - Mutabile referat unique vindicat proprietatis.
        //  - et omnia idem `Self` alignment `*mut T` Vestibulum rust subnixus, verificata est.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Sumit continebat valorem ad nuclei redit.
    ///
    /// `self` tutum est, quod transeat per valorem alius relatorum polliceri, qui sunt simul accessing nuclei sunt data.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Frumentum desiderat est a valorem indicatorum.
    ///
    /// `load` describit rationem accipit [`Ordering`] memoriae operationem ordinari.
    /// Values possibilia sunt [`SeqCst`], et [`Acquire`] [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Aut si Panics `order` est [`Release`] [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // Salute data generis atomi intrinsics impediuntur.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Et addit valorem ad monstratorem.
    ///
    /// `store` describit rationem accipit [`Ordering`] memoriae operationem ordinari.
    /// Values possibilia sunt [`SeqCst`], et [`Release`] [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Aut si Panics `order` est [`Acquire`] [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // Salute data generis atomi intrinsics impediuntur.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Recondit a valore ad monstratorem, prior reversus valorem.
    ///
    /// `swap` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
    /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
    ///
    ///
    /// **Note:** Hoc est tantum available modum nuclei res ex quibus omnis inminet super aggeres indicibusque.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // Salute data generis atomi intrinsics impediuntur.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Est in regula Stores valorem, si eadem sit vis praesens et `current` valorem.
    ///
    /// De reditu valorem semper priorem valorem.Si aequalis `current` igitur updated pretium.
    ///
    /// `compare_and_swap` per quae describitur [`Ordering`] argumentum sumit ex memoria et ratio huius operatio.
    /// Et cum usus est Notitia [`AcqRel`] et deficient operationem Et ideo, ut in `Acquire` onus praestare, sed non `Release` semantics.
    /// Usus facit [`Acquire`] copia pars [`Relaxed`] si fieri hoc operandi, et utendi [`Release`] facit [`Relaxed`] pars onus.
    ///
    /// **Note:** Hoc est tantum available modum nuclei res ex quibus omnis inminet super aggeres indicibusque.
    ///
    /// # `compare_exchange` esse ut et `compare_exchange_weak`
    ///
    /// `compare_and_swap` nam tali `compare_exchange` tabularum vices aequiparatur;
    ///
    /// originale |victoria |defectum,
    /// -------- | ------- | -------
    /// solvit |solvit |Acquire remissa |Durum |Posside Release |release |AcqRel remissa |AcqRel |Posside SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` licet spuriously et deficere in quo sequitur, collatio, quam in compiler concedit conferre et VERTO cum codice generare meliorem ecclesiam adhibetur in loop.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Est in regula Stores valorem, si eadem sit vis praesens et `current` valorem.
    ///
    /// Et reditu ostendit eventus pretii est, an pretii novum scriptum est quibus et priorem valorem.
    /// Valor aequalis rebus `current` praestatur.
    ///
    /// `compare_exchange` [`Ordering`] memoria rationum paria ordinatio describitur operatio.
    /// `success` requiratur describitur per vices legere ad mutare-quod-operationem fit, si collatio ecclesiæ scribe in `current` MISERIT.
    /// `failure` describitur onus enim requiritur dispositio ad operationem, quae est quando non est similis ratio.
    /// [`Acquire`] victoria uti pro copia pars haec ordinatio facit [`Relaxed`] operatio et usus facit [`Release`] felix [`Relaxed`] onus.
    ///
    /// Defectum ordinis tantum [`SeqCst`], aequivalere debet [`Relaxed`] [`Acquire`] aut res quam ratio an infirmior.
    ///
    /// **Note:** Hoc est tantum available modum nuclei res ex quibus omnis inminet super aggeres indicibusque.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // Salute data generis atomi intrinsics impediuntur.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Est in regula Stores valorem, si eadem sit vis praesens et `current` valorem.
    ///
    /// Secus [`AtomicPtr::compare_exchange`], licet munus hoc sequitur, collatio cum spuriously deficient et qui non consequuntur aliqui ex pluribus agentibus codice tabulatis adlevatae.
    ///
    /// Et reditu ostendit eventus pretii est, an pretii novum scriptum est quibus et priorem valorem.
    ///
    /// `compare_exchange_weak` [`Ordering`] memoria rationum paria ordinatio describitur operatio.
    /// `success` requiratur describitur per vices legere ad mutare-quod-operationem fit, si collatio ecclesiæ scribe in `current` MISERIT.
    /// `failure` describitur onus enim requiritur dispositio ad operationem, quae est quando non est similis ratio.
    /// [`Acquire`] victoria uti pro copia pars haec ordinatio facit [`Relaxed`] operatio et usus facit [`Release`] felix [`Relaxed`] onus.
    /// Defectum ordinis tantum [`SeqCst`], aequivalere debet [`Relaxed`] [`Acquire`] aut res quam ratio an infirmior.
    ///
    /// **Note:** Hoc est tantum available modum nuclei res ex quibus omnis inminet super aggeres indicibusque.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SALUS: Haec operates per se parum tutum est, quod in rudis monstratorem
        // sed quod pro certo verum est regula (ut iustus got an ex hoc quod nos habemus per `UnsafeCell` reference) et nuclei operatio se tuto ad nobis concedit mutate `UnsafeCell` de contentis in eodem.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Omnes electos valorem, et munus etiam in ea, quae redit ad libitum in novum valorem.Si autem `Ok(previous_value)` `Result` refert ad munus `Some(_)` rediit, `Err(previous_value)` aliud.
    ///
    /// Note: Glorificatum: appellare Divinum hoc munus plures temporibus ad valorem si mutata est ab alio interim relatorum, ut dum refert `Some(_)` munus, sed munus erit quondam fuisse tantum applicari ad valorem stored.
    ///
    ///
    /// `fetch_update` [`Ordering`] memoria rationum paria ordinatio describitur operatio.
    /// Primum describitur per quando requiritur dispositio requiritur ordo describitur secundus est operatio dum tandem pro onerat.
    /// Successu et defectum [`AtomicPtr::compare_exchange`] correspondent vices sunt.
    ///
    /// [`Acquire`] usura ratio ut planto copia victoria hac parte [`Relaxed`] operandi, et utendi [`Release`] onus [`Relaxed`] felix facit extremum.
    /// In tantum (failed) onere [`SeqCst`] ordine, inferiorem [`Acquire`] vel fortuna vel aequivalens [`Relaxed`] debeat ordinare.
    ///
    /// **Note:** Hoc est tantum available modum nuclei res ex quibus omnis inminet super aggeres indicibusque.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Conuerti fecerit `bool` est in `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Quo efficitur tortor aliquam architectures reposuit.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Type unum integrum quod participatur tute poterunt inter relatorum.
        ///
        /// Eiusdem generis haec est, in memoria interiore repraesentabat ac integrum genus: [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Nam nuclei de modo inter species et genera ut etiam non-nuclei informationem de portability huius generis, in [module-level documentation] videbis.
        ///
        ///
        /// **Note:** Et hoc est tantum available genus onerat super aggeres et pabula brumae ire nuclei support quod [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// An nuclei initialized in integrum `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Mitte sit implemented per sensum.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Novam gignit nuclei integrum.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Refert subiectum ad commutabile quemcunque integrum affirmativum.
            ///
            /// Polliceri se referat, quod tutum est uoluntas mutabilis alius relatorum nuclei qui sunt simul obvius notitia.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() V=;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// CXXIII mut some_int=fiat,
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, C);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - Mutabile referat unique vindicat proprietatis.
                //  - `$int_type` `Self` alignment et idem secundum promissionem relinquam $cfg_align est.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Sumit continebat valorem ad nuclei redit.
            ///
            /// `self` tutum est, quod transeat per valorem alius relatorum polliceri, qui sunt simul accessing nuclei sunt data.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Frumentum desiderat ad valorem de nuclei quemcunque integrum affirmativum.
            ///
            /// `load` describit rationem accipit [`Ordering`] memoriae operationem ordinari.
            /// Values possibilia sunt [`SeqCst`], et [`Acquire`] [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Aut si Panics `order` est [`Release`] [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Thesaurizat nuclei vim in in integrum.
            ///
            /// `store` describit rationem accipit [`Ordering`] memoriae operationem ordinari.
            ///  Values possibilia sunt [`SeqCst`], et [`Release`] [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Aut si Panics `order` est [`Acquire`] [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Thesaurizat nuclei ad valorem vir integer, reverti ad priorem valorem.
            ///
            /// `swap` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
            /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
            ///
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Ad valorem thesaurizat nuclei ad idem integer, si vis praesens et `current` valorem.
            ///
            /// De reditu valorem semper priorem valorem.Si aequalis `current` igitur updated pretium.
            ///
            /// `compare_and_swap` per quae describitur [`Ordering`] argumentum sumit ex memoria et ratio huius operatio.
            /// Et cum usus est Notitia [`AcqRel`] et deficient operationem Et ideo, ut in `Acquire` onus praestare, sed non `Release` semantics.
            ///
            /// Usus facit [`Acquire`] copia pars [`Relaxed`] si fieri hoc operandi, et utendi [`Release`] facit [`Relaxed`] pars onus.
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` esse ut et `compare_exchange_weak`
            ///
            /// `compare_and_swap` nam tali `compare_exchange` tabularum vices aequiparatur;
            ///
            /// originale |victoria |defectum,
            /// -------- | ------- | -------
            /// solvit |solvit |Acquire remissa |Durum |Posside Release |release |AcqRel remissa |AcqRel |Posside SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` licet spuriously et deficere in quo sequitur, collatio, quam in compiler concedit conferre et VERTO cum codice generare meliorem ecclesiam adhibetur in loop.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Ad valorem thesaurizat nuclei ad idem integer, si vis praesens et `current` valorem.
            ///
            /// Et reditu ostendit eventus pretii est, an pretii novum scriptum est quibus et priorem valorem.
            /// Valor aequalis rebus `current` praestatur.
            ///
            /// `compare_exchange` [`Ordering`] memoria rationum paria ordinatio describitur operatio.
            /// `success` requiratur describitur per vices legere ad mutare-quod-operationem fit, si collatio ecclesiæ scribe in `current` MISERIT.
            /// `failure` describitur onus enim requiritur dispositio ad operationem, quae est quando non est similis ratio.
            /// [`Acquire`] victoria uti pro copia pars haec ordinatio facit [`Relaxed`] operatio et usus facit [`Release`] felix [`Relaxed`] onus.
            ///
            /// Defectum ordinis tantum [`SeqCst`], aequivalere debet [`Relaxed`] [`Acquire`] aut res quam ratio an infirmior.
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Ad valorem thesaurizat nuclei ad idem integer, si vis praesens et `current` valorem.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// licet spuriously id munus et deficient cum collatio sequitur quod aliquid possit esse in pluribus agentibus codice in tabulatis adlevatae.
            /// Et reditu ostendit eventus pretii est, an pretii novum scriptum est quibus et priorem valorem.
            ///
            /// `compare_exchange_weak` [`Ordering`] memoria rationum paria ordinatio describitur operatio.
            /// `success` requiratur describitur per vices legere ad mutare-quod-operationem fit, si collatio ecclesiæ scribe in `current` MISERIT.
            /// `failure` describitur onus enim requiritur dispositio ad operationem, quae est quando non est similis ratio.
            /// [`Acquire`] victoria uti pro copia pars haec ordinatio facit [`Relaxed`] operatio et usus facit [`Release`] felix [`Relaxed`] onus.
            ///
            /// Defectum ordinis tantum [`SeqCst`], aequivalere debet [`Relaxed`] [`Acquire`] aut res quam ratio an infirmior.
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// Sit vetus mut= val.load(Ordering::Relaxed),
            /// loop {* veteris et novae=II,
            ///     par val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Adiungit ut vis praesens, redeuntem priorem valorem.
            ///
            /// Haec operatio est adligat circa redundantiam.
            ///
            /// `fetch_add` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
            /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
            ///
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Subtrahi de current valorem, previous reversus ad valorem.
            ///
            /// Haec operatio est adligat circa redundantiam.
            ///
            /// `fetch_sub` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
            /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
            ///
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Cum current valorem bitwise "and".
            ///
            /// Bitwise faciat "and" operationem in praesens et vis ratio `val` et occidere effectus novus ad valorem.
            ///
            /// Priorem refert ad valorem.
            ///
            /// `fetch_and` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
            /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
            ///
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Cum bitwise "nand" current valorem.
            ///
            /// Bitwise faciat "nand" operandi ratio in praesens et vis `val` et occidere effectus novus ad valorem.
            ///
            /// Priorem refert ad valorem.
            ///
            /// `fetch_nand` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
            /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
            ///
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Cum current valorem bitwise "or".
            ///
            /// Exsequitur bitwise "or" vis praesens et ratio operandi in `val`, et occidere est ad valorem novi exitum.
            ///
            /// Priorem refert ad valorem.
            ///
            /// `fetch_or` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
            /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
            ///
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise cum current "xor" valorem.
            ///
            /// Bitwise faciat "xor" vis praesens et ratio operandi in `val` et occidere novi effectus ad valorem.
            ///
            /// Priorem refert ad valorem.
            ///
            /// `fetch_xor` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
            /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
            ///
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Omnes electos valorem, et munus etiam in ea, quae redit ad libitum in novum valorem.Si autem `Ok(previous_value)` `Result` refert ad munus `Some(_)` rediit, `Err(previous_value)` aliud.
            ///
            /// Note: Glorificatum: appellare Divinum hoc munus plures temporibus ad valorem si mutata est ab alio interim relatorum, ut dum refert `Some(_)` munus, sed munus erit quondam fuisse tantum applicari ad valorem stored.
            ///
            ///
            /// `fetch_update` [`Ordering`] memoria rationum paria ordinatio describitur operatio.
            /// Ordo describitur in primis requiritur, cum per operationem secundam dum tandem sequitur ordinatio describitur per quod requiritur onerat.Correspondent vices successu infelicis
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] usura ratio ut planto copia victoria hac parte [`Relaxed`] operandi, et utendi [`Release`] onus [`Relaxed`] felix facit extremum.
            /// In tantum (failed) onere [`SeqCst`] ordine, inferiorem [`Acquire`] vel fortuna vel aequivalens [`Relaxed`] debeat ordinare.
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (ORDINATIONE: : SeqCst, Ordering::SeqCst: | X | Some(x + 1)): Ok(7));
            /// assert_eq! (x.fetch_update (ORDINATIONE: : SeqCst, Ordering::SeqCst: | X | Some(x + 1)): Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maximum est hodiernam pretii.
            ///
            /// Invenit maximam vis praesens et vis et ratio `val` et novis sets a valore ad exitum.
            ///
            /// Priorem refert ad valorem.
            ///
            /// `fetch_max` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
            /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
            ///
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// et sera=XLII;
            /// et max_foo=foo.fetch_max (talea, Ordering::SeqCst).max(bar);
            /// progressibus profertur! (==XLII max_foo);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// De vena minimum valorem.
            ///
            /// Ad minimum invenit in praesens et vis argumentum `val`, et novis sets ad valorem usque ad exitum.
            ///
            /// Priorem refert ad valorem.
            ///
            /// `fetch_min` describit rationem accipit [`Ordering`] memoriae operationem ordinari.Detur dispensatio omnis modi.
            /// Quod per [`Acquire`] facit copia hac parte [`Relaxed`] operatio et usus facit [`Release`] [`Relaxed`] pars onus.
            ///
            ///
            /// ** ** Nota: est tantum available modum Hanc nuclei super aggeres res de quibus omnis inminet
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// Sit talea=XII;
            /// et min_foo=foo.fetch_min (talea, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, XII);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // Salute data generis atomi intrinsics impediuntur.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Refert mutabiliter underlying regula ad quemcunque integrum affirmativum.
            ///
            /// Facientes, non nuclei legit et scribit in notitia fit integrum potest esse genus.
            /// Hoc enim FFI modum maxime utilis, ut ubi munus uti signature
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Ex communi regula reddendo `*mut` atomi necessarium propter ipsam mutabilitatem nuclei intus operantur rationes.
            /// Utilitas communis in omni mutatione modificationibus atomicus quantum et quamdiu incolumis licet operationibus utuntur atomica.
            /// Aliqua regula requirit usum rediit rudis in obstructionum `unsafe` et corroboret est idem absolute: est enim res in esse nuclei.
            ///
            ///
            /// # Examples
            ///
            /// `` `Ignorare (extern-declaration)
            ///
            /// # {f main()
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// {externarum "C"
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SALUS: `my_atomic_op` modo tutum ut sit nuclei.
            /// {statio male fida
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // Confidenter RECENS `atomic_store` contractus debeat sustinere salutem.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // Confidenter RECENS `atomic_load` contractus debeat sustinere salutem.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Confidenter RECENS `atomic_swap` contractus debeat sustinere salutem.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Refert ad valorem prior (quasi __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Confidenter RECENS `atomic_add` contractus debeat sustinere salutem.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Refert ad valorem previous (sicut __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Confidenter RECENS `atomic_sub` contractus debeat sustinere salutem.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // Confidenter RECENS `atomic_compare_exchange` contractus debeat sustinere salutem.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // Confidenter RECENS `atomic_compare_exchange_weak` contractus debeat sustinere salutem.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Salutem RECENS salutem tueri debet contractus `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Saluti `atomic_nand` RECENS contractus est tutius muniendam
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Salutem tutius muniendam RECENS est contractus `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Salutem et incolumitatem tueri debeat RECENS contractus `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// refert ad valorem max (signati comparationis)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Salutem et incolumitatem tueri debeat RECENS contractus `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// refert ad min value (signati collatio)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Salutem RECENS `atomic_min` contractus est tutius muniendam
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// in returns valorem max (unsigned collatio)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Consulens saluti contractus sustentare debent `atomic_umax` RECENS
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// ad valorem refert min (unsigned collatio)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Salutem RECENS `atomic_umin` sit contractus tueri salutem
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// An nuclei cadit.
///
/// Certo ordine pendentes saepemque impedit et compilator reordinans Pentium de memoria quaedam operationum genera circuitum.
/// Nobiscum et alias res conformiter creat atomi maceriae aliis filis.
///
/// A velantia saepes 'A', qui habet (quidem) [`Release`] ordine semantics conformiter sepem 'B' apud (saltem) [`Acquire`] semantics, nisi quod tantum non est res XY et operating in aliquo nuclei object 'M' sic quod A sit sequenced ante X, Y, synchronized servare mutatio est prius B, Y M.
/// Hoc, priusquam fit dependentia praebet inter B&A.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Sive res per nuclei [`Release`] quoque semantics [`Acquire`] synchronize sepem.
///
/// A quibus sepe habet [`SeqCst`] vi hominibvs armatis sive habentem praeter [`Acquire`] [`Release`], et semantics program global participat ut res ex alia [`SeqCst`] and/or quoque septa premunt.
///
/// [`Acquire`] accipit, [`Release`], et [`AcqRel`] [`SeqCst`] disciplinarum.
///
/// # Panics
///
/// Si Panics `order` [`Relaxed`] est.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // A primo exclusio mutua secundum spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // `false` est antiquis Imple hebdomadam dierum hujus valorem.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Haec saepes, conformiter cum in copia `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // Salutem et saepe uti an nuclei tutum est.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Memoriae compilator cadit.
///
/// `compiler_fence` non emittunt aliquo apparatus codice, sed et species restringit memoriae rursus ordinare licet facere compiler.Specie secundum datam [`Ordering`] semantics recitat compilator motum vivum sit an ex parte ante vel post vocationem `compiler_fence` vocatio.Nota quod neque enim ** ** hardware * * ne rursus talia facitis, ex ordine transigemus.
///
/// Hoc-in unum, non est a forsit fila, supplicium context sed mutare potest cum aliis relatorum simul memoriam, ut fortius synchronization primis [`fence`] non requiritur.
///
/// Et rursus posset, ordini semantics diversas vices sunt:
///
///  - cum [`SeqCst`] nec rursus ordinantur legit et scribit contra illud quod permissum est.
///  - [`Release`] cum praecedentia post factam scribit et legit immobiles.
///  - cum [`Acquire`], subsequent legit et scribit ex preceding legit non potest deviari obvius.
///  - et [`AcqRel`] et de supra praecepta sunt re spondit.
///
/// `compiler_fence` plerumque non minus utile est rumpat quis filum a currentium * * cum ipso.Id si exsecutioni dato filum codice uno et interruptus et capiendum animi signum est (manens eadem fila eiusdem rationis adhuc coro).In traditional programs, cum hoc fieri non potest nisi signo Handler relatus est.
/// Plus humili gradu codice, in casibus oriri possit tractare obloquitur dum fila deducendi pre-emptionem ligno etc.
/// Movet reddant legentium curiositati legere Linux kernel est disputationem de [memory barriers].
///
/// # Panics
///
/// Si Panics `order` [`Relaxed`] est.
///
/// # Examples
///
/// Sine `compiler_fence` et in hoc codice est `assert_eq!`* * praestitit, non obtinuit, quae non obstante fieri per singula fila telarum.
/// Videam mementote `IMPORTANT_VARIABLE` compilator ut libere et thesáuris RES `IS_READ` `Ordering::Relaxed` quia utrumque.Si enim et signo Handler post `IS_READY` invocatum est updated, tunc videbunt signo Handler `IS_READY=1` et `IMPORTANT_VARIABLE=0`.
/// In hoc situ `compiler_fence` remediis uti.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // ne antea dicit, ex hoc quod movetur quam punctus
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // Salutem et saepe uti an nuclei tutum est.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signa processus quod de intus insidiae nent-occupatus loop ("nent cincinno").
///
/// Hoc munus deprecatus est autem in gratiam [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}