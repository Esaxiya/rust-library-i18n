use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// A fascia non rudis circa indicat, quod nulla `*mut T` efficiat ut a possessore possidet serratus huius referent.
/// Sicut abstractum quid enim prodest aedificationem `Box<T>`, `Vec<T>`, `String` et `HashMap<K, V>`.
///
/// Secus `*mut T`, `Unique<T>` exempli gratia de se an esset hoc "as if" `T`.
/// Hoc effectum est `Send`/`Sync` si `T` `Send`/`Sync`.
/// Munitionum praesidia aliasing etiam importat quoddam exemplum `T` sperare;
/// et referent immutabile est in regula debet quin summus, habendi a unique semita ut Unicum suum.
///
/// Incertum an illud et si tibi proposita bene uti `Unique` tuum, considerans per `NonNull`, quae habet debilius semantics.
///
///
/// Secus `*mut T`, monstratorem semper debet non-vitio nullitatis infecta, etsi non sit dereferenced monstratorem.
/// Hoc enums ut et in hac pretii vetiti discriminant-`Option<Unique<T>>` mole habet etiam quod `Unique<T>`.
/// Sed si non dereferenced monstratorem adhuc pendeat.
///
/// Secus `*mut T`, `Unique<T>` est super covariant `T`.
/// Et hoc deberet esse semper rectam cuiuslibet generis, quae ad vindictam aliasing Unicum est scriptor accommodabat.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: titulum huius consequentiae est quia non judicans, sed necessarium
    // quia dropck quod intelligere sit secundum rationem habere `T`.
    //
    // Nam singula vide:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` Si enim data `Send` `T` est quia sunt indicia `Send` unaliased refertur.
/// Nota, quod haec a genus systematis INCOACTUS aliasing immutabilis est;quod est per modum abstractionis `Unique` actorem supplicii dedit.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` Si enim data `Sync` `T` est quia sunt indicia `Sync` unaliased refertur.
/// Nota, quod haec a genus systematis INCOACTUS aliasing immutabilis est;quod est per modum abstractionis `Unique` actorem supplicii dedit.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Nova gignit `Unique` est quod pendet; sed bene varius.
    ///
    /// Hoc est utilis pro initializing generis tormentis deducendae agroque diuidundo segniter, ut non `Vec::new`.
    ///
    /// Ut Nota quod in potentia ad valorem indicatorum repraesentaretur verum a monstratorem ad `T`, id Hoc quia non potest non esse in hominis speculatorem "not yet initialized" valorem.
    /// Id est indagare Initialization alio modo typi segniter collocant.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SALUS: returns validum mem::align_of(), non-nulli monstratorem.Quod
        // conditionibus new_unchecked() ita appellare licet.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// `Unique` novam gignit.
    ///
    /// # Safety
    ///
    /// `ptr` non-esse est non meretur.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // Utilitatibus consulens, ut `ptr` ma gistrum suum praestare non est, nihil est.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Nova gignit `Unique` si `ptr` non est, nihil est.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // Salútem: jam regula quod esse non sedatus et actum.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Consequendum underlying `*mut` monstratorem.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferences contentus est.
    ///
    /// Est vita inde enim tenetur ad id ita se gerat "as if" vero novom nunc questus est, quod in genere T mutuo acceperam.
    /// Si longiore vita (unbound) necesse est: uti `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // Salutem RECENS convenit omnibus praestare quod `self`
        // de requisitis ut referat.
        unsafe { &*self.as_ptr() }
    }

    /// Mu-tabiliter inest dereferences contentus est.
    ///
    /// Est vita inde enim tenetur ad id ita se gerat "as if" vero novom nunc questus est, quod in genere T mutuo acceperam.
    /// Et si vita longior (unbound) necesse est: uti `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // Salutem RECENS convenit omnibus praestare quod `self`
        // requiruntur ad commutabile reference.
        unsafe { &mut *self.as_ptr() }
    }

    /// Vesalius, ut monstratorem genus alia.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // Utilitatibus consulens Unique::new_unchecked() creates a unique atque necessitates
        // per eos quomodolibet non dedit monstratorem.
        // Cum ipso a monstratorem nos transeat, non potest esse irritum.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // Salus: A reference mutabilitatis non potest esse nulla
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}