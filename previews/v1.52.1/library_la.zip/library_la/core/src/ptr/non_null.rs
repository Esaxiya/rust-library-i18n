use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` sed non-nulla, et covariant.
///
/// Haec enim plerumque rectam ut res in aedificationem data opera rudis usura indicibusque, nisi propter se tanto periculo ob uti additional possessiones suas.`NonNull<T>` Si vestri 'non certus si utor, uti, sicut `*mut T`!
///
/// Secus `*mut T`: monstratorem necesse est semper non-vitio nullitatis infecta, etsi non sit Regula in dereferenced.Et est pro valore discriminant vetiti enums ex manifesta re utamur-est eadem mole, sicut `Option<NonNull<T>>` `* mut T`.
/// Sed si non dereferenced monstratorem adhuc pendeat.
///
/// `*mut T` dissimilis, ex `T` covariant `NonNull<T>` electus est.Et hoc facit non potest ut, cum `NonNull<T>` aedificationem covariant genera, sed etiam insania, si usus comprobat periculo, si non actu esse in type covariant.
/// (Oppositum electionis est `*mut T` nam etsi facta est insania technica ratione fieri possit nisi a causa munera subire tutum vocant.)
///
/// Quia tutissima covariance sit verum abstractum quid, quod tam `Box`, `Rc`, `Arc`, `Vec` et `LinkedList`.Hoc est quia sequitur ex casu quod API publicae est providere normalis participatur a Rust praecepta XOR posterius mutari potest.
///
/// Si autem covariant genus Sodorensem nequeat convenire secure, non continet aliquam operam dare opus providere additional agro invariance.Saepe erit [`PhantomData`] dum ipsa cellula genus vel quasi `PhantomData<Cell<T>>` `PhantomData<&'a mut T>`.
///
/// Notitia est hoc `NonNull<T>` `From` exempli gratia quia `&T`.Sed id quod mutare non mutating per (ex regula a) mores Finis enim participatur nisi referat intra fit per mutationem [`UnsafeCell<T>`].Idem refert de communi faciendi mutabilis secundum.
///
/// `From` absque usura is cum exempli `UnsafeCell<T>` est, hoc est efficere ut non sit `as_mut` vocavi, et non est propter mutationem `as_ptr`.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` referri possunt illi sunt data propter indicium `Send` aliased.
// NB, hoc est, necesse impl sed melius providere debet errorem dispenses.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` quod relatio non potest `Sync` propter indicium aliased elit.
// NB, hoc est, necesse impl sed melius providere debet errorem dispenses.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Novam gignit `NonNull` qui pendet oratio est, at bene varius.
    ///
    /// Hoc est utilis pro initializing generis tormentis deducendae agroque diuidundo segniter, ut non `Vec::new`.
    ///
    /// Ut Nota quod in potentia ad valorem indicatorum repraesentaretur verum a monstratorem ad `T`, id Hoc quia non potest non esse in hominis speculatorem "not yet initialized" valorem.
    /// Id est indagare Initialization alio modo typi segniter collocant.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // Utilitatibus consulens mem::align_of() refert ad non-nulla usize qui tunc casted
        // ad S. mut *
        // Ideo non `ptr` irritantibus et probationibus ad condiciones vocant new_unchecked() observentur.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Quae ad valorem participatur a refert.Contraque [`as_ref`], hoc requirere, quod non potest ad valorem habet initialized.
    ///
    /// Nam posterius mutari potest videre quomodo reputati [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Cum vocant dividentes, sicut habetis ut haec omnia ad verum;
    ///
    /// * In regula apte varius sit.
    ///
    /// * Oportet quod sit in sensu "dereferencable" defined in [the module documentation].
    ///
    /// * Vos Rust imperatorium exeat, de aliasing praecepta, ex quo vita rediit ad arbitrium assumi `'a` est ipsa vita, et qui reflectunt, non necessario ex data.
    ///
    ///   In particular, durante hac vita, in memoriam in regula oportet, ut adepto puncta mutatur (nisi intra `UnsafeCell`).
    ///
    /// Haec etsi per hunc modum effectus insolitum?
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // Salutem RECENS convenit omnibus praestare quod `self`
        // de requisitis ut referat.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Returns a unique quae ad valorem.Contra [`as_mut`], hoc requirere, non potest esse valorem habet initialized.
    ///
    /// Qua par est participata [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Cum vocant dividentes, sicut habetis ut haec omnia ad verum;
    ///
    /// * In regula apte varius sit.
    ///
    /// * Oportet quod sit in sensu "dereferencable" defined in [the module documentation].
    ///
    /// * Vos Rust imperatorium exeat, de aliasing praecepta, ex quo vita rediit ad arbitrium assumi `'a` est ipsa vita, et qui reflectunt, non necessario ex data.
    ///
    ///   Praesertim durante hac vita, in memoriam in regula adepto puncta ad accessed oportet, (non scripta legere) in alia regula.
    ///
    /// Haec etsi per hunc modum effectus insolitum?
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // Salutem RECENS convenit omnibus praestare quod `self`
        // de requisitis ut referat.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// `NonNull` novam gignit.
    ///
    /// # Safety
    ///
    /// `ptr` non-esse est non meretur.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // Utilitatibus consulens, ut `ptr` ma gistrum suum praestare non est, nihil est.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Nova gignit `NonNull` `ptr` si non est, nihil est.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // Salutem et nulla est regula iam auersi
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Facit idem pro [`std::ptr::from_raw_parts`] functionality nisi quod regula `NonNull` reversam crudum `*const` monstratorem opponitur.
    ///
    ///
    /// Ecce enim omnibus documentis, prout in [`std::ptr::from_raw_parts`] quo hic escorol.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // Utilitatibus consulens quod non sit effectus `ptr::from::raw_parts_mut`, nullum ob `data_address` sit.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Dissolutum est (forte wide) metadata et regula in components est oratio.
    ///
    /// In monstratorem [`NonNull::from_raw_parts`] in possit postea restituit.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Consequendum underlying `*mut` monstratorem.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Qui participatur in refert ad valorem.Si uninitialized pretii potest, [`as_uninit_ref`] debet esse in loco.
    ///
    /// Nam quomodo reputati sunt posterius mutari potest videre [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Cum vocant dividentes, sicut habetis ut haec omnia ad verum;
    ///
    /// * In regula apte varius sit.
    ///
    /// * Oportet quod sit in sensu "dereferencable" defined in [the module documentation].
    ///
    /// * In monstratorem est ad designandum Initialized exempli gratia ex `T`.
    ///
    /// * Vos Rust imperatorium exeat, de aliasing praecepta, ex quo vita rediit ad arbitrium assumi `'a` est ipsa vita, et qui reflectunt, non necessario ex data.
    ///
    ///   In particular, durante hac vita, in memoriam in regula oportet, ut adepto puncta mutatur (nisi intra `UnsafeCell`).
    ///
    /// Haec etsi per hunc modum effectus insolitum?
    /// (Partem et non accepit de initialized voluit esse, sed usque hoc est solum aditus est tutum ut se quidem initialized sunt.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // Salutem RECENS convenit omnibus praestare quod `self`
        // de requisitis ut referat.
        unsafe { &*self.as_ptr() }
    }

    /// A unique refert ad valentiam.Si valorem potest uninitialized, [`as_uninit_mut`] debet esse in loco.
    ///
    /// Vide ad instar [`as_ref`] participata.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Cum vocant dividentes, sicut habetis ut haec omnia ad verum;
    ///
    /// * In regula apte varius sit.
    ///
    /// * Oportet quod sit in sensu "dereferencable" defined in [the module documentation].
    ///
    /// * In monstratorem est ad designandum Initialized exempli gratia ex `T`.
    ///
    /// * Vos Rust imperatorium exeat, de aliasing praecepta, ex quo vita rediit ad arbitrium assumi `'a` est ipsa vita, et qui reflectunt, non necessario ex data.
    ///
    ///   Praesertim durante hac vita, in memoriam in regula adepto puncta ad accessed oportet, (non scripta legere) in alia regula.
    ///
    /// Haec etsi per hunc modum effectus insolitum?
    /// (Partem et non accepit de initialized voluit esse, sed usque hoc est solum aditus est tutum ut se quidem initialized sunt.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // Salutem RECENS convenit omnibus praestare quod `self`
        // requiruntur ad commutabile reference.
        unsafe { &mut *self.as_ptr() }
    }

    /// Vesalius, ut monstratorem genus alia.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // Utilitatibus consulens, quae est regula `self` est `NonNull` non necessario nullum,
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Gignit a non-nulla est regula et longitudo rudis FRUSTUM tenui.
    ///
    /// Et elementa ** **`len` ratio est numerus, neque enim numero bytes.
    ///
    /// Hoc munus tutum est, quod dereferencing autem reditus non stabilieris tu pretii.
    /// Ecce enim [`slice::from_raw_parts`] omnibus documentis, prout in FRUSTUM salute elit.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // monstratorem quod partum FRUSTUM cum incipiens a monstratorem primum elementum
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Nota est artificialis huius exempli gratia monstrat et modum quo usu, sed non fiat segmentum= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // Utilitatibus consulens `data` est `NonNull` quod regula est, non necessario nullum,
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Redit, quod non est longitudinem nullum rudis scalpere.
    ///
    /// ** ** quot elementa rediit pretii sit quod non fuerit numerus bytes.
    ///
    /// Munus hoc tutum est, etiam cum de non-fragmen rudis irritum potest fieri dereferenced est segmentum quod regula non habet inscriptio electronica valida.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// A FRUSTUM de monstratorem non redit, quiddam nullum.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SALUS: Scimus `self` non est, non meretur.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Quiddam est scriptor refert fragmen rudis monstratorem.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// A FRUSTUM nusquam redit participatur ad uninitialized values.Contraque [`as_ref`], hic non requirere quæ habet in valore ut initialized.
    ///
    /// Et vide quomodo reputati [`as_uninit_slice_mut`] uoluntas mutabilis.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Cum vocant dividentes, sicut habetis ut haec omnia ad verum;
    ///
    /// * In monstratorem oportet [valid] legit quia pro pluribus `ptr.len() * mem::size_of::<T>()` bytes et varius sit bene.Et hoc maxime est;
    ///
    ///     * FRUSTUM memoriae latitudine totius huius rei est intra unius datum!
    ///       Crustae non potest contra multa spatia obiecti partita imperia.
    ///
    ///     * Tandem etiam nulla sit amet segmenta monstratorem.
    ///     Una ratio ad hoc quod sibi possit enum in layout optimizations references (longitudo inter crustae de quolibet) non-nulla, et varius esse eas distinguere ab aliis data.
    ///
    ///     Vos potest sicut `data` quia nulla est regula, quod est utilis, longitudo uti [`NonNull::dangling()`] purus.
    ///
    /// * In summa magnitudine `ptr.len() * mem::size_of::<T>()` de secare non debet esse maior quam `isize::MAX`.
    ///   Vide documenta ad salutem [`pointer::offset`].
    ///
    /// * Vos Rust imperatorium exeat, de aliasing praecepta, ex quo vita rediit ad arbitrium assumi `'a` est ipsa vita, et qui reflectunt, non necessario ex data.
    ///   In particular, durante hac vita, in memoriam in regula oportet, ut adepto puncta mutatur (nisi intra `UnsafeCell`).
    ///
    /// Haec etsi per hunc modum effectus insolitum?
    ///
    /// Vide et [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // Confidenter RECENS `as_uninit_slice` contractus debeat sustinere salutem.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Segmentum placentae nusquam refert ad uninitialized values a unique.Contraque [`as_mut`], hoc requirere, non potest esse valorem habet initialized.
    ///
    /// In qua par [`as_uninit_slice`] participata.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Cum vocant dividentes, sicut habetis ut haec omnia ad verum;
    ///
    /// * In regula est quod in [valid] legit et scribit multos enim `ptr.len() * mem::size_of::<T>()` bytes, et bene sit varius.Hoc est maxime:
    ///
    ///     * FRUSTUM memoriae latitudine totius huius rei est intra unius datum!
    ///       Crustae non potest contra multa spatia obiecti partita imperia.
    ///
    ///     * Tandem etiam nulla sit amet segmenta monstratorem.
    ///     Una ratio ad hoc quod sibi possit enum in layout optimizations references (longitudo inter crustae de quolibet) non-nulla, et varius esse eas distinguere ab aliis data.
    ///
    ///     Vos potest sicut `data` quia nulla est regula, quod est utilis, longitudo uti [`NonNull::dangling()`] purus.
    ///
    /// * In summa magnitudine `ptr.len() * mem::size_of::<T>()` de secare non debet esse maior quam `isize::MAX`.
    ///   Vide documenta ad salutem [`pointer::offset`].
    ///
    /// * Vos Rust imperatorium exeat, de aliasing praecepta, ex quo vita rediit ad arbitrium assumi `'a` est ipsa vita, et qui reflectunt, non necessario ex data.
    ///   Praesertim durante hac vita, in memoriam in regula adepto puncta ad accessed oportet, (non scripta legere) in alia regula.
    ///
    /// Haec etsi per hunc modum effectus insolitum?
    ///
    /// Vide et [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Hoc ut salvum `memory` valet ad multas legit et scribit ad `memory.len()` bytes.
    /// // Nota vocantem se `memory.as_mut()` quod non licet hie contentus uninitialized potest.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // Confidenter RECENS `as_uninit_slice_mut` contractus debeat sustinere salutem.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Vir rudis refert regula vel subslice ad elementum, fines facere, non reprehendo.
    ///
    /// Et cum hoc modum vocant indicem, aut cum terminis-of-`self` dereferencable non sit *[Finis mores]* etiam si inde non uti regula.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SALUS: ut, in RECENS `self` est dereferencable, et `index` in terminis.
        // Ita factum est, unde non potest regula ne habeantur.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // Salus: A Unique regula non potest esse nulla, quia ita conditionibus
        // new_unchecked() curet observentur.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // Salus: A reference mutari potest esse nulla potest.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // Salus: A reference nullum potest esse tam in conditionibus
        // new_unchecked() curet observentur.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}