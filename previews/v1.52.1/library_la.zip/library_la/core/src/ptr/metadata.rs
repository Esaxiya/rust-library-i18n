#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Praebet monstratorem genus metadata aliquo acuto, ut typus.
///
/// # Indicium metadata
///
/// Quantum viva regula genera cogitari potest ex speciebus Rust in duas partes
/// monstratorem quod habet in notitia inscriptio in memoriam in valore, et metadata.
///
/// Quia mediocri-immobiliter types (ut `Sized` ad effectum deducendi traits) tum quia `extern` types, indicibusque sunt dixit ad esse "gracili": metadata nullus est-amplitudo et non `()` genus suum.
///
///
/// Quae ad indicium [dynamically-sized types][dst] dicitur esse "wide" sive "adipem", qui sunt non-nulla-sized metadata:
///
/// * Nam structs quorum DST est agris ultimo, nam ultimo metadata est ager metadata
/// * Nam `str` generis, in Fasciculus bytes quae sit longitudo `usize`
/// * Sicut fragmen enim genera `[T]`, in Fasciculus longitudo `usize` items
/// * Simile enim occurrit trait `dyn SomeTrait`, metadata est [`DynMetadata<Self>`][DynMetadata] (eg `DynMetadata<dyn SomeTrait>`)
///
/// In future et Rust lingua potest lucrari Nova genera et species habent diversas metadata regula.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Et `Pointee` trait
///
/// In loco hoc est trait `Metadata` concomitante ejus generis, qui sive `()` `usize` `DynMetadata<_>` seu sicut superius dictum est.
/// Implemented statim est ad genus omne.
/// Potest supponi potest generalis in context implemented etiam sine correspondens tenetur.
///
/// # Usage
///
/// Rudis indicibusque potest resolutum in notitia metadata components et oratio eorum in [`to_raw_parts`] modum.
///
/// Vel potest solum metadata potest, cum munus [`metadata`].
/// Transierunt [`metadata`] implicite est A reference posse coerceri.
///
/// In regula (possibly-wide) Fasciculus in contione posse dimittere ab se et [`from_raw_parts`] [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Quod genus est metadata in indicativam habent references to `Self`.
    #[lang = "metadata_type"]
    // NOTE: Ut in trait bounds `static_assert_expected_bounds_for_metadata`
    //
    // `library/core/src/ptr/metadata.rs` apud illos in sync cum hic
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Types indicibus etiam, ad effectum deducendi his quae alias trait "tenues".
///
/// Hoc includit typis et immobiliter, `Sized` `extern` types.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: nec ante trait aliases stabiliendum hoc firmum et in linguam?
pub trait Thin = Pointee<Metadata = ()>;

/// Et pars alia regula metadata eliciunt.
///
/// `*mut T` generis valores, `&T` vel directe ad hoc munus `&mut T` si multi venentur, etiamsi implicite, cum ad coercendos `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // Salutem et accessu ad valentiam de `PtrRepr` unio est tutum ab int T *
    // et PtrComponents<T>Home memoriam habere.
    // Tantum hoc vinculum std potest.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Et ex forms (possibly-wide) rudis notitia oratio monstratorem, et metadata.
///
/// Reversus autem regula non necessario munere tuta tutum dereference.
/// Nam purus videte documentum [`slice::from_raw_parts`] salute elit.
/// Nam trait speculata cognoverimus, intellectus est regula metadata debet venire ad idem genus underlying ereased.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // Salutem et accessu ad valentiam de `PtrRepr` unio est tutum ab int T *
    // et PtrComponents<T>Home memoriam habere.
    // Tantum hoc vinculum std potest.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Idem facit ut funcionalidades [`from_raw_parts`] nisi rudis `*mut` monstratorem reversam crudum `* const` monstratorem opponitur.
///
///
/// Vide de omnibus documentis, prout in [`from_raw_parts`] quo hic escorol.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // Salutem et accessu ad valentiam de `PtrRepr` unio est tutum ab int T *
    // et PtrComponents<T>Home memoriam habere.
    // Tantum hoc vinculum std potest.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manual opus ad vitare impl `T: Copy` tenetur.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manual opus fuerit ne impl `T: Clone` tenetur.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Et metadata ad object `Dyn = dyn SomeTrait` trait genus.
///
/// Est monstratorem a vtable (virtual vocationem mensa), quod plane necessarium omnis generis concretum notitia very molimina corrumpendi posita procer interius est trait est.
/// Et vtable haud pauca continet,
///
/// * genus magnitudinis
/// * Gratia diei et noctis genus
/// * monstratorem genus impl `drop_in_place` est (op ut patet, non enim potest esse-vetus-notitia)
/// * omnibus modi'sgenus implementation pro argumentis ex trait
///
/// Primum peculiari nota quod tria sunt necessaria collocare nequimus, quia tu, gutta, et omnis deallocate trait est.
///
/// Non enim potest dicere quo instrúite type cum modulus a non `dyn` trait object id (exempli gratia `DynMetadata<u64>`) Significantius et valorem illius non ad aliquam rem efficere.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Communi omnium vtables praeposita.Insequitur trait functio indicibusque Nam elit.
///
/// Implementation detail a privatis etc. `DynMetadata::size_of`
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Genus refert magnitudinem consociata cum hoc vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Genus refert ad consociata cum hoc vtable membrorum dispositione sub vestibus.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Dam magnitudinem redit `Layout` quemadmodum
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // Salutem et in concreto Rust compiler emittitur huius generis quod in vtable
        // ut valida notum sit layout.Ut in eodem rationale `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manual impls opus vitare `Dyn: $Trait` fines.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}