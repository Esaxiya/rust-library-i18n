use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Regula in `true` redit, si nihil est actum.
    ///
    /// Genera multa esse non nulla indicia unsized nota quod regula habeatur notitia crudum solum et non longitudinis vtable etc.
    /// Ergo duobus argumentis quae tamen nulla inter se conferre.
    ///
    /// ## Const mores in iudicium
    ///
    /// Quod cum adhibetur in Const munus iudicium, ut reverterentur ad `false` turn argumentis, quae apud eos quomodolibet dicta sunt ut runtime.
    /// Specie cum monstratorem aliqua memoria ultra eius fines sit offset ita ut nulla sit consequens regula, quod tamen munus non revertetur `false`.
    ///
    /// Nulla ut ipsum per situm CTFE memoria nulla est regula si nescimus necne.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Per jactum comparare tenui monstratorem, nulla pars pinguis "data" considerans, nisi indicibus sentiat.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Vesalius, ut monstratorem genus alia.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Dissolutum est (forte wide) metadata et regula in components est oratio.
    ///
    /// In monstratorem possunt reparari cum [`from_raw_parts`] postea.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Refert `None` si monstratorem esse nullum aut aliud autem redit ad valorem participatur a pluribus involuta `Some`.Si valorem uninitialized potest, debet esse pro [`as_uninit_ref`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Cum vocant hunc modum: sunt et aut ut * **et* monstratorem nulla sit omnibus haec sit vera:
    ///
    /// * In regula apte varius sit.
    ///
    /// * Oportet quod sit in sensu "dereferencable" defined in [the module documentation].
    ///
    /// * In monstratorem est ad designandum Initialized exempli gratia ex `T`.
    ///
    /// * Vos Rust imperatorium exeat, de aliasing praecepta, ex quo vita rediit ad arbitrium assumi `'a` est ipsa vita, et qui reflectunt, non necessario ex data.
    ///   In particular, durante hac vita, in memoriam in regula oportet, ut adepto puncta mutatur (nisi intra `UnsafeCell`).
    ///
    /// Haec etsi per hunc modum effectus insolitum?
    /// (Partem et non accepit de initialized voluit esse, sed usque hoc est solum aditus est tutum ut se quidem initialized sunt.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null-versio inoffensum
    ///
    /// Si nulla sunt, certa esse non potest, est regula quaedam `as_ref_unchecked` quaeritis quae refert ad `&T` pro `Option<&T>`, ut scire possunt ex regula recta dereference.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SALUS: quia non SALUTATOR valet pignus `self`
        // Si enim non in ipso referat.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Refert `None` si regula vitio nullitatis infecta, sive aliud redeunt ad participatur a pluribus involuta `Some` ad valorem.
    /// Contraque [`as_ref`], hoc valore habet et quod non eget initialized.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Cum vocant hunc modum: sunt et aut ut * **et* monstratorem nulla sit omnibus haec sit vera:
    ///
    /// * In regula apte varius sit.
    ///
    /// * Oportet quod sit in sensu "dereferencable" defined in [the module documentation].
    ///
    /// * Vos Rust imperatorium exeat, de aliasing praecepta, ex quo vita rediit ad arbitrium assumi `'a` est ipsa vita, et qui reflectunt, non necessario ex data.
    ///
    ///   In particular, durante hac vita, in memoriam in regula oportet, ut adepto puncta mutatur (nisi intra `UnsafeCell`).
    ///
    /// Haec etsi per hunc modum effectus insolitum?
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // Salutem RECENS convenit omnibus praestare quod `self`
        // de requisitis ut referat.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Subolem computantem offset a monstratorem.
    ///
    /// `count` et quod populus per turmas T;eg, in III de `count` represents regula de offset `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Conditionibus Si quis autem haec violare sunt: ex Gestu Undefined effectus est:
    ///
    /// * Tum ex regula vel in carcere et bondas eiusdem estimationis obiectum vel finis praeteriti byte.
    /// Nota Rust ut singuli separatim consideratur partita (stack-allocated) varius tempus.
    ///
    /// * Et computatis offset,**apud bytes** possit flamma non ardebit in `isize`.
    ///
    /// * Et in fines offset non potest, non potentia nititur "wrapping around" oratio in spatio.Nempe infinitum certa summa ** ** est in bytes usize fit in.
    ///
    /// Et quod compiler bibliotheca plerumque vexillum magnitudine a quo vult pervenire, ut prouinciis non est de offset est.
    /// Nam et `Vec` `Box` ut numquam plus placeat `isize::MAX` bytes ita `vec.as_ptr().add(vec.len())` semper salvo.
    ///
    /// Most platforms ratione disiunctum potest fingere quidem tale quod destinatio.
    /// Nam exempli gratia, nemo sciri potest platform semper serve et LXIV frenum Petentibus <sup>II-LXIII-page</sup> mensam ex bytes, aut limitations in scissione inquiunt electronica locus.
    /// Autem, quidam aliquantulus XXXII-et-XVI platforms aliquantulus magis quam ad petitionem, ut bene sit serve `isize::MAX` bytes ut res Physica Oratio ad extensionem.
    ///
    /// Ut sic, et memoriam acquiritur allocators directe a memoria sint provisa * * files tam magnus est ut non cum hoc munus tractamus.
    ///
    /// Considerans [`wrapping_offset`] pro uti si sint isti angustiis difficile satisfacere.
    /// Sola modum utendi hoc est quod dat, immo suflicit optimizations compiler.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // Confidenter RECENS `offset` contractus debeat sustinere salutem.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Subolem computantem offset monstratorem per involuti ab arithmetico.
    ///
    /// `count` et quod populus per turmas T;eg, in III de `count` represents regula de offset `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Haec operatio semper tutum se, sed per consequens regula quod non est.
    ///
    /// Eiusdem estimationis rei consequens regula `self` manet in punctis.
    /// * * Non est utendum sit accedere ad alium sortita est.Nota quod Rust singuli separatim consideratur partita (stack-allocated) varius tempus.
    ///
    /// Id `let z = x.wrapping_offset((y as isize) - (x as isize))` facit, nonne * faciam `z` idem quod `y` etiam si ponamus `T` habet magnitudinem `1`, et non est redundantiam: `z` adhuc coniuncta ad object `x` est coniuncta et dereferencing indeterminata est, quibus innocentia nisi `x`, et id quod in eadem diuisione `y`.
    ///
    /// [`offset`] comparatur, ratio plerumque eiusdem prouinciae manere pia institutio dicunt quod transituri [`offset`] immediata Undefined mores terminosSi tamen inducit mores Undefined `wrapping_offset` producit regula est regula dereferenced cum sicco-modum obiecti cohaereat.
    /// [`offset`] posse performance optimized melius et sic potior est in codice-sensitive.
    ///
    /// Tantum moratus est reprehendo valore autem ex regula considerat dereferenced, quod non est medium in usum computationis values supremum exitum.
    /// For example, sicut `x` `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` semper.In aliis verba allocated relinquens ad object-re et intrantes autem postea non permittitur.
    ///
    /// Quod si opus est object crucis fines terrae et misit in regula est numerus integer arithmetica est.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // Iterate usus rudis suorum incrementorum ipsis duo elementa in indicatorum
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Hoc loop procer "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SALUS et `arith_offset` intrinsecam habet in necessarias proprietates dicuntur.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Pendat distantia duorum indicibusque.Et reddidit valorem T is populus per turmas suas: in spatium bytes `mem::size_of::<T>()` divisa est.
    ///
    /// Hoc munus a eadem cum [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Conditionibus Si quis autem haec violare sunt: ex Gestu Undefined effectus est:
    ///
    /// * Et regula ab initio neque erunt ultra terminos sive ejusdem byte sortita est.
    /// Nota Rust ut singuli separatim consideratur partita (stack-allocated) varius tempus.
    ///
    /// * Tum argumentis debet * * ex regula ad idem est.
    ///   (Vide inferius pro per exemplum.)
    ///
    /// * Distantia indicibusque in bytes oportet certa quantitate `T` multiplex.
    ///
    /// * Indicia intervallo ** ** in bytes potest redundare in `isize`.
    ///
    /// * Non procul in fine orationis "wrapping around" diam elit.
    ///
    /// Rust genera sunt nusquam maior quam `isize::MAX` alter decidat et non Rust prouinciis referentibus oratio in spatio, ut in duobus argumentis aliquid de valorem Rust omnis generis `T` semper satiat duobus ultimis conditionibus.
    ///
    /// De bibliotheca vexillum amplitudo etiam plerumque efficit, ut de prouinciis referentibus non perveniant offset in quo est, spectat.
    /// Nam et `Vec` `Box` ensure numquam magis quam deducendae agroque diuidundo `isize::MAX` bytes, ut semper `ptr_into_vec.offset_from(vec.as_ptr())` duobus ultimis conditionibus satisfaciet.
    ///
    /// Most platforms ratione non potest fingendo talem informabo magnam destinatio.
    /// Nam exempli gratia, nemo sciri potest platform semper serve et LXIV frenum Petentibus <sup>II-LXIII-page</sup> mensam ex bytes, aut limitations in scissione inquiunt electronica locus.
    /// Autem, quidam aliquantulus XXXII-et-XVI platforms aliquantulus magis quam ad petitionem, ut bene sit serve `isize::MAX` bytes ut res Physica Oratio ad extensionem.
    /// Ut sic, et memoriam acquiritur allocators directe a memoria sint provisa * * files tam magnus est ut non cum hoc munus tractamus.
    /// ([`offset`] et [`add`] Nota etiam, quod habent limitationem et ideo nullo modo similis esse in tam magnis aut prouinciis referentibus.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Hoc munus panics si `T` est a Zero-sized ("ZST") Type.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// Non recta * * usus:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Et fac ptr2_other "alias" de ptr2 et ex ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Et cum ptr2_other ptr2 obiecti sunt ex diversis argumentis, computatis offset illorum indeterminata est, mores, ad designandum quod etsi eadem inscriptio?
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Finis MORES
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // Confidenter RECENS `ptr_offset_from` contractus debeat sustinere salutem.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Utrum reddit aequalem indicibusque praestati.
    ///
    /// In hoc munus gerit, ut `self == other` runtime.
    /// Tamen in aliqui contextuum (eg, tempore iudicium, compile), non semper ex duabus potest determinare aequalitatem, Romane, memento ut hoc munus spuriously ut reverterentur ad `false` indicia, quae postea sunt actu conuertatur ad esse pares.
    ///
    /// Cum redit `true`, utpote quae indicia sunt aequales.
    ///
    /// Haec munus est de [`guaranteed_ne`] Speculum, sed et ipsius inversa.None Sunt rationes ad quam munera et `false` revertetur.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Mutare potest de reditus valorem fretus in compiler codice non versionem et statio male fida nititur propter hoc munus ob incolumes.
    /// Non enim hoc munus est ut suggesserant optimizations ubi perficientur falsum values `false` reditus non afficit munus hac in exitus est, sed solum in perficientur.
    /// Consequentiae, ut per hunc modum, tempus codice runtime quod congero behave non aliter exploratus.
    /// Ita non potest inducere ad hoc oportet modum differentiis differunt, et ita oportet erit stabilita coram nobis et non habent exitus est melior intellectus.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Vel duo redit in tuto positis ut indicia proelium par.
    ///
    /// In hoc munus gerit ut runtime `self != other`.
    /// However, in quibusdam adiunctis (eg, compone, iudicium temporis), est non semper potest determinare inaequalitatem duarum, Romane, memento ut hoc munus spuriously ut reverterentur ad `false` indicium quod postea actu conuertatur ad inequales.
    ///
    /// Cum `true` redit, indicibusque praestati impares.
    ///
    /// Haec munus est Dei [`guaranteed_eq`] Speculum sed ipsius inversa.Sunt regula comparationes, qui munera et `false` revertetur.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Mutare potest de reditus valorem fretus in compiler codice non versionem et statio male fida nititur propter hoc munus ob incolumes.
    /// Non enim hoc munus est ut suggesserant optimizations ubi perficientur falsum values `false` reditus non afficit munus hac in exitus est, sed solum in perficientur.
    /// Consequentiae, ut per hunc modum, tempus codice runtime quod congero behave non aliter exploratus.
    /// Ita non potest inducere ad hoc oportet modum differentiis differunt, et ita oportet erit stabilita coram nobis et non habent exitus est melior intellectus.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Subolem computantem offset regula ab (ad commodum `.offset(count as isize)`).
    ///
    /// `count` et quod populus per turmas T;eg, in III de `count` represents regula de offset `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Conditionibus Si quis autem haec violare sunt: ex Gestu Undefined effectus est:
    ///
    /// * Tum ex regula vel in carcere et bondas eiusdem estimationis obiectum vel finis praeteriti byte.
    /// Nota Rust ut singuli separatim consideratur partita (stack-allocated) varius tempus.
    ///
    /// * Et computatis offset,**apud bytes** possit flamma non ardebit in `isize`.
    ///
    /// * Et non est in terminis offset potest non confidunt in "wrapping around" electronica locus.Hoc in infinitum, esse certa summa fit per `usize`.
    ///
    /// Et quod compiler bibliotheca plerumque vexillum magnitudine a quo vult pervenire, ut prouinciis non est de offset est.
    /// Nam et `Vec` `Box` ut numquam plus placeat `isize::MAX` bytes ita `vec.as_ptr().add(vec.len())` semper salvo.
    ///
    /// Most platforms ratione disiunctum potest fingere quidem tale quod destinatio.
    /// Nam exempli gratia, nemo sciri potest platform semper serve et LXIV frenum Petentibus <sup>II-LXIII-page</sup> mensam ex bytes, aut limitations in scissione inquiunt electronica locus.
    /// Autem, quidam aliquantulus XXXII-et-XVI platforms aliquantulus magis quam ad petitionem, ut bene sit serve `isize::MAX` bytes ut res Physica Oratio ad extensionem.
    ///
    /// Ut sic, et memoriam acquiritur allocators directe a memoria sint provisa * * files tam magnus est ut non cum hoc munus tractamus.
    ///
    /// Per consider [`wrapping_add`] pro cohiberi, si haec non est difficile satisfacere.
    /// Sola modum utendi hoc est quod dat, immo suflicit optimizations compiler.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // Confidenter RECENS `offset` contractus debeat sustinere salutem.
        unsafe { self.offset(count as isize) }
    }

    /// Subolem computantem offset a regula (nam istae commodum .offset ((Sicut isize).wrapping_neg())`) numerare.
    ///
    /// `count` et quod populus per turmas T;eg, in III de `count` represents regula de offset `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Conditionibus Si quis autem haec violare sunt: ex Gestu Undefined effectus est:
    ///
    /// * Tum ex regula vel in carcere et bondas eiusdem estimationis obiectum vel finis praeteriti byte.
    /// Nota Rust ut singuli separatim consideratur partita (stack-allocated) varius tempus.
    ///
    /// * ** ** bytes `isize::MAX` et computatis offset qui praeterire non poterunt.
    ///
    /// * Offset quod ens non potest in terminis "wrapping around" inscriptione an fiduciam habes in spatio.Quod est, necesse est infinitum, certa summa fit per usize.
    ///
    /// Et quod compiler bibliotheca plerumque vexillum magnitudine a quo vult pervenire, ut prouinciis non est de offset est.
    /// Nam et `Vec` nunquam tuto collocant `Box` bytes `isize::MAX` quam ut incolumis sit `vec.as_ptr().add(vec.len()).sub(vec.len())`.
    ///
    /// Most platforms ratione disiunctum potest fingere quidem tale quod destinatio.
    /// Nam exempli gratia, nemo sciri potest platform semper serve et LXIV frenum Petentibus <sup>II-LXIII-page</sup> mensam ex bytes, aut limitations in scissione inquiunt electronica locus.
    /// Autem, quidam aliquantulus XXXII-et-XVI platforms aliquantulus magis quam ad petitionem, ut bene sit serve `isize::MAX` bytes ut res Physica Oratio ad extensionem.
    ///
    /// Ut sic, et memoriam acquiritur allocators directe a memoria sint provisa * * files tam magnus est ut non cum hoc munus tractamus.
    ///
    /// [`wrapping_sub`] utendi angustiis loco consideramus, si haec non est difficile satisfacere.
    /// Sola modum utendi hoc est quod dat, immo suflicit optimizations compiler.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // Confidenter RECENS `offset` contractus debeat sustinere salutem.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Subolem computantem offset monstratorem per involuti ab arithmetico.
    /// (Nam commodum `.wrapping_offset(count as isize)`)
    ///
    /// `count` et quod populus per turmas T;eg, in III de `count` represents regula de offset `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Haec operatio semper tutum se, sed per consequens regula quod non est.
    ///
    /// Eiusdem estimationis rei consequens regula `self` manet in punctis.
    /// * * Non est utendum sit accedere ad alium sortita est.Nota quod Rust singuli separatim consideratur partita (stack-allocated) varius tempus.
    ///
    /// In verba `let z = x.wrapping_add((y as usize) - (x as usize))` does *non* faciam `z` idem quod `y`, etiam si ponamus `T` habet mole `1` et non est redundantiam: `z` adhuc coniuncta ad object `x` est coniuncta et dereferencing est Undefined mores, nisi `x` atque id quod in eadem diuisione `y`.
    ///
    /// [`add`] comparata haec ratio plerumque eiusdem prouinciae manere pia institutio dicunt quod transituri [`add`] immediata Moribus Undefined terminosSi tamen inducit Undefined mores exprimit `wrapping_add` monstratorem est regula dereferenced cum sicco-modum obiecti cohaereat.
    /// [`add`] posse performance optimized melius et sic potior est in codice-sensitive.
    ///
    /// Tantum moratus est reprehendo valore autem ex regula considerat dereferenced, quod non est medium in usum computationis values supremum exitum.
    /// Eg `x.wrapping_add(o).wrapping_sub(o)` `x` quod est semper eadem.In aliis, in partita relinquo object-re et intrantes factum est post permittitur.
    ///
    /// Quod si opus est object crucis fines terrae et misit in regula est numerus integer arithmetica est.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // Iterate usus rudis suorum incrementorum ipsis duo elementa in indicatorum
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Hoc loop procer "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Subolem computantem offset monstratorem per involuti ab arithmetico.
    /// (Nam istae commodum .wrapping_offset ((quam numerare isize).wrapping_neg())`)
    ///
    /// `count` et quod populus per turmas T;eg, in III de `count` represents regula de offset `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Haec operatio semper tutum se, sed per consequens regula quod non est.
    ///
    /// Eiusdem estimationis rei consequens regula `self` manet in punctis.
    /// * * Non est utendum sit accedere ad alium sortita est.Nota quod Rust singuli separatim consideratur partita (stack-allocated) varius tempus.
    ///
    /// Id `let z = x.wrapping_sub((x as usize) - (y as usize))` est *Non* faciam `z` idem quod `y` etiam si ponamus `T` habet mole `1`, et non est redundantiam: `z` adhuc attachiatus ad object `x` est coniuncta et dereferencing indeterminata est, quibus innocentia nisi `x`, et datum punctum `y` eandem rem.
    ///
    /// [`sub`] comparatur, plerumque differt hanc necessitatem partita stando idem objectum Undefined [`sub`] immediata secundum mores transituri terminosSi tamen inducit mores Undefined producit `wrapping_sub` regula cum regula est sicco-dereferenced modum obiecti cohaereat.
    /// [`sub`] posse performance optimized melius et sic potior est in codice-sensitive.
    ///
    /// Tantum moratus est reprehendo valore autem ex regula considerat dereferenced, quod non est medium in usum computationis values supremum exitum.
    /// Eg `x.wrapping_add(o).wrapping_sub(o)` `x` quod est semper eadem.In aliis, in partita relinquo object-re et intrantes factum est post permittitur.
    ///
    /// Quod si opus est object crucis fines terrae et misit in regula est numerus integer arithmetica est.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // Iterate regula usus rudis incrementa duo elementa in (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Hoc loop procer "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Sets monstratorem ad valorem `ptr`.
    ///
    /// Si `self` est (fat) monstratorem type unsized est, haec operatio non solum afficit Regula in parte, cum de mediocri types (thin) indicium est, quod idem est effectus est simplex carminibus Marcianis.
    ///
    /// Inde provenientia erit ex regula `val`, id est, pro regula adipem, haec operatio est eadem quod semantically partum a adipem de regula data ab valorem indicatorum `val` sed ex metadata `self`.
    ///
    ///
    /// # Examples
    ///
    /// Praesertim utilis pro hoc munus sit sapiens arithmeticam indicatorum-byte permittens in potentia, adipem indicium:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // "3" mos procer
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // Salutem et tenuis In casu regula, haec res est identical
        // ad simplex carminibus Marcianis.
        // Si a adipem monstratorem, implementation layout de current pinguis regula, prima regula est talis ager semper regula notitia, de qua etiam assignata.
        //
        unsafe { *thin = val };
        self
    }

    /// Legit autem `self` sine valore ex ea movere.
    /// Quo memoria `self` pariatur.
    ///
    /// Et vide de [`ptr::read`] pro salute exempla.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // Confidenter RECENS `read` contractus debeat sustinere salutem.
        unsafe { read(self) }
    }

    /// Exsequitur volatile legere non de valore ex `self` ea movere.Quo memoria `self` pariatur.
    ///
    /// Animo agunt operationes memoriae I/O volatilem et stabiliri nec per se adiecta elided mobile vel ad operationem ordinatur.
    ///
    ///
    /// Vide [`ptr::read_volatile`] de salute enim et exempla.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // Confidenter RECENS `read_volatile` contractus debeat sustinere salutem.
        unsafe { read_volatile(self) }
    }

    /// Legit autem `self` sine valore ex ea movere.
    /// Quo memoria `self` pariatur.
    ///
    /// Secus `read`, ut Unaligned monstratorem.
    ///
    /// De salute, et vide quia [`ptr::read_unaligned`] exempla.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // Confidenter RECENS `read_unaligned` contractus debeat sustinere salutem.
        unsafe { read_unaligned(self) }
    }

    /// Idea de `count * size_of<T>` bytes `self` ad `dest`.
    /// Et aliudque destination potest fons.
    ///
    /// NOTE: * * ratio habet hunc eundem ordinem in [`ptr::copy`].
    ///
    /// Et vide de exempla [`ptr::copy`] ad salutem.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // Confidenter RECENS `copy` contractus debeat sustinere salutem.
        unsafe { copy(self, dest, count) }
    }

    /// Idea de `count * size_of<T>` bytes `self` ad `dest`.
    /// Ut destination fons et ne * * LINO.
    ///
    /// NOTE: * * et habet haec eadem ratio in ordine [`ptr::copy_nonoverlapping`].
    ///
    /// Vide [`ptr::copy_nonoverlapping`] de salute enim et exempla.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // Confidenter RECENS `copy_nonoverlapping` contractus debeat sustinere salutem.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Computat applicari potest ad necessitates offset ut in regula est ut faciam illud `align` varius.
    ///
    /// Hispania monstratorem Si non potest in `usize::MAX` implementation refert.
    /// Licet implementation pro semper,*et*`usize::MAX` reditus.
    /// Algorithm solum vester est scriptor perficientur potest dependere ab questus offset utibile hic non est eius rectitudo.
    ///
    /// Et offset hoc expressit In `T` quot elementa, neque bytes.Et reddidit pretii adhiberi potest, cum `wrapping_add` modum.
    ///
    /// Nulla non operient cautionibus seu quaecunque firmanda monstratorem prouinciis extra puncta in regula est.
    ///
    /// Est consurgens esse ma gistrum ut bene autem reversus est in verbis quam offset Gratia diei et noctis.
    ///
    /// # Panics
    ///
    /// Quod si `align` panics munus non ex potestate duorum.
    ///
    /// # Examples
    ///
    /// Accessing adjacent ut `u8` `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // dum per `offset` varius regula potest, quod esset de prouinciis extra designandum
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // Utilitatibus consulens, ut `align` sedatus esset potestas est supra II
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Segmentum returns longitudinem metus.
    ///
    /// ** ** quot elementa rediit pretii sit quod non fuerit numerus bytes.
    ///
    /// Munere tuta tametsi rudis segmentum segmentum secundum quod regula non mitti nec Unaligned nulla.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // Salutem tuta est `*const [T]` `FatPtr<T>` idem et arcu.
            // Hoc solum potest `std` spondet.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Quiddam est scriptor refert fragmen rudis monstratorem.
    ///
    /// `self` est equivalent ad `*const T` aliqui sed magis tutum-typus.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Vir rudis refert regula vel subslice ad elementum, fines facere, non reprehendo.
    ///
    /// Et cum hoc modum vocant indicem, aut cum terminis-of-`self` dereferencable non sit *[Finis mores]* etiam si inde non uti regula.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SALUS: ut, in RECENS `self` est dereferencable, et `index` in terminis.
        unsafe { index.get_unchecked(self) }
    }

    /// `None` refert si monstratorem vitio nullitatis infecta, sive aliud redit participatur a FRUSTUM ad valorem `Some` pluribus involuta.
    /// Contraque [`as_ref`], hoc valore habet et quod non eget initialized.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Cum vocant hunc modum: sunt et aut ut * **et* monstratorem nulla sit omnibus haec sit vera:
    ///
    /// * In monstratorem oportet [valid] legit quia pro pluribus `ptr.len() * mem::size_of::<T>()` bytes et varius sit bene.Et hoc maxime est;
    ///
    ///     * FRUSTUM memoriae latitudine totius huius rei est intra unius datum!
    ///       Crustae non potest contra multa spatia obiecti partita imperia.
    ///
    ///     * Tandem etiam nulla sit amet segmenta monstratorem.
    ///     Una ratio ad hoc quod sibi possit enum in layout optimizations references (longitudo inter crustae de quolibet) non-nulla, et varius esse eas distinguere ab aliis data.
    ///
    ///     Vos potest sicut `data` quia nulla est regula, quod est utilis, longitudo uti [`NonNull::dangling()`] purus.
    ///
    /// * In summa magnitudine `ptr.len() * mem::size_of::<T>()` de secare non debet esse maior quam `isize::MAX`.
    ///   Vide documenta ad salutem [`pointer::offset`].
    ///
    /// * Vos Rust imperatorium exeat, de aliasing praecepta, ex quo vita rediit ad arbitrium assumi `'a` est ipsa vita, et qui reflectunt, non necessario ex data.
    ///   In particular, durante hac vita, in memoriam in regula oportet, ut adepto puncta mutatur (nisi intra `UnsafeCell`).
    ///
    /// Haec etsi per hunc modum effectus insolitum?
    ///
    /// Vide et [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // Confidenter RECENS `as_uninit_slice` contractus debeat sustinere salutem.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Ad aequalitatem indicium
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Collatio ad indicium
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}