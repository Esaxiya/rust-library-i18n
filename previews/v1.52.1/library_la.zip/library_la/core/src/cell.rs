//! Partibilis sit mutabilis continentia.
//!
//! Salutem hanc memoriam nititur Rust dantur `T` objectum est solum ut ex sequenti
//!
//! - Pluribus immutabilis Greek (`&T`) obiectum (qui et aliasing ** **).
//! - Unam comparationem mutabiles (T`mut:`) id est (ut etiam mutabiliter ** **).
//!
//! Hoc profecto in Rust compiler.Sed haec regula oculis habita sunt non satis flexibile.Interdum enim quod requiritur ad multa references to object et mutate illud.
//!
//! Scripta sunt in potestate mobilitas modum tute partibilis mutabilis etiam coram aliasing.Facere et pati [`RefCell<T>`] [`Cell<T>`] atque hoc modo per unius-flat.
//! Sed neque `Cell<T>` `RefCell<T>` non est tutum filo subtegminis (non [`Sync`] effectum deducendi).
//! Quod si vos postulo ut facere aliasing et inter mutationem fieri potest utor multiple relatorum [`Mutex<T>`], aut [`RwLock<T>`] [`atomic`] types.
//!
//! Pretio de `Cell<T>` et `RefCell<T>` participatur in figura mutari potest references (id est
//! communi generis `&T`) cum maxime Rust specierum sic mutari potest nisi per unique ('mut&T`) p.
//! Nos autem dicimus `Cell<T>` et `RefCell<T>` providere, intus mutabilitate commoneretur ', quod ostendit, aliter ac typical Rust types' hereditatis immutabilitas.
//!
//! Duo genera cell venient in flavors: et `Cell<T>` `RefCell<T>`.`Cell<T>` varia ab intus arma moventes de numeris et `Cell<T>`.
//! Uti references pro valorum observari debet uti aliquis `RefCell<T>` genus scientiae non est in conspectu ecclesiæ scribe cincinno mutating.`Cell<T>` modi cursuali et mutant praebet valorem hodiernam intus;
//!
//!  - Nam qui types effectum deducendi [`Copy`] in hodiernam [`get`](Cell::get) modum intus retreive valorem.
//!  - Ad hoc efficiendum types [`Default`] et sumitur item loco [`take`](Cell::take) modum intus refert ad valorem damnum et cum [`Default::default()`] valorem.
//!  - Nam dispositis omnis generis tormentis et [`replace`](Cell::replace) modum intus sumitur item loco redit ad valorem damnum et vis ad consumat [`into_inner`](Cell::into_inner) modum `Cell<T>` redit intus valorem.
//!  Insuper, in [`set`](Cell::set) intus valorem eumque modum, posito valore loco.
//!
//! `RefCell<T>` Rust in vita utitur ad effectum deducendi 'dynamic mutuo petere'; quibus potest dici tempus ad processus, exclusive, aditum est ad interiorem valorem posterius mutari potest.
//! RefCell pro bonis detrahebant mihi: <T>World`s sunt eorundem domitorem investigavi, ad runtime ', Rust dissimilis est patria referat sunt omnino genera, quae eorundem domitorem investigavi immobiliter, compile ad tempus.
//! `RefCell<T>` bonis detrahebant mihi quoniam sunt dynamic mutuari a valore fieri potest velle quod iam mutuo acceperam mu-tabiliter inest;Cum hoc accidit autem panic results e sequela.
//!
//! # Cum eligere intus mutabilitate commoneretur
//!
//! Magis commune hereditatis immutabilitas, ut est, ubi unus unique obvius ad mutate et valorem, clavis est unus ex linguae elementa, quae dat valde Rust de regula rationis ad aliasing, quo minus fragore immobiliter bugs.
//! Propter hoc hereditas mutabilitate solum honore antecedentibus, quod intus est, est mutabile aliquid de ultima ratione.
//! In qua cellula cum figura mutationem esset enable quamquam aliter interdici jussimus, ut non numquam intus mutabilem esse oportet, aut etiam * * debet esse, eg
//!
//! * Quod est mutabile ab immutabili 'inside' introducendis
//! * Details ex Logice modi res immobiles, implementation.
//! * Mutating de [`Clone`] implementations.
//!
//! ## Quod est mutabile ab immutabili 'inside' introducendis
//!
//! Multa dolor participatur regula types, inter [`Rc<T>`] et [`Arc<T>`], continentia providere potest cloned et sortitus est sortem inter plures partes.
//! Quia values ut continebat, aliased multiplicetur, non potest fieri nisi per `&` mutuo acceperam, nec `&mut`.
//! Quin intra cellulas impossibile haec notitia ad mutate indicibusque dolor nulla.
//!
//! Est igitur communis regula communi ponere intra `RefCell<T>` generibus conarentùr mutabilitas
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Obstructionum novum creare et finire harum horum mutuo postulaverit in dynamic
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Si non prius nota mutuo nos igitur, postea cadet cache dynamicum filo panic mutuo faciunt.
//!     //
//!     // Maior `RefCell` aleam Hic est usus.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Nota quod exempli gratia utitur, nec `Rc<T>` `Arc<T>`.`RefCell<T>`S sint unum, staminea missionibus.Per consider [`RwLock<T>`] sive eget [`Mutex<T>`] si attendatur mutabilitas participatur in a multi-staminea situ.
//!
//! ## Details of modi res immobiles, implementation logically
//!
//! Interdum ut, ne se petenda API quod non est per mutationem fieri "under the hood".
//! Et hoc potest fieri secundum rationem est, quia operatio est im-mutabilis sit, sed eg, caching exsecutionem viribus praestare mutationem;vel quia trait ad effectum deducendi his necessarium esse mutationem modum primum defined quae ad `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Sequitur hinc sumptuosus computation
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutating implementations de `Clone`
//!
//! Hoc peculiari simpliciter, sed communi, ex causa prior, quae videntur esse latebras varia ad res autem immobiles.
//! Et [`clone`](Clone::clone) modum expectat est fons valorem non immutare, ut `&self` et declaravit, non `&mut self`.
//! Unde nihil `clone` mutationem quod fit per modum debemus uti rationibus cellula.
//! Eg [`Rc<T>`] suam retinere videtur valere referat intra `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Mutabilem memoriae locus.
///
/// # Examples
///
/// In hoc exemplum, vos can videre illam incommutabilem `Cell<T>` dat mutationem intra instrúite.
/// Id est: quia enables "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERROR: `my_struct` sit immutabilis
/// // my_struct.regular_field =New_value;
///
/// // Operibus quidem `my_struct` incommutabile `special_field` `Cell` sit;
/// // mutari non potest, qui semper
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Ecce enim in [module-level documentation](self) magis.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Creates a `Cell<T>` cum valore `Default` apud R.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Novam gignit `Cell` quibus datis valorem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Quod sets continebat valorem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Cellulae duos valores ipsius swaps.
    /// `std::mem::swap` Differentia cum quo est munus non eget `&mut` referat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // Saluti periculosa Id separatarum vocari filis sed `Cell`
        // Hoc est `!Sync` non fore.
        // Hoc quidem non irritum facit omne aliud esse demonstrato argumentis `Cell` cum in utroque: Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Notificata locum tenet `val` cum valorem continebat atque vetus continebat refert ad valorem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // Salute data Hoc genus vocari potest separata a filo
        // et ita non erit `!Sync` `Cell` est.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Unwraps in valore.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Refert exemplum continebat valorem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // Salute data Hoc genus vocari potest separata a filo
        // et ita non erit `!Sync` `Cell` est.
        unsafe { *self.value.get() }
    }

    /// Continebat valorem updates in usus ac munus novae redit valorem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Redit monstratorem underlying rudis est in cellula data.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Redit mutabilis ad subjectam data.
    ///
    /// Hanc mutuatur mutabiliter `Cell` (at compile tempus) qui solus praestat Habemus referantur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Refert ad `&Cell<T>` ex `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // Utilitatibus consulens `&mut` ensures unique obvius.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Sumit de valore cellulam, `Default::default()` in suo relinquens locum.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Refert ad `&[Cell<T>]` ex `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // Utilitatibus consulens `Cell<T>` habet sicut idem layout memoria `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Mutuatur alacriter repressit memoriae mandata sunt mutabilem situm
///
/// Ecce enim in [module-level documentation](self) magis.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Error rediit a [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Error in rediit [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Values numerum positivum repraesentat `Ref` activae.Numerus negative repraesentaturi erant `RefMut` activae.
// RefMut`s multiplici modo agere: tum si ad distinctam a `RefCell` nonoverlapping partium (ut diversis ordinibus segmentum).
//
// `Ref` et `RefMut` duo verba sint et magnitudine; et ideo non est probabile esset satis: neque aut exercitus Ref`s RefMut`s in esse medium per redundantiam `usize` range.
// Et sic, erit verisimile nunquam redundantiam a `BorrowFlag` aut underflow.
// Sed hoc non est cautum tanquam dogma pathologi-cum saepe progressio potest creare et mem::forget Ref`s 'seu`RefMut`s.
// Unde oportet omnem codice expressum reprehendo inundans underflow unsafety ne saltem FACIO aut recte factum inundantes underflow fit (ut videre BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Creates a quibus `RefCell` `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` consumit, est involutus reversus valorem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Quia hæc munus sumit `self` (in `RefCell`) ab valorem, quod non est currently compiler immobiliter certificat sit mutuo acceperam.
        //
        self.value.into_inner()
    }

    /// Notificata locum tenet in nova autem pretii pannis, redeuntem senem valore, sine deinitializing vel unum.
    ///
    ///
    /// Hoc munus respondet [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Si is currently Panics valorem mutuo acceperam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Notificata locum tenet novus apud se depositum involvit pretii `f` conputatum reverten antiquam valorem sine deinitializing vel unum.
    ///
    ///
    /// # Panics
    ///
    /// Si is currently Panics valorem mutuo acceperam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Et pannis involuta pretium pretium cum strigili `self` `other` non deinitializing alterum.
    ///
    ///
    /// Hoc munus respondet [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics si in valore est currently `RefCell` vel mutuo acceperam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Pretii pannis involutum et immutabiliter horum mutuo postularit.
    ///
    /// Horum mutuo postularit et durat usque ad `Ref` reddidit exitus scope.
    /// Pluribus simul sumpta esse immutabiles detrahebant.
    ///
    /// # Panics
    ///
    /// Si Panics pretii est currently mu-tabiliter inest mutuo acceperam.
    /// Quia non est variante TREPIDANS, utere [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// An example of panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Horum mutuo postularit incommutabiliter super pretii pannis involutum, reversus est error, si in valore est currently mu-tabiliter inest mutuo acceperam.
    ///
    ///
    /// Horum mutuo postularit et durat usque ad `Ref` reddidit exitus scope.
    /// Pluribus simul sumpta esse immutabiles detrahebant.
    ///
    /// Hoc variante TREPIDANS de non-[`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // Utilitatibus consulens `BorrowRef` invigilat, quod non modo sit mutabilis obvius
            // ad valorem cum mutuo acceperam.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mu-tabiliter inest valorem horum mutuo postularit et depositum involvit.
    ///
    /// Quod horum mutuo postularit `RefMut` perseverat usque ad rediit et 'omne quod exit ex RefMut`s scope.
    ///
    /// De valore activae esse non potest mutuatus in hac mutuo postulaverit.
    ///
    /// # Panics
    ///
    /// Si is currently Panics valorem mutuo acceperam.
    /// Quia non est variant TREPIDANS, utere [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// An example of panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mu-tabiliter inest mutuo postulaverit ad depositum involvit valore; valorem si reversus est currently errorem mutuo acceperam.
    ///
    ///
    /// Quod horum mutuo postularit `RefMut` perseverat usque ad rediit et 'omne quod exit ex RefMut`s scope.
    /// De valore activae esse non potest mutuatus in hac mutuo postulaverit.
    ///
    /// Hoc non-[`borrow_mut`](#method.borrow_mut) TREPIDANS variant.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // Utilitatibus consulens `BorrowRef` unique obvius praestat.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Redit monstratorem underlying rudis est in cellula data.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Redit mutabilis ad subjectam data.
    ///
    /// Haec vocatio `RefCell` mutuo postulaverit mu-tabiliter inest (compile-a time) ita nullum est opus dynamic checks.
    ///
    /// Caveat autem, Expectat `self` hunc modum est mutabilis est, quae est fere non si quando usus `RefCell`.
    ///
    /// Pro [`borrow_mut`] ad modum si take a vultus `self` est mutabile.
    ///
    /// Etiam, placere nisi per conscientiam hunc modum peculiaribus rerum adiunctis, quae non plerumque vis.
    /// In casu autem dubium utere pro [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Undo fit status `RefCell` quaeque mutuo custodibus.
    ///
    /// Sed propria Hanc [`get_mut`] similis.
    /// Quod horum mutuo postularit et resets `RefCell` mu-tabiliter inest ut est nulla re publica bonis detrahebant mihi tracking shared bonis detrahebant mihi.
    /// Hoc autem pertinet `Ref` si alii bonis detrahebant sunt `RefMut` non leaked.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Horum mutuo postularit incommutabiliter super pretii pannis involutum, reversus est error, si in valore est currently mu-tabiliter inest mutuo acceperam.
    ///
    /// # Safety
    ///
    /// Dissimilis `RefCell::borrow` hanc methodum non reddere `Ref` tuta haec vexillum intactum relinquentes postulet.
    /// Dum rediit referat `RefCell` mu-tabiliter inest mutuatus est ab hac modum vivens mores Finis est.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // Salutem et quod nullus Non reprehendo se active nunc scribo, sed ut sit
            // RECENS efficere nemo scribit ut non iam in usum referat ad rediit.
            // Item, `self.value.get()` refert ad valorem amet `self` et sic ratum esse monet, ut pro vita ex `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Accipit et depositum involvit value, `Default::default()` in suo relinquens locum.
    ///
    /// # Panics
    ///
    /// Si is currently Panics valorem mutuo acceperam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Si Panics pretii est currently mu-tabiliter inest mutuo acceperam.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Creates a `RefCell<T>` cum apud R. valorem `Default`
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics si in valore est currently `RefCell` vel mutuo acceperam.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics si in valore est currently `RefCell` vel mutuo acceperam.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics si in valore est currently `RefCell` vel mutuo acceperam.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si in valore est currently `RefCell` vel mutuo acceperam.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si in valore est currently `RefCell` vel mutuo acceperam.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si in valore est currently `RefCell` vel mutuo acceperam.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics si in valore est currently `RefCell` vel mutuo acceperam.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Incrementing result in a non potes horum mutuo postulaverit reading-value (<=0) in huiusmodi casibus:
            // 1. Non autem <0, non est id scribo bonis detrahebant mihi, ut permittere possumus legere postulet a tempore usque ad aliasing praecepta referat Rust est scriptor
            // 2.
            // isize::MAX non est (enim max tantum bonis detrahebant mihi legendi) isize::MIN, et in aquas (quod max tantum bonis detrahebant mihi scribo), ut nobis non liceat aliquid etiam horum mutuo postulaverit legere legere multis bonis detrahebant mihi quoniam isize potest, nemo vero sic (quod non fit nisi nisi mem::forget tibi magis quam moles parvis constant Ref`s: quod non bonum usu est)
            //
            //
            //
            //
            None
        } else {
            // Lectio mutuo postulaverit incrementing aliud in valorem (> 0) in huiusmodi casibus:
            // 1. =Sit 0, ita id non alieno, et tuleris summam primum legere horum mutuo postularit
            // 2. Fuit> 0 atque <isize::MAX, id est
            // erant legere bonis detrahebant mihi: et isize satis magna est ad repraesentandum unum habent legere horum mutuo postulaverit
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Quae cum external link existit, we know horum mutuo postulaverit vexillum ad est a Lectio horum mutuo postulaverit.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Ex horum mutuo postulaverit contra inundare consuevit ne in scripto horum mutuo postulaverit.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Inducitur ad aliena pretii sit in arca archa `RefCell`.
/// A serratus type et mutuati ad valorem ex `RefCell<T>` immutabiliter.
///
/// Ecce enim in [module-level documentation](self) magis.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Idea enim `Ref`.
    ///
    /// Et iam `RefCell` mutuo acceperam immutabiliter, id est non deficere.
    ///
    /// Hic est qui munus indiget ad esse ut sociis `Ref::clone(...)`.
    /// `Clone` implementation A intermixti vel per modum esse latos usum `r.borrow().clone()` clonem contenta in `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Facit `Ref` novam elementum ad mutuum data.
    ///
    /// Et iam `RefCell` mutuo acceperam immutabiliter, id est non deficere.
    ///
    /// Et hoc est esse quod `Ref::map(...)` quae indiget et adiuncti munus.
    /// Intermixti essent modi ejusdem nominis&media G. de et super contentis in `RefCell` usus est in `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// `Ref` facit ad novam elementum ad libitum data mutuo acceperam.
    /// A custodia originale sicut in rediit `Err(..)` `None` refert si Agricola.
    ///
    /// Et iam `RefCell` mutuo acceperam immutabiliter, id est non deficere.
    ///
    /// Associated Haec est quae indiget et esse, ut munus `Ref::filter_map(...)`.
    /// Intermixti essent modi ejusdem nominis&media G. de et super contentis in `RefCell` usus est in `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Et in pluribus: Ref`s scindit `Ref` mutuo diversarum partium elit.
    ///
    /// Et iam `RefCell` mutuo acceperam immutabiliter, id est non deficere.
    ///
    /// Hoc est munus adiuncti esse necessitatis sicut `Ref::map_split(...)`.
    /// Intermixti essent modi ejusdem nominis&media G. de et super contentis in `RefCell` usus est in `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Ad conversus, in interiore notitia.
    ///
    /// Nusquam etiam mutabiliter `RefCell` subditis mutuo petierunt et incommutabiliter est semper.
    ///
    /// Est non constant magis quam bonum idea de Claudia rimis fatiscere.
    /// Et iterum sumamus immutabiliter `RefCell` potest fieri nisi prorsus pauciores libero.
    ///
    /// Est ad munus illius adiuncti esse debet ut `Ref::leak(...)`.
    /// Intermixti essent modi ejusdem nominis&media G. de et super contentis in `RefCell` usus est in `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Ut id obliuiscendo Ref postulet autem in contrarium ire nequeat NOVUS RefCell `'b` in vita.
        // Quantum ad singularem sequi resetting res exigeret RefCell mutuo.
        // No references adhuc posterius mutari potest ex originali creatus cellula.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Nova facit omnia partem boni `RefMut` pro data mutuo acceperam, eg, per enum variant.
    ///
    /// Et iam `RefCell` mu-tabiliter inest feneravit mihi hoc ut nunquam deficere possit.
    ///
    /// Hoc munus coniungitur necessitatis esse quod `RefMut::map(...)`.
    /// Intermixti essent modi ejusdem nominis&media G. de et super contentis in `RefCell` usus est in `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): - fix reprehendo horum mutuo postulaverit
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Ad libitum est `RefMut` omnia partem boni facit nova notitia mutuo acceperam.
    /// A custodia originale sicut in rediit `Err(..)` `None` refert si Agricola.
    ///
    /// Et iam `RefCell` mu-tabiliter inest feneravit mihi hoc ut nunquam deficere possit.
    ///
    /// Hoc munus et adiuncti esse necessitatis sicut `RefMut::filter_map(...)`.
    /// Intermixti essent modi ejusdem nominis&media G. de et super contentis in `RefCell` usus est in `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): - fix reprehendo horum mutuo postulaverit
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // Incolumes functioni retinet ordine durationis consuetudine
        // `orig` per vocationem suam et sit regula de intus referenced munus vocatus, licet non quantum ad proprias fugere.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SALUS, sicut etiam supra.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Multiplex et uniformiter in `RefMut` RefMut`s diversa partium`mutuo elit.
    ///
    /// `RefCell` interiore et mutabiliter permanent usque mutuatus rediit et 'egredi ex scope RefMut`s.
    ///
    /// Et iam `RefCell` mu-tabiliter inest feneravit mihi hoc ut nunquam deficere possit.
    ///
    /// Est ad munus illius adiuncti esse debet, ut `RefMut::map_split(...)`.
    /// Intermixti essent modi ejusdem nominis&media G. de et super contentis in `RefCell` usus est in `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// In interiore notitia conversus ad commutabile.
    ///
    /// Et non est sumptum subjectam `RefCell` mutabiliter est semper alieno solo interiori ordine facto rediit.
    ///
    ///
    /// Hoc munus, quod necesse est esse, sicut et adiuncti `RefMut::leak(...)`.
    /// Intermixti essent modi ejusdem nominis&media G. de et super contentis in `RefCell` usus est in `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Ut in ea nobis oblivio BorrowRefMut RefCell mutuo non in contrarium ire NOVUS `'b` in vita.
        // Quantum ad singularem sequi resetting res exigeret RefCell mutuo.
        // References amplius non potest creatum quod in originali cellam in vita sua, faciens referat ad reliqua vita tantum in current bonis detrahebant mihi.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Secus BorrowRefMut::clone, dicitur novam creare initial
        // mutabilis reference; et ideo oportet quod currently non existentium p.
        // Ut, incrementa dum mutabile refcount cDNA, hic expressis verbis nos permittit nisi agatur de eius insueta expavisset INEXPERTUS, I.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clones de `BorrowRefMut`.
    //
    // Haec utraque solitarie `BorrowRefMut` semita dicitur mutabile respectu distinctionis primo obiecto nonoverlapping rhoncus.
    //
    // Hoc impl clone: Non est in codice, ut hic vocant, non per sensum.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Ne ab contra underflowing horum mutuo postulaverit.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// A type serratus mu-tabiliter inest ad valorem ex `RefCell<T>` mutuo acceperam.
///
/// Ecce enim in [module-level documentation](self) magis.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Core primitivum est in alterutro mutabilitas intus Rust.
///
/// Si autem referat `&T` ergo ad fungendum aptam, in Rust compiler optimizations facit secundum scientia demonstrat quod `&T` res data.Data Mutating ut, exempli gratia per quod alias non est `&T` transmutando in `&mut T` est, indefinitam mores consideretur.
/// `UnsafeCell<T>` de-opts hæredibus, immobilitatem fideiussor habendi pro eo `&T`: participatur in `&UnsafeCell<T>` ut referat quae ad hoc data est mutari.Et hoc dicitur "interior mutability".
///
/// Aliae internae factae patitur ut `Cell<T>` `RefCell<T>` et interne ad usum data `UnsafeCell` utrumque.
///
/// Et nota quod non est guarantee shared references and accipiatur immutabilitas sit affectus `UnsafeCell`.Quod peculiare quiddam references reddere pignus, commutabilis.* * Iure nullum est `&mut` itinere, ut sumerem aliasing non etiam cum `UnsafeCell<T>`.
///
/// Et valde technica `UnsafeCell` API ipsum esse simplex, rudis [`.get()`] dederit vobis `*mut T` regula ad singula contenta in eodem._you_ ad modum abstractionis non est sicut excogitatoris quia ut bene rudis regula.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Et precise Rust aliasing praecepta aliquantulum in motu et fluxu, at praecipua sunt ex contentione;
///
/// - Si enim tuto Respicitur tecum vivit `'a` (vel `&T` vel `&mut T` Edition) est accessibilis tutum codice (puta quia reddidit) reddet obvius notitia ullatenus contradicit referimus reliquum et `'a`.
/// Nam id a te accipere `*mut T` `UnsafeCell<T>` projecerunt ad `&T` igitur indicia `T` maneat immutabile (modulo invenitur aliqua notitia `UnsafeCell` `T` quidem) usque comparationem vita exspirat.
/// Et similiter si `&mut T` reference creata est ut sit tutum codice ei dimisit, tunc oportet tibi accedere non est data in se referat ad `UnsafeCell` parere.
///
/// - Semper caventes vobis gentibus data.Si habes plures aditus ad idem `UnsafeCell` relatorum, deinde quid scribit fieri debet habere, propriis coram omni relatione aliarum febrium (vel uti Atomics).
///
/// Iuvare suo consilio unius fila sequente missionibus licet explicite declaratur code
///
/// 1. A reference `&T` possit esse incolumem dimisit non possit simul esse cum alio codice et `&T` agitur, non est tamen `&mut T`
///
/// 2. A reference `&mut T`, ut salvus esse non dimisit nec alio codice provisum `&mut T` `&T` non coexistunt in ea.A unique `&mut T` est semper.
///
/// Ut mutating Nota cum contenta `&UnsafeCell<T>` est (etiam references dum alii alias `&UnsafeCell<T>` cellula) est ok (provisum est supra repetere, et alia via invariants), usque indefinitum est plures mores ut `&mut UnsafeCell<T>` aliases.
/// Hoc est, quod `UnsafeCell` serratus commercium cum _shared_ accesses (_i.e._ disposito specialis habere, per quod referat `&UnsafeCell<_>`): omne agens _exclusive_ accesses (_e.g._ justo nulla Per `&mut UnsafeCell<_>`) nec valet esse involutos aut cellam illius durationis aliased `&mut` accipies.
///
/// Hoc est [`.get_mut()`] accessor showcased per quam facit id est _safe_ getter `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Showcasing Hic est exemplum esse quam bene mutate `UnsafeCell<_>` non obstante illa quae ibi esse multa references ad aliasing cellulam:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Ut plures/quae ad eandem participatur `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // Salutem et in scope est hic sunt `x` ut de aliis contentis,
///     // ut nostrum unicum effectum.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- horum mutuo postulaverit-+
///     *p1_exclusive += 27; // |
/// } // <---------- quod punctus non supergrediatur -------------------+
///
/// unsafe {
///     // Salutem et nullus Expectat in hac scope scriptor habere exclusive obvius ei: x` contenta in eodem,
///     // commune pluribus simul ut cognoscamus aditus.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Exempli gratia showcases in hoc quod obvius exclusive obvius exclusive pertinet ad `UnsafeCell<T>` `T` suo:
///
/// ```rust
/// #![forbid(unsafe_code)] // cum febrium exclusive;
///                         // `UnsafeCell` non est transparent-op serratus, ut nihil opus `unsafe` hic.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // A singulari praedicatur Compile vicis-`x` repressit.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Cum dictio exclusiva referat, posse mutate quae in nobis est liberum.
/// *p_unique.get_mut() = 0;
/// // Aut aequivalenter;
/// x = UnsafeCell::new(0);
///
/// // Cum ad valorem habere: et ideo possunt abstrahi liberos pro contentis in eodem.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Exempli gratia ex surculis construere novum `UnsafeCell` quod involvent certa ad valorem.
    ///
    ///
    /// Omnes interiore aditum ad valorem in usum `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Unwraps in valore.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Ad depositum involvit valorem indicatorum accipit mutabilem uerteretur.
    ///
    /// Mitti potest aliqua regula.
    /// Ut non ad obvius unique (activae nec agitur, nec mutabilem) Cum projicere `&mut T`, atque ut illic es non iens mutationes in quo est et mutabilis aliases projicere `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Possumus `UnsafeCell<T>` eiectum esse ab `T` propter #[repr(transparent)] monstratorem.
        // Hic status titulos inponimus libstd in speciali, quia nihil cautum est, ut hoc opus in codice user future compiler de versions?
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Redit mutabilis ad subjectam data.
    ///
    /// Hanc mutuatur `UnsafeCell` mutabiliter (Compile ad tempus) qui solus praestat Habemus referunt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Ad depositum involvit valorem indicatorum accipit mutabilem uerteretur.
    /// Discrimen autem, qui ad hoc munus acceperit rudis [`get`] monstratorem, quod est utile ad vitare temporalis creaturae Dei indiciorum.
    ///
    /// Ex aliqua regula potest mitti.
    /// Ut ex unique obvius is (non activae agitur, non quod nutabile aut volubile) Cum projicere `&mut T`, et ut posterius mutari non sunt mutationes aliases agatur, ubi neque projicere `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Psalm ad initialization de `UnsafeCell` `raw_get` postulat, ut vocantem se requirere `get` uninitialized ad partum a notitia;
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Possumus `UnsafeCell<T>` eiectum esse ab `T` propter #[repr(transparent)] monstratorem.
        // Hic status titulos inponimus libstd in speciali, quia nihil cautum est, ut hoc opus in codice user future compiler de versions?
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Gignit et `UnsafeCell` cum `Default` valorem T. Wood
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}