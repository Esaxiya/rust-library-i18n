#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A significat asynchronous future vertant.
///
/// future valorem, quod non est A sed consummavi computandi.
/// "asynchronous value" ex hoc quod facit posse in momento et continue utilis operis facere ad valorem usque dum expectatur facti sunt available.
///
///
/// # In modum `poll`
///
/// Core modum future, `poll`,* * conatus ad propono in ultima future ad valorem.
/// Haec modum pretii si angustos non est paratus.
/// Instead: et ut current negotium venturus est cum vigil factus est cum eo qui fieri potest, ut longius progressus poll`ing iterum.
/// De transitu ad `context` `poll` praebere possunt per modum [`Waker`], qui se ansam retinere omnium current negotium in somno expergiscitur.
///
/// Cum usus future, te voco `poll` plerumque non directe, sed pro `.await` ad valorem.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Genus est complementum et productum valorem.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Conatus propono in future ad extremum valore: current perscriptum est negotium valorem ad WakeUp si non est tamen paratum.
    ///
    /// # Redi pretii
    ///
    /// Hoc munus redit;
    ///
    /// - [`Poll::Pending`] Nondum est future si
    /// - [`Poll::Ready(val)`] Hoc confecto `val` future si ita feliciter.
    ///
    /// Cum autem consummatum future est, clients ut non `poll` illud.
    ///
    /// Cum paratus future Atqui redeunti `poll` `Poll::Pending` recondit a clone de currenti [`Context`] [`Waker`] scriptam.
    /// Hoc est ergo [`Waker`] vigil olim future possit proficere.
    /// Eg future exspectantes per bases singulas supputatis facti sunt readable se vocant `.clone()` in [`Waker`] et comportabis apud te.
    /// Cum alibi advenit signo instantis iuxta ostium tabernaculi quod sit readable, et ad ostium tabernaculi future [`Waker::wake`] dicitur negotium est scriptor recensetur.
    /// Semel has been opus sit vigil factus, quod conarentur in `poll` future iterum cuius ultima vel non producendum est pretii.
    ///
    /// Nota ut `poll` vocat, quae est plures, nisi ex [`Waker`] [`Context`] Transierunt recentissimus ad vocationem deberet accipere scheduled enim WakeUp.
    ///
    /// # habet runtime
    ///
    /// Solus * * Futures efficaciæ iners,* * poll`ed oportet quod actu est proficere, ad designandum quod per hodiernam tempore opus est vigil factus est, debet active rursus`poll` futures pendente placito quod habet tamen in faenore.
    ///
    /// Quod munus `poll` non est nomine saepe in arta-loco, qui dicitur cum non sit nisi paratus sit ad profectum future indicat (per `wake()`) vocant.
    /// Si nota erant cum eo in `poll(2)` aut `select(2)` syscalls in Unix occurrit notatione dignum, quod saepe futures * * non patiatur ab idem problems "all wakeups must poll all events";sunt magis amo `epoll(4)`.
    ///
    /// Ad exsequendam citius `poll` conabitur, nec impedit.Ne superflue reddens cito obstruxerunt implentes humo et res ora sagi alterius relatorum.
    /// Si enim hoc notum ante tempus vocatio ad `poll` ut terminus sursum tollens parumper a filo subtegminis usque ad piscinam offloaded debere opus (aut aliquid huiusmodi) `poll` ut cito redire potest.
    ///
    /// # Panics
    ///
    /// Cum autem future has completed (redierat ab `Ready` `poll`) vocantem ad modum `poll` panic ut iterum: angustos æternum, aut quibuscunque aliis infestati causa problems;requiruntur ad talem effectum est `Future` trait nemo luctus.
    /// Tamen, quod non `poll` modum `unsafe` notata, Rust praecepta solitum est adhibere, est non causa, vocat mores Finis (memoria corruptae vitae, uti `unsafe` falsa munera, aut similis), nec adhuc de statu future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}