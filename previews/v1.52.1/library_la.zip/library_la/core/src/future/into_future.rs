use crate::future::Future;

/// Conversionem in `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// In output future autem producendum est quod complementum.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Qua tandem future aversi sumus?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Et ex gignit future valorem.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}