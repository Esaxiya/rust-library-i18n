use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Fascia statim ab A ad inhibere compiler vocant: T` est destructor.
/// Hoc est serratus 0-cost.
///
/// `ManuallyDrop<T>` layout optimizations `T` ut eidem subest.
/// Et per consequens est quod effectus *a* non Isto posito quod facit compiler de contentis in eodem.
/// Exempli gratia, in initializing `ManuallyDrop<&mut T>` [`mem::zeroed`] cum indefinita sit morum.
/// Si opus tractamus uninitialized data utere loco [`MaybeUninit<T>`].
///
/// Nota, quod interius de accessu ad valentiam `ManuallyDrop<T>` tutum est.
/// `ManuallyDrop<T>` hoc modo ut sit contentus est cui non potest patere per publicum elapsum est tutum API.
/// Ergo etiam, `ManuallyDrop::drop` sit tutum.
///
/// # `ManuallyDrop` et fluent ordinem.
///
/// Rust bene terminis circumscriptos [drop order] habet virtutes examinamus.
/// Ut agri ut non locus fac instillatur certa certisve ordine, reordinatque verba talis ut stilla implicita sit verum unum.
///
/// Hoc potest ad moderari `ManuallyDrop` gutta ordinis, sed hoc requirit dura et statio male fida codice coram unwinding recte facere.
///
///
/// Exempli gratia: Si vis fac ut propriam instillatur cum aliis, tandem ad eam instrúite agro:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` et omitteretur institutum post `children`.
///     // Rust praestat ut agris ordo declarationem instilletur.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Ut manually valorem involvent est factus.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Vos can tutus agunt etiam de valore
    /// assert_eq!(*x, "Hello");
    /// // Hic non currunt sed `Drop`
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extrahit ex valore `ManuallyDrop` continentis.
    ///
    /// Hoc permittit fieri valorem stillaret iterum.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Hoc `Box` deponat.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// A quo est `ManuallyDrop<T>` de valore sumit.
    ///
    /// Et hoc est principale intentum ad movere ex numeris modum gutta.
    /// Per manually [`ManuallyDrop::drop`] loco usque concrescunt valorem, vos can utor ad modum ad hunc valorem et tamen desideravit uti.
    ///
    /// Cum possibile est ut [`into_inner`][`ManuallyDrop::into_inner`] pro potior, per quam crimina contentus de duplicatione `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Semantically munus ad hoc tendere non continebat valorem usus prohibentis ulteriorem, hoc relinquo in statu quo est immutatus.
    /// Et respondens `ManuallyDrop` ut non usus hoc iterum.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // Utilitatibus consulens legere sumus de referat est, quod praestatur
        // legit enim est verum.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Manually deponat valorem continebat.Hoc est prorsus equivalent ad vocantem [`ptr::drop_in_place`] valorem cum monstratorem continebat.
    /// Ut haec, nisi valorem continebat instruere est stipata et destructor, in loco qui dicitur voluntas non de valore movere, et sic potest salvum perducerent ad stillabunt [pinned] data.
    ///
    /// Si enim rerum valorem, vos can utor pro [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Hoc munus continebat decurrit ad destructor et valorem.
    /// Destructor fiunt mutationes per quam se, et egressus est memoria integra et usque compiler ut sit documentum, quod etiam tenet paulum valet ad genus `T`.
    ///
    ///
    /// Sed hoc "zombie" valore non sit tutum patere Code et non dicitur hoc munus ne plus quam semel.
    /// Uti vir suus 'valorem post elapsum excidit, aut per valorem stillabunt multa temporum non faciam Undefined Behavior (`drop` quibus fretus agit).
    /// Hoc genus non posset, Northmanni ratio et facies iudicium eorum polliceri non est auxilium users of `ManuallyDrop` ex compiler.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // Salutem et sunt ostendens per valorem omissa ad commutabile reference
        // quibus praestatur invalidam esse scribit.
        // Quia non est usque in RECENS fac `slot` est iterum, non ponitur.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}