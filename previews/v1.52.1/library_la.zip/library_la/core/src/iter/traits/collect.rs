/// Inde per conversionem [`Iterator`].
///
/// Per `FromIterator` in effectum ducenda generis, define vos et quomodo a creatum est iterator.
/// Haec collectio quaedam communis generis describunt.
///
/// [`FromIterator::from_iter()`] raro expressis vocavit est, et pro usus per modum [`Iterator::collect()`].
///
/// Videre enim potius [`Iterator::collect()`]'s documentis exempla.
///
/// Vide quoque: [`IntoIterator`].
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Ut per [`Iterator::collect()`] `FromIterator` implicite utitur:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Exsequendam `FromIterator` genus tuum:
///
/// ```
/// use std::iter::FromIterator;
///
/// // A sample collectione, id est iustum est fascia super Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Sit scriptor ut possimus reddere partum et alii modi unum et addere rebus ad eam.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // et effectum deducendi te FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Non possumus facere iterator autem nova ...
/// let iter = (0..5).into_iter();
///
/// // ... et ab MyCollection faciet illud
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // collecta opera quoque
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Gignit et valorem quod de iterator.
    ///
    /// Ecce enim in [module-level documentation] magis.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Per conversionem in [`Iterator`].
///
/// Per `IntoIterator` ad effectum deduci genus, define et quomodo conversi fueritis ad iterator.
/// Haec collectio quaedam communis generis describunt.
///
/// Unum bonum `IntoIterator` exsequendam, quod erit vestri generis [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Vide quoque: [`FromIterator`].
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Pro exsequendam `IntoIterator` genus;
///
/// ```
/// // A sample collectione, id est iustum est fascia super Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Sit scriptor ut possimus reddere partum et alii modi unum et addere rebus ad eam.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // et te effectum deducendi IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Hoc autem non potest facere novum collection ...
/// let mut c = MyCollection::new();
///
/// // ... adde supellectilem quidam ad illum ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // Et in ... conversus est ad Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` est commune ut pro trait bound.Haec collectio genus initus ad mutationem patitur, dummodo adhuc sit in iterator.
/// Additional possunt recipiunt speciem a termino ad fines
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Et ferè per rationem sunt elementa.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Qua tandem verto iterator sumus?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Gignit et iterator ex valorem.
    ///
    /// Ecce enim in [module-level documentation] magis.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Extend quippe secundum quod est collectio iterator.
///
/// Iterators produce serie values, et collections quasi quoque potest ex serie rerum aestimationem prae cogitatur.
/// Hoc intervallum `Extend` trait pontes et sino vos ut dilatare contentis iterator includendo colligit.
/// Usque dum colligit existens cum clavibus updated est introitus vel permittere ut in pluribus collectis viscus pari clavium introitum ponitur.
///
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// // Gloria in porrigendum confer Vos can aliquam chars:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementing `Extend`:
///
/// ```
/// // A sample collectione, id est iustum est fascia super Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Sit scriptor ut possimus reddere partum et alii modi unum et addere rebus ad eam.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ex quo album i32s MyCollection habet, ut ad effectum deducendi Extende i32
/// impl Extend<i32> for MyCollection {
///
///     // Hoc est aliquantulus simpler generis cum solido signature: non possumus appellare qui potest quicquam de extend et Convertétur in Iterator qui dat nobis i32s.
///     // Quia opus i32s in MyCollection ad induendum.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Exsequendam fuerit ipso straightforward, per loop iterator et add() ut ipsi inter se elementum.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // extendere ultra tres numeri collecta scriptor
/// c.extend(vec![1, 2, 3]);
///
/// // weve 'onto fine addita sunt elementis
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Protenditur collectio quippe secundum quod iterator.
    ///
    /// Hoc est quod non requiratur ad hunc modum trait in [trait-level] baud amplius singula continent.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // Gloria in porrigendum confer Vos can aliquam chars:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Patet apud sed unum collectio a elementum.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Subsidia collectis per facultatem ad datum numerum additional elementa.
    ///
    /// Default et non implementation nihil.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}