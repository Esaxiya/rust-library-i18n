// bene servetur, filelength ignorare, hoc solum consistit in hoc quod fere file `Iterator` definitionem.
// Scinditur, ut multa non possumus in files.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// An interface iterators demonstrare.
///
/// Haec est principalis trait iterator.
/// Nam plerumque iterators de conceptum Dei, et videbis [module-level documentation].
/// Maxime, vos may volo scio quam [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Et ferè per rationem sunt elementa.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Et refert altera valorem progreditur iterator.
    ///
    /// Dum redit [`None`] iteratione finitur.
    /// Iterator singula implementations eligere possunt reuocare iteration, et iterum vocant `next()` potest vel non potest eventually reversus [`Some(Item)`] satus iterum procul aliquo puncto.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Refert ad theologum quendam next() proximo utilitas circumcisionis ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // Et in ... Nihil est statim.
    /// assert_eq!(None, iter.next());
    ///
    /// // Et non potius ut reverterentur `None` vocat.Hic autem semper in.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Terminis iterator longitudine reliquum redit.
    ///
    /// In specie refert `size_hint()` tuple in quo primum elementum quod est minus tenetur, secundum quod est superius elementum tenetur.
    ///
    /// Secundum tuple medium de sit reddidit est quod [`Option`]`<: [`usize`] '>:.
    /// A hic aut nihil est [`None`] superior seu superior maior [`usize`].
    ///
    /// # notas implementation
    ///
    /// Cedit iterator declarabat quod coeptum non turpis numerum elementorum.Et gignat iterator Buggy minus quam superior sive inferior elementorum.
    ///
    /// `size_hint()` praesertim optimizations ut est in animo adhiberi retinendo tantum spatii de elementis iterator: sed non debet esse confidebat eg, tuta non est in codice checks terminis Antiphona.
    /// Ad exsecutionem memoria `size_hint()` alienae salutis non violationes.
    ///
    /// Quod ait de implementation sit recta providere aestimationem reddere, quia aliter esset vir contra est quod trait protocol.
    ///
    /// Et default redit implementation `(0: [` None`]`): quod verum est, quis enim iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// A more universa exemplum:
    ///
    /// ```
    /// // Decem numeris par nulla.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Ut iterate decies ro.
    /// // Sciens quoniam non potest esse sine exsecutioni mandandis non est exacte quinque filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Addere numerus quinque lets 'magis per chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // Quinque modum augentur Utrumque
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Reversus est quia `None` superius tenetur;
    ///
    /// ```
    /// // quae infinita est iterator non potest superiores inferioribus maxime tenetur, et vinctum
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Manducat iterator, et iterations computatis numerus reversus est.
    ///
    /// Et [`None`] ad modum appellant [`next`] haec saepe occurrit, reversus est videns [`Some`] numerum temporum.
    /// Nota [`next`], quae dicta est ut saltem semel, et si non habes elementa iterator.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # redundantiam MORES
    ///
    /// Modo nihil superfluit cavendi sic numerat iterator ex elementis fit plus mali effectum panics [`usize::MAX`] elementum vel.
    ///
    /// Si autem diceret enabled debug a panic praestatur.
    ///
    /// # Panics
    ///
    /// Si hoc munus fortitudine panic iterator plus habet [`usize::MAX`] elementa.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Manducat iterator, reversus ultima elementum.
    ///
    /// Iterator talem quidem modum aestimandi, donec refert [`None`].
    /// Dum ita faciens, et servat track in current elementum.
    /// Postquam is rediit [`None`], et tunc revertetur `last()` quia ultimum elementum vidit.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` progreditur ab elementis iterator.
    ///
    /// Haec modum skip sollicita `n` ab elementis vocant [`next`] temporibus usque ad `n` [`None`] est offendit.
    ///
    /// `advance_by(n)` Si converteris iterator [`Ok(())`][Ok] nititur `n` elementum tincidunt vel [`Err(k)`][Err] [`None`] Si occurritur in elementis iterator `k` crescit numerus particularum ante excurrant (ie
    /// longitudo iterator).
    /// Nota quod `k` semper minus quam `n`.
    ///
    /// `advance_by(0)` vocant nec tamen consumetur nec quisquam elementa et semper [`Ok(())`][Ok] refert.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // omittendum est modo `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Redit ad ly 'n`th elementum iterator.
    ///
    /// Iudex rebus veluti comes incipit nihilo igitur primo refert `nth(0)` pretium `nth(1)` alterum cetera.
    ///
    /// Omnia nota praecedenti elementum ut reverterentur elementum consumentur a iterator.
    /// Id praecedenti abdicavit elementa, eadem quoque iterator rursum vocare `nth(0)` pluribus diversis temporibus.
    ///
    ///
    /// `nth()` si redeat [`None`] `n` longitudinem paribus major iterator.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Non plures temporum `nth()` vocant rewind quod iterator;
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Si minus, quam `n + 1` `None` reversus sunt elementa,
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Et incipiens ad idem punctum iterator gignit, sed per sese dedit in quantum quisque iterationem.
    ///
    /// Nota I: iterator semper sit ad Primum rediit, cujuscumque gradus dantur.
    ///
    /// Nota II: Quod tunc in quibus elementa sunt extraxerunt neglecta sit, incertum est.
    /// `StepBy` se gerat quasi nexu `next(), nth(step-1), nth(step-1),…`, sed etiam est in serie sicut liber conversari
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Adhiberi possunt immutare aliquot iterators Quod ita sit et perficiendi de causis.
    /// Secundum iterator de mane proficiscemini in via et deleam pluribus elementis.
    ///
    /// `advance_n_and_return_first` et sit equivalent;
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Et si panic data est `0` modum gradus.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Accipit novam duorum iterators et gignit et successive super iterator.
    ///
    /// `chain()` quod non reverteretur a prima repetere super values iterator iterator de primo et in secundo de values iterator.
    ///
    /// Id est duo iterators in unum conjungit illa, in catena.🔗
    ///
    /// [`once`] aptet unum communiter usus est in valore catena alias species ex iteration.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Cum `chain()` utitur [`IntoIterator`] argumentum potest fieri quod convertitur in [`Iterator`] non est iustus [`Iterator`].
    /// Exempli gratia (`&[T]`) crustae effectum deducendi [`IntoIterator`] et ita potest transierunt directe ad `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Si opus Windows API vos converti velitis [`OsStr`] `Vec<u16>` est;
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// , Usque zips 'paria duo iterators in una iterator.
    ///
    /// `zip()` redit in duas alias iterators novum iterator quod iterate, quo primum elementum tuple autem reversus est de iterator prima et secunda secundam, a elementum est iterator.
    ///
    ///
    /// Praeterea, illud zips iterators duo simul, unum in unum.
    ///
    /// Alterutra iterator [`None`] redit, iterator [`next`] ex zipped [`None`] revertar.
    /// Primumque iterator [`None`] redit, in brevi spatio `zip` `next` altero dici non iterator.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Utitur enim `zip()` [`IntoIterator`] argumentum potest fieri quae posse conuerti in [`Iterator`] non [`Iterator`] iustus est.
    /// Exempli gratia efficiendum crustae (`&[T]`) [`IntoIterator`], et `zip()` directe ad cognoscendum transmitterent,
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` saepe enim ad quod avi iterator infinito ad finitum.
    /// Hic mos eventually revertetur operatur, quia finita est iterator [`None`], ending zipper.Zipping cum `(0..)` intueri dudley simillimus [`enumerate`] potest;
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Quae nova gignit iterator ponit exemplum de items `separator` adjacent inter originale iterator.
    ///
    /// Si non `separator` [`Clone`] effectum deducendi et computatis necessitates in omni tempore uti [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Primum Ex `a`.
    /// assert_eq!(a.next(), Some(&100)); // Et separator.
    /// assert_eq!(a.next(), Some(&1));   // Postero `a` elementum a.
    /// assert_eq!(a.next(), Some(&100)); // Et separator.
    /// assert_eq!(a.next(), Some(&2));   // Ab ultima `a` elementum.
    /// assert_eq!(a.next(), None);       // Consummatum est et iterator.
    /// ```
    ///
    /// `intersperse` admodum utile potest esse communis usus items iungere elementum est scriptor iterator:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Nova gignit iterator quæ adjacent inter `separator` items per locat an item generatae ex originali iterator.
    ///
    /// Clausurae statim dicetur quinam interponitur singulis item item binos iterator interiore;
    /// Specialius clausurae iterator quin cedat quam si subiecta et duo extrema item obiit.
    ///
    ///
    /// Item si de iterator [`Clone`] telis conficitur, ut illud facillimus utor [`intersperse`].
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Primum elementum a `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Et separator.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Postero ex `v` elementum.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Et separator.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Ultima ex `v` a elementum.
    /// assert_eq!(it.next(), None);               // Consummatum est et iterator.
    /// ```
    ///
    /// `intersperse_with` possunt esse in locis separator computandos, non sit necesse est:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Agricola sui mu-tabiliter inest in context horum mutuo postulaverit, ut et generate item.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Takes a Agricola Agricola, quae vocat et quem gignit in se elementum est iterator.
    ///
    /// `map()` alter alterius traducit iterator per se ratio
    /// [`FnMut`] effectum adducit eo aliquid.Agricola vocat id quod in se est iterator novam elementum ad originale iterator.
    ///
    /// Si bene cogitandi rationes cogitare potes `map()` huiuscemodi
    /// Quae dat iterator si quid aliquem `A` elementis et alia quaedam vis iterator `B` possis `map()` transit clausuram illam accipit et remittit `A` `B`.
    ///
    ///
    /// `map()` ratione similis loop [`for`].Sed `map()` est piger et, ut solebant maxime cum erant 'opus cum aliis jam iterators.
    /// Nam si facitis looping aliquam partem effectus suus habeatur uti turpia [`for`] `map()` quam.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Si aliqua pars agis effectum est `map()` [`for`] malunt;
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // non facere,
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ne feceritis ea, ut mollis.Rust mos moneo tibi hanc.
    ///
    /// // Potius, uti est:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Vocat Agricola an in ea ex iterator.
    ///
    /// Equivalent ad haec usus [`for`] in loop iterator, et `continue` `break` tamen non fieri potest ex Agricola.
    /// Suus 'plerumque ad hoc turpia per loop `for` sed `for_each` sit legibilior items dispensando cum in fine iam catenis iterator.
    ///
    /// `for_each` Interdum et potest non citius quam loop propter mos utor iteration internus qualis in adapters `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Et tam parvum exemplum est lautus `for` tabernaculum fiat, sed ut sit potior `for_each` servare style cum iam non eget iterators:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Quæ gignit iterator ad determinare si hoc ipsum deberet utitur Agricola obiit.
    ///
    /// Agricola `true` vel redire debent ad placitum de elementum `false`.Et rediit iterator meus cedere tantum elementa quibus Agricola refert ad verum.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Quia `filter()` Agricola accipit a referat ad Transierunt et iterate iterators in multis agitur, et quod ideo ad statum modo falleret, cum Agricola, ubi genus est duplex referat;
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // s * duobus opus!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Is est pro communi usu est detrahentes destructuring ratio de una:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // et ambo *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// sive utrumque:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // duo &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// horum stratorum.
    ///
    /// `iter.filter(f).next()` quod videtur idem esse `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Et gignit et iterator quae Filtra et maps.
    ///
    /// Sed reduces reddit iterator suppetent: quibus clausuram value`s `Some(value)` redit.
    ///
    /// `filter_map` uti potest facere plura vincula [`filter`] [`map`] atque breuis explicatio.
    /// Exemplum infra `map().filter().map()` ostendit quomodo esse illi uni `filter_map` vocant.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ecce eundem, exempli gratia, sed [`filter`] et [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Gignit et iterator qui dat hodiernam iteration tum comitem altera valorem.
    ///
    /// Et iterator cedit rediit `(i, val)` pairs ubi est `i` current valorem index est de iteration `val`, et rediit ad iterator.
    ///
    ///
    /// `enumerate()` ut [`usize`] comitem suum custodit.
    /// Si vis alia per numerare mediocri integro: illic enim similis functionality [`zip`] munus praebet.
    ///
    /// # redundantiam MORES
    ///
    /// Nihil superfluit modum cavendi ita facit iniuriam vel enumerando plura elementa [`usize::MAX`] panics effectum.
    /// Si autem diceret enabled debug a panic praestatur.
    ///
    /// # Panics
    ///
    /// Ut iterator panic si non rediit hac, revertens in [`usize`] exuberans p.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Quae potest esse iterator creates [`peek`] ad perussi quia absque vultus in deinde elementum ex iterator.
    ///
    /// Et ad modum [`peek`] adiungit iterator.Et videre documentis pro magis notitia.
    ///
    /// Nota adhuc ætate est iterator underlying [`peek`] cum dicitur primum: Ut recuperare elementum altera, [`next`] iterator dicitur in underlying, ergo nulla parte effectus (ie
    ///
    /// intimo nihil aliud quam proximo valorem) et ex [`next`] modum fieri.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() lets videre nos in future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // multiplex peek() possimus tempora iterator non proficient
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // post finita iterator ita peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Et iterator ut creates [`skip`] s in vi praedicati secundum elementa.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` ut clausuram tollit rationem.Et super hanc Agricola hoc elementum ex se iterator, et donec oriturus redeat `false` ignorare elementa.
    ///
    /// `false` est postquam redierat, in `skip_while()`'s officium esse, et reliquum sunt elementa cesserunt.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Quia Transierunt Agricola accipit a referat ad `skip_while()` et iterate iterators super multis agitur, et quod ideo nusquam ad turbatio situ, Agricola, ubi ratio ad genus duplex est, referat;
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // s * duobus opus!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Restitit post initium `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // dum hoc fuisset falsa, quia iam obtinuit est falsus, uti non sit ultra skip_while()
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Secundum elementa creates esse de quocumque praedicatur aliquid quod cedit iterator.
    ///
    /// `take_while()` Agricola rationem ut takes a.Claustrum illud vocant singulis iterator elementum et fructum elementum `true` dum redit.
    ///
    /// Post `false` viderit reversam officium `take_while()`'s est super, et ex reliquis elementis neglecta sunt.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Quia abiit `take_while()` Agricola accipit a referat, supra repetere ac multis iterators agitur, fortasse vestrum in hoc situ falleret: ubi genus est duplex ad clausuram referat;
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // s * duobus opus!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Restitit post initium `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Plus minusve quam habemus, quae nulla elementa, sed falsus est quia jam surrexit, non est usus take_while() ultra
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Quia `take_while()` respice ad valorem indiget ut videatur vel non includi si quid, perussi mos animadverto quod est remotum iterators:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` non amplius in eo defecerat, ut videret si iteratione quiescere sed ne rursus in iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Gignit et iterator quod utrumque praedicatum et de quo iaceat elementa secundum maps.
    ///
    /// `map_while()` tollit enim quod Agricola rationem.
    /// Et hanc clausuram iterator singulis elementum et fructum elementum [`Some(_)`][`Some`] dum redeat.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hic idem est exemplum, sed [`take_while`] et [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Restitit post initium [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Plus possint quam fit in elementis habemus u32 (IV, V), sed `map_while` `None` rediit ad `-3` (ut rediit `predicate` `None`) et stat ad primum `collect` `None` offendit.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Quia indiget inspicere ad valorem in ordine ad `map_while()` si non esset, vel includi, perussi iterators videbis quod sit remotum;
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` est amplius, quia ut videret si esset consumpta iteratione quiescere sed ne rursus in iterator.
    ///
    /// Nota hic [`take_while`] quod dissimilis non ** ** naturis conflata est iterator.
    /// Iterator etiam non est certa quod hoc est [`None`] redit post primam rediit.
    /// Si eget iterator fusile robur, uti [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Gignit id quod iterator extrema plebe quaerit primo `n` elementa.
    ///
    /// Postquam consumpti reliqua elementa cesserunt.
    /// Quam ab earundem recta hac, pro delendi antiquitus modum `nth`.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Iterator est adaequatus elementa `n` prius gignit.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` quotiens usus est, cum iterator infinito ad finitum eam:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Quam si minus `n` praesto sint elementa, et `take` solummodo magnitudinem iterator underlying:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// An semper nibh ut iterator [`fold`] quod similes status, et internum tenet novam iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` accipit duas rationes: valore initiali statu internum, qui cum seminibus, et cum Agricola duas rationes: quarum prima erat quod secundum statum quod internus et rerum invisibilium visibiliumque ad elementum iterator.
    ///
    /// Et Agricola inter statum assignare possit ad participes ad statum internum iterations.
    ///
    /// De iteration, elementum in se est Agricola et applicari ad valorem reditum ab Agricola iterator, et [`Option`], est antememoratus episcopatus Halberstadiensis et iterator.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // iteration inter se, ut tibi a re publica multiplicamini elementum
    ///     *state = *state * x;
    ///
    ///     // tunc dabimus cedere negationem publicae
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Tanquam in tabula iterator operanti creet sed flattens nested consequat.
    ///
    /// Et semper nibh ut [`map`] usui est, nisi cum sola ratio fert values Agricola.
    /// Si producit pro iterator: illic 'an susicivus layer ex indirection.
    /// `flat_map()` extra tabulatum super te remove hanc sui.
    ///
    /// `flat_map(f)` potest cogitare de te ut semantic equivalent of [`map`] ping, et [`flatten`] tur ut in `map(f).flatten()`.
    ///
    /// Alius cogitas viam `flat_map()`: [map` ']' s Agricola pro sulum item elementum una redit et Agricola `flat_map()`'s redit ad se per elementum iterator.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() quod refert iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Gignit id est iterator flattens nested compages.
    ///
    /// Cum autem sit utile iterator iterators seu iterator quae potest in uno gradu indirection iterators vis tollere.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Et aequandi Mapping,
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() quod refert iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Unfold termini [`flat_map()`] Hoc potes, quod causa sit potior hoc scilicet quod importet plus mente;
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() quod refert iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Unam duntaxat gradu tempore aerarii adulatione;
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Hic videamus `flatten()` non perform a "deep" Platten.
    /// Sed solum gradum commorantes tollitur.Hoc est tres dimensiva `flatten()` si ordinata in duo-dimensiva effectus non erit unius dimensionis.
    /// Ad structuram proposita una dumtaxat tu mihi `flatten()` iterum.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Primi generantis iterator [`None`] finitur secundum.
    ///
    /// Postea iterator quod refert [`None`], future vocat potest non cedere aut [`Some(T)`] iterum.
    /// `fuse()` iterator et ceremonias, ensuring [`None`] illud post datum est, quod semper revertetur [`None`] usque in sempiternum.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // inter iterator quae sit nona alternat
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // Si eam etiam Some(i32) alias omnes
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // nos videmus iterator eundo et redeundo
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // tamen aliquando illud ... annectetur sumus
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // semper `None` post primum sic revertetur.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// An quod in se est et iterator elementum, super transeuntes per valorem.
    ///
    /// Cum usura iterators, youll saepe concatenata ex illis pluribus unum.
    /// Opere talibus Codicis speres Lorem variis partibus Pipeline quid agatur.Facere, quod addita est vocatio `inspect()`.
    ///
    /// It's more common for `inspect()` to be used as a debugging tool than to exist in your final code, but applications may find it useful in certain situations when errors need to be logged before being discarded.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // id est ordinem universa iterator.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // et in aliquam add to investigate inspect() vocat futurum erat quid
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Hic erit imprimere:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Logging errores amissis eos;
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Hic erit imprimere:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Horum mutuo postularit et iterator: quam est perussi.
    ///
    /// Hoc est utile ad applicationem iterator adaptors liceat salva dominium originale iterator.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // conantur uti iter iterum si fuerit opus.
    /// // Dat linea «errore movetur uti valeat: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // et iterum experiri
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // pro nobis addere in .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // nunc autem hic finis est;
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Et in iterator transforms collectio.
    ///
    /// `collect()` accipere quicquam potest iterable ac vertere in collectione pertinet.
    /// Hoc unum ad vexillum magis potens modi bibliothecam, in variis contextibus.
    ///
    /// Maxime regulam `collect()` adhibetur in quo est collectio se vertere in alterius.
    /// Accipias pecuniam [`iter`] vocaret eam fasciculum mutationes faciant et `collect()` fine.
    ///
    /// `collect()` Item, quod non potest creare exempla types typical collections.
    /// Nam quae sub formari possunt ex [`String`] [`char`] s, et iterator [`Result<T, E>`][`Result`] de items in `Result<Collection<T>, E>` colligi potest.
    ///
    /// Et videre exempla plura infra ad.
    ///
    /// Tam generalis quod `collect()`, ut non causa problems in genus inlatione causetur.
    /// Talis est `collect()` affectuose ut aliquoties syntaxi 'turbofish' videbis: `::<>`.
    /// Adjuvat intelligis illam consequentiam Hoc algorithm specie colligunt in quibus collection ut vos erant 'trying.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `: Vec<i32>` Nota, quod est opus in sinistra-manus manus pars.Est quia agris contracto in, exempli gratia, in loco [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Using the 'turbofish' pro annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Quia non curat de `collect()` colligendis in voluisti, te potest etiam uti genus admonitus a propria dioecesi excardinatur, `_` cum turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` [`String`] facere usus,
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Et si habes album de ['Result<T, E>`][Result``] s, uti `collect()` potes videre, si quis ex eis defuit:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // nobis primo errorem
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // dat nobis album ex Answers
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Et comedit iterator duo creabantur collectis illi.
    ///
    /// Transierunt `partition()` ex parte praedicati, ut non reverteretur `true` aut `false`.
    /// `partition()` reditus par omnibus quæ reddidit `true` elementatorum et elementorum reversa `false` quam.
    ///
    ///
    /// Vide etiam [`is_partitioned()`] et [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// * * Loci, in edicat aut ab elementis hujus secundum nomine significetur iterator: ita ut omnia illa quae praecedunt omnes illi qui `true` reditus reditus `false`.
    ///
    /// Redit numerum `true` elementis invenitur.
    ///
    /// Item ordine partita non relativus conservetur.
    ///
    /// Vide etiam atque [`is_partitioned()`] [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // In odds et maceriæ solvens-place inter aequalia inaequalibus,
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: solliciti sumus, circa flumen ut comitem?Solum ita ut ultra
        // `usize::MAX` mutabilis references cum ZSTs, et maceria ... non utile

        // Haec munera Agricola "factory" ne genericity est in `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Saepe invenies `false` primis et in ultimis `true` non PERMUTO.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Suspendisse et si iterator elementis secundum partita est praedicatum, tales omnes reversionem `true` reversionem `false` praecederet.
    ///
    ///
    /// Et [`partition()`] Vide etiam [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Item Aut experiri `true` vel primam esse non desinit `false` `true` reprehendo et item postea.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Modum iterator An, quod ad hoc sit munus in diu feliciter refert, producendo unum, ultima valorem.
    ///
    /// `try_fold()` tollis duas rationes: an valorem, and Agricola cum in duas rationes: an 'accumulator' et est elementum.
    /// Feliciter rediit aut clausum cum esset postero valoris Accumulator iteratione aut redit peccatum ad propagatur per errorem valoris statim (short-circuiting) RECENS.
    ///
    ///
    /// Valorem Accumulator erit in die prima vocatio est pretii.Clausurae iterator applicatione post omne elementum nisi, `try_fold()` Accumulator redit ad ultimum effectum.
    ///
    /// Folding utile est ubicumque aliquid habetis de collectione et vis ad producendum unum valorem ab eo.
    ///
    /// # Nota ut Implementors
    ///
    /// Alii modi (forward) complures in default est apud implementations huius termini unius, ut id ad effectum deducendi expressis verbis si experiri non potest aliquid facere melius quam default `for` loop implementation.
    ///
    /// Praesertim `try_fold()` interioribus partibus studeant habere vocationem iterator quibus componitur.
    /// Si plures sunt necesse vocat, et operator `?` potest esse ternarium duplus est convenient una cum Accumulator pretii, sed cave ne quis invariants opus staturam est ante eos diluculo redit.
    /// Haec methodus `&mut self` sic oportet iteratione resumable ferendi ad VI.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // sedatus et omnium elementorum ordine summam
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Haec summa fortuna redundat Cum C ad elementum addendo
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Quoniam brevis sit, circuited, reliqua elementa, per quae adhuc praesto iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iterator se habet ad modum in se quisque fallitur in eo quod est munus iterator, et reversus est cum stetissent iuxta primus error errorem.
    ///
    ///
    /// Et hoc cogitandum sit sicut etiam non potest errare vel sicut forma [`for_each()`] stateless versionem [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Si denique circuited sic adhuc in iterator reliqua;
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// In quod omne elementum ligula Accumulator per appli operationem, reversus est finalis effectus.
    ///
    /// `fold()` tollis duas rationes: an valorem, and Agricola cum in duas rationes: an 'accumulator' et est elementum.
    /// Agricola refert in De valore Accumulator quid haberet quod pro tunc iteration.
    ///
    /// De valore ad valorem sit in Accumulator erit prima vocatio.
    ///
    /// Postea Agricola applicatur ad omne elementum est iterator; `fold()` refert ad Accumulator.
    ///
    /// Haec operatio dicitur esse aliquando aut 'reduce' 'inject'.
    ///
    /// Folding utile est ubicumque aliquid habetis de collectione et vis ad producendum unum valorem ab eo.
    ///
    /// Note: `fold()` et alia quæ totius iterator conficitur, non desinunt infinita iterators etiam certa traits unde fit in tempore finito.
    ///
    /// Note: [`reduce()`] potest esse primum elementum quod est ad valorem si Accumulator item generis et genus idem.
    ///
    /// # Nota ut Implementors
    ///
    /// Alii modi (forward) complures in default est apud implementations huius termini unius, ut id ad effectum deducendi expressis verbis si experiri non potest aliquid facere melius quam default `for` loop implementation.
    ///
    ///
    /// Maxime studeant habere vocationem qua iterator `fold()` interna partibus componitur.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // in summa omnes ex elementis ordinata
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Lets per se gradus et deambulatio iteration hic:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Itaque eventus ultima nostri, `6`.
    ///
    /// Est enim in commune iterators qui non multum solebant ut `for` per loop cum a album de rebus facere usque ad exitum.In `fold()`s possint;
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // pro loop;
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ut sis similiter
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reduces elementa in se est unum per operatio, reducendo saepe applicanda servandi.
    ///
    /// Si vacat iterator redit [`None`];secus reddit propter redundet.
    ///
    /// Nam cum quolibet iterators elementum, et hoc idem est quod [`fold()`] primum elementum quod est ad valorem iterator: stringensque collum ejus, in omni subsequent elementum.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Maximum valorem invenire:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Si autem quod omne elementum probat iterator aequet praedicatum.
    ///
    /// `all()` Agricola enim accipit et qui refert `true` `false`.Id se hanc segregationem iterator elementum et reversus `true` si ergo ita `all()`.
    /// Si `false` rursum redit `false`.
    ///
    /// `all()` brevis-circuiting: in verba eius et invenit in ea simul dispensando prohibere `false`, utcumque data ut quid fit alibi, effectus quoque erit `false`.
    ///
    ///
    /// An inanis iterator refert `true`.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Cum stetissent iuxta `false` primum,
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // `iter` uti possumus etiam quod inde sint elementa.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Si quis probat elementum aequet de quocumque praedicatur aliquid de iterator.
    ///
    /// `any()` Agricola `true` vel takes a `false`, ut refert.Elementum de se est haec vox ista promittat Agricola iterator ac si quis ex eis `true` revertere ergo et non `any()`.
    /// Fuerint reversus `false` redit `false`.
    ///
    /// `any()` brevis-circuiting: in verbis est, ubi primum prohibere et invenit in dispensando `true`, utcumque data ut enim aliud fit, effectus quoque erit `true`.
    ///
    ///
    /// An vana refert `false` iterator.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Restitit ante prima `true`;
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // `iter` uti possumus etiam quod inde sint elementa.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Nam Searches aliquid implet id quod est predicatum iterator.
    ///
    /// `find()` Agricola enim refert `true` vel takes a `false`.
    /// Hoc convenit cuilibet clausurae iterator elementum ac si `true` Redeant ergo `find()` [`Some(element)`] redit.
    /// Si reversus `false` redit [`None`].
    ///
    /// `find()` brevis-circuiting: id est simul dispensando stabit in `true` Agricola refert.
    ///
    /// Quia accipit a `find()` referat, repetere supra multa iterators agitur, fortasse vestrum in confusione huius rei ratio est duplex, ubi referat.
    ///
    /// Vos can exempla infra videbimus in hunc modum cum `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Restitit ante prima `true`;
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // `iter` uti possumus etiam quod inde sint elementa.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Quod tantumdem valeret si `iter.find(f)` `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Etiam munus ad elementis iterator refert ac primis nulli non-exitum.
    ///
    ///
    /// `iter.find_map(f)` tantumdem valeret si `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Et refert munus etiam in elementis iterator primum verum et primum effectus errore.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Quaero enim elementum iterator: Index reversus suo.
    ///
    /// `position()` Agricola enim refert `true` vel takes a `false`.
    /// Hoc autem pertinet singulari segregationem iterator si unus `true` Redit igitur `position()` [`Some(index)`] redit.
    /// Si `false` rursum redit [`None`].
    ///
    /// `position()` brevis-circuiting;in aliis sermonibus, et non invenit eam prohibere simul dispensando a `true`.
    ///
    /// # redundantiam MORES
    ///
    /// Nullum modum cavendi non superfluit, et si quae sint elementa quam matching [`usize::MAX`] non-, vel quod producit malum exitum, vel panics.
    ///
    /// Si autem diceret enabled debug a panic praestatur.
    ///
    /// # Panics
    ///
    /// Hoc munus habet quam ut panic iterator `usize::MAX` si elementa non-matching.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Restitit ante prima `true`;
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // `iter` uti possumus etiam quod inde sint elementa.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Et positum in Index iterator statum rediit
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Per iterator Quaero enim est elementum a dextris, et reversus indice.
    ///
    /// `rposition()` Agricola enim refert `true` vel takes a `false`.
    /// Hoc convenit cuilibet elementum clausurae iterator incipiens a fine aliquis redit `true` igitur `rposition()` [`Some(index)`] redit.
    ///
    /// Si `false` rursum redit [`None`].
    ///
    /// `rposition()` brevis-circuiting;in aliis sermonibus, et non invenit eam prohibere simul dispensando a `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Restitit ante prima `true`;
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // `iter` uti possumus etiam quod inde sint elementa.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Redundantiam opus non est reprehendo hic, quia `ExactSizeIterator` non esset numerus in elementis; utiq; `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Refert ad elementum maximum esse in iterator.
    ///
    /// Si pariter quaeque maximam ultima pars redditur.
    /// Si iterator vacuum [`None`] redditur.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Quod est minimum quiddam refert iterator.
    ///
    /// Si sint multa elementa minimum aequo, primum elementum quod reddidit.
    /// Si iterator vacuum [`None`] redditur.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Redit, quod est elementum maximum valorem ad dederit ex certa munus.
    ///
    ///
    /// Si pariter quaeque maximam ultima pars redditur.
    /// Si iterator vacuum [`None`] redditur.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Redit, quod elementum dat maximam pretii collatio cum respectu ad praefinitum munus.
    ///
    ///
    /// Si pariter quaeque maximam ultima pars redditur.
    /// Si iterator vacuum [`None`] redditur.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Redit elementum quam quod minimum valorem dat munus a certa.
    ///
    ///
    /// Si sint multa elementa minimum aequo, primum elementum quod reddidit.
    /// Si iterator vacuum [`None`] redditur.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Redit elementum enim dat quod minimum valorem cum respectu ad certum munus collatio.
    ///
    ///
    /// Si sint multa elementa minimum aequo, primum elementum quod reddidit.
    /// Si iterator vacuum [`None`] redditur.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Iussus est cladibus iterator.
    ///
    /// Plerumque de sinistro iterators repetere.
    /// Post utendi `rev()`, et iterate pro iterator erit a sinistra ad dextram.
    ///
    /// Iterator est solum possibile si habet finem, ut `rev()` operatur nisi ex [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Converts est iterator pairs de par, in continentia.
    ///
    /// `unzip()` totam consumit iterator paria producens collectis duobus alterum a sinistris duo elementa et quae a parte dextra.
    ///
    ///
    /// Hoc munus sit in sensu et in contrarium [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Iterator exemplans et gignit omnia elementa suum.
    ///
    /// Haec enim utilis tibi habere iterator `&T` supra, sed opus esse in `T` iterator.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // idem transtulerunt .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Iterator creates esse quod [`clone`] s sua omnia elementa.
    ///
    /// Haec enim utilis tibi habere iterator `&T` supra, sed opus esse in `T` iterator.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // idem Cloned .map(|&x| x) enim integros
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// S. O iterator et omne sæculum.
    ///
    /// Potius, exeundi [`None`] in loco iterator: et rursus ab initio.Post iterando iterum incipiet a principio autem iterum.Et iterum.
    /// Et iterum.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Et in resumuntur elementis iterator.
    ///
    /// Singulari accipit præditas pariter et fructum reddit.
    ///
    /// An nullus ex refert valore ad genus inanis iterator.
    ///
    /// # Panics
    ///
    /// Cum vocant `sum()` integrum et primi generis est redierat, hoc redundat in computum ingreditur, et, si modum in lusione cum panic dicta sunt enabled.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Univer iterator iterates multiplicent elementa
    ///
    /// An inanis iterator aliquis refert ad valorem in genus.
    ///
    /// # Panics
    ///
    /// Et integer primi generis est dum vocantem `product()` rediit, si modum in panic computation et inebrians lusione cum assertiones enabled.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) [`Iterator`] elementis cum alio comparat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) comparat elementis [`Iterator`] certo respectu alterius comparatione ad actum.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) [`Iterator`] elementis cum alio comparat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) comparat elementis [`Iterator`] certo respectu alterius comparatione ad actum.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Si talis [`Iterator`] elementis aequale alterius.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// [`Iterator`] determinat si elementa aequalia certo respectu alterius muneris aequalitatem.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Si talis elementa aliorum [`Iterator`] impar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Si enim talis [`Iterator`] [lexicographically](Ord#lexicographical-comparison) minor alia elementa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Si autem talis [`Iterator`] elementis [lexicographically](Ord#lexicographical-comparison) minor vel aequalis alterius.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Si autem talis [`Iterator`] [lexicographically](Ord#lexicographical-comparison) maiora alia elementa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// [`Iterator`] sint elementa constituit [lexicographically](Ord#lexicographical-comparison) si maior aut aequalis alterius.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Si checks elementis hujus iterator dicuntur, digestus.
    ///
    /// Id est: nam quisque `a` atque hoc elementum elementum `b`, `a <= b` habere debet.Si nulla prorsus iterator cedit, vel unum elementum: est `true` rediit.
    ///
    /// Nota, quod solum si `Self::Item` `PartialOrd`, sed non `Ord`, pertinet definitio superius ad hoc munus `false` refert si quis biennium continuum iudex items huic non valent comparari.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Checks elementa huius si coetibus territorialibus iterator quae comparatur per datis munus.
    ///
    /// Instead usus `PartialOrd::partial_cmp`, utitur hoc munus datis determinare munus `compare` praeceptiva ordinationis duobus elementis.
    /// Praeter hoc est [`is_sorted`] equivalent to;magis notitia documenta eius vident enim.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Si checks iterator elementis huius commoda quae data est clavis usus est extraction munus.
    ///
    /// Iterator in loco comparet elementa directe, hoc munus et conferre claves ex elementis, ut determinari ab `f`.
    /// Praeter hoc est [`is_sorted`] equivalent to;magis notitia documenta eius vident enim.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// See [TrustedRandomAccess]
    // Ratio est in proposito vitandi insolitam nominis videre #76479 collisiones.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}