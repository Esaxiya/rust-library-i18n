use crate::ops::{ControlFlow, Try};

/// An iterator possunt elementa tradite utrumque.
///
/// Arma `DoubleEndedIterator` aliquid, quod est extra facultatem unam aliquid in utensilia [`Iterator`], qui et facultatem: et tolle inde a tergo Item`s, tum fronte.
///
///
/// Et reversus est notandum quod nituerunt opus, nec crucem mediis occursum est iteratio.
///
/// In simili est protocol [`Iterator`], semel in `DoubleEndedIterator` ex refert [`None`] [`next_back()`] vocantem illud sit, sive non sit semper [`Some`] rursus redire.
/// [`next()`] atque hoc [`next_back()`] convertuntur.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Aliam tollit ac redit per elementum a fine iterator.
    ///
    /// Cum refert `None` ultra non sunt elementa.
    ///
    /// Et importat soUicitudo quae ultra details [trait-level].
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Elementa differunt, ut fructum in nobis per DoubleEndedIterator`modi s liis tribuit ones [`Iterator`] 's modi:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// A tergo `n` proficiscitur iterator elementum.
    ///
    /// `advance_back_by` versio [`advance_by`] est e converso.Hoc modum sollicita `n` skip vocant ab elementis incipiens a tergo [`next_back`] `n` tempore usque ad [`None`] est offendit.
    ///
    /// `advance_back_by(n)` iterator feliciter revertatur [`Ok(())`] si nititur `n` elementum vel [`Err(k)`] [`None`] si occurritur `k` ubi ante crescit numerus elementis iterator excurrant elementa (id
    /// longitudo iterator).
    /// Nota quod `k` semper minus quam `n`.
    ///
    /// Non enim absumit vocant `advance_back_by(0)` omnibus elementis [`Ok(())`] imbibit et semper.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // omittendum est modo `&3`
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Redit n`th elementum ly 'a fine iterator.
    ///
    /// Haec versio [`Iterator::nth()`] contrario versu ad se.
    /// Iudex cum operationes veluti comes incipit adipiscing ut primum redeunt `nth_back(0)` valorem finis `nth_back(1)` secundo sic.
    ///
    ///
    /// Nota, quod inter elementa finem omnium, et novissimum tuum devorabitur elementum rediit, inter quas elementum rediit.
    /// Hoc subsidium vocatis iterator `nth_back(0)` pluribus eodem tempore diversis revertar.
    ///
    /// `nth_back()` si redeat [`None`] `n` longitudinem paribus major iterator.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Vocant `nth_back()` multiple temporibus iterator quod non rewind:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Si minus, quam `n + 1` `None` reversus sunt elementa,
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Haec est versio [`Iterator::try_fold()`] e converso: quia accipit elementa incipiens a posteriore iterator.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Quoniam brevis sit, circuited, reliqua elementa, per quae adhuc praesto iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iterator in modum elementa et redigit in unum scriptor iterator, ultima valorem, incipiens a tergo.
    ///
    /// Versionem [`Iterator::fold()`] quod prorsus contrarium, ut elementa accipit incipiens a posteriore iterator.
    ///
    /// `rfold()` tollis duas rationes: an valorem, and Agricola cum in duas rationes: an 'accumulator' et est elementum.
    /// Agricola refert in De valore Accumulator quid haberet quod pro tunc iteration.
    ///
    /// De valore ad valorem sit in Accumulator erit prima vocatio.
    ///
    /// Postea Agricola vestigetur hoc elementum ex omnibus iterator; `rfold()` refert ad Accumulator.
    ///
    /// Haec operatio dicitur esse aliquando aut 'reduce' 'inject'.
    ///
    /// Folding utile est ubicumque aliquid habetis de collectione et vis ad producendum unum valorem ab eo.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // summa enim omnia ex elementis
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Exempli gratia haec builds a linea, initial incipiens cum se pretii et pergens ad elementum ante, a tergo:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Quaero, quia aliqua est esse contenta, quae retro de quocumque praedicatur aliquid de iterator.
    ///
    /// `rfind()` Agricola enim refert `true` vel takes a `false`.
    /// Utrumque enim hanc segregationem iterator elementum incipiens ad finem `true` si Redeant ergo `rfind()` [`Some(element)`] redit.
    /// Si reversus `false` redit [`None`].
    ///
    /// `rfind()` brevis-circuiting: id est simul dispensando stabit in `true` Agricola refert.
    ///
    /// Ad quod referat `rfind()` accipit, supra repetere ac iterators multis agitur, et ideo eveniet eis turbatio situ ubi fortasse ratio est duplex referat.
    ///
    /// Vos can exempla infra videbimus in hunc modum cum `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Restitit ante prima `true`;
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // `iter` uti possumus etiam quod inde sint elementa.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}