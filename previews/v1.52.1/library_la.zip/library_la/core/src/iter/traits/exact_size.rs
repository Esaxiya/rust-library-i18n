/// An quia iterator scit exacte longitudo ejus.
///
/// Multae [Iterator` `] s nesciunt iterate multis partibus ipsi autem et alii faciunt.
/// Si scit iterator saepe repetere possit, nec obvius informationes prodesse possunt.
/// Exempli gratia si iterate vis retro a bonus satus is scire ubi est finis.
///
/// Cum in effectum ducenda `ExactSizeIterator`, non oportet effectum deducendi [`Iterator`].
/// Cum Sic elit iterator magnitudinem exigere redire [`Iterator::size_hint`] * canenda.
///
/// Et habet modum default [`len`] implementation, sic ut plerumque non esse effectum deducendi.
/// Sed implementation performant ut possis plus est quam default providere, ut in hoc casu eam facit sensum earundem.
///
///
/// trait Nota quod haec non est tutum trait et quod sic non * **et* non est est sponsio enim recte longitudinem rediit.
/// Non est hoc modo ** ** confidunt in eo codice `unsafe` recte atque ordine imperatorem [`Iterator::size_hint`].
/// Periculum quoque et instabiles [`TrustedLen`](super::marker::TrustedLen) trait dat fiduciam.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// // scit quod sæpe repetere rhoncus finitae
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// In [module-level docs], ut implemented in [`Iterator`], `Counter`.
/// Quia tum s fiat `ExactSizeIterator` effectum deducendi;
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Manente numero computare facile iterations.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Et nunc non possumus potest?
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Exigere redire iterator longitudine.
    ///
    /// Exsequendam invigilat, ut reddam iterator `len()` prorsus plures temporibus ad valorem [`Some(T)`] antequam reversus [`None`].
    ///
    /// Hoc habet modum implementation default ut vos should plerumque non ita directe effectum deducendi.
    /// Tamen si potestis agentibus praebere ultra ad implementation, potes facere.
    /// Ecce enim in [trait-level] Docs per exemplum.
    ///
    /// Hoc munus habet eandem salutem polliceri [`Iterator::size_hint`] sicut munus.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // scit quod sæpe repetere rhoncus finitae
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Praeoccupatum assertio defensivum et immutabilis sistit
        // trait interposita fide.
        // Si trait rust, et internum, uti nos posse debug_assert !;assert_eq!Omnes quoque implementations User Rust reprehendo.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Si iterator `true` reversus inanis.
    ///
    /// Per hanc modum habet implementation [`ExactSizeIterator::len()`] default, et non sit tibi necessaria ad effectum deducendi.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}