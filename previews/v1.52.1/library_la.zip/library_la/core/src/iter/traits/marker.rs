/// Quia semper in iterator continues cedere `None` defectionem iracundiae.
///
/// Vocant in altera lentis iterator `None` statim rediit quae praestatur [`None`] rursus redire.
/// Hoc trait ut non sit implemented per omnia iterators sic conversari concedit optimizing eam propter [`Iterator::fuse()`].
///
///
/// Note: In generali tu uti neque in genere fines `FusedIterator` si opus sit quoddam iterator.
/// Sed qui in iterator [`Iterator::fuse()`] vocare iustos.
/// Si iterator enim iam facta, additional super-op [`Fuse`] fascia nulla erit ultra in perficientur damus.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// An refert in illam accurate longitudo per size_hint iterator.
///
/// Aut in qua admonitus magnitudine iterator tradit prorsus (superior inferior aequalis) vel superius [`None`] ligatur.
///
/// Et vinctum superius quia non solum esse ipsam [`None`] si longitudo est maior quam [`usize::MAX`] iterator.
/// In hoc casu necesse erit inferioribus [`usize::MAX`] tenetur, et inde in [`Iterator::size_hint()`] `(usize::MAX, None)`.
///
/// Et prorsus iterator necesse est numerus relatus est elementis aut PRAEVARICOR quam ad extremum.
///
/// # Safety
///
/// Cum trait hoc tantummodo legem impleri sustentatur.
/// Consumers huius trait [`Iterator::size_hint()`]’s superius est inspicere tenetur.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// An quia iterator Cum pomiferum faciens et te et capta item elementum una quidem ex ejus underlying [`SourceIter`].
///
/// Ad modum aliquem vocant tribuantur, iterator, eg
/// [`next()`] et [`try_fold()`], qui polliceri se in gradum ad minimum unus de valore iterator underlying est fons motus est et ex iterator effectus in suo loco inserta catena possit, velut ex fonte vitae angustiis: sistens descriptiones patitur tali insertione.
///
/// Haec indicat trait In aliis verbis possit esse iterator pipeline id colligi necesse est.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}