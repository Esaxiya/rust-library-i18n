use crate::iter::{FusedIterator, TrustedLen};

/// Creates iterator novum, quod unum sine altero sermone repetit elementum.
///
/// Et iterum suscipit principale quoddam `repeat()` munus uno atque etiam valorem.
///
/// Iterators infinito similis `repeat()` saepe usus adapters et quasi [`Iterator::take()`], ut faciam eis finitum.
///
/// Si genus elementum iterator ad opus efficiendum, non `Clone`: si tu non vis servare, aut, quod saepius in memoriam elementum, vos can utor pro [`repeat_with()`] munus.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::iter;
///
/// // 4ever quaternarius;
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup tamen quadringentis
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Euntes finita in [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // tandem exemplum, ut nimium multis quattuor.Sit quattuor pedes sed.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... Nunc erant 'quod fit
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Qui altero sermone repetit iterator ad elementum et per omne sæculum.
///
/// Hoc munus [`repeat()`] `struct` est creata sunt.Quia eius plura videantur documenta.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}