use crate::fmt;

/// A qua gignit iterator se vocat iteration Agricola `F: FnMut() -> Option<T>` provisum est.
///
/// Hic mos creando concedit iterator cum aliquo mores sine usura magis verbosum Syntax of exsequendam et partum a genus [`Iterator`] trait dedicated pro eo.
///
/// Iterator `FromFn` nota quod non facit positionibus circa mores est Agricola et conservatively igitur efficiendum, non [`FusedIterator`] vel dominari ejus a [`Iterator::size_hint()`] `(0, None)` default.
///
///
/// A Agricola potest capit et per eius environment ad inuestigandum statu iterations.Fretus quomodo iterator adhibetur, hoc est, ut requirere specifica keyword in [`move`] Agricola.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Sit scriptor in effectum deducendi rursus e contra iterator [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Incremento nostrae comitem.Hoc est cur interdum at, nulla.
///     count += 1;
///
///     // Reprehendo ad animadverto si youve 'perfecti sumus aut non est numerus.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Ex quo quisque iterationem vocat Agricola `F: FnMut() -> Option<T>` iterator esse provisum.
///
/// Hoc `struct` creatus est in [`iter::from_fn()`] munus.
/// Vide eius pro documentis magis.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}