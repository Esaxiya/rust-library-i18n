use crate::iter::{FusedIterator, TrustedLen};

/// Gignit et iterator eius ociosus iacui generat, quod sit exacte valorem olim provisum est ut expeterem Agricola.
///
/// Hoc communiter aptet unum valorem [`chain()`] generantis derivata in alias species ex iteration.
/// Maybe vestri sunt et fere omnibus iterator opercula, sed opus esse extra casu speciali.
/// Maybe habere opus quod operatus es in iterators, sed necesse est tantum aliquid unum valorem.
///
/// Secus [`once()`], munus erit hic generate segniter ad petitionem ad valorem.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::iter;
///
/// // est numerus loneliest
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // iustum est: quod omnes dabimus tibi
/// assert_eq!(None, one.next());
/// ```
///
/// Una in aliam Chaining iterator.
/// Lets 'narro quod per sulum lima Volo repetere `.foo` ex indice sed et configuratione file:
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // et iterator DirEntry translatum a patriis opus est an-s de iterator ad PathBufs, ita et nos uti tabula
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // modo iustum nostrae nobis aboutconfig file iterator
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // duas in unum magnum iterator catena iterators
/// let files = dirs.chain(config);
///
/// // quae nobis in omni files .foo tum .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// An iterator facientem unum genus element a per quod provisum `A` `F: FnOnce() -> A` Agricola.
///
///
/// Hoc munus [`once_with()`] `struct` est creata sunt.
/// Vide eius pro documentis magis.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}