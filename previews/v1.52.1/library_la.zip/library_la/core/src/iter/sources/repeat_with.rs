use crate::iter::{FusedIterator, TrustedLen};

/// Quae nova gignit iterator genus repetit elementis per quod provisum `A` sine fine claudetur, in repeater, `F: FnMut() -> A`.
///
/// Et vocat `repeat_with()` ad munus repeater et super iterum.
///
/// Iterators infinito similis `repeat_with()` saepe usus adapters et quasi [`Iterator::take()`], ut faciam eis Vtrum finitum.
///
/// Si enim genus element iterator [`Clone`] instrumentis opus est, et ut sit OK fons elementum in memoria, ut vos utor pro [`repeat()`] munus.
///
///
/// An non [`DoubleEndedIterator`] `repeat_with()` iterator produci.
/// Si opus sit [`DoubleEndedIterator`] `repeat_with()` redire, placere aperire GitHub exitus tuus usus explicandi causa.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::iter;
///
/// // ut lets pono quod habet genus, non est de aliquo valore `Clone` sive quae in memoria sunt iustus non vis ad quod tamen non est sumptuosus:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // certo valorem æternum:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Et mutationem usus futura finita:
///
/// ```rust
/// use std::iter;
///
/// // Ut zeroth de duabus tertiam potentiam:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... Nunc erant 'quod fit
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// An `A` iterator qui iterat elementis genus omne sæculum per quod provisum `F: FnMut() -> A` Agricola.
///
///
/// Hoc `struct` creatus est in [`repeat_with()`] munus.
/// Vide eius pro documentis magis.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}