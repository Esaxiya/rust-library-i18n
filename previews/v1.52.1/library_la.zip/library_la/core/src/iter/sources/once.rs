use crate::iter::{FusedIterator, TrustedLen};

/// Iterator gignit est qui aliquando non sequitur prorsus elementum.
///
/// Hoc unum aptet pretii communiter rem in aliis generibus [`chain()`] iteration.
/// Maybe vestri sunt et fere omnibus iterator opercula, sed opus esse extra casu speciali.
/// Maybe habere opus quod operatus es in iterators, sed necesse est tantum aliquid unum valorem.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::iter;
///
/// // est numerus loneliest
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // iustum est: quod omnes dabimus tibi
/// assert_eq!(None, one.next());
/// ```
///
/// Una in aliam Chaining iterator.
/// Lets 'narro quod per sulum lima Volo repetere `.foo` ex indice sed et configuratione file:
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // et iterator DirEntry translatum a patriis opus est an-s de iterator ad PathBufs, ita et nos uti tabula
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // modo iustum nostrae nobis aboutconfig file iterator
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // duas in unum magnum iterator catena iterators
/// let files = dirs.chain(config);
///
/// // quae nobis in omni files .foo tum .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// An quia non sequitur iterator prorsus elementum semel.
///
/// Hoc munus [`once()`] `struct` est creata sunt.Vide eius ad plura documenta.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}