//! Quia `str` Trait implementations.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Iubere arma in chordis.
///
/// Gloria iussi sunt a [lexicographically](Ord#lexicographical-comparison) values byte.
/// Secundum ordines forms Hoc codice officio contineat puncta in codice charts.
/// "alphabetical" non oportet quod ordo qui variatur per linguam locus.
/// Genus chordarum secundum culturaliter acceptabile Utilia data signa requirit locale quod est extra genus `str` ad harum.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Comparatio instrumentis chordae gereretur.
///
/// Nervi a [lexicographically](Ord#lexicographical-comparison) comparari values byte.
/// Haec forms codice comparat puncta secundum ad codice charts suam dignitatem teneant.
/// "alphabetical" non oportet quod ordo qui variatur per linguam locus.
/// Cum in propria chordarum secundum culturaliter acceptabile data signa requirit fronte tegunt, quod est extra genus `str` harum ex.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Syntax cum vasis substring slicing `&self[..]` aut `&mut self[..]`.
///
/// Segmentum returns totius chordae id vel `&mut self` `&self` redit.`&Se aequiparantur ii [0 ..
/// len] or ``&mut se [0 ..
/// len]`.
/// Dissimile Iudex operāciju nusquam panic.
///
/// *O* Ac (I).
///
/// Prior ad 1.20.0, haec Indexing cum adhuc fulta res recta et exsecutionem `Index` `IndexMut`.
///
/// Vel equivalent ad `&self[0 .. len]` `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Syntax substring slicing cum instrumentis vel `&self[begin .. end]` `&mut self[begin .. end]`.
///
/// Redit a FRUSTUM de filum data est a range byte [`begin`, `end`).
///
/// *O* Ac (I).
///
/// Prior ad 1.20.0, haec Indexing cum adhuc fulta res recta et exsecutionem `Index` `IndexMut`.
///
/// # Panics
///
/// Panics `begin` vel si non `end` quae ad mores et incipiens a offset byte (ut definitur in `is_char_boundary`), si `begin > end`, vel `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // haec voluntatis panic:
/// // byte `ö` in II mendacium:
/// // S [II ..3]:
///
/// // byte mendacium in `老`&s VIII [I ..
/// // 8];
///
/// // byte est extra linea C&s [III ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // Salutem et justo repressit `start` `end` sint chari et terminus
            // et transiens in tutum nos referat, ita reditus ad unum quoque valorem.
            // Nos quoque termini sedatus charitatis, et verum est UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // Confidenter `start` sicut et repressit et chari `end` sunt termini.
            // Scimus obtinuit eam a monstratorem sit quod unique `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // UMBRA: in `self` non SALUTATOR polliceri fines `slice`
        // omnes conditiones `add` quod satiat.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // Salutem et vide quia comment `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // ut indicem in is_char_boundary checks [0: .len()] potest reuse `get` ut supra propter NLL tribulationis
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // Salutem et justo repressit `start` `end` sint chari et terminus
            // et transiens in tutum nos referat, ita reditus ad unum quoque valorem.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Syntax substring slicing cum instrumentis vel `&self[.. end]` `&mut self[.. end]`.
///
/// Segmentum placentae datis refert filum a byte range [`0`, `end`).
/// Vel equivalent ad `&self[0 .. end]` `&mut self[0 .. end]`.
///
/// *O* Ac (I).
///
/// Prior ad 1.20.0, haec Indexing cum adhuc fulta res recta et exsecutionem `Index` `IndexMut`.
///
/// # Panics
///
/// Panics `end` si non quae ad byte et incipiens a offset ingenii (ut ex defined `is_char_boundary`), aut, si `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // Salutem sicut est `end` chari sedatus est terminus
            // et transiens in tutum nos referat, ita reditus ad unum quoque valorem.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // Salutem sicut est `end` chari sedatus est terminus
            // et transiens in tutum nos referat, ita reditus ad unum quoque valorem.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // Salutem sicut est `end` chari sedatus est terminus
            // et transiens in tutum nos referat, ita reditus ad unum quoque valorem.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Syntax `&self[begin ..]` et cum arma substring slicing `&mut self[begin ..]`.
///
/// Segmentum placentae redit datis linea a range byte [`begin`, `len`).`&Equivalent ad se [.. incipiunt
/// ben] 'aut `&mut se [.. incipere
/// len]`.
///
/// *O* Ac (I).
///
/// Prior ad 1.20.0, haec Indexing cum adhuc fulta res recta et exsecutionem `Index` `IndexMut`.
///
/// # Panics
///
/// Si non Panics `begin` quae ad mores et incipiens a felis byte (ut definitur in `is_char_boundary`), vel `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // Salutem `start` est quod ita repressit chari terminos
            // et transiens in tutum nos referat, ita reditus ad unum quoque valorem.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // Salutem `start` est quod ita repressit chari terminos
            // et transiens in tutum nos referat, ita reditus ad unum quoque valorem.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // UMBRA: in `self` non SALUTATOR polliceri fines `slice`
        // omnes conditiones `add` quod satiat.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SALUS: identical ut `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // Salutem `start` est quod ita repressit chari terminos
            // et transiens in tutum nos referat, ita reditus ad unum quoque valorem.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Syntax cum vasis substring slicing `&self[begin ..= end]` aut `&mut self[begin ..= end]`.
///
/// Segmentum returns byte rhoncus [`begin`, `end`] ex linea data.Vel equivalent ad `&self [begin .. end + 1]` `&mut self[begin .. end + 1]` nisi `end` si maximum valorem habet ad `usize`.
///
/// *O* Ac (I).
///
/// # Panics
///
/// Panics si `begin` non designandum ad incipiens byte offset a ingenii (ut definitur in `is_char_boundary`), si `end` non illud est quod ending byte offset de character (`end + 1` aut a incipiens byte offset non pervenerunt usque ad `len`), si `begin > end` vel si `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // Confidenter RECENS `get_unchecked` contractus debeat sustinere salutem.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // Confidenter RECENS `get_unchecked_mut` contractus debeat sustinere salutem.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Syntax cum vasis substring slicing `&self[..= end]` aut `&mut self[..= end]`.
///
/// Byte redit a FRUSTUM fili data [0, `end`] rhoncus.
/// Equivalent ad `&self [0 .. end + 1]` nisi `end` si habeat maximum valorem et in `usize`.
///
/// *O* Ac (I).
///
/// # Panics
///
/// Si non Panics `end` a quo ad terminum a offset mores byte (byte incipiens a `end + 1` aut offset `is_char_boundary` possumus definire, ut aut aequales `len`), vel `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // Confidenter RECENS `get_unchecked` contractus debeat sustinere salutem.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // Confidenter RECENS `get_unchecked_mut` contractus debeat sustinere salutem.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Et a linea Mysql_queries valorem
///
/// `FromStr` est scriptor [`from_str`] modum adhiberi saepe implicite, per [`str`] 's [`parse`] modum.
/// Vide [parse` ']' s documenta et exempla.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` non est vita parametri, et quia non potes modo parse types vita quae ipsi parametro æqualis.
///
/// Id est: parse in possis cum `i32` `FromStr` sed non `&i32`.
/// Parse `i32` continet instrúite non potes, sed non unum est continet `&i32`.
///
/// # Examples
///
/// Implementation in exemplum basic et `FromStr` in `Point` type:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Ex quibus error potest esse consociata et reddidit parsing.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Parses `s` ut reverterentur ad filum de valore huius generis.
    ///
    /// Si parsing succedit qui interius reverterentur ad valorem [`Ok`], aliter in linea cum ill is, quae formatae sint ut reditus errorem specifica intus [`Err`].
    /// Quod genus suum est error de trait implementation.
    ///
    /// # Examples
    ///
    /// In basic usus [`i32`], vir, ut generis instrumentis `FromStr`;
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Et ex parse `bool` filum.
    ///
    /// `Result<bool, ParseBoolError>` facit: quia, ut `s` parseable esse vel non esse.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Nota: In multis casibus `.parse()` modum supra est `str` propriis.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}