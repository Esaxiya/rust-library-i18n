//! Diffinit genus utf8 errorem.

use crate::fmt;

/// Conantes errores possunt interpretari [`u8`] serie velut filo.
///
/// Ut sic, qui de genere `from_utf8` munera et quia utraque modi [`String`] s, et ['&str`] s id error est uti, exempli gratia.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Modi'shic error potest esse in type partum similes functionality `String::from_utf8_lossy` sine opum congerie memoria;
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Redit usque ad indicem ad filum, quae data est verum UTF-8 verificatur.
    ///
    /// Index `from_utf8(&input[..index])` maximum est ita ut non reverteretur `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// use std::str;
    ///
    /// // nulli alii bytes, per vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 refert enim Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // hic secundo irritum byte
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Praebet magis notitia de defectum;
    ///
    /// * `None`: insperata tandem uentum input.
    ///   `self.valid_up_to()` quod ab I ad III bytes ad ultimum input.
    ///   Si in byte amnis (ut per network vel lima ostium tabernaculi) est componerentur incrementally, hoc posset esse valet, cuius `char` spanning multiple UTF-8 byte Consequentia chunks.
    ///
    ///
    /// * `Some(len)`: byte et repentina inventi.
    ///   Tamen est longum ad minimum valet iste ordo divinitus `valid_up_to()` byte.
    ///   Decoding pergere ut postquam seriem (Post fermentum a odio [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) si autem lossy decoding.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Error postquam rediit a `bool` per parsing deficit [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}