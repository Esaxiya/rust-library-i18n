//! OBFULA ex `str` bytes vias ad creare.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Segmentum placentae bytes linea converts ad scalpere.
///
/// A filum ([`&str`]) FRUSTUM de bytes factum ([`u8`]), et byte FRUSTUM de bytes ([`&[u8]`][byteslice]) est factus, sic inter duas proselytis hoc munus.
/// Byte crustae omnem Nec valet filum crustae vero, qui eam exigit [`&str`] UTF-8 valet.
/// `from_utf8()` Suspendisse ut sint et valida bytes UTF-8, et non per conversionem.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Si ut certo valet UTF-8 scalpere byte et non vis penes eosdem peri reprehendo caput de validitate, hoc munus non est statio male fida versio, [`from_utf8_unchecked`], quam habet in extrema plebe quaerit reprehendo, sed etiam morum.
///
///
/// Si opus `String` loco `&str`, considerans [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Quia tu potes, nequimus, et `[u8; N]` Stack et accipies [`&[u8]`][byteslice] potest ex eo, hoc munus est ut a ACERVUS filum-partita imperia.Est et in hoc exemplum exempla infra sectionem.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Segmentum `Err` redit si non caveatur, cur UTF-8 descriptione UTF-8 non scalpere.
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::str;
///
/// // quidam bytes, in vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Scimus autem his bytes valet, ut iustus utor `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Non recta bytes:
///
/// ```
/// use std::str;
///
/// // nulli alii bytes, per vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Ecce enim importat soUicitudo de [`Utf8Error`] pro magis details de generis errores, qui potest rediit.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // quidam bytes in ordinata Stack disposuit,
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Scimus autem his bytes valet, ut iustus utor `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // Utilitatibus consulens currentes radice Just.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Segmentum placentae bytes converts rerum invisibilium visibiliumque ad commutabile linea segmentum.
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" ut rerum invisibilium visibiliumque vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Scimus enim quod haec bytes ratum est, si uti `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Non recta bytes:
///
/// ```
/// use std::str;
///
/// // Nonnulli bytes irritum mutabiliter vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Ecce enim importat soUicitudo de [`Utf8Error`] pro magis details de generis errores, qui potest rediit.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // Utilitatibus consulens currentes radice Just.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Segmentum placentae bytes converts ad filum super filum contineat illa secare non valet reprehendo UTF-8.
///
/// Ecce enim salvum versionem, [`from_utf8`], quia magis notitia.
///
/// # Safety
///
/// Hoc munus tutum est, quod verum est, non reprehendo qui illum ad Transierunt bytes UTF-8.
/// Si violare coactione est, indefinitam mores eventus, quod reliquum Rust supponitur, scilicet quod [`&str`] s UTF-8 non valet.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::str;
///
/// // quidam bytes, in vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // Utilitatibus consulens RECENS `v` sunt, est verum fidei in bytes UTF-8.
    // Et placebit vecordia sua `&str` et `&[u8]` habent idem layout.
    unsafe { mem::transmute(v) }
}

/// Segmentum placentae bytes converts ad filum super filum contineat illa secare non valet reprehendo UTF-8;versio posterius mutari potest.
///
///
/// Vide incommutabili versionem, [`from_utf8_unchecked()`] pro magis notitia.
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // Utilitatibus consulens ma gistrum suum praestare ut `v` bytes
    // UTF-8 quae valet, sicut in `*mut str` cast tutum est.
    // Item, non tutum est, quod illa regula est regula dereference referat ex quibus praestatur invalidam esse scribit.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}