//! Manipulation filum.
//!
//! Quia magis details, videatur in [`std::str`] moduli.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ex terminis
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. primo <ultimum
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. mores terminus
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // mores invenire
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` terminus len minus sit et integer
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Longitudo `self` redeat.
    ///
    /// Hoc est longitudinem bytes non [`char`] s vel graphemes.
    /// In aliis verba, quae non licet homini considerat id quod est longitudinem filum.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // ludo mentis f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `true` refert, si nulla `self` habet longitudinem bytes.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Quod `index`-byte checks th prima parte codice byte UTF-8 in ordine ad finem vel filum.
    ///
    ///
    /// Est filum initium et finis (cum indicem '== self.len()`) sunt, considerandum ut terminus.
    ///
    /// Si autem major `false` refert `index` `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // satus of `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // byte secundo de `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // byte et tertia `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 len et semper ok.
        // 0 expressis verbis et in test optimize possit facile reprehendo sicco filum notitia legere et skip in eo causam.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Hic est aliquantulus equivalent ad magica: b <|| CXXVIIIb> CXCII=
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Converts in linea segmentum byte ad scalpere.
    /// Ut convertendum sit in linea segmentum segmentum byte utere [`from_utf8`] munus.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // Consulens int eadem voce quod duplex transmutare layout
        unsafe { mem::transmute(self) }
    }

    /// Mutabilem uerteretur converts filum segmentum segmentum byte ad commutabile.
    ///
    /// # Safety
    ///
    /// In RECENS esse contentus ut ad ad ultimum segmentum horum mutuo postulaverit, et valet ante UTF-8 underlying `str` adhibetur.
    ///
    ///
    /// Uti de quorum `str` UTF-8 continet in se verum est, indefinitam, non mores.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SALUS et cast from `&str` `&[u8]` est ut sit tutum `str`
        // ut layout idem est `&[u8]` (hoc possunt tantum libstd testamenti sponsor).
        // Monstratorem dereference tutum est quod fit ex quibus praestatur rerum invisibilium visibiliumque referat ad verum esse scribit.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Est filum fragmen rudis converts ad monstratorem.
    ///
    /// Sicut filum a FRUSTUM de bytes crustae, in a rudis [`u8`] regula demonstrat.
    /// Hoc regula et arte conexa perhibent de linea segmentum prima byte.
    ///
    /// Necesse est ut sit non SALUTATOR scripta sunt in regula rediit.
    /// Mutate Si vos postulo ut linea contenta, nempe segmentum utere [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Converts ad rerum invisibilium visibiliumque filum fragmen rudis monstratorem.
    ///
    /// Sicut filum a FRUSTUM de bytes crustae, in a rudis [`u8`] regula demonstrat.
    /// Hoc regula et arte conexa perhibent de linea segmentum prima byte.
    ///
    /// Quod linea segmentum et respondens fac solum sudatio, ita mutatus est, quod illud verum manet UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Refert enim subslice de `str`.
    ///
    /// Hoc non est `str` indexing, TREPIDANS opposita.
    /// Quotiens equivalent redit [`None`] Indexing panic esset operatio.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // ordo terminorum indices non UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ex terminis
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Subslice refert mutabiliter ab `str`.
    ///
    /// Hoc non est `str` indexing, TREPIDANS opposita.
    /// Quotiens equivalent redit [`None`] Indexing panic esset operatio.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // recte longitudinem
    /// assert!(v.get_mut(0..5).is_some());
    /// // ex terminis
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Subslice refert immoderata est `str`.
    ///
    /// Haec ferat h or ret indexing ad alterutram istarum `str`.
    ///
    /// # Safety
    ///
    /// Nomenclator digesserit hoc munus ab his, qui sunt responsible preconditions es satiata:
    ///
    /// * Index est incipiens ut ultra non transeat in ending index;
    /// * Index secare oportet modum primi;
    /// * Index tamdiu prostratus in serie UTF-8 fines habet proprios.
    ///
    /// Numquam mihi animus est, et filum rediit referiat irritum segmentum memoria non violaverit invariants `str` communicatione genus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // Consulens saluti contractus `get_unchecked` gistrum debet tueri;
        // segmentum est dereferencable tutum est quia `self` referat.
        // Et incolumem reddidit, quod est regula impls `SliceIndex` est inter gentes prospiciendum est, ut sit.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Refert mutabilis inoffensum subslice de `str`.
    ///
    /// Haec ferat h or ret indexing ad alterutram istarum `str`.
    ///
    /// # Safety
    ///
    /// Nomenclator digesserit hoc munus ab his, qui sunt responsible preconditions es satiata:
    ///
    /// * Index est incipiens ut ultra non transeat in ending index;
    /// * Index secare oportet modum primi;
    /// * Index tamdiu prostratus in serie UTF-8 fines habet proprios.
    ///
    /// Numquam mihi animus est, et filum rediit referiat irritum segmentum memoria non violaverit invariants `str` communicatione genus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // Salutem et incolumitatem tueri debeat RECENS `get_unchecked_mut` contractus;
        // segmentum est dereferencable tutum est quia `self` referat.
        // Et incolumem reddidit, quod est regula impls `SliceIndex` est inter gentes prospiciendum est, ut sit.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Linea segmentum segmentum filo se facit, praeteriens salutis compescit.
    ///
    /// Hoc generaliter commendatur usus caute;Nam tutam ac [`Index`] [`str`] modo video.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Haec nova FRUSTUM de `begin` accedit ad `end`, inter `begin` `end` brevem exclusive.
    ///
    /// Ut mutabilem uerteretur scalpere pro linea, videatur in [`slice_mut_unchecked`] modum.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Tamquam salutores huius author est, quod tria sunt condiciones munus saturatus fueris:
    ///
    /// * `begin` `end` ne excedat.
    /// * `begin` locum in nervo atque `end` byte secare oportet.
    /// * `begin` et `end` mentiri oportet serie UTF-8 in finibus circumscribit.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // Consulens saluti contractus `get_unchecked` gistrum debet tueri;
        // segmentum est dereferencable tutum est quia `self` referat.
        // Et incolumem reddidit, quod est regula impls `SliceIndex` est inter gentes prospiciendum est, ut sit.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Linea segmentum segmentum filo se facit, praeteriens salutis compescit.
    /// Hic commendatur communiter uti caute;Nam aliter tutam [`str`] et vide [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Haec nova FRUSTUM de `begin` accedit ad `end`, inter `begin` `end` brevem exclusive.
    ///
    /// Ut filum scalpere pro incommutabilem, videatur in [`slice_unchecked`] modum.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Tamquam salutores huius author est, quod tria sunt condiciones munus saturatus fueris:
    ///
    /// * `begin` `end` ne excedat.
    /// * `begin` locum in nervo atque `end` byte secare oportet.
    /// * `begin` et `end` mentiri oportet serie UTF-8 in finibus circumscribit.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // Salutem et incolumitatem tueri debeat RECENS `get_unchecked_mut` contractus;
        // segmentum est dereferencable tutum est quia `self` referat.
        // Et incolumem reddidit, quod est regula impls `SliceIndex` est inter gentes prospiciendum est, ut sit.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Bifariam dividunt ad indicem chorda secare.
    ///
    /// In argumentum, `mid`, debet esse offset byte ab initio ad filum.
    /// Ita oportet quod in codice UTF-8 terminus a puncto.
    ///
    /// Duo purus ab initio ire in rediit ad filum `mid` secare, et ad finem filum `mid` scalpere.
    ///
    /// Ut filum posterius mutari potest pro crustae, videatur in [`split_at_mut`] modum.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Si non Panics `mid` in UTF-8 codice parte terminus, vel quod praeteritum sit in fine ultimo puncto in linea codice FRUSTUM.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // ut indicem is_char_boundary checks in [0; .len()]
        if self.is_char_boundary(mid) {
            // Salutem sicut est `mid` chari sedatus est lex.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Unam chordam mutabilium duo incidunt index.
    ///
    /// In argumentum, `mid`, debet esse offset byte ab initio ad filum.
    /// Ita oportet quod in codice UTF-8 terminus a puncto.
    ///
    /// Duo purus ab initio ire in rediit ad filum `mid` secare, et ad finem filum `mid` scalpere.
    ///
    /// Ut res immobiles filum pro crustae, [`split_at`] modum videre.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Si non Panics `mid` in UTF-8 codice parte terminus, vel quod praeteritum sit in fine ultimo puncto in linea codice FRUSTUM.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // ut indicem is_char_boundary checks in [0; .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // Salutem sicut est `mid` chari sedatus est lex.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Refert quod in iterator [`char`] s filum de scalpere.
    ///
    /// Quasi ex linea segmentum UTF-8 valet, repetere non poterit per filum [`char`] a FRUSTUM.
    /// Quod factum tale iterator refert.
    ///
    /// [`char`] Gravis meminisse non habens forms Scalar aestimationis supra et non congruit vobis ideam de 'character' quid sit.
    ///
    /// Iteration super grapheme racemus patens est quis vos vere volo.
    /// Hoc provisum est a Rust functionality non vexillum scriptor bibliotheca, crates.io reprehendo instead.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Scito [`char`] s potest insito vestras congruit fere ingenia,
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // non 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Refert ad iterator in ['char`] s FRUSTUM de linea et officiis suis.
    ///
    /// Quasi ex linea segmentum UTF-8 valet, repetere non poterit per filum [`char`] a FRUSTUM.
    /// Haec per modum iterator returns His utrorumque [char` '] s, tum byte suis locis habere iussi.
    ///
    /// Et fruges ejus tuples iterator.Positio prima [`char`] secundo.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Scito [`char`] s potest insito vestras congruit fere ingenia,
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ne (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // III ad note hic est duo ultima mores tulit bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// An filum iterator in bytes de scalpere.
    ///
    /// A FRUSTUM est ut linea eas in sequens quadrichordum bytes, repetere non poterit per a linea segmentum byte.
    /// Quod factum tale iterator refert.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// A FRUSTUM filum scinditur et whitespace.
    ///
    /// Iterator reddet rediit crustae de linea, quae sub-segmentis originali in linea segmentum, moles separari a nullo whitespace.
    ///
    ///
    /// 'Whitespace' Related dicitur, secundum verba forms of the property `White_Space` Core.
    /// Quod si non modo in ASCII whitespace split vis pro utere [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Omnium whitespace censentur;
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// A FRUSTUM filum scinditur in ASCII whitespace.
    ///
    /// Iterator reddam in rediit sub-segmentis, quae filum crustae de originali linea segmentum, moles ASCII separata a nullo whitespace.
    ///
    ///
    /// Ad forms per split pro `Whitespace` utere [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ASCII omnium whitespace censentur;
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Et versus ad iterator filo sicut filum purus.
    ///
    /// Aut finita aut vehiculis (`\n`) newline ducantur linea reditu (`\r\n`) turpis.
    ///
    /// In ultima recta ad libitum est finis.
    /// Ultimo terminatur revertetur filo ipso fine versus eandem chordam alioqui sine fine ultimo.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Et non requiratur ultima linea finis:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// An per lineas a linea iterator.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Refert ad `u16` iterator et in linea cum encoded UTF-16.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Si enim data `true` refert aequet exemplar a FRUSTUM de hac sub-filum scalpere.
    ///
    /// Si non refert `false`.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Redit lino `true` si dicatur quod forma compositus praepositionem scalpere.
    ///
    /// Si non refert `false`.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Etiamne si data est forma compositus `true` Redit lino scalpere.
    ///
    /// Si non refert `false`.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Haec prima linea index byte redit naturam secare ut compositus exemplum.
    ///
    /// Non refert [`None`] si exemplum aequare.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Forma simplex;
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Plus uti punctum patterns universa-style liberum atque clausuris,
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Non invenire formam,
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Index redit primum indolem byte par ratio in linea rightmost scalpere.
    ///
    /// Non refert [`None`] si exemplum aequare.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Forma simplex;
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Magis universa patterns ad commissuras;
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Non invenire formam,
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// An iterator super substrings filum FRUSTUM huius paginarum, separata per characteres matched formam nostram.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # mores iterator
    ///
    /// Et rediit [`DoubleEndedIterator`] iterator erit exemplo, si fortuna concedit quaerere et fructum quaerere forward/reverse eadem elementa.
    /// Haec enim sit verum, eg, [`char`] sed non `&str`.
    ///
    /// Si fortuna concedit exemplum eventumque pugnae quaerere, sed differunt ut deinceps a search, [`rsplit`] ad modum adhiberi potest.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Forma simplex;
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Si forma chars Segmentum divisit unicuique rei totius moribus
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// A more universa forma est usus Agricola;
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Si plures sunt contigua diviserunt corda tu demum vacuis output chordas:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Contiguis diviserunt inania corda separentur.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Diviserunt exortu vel filum finitimae inanitate fine trahunt.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Cum vacuis uti chorda separator est ratio disterminat omnis chordam inter initium finemque fili.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Diviserunt sibi contiguus non modo ducunt ad mores, ubi surprising whitespace SEPARATOR ut adhibetur.Hoc codice sit verum:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Est enim dabo vobis _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Uti [`split_whitespace`] haec mores.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// An iterator super substrings filum FRUSTUM huius paginarum, separata per characteres matched formam nostram.
    /// Differt ab iterator `split` ex parte tamquam in Termino compositus ex Substring `split_inclusive` relinquit.
    ///
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Si enim elementum ad ultima linea est comparatus, ut sit erit elementum consideretur in Termino substring, quales ante praecesserint.
    /// Item quod substring novissima erit in rediit iterator.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// An iterator substrings super linea data segmentum est, separata a forma characteres matched: et dabat in vicissim retro commeant.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # mores iterator
    ///
    /// Et rediit iterator postulat ut sculptura sustinet que clades acceptae quaerere et erunt fruges ejus quaerere forward/reverse [`DoubleEndedIterator`] si in eadem elementa.
    ///
    ///
    /// Nam iterando a fronte ad [`split`] modum adhiberi potest.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Forma simplex;
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// A more universa forma est usus Agricola;
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// An substrings iterator in data linea a FRUSTUM de paginarum, separata ab characteres matched formam nostram.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] valet, quin vacuum Trailing Substring Si autem captivus duceris.
    ///
    /// [`split`]: str::split
    ///
    /// Hoc potest esse modum usus ad filum, quae data est _terminated_, _separated_ quam per formam nostram.
    ///
    /// # mores iterator
    ///
    /// Et rediit [`DoubleEndedIterator`] iterator erit exemplo, si fortuna concedit quaerere et fructum quaerere forward/reverse eadem elementa.
    /// Haec enim sit verum, eg, [`char`] sed non `&str`.
    ///
    /// Si fortuna habetis formam concedit ut quaero praecessi et non differunt ex deinceps quaerere et [`rsplit_terminator`] modum adhiberi potest.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// An iterator super substrings `self` est, separata a forma matched characters in principio ordinis, et afferebat.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] valet, quin vacuum Trailing Substring Si autem captivus duceris.
    ///
    /// [`split`]: str::split
    ///
    /// Hoc potest esse modum usus ad filum, quae data est _terminated_, _separated_ quam per formam nostram.
    ///
    /// # mores iterator
    ///
    /// Iterator requirit ut rediit in formam quaerere fortuna sustinet, et sit tibi si finita est duplex forward/reverse quaerere sese fert elementa eodem.
    ///
    ///
    /// Nam iterando a fronte ad [`split_terminator`] modum adhiberi possunt.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Iterator substrings est supra de linea data segmentum paginarum, separata a forma determinata est reversus ad `n` maxime items.
    ///
    /// Si `n` substrings sunt rediit, ultimum substring (n`th substring ly ') residuum erit in linea continet.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # mores iterator
    ///
    /// Et reddidit iterator non sit duplex finita; quia non efficient ut sustentatio.
    ///
    /// Si fortuna habetis formam concedit search, [`rsplitn`] ad modum adhiberi potest.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Forma simplex;
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// A more universa forma est usus Agricola;
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// An hoc substrings filum super iterator FRUSTUM, separata per informationem, de incipiens linea ad extremum, quid est reversus ad `n` maxime items.
    ///
    ///
    /// Si `n` substrings sunt rediit, ultimum substring (n`th substring ly ') residuum erit in linea continet.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # mores iterator
    ///
    /// Et reddidit iterator non sit duplex finita; quia non efficient ut sustentatio.
    ///
    /// Scissione inquiunt Nam a fronte et [`splitn`] modum adhiberi potest.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Forma simplex;
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// A more universa forma est usus Agricola;
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Certum eventum delimiter filum scinditur prima que est ac reversa praemittunt delimiter delimiter ante.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Aestifer filum de ultimo Eventum praefigunt ex certa redit delimiter que ante et post delimiter delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// An in iterator disiunctis aequet datum est exemplum in linea segmentum.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # mores iterator
    ///
    /// Et rediit [`DoubleEndedIterator`] iterator erit exemplo, si fortuna concedit quaerere et fructum quaerere forward/reverse eadem elementa.
    /// Haec enim sit verum, eg, [`char`] sed non `&str`.
    ///
    /// Sed quaero praecessi ut ejus exemplo, si fortuna concedit deinceps differunt a search, [`rmatches`] ad modum adhiberi potest.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// An de disiunctis iterator aequet exemplaris in linea segmentum haec fecit in vicissim retro commeant.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # mores iterator
    ///
    /// Et rediit iterator postulat ut sculptura sustinet que clades acceptae quaerere et erunt fruges ejus quaerere forward/reverse [`DoubleEndedIterator`] si in eadem elementa.
    ///
    ///
    /// Nam iterando a fronte ad [`matches`] modum esse possit.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// An iterator per disiunctis par ratio in hac filum de fragmen tum par est index animi, ut ad.
    ///
    /// Quia compositus est in `pat` `self` qui overlap, indices correspondentes modo par primis sunt, rediit.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # mores iterator
    ///
    /// Et rediit [`DoubleEndedIterator`] iterator erit exemplo, si fortuna concedit quaerere et fructum quaerere forward/reverse eadem elementa.
    /// Haec enim sit verum, eg, [`char`] sed non `&str`.
    ///
    /// Si autem exemplar eius concedit que clades acceptae quaero praecessi ut deinceps differunt a search, [`rmatch_indices`] ad modum adhiberi potest.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // nisi prius `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Iterator in aequet exemplaris de disiunctis in `self` fecit movetur in ordinem compositus ex una cum indice.
    ///
    /// Nam Matches de `pat` qui in `self` overlap, non modo par indices correspondentes ultimum rediit.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # mores iterator
    ///
    /// Et rediit iterator postulat ut sculptura sustinet que clades acceptae quaerere et erunt fruges ejus quaerere forward/reverse [`DoubleEndedIterator`] si in eadem elementa.
    ///
    ///
    /// Nam iterating a fronte ad [`match_indices`] modum adhiberi possunt.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // solum ultimum `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Redit a FRUSTUM secum ducens latamque trahens filum whitespace remota.
    ///
    /// 'Whitespace' Related dicitur, secundum verba forms of the property `White_Space` Core.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Sit linea segmentum ducens secum redit whitespace remotum est.
    ///
    /// 'Whitespace' Related dicitur, secundum verba forms of the property `White_Space` Core.
    ///
    /// # text directio
    ///
    /// A filum est bytes eas in sequens quadrichordum.
    /// `start` hoc intelligitur per quod primus byte nervisad sinistram-ad-Latina sive rectum, sicut Russian lingua, hoc erit in latere sinistro et dextro ad sinistram-ad-Arabica et Hebraica, sicut linguae, haec erunt in latere dextro.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Redit filum a FRUSTUM latas whitespace remotum est.
    ///
    /// 'Whitespace' Related dicitur, secundum verba forms of the property `White_Space` Core.
    ///
    /// # text directio
    ///
    /// A filum est bytes eas in sequens quadrichordum.
    /// `end` situm est ultima in hoc byte nervisad sinistram-ad-similis lingua Latina aut Russian rectum, hoc erit in latere dextra et sinistra, in dextra linguae tamquam Arabica et Hebraica, hoc est a sinistra parte.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Sit linea segmentum ducens secum redit whitespace remotum est.
    ///
    /// 'Whitespace' Related dicitur, secundum verba forms of the property `White_Space` Core.
    ///
    /// # text directio
    ///
    /// A filum est bytes eas in sequens quadrichordum.
    /// 'Left' quod significatur in hoc primus byte nervisSimiliter in vocabulis Hebraica aut Arabica quae dextra sinistra potius quam relinquenda rectum hoc sit _right_ parte sinistra est.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Redit filum a FRUSTUM latas whitespace remotum est.
    ///
    /// 'Whitespace' Related dicitur, secundum verba forms of the property `White_Space` Core.
    ///
    /// # text directio
    ///
    /// A filum est bytes eas in sequens quadrichordum.
    /// 'Right' In hoc enim significatur ultimus status byte nervislinguae hebraeae sicut nec de Armenia quae ius sinistram potius quam ad dextrum, hoc erit _left_ latus rectum est.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// A FRUSTUM filum refert negandum praemittit suffixes cum omnibus sitis forma, ut saepe aequare remotum est.
    ///
    /// Quod non potest esse [pattern] [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si fuerit par.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Forma simplex;
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// A more universa forma est usus Agricola;
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Nota memento primo par, inferius si corrigere eum
            // tandem diversis compositus est,
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // UMBRA: `Searcher` est nota redire valet indices.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Refert filum de frustum ex toto saepe praemittit quae remota forma congruit.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # text directio
    ///
    /// A filum est bytes eas in sequens quadrichordum.
    /// `start` hoc intelligitur per quod primus byte nervisad sinistram-ad-Latina sive rectum, sicut Russian lingua, hoc erit in latere sinistro et dextro ad sinistram-ad-Arabica et Hebraica, sicut linguae, haec erunt in latere dextro.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // UMBRA: `Searcher` est nota redire valet indices.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// A FRUSTUM refert filum cum praepositione dicit remota.
    ///
    /// Et cum incipit quo adoletur incensum `prefix` Quod si filum, post redit substring praepositionis pluribus involuta `Some`.
    /// Secus `trim_start_matches`, hoc removet modum prorsus in prae semel.
    ///
    /// Si filum `prefix` non incipere, `None` refert.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// A FRUSTUM refert filum cum suffixo remota.
    ///
    /// Si filum `suffix` exemplar fines reddit Substring que prius inuolutum `Some`.
    /// Secus `trim_end_matches`, hoc removet modum que prorsus semel.
    ///
    /// Si filum non est terminus `suffix`, `None` refert.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// In linea segmentum suffixes cum omnibus sitis forma refert, quod saepe aequare remotum est.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # text directio
    ///
    /// A filum est bytes eas in sequens quadrichordum.
    /// `end` situm est ultima in hoc byte nervisad sinistram-ad-similis lingua Latina aut Russian rectum, hoc erit in latere dextra et sinistra, in dextra linguae tamquam Arabica et Hebraica, hoc est a sinistra parte.
    ///
    ///
    /// # Examples
    ///
    /// Forma simplex;
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// A more universa forma est usus Agricola;
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // UMBRA: `Searcher` est nota redire valet indices.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Refert filum de frustum ex toto saepe praemittit quae remota forma congruit.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # text directio
    ///
    /// A filum est bytes eas in sequens quadrichordum.
    /// 'Left' quod significatur in hoc primus byte nervisSimiliter in vocabulis Hebraica aut Arabica quae dextra sinistra potius quam relinquenda rectum hoc sit _right_ parte sinistra est.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// In linea segmentum suffixes cum omnibus sitis forma refert, quod saepe aequare remotum est.
    ///
    /// Et [pattern] potest esse `&str`, [`char`], a FRUSTUM [`char`] s, decernit aut munus aut Agricola, qui, si per mores par.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # text directio
    ///
    /// A filum est bytes eas in sequens quadrichordum.
    /// 'Right' In hoc enim significatur ultimus status byte nervislinguae hebraeae sicut nec de Armenia quae ius sinistram potius quam ad dextrum, hoc erit _left_ latus rectum est.
    ///
    ///
    /// # Examples
    ///
    /// Forma simplex;
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// A more universa forma est usus Agricola;
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// In hac linea parses FRUSTUM alterius generis.
    ///
    /// Tam generalis quod `parse`, ut non causa problems in genus inlatione causetur.
    /// Talis est `parse` affectuose ut aliquoties syntaxi 'turbofish' videbis: `::<>`.
    ///
    /// Cras consequentiam scilicet intelligere quod typus es trying ad parse in algorithm.
    ///
    /// `parse` parse possit esse in type quis [`FromStr`] trait ad effectum adducit.
    ///

    /// # Errors
    ///
    /// Et revertetur [`Err`] si suus 'non potest hoc filum parse desideravit genus incidunt.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// basic usus
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Using the 'turbofish' pro annotating `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Numquam mihi animus parse est:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Suspendisse in omnibus litteris in ASCII filum parte.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Byte tractabilis unaquaeque ibi persona, sicut omnes characteres multibyte byte satus cum in ASCII non visibilis, ut ibi ostensum.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// An-ASCII causa minime par est ut checks duobus filis sustinetur.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` quod idem, sed sine temporaries dispertientes et iactat imitari.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Hoc casu superiori aequiparantur convertat corda ASCII locum suum.
    ///
    /// ASCII epistolas ad 'a' 'z' sunt divisi sunt in 'A' 'Z': litterae non-ASCII sed non mutatur.
    ///
    /// Ad revertetur novum valorem uppercased est existentium non moderaretur, uti [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // Salute securus debeat quia eadem genera arcu.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Proselytis hac suum filum in-ASCII equivalent causa inferiore loco.
    ///
    /// ASCII epistolas ad 'A' 'Z' sunt divisi sunt in 'a' 'z': litterae non-ASCII sed non mutatur.
    ///
    /// Ut reverteretur a lowercased pretii est existentium non moderaretur, [`to_ascii_lowercase()`] utuntur.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // Salute securus debeat quia eadem genera arcu.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// In singulis integer iterator `self` cum fugerit [`char::escape_debug`] redire.
    ///
    ///
    /// Note: fili erit latius grapheme codepoints incipiunt euasit.
    ///
    /// # Examples
    ///
    /// Ut in iterator;
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Recta per `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Et qui equivalent ad:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Per `to_string`;
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// In singulis integer [`char::escape_default`] cum fugerit iterator `self` redire.
    ///
    ///
    /// # Examples
    ///
    /// Ut in iterator;
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Recta per `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Et qui equivalent ad:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Per `to_string`;
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// In singulis integer iterator `self` redire in [`char::escape_unicode`] fugient.
    ///
    ///
    /// # Examples
    ///
    /// Ut in iterator;
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Recta per `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Et qui equivalent ad:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Per `to_string`;
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Et gignit vacua subsp
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Ut vacuum str mutabile
    #[inline]
    fn default() -> Self {
        // Salutem et filum in vacua UTF-8 valet.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// A nominabilis, n generis cloneable
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // Utilitatibus consulens, non tutum
        unsafe { from_utf8_unchecked(bytes) }
    };
}