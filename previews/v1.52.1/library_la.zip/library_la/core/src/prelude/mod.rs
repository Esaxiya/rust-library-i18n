//! Et libcore prelude
//!
//! Hoc lacinia magna de users in animo est, ne cuius libcore ad libstd sicut bene.
//! Hic modulus per default quod est importari `#![no_std]` est in eodem modo quod a vexillum scriptor bibliotheca prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Versio in MMXV core prelude.
///
/// Ecce enim in [module-level documentation](self) magis.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Et MMXVIII version of core prelude.
///
/// Ecce enim in [module-level documentation](self) magis.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// The version of core MMXXI prelude.
///
/// Ecce enim in [module-level documentation](self) magis.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Ultra addere rebus.
}