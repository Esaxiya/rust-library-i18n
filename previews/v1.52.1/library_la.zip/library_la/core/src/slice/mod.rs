// ignore-tidy-filelength

//! Scalpere administratione et manipulation.
//!
//! Pro more details videre [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Pura rust memchr implementation, ex rust, memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Et hoc munus publicum tantum est unitas quia non est alius ut test heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Refert in numerus elementa scalpere.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // Confidenter int in longitudinem campi tamquam sanus debeat usize quia (quod est)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // Salutem et `FatPtr<T>` `&[T]` tuta est eadem arcu.
            // Hoc solum potest `std` spondet.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Reponere ad `crate::ptr::metadata(self)` Cum id est firmum, Const.
            // Cum autem inde se per scripturam hanc "Const-stable functions can only call other const-stable functions" errore.
            //

            // Salutem et accessu ad valentiam de `PtrRepr` unio est tutum ab int T *
            // et PtrComponents<T>Home memoriam habere.
            // Tantum hoc vinculum std potest.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Si redit `true` habet longitudinem FRUSTUM 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Refert ad primum elementum secare, aut si `None` vacua remansit.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Refert mutabiliter prima regula ad scalpere de elementum vel si `None` vacua remansit.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Primi elementorum reditus reliquum segmentum vel `None` si vacat.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Primi elementorum reditus reliquum segmentum vel `None` si vacat.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Elementa cetera redit ultimum segmentum vel `None` si vacat.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Elementa cetera redit ultimum segmentum vel `None` si vacat.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Refert ad ultimum segmentum elementum vel si `None` vacua remansit.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Refert mutabiliter item in ultimo regula ad scalpere.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Refert ad elementum, vel ad esse in type of Index subslice fretus.
    ///
    /// - Datum locum remittit aut ad situm `None` elementum nisi ex bono.
    ///
    /// - Datum rhoncus redit subslice rhoncus respondet aut quasi extra modum `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Refert ad commutabile est non elementum subslice fretus in genus indicem (videatur [`get`]) indicem vel `None` si est ex terminis.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Et quod refert ad subslice aut elementum, fines facere, non reprehendo.
    ///
    /// Nam tutam modo [`get`] videre.
    ///
    /// # Safety
    ///
    /// Vox ad modum, cum ex-of-terminis index est *[Finis mores]* etiam si inde non usum referat.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // Confidenter RECENS sustentare debent `get_unchecked` maxime requiruntur ad salutem;
        // segmentum est dereferencable tutum est quia `self` referat.
        // Et incolumem reddidit, quod est regula impls `SliceIndex` est inter gentes prospiciendum est, ut sit.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Refert mutabiliter vel subslice referat ad elementum, fines facere, non reprehendo.
    ///
    /// Nam tutam modo [`get_mut`] videatur.
    ///
    /// # Safety
    ///
    /// Vox ad modum, cum ex-of-terminis index est *[Finis mores]* etiam si inde non usum referat.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // Salutem requiruntur gistrum `get_unchecked_mut` salutem tueri debet;
        // segmentum est dereferencable tutum est quia `self` referat.
        // Et incolumem reddidit, quod est regula impls `SliceIndex` est inter gentes prospiciendum est, ut sit.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Quiddam est scriptor refert fragmen rudis monstratorem.
    ///
    /// Necesse est ut hanc ma gistrum suum segmentum volvens durando munus monstratorem redit, vel aliud demonstrans quod usque in finem, quisquiliarum.
    ///
    /// Et ma gistrum suum necesse est ut numquam scriptum est enim memoria monstratorem (non-transitively) demonstrat (nisi intus in `UnsafeCell`) isve index seu per aliquem ex illa regula.
    /// Si postulo mutate ad contenta in dicto FRUSTUM, uti [`as_mut_ptr`].
    ///
    /// Modifying in quo est ut causa, eius FRUSTUM hac referenced in reallocated quiddam, quod indicium esset nec etiam ad eam ut irritum.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Segmentum scriptor refert in tuta est regula ad commutabile quiddam.
    ///
    /// Necesse est ut hanc ma gistrum suum segmentum volvens durando munus monstratorem redit, vel aliud demonstrans quod usque in finem, quisquiliarum.
    ///
    /// Modifying in quo est ut causa, eius FRUSTUM hac referenced in reallocated quiddam, quod indicium esset nec etiam ad eam ut irritum.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Rudis refert duobus indicibus spanning segmentum.
    ///
    /// Et rediit range media, est apertum, quod modo et regula finis punctorum * * ultimum elementum est praeter unum scalpere.
    /// Ita per uanam secare bifariam argumentis quae et quanta differentia significat indicium scalpere.
    ///
    /// Ecce enim testificatus [`as_ptr`] utendo indicibusque die.Monstratorem extra finis exigit incautum et tamquam ad validum elementum designandum quod non ad scalpere.
    ///
    /// Munere quo utiliter mutuo interfeisi alienis indicibus duobus elementis rhoncus referre memoria ceu C++ .
    ///
    ///
    /// Potest etiam reprehendo utile esse nisi a monstratorem ad elementum elementum huius refers to an frustum:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // Salutem et `add` hic salvus quoniam;
        //
        //   - Indicatores, quae utraque pars refertur ad idem, quod est obiectum et ponit praeteritum recta monstrantem.
        //
        //   - Segmentum placentae magnitudinem non sit maior quam isize::MAX bytes, attendendum est hic:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Non est implicari circa involuti sumus, sicut crustae non involvere praeter extremum spatium oratio.
        //
        // Vide omnibus documentis, prout in pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Redit duo spanning minus securum putavimus, Romane segmentum mutabilem uerteretur.
    ///
    /// Et rediit range media, est apertum, quod modo et regula finis punctorum * * ultimum elementum est praeter unum scalpere.
    /// Ita per uanam secare bifariam argumentis quae et quanta differentia significat indicium scalpere.
    ///
    /// Ecce enim testificatus est [`as_mut_ptr`] utendo indicibusque.
    /// Pointer et finis extra postulat incautum et tamquam ad validum nec elementum designandum ad scalpere.
    ///
    /// Munere quo utiliter mutuo interfeisi alienis indicibus duobus elementis rhoncus referre memoria ceu C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SALUS: See above as_ptr_range() nam cur hie `add` tutum est.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Duo elementa swaps in scalpere.
    ///
    /// # Arguments
    ///
    /// * est, indicem et primi elementum
    /// * b, index Et de secundo elementum
    ///
    /// # Panics
    ///
    /// Aut si Panics `a` `b` ex terminis sunt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // vector duobus mutabilibus, non potest ab uno personas reperiantur, ita uti rudis pro indicibusque.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // Confidenter et `pa` `pb` creata sunt de mobilibus tutum referri scriptorum graecorum et romanorum
        // quapropter ut segmentum elementa stabiliri valeat et amet.
        // Et post `a` utpote elementum accessu `b` extra metas panic voluntas cohibetur.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Adversarumque ex ordine ad secare elementa in locis.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Quia multum parva rationes omnium in singulos normalis iter praestare male legit.
        // We can do better: dedit Unaligned load/store agentibus per oneratisque et maius FRUSTUM de retro actis mandare.
        //

        // Ideally LLVM hoc esset pro nobis, ut sciat bonum est faciatis nos autem agentibus legit Unaligned sive (quod inter mutationes, ut diversis versions BRACHIUM, exempli gratia), atque id optimum FRUSTUM esset magnitudine.
        // Valde dolendum, quod ab LLVM 4.0 (2017-05) non arat in loop solum ut ipsi simus opus hoc.
        // (Hypothesis: molesta est e converso, quia utrimque varius potest aliter-erit, si impar sit longitudo per-sic illic 'nullo modo emittens, de pre-et-postludes ut plene in medio SIMD varius.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Utere llvm.bswap hominibus extrinsecus provenit, in vicissim U8s usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // Salutem reprehendo Sunt plura hic
                //
                // - `chunk` Nota quod aut ex IV vel VIII super cfg reprehendo.`chunk - 1` positivum est ita.
                // - Index `i` loop cum sit pulchrum indexing ut reprehendo polliceri
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Cum indice indexing `ln - i - chunk = ln - (i + chunk)` sit pulchrum,
                //   - `i + chunk > 0` Triviae in modum plantatas est verum.
                //   - Spondent ansa reprehendo;
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, ita subtracta non underflow.
                // - Et `read_unaligned` es bysso et `write_unaligned` vocat;
                //   - `pa` Index `i < ln / 2 - (chunk - 1)` demonstrat `i` in (see above) and index `pb` demonstrat `ln - i - chunk`, ut tam multa sunt, certe `chunk` bytes a fine `self`.
                //
                //   - Initialized memoria ulla valet `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // - By-XVI usus gyrari incipiet regredi in u16s u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // Utilitatibus consulens Unaligned u32 An legere possunt si ab `i` `i + 1 < ln`
                // (Et manifesto `i < ln`), inter se quia sit elementum II IV bytes, et legendi erant.
                //
                // `i + chunk - 1 < ln / 2` # cum conditione,
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Longitudo dividatur illud quo minus II, oportet in infinitum.
                //
                // Haec etiam `0 < i + chunk <= ln` conditio est ut sit semper honestus, tutus esse non potest regula `pb` est cursus.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // Incolumes `i` dimidio minorem ut segmentum
            // accessing `i` et tutum est `ln - i - 1` (`i` incipit ad 0, et non erunt amplius quam `ln / 2 - 1`).
            // `pa` `pb` et inde quod indicium est igitur verum quod varius est, et fieri potest et a lege scriptum est.
            //
            //
            unsafe {
                // Periculum euitare PERMUTO fine salvo PERMUTO reprehendo.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Refert ad scalpere super iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Qui concedit esse iterator refert inter se mutare valorem.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Reversus est omnis iterator contigua windows `size` longitudinis.
    /// Et windows LINO.
    /// Si scalpere brevius `size`, nihil refert ad values iterator.
    ///
    /// # Panics
    ///
    /// Si sit 0 Panics `size`.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Segmentum `size` si brevius;
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// A FRUSTUM iterator in elementis reditur `chunk_size` temporis incipiens a scalpere.
    ///
    /// In chunks sunt crustae et non overlap.Si non dividit `chunk_size` frustum longitudine tum demum extremum non `chunk_size` FRUSTUM.
    ///
    /// Nam videre [`chunks_exact`] permutationis huius iterator quae semper redit prorsus `chunk_size` chunks de elementis, et [`rchunks`] ad idem incipiens, sed in fine segmentum iterator.
    ///
    ///
    /// # Panics
    ///
    /// Si sit 0 Panics `chunk_size`.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// A FRUSTUM iterator in elementis reditur `chunk_size` temporis incipiens a scalpere.
    ///
    /// Et chunks mutabilia diuisa, tum non overlap.Si non dividit `chunk_size` frustum longitudine, non erit longum `chunk_size` FRUSTUM ultimus.
    ///
    /// Vide [`chunks_exact_mut`] ad permutationis huius iterator qui redeunt prorsus `chunk_size` semper chunks de elementis, in eadem iterator [`rchunks_mut`] et incipiens, sed in fine segmentum.
    ///
    ///
    /// # Panics
    ///
    /// Si sit 0 Panics `chunk_size`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// A FRUSTUM iterator in elementis reditur `chunk_size` temporis incipiens a scalpere.
    ///
    /// Et in chunks crustae et non overlap.
    /// Si non dividit `chunk_size` frustum longitudine tum demum omitti potest ad `chunk_size-1` elementorum usu recepta ab `remainder` iterator.
    ///
    ///
    /// Ob inter se prorsus `chunk_size` FRUSTUM habent elementa, et ad optimize compiler saepe potest quam unde bonum apud codice de [`chunks`].
    ///
    /// En huius iterator [`chunks`] permutationis de reliquis etiam ut minores reditus FRUSTUM et [`rchunks_exact`] sed longa post idem segmentum iterator.
    ///
    /// # Panics
    ///
    /// Si sit 0 Panics `chunk_size`.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// A FRUSTUM iterator in elementis reditur `chunk_size` temporis incipiens a scalpere.
    ///
    /// In chunks mutabilia sunt diuisa, tum facere LINO.
    /// Longitudo dividatur `chunk_size` non scalpere Si igitur ad ultima elementa `chunk_size-1` omitti potest ex recepta `into_remainder` iterator munus.
    ///
    ///
    /// Ob prorsus inter se habens `chunk_size` FRUSTUM elementis, non plerumque compiler ad optimize in quam ad melius codice fit ex causa [`chunks_mut`].
    ///
    /// Videte quia variant [`chunks_mut`] reliquum est ut minores reditus FRUSTUM etiam iterator et iterator [`rchunks_exact_mut`] nisi eadem segmentum fine principium.
    ///
    /// # Panics
    ///
    /// Si sit 0 Panics `chunk_size`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Aestifer FRUSTUM de `secare in N`, elementum vestit, si tamen residuum illic 'nulla.
    ///
    ///
    /// # Safety
    ///
    /// Et hoc potest esse nisi quando dicitur
    /// - Segmentum bipartito finditur, N`elementum`prorsus in chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // Utilitatibus consulens I-residuum elementum chunks non habent
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // Utilitatibus consulens (6) est multa de longitudo III Segmentum
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Haec non possumus insaniam vocare:
    /// // et chunks,&[[_;V]]//= slice.as_chunks_unchecked() longitudinem OBFULA et non plures ex puncto V chunks,&[[_;0]]=//slice.as_chunks_unchecked()-Nulla sunt non conceditur longitudo chunks
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // Salute nostra praevia opus est prorsus, ut quod suus 'hanc
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // Salutem et nos Segmentum placentae mittet in circuitu eius sunt in elementis `new_len * N`
        // Segmentum placentae `new_len` multa elementa `N` chunks.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Segmentum, incidunt: scindit elementum N` vestit, et incipiens scalpere et reliquum segmentum minus proprie `N` longitudine.
    ///
    ///
    /// # Panics
    ///
    /// 0. hoc `N` Panics si mutavit reprehendo et adepto maxime verisimile ad tempus error in conspectu compile hac methodo sudatio, stabiliuntur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SALUS, iam nos pro dammae trepidant nulla, et ut in constructione
        // quod multiplex est longitudo N. subslice
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Aestifer N` incidunt: segmentum vestit, elementum incipiens fine segmentum et reliquum segmentum minus proprie `N` longitudine.
    ///
    ///
    /// # Panics
    ///
    /// 0. hoc `N` Panics si mutavit reprehendo et adepto maxime verisimile ad tempus error in conspectu compile hac methodo sudatio, stabiliuntur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SALUS, iam nos pro dammae trepidant nulla, et ut in constructione
        // quod multiplex est longitudo N. subslice
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// A FRUSTUM iterator in elementis reditur `N` tempore incipiens per scalpere.
    ///
    /// Non sunt ordinata scriptorum Graecorum et Romanorum chunks de LINO.
    /// Si longitudo dividatur `N` non scalpere, ultimus omitti potest ad `N-1` elementorum usu recepta ab `remainder` iterator.
    ///
    ///
    /// Hoc genus modum sit equivalent of [`chunks_exact`] Const.
    ///
    /// # Panics
    ///
    /// 0. hoc `N` Panics si mutavit reprehendo et adepto maxime verisimile ad tempus error in conspectu compile hac methodo sudatio, stabiliuntur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Aestifer FRUSTUM de `secare in N`, elementum vestit, si tamen residuum illic 'nulla.
    ///
    ///
    /// # Safety
    ///
    /// Et hoc potest esse nisi quando dicitur
    /// - Segmentum bipartito finditur, N`elementum`prorsus in chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // Utilitatibus consulens I-residuum elementum chunks non habent
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // Utilitatibus consulens (6) est multa de longitudo III Segmentum
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Haec non possumus insaniam vocare:
    /// // et chunks,&[[_;V]] slice.as_chunks_unchecked_mut()//=puncto V Segmentum longitudinem non plures ex chunks,&[[_;0]]= slice.as_chunks_unchecked_mut()//longitudo chunks quae numquam licere Zero-
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // Salute nostra praevia opus est prorsus, ut quod suus 'hanc
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // Salutem et nos Segmentum placentae mittet in circuitu eius sunt in elementis `new_len * N`
        // Segmentum placentae `new_len` multa elementa `N` chunks.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Segmentum, incidunt: scindit elementum N` vestit, et incipiens scalpere et reliquum segmentum minus proprie `N` longitudine.
    ///
    ///
    /// # Panics
    ///
    /// 0. hoc `N` Panics si mutavit reprehendo et adepto maxime verisimile ad tempus error in conspectu compile hac methodo sudatio, stabiliuntur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SALUS, iam nos pro dammae trepidant nulla, et ut in constructione
        // quod multiplex est longitudo N. subslice
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Aestifer N` incidunt: segmentum vestit, elementum incipiens fine segmentum et reliquum segmentum minus proprie `N` longitudine.
    ///
    ///
    /// # Panics
    ///
    /// 0. hoc `N` Panics si mutavit reprehendo et adepto maxime verisimile ad tempus error in conspectu compile hac methodo sudatio, stabiliuntur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SALUS, iam nos pro dammae trepidant nulla, et ut in constructione
        // quod multiplex est longitudo N. subslice
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// A FRUSTUM iterator in elementis reditur `N` tempore incipiens per scalpere.
    ///
    /// Chunks mutabilia sunt et ordinata faciunt scriptorum Graecorum et Romanorum LINO.
    /// Longitudo dividatur nisi `N` non scalpere, ultimus omitti potest ad `N-1` elementorum usu recepta ab `into_remainder` iterator.
    ///
    ///
    /// Hoc est modum equivalent de genere [`chunks_exact_mut`] Const.
    ///
    /// # Panics
    ///
    /// 0. hoc `N` Panics si mutavit reprehendo et adepto maxime verisimile ad tempus error in conspectu compile hac methodo sudatio, stabiliuntur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Et super iterator refert imbricatis windows ex elementis `N` Segmentum placentae, incipiens a principium ad scalpere.
    ///
    ///
    /// Hoc equivalent de genere [`windows`] Const.
    ///
    /// Si `N` maius est quam a mole FRUSTUM, sic revertetur et nihil windows.
    ///
    /// # Panics
    ///
    /// Si sit 0 Panics `N`.
    /// Hoc mutavit reprehendo in ad adepto verisimillimum compile ante hoc tempus error methodo sudatio, stabiliuntur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Redit ad iterator FRUSTUM de `chunk_size` elementis temporis segmentum fine principium.
    ///
    /// In chunks sunt crustae et non overlap.Si non dividit `chunk_size` frustum longitudine tum demum extremum non `chunk_size` FRUSTUM.
    ///
    /// Vide [`rchunks_exact`] ad permutationis huius iterator, quae semper redit chunks de elementis `chunk_size` exacte et pro eodem [`chunks`] iterator et incipiens a principium ad scalpere.
    ///
    ///
    /// # Panics
    ///
    /// Si sit 0 Panics `chunk_size`.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Redit ad iterator FRUSTUM de `chunk_size` elementis temporis segmentum fine principium.
    ///
    /// Et chunks mutabilia diuisa, tum non overlap.Si non dividit `chunk_size` frustum longitudine, non erit longum `chunk_size` FRUSTUM ultimus.
    ///
    /// Ecce [`rchunks_exact_mut`] semper chunks de redit ad illam permutationis huius iterator prorsus `chunk_size` elementa, et ad [`chunks_mut`] iterator sed etiam incipiens ad principium scalpere.
    ///
    ///
    /// # Panics
    ///
    /// Si sit 0 Panics `chunk_size`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Redit ad iterator FRUSTUM de `chunk_size` elementis temporis segmentum fine principium.
    ///
    /// Et in chunks crustae et non overlap.
    /// Si non dividit `chunk_size` frustum longitudine tum demum omitti potest ad `chunk_size-1` elementorum usu recepta ab `remainder` iterator.
    ///
    /// Ob inter se prorsus `chunk_size` FRUSTUM habent elementa, et ad optimize compiler saepe potest quam unde bonum apud codice de [`chunks`].
    ///
    /// Nam iterator [`rchunks`] variam quoque videndum est ut reliquas minores reditus FRUSTUM et incipiens a [`chunks_exact`] sed iterator idem segmentum.
    ///
    ///
    /// # Panics
    ///
    /// Si sit 0 Panics `chunk_size`.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Redit ad iterator FRUSTUM de `chunk_size` elementis temporis segmentum fine principium.
    ///
    /// In chunks mutabilia sunt diuisa, tum facere LINO.
    /// Longitudo dividatur `chunk_size` non scalpere Si igitur ad ultima elementa `chunk_size-1` omitti potest ex recepta `into_remainder` iterator munus.
    ///
    /// Ob prorsus inter se habens `chunk_size` FRUSTUM elementis, non plerumque compiler ad optimize in quam ad melius codice fit ex causa [`chunks_mut`].
    ///
    /// Vide etiam refert iterator [`rchunks_mut`] reliquum hujus permutationis pro minori quam FRUSTUM et eadem [`chunks_exact_mut`] iterator et incipiens a scalpere.
    ///
    ///
    /// # Panics
    ///
    /// Si sit 0 Panics `chunk_size`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Iterator esse refert in producendo OBFULA per elementa non-imbricatis autem fugit, quia praedicatum est separare.
    ///
    /// Sequentibus duabus se praedicatum dicitur, et ideo praedicatum dicitur `slice[0]` `slice[1]` `slice[2]` et sic deinceps `slice[1]`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eliciunt haec methodus possit adhiberi, ut in coetibus territorialibus subslices:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// FRUSTUM in producendo non-esse refert iterator imbricatis elementa mutabilia et fugit per praedicatum ad separate illos.
    ///
    /// Sequentibus duabus se praedicatum dicitur, et ideo praedicatum dicitur `slice[0]` `slice[1]` `slice[2]` et sic deinceps `slice[1]`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eliciunt haec methodus possit adhiberi, ut in coetibus territorialibus subslices:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Dividit enim duae incidunt indice.
    ///
    /// Primum Ex `[0, mid)` autem continent omnes indices (praeter indicem ipsum `mid`) et secundum non habet indices ab omni `[mid, len)` (exclusa in `len` se indicem).
    ///
    ///
    /// # Panics
    ///
    /// Si Panics `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // Utilitatibus consulens, et `[ptr; mid]` `[mid; len]` `self` sunt intra quam
        // perficit postulata `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Mutabilia dividit inter duas indice incidunt.
    ///
    /// Primum Ex `[0, mid)` autem continent omnes indices (praeter indicem ipsum `mid`) et secundum non habet indices ab omni `[mid, len)` (exclusa in `len` se indicem).
    ///
    ///
    /// # Panics
    ///
    /// Si Panics `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // Utilitatibus consulens, et `[ptr; mid]` `[mid; len]` `self` sunt intra quam
        // perficit postulata `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Duobus autem incidunt dividit indice tenendo sine termino.
    ///
    /// Primum Ex `[0, mid)` autem continent omnes indices (praeter indicem ipsum `mid`) et secundum non habet indices ab omni `[mid, len)` (exclusa in `len` se indicem).
    ///
    ///
    /// Nam tutam [`split_at`] modo video.
    ///
    /// # Safety
    ///
    /// Vox-de modum, cum ex terminis est index *[undefined mores]* etiam si inde non usum referat.In RECENS habet ut `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SALUS: Caller habet ut reprehendo `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Dividit enim duae incidunt mutabilis indice quippe sine fine.
    ///
    /// Primum Ex `[0, mid)` autem continent omnes indices (praeter indicem ipsum `mid`) et secundum non habet indices ab omni `[mid, len)` (exclusa in `len` se indicem).
    ///
    ///
    /// Nam videte aliter tutam [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Vox-de modum, cum ex terminis est index *[undefined mores]* etiam si inde non usum referat.In RECENS habet ut `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // Utilitatibus consulens Caller ad reprehendo quod habeat `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` et non imbricatis `[mid; len]`, ut referat reversus est bene mutabilis.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Redit ad subslices iterator super elementa separata `pred` iste componere.
    /// Matched elementum quod est minus inclusi, a subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si primum elementum matched est, quod vacua erit scalpere primum item rediit in iterator.
    /// Et eodem modo si ad segmentum ultimum elementum sit comparatus, vel per vacua erit segmentum ultimum item per iterator rediit:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Item si duo elementa proxima prorsus inane segmentum medium aderit;
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Iterator recurrit ad commutabile subslices separari ab elementis, quae super `pred` congruit.
    /// Matched elementum quod est minus inclusi, a subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Redit ad subslices iterator super elementa separata `pred` iste componere.
    /// Et matched ultimum elementum est in subslice prior sicut in Termino.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si elementum ultimum segmentum respondet ad id elementum et considerandum est de Termino preceding scalpere.
    ///
    /// Hoc autem scalpere sit per ultimum item rediit iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Iterator recurrit ad commutabile subslices separari ab elementis, quae super `pred` congruit.
    /// Matched elementum et, quae in priorem subslice sicut Termino.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Reversus est super iterator subslices aequis partes divisae `pred` incipiens retro fine segmentum laboris.
    /// Matched elementum quod est minus inclusi, a subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ut apud `split()` si primo seu ultimum elementum est comparatus, vel per vacua erit scalpere primum (sive ultimo), item si ab iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Redit et mutabilium iterator subslices `pred` aequis partes divisa, initio et fine segmentum retrogrediendo.
    /// Matched elementum quod est minus inclusi, a subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Redit ad subslices super iterator separari ab elementis, ut par `pred`, limited reversus est ad `n` maxime items.
    /// Matched elementum quod est minus inclusi, a subslices.
    ///
    /// Elementum rediit ultima; si aliqua, non habet de reliquo scalpere.
    ///
    /// # Examples
    ///
    /// Print segmentum split simul divisibile per numeros III (id est, `[10, 40]`, `[20, 60, 50]`)
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Redit ad subslices super iterator separari ab elementis, ut par `pred`, limited reversus est ad `n` maxime items.
    /// Matched elementum quod est minus inclusi, a subslices.
    ///
    /// Elementum rediit ultima; si aliqua, non habet de reliquo scalpere.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Redit ad iterator super subslices elementa separata ut par est reversus ad `pred` limited `n` maxime items.
    /// Segmentum retro post opera incipientibus.
    /// Matched elementum quod est minus inclusi, a subslices.
    ///
    /// Elementum rediit ultima; si aliqua, non habet de reliquo scalpere.
    ///
    /// # Examples
    ///
    /// Segmentum placentae split imprimendi semel, illius a termino A, a numerus divisibilis III (id est, `[50]`, `[10, 40, 30, 20]`)
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Redit ad iterator super subslices elementa separata ut par est reversus ad `pred` limited `n` maxime items.
    /// Segmentum retro post opera incipientibus.
    /// Matched elementum quod est minus inclusi, a subslices.
    ///
    /// Elementum rediit ultima; si aliqua, non habet de reliquo scalpere.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Si scalpere `true` refert ad valorem datum est cum elementum continet.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Si non est `&T` et justum est `&U` ita ut `T: Borrow<U>` (eg
    /// : Gloria: Borrow<str>`), Vos can utor `iter().any`;
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // Segmentum placentae `String`
    /// assert!(v.iter().any(|e| e == "hello")); // cum `&str` quaerere
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Si de re praepositione negationis `true` refert `needle` est scalpere.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Revertetur vacua `needle` `true` si semper secare;
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Si redit `true` `needle`, etiamne hoc segmentum.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Revertetur vacua `needle` `true` si semper secare;
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Quae praeposita est subslice refert remota sunt.
    ///
    /// Si scalpere incipit cum `prefix`, subslice cum refert ad praepositionis pluribus involuta `Some`.
    /// Si `prefix` inanis tantum originali refert in scalpere.
    ///
    /// Si scalpere `prefix` non satus, `None` refert.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Hoc munus et si necesse rewriting magis sophisticated quod fit SlicePattern.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Refert ad extrema illa partícula a subslice remotum est.
    ///
    /// Si scalpere fines `suffix` redit subslice que prius inuolutum `Some`.
    /// Si `suffix` inanis tantum refert autem originale scalpere.
    ///
    /// Si scalpere non est terminus `suffix`, `None` refert.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Hoc munus et si necesse rewriting magis sophisticated quod fit SlicePattern.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Hoc binarii sorted scrutatur scalpere data est elementum.
    ///
    /// Si ergo inveni [`Result::Ok`] est rediit pretii est, qui continentur in indice matching elementum.
    /// Si par plures autem reddi par quisquam.
    /// Si igitur [`Result::Err`] valorem non est inventus qui rediret, in qua continentur in indice elementum per matching eam immitti possit servato ordine sorted.
    ///
    ///
    /// Vide etiam [`binary_search_by`], [`binary_search_by_key`] et [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Suspicit elementorum seriem.
    /// Primo invenitur singulariter proposuerunt in locumsecundam&non invenieturQuarta loca `[1, 4]` aequiparare potuit.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Item si vis ad inserere et coetibus territorialibus vector, quamquam in ordine generis;
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Searches hoc segmentum cum binarii coetibus territorialibus comparatur munus.
    ///
    /// Comparatur ad munus ordinem cum priore posterius cohaerere debet effectum deducendi ordine generis subjectam FRUSTUM, reversus est ut ejus ratio est, sive signum, quod indicat `Less`, `Equal` vel desideravit `Greater` ad scopum.
    ///
    ///
    /// Si ergo valorem [`Result::Ok`] est inventus est rediit, in quibus cum indice matching elementum.Si plures par et una reddi par.
    /// Si igitur [`Result::Err`] valorem non est inventus qui rediret, in qua continentur in indice elementum per matching eam immitti possit servato ordine sorted.
    ///
    /// [`binary_search`] Vide etiam: [`binary_search_by_key`] et [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Suspicit elementorum ordinem.Prima est, cum unice positione determinata;invenitur secundi et tertii;loca `[1, 4]` quarta aequiparare potuit.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // Consulens vocationem salva invariants sequentia:
            // - `mid >= 0`
            // - `mid < size`: `mid` finitur `[left; right)` tenetur.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Quam par imperium influit causa utimur if/else reorders par est respectu operationum sensitivarum quo perf.
            //
            // Hoc x86 hibitisque u8; https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Hoc binarii searches coetibus territorialibus FRUSTUM de a key munus extraction.
    ///
    /// Ponit enim segmentum coetibus key, exempli gratia apud eundem, uti [`sort_by_key`] extraction key munus.
    ///
    /// Si ergo inveni [`Result::Ok`] est rediit pretii est, qui continentur in indice matching elementum.
    /// Si par plures autem reddi par quisquam.
    /// Si igitur [`Result::Err`] valorem non est inventus qui rediret, in qua continentur in indice elementum per matching eam immitti possit servato ordine sorted.
    ///
    ///
    /// Vide etiam [`binary_search`], [`binary_search_by`] et [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// In seriem suspicit scalpere paria quatuor elementa coetibus secundo.
    /// Primo invenitur singulariter proposuerunt in locumsecundam&non invenieturQuarta loca `[1, 4]` aequiparare potuit.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links conceditur ut in `slice::sort_by_key` crate `alloc`, et quod talis non existit in aedificationem tamen `core`.
    //
    // ut sunt decurrent atque conjungit crate: #74481.Cum rudes tantum comprobatum libstd (#73423) hoc nunquam usu et fractos.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Generis secare et partes eiusdem ordinis non servat.
    ///
    /// Hic obvenit instabile est generis (id est, reorder sint elementa pari) in loco, (id est, non deducendae agroque diuidundo), et *o*(*n*\*log(* n*)) pessimus-casu.
    ///
    /// # Current implementation
    ///
    /// In current [pattern-defeating quicksort][pdqsort] algorithm a Orson Petrum fundatur insunt, quae putant ieiunium si mediocris est cum ieiunium randomized quicksort de heapsort Maxime in re, cum tempus achieving in crustae per lineae quaedam exempla.
    /// Non randomization utitur aliqua casibus vitare pravum, et certa semper providere deterministic mores seed.
    ///
    /// Velocius voluptua stabilis est nulla nisi in paucis casibus, puta cum pluribus segmentum catenata series sorted.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Segmentum perplura cum comparatur, verum non servet ordinem elementorum aequis.
    ///
    /// Hic obvenit instabile est generis (id est, reorder sint elementa pari) in loco, (id est, non deducendae agroque diuidundo), et *o*(*n*\*log(* n*)) pessimus-casu.
    ///
    /// Comparator propter quod elementa sunt in munus ordinatione est summa define scalpere.Si non est summa ratio, ordo est in elementis etc.A totalis ordinem, si ordo non est (nam omnis `a`, et `b` `c`)
    ///
    /// * et summa antisymmetric: `a < b` prorsus unum, `a == b` `a > b` et verum est, et
    /// * transi, et `a < b` `b < c` `a < c` importat.Nam et tenenda eisdem `==` `>`.
    ///
    /// Exempli gratia dum [`f64`] non `NaN != NaN` effectum deducendi [`Ord`] quod, sicut nos nostri generis munus uti `partial_cmp` cum scire FRUSTUM non continet in `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Current implementation
    ///
    /// In current [pattern-defeating quicksort][pdqsort] algorithm a Orson Petrum fundatur insunt, quae putant ieiunium si mediocris est cum ieiunium randomized quicksort de heapsort Maxime in re, cum tempus achieving in crustae per lineae quaedam exempla.
    /// Non randomization utitur aliqua casibus vitare pravum, et certa semper providere deterministic mores seed.
    ///
    /// Velocius voluptua stabilis est nulla nisi in paucis casibus, puta cum pluribus segmentum catenata series sorted.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // diribitio e converso,
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Segmentum clavem extractionem generis actum non servet ordinem elementa aequalia nisi.
    ///
    /// Huiusmodi inconstans (id, ut reorder aequalis elementis) in-place (id est, non deducendae agroque), et *Domine*(m\* * n *\* log(*n*)) pessimi, casu quo key munus est *o*(*m*).
    ///
    /// # Current implementation
    ///
    /// In current [pattern-defeating quicksort][pdqsort] algorithm a Orson Petrum fundatur insunt, quae putant ieiunium si mediocris est cum ieiunium randomized quicksort de heapsort Maxime in re, cum tempus achieving in crustae per lineae quaedam exempla.
    /// Non randomization utitur aliqua casibus vitare pravum, et certa semper providere deterministic mores seed.
    ///
    /// Ob key eius vocatio belli, [`sort_unstable_by_key`](#method.sort_unstable_by_key) est verisimile ad esse tardius quam [`sort_by_cached_key`](#method.sort_by_cached_key) key munus in casibus ubi est pretiosa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Segmentum Reorder, quod tale elementum in sorted `index` ultima, est in suo loco.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Reorder segmentum cum comparator ad sua ultima est agere talia, quae elementum in sorted `index` situ.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Segmentum placentae in reordinatque a key munus extraction ita ut elementum in sorted `index` est ad ultima ejus statum.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Segmentum Reorder, quod tale elementum in sorted `index` ultima, est in suo loco.
    ///
    /// Haec enim etiam bonis reordering aliquo situ `i < index` minor vel aequalis in honore aliquo `j > index`.
    /// Praeterea, hoc enim refectio instabiles (ANTOECUMENE
    /// pari quotcumque situ partium `index` fine) in loco (id
    /// Non placeat), and *O*(* * n) pessimus-casu.
    /// Hoc munus quod etiam/quae in aliis "kth element" libraries.
    /// Trigemini values sequenti sic refert: omnia elementa minus est quam dederat in indice ad valorem datum cum indice et in omnibus elementis datis maior quam unum ad indicem.
    ///
    ///
    /// # Current implementation
    ///
    /// Algorithm est fundatur in current quickselect de eodem usus est pro [`sort_unstable`] quicksort algorithm.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Cum Panics `index >= len()`, id semper in panics inanis purus.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Reperio media
    /// v.select_nth_unstable(2);
    ///
    /// // Nos autem fides nisi una segmentum erit quae sequuntur, secundum modo quo tale quid statis indice.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reorder segmentum cum comparator ad sua ultima est agere talia, quae elementum in sorted `index` situ.
    ///
    /// Hoc est sub proprietate ut quod alicuius esset preti enim refectio `i < index` situ erit aut minus quam par sit ad statum ad valorem `j > index` uti comparator ad munus.
    /// Item vanum est quod est reordering (id elementa aliquo numero sit aequalis terminus sursum in loco `index`), in-place (id est, non deducendae agroque diuidundo), et *o*(*n*) pessimus-casu.
    /// Etiam hoc munus est quae in aliis "kth element" libraries.
    /// Refert ad illam sextus ter geminos sequitur artificiales exhibere: omnia elementa minus est quam dederat in indice ad valorem index ad dedit, et omnibus elementis datis maior quam unum ad indice uti comparator ad munus provisum.
    ///
    ///
    /// # Current implementation
    ///
    /// Algorithm est fundatur in current quickselect de eodem usus est pro [`sort_unstable`] quicksort algorithm.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Cum Panics `index >= len()`, id semper in panics inanis purus.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Mediana autem scalpere si invenero descendendo fringilla.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Nos autem fides nisi una segmentum erit quae sequuntur, secundum modo quo tale quid statis indice.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Segmentum placentae in reordinatque a key munus extraction ita ut elementum in sorted `index` est ad ultima ejus statum.
    ///
    /// Haec est enim refectio sub proprietate, ut in omni loco `i < index` valorem fore valorem minus quam vel aequalis ad nulla ad statum `j > index` extraction key munus in usus.
    /// Item vanum est quod est reordering (id elementa aliquo numero sit aequalis terminus sursum in loco `index`), in-place (id est, non deducendae agroque diuidundo), et *o*(*n*) pessimus-casu.
    /// Etiam hoc munus est quae in aliis "kth element" libraries.
    /// Non refert sequentibus values erant trigemini, omnia elementa minus est quam dederat in indice ad valorem index ad dedit, et omnibus elementis data est maius quam una cum indice usura a clavem extraction provisum munus.
    ///
    ///
    /// # Current implementation
    ///
    /// Algorithm est fundatur in current quickselect de eodem usus est pro [`sort_unstable`] quicksort algorithm.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Cum Panics `index >= len()`, id semper in panics inanis purus.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Sicut in media ordinata revertere sunt sorted secundum valorem absolutum.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Nos autem fides nisi una segmentum erit quae sequuntur, secundum modo quo tale quid statis indice.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Segmentum ultimum crebris continuos movet elementis secundum [`PartialEq`] trait turpis.
    ///
    ///
    /// Duo segmenta refert.Primum continet non continuati iterum elementa.
    /// Secundum ad effingo continet omnes nullo certo ordine.
    ///
    /// Si fragmen obicitur: primus continet non effingo rediit scalpere.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Primus omnium elementorum motus continuos satis dato aequale segmentum secundum finem.
    ///
    /// Duo segmenta refert.Primum continet non continuati iterum elementa.
    /// Secundum ad effingo continet omnes nullo certo ordine.
    ///
    /// Et transivit munus `same_bucket` Greek segmentum principiis ac duobus utrum elementa paria comparabimus.
    /// Lata contra ordinem elementorum in ordinis secare, si `same_bucket(a, b)` `true` revertitur, movetur `a` fine segmentum.
    ///
    ///
    /// Si fragmen obicitur: primus continet non effingo rediit scalpere.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Licet habemus ad `self` posterius mutari potest, non possumus facere arbitrium * * mutationes.Et vocat `same_bucket` poterat panic, ut nos in valida civitate ut segmentum in omni tempore.
        //
        // Et ita tractamus, ut utendo swaps, hoc est,Nos RESUMO omnium elementorum pergentibus permutando vt elementorum uolumus fine custodiunt in fronte et postico rejicient volumus.
        // Non potest ergo segmentum Scinditur.
        // Haec operatio, est tamen `O(n)`.
        //
        // Exempli gratia: Nos satus in hoc statu, in quo `r` represents "iuxta
        // legere ', et significat `w` "next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Adversus se comparet self[r] [I W], hoc non esse duplicatam, ita et nos PERMUTO self[r] self[w] (quod nullus effectus r==Latin) et erit tam incremento r et u, relinquens nobis:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] contra comparet se [I Latin-], id est valorem duplici exemplari non est nisi incremento `r` valedixit quae caeteris non mutatis:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // In comparet self[r] sui [n-I], hoc non esse duplicatam, et VERTO self[r] et self[w] et antecessum et w r:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Non est duplici exemplari imperat
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplici exemplari advance r. End a scalpere.Scinditur in vv.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // Salutem et in tuto collocat `while` conditione `next_read` et `next_write`
        // minus `len` sic `self` intus.
        // `prev_ptr_write` unum elementum in conspectu `ptr_write` demonstrat, sed in I `next_write` animi ut numquam minus quam `prev_ptr_write` est intra 0 et scalpere.
        // De necessariis ad vitam dereferencing ut impleatur `ptr_read`, et `prev_ptr_write` `ptr_write` et per `ptr.add(next_read)`, et `ptr.add(next_write - 1)` `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` etiam plus semel sit in z per loop elementum nulla at potissimum hoc est opus, ut illud omittendum est swapped.
        //
        // `ptr_read` et non `prev_ptr_write` quae ad idem elementum.Hoc `&mut *ptr_read` requisiti, `&mut* prev_ptr_write` ad esse tutum.
        // Et ratio est quia tantum `next_read >= next_write` semper est verus, ita `next_read > next_write - 1` est.
        //
        //
        //
        //
        //
        unsafe {
            // Vitare utendo terminis checks rudis indicibusque.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Ex continuis omnium movet et primis elementis usque ad ultimum segmentum consilium, quod clavis ad idem.
    ///
    ///
    /// Duo segmenta refert.Primum continet non continuati iterum elementa.
    /// Secundum ad effingo continet omnes nullo certo ordine.
    ///
    /// Si fragmen obicitur: primus continet non effingo rediit scalpere.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Segmentum primum in gyretur `mid` locum elementa motus segmentum ultimum finem `self.len() - mid` elementa moveri ante tempus.
    /// Tunc pater vocato `rotate_left`, fiet elementum `mid` Index antea ad primum elementum in scalpere.
    ///
    /// # Panics
    ///
    /// Si hoc panic functio `mid` maius segmentum longitudo.Nota ut `mid == self.len()` _not_ panic et non est ultra-op vicissitudine sortiri iubet.
    ///
    /// # Complexity
    ///
    /// Tollit lineari (`self.len()`) in tempore.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Rotating subslice est:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // Confidenter modice sit iuga `[p.add(mid) - mid, p.add(mid) + k)`
        // valet ad legendi et scribendi: in `ptr_rotate` Quod erat faciendum.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Locum in gyretur primum `self.len() - k` segmentum segmentum elementa elementorum motum movet finis priori `k` ante.
    /// Vocato `rotate_right`, elementum at antea `self.len() - k` Index facti erit primum elementum in scalpere.
    ///
    /// # Panics
    ///
    /// Si autem hac panic `k` segmentum maius spatium.Nota quod `k == self.len()` panic et non _not_-op est, nihil vicissitudine sortiri iubet.
    ///
    /// # Complexity
    ///
    /// Tollit lineari (`self.len()`) in tempore.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Rotata ad subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // Confidenter modice sit iuga `[p.add(mid) - mid, p.add(mid) + k)`
        // valet ad legendi et scribendi: in `ptr_rotate` Quod erat faciendum.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `self` ab elementis cloning `value` et implet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Cum Agricola `self` implet elementa saepe enim redierat ab vocant.
    ///
    /// Haec methodus utitur Agricola creare novum animationem.Si Curabitur data est magis [`Clone`] valorem, uti [`fill`].
    /// Si vos volo utor usque generate [`Default`] trait values potes [`Default::default`] transiet sicut argumentum.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Idea enim ab elementis `src` in `self`.
    ///
    /// Idem est longitudo `src` `self`.
    ///
    /// Si `T` effectum adducit `Copy`, illud potest esse magis performant ut [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// panic hoc munus et si sunt duo crustae disparibus.
    ///
    /// # Examples
    ///
    /// Cloning, in Segmentum placentae duo elementa ab alia;
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Quod pares esse purus, non scalpere caput scalpere duo de quatuor elementis.
    /// // Hoc si non feceris tibi panic.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust commendat potest esse nisi unum, quod nihil referat mutabilium immutabiles references to a piece of notitia maxime in maxime scope.
    /// Quia ex hoc conanti `clone_from_slice` uti ad unum scalpere et compile consequuntur per defectum;
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ut operi circum hoc non possumus uti ad creandum [`split_at_mut`] duo distincta a sub-segmentis Segmentum placentae;
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Idea de elementis `src` in omnibus `self`, memcpy usus.
    ///
    /// Idem est longitudo `src` `self`.
    ///
    /// Si non `T` effectum deducendi `Copy` utere [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// panic hoc munus et si sunt duo crustae disparibus.
    ///
    /// # Examples
    ///
    /// Effingo duo elementa a FRUSTUM in aliam;
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Quod pares esse purus, non scalpere caput scalpere duo de quatuor elementis.
    /// // Hoc si non feceris tibi panic.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust commendat potest esse nisi unum, quod nihil referat mutabilium immutabiles references to a piece of notitia maxime in maxime scope.
    /// Propter hoc `copy_from_slice` super unum scalpere conanti ad defectum mos praecessi in compile:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ut operi circum hoc non possumus uti ad creandum [`split_at_mut`] duo distincta a sub-segmentis Segmentum placentae;
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // In codice panic non bloat iter vocant locum spectat in frigore.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // Utilitatibus consulens `self` valet ad `self.len()` ab elementis definitione, et quod `src`
        // idem repressit longitudine.
        // Segmentis aliudque quia non spectant ad commutabile exclusive.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Idea partem unam scalpere de elementis partem alteri se, memmove usus.
    ///
    /// `src` ab intra teli `self` est imitari.
    /// `dest` principium est in monte `self` exscribere indicem illi qui habent longitudinem `src`.
    /// Duo septum templi potest aliudque.
    /// Minus est duobus extremis iugis `self.len()` paribus.
    ///
    /// # Panics
    ///
    /// Sive quod panic functio finis excedit FRUSTUM rhoncus vel `src` finis est principium.
    ///
    ///
    /// # Examples
    ///
    /// Segmentum bytes in describendo quatuor:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // Salutem conditiones omnes `ptr::copy` repressum supra
        // ut non ea pro `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Per omnia elementa cum strigili `self` `other`.
    ///
    /// Idem esse `self` `other` longitudine.
    ///
    /// # Panics
    ///
    /// panic hoc munus et si sunt duo crustae disparibus.
    ///
    /// # Example
    ///
    /// Crustae per duo elementa permutando;
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust non solum sancit, quod non sit mutabile est ad certo fragmen notitia in certo scope.
    ///
    /// Propter hoc `swap_with_slice` conanti utor super unum scalpere et consequuntur in compile defectum;
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Ad opus circa hoc duo distincta mutari non potest [`split_at_mut`] creare a sub-segmentis Segmentum placentae;
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // Utilitatibus consulens `self` valet ad `self.len()` ab elementis definitione, et quod `src`
        // idem repressit longitudine.
        // Segmentis aliudque quia non spectant ad commutabile exclusive.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Segmentum fluidumque est muneris ratio longitudinum `align_to{,_mut}` medium.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Quid autem est figure `rest` laudibus? Circa quae multa non possumus falsi U`s in numero est ultimum ejus, quod`T`s.
        //
        // Et quot per talia quae opus sunt nobis: T`s "multiple".
        //
        // Exempli gratia T U==considerans u8 U16.Et posuit possumus I in U T II.Simplex.
        // Nunc, consideramus exempli causa de qua: : size_of<T>=XVI, size_of::<U>=XXIV.</u>
        // II possumus Nobis posuit in loco omnis T III Segmentum placentae in `rest`.
        // A frenum magis turpis.
        //
        // Formula, calculari est;
        //
        // Nos lcm(size_of::<T>, size_of::<U>) =/<U>=</u> size_of: : <U>T lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Diffusa et simplicior:
        //
        // Nos size_of: :=<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Fortunate, quia omnibus his est constant ... aestimare perficientur quicquam facit hic?
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // oportet nos tamen hoc algorithm est adipisicing stein `const fn` (revertatur, et si nos algorithm ad facere recursive) freti quod llvm consteval ut omnia bene ... id est, me et incommoda.
            //
            //

            // Utilitatibus consulens et `a` non-nulla `b` esse non sedatus animationem.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // omnes erunt factores removere a b II
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // Utilitatibus consulens `b` refrenatur non-nulla est.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Armari scientia U`s possumus: possumus quanta fit!
        let us_len = self.len() / ts * us;
        // Et erit in trailing T`s quot`secare!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Eiusdem est transmutare ad segmentum segmentum genus alia, quae dicuntur vita types cursus membrorum dispositione sub vestibus.
    ///
    /// Hoc tribus distincta peragitato in modum scindit Segmentum placentae: praepositionem FRUSTUM de medio varius bene novi generis atque extrema illa partícula scalpere.
    /// Modo possit facere aliquod medium secare copiosissime input type scalpere sed scriptor algorithm vobis constet quod non recte.
    ///
    /// Licet omnibus notitia ut rediit ad initus que quae praeposita vel scalpere.
    ///
    /// Modum neque rem in hanc aut non habet input vel output `T` elementum elementum nullus est-amplitudo et `U` redabit ad illas sine originali aliquid scalpere.
    ///
    /// # Safety
    ///
    /// Essentialiter `transmute` modus secundum elementa reduces segmentum medium, ita fit ad caveats `transmute::<T, U>` dicendum est.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Nota quod in hoc plurimum constant, munus erit, aestimari,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // praecipue tractamus ZSTs, quod est-quod omnino non essent tractandae.
            return (self, &[], &[]);
        }

        // Primo, quid designandum invenire non possumus Scinditur, et inter primos 2 scalpere.
        // Facile apud ptr.align_offset.
        let ptr = self.as_ptr();
        // Salutem et vide a detailed `align_to_mut` ad modum salutem comment.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // Salutem et `rest` Nunc varius turpis est ut bene sit infra `from_raw_parts`,
            // in RECENS polliceri non possumus `T` quod eiusdem est transmutare ad `U` tuto possent.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Eiusdem est transmutare ad segmentum segmentum genus alia, quae dicuntur vita types cursus membrorum dispositione sub vestibus.
    ///
    /// Hoc tribus distincta peragitato in modum scindit Segmentum placentae: praepositionem FRUSTUM de medio varius bene novi generis atque extrema illa partícula scalpere.
    /// Modo possit facere aliquod medium secare copiosissime input type scalpere sed scriptor algorithm vobis constet quod non recte.
    ///
    /// Licet omnibus notitia ut rediit ad initus que quae praeposita vel scalpere.
    ///
    /// Modum neque rem in hanc aut non habet input vel output `T` elementum elementum nullus est-amplitudo et `U` redabit ad illas sine originali aliquid scalpere.
    ///
    /// # Safety
    ///
    /// Essentialiter `transmute` modus secundum elementa reduces segmentum medium, ita fit ad caveats `transmute::<T, U>` dicendum est.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Nota quod in hoc plurimum constant, munus erit, aestimari,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // praecipue tractamus ZSTs, quod est-quod omnino non essent tractandae.
            return (self, &mut [], &mut []);
        }

        // Primo, quid designandum invenire non possumus Scinditur, et inter primos 2 scalpere.
        // Facile apud ptr.align_offset.
        let ptr = self.as_ptr();
        // Utilitatibus consulens Hic nos mos utor varius enim cursus in U ad indicium
        // reliqua ratio.Hoc fit transeuntes&regula ad [T] dam cum ii pro targeted
        // `crate::ptr::align_offset` recte dicitur cum et valida varius `ptr` regula (fit ex ad `self`) cum magnitudine et virtute, qui est duorum (ex quo fit ex Alignement in U), salutem angustiis tristitiae satisfaciat.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Post hunc `rest` uti non possumus; quia non irritam facit ad alias `mut_ptr`!Salutem et vide quia `align_to` comment.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Checks si elementa non hoc segmentum sorted.
    ///
    /// Id est: nam quisque `a` atque hoc elementum elementum `b`, `a <= b` habere debet.Si scalpere dat, nulla prorsus est aut elementum, `true` est rediit.
    ///
    /// Nota, quod solum si `Self::Item` `PartialOrd`, sed non `Ord`, pertinet definitio superius ad hoc munus `false` refert si quis biennium continuum iudex items huic non valent comparari.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Si elementa dicuntur, digestus a FRUSTUM huius checks uti comparator ad dedit munus.
    ///
    /// Instead usus `PartialOrd::partial_cmp`, utitur hoc munus datis determinare munus `compare` praeceptiva ordinationis duobus elementis.
    /// Praeter hoc est [`is_sorted`] equivalent to;magis notitia documenta eius vident enim.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Checks si elementa non hoc segmentum coetibus territorialibus data est clavis usus est extraction munus.
    ///
    /// Instead of comparet FRUSTUM de elementis directe, hoc munus ab elementis claves, comparat, sicut per `f` determinari.
    /// Praeter hoc est [`is_sorted`] equivalent to;magis notitia documenta eius vident enim.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Index de partitione ex parte refert ad secundum nomine significetur (the index elementum primae ad secundam partem).
    ///
    /// Segmentum partita secundum nomine significetur assumitur.
    /// Quam, elementum id redit praedicatum verum initium et elementa quibus praedicatum segmentum falsum redit in.
    ///
    /// Nam exempli gratia [7, 15, 3, 5, 4, 12, 6] sub partita sit a consortio praedicati x II%!=0 (sunt omnes impar in numeris initium omnis usque ad finem).
    ///
    /// Segmentum partita hoc non est reversus inanis fit incerta et quasi signa quaedam ratio binariae search.
    ///
    /// Vide etiam [`binary_search`], [`binary_search_by`] et [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // Salutem et cum `left < right`; `left <= mid < right`.
            // Semper igitur `left` `right` semper incrementum et decrementum et utraque electus.In utrisque casibus `left <= right` satiatur.Si igitur in `left < right` gradus, in altera gradus satisfieri `left <= right`.
            //
            // Sicut igitur dum `left != right`, `0 <= left < right <= len` saturatus est, et saturatus est, si hanc causam `0 <= mid < len` quoque.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: OBFULA nos postulo ut explicitly eadem longitudo
        // optimizer Facere facilius pro est reprehendo terminis elide.
        // Sed quia illud non potest esse in nobis quoque expressa habere specialis ad T: Exemplar.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Ut vacuum scalpere.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Mutabilia facit inanis scalpere.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Per crustae Patterns, currently solum a usus et `strip_prefix` `strip_suffix`.
/// At a future illud, `core::str::Pattern` ad generaliter speramus (quo in scripto autem usque ad tempus `str`) ad peragitato, et tunc iste erit reponi trait aut sublati.
///
pub trait SlicePattern {
    /// Quod ad segmentum matched elementum genus.
    type Item;

    /// Currently, opus `SlicePattern` FRUSTUM de consumentes.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}