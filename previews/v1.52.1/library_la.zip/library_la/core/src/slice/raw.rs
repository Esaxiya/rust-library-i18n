//! Munera liberum creare `&[T]` et `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Segmentum format de regula et longitudine.
///
/// Et elementa ** **`len` ratio est numerus, neque enim numero bytes.
///
/// # Safety
///
/// Temporis sequentibus conditionibus si quis autem hoc violare mores sunt;
///
/// * `data` nam quicumque legit `len * mem::size_of::<T>()` bytes [valid] sit et proprie amet.Et hoc maxime est;
///
///     * FRUSTUM memoriae latitudine totius huius rei est intra unius datum!
///       Non potest crustae per spatia obiecti plures partita imperia.Exemplum in male [below](#incorrect-usage) vide quia non inputatur eo quod tale reperisti.
///     * `data` necesse est etiam non-nulla-longitudo nulla varius purus.
///     Una ratio ad hoc quod sibi possit enum in layout optimizations references (longitudo inter crustae de quolibet) non-nulla, et varius esse eas distinguere ab aliis data.
///     Vos potest sicut `data` quia nulla est regula, quod est utilis, longitudo uti [`NonNull::dangling()`] purus.
///
/// * `data` `len` continuati quae ad recte esse in type initialized values `T`.
///
/// * Mutari non secare referenced memoria converso `'a` durante vita nisi intus sit `UnsafeCell`.
///
/// * Segmentum magnitudine et `len * mem::size_of::<T>()` In summa debet esse maior quam `isize::MAX`.
///   Vide documenta ad salutem [`pointer::offset`].
///
/// # Caveat
///
/// Segmentum placentae quo infertur quod vita rediit ad suos usus.
/// Ut impedire casu abutentis, suus 'tutum est vita suggesserant iussit ut ligatis pedibus in vita sua: ad fontem in context sicut et dedisset ei adiutorium munus taking the host de vita sua pretii pro FRUSTUM, aut aperte semideletum.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifest a FRUSTUM pro unum elementum
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Non recta usus
///
/// `join_slices` possumus insaniam vocare ** ** hoc munus est ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Contiguis et `snd` ensures `fst` est assertio sed tarnen _different allocated objects_ continetur, unde hunc partum FRUSTUM Proin vitae est.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` Sunt et alia datum obiecti ... `b`
///     let a = 42;
///     let b = 27;
///     // ... de contiguously posita sit in memoriam, quae tamen potest, |a |B |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // Confidenter RECENS `from_raw_parts` contractus debeat sustinere salutem.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Idem praestat ut funcionalidades [`from_raw_parts`] nisi commutabile scalpere redditur.
///
/// # Safety
///
/// Temporis sequentibus conditionibus si quis autem hoc violare mores sunt;
///
/// * `data` oportet [valid] enim tam multa legit et scribit ad `len * mem::size_of::<T>()` bytes et bene sit varius.Hoc est potissimum animadvertendum est:
///
///     * FRUSTUM memoriae latitudine totius huius rei est intra unius datum!
///       Crustae non potest contra multa spatia obiecti partita imperia.
///     * `data` necesse est etiam non-nulla-longitudo nulla varius purus.
///     Una ratio ad hoc quod sibi possit enum in layout optimizations references (longitudo inter crustae de quolibet) non-nulla, et varius esse eas distinguere ab aliis data.
///
///     Vos potest sicut `data` quia nulla est regula, quod est utilis, longitudo uti [`NonNull::dangling()`] purus.
///
/// * `data` `len` continuati quae ad recte esse in type initialized values `T`.
///
/// * Referenced in memoriam rediit ad segmentum esse non potest accessed per alia regula (non ex reditu ad valorem) `'a` durante vita sua.
///   Tum legere et scribere febrium vetiti sunt.
///
/// * Segmentum magnitudine et `len * mem::size_of::<T>()` In summa debet esse maior quam `isize::MAX`.
///   Vide documenta ad salutem [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // Confidenter RECENS `from_raw_parts_mut` contractus debeat sustinere salutem.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Segmentum placentae in longitudinem converts est ad T I (expresseris).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Segmentum placentae in longitudinem converts est ad T I (expresseris).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}