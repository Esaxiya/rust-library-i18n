//! `[u8]` res in ASCII.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Si intra segmentum in ASCII bytes feugiat rhoncus.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// - ASCII in re minime par, quod in duas feugiat purus.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` quod idem, sed sine temporaries dispertientes et iactat imitari.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Segmentum secundum ASCII superiori se convertit hoc loco eiusdem.
    ///
    /// ASCII epistolas ad 'a' 'z' sunt divisi sunt in 'A' 'Z': litterae non-ASCII sed non mutatur.
    ///
    /// Ad revertetur novum valorem uppercased est existentium non moderaretur, uti [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// - ASCII in inferioribus equivalent casu suo proselytis Hoc segmentum est.
    ///
    /// ASCII epistolas ad 'A' 'Z' sunt divisi sunt in 'a' 'z': litterae non-ASCII sed non mutatur.
    ///
    /// Ut reverteretur a lowercased pretii est existentium non moderaretur, [`to_ascii_lowercase`] utuntur.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Byte `true` refert si in hoc verbo `v` nonascii (>=CXXVIII).
/// Snarfed `../str/mod.rs` ex quo fit aliquid utf8 propter validation similes.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimized usize-at-a-ASCII tempus test, quod uti res pro byte-at-a-tempus, res (si fieri potest).
///
/// Et algorithmus hie utimur est pulchellus simplex.Brevior si `s` sumus sicut et quemlibet byte perage.Alioquin;
///
/// - Onus verbi primum cum Read Unaligned.
/// - Conlineare Regula in lege quæque verba subsequuntur, usque ad extremum varius onerat.
/// - Ab ultima `usize` Read `s` cum Unaligned onus.
///
/// Quod si de omnibus his onerat `contains_nonascii` (above) refert quam aliquod verum et falsum est non invenissetis propositionem meam.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Si autem non prodest quicquam verba nostrorum tempore exsequendam decidant scalari ansa.
    //
    // Nobis etiam hoc ad architectures ubi `size_of::<usize>()` non sufficient `usize` ad Gratia diei et noctis, quoniam suus 'a edge infandum casum.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Semper legunt Verbum primo Unaligned nos, id est `align_offset`
    // 0: volumus tanti iterum legere legere ad varius.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // Utilitatibus consulens `len < USIZE_SIZE` super nos cognoscere.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Nos sedatus est supra, quasi implicite.
    // Animadvertendum est `offset_to_aligned` `align_offset` `USIZE_SIZE` aut tam sedatus praelatus est.
    //
    debug_assert!(offset_to_aligned <= len);

    // Utilitatibus consulens est word_ptr (bene varius) usize utimur legere Press
    // FRUSTUM segmentum medium.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` byte est index de `word_ptr`, quia loop finem usus pecuniae ostendens.
    let mut byte_pos = offset_to_aligned;

    // Paranoia de reprehendo alignment, quod sumus ad fasciculum Unaligned non onerat.
    // Impossibile sit in hoc usu uenit ugbay etsi in `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Verbum subsequent Read sermonibus donec consumantur varius absque ultimis aligned se per Verbum factum est in cauda debet reprehendo postea cauda semper est `usize` ut plurimum est apud extra branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Reprehendo sanitas quae legere in terminis
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ut de suppositionibus `byte_pos` tenent.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SECURITAS; `word_ptr` Scimus enim varius bene (per
        // 'Align_offset`), ac Nos scimus quia satis bytes et finis inter `word_ptr`
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SALUS: Scimus `byte_pos <= len - USIZE_SIZE` quod significat, quod
        // `add` hanc, de praeterito `word_ptr` erit unum omnium finem.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Ut nihil sit vere unum tantum reprehendo sanitas `usize` reliquit.
    // Status stabiliri debet ab ansa.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // Saluti `len >= USIZE_SIZE` innititur iste qui initio refutamus.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}