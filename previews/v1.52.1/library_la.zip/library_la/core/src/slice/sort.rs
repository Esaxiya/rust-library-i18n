//! scalpere diribitio
//!
//! Cuius moduli rationem habet Orson voluptua algorithm secundum Petrum, 'formam, percussit quicksort, published at: <https://github.com/orlp/pdqsort>
//!
//!
//! Effusus es Sorting libcore quia non pertinet ad collocant memoria, firmum dissimilis genus nostrum implementation.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Ubi cecidit in transcribit `src` `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SALUS: Hæc ordinis adiutorium.
        //          Placere ad suum bene usus est.
        //          Nempe oportet ut certus sit `src` `dst`, et non overlap per `ptr::copy_nonoverlapping` Quod erat faciendum.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Donec inventa formas ad primum elementum maior aut aequalis.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // Salutem et tutum non est res sub Indexing involves sine reprehendo ligatus (`get_unchecked` et `get_unchecked_mut`)
    // lestia (`ptr::copy_nonoverlapping`) memoriam.
    //
    // a.Indexing:
    //  1. Nos sedatus ordinata ad magnitudinem> II=.
    //  2. Omnes Indexing semper inter faciam ut in summa {0 <= index < len}.
    //
    // b.memoria effingo
    //  1. Nos references obtinendae indicibus etiam, ad quod valet, utpote quae veneranda sit.
    //  2. Quod assequi non aliudque indicium differentiam segmentum indices.
    //     Quinque satrapas Philisthinorum, et `i` `i-1`.
    //  3. Si scalpere est varius recte et bene elementa varius.
    //     SALUTATOR scriptor officium est ad segmentum est bene certa varius.
    //
    // Vide quae infra quoniam adhuc detail.
    unsafe {
        // Si enim duo prima elementa sint ... ut ex-of-
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Primum elementum Read in acervum-partita imperia variabilis.
            // Si autem collatio sequitur panics operationem, `hole` mos adepto statim omissa: et scribam in segmentum elementum.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // I` ti: unum elementum mouere sinistram ita ius varium foraminis.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` sicque fit codicibus omissa `tmp` foramen `v` caetera.
        }
    }
}

/// Usque ad ultimam particulam subsit vices aequalem minori elementum.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // Salutem et tutum non est res sub Indexing involves sine reprehendo ligatus (`get_unchecked` et `get_unchecked_mut`)
    // lestia (`ptr::copy_nonoverlapping`) memoriam.
    //
    // a.Indexing:
    //  1. Nos sedatus et ordinata magnitudinem>=II.
    //  2. Omnes Indexing faciam, quod semper in summa inter `0 <= index < len-1`.
    //
    // b.memoria effingo
    //  1. Nos references obtinendae indicibus etiam, ad quod valet, utpote quae veneranda sit.
    //  2. Quod assequi non aliudque indicium differentiam segmentum indices.
    //     Quinque satrapas Philisthinorum, et `i` `i+1`.
    //  3. Si scalpere est varius recte et bene elementa varius.
    //     SALUTATOR scriptor officium est ad segmentum est bene certa varius.
    //
    // Vide quae infra quoniam adhuc detail.
    unsafe {
        // Si duobus elementis sint ultima ordinis ... ex-of-
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Postremo in acervum Read elementum-partita imperia variabilis.
            // Si autem collatio sequitur panics operationem, `hole` mos adepto statim omissa: et scribam in segmentum elementum.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Ti i`elementum mouere loco`dextra sinistra ut versis foraminis.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` sicque fit codicibus omissa `tmp` foramen `v` caetera.
        }
    }
}

/// Plura genera segmentum partim incertis elementum Out-ut massa.
///
/// Si fragmen est: coetibus territorialibus refert `true` ad finem.Haec munus est *Domine*(*n*) pessimus-casu.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Adjacent numerus maximus acceptorum-of-sicco mos adepto ut, quae pairs accipere.
    const MAX_STEPS: usize = 5;
    // Si ea Verre brevius non derivare quis elementum.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // Utilitatibus consulens fecit nobis iam expressis verbis ad reprehendo cum `i < len` vinctum.
        // Tota deinde facultatem tantum Iudex `0 <= index < len`
        unsafe {
            // Reperio altera par adjacent ex-of-Ut elementa.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Nos fecit
        if i == len {
            return true;
        }

        // Non transeunt in modico elementa vestit, quae a perficiendi sumptus.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // RES elementa par inventae.Hic ponit ea Recto phalanges consul ordine.
        v.swap(i - 1, i);

        // Accito minor elementum ad sinistram.
        shift_tail(&mut v[..i], is_less);
        // Accito elementum maior ad dextram.
        shift_head(&mut v[i..], is_less);
    }

    // Segmentum exprimere non ut genus ad numerum gradus terminata.
    false
}

/// Segmentum placentae speciebus perplura usura insertionem quaedam, et non *o*(^*n* II) pessimus-casu.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// `v` per heapsort speciebus perplura, quae polliceri * * O (n ^\log(*n*)) * pessimus-casu.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Haec binarii cumulo observet `parent >= child` immutatum.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Filii `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Puer maiorem eligere.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Si cesset immutatum tenet `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // `node` PERMUTO cum maior puer, una moveri deorsum gradus, et cribratam permanere.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Linearibus ad ædificem acervum lapidum in hora.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop elementis ex maxima ruinarum.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// In parietibus `v` elementa minora `pivot` sequebatur `pivot` quae maior aut aequalis.
///
///
/// Minores numeri particularum `pivot` redit.
///
/// Partitionibus impedimentum fieri per operationem ramosis impedimentum ut pretium magna.
/// [BlockQuicksort][pdf] idea ponitur charta.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Et in pluribus elementis obstructionum typical.
    const BLOCK: usize = 128;

    // Et partiare algorithm usque ad vestigia rettulit complementum:
    //
    // 1. Vestigium elementa quam truncus ex paribus eandem sinistra queramur.
    // 2. Vestigium elementa minora stipitem a dextris cognoscere queramur.
    // 3. Quae in eadem parte dextra inter commutatio.
    //
    // Ut hoc nobis in variables obstructionum ex elementis:
    //
    // 1. `block` - Obstructionum in numero elementa.
    // 2. `start` - Satus monstratorem in `offsets` ordinata.
    // 3. `end` - End regula in `offsets` ordinata.
    // 4. Exsertiones ': Indices obstructionum ex-of-ordo inter elementa.

    // In current obstructionum de sinistra parte (ut de `l` `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Obstructionum hodiernam in dextera parte (e `r.sub(block_r)` to `r`).
    // SALUS: Documenta ad .add() speciali allegare, ut semper `vec.as_ptr().add(vec.len())` safe`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Ut cum Vlas, conare creando unum ex longitudo `min(v.len() ordinata, II OBSIDEO *) potius:
    // quam certa longitudinis `BLOCK` size vestit.Vlas cache esset ultra-efficient.

    // Numerum refert inter elementa `l` (inclusive) et `r` (exclusive) indicibusque.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Dum enim fit partiare `l` scandalum et scandalum `r` ut per ipsum.
        // Opus ergo est ut quidam pannus inter reliqua elementa partiri.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Reliquis deinde elementis numerus (non comparari etiam super versorium).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Moles aptare ut scandalum scandalum non aliudque dextra vero reliquus posset omnino cooperiret omnem hiatum varius.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Vestigium elementa `block_l` sinistris.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // Salutem et unsafety res ex usus est infra involvere `offset`.
                //         Iuxta condiciones a munus, quod nos satiat eos:
                //         1. `offsets_l` datum est, ACERVUS ita quod datum esse separatum.
                //         2. Quod munus est `is_less` refert `bool`.
                //            Numquam exundabunt enim Casting `bool` `isize`.
                //         3. Nos `block_l` erit `<= BLOCK` spoponderunt.
                //            Plus, `end_l` initio constitutus erat ut incipiat a regula declaravit `offsets_` quae in ACERVUS.
                //            Et sic, si scio usque ad Maxime in re (omnibus invocationes `is_less` falsa refert) non plus I byte transiet a te non erit finis.
                //        Alii operatio unsafety hic est dereferencing `elem`.
                //        Autem, a primo initio fuit `elem` regula ad scalpere episcopalis essent cooperatores.
                unsafe {
                    // Branchless collatio.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Vestigium elementa `block_r` dextram.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // Salutem et unsafety res ex usus est infra involvere `offset`.
                //         Iuxta condiciones a munus, quod nos satiat eos:
                //         1. `offsets_r` datum est, ACERVUS ita quod datum esse separatum.
                //         2. Quod munus est `is_less` refert `bool`.
                //            Numquam exundabunt enim Casting `bool` `isize`.
                //         3. Non erit `<= BLOCK` `block_r` spoponderunt.
                //            Plus, initio `end_r` est qui constitutus est a incipiunt regula declaravit quod `offsets_` in ACERVUS.
                //            Ut notum est nobis quia etiam in Maxime in re (omnibus invocationes `is_less` vero refert) non plus I byte transiet a te non erit finis.
                //        Alii operatio unsafety hic est dereferencing `elem`.
                //        Sed praeterita `1 *sizeof(T)` `elem` initio fuit in finem, et non ex nobis `1* sizeof(T)` decrement accessing in conspectu ejus.
                //        Plus `block_r` `BLOCK` dictum minus et ut plurimum indicat `elem` igitur principium scalpere.
                unsafe {
                    // Branchless collatio.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Ut inter elementa Out-of PERMUTO parte dextra.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Pro par est permutando eo tempore, quod est alternando efficient ut Calcio perform a.
            // Et hoc est condignum ut swapping, sed similis effectus producit res memoriae verbis paucioribus uti.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Relictis omnibus scandalum moveretur, de elementorum ordinem.Postero obstructionum Movere.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Stipes rectus ordo elementorum, et cunctis quæ moventur in.Movere ad priorem obstructionum.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Et maxime in truncus Reliquum jam (vel dextra vel sinistra) ex ordine elementorum sicco-indigeat moveri.
    // Potest simpliciter reliquis deinde elementis quae in priora dimittens post ultimum obstructionum eorum.
    //

    if start_l < end_l {
        // In sinistra obstructionum manet.
        // Reliqua elementa sicco-movisse ut longe dissimilis.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // De iure obstructionum manet.
        // Ordinem elementorum motus longe ab reliquis foris reliquisset.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nihil aliud facere, erant 'fieri.
        width(v.as_mut_ptr(), l)
    }
}

/// In parietibus `v` `v[pivot]` minores partes sequerentur `v[pivot]` elementum maior aut aequalis.
///
///
/// Refert ad tuple est,
///
/// 1. Minor `v[pivot]` multis elementis.
/// 2. Verum si `v` iam partita est.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Ad principium ponere versorium ad scalpere.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Versorium in Read in ACERVUS est variabilis efficientiam-partita imperia.
        // Et si haec operatio comparationis panics et versorium et statim scripta sunt in scalpere.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Reperio primo par est, ordine, de elementis.
        let mut l = 0;
        let mut r = v.len();

        // Salutem et avaritiam pertinet quod inferius unsafety indexing est ordinata.
        // Nam primum: Nos ex terminis jam non reprehendo hic `l < r`.
        // Ad secundum, nos initio esse non sedatus et `l == 0` et `r == v.len()` `l < r` ad indicationem omnis operatio.
        //                     Scimus enim necesse est ut saltem hinc `r` `r == l` ostensum quod sit verum ex primis unum.
        unsafe {
            // Primum aequalis invenitur quam queramur.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Reperio versorium ultimum elementum est minor.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` et in scope versorium egreditur scribit (BIBLIOTHECA quod est variabilis-partita imperia) segmentum in quo primum fuit.
        // Quod hic gradus apud ensuring discrimine salutem!
        //
    };

    // Versorium duos parietes inter Ac personis has res.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Deinde exaequabo `v[pivot]` elementa quae in parietibus `v` `v[pivot]` maius.
///
/// Cardo numeri particularum aequalem reditum.
/// Quae non habet minor ponatur `v` queramur.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Ad principium ponere versorium ad scalpere.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Versorium in Read in ACERVUS est variabilis efficientiam-partita imperia.
    // Et si haec operatio comparationis panics et versorium et statim scripta sunt in scalpere.
    // Utilitatibus consulens In monstratorem Hic valet quod fit ex a ad scalpere.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Nunc partiri cum scalpere.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // Salutem et avaritiam pertinet quod inferius unsafety indexing est ordinata.
        // Nam primum: Nos ex terminis jam non reprehendo hic `l < r`.
        // Ad secundum, nos initio esse non sedatus et `l == 0` et `r == v.len()` `l < r` ad indicationem omnis operatio.
        //                     Scimus enim necesse est ut saltem hinc `r` `r == l` ostensum quod sit verum ex primis unum.
        unsafe {
            // Invenies maiora quam versorium primum elementum.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Reperio versorium ultimum elementum est aequalis.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Nos fecit
            if l >= r {
                break;
            }

            // PERMUTO ex par-of-ordinem inventis elementa.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Par `l` elementis invenimus versorium.Addere I ad rationem pro se versorium.
    l + 1

    // `_pivot_guard` et in scope versorium egreditur scribit (BIBLIOTHECA quod est variabilis-partita imperia) segmentum in quo primum fuit.
    // Quod hic gradus apud ensuring discrimine salutem!
}

/// Aliqua forma quae violare conatus spargit circum parietes in quicksort imbalanced consecraret.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom numerum a generante "Xorshift RNGs" per chartam George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Ut temere numerus modulo est numerus.
        // Quia `len` maior est numerus `usize` `isize::MAX` inseritur.
        let modulus = len.next_power_of_two();

        // Quidam versorium prope candidati erit in hoc indicem.Sit scriptor randomize eos.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Omnique fœlicissimè gubernandi generate a numerus temere `len`.
            // Sed ne opus pretio virtus modulo accipias duo primo et per diminutionem `len` donec rhoncus `[0, len - 1]` inseritur.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` est, praestatur esse minus quam `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Versorium in inducit `v` redit cum indice et `true` si segmentum sit verisimile iam sorted.
///
/// Elementa `v` vbique ut elit.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimum eligere media-of-ratio medians.
    // Breviori crustae uti simplex, medius ex tribus, modum.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Ut swaps numerus maximus acceptorum non possunt tamdiu in munere mansurum.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Quae circa nos ire eligere tres indices versorium.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Comites nonaginta sex dependentia sumus swaps ut indices praestare in voluptua.
    let mut swaps = 0;

    if len >= 8 {
        // Swaps ut indices `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Swaps ut indices `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Invenit media `v[a - 1], v[a], v[a + 1]` ciborumque horrea hoc est ab into the index `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Reperio apud medians, circa `a`, `b` et `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Reperio mediam quisque inter `a`, `b` et `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // A numerus maximus strigili conditum est.
        // Sunt casus vel plurimum descendit segmentum descendam, ut verisimile prodesse generis retro citius eam.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` Generibus Post Pretia Rerum recursively.
///
/// Si autem praedecessor FRUSTUM erat in originale ordinata, ita quod certa sit `pred`.
///
/// `limit` permissum est numerus imbalanced Spartiti ante switching ad `heapsort`.
/// Si nulla, hoc munus statim heapsort mutes rationem tuam.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Crustae ad adepto longitudinem haec commoda per insertionem generis.
    const MAX_INSERTION: usize = 20;

    // Verum si recte cum partitionibus tandem compensetur.
    let mut was_balanced = true;
    // Si non verum; Partition aliqua tergiversatione ultima elementa (segmentum iam partita est).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Coetibus adepto purus paululum usura insertionem generis.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Et si plures electiones versorium sunt mala fecit simpliciter cadunt in heapsort ut pignus `O(n * log(n))` pessimus-casu.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Si novissimus imbalanced et partitionibus, frustum in prasenti aliqua exemplaria frangere gyro.
        // Sine spe milites youll hoc versorium eligere meliorem.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Elige utrum versorium conantur segmentum coniciens iam sorted.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Si ultimum partitionibus est honeste, et non aliqua tergiversatione relata elementa et si segmentum sit, praedicit, versorium delectu verisimile iam sorted ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Ordinem elementorum aliquot noscendis operam sicco-versis ad rectam positione.
            // Si penitus defixa segmentum commoda, 'perfectus.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Si molem aequalem electum praedecessor segmentum illud minimum elementum.
        // Quae in ipsis et maius segmentum elementa partiri cardine.
        // Hic continet fere ledo cum a FRUSTUM duplicata multis elementis.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Continue in versorium major elementa voluptua.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Partition segmentum.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Segmentum placentae in `left` divide illud, `pivot` et `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Tantummodo in obscuratis Recurse minoris recursive vocat numerum minorem BIBLIOTHECA spatium consumere.
        // Iustus parte longius prosequi (propior est cauda Recursion).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// - Exemplar usus speciebus perplura `v` praevaluerint adversum quicksort, qua *Domine*(*n*\*log(* n*)) pessimus-casu.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Significativum habet a priori nulla Sorting-sized types.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Finire numerum imbalanced ad parietes `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Nam crustae de longitudinem ad hoc tantum, ut suus 'verisimile citius generis eorum.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Elige versorium
        let (pivot, _) = choose_pivot(v, is_less);

        // Si molem aequalem electum praedecessor segmentum illud minimum elementum.
        // Quae in ipsis et maius segmentum elementa partiri cardine.
        // Hic continet fere ledo cum a FRUSTUM duplicata multis elementis.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Si transeam indice nostro non igitur sumus bonum.
                if mid > index {
                    return;
                }

                // Alioquin continue voluptua elementa maior quam queramur.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Segmentum placentae in `left` divide illud, `pivot` et `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Si==inter indicem et fecit nos, quia post meridiem partition() spopondissemus elementum maior aut aequalis medium.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Significativum habet a priori nulla Sorting-sized types.Nihil facere.
    } else if index == v.len() - 1 {
        // Elementum invenire max contuderis pones ex eo loco ad ultimum ordinata.
        // Nos scimus quia hic es usurpari `unwrap()` v est non erit inanis.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Min reperire elementum primus in ordine poneretur.
        // Nos scimus quia hic es usurpari `unwrap()` v est non erit inanis.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}