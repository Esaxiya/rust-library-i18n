//! A FRUSTUM de iterators usus utentis.

// Ben et perficientur facit ingens discrimen Inlining is_empty
macro_rules! is_empty {
    // Et nos in longitudinem a via encode ZST iterator: quia uterque operatus est et non-ZST ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Ut quidam fines impetro rid of checks (videatur `position`), computamus, in longitudinem per aliquantum inopinatum via.
// (Exertus eo qui codegen/check`, scalpere-locus-fines.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // non tutam ambulantibus nos aliquando usus in scandalum

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Uti hoc _cannot_ `unchecked_sub` quia innitimur dum tegmen ZST segmentum longitudo iterators repraesentare.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Scimus `start <= end`, sic potest facere melius `offset_from`, oportet quod illud in quo signati.
            // Conveniens statui potest vexilla LLVM Ubi hoc removet modum conferat compescit.
            // SALUS: A type ab immutatum relinquit; `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Per quae etiam vera LLVM indicia esse seorsum ab esse effigiem generis multa de magnitudine, ita potest ad optimize `len() == 0` `start == end` pro `(end - start) < size`.
            //
            // Salus: A type in immutabilis, ita quod varius indicia sunt,
            //         multiplex est distantia magnitudinis pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Et communi definitione `Iter` `IterMut` iterators
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Primum initium redit elementum movet, et motu progressivo I iterator.
        // His magno opere ad meliorem perficientur inlined munus comparari.
        // Non sunt vanae iterator.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Redit et elementum ultimum finem movet eximium quemque I iterator.
        // His magno opere ad meliorem perficientur inlined munus comparari.
        // Non sunt vanae iterator.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Iterator recusat, ex quo est ZST T, moveri in finem retrorsum `n` iterator.
        // `n` ut ultra non transeat `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Adiutor ex munere iterator scalpere partum.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // Salutem et cum a FRUSTUM iterator creata est monstratorem
                // `self.ptr` `len!(self)` diuturnitatem.
                // Haec polliceri omnes necessarias proprietates `from_raw_parts` sunt.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Movere ad munus auxiliator promoveatur `offset` elementa initium iterator: vetus satus reversus est.
            //
            // Quia minus securum putavimus offset `self.len()` ut ultra non transeat.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SALUS, in RECENS polliceri, quod `offset` `self.len()` non excedens,
                    // `self` et hoc regula est quod interius non ita certo non-nulli.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Nam finis munus adiutoris movere retrorsum iterator `offset` elementa, reversus finem novae.
            //
            // Quia minus securum putavimus offset `self.len()` ut ultra non transeat.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SALUS, in RECENS polliceri, quod `offset` `self.len()` non excedens,
                    // confirmatum est per redundantiam, quae non `isize`.
                    // Item, regula inde in fines `slice`, quo perficitur ad `offset` aliis.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // purus et posse amet sed modum cavendi compescit

                // Salutem et tutum `assume` vocat quae ab initio a FRUSTUM de regula
                // necesse non erit irritum, et in crustae ZSTs non-esse et non-nullum finem habent monstratorem.
                // Quia pacto tutus `next_unchecked!` vacuum iterator reprimendam si primum.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Hujus vana est iterator.
                    if mem::size_of::<T>() == 0 {
                        // `ptr` quod sic nos have ut facere ne forte sit 0 et `end` esse (ex involuti).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // Utilitatibus consulens, non potest esse extremum T si est 0, non est 0 ZST et finis propter ptr> ptr=
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // Salutem et nos sumus in terminis.`post_inc_start` etiam non est ius ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Nos dominari implementation default, quod utitur `try_fold` propter hoc generat implementation simplex et citius minus LLVM IR ordinare.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Nos dominari implementation default, quod utitur `try_fold` propter hoc generat implementation simplex et citius minus LLVM IR ordinare.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Nos dominari implementation default, quod utitur `try_fold` propter hoc generat implementation simplex et citius minus LLVM IR ordinare.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Nos dominari implementation default, quod utitur `try_fold` propter hoc generat implementation simplex et citius minus LLVM IR ordinare.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Nos dominari implementation default, quod utitur `try_fold` propter hoc generat implementation simplex et citius minus LLVM IR ordinare.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Nos dominari implementation default, quod utitur `try_fold` propter hoc generat implementation simplex et citius minus LLVM IR ordinare.
            // Item, in `assume` vitat in fines reprehendo.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // Utilitatibus consulens consistere putetur in terminis habemus loop ab immutatum relinquit:
                        // Cum `i >= n`, `self.next()` ansam veniat et `None` rumpit.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Nos dominari implementation default, quod utitur `try_fold` propter hoc generat implementation simplex et citius minus LLVM IR ordinare.
            // Item, in `assume` vitat in fines reprehendo.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // Salutem `i` incipit esse quod infra `n` `n`
                        // et solam minuendo.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // Salutem et non SALUTATOR praestare in fines `i`
                // subest secare ut `i` non conteret, et `isize` et reddidit references indicant quod elementum est, praestatur ad scalpere ac valida esse sanxit.
                //
                // Et quod es non SALUTATOR tum vadimonia, quod rursus dicitur ad eundem indicem et alius modi, qui dicuntur subslice tibi accessere hanc, sic valet ad rediit ad mutabilis est in casu
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // purus et posse amet sed modum cavendi compescit

                // Salutem et vocat `assume` esse tutum ab initio a FRUSTUM de non-esse est regula vitio nullitatis infecta,
                // et in crustae ZSTs non-esse et non-nullum finem habent monstratorem.
                // Tutum enim `next_back_unchecked!` pacto iterator reprimendam si prima vacat.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Hujus vana est iterator.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // Utilitatibus consulens in fines sumus.`pre_dec_end` ius habet aliquid etiam ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}