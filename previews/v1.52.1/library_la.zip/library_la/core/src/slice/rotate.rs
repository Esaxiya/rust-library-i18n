// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Quod fit cottidie rotetur circum range `[mid-left, mid+right)` `mid` ita ut ad primum elementum elementum.Possibile roto rhoncus `left` `right` elementorum partes dextra vel sinistra.
///
/// # Safety
///
/// A range est invalidam esse certa legere et scribere exercitent.
///
/// # Algorithm
///
/// I algorithm esse usus in magnis vel parvis ipsarum `left + right` `T`.
/// De elementa sunt ultima eorum, movetur in loco uno, et ad tempus, incipiens `mid - left` apud progredientes a modulo `left + right` `right` gradus, ita ut non opus sit unum ad tempus.
/// Eventually nobis ad venire tergum `mid - left`.
/// Autem, si non `gcd(left + right, right)` I, perstrinxisse gradus est supra elementa.
/// For example:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Feliciter tinentibus partes inter elementorum numerum aequalem perstrinxisse possumus justo felis situs magis principali circumeunt (`gcd(left + right, right)` value) est numerus orbes.
///
/// , Quod finis sit omne effectus elementa tantum et semel, et iterum tinentibus consummantur.
///
/// Algorithm si adhibetur II `left + right` `min(left, right)` magna et parva est satis fit acervus onto quiddam.
/// Ab elementis `min(left, right)` super quiddam transtulerunt, `memmove` applicatur aliis quiddam moventur in foveam et qui ex adverso ubi pergunt.
///
/// Algorithms vectorized potest Outperform magna satis erit quod super iterum `left + right`.
/// Algorithm I vectorized posse per plures rounds simul LAEVUS et in faciendo sed etiam non pauci sunt mediocris ad `left + right` in rounds, sit enormis, et per unius de Maxime in re semper est.
/// Instead, permutando algorithm III utilises repetitum ex elementis `min(left, right)` usque ad rotate minor est forsit relicto.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// quod fit ex `left < right` swapping ad sinistram loco.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. Si infra Algorithms quin casu retentus
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // I indicant Microbenchmarks algorithm in mediocris perficientur melius est enim temere arte cucurrit vestibus extentis omnem circa `left + right == 32` usque modo, sed etiam circa XVI comminuit, Maxime in re perficientur.
            // XXIV elegit quae est medium.
            // Si magnitudinem `T` est maior quam IV: usize`s, algorithm est etiam alia outperforms algorithms.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ex primis per beginning
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` referentem `gcd(left + right, right)` inveniri potest manus autem quod celerius est aestimet GCD ut ansa contra sententiam et ceteri facerent FRUSTUM
            //
            //
            let mut gcd = right;
            // benchmarks quod sit revelare est PERMUTO citius temporaries omni via per legendi pro se aliquando ad tempus et ambulavit retrorsum, qui scribebat ad tempus et ad finem usque complevit.
            // Haec forte permutando ex eo, quod aut utitur temporaries repositoque unus tantum, memoria repetita oratio, in pro loop ad binos trahentibus.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // et si non reprehendo pro incrementing `i` extra fines, non reprehendo, si dabitur proximum Incrementum in `i` ibimus extra fines.
                // Et hoc indicium est ulla aut involuti `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // primo per ultimum
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // hîc esse condicionalis `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // consummare ultra in FRUSTUM de rounds
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` non nulla-sized genus, sic suus 'okay ut dividant ex sua magnitudine.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Et algorithm II `[T; 0]` hic est pro T ensure varius id est appropriately
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // III Est alternis modus algorithm ut involves swapping invenire, ubi extremum in algorithm non PERMUTO ex quo et per quod swapping FRUSTUM tandem pro permutando adjacent chunks algorithm est facere sic, sic, sed etiam citius.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // III algorithm, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}