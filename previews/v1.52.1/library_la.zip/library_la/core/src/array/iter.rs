//! Vestit iterator enim definit `IntoIter` owned.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A by-valorem [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Haec nos ordinata in iterando.
    ///
    /// Cum indice `i` `alive.start <= i < alive.end` elementa quibus non liis tamen et ordinata sunt entries valet.
    /// Elementa apud indices, aut `i < alive.start` `i >= alive.end` liis quae iam est, et non potest accessed vinciantur!Prorsus etiam mortuis elementis uninitialized publicae
    ///
    ///
    /// Sic invariants sunt:
    /// - `data[alive]` est vivere (id verum elementa contineat)
    /// - `data[..alive.start]` mortui sunt atque `data[alive.end..]` (id quod elementa non esse iam legere et tetigit ultra!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Quod in elementis `data` quod tamen non liis.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Novam gignit super dedit `array` iterator.
    ///
    /// * * Nota: future ad hunc modum apud ne abominandam post [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Quod genus `value` `i32` est hic, pro `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // Salútem: et CONVERTO hic esse tutum.Et importat soUicitudo de `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` idem praestatur dam magnitudine
        // > ut `T`.
        //
        // Quod importat soUicitudo a ostendere etiam ex CONVERTO an ordinata de `MaybeUninit<T>` est ordinata ad `T`.
        //
        //
        // In ea, haec initialization invariants implet.

        // FIXME(LukasKalbertodt): hic etiam per `mem::transmute`, Const generics statim operatus est:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Usque tum `mem::transmute_copy` possumus uti ad creandum et ad exemplum bitwise alteram rationem, tum illud, ut obliviscar `array` sumitur, non ponitur.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Refert immutabilis est omnibus elementis segmentum tamen non liis.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SALUS: Scimus quia omnia elementa bene in `alive` initialized.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Refert omnium rerum invisibilium visibiliumque fragmen fructum elementa, quae tamen non sunt.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SALUS: Scimus quia omnia elementa bene in `alive` initialized.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Index adepto a fronte alterius.
        //
        // In I de `alive` servatque suae `alive.start` augendae immutatum relinquit.
        // Sed hoc mutatione debitum ad brevi tempore vivit et zona `data[alive]` non ultra, nisi `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Read a elementum ordinata.
            // SALUS: Index `idx` est autem in illa regione "alive"
            // ordinata.`data[idx]` habetur modo, quae iam mortua est elementum legendi (id nolite tangere).
            // Sicut zona `idx` fuit initium est, vivens: ergo et vivere est zona `data[alive]` rursus Daunia reddit omnem invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Ut altero ab tergo indice.
        //
        // Per decrescentes `alive.end` servatque suae I de `alive` immutatum relinquit.
        // Autem, huic ob mutatio, quia brevi tempore vivit et zona `data[alive]` non valet ultra, nisi `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Read a elementum ordinata.
            // SALUS: Index `idx` est autem in illa regione "alive"
            // ordinata.`data[idx]` habetur modo, quae iam mortua est elementum legendi (id nolite tangere).
            // Sicut zona `idx` quod in fine vivere, et vivere zona `data[alive]` nunc iterum restitutionis omnium invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // Salutem et tutum est; `as_mut_slice` refert ad exacte sub-secare
        // et hoc non ex elementis e motus, et tamen manet in relinquantur.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Non ex underflow immutatum relinquit: alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Quod quidem iterator rectam longitudinem refert.
// Numerum "alive" elementis (quae tamen cessit) `alive` longitudo latitudine.
// Haec extensio est vel `next_back` `next` decremented longitudine utrumque.
// Non semper ea sunt in I decremented a modi, sed tantum `Some(_)` est rediit.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Nota: vere non necesse est exactam eadem vivere range par, sic nos can iustus in offset clone: 0 regardless of qua `self` sit.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clone omnibus elementa vivere.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Clone novos exercitus scribere in deinde eget rhoncus ejus viveret.
            // Si cloning panics sumus te concrescunt recte priorem items.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Tantum typis imprimi, quae non fructum sed elementis: ut non ultra access the elementa cesserunt.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}