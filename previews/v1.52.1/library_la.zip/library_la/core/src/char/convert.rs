//! Ad conversiones promovendas mores.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Conuerti fecerit `u32` ad `char`.
///
/// Nota quod omnis [`char`] s sint valida [`u32`] s, et esse cast cum ad unum
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Tamen, e converso, non est verum; verum non omnes [`u32`] s es validum [`char`] s.
/// `from_u32()` `None` initus reddam si non sit valida in [`char`] pretii.
///
/// Propter hoc munus versionem statio male fida haec checks in solidum ignorans, videatur [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Quando reversus `None` initus [`char`] non valet:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Conuerti fecerit `u32` ad `char` multo egent firmitatis.
///
/// Nota quod omnis [`char`] s sint valida [`u32`] s, et esse cast cum ad unum
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Tamen, e converso, non est verum; verum non omnes [`u32`] s es validum [`char`] s.
/// `from_u32_unchecked()` ignorare id [`char`] mitti ac temere fieri invalidam creando.
///
///
/// # Safety
///
/// Hoc munus non stabilieris tu, ut illum constitui, ut irritum `char` values.
///
/// Versionem parumper hic salvus munus, munus [`from_u32`] videre.
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SALUS, in RECENS `i` confirmare oportet quod charitatis est verum valorem.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Converts [`char`] est in [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Conuerti fecerit [`char`] in [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Et casu percus casted est ad valorem signum ex parte: tunc nulla, extenditur ad LXIV frenum.
        // See [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Conuerti fecerit [`char`] in [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Et integer enim casted in valore ex codice illud, tunc est nulla CXXVIII-extenso partem.
        // See [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Maps est byte 0x00 ..=0xff in puncto ad `char` codice cui acquiritur eodem fruitur pondere, in U + 0000 .. U=+ 00FF.
///
/// Forms decodes est disposito tam efficaciter vocat IANA bytes de signorum delatam esse ISO-8859-1.
/// Hoc modum translitterandi potest esse cum ASCII.
///
/// Nota ista alias aliud ISO/IEC 8859-1
/// ISO 8859-1 (hyphen uno minus), quo aliquid relinquit "blanks", byte values sunt assignata, quae ad mores.
/// ISO-8859-1; (est enim IANA) C0 attribuit eas in potestate et C1 ostendentur.
///
/// * * Hoc quod Nota etiam alia a Fenestra, aka MCCLII
/// Code pagina MCCLII, quod est superset ISO/IEC 8859-1 assigns quod quidam (non omnium?) colis et codicellos ad variis Latine ingenia.
///
/// Ut adhuc confundamus res, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` et `windows-1252` omnes in aliases quod implet MCCLII superset of Fenestra, quod reliquum est in correspondentes C0 et codicellos ad hoc C1 imperium ostendentur.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Conuerti fecerit [`u8`] in [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Parsing Error cui non debet, cum chari rediit.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // Utilitatibus consulens sedatus iuris systemati UNICODE valorem eam vir suus '
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Prima luce, cum rediit type int, ad conversionem ex u32 fallere satis probant.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Radix enim dedi ad converts in digit `char`.
///
/// A 'radix' hic est enim 'base' nunc quoque dicitur.
/// Radix enim duorum indicat numerus binarii A, a radix of ten: decimales, et radix de sedecim, veste hexadecimali ostendentur, ad aliquid commune values.
///
/// Arbitraria radices sunt praesto est.
///
/// `from_digit()` et revertetur `None` si initus digit non dedit ad radix.
///
/// # Panics
///
/// Et si radix Panics datis maior quam XXXVI.
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // XI punctum a XVI basis unius digit apud
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Reversus autem cum initus `None` non digit;
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Transeuntes magnam radix, causans panic;
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}