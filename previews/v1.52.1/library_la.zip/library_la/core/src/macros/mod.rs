#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Aut `$crate::panic::panic_2015` Expands est in editione seu `$crate::panic::panic_2021` fretus ma gistrum suum.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Dicit, quod ista duo sunt ad invicem æquales (per [`PartialEq`]).
///
/// De panic, id tortor non imprimi, quae in suis locutionibus ex repraesentatione debug.
///
///
/// Velut [`assert!`], id tortor est secundum speciem, ubi mos est panic praeberi potest nuntio.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Et reborrows voluntariam infra sunt.
                    // Absque illis enim socors ACERVUS est initialized horum mutuo postulaverit comparari etiam coram illis sunt contraria, ducens ad tardus ad perceptionem veniunt.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Et reborrows voluntariam infra sunt.
                    // Absque illis enim socors ACERVUS est initialized horum mutuo postulaverit comparari etiam coram illis sunt contraria, ducens ad tardus ad perceptionem veniunt.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Non ponentis duo inter se aequalia (uti [`PartialEq`]).
///
/// De panic, id tortor non imprimi, quae in suis locutionibus ex repraesentatione debug.
///
///
/// Velut [`assert!`], id tortor est secundum speciem, ubi mos est panic praeberi potest nuntio.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Et reborrows voluntariam infra sunt.
                    // Absque illis enim socors ACERVUS est initialized horum mutuo postulaverit comparari etiam coram illis sunt contraria, ducens ad tardus ad perceptionem veniunt.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Et reborrows voluntariam infra sunt.
                    // Absque illis enim socors ACERVUS est initialized horum mutuo postulaverit comparari etiam coram illis sunt contraria, ducens ad tardus ad perceptionem veniunt.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Asserit est expressio a Boolean `true` ad runtime.
///
/// Hoc si provisum invocabo [`panic!`] tortor neque existimari potest, ut expressio `true` in runtime.
///
/// Velut [`assert!`], hoc etiam a tortor secundam version, qua nuntius a mos panic praeberi possit.
///
/// # Uses
///
/// Secus [`assert!`], enabled in solum `debug_assert!` allata sunt non default optimized builds a.
/// An optimized constructum Non faciam nisi `debug_assert!` statements `-C debug-assertions` praecessit in compiler.
/// Et hoc facit `debug_assert!` utilis pro est reprehendo quae sunt pretiosa quod in praesenti non potest esse utile release in extructione progressus.
/// Et propter expanding `debug_assert!` typus semper sedatus.
///
/// Assertio concedit progressio a fine per status inconveniens est ut currit, quae tamen non sequitur ut inopinatum ac inducere unsafety dum hoc tutum non fit in codice.
///
/// Et perficientur sumptus assertiones distinctae, tamen non measurable in generali.
/// Sed ita cum `debug_assert!` accurata profiling [`assert!`] animum loco et maius in tuto code
///
/// # Examples
///
/// ```
/// // nuntius ista quod est in panic stringified pretii expressio est data.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // sit ipsum simplex function
/// debug_assert!(some_expensive_computation());
///
/// // consuetudinem confirmare sermonem
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Duo inter se aequalia asseverat.
///
/// De panic, id tortor non imprimi, quae in suis locutionibus ex repraesentatione debug.
///
/// Secus [`assert_eq!`], `debug_assert_eq!` statements es optimized in non non enabled per default builds.
/// Optimized `debug_assert_eq!` statements Non faciam nisi per constructum est Transierunt `-C debug-assertions` ad compiler.
/// Hoc facit `debug_assert_eq!` utilis pro est reprehendo quod pretiosa esse in praesens utile erit release sed in extructione progressus.
///
/// Et propter expanding semper typus `debug_assert_eq!` sedatus.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Non duo aequalia asseverat.
///
/// De panic, id tortor non imprimi, quae in suis locutionibus ex repraesentatione debug.
///
/// Secus [`assert_ne!`], enabled `debug_assert_ne!` in non tantum es optimized statements builds per default.
/// An `debug_assert_ne!` statements optimized aedificare Non faciam nisi is passed `-C debug-assertions` ad compiler.
/// Et hoc facit ad checks `debug_assert_ne!` utiles sunt quoque pretiosa esse in praesens utile erit ut release sed in extructione progressus.
///
/// Est semper propter expanding `debug_assert_ne!` typus sedatus.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Sive redit aequet expressio datis aliquo datis exempla.
///
/// Sicut in `match` expressio exemplaria potest ad libitum: `if` et custodiam expressio sequitur quod per accessum ad exemplar nomina tenetur.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Effectus seu a suo errore unwraps propagatur.
///
/// Et `?` operator addita reponere `try!` et quid esse in loco.
/// Ceterum `try` est sermo in Rust MMXVIII reservatis: ut si vos must utor is, vos mos postulo utor [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` aequet dedit [`Result`].In casu de `Ok` variant, ex habet pretii expressio separatim involutum in valorem.
///
/// Si de `Err` varius, ad interiorem eam retreive errore.Et per conversionem `try!` performs `From`.
/// Automatic inter specialized errorum adhuc communioribus et praebet hanc conversionem.
/// Et pertinaciter Quod inde protinus reddidit.
///
/// Quia primo de reditu, munera, quae in `try!` modo potest redire [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Quos errores modum antepositum reversus velox
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Quos errores modum prior velox reverti
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Equivalent ad haec;
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Quae formatae sint in notitia scribit quiddam.
///
/// Hac admissam 'writer' tortor, sit forma filum et Lucius partibus.
/// Argumentis et formatae secundum certa ac format filum effectus inebriaberis atque nudaberis ad bellandum.
/// Auctor, aliquam sit cum `write_fmt` valorem modum;ex hoc exsequendum [`fmt::Write`] sive generaliter sive [`io::Write`] trait.
/// Redeat quocumque modo `write_fmt` tortor redeuntplerumque [`fmt::Result`], nec [`io::Result`].
///
/// Videre magis notitia [`std::fmt`] enim in syntaxi format filum.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// A `std::fmt::Write` moduli et utrumque importat `std::io::Write` vocati `write!` rebus effectum in utraque figura efficere non tam objecti.
///
/// Sed traits modulus importare debet ut probati, non conflictu nomina sua:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // utitur fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // utitur io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Et hoc fieri in can tortor `no_std` setups, ut bene.
/// In `no_std` es responsible pro setup implementation details de components.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Scribere notitia in formatae quiddam est, cum newline appensa.
///
/// Omnium rostra, linea newline ADESCO (`\n`/`U+000A`) ingenium solius (RURSUS (`\r`/`U+000D`) HABITUS nulls.
///
/// Quia magis notitia, videre [`write!`].Nam forma notitia in filum Syntax, videatur [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// A `std::fmt::Write` moduli et utrumque importat `std::io::Write` vocati `write!` rebus effectum in utraque figura efficere non tam objecti.
/// Sed traits modulus importare debet ut probati, non conflictu nomina sua:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // utitur fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // utitur io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Impossibile codice indicat.
///
/// Hoc est utile quod non possent ullum tempus codice adiecta est impossibile.For example:
///
/// * Armis conditionibus praesidium parem.
/// * Ora sagi alterius, ut dynamically fine terminari.
/// * Quod Iterators dynamically fine terminari.
///
/// Si Code arbitrium non est impossibile esse falsa, probat, protinus progressio terminatur in [`panic!`].
///
/// Et par periculum est hoc tortor [`unreachable_unchecked`] munus, quod si causa Finis mores codice ventum est.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Hoc arbitrium [`panic!`] semper.
///
/// # Examples
///
/// Par manibus
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // si ex errore annotavit compilare
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // De pauperibus implementations unus ex x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Ex codice indicat unimplemented TREPIDANS de "not implemented" cum epistula.
///
/// Hoc genus et vestra code allows-reprehendo, et est utilis si vos es in effectum ducenda prototyping sive modi multa, quae facis trait, quod postulat usus consilio non omnes.
///
/// Et [`todo!`] `unimplemented!` Horum autem differentia est quod traditum est dum mente `todo!` functionality ad effectum deducendi praecepta ac postea "not yet implemented" verbo est, ita nihil facit `unimplemented!` necessitudinibus habuisse potiora.
/// Et "not implemented" est nuntius.
/// Etiam de `IDEs mark te todo!` S.
///
/// # Panics
///
/// Hoc [`panic!`] semper voluntatem quia `unimplemented!` est notarius ad `panic!` est certa, specifica nuntius.
///
/// Velut `panic!`, secundum quod habet formam ostenderet more tortor valores.
///
/// # Examples
///
/// Dicere habemus trait `Foo`;
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Quia volumus ad effectum deducendi `Foo` 'MyStruct', nisi propter aliquam causam, nisi quod facit sensu ad effectum deducendi ad `bar()` munus.
/// `baz()` et `qux()` erit adhuc opus ad esse in exsequendam defined `Foo` sed possumus uti `unimplemented!` in definitionibus nostris codice patitur ut necessitati.
///
/// Et si nos vis cursus ut nos subsisto progressio unimplemented modi sunt pervenit.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Nullum sensum facit `baz` `MyStruct` sit, et ratione non habemus hic omnino.
/////
///         // Hic monstrantur "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Non ratione facit sumus aliqui hic addere possumus ad unimplemented!ad nostros omissionis.
///         // Hoc erit display: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Codice indicat imperfectum.
///
/// Prototyping Hoc potest esse utilis, si tu es, et iustus vultus ad vestra code typecheck.
///
/// Discrimen est, quod [`unimplemented!`] et `todo!` `todo!` importat dum mente ad effectum deducendi praecepta postea functionality est, et nuntium "not yet implemented", quae non facit `unimplemented!` necessitudinibus habuisse potiora.
/// Et "not implemented" est nuntius.
/// Etiam de `IDEs mark te todo!` S.
///
/// # Panics
///
/// Hoc arbitrium [`panic!`] semper.
///
/// # Examples
///
/// Ecce quaedam exempla de in-codice profectum.trait Habemus `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Unus ex nostris volumus ad effectum deducendi `Foo` types, sed etiam iustus volo ut opus in primis `bar()`.Ut codice nostro concinnare: indigemus `baz()` ad effectum deducendi, ut possimus uti `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // here exsecutionem
///     }
///
///     fn baz(&self) {
///         // lets tertius ne sollicitus sis quia nunc baz() exsequendam
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // non enim per baz() et sic est finis.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Saxum aedificavit in definitionibus.
///
/// Potissimum macro properties (firmitatem, uisibilitas, etc.), quae ex codice fons hic cum exceptione est expansion munera transferentes in tortor initibus exitibusque outputs, eorum qui munera provisum est per compiler.
///
///
pub(crate) mod builtin {

    /// Compilation deficere causas ex datis si offendit errorem nuntius.
    ///
    /// Hoc utendum tortor deberet utitur crate cum nota conditionis errore mandata erronea melius compilation providere belli condiciones.
    ///
    /// Hoc est forma [`panic!`] compiler-gradu, absente pulsante autem per errorem compilation * **quam in runtime*.
    ///
    /// # Examples
    ///
    /// Duae talia exempla sunt `#[cfg]` et unitas ambitum mutandum.
    ///
    /// Emit compiler melius est error si irritum reddit values tortor.
    /// Sine extremum branch et usque compiler emittunt ut nunquam fallar, sed error est validum in verbo non recorderis duo animationem.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Si autem emit ab compiler errore multis features est non available.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Construit RUBIDIUM, formatting macros filum alterum.
    ///
    /// Hoc est tortor munera adsumptus formatting filum `{}` litterae quibus se Adde Transierunt.
    /// `format_args!` prepares the fore ut output parametri additional sicut filum potest interpretata: et argumentis in canonicalizes unius generis.
    /// Valorem [`Display`] trait omnibus qui arma enim quod si multi venentur `format_args!` est quod non ullus formatting in `{:?}` [`Debug`] implementation poterunt ad filum.
    ///
    ///
    /// Valorem genus [`fmt::Arguments`] de hoc facit tortor.Hoc valore habitis, non potest esse unitas in [`std::fmt`] Amicus et faciendo utilis.
    /// All macros aliis Asiaticus ([`forma?:], [`write!`], [`println!`], etc.) Hoc non proxied per unum.
    /// `format_args!`, et dissimilis derived Saxum supponit, quia allocations vetera cumulare.
    ///
    /// Te potest uti valorem [`fmt::Arguments`] `format_args!` esse refert in `Debug` adiunctis et quasi `Display` videatur infra.
    /// Et in exemplum quod ostendit `Debug` et `Display` idem est forma et testus interpolatus format filum in `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Nam dui videantur documenta inspiciet [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Idem `format_args` sed addit newline finem.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Veni ad esse elit variabilis compile tempus.
    ///
    /// Et hoc tortor erit variabilis ad expand ad valorem elit in nomine compile tempore pomiferum faciens `&'static str` genus est expressio.
    ///
    ///
    /// Si is not defined amet variabilis altera, dein compilation et errorem egrediens.
    /// Ut non emittunt compile errorem, [`option_env!`] uti pro tortor.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Nuntius autem transiens per filum ut vos can mos errore moduli secundum:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Si `documentation` amet variabilis non definiuntur, ut per te sequitur error:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ad libitum: inspicit, an elit variabilis compile est.
    ///
    /// Si autem nomine praesens apud sit amet variabilis compile tempore haec expressio esse in type ego expand `Option<&'static str>` cuius est `Some` valorem variabilis in pretium elit.
    /// Variabilis si elit non est praesens, tunc expand hoc est `None`.
    /// Ecce [`Option<T>`][Option] huius generis pro magis notitia super.
    ///
    /// A diebus compile errorem egrediens non est cum usura is praesens est variabilis vel elit tortor, sive non.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates identifiers in unum identifier.
    ///
    /// Separatum est, comma identifiers tortor hac copia atque omnium, concatenates Cessurus identificador voce quae nova.
    /// Nota quod facit illud tale ut hygiene potest capere loci tortor id purus.
    /// Et ut regula generali, quae non liceat unitas in item, seu expressio loco dicitur.
    /// Quod cum modo ut referatur ad hoc Macrone variables existentium, aut munera etc modules, non definias novum unum cum eo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // n concat_idents! (New, fun, nomine)//{ } utilis ne in via?
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Vestibulum Concatenates literals in linea segmentum.
    ///
    /// Hic est numerus distingue: divisique tortor literals Cessurus `&'static str` genus repraesentat omnis dictio literals catenata hac dextra sinistra.
    ///
    ///
    /// Cras natantis punctum stringified sunt literals ut sit quasi catenata.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Qua invocatum linea numerus ampliatur.
    ///
    /// Cum [`column!`] et [`file!`], quia developers de illa unitas providebit notitia debugging ad locum intra indicem fons.
    ///
    /// Et in expanded expressio I `u32` habet, secundum genus, ut primo linea in I evaluates ad se file: in secundo II, etc.
    /// Hoc autem pertinet ad errorem vel compilers popularibus commune epistulae by editors.
    /// Linea, * qui de linea necesse est invocatione `line!` sed invocatio prima tabellas obsignaverunt invocatio `line!` tortor tortor.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Quitur quod numerus ad invocationem agmen.
    ///
    /// Cum [`line!`] et [`file!`], isti unitas debugging providebit notitia in locus, quia de fonte developers.
    ///
    /// Quod genus non habet expressio expanded et `u32` I, secundum, et primum in columna per line evaluates ad I et II secundus, etc.
    /// Hoc autem pertinet ad errorem vel compilers popularibus commune epistulae by editors.
    /// * * Agmen rediit linea necesse est invocatione `column!` sed tortor primus ducentem ad invocationem `column!` invocationem tortor.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Expands lima est nomen quod invocatum est.
    ///
    /// Cum [`line!`] et [`column!`], haec unitas debugging providere informationes circa locum intra indicem ad fontem developers.
    ///
    /// Et expanded `&'static str` expressio est typus et non ad utilitatem eorum qui `file!` rediit Scapus tortor ipsum, sed ad invocationem prima macronum, ducens ad utilitatem eorum qui `file!` tortor.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifies motivis eiusdem.
    ///
    /// Hoc autem tortor cedere `&'static str` est expressio quae genus est omnium stringification tokens Transierunt ut in tortor.
    /// Non collocantur in Syntax of restrictiones in tortor ipsam invocationem ostendit.
    ///
    /// Note quod expanded in input eventus mutare potest tokens in future.Vos videat si confidis in output.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ut autem includit UTF-8 encoded file linea.
    ///
    /// Et lima sita fasciculus recentissimus eventum respicientia (ut eodem modo sunt, invenitur modules).
    /// Provisum est per viam specialium intellectum platform compile modo ad tempus.
    /// Itaque exempli invocatio Windows cum iter non componat bene in quibus virgulas `\` Unix.
    ///
    ///
    /// Hoc macro arari poterit esse in type `&'static str` quae est expressio quae in tabella.
    ///
    /// # Examples
    ///
    /// Apud eundem, Indue files sunt duo Directory ex sequentibus:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' File:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Et inde 'main.rs' componendis currit binarii "adiós" mos procer.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Includit enim lima ut a ad byte ordinata.
    ///
    /// Et lima sita fasciculus recentissimus eventum respicientia (ut eodem modo sunt, invenitur modules).
    /// Provisum est per viam specialium intellectum platform compile modo ad tempus.
    /// Itaque exempli invocatio Windows cum iter non componat bene in quibus virgulas `\` Unix.
    ///
    ///
    /// Hoc genus `&'static [u8; N]` qui tortor non cedere in expressio illa quae in tabella.
    ///
    /// # Examples
    ///
    /// Apud eundem, Indue files sunt duo Directory ex sequentibus:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' File:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Et inde 'main.rs' componendis currit binarii "adiós" mos procer.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Expands moduli ad filum ut semita current repraesentet.
    ///
    /// Quod non potest cogitari ut semita current moduli gradum retro ducens ad crate root modules.
    /// Primum rediit elementum semita est nomen crate currently compilavit.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Evaluates Boolean compile commixtiones in papyrione, configuratione tempus.
    ///
    /// `#[cfg]` attributum praeter haec aestimatio tortor provideatur ut figuram orationis string ferunt.
    /// Geminati frequenter inducit magis credebant.
    ///
    /// Syntax est syntax huic tortor [`cfg`] est attributum.
    ///
    /// `cfg!`, dissimilis `#[cfg]`, neque quis privatur aliquo modo codice et evaluates ad verum aut falsum.
    /// Exempli omnia per cuneos if/else expressio opus sit verum `cfg!` cum adhibetur pro conditione temporis ratione habita est, denuo considerandi quod `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parses autem est expressio emendationem fasciculi inspiciendum, nec item legitur ex contextui.
    ///
    /// Sita est tabella, quae ad quaestionem fasciculus recentissimus (ut eodem modo sunt, invenitur modules).Et platform specialium intellectum modo provisum est iter compile ad tempus.
    /// Itaque exempli invocatio Windows cum iter non componat bene in quibus virgulas `\` Unix.
    ///
    /// Hac tortor saepe malae idea parsed veluti si lima quod est futurum in codice unhygienically circuitum.
    /// Munera variables an non consequuntur ens per hoc quod ex diversis variables tabella vel expectata sunt munera quae habent idem nomen, si in current lima.
    ///
    ///
    /// # Examples
    ///
    /// Apud eundem, Indue files sunt duo Directory ex sequentibus:
    ///
    /// 'monkeys.in' File:
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 'main.rs' File:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Atque inde 'main.rs' Compiling currit mos procer "🙈🙊🙉🙈🙊🙉" binarii.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Asserit est expressio a Boolean `true` ad runtime.
    ///
    /// Hoc si provisum invocabo [`panic!`] tortor neque existimari potest, ut expressio `true` in runtime.
    ///
    /// # Uses
    ///
    /// Sedatus sunt assertiones semper, et in utroque CIMICO release builds et non erret.
    /// See [`debug_assert!`] quia assertiones sunt non default enabled in release builds a.
    ///
    /// INTUTUS codice auctores currere-time vigentem repetere, ex `assert!` invariants ut, si posset ducunt ad unsafety violare.
    ///
    /// Alia est `assert!` usum includunt casibus, exigere ac testis, nunc currere in tutum invariants codice (quorum non consequuntur contra in unsafety).
    ///
    ///
    /// # more Messages
    ///
    /// Hoc tortor habeat species secunda, ubi per mos panic nuntium non potest esse provisum est vel ad formatting rationes.
    /// Syntax [`std::fmt`] Ecce enim haec forma.
    /// Format rationes quae non modo ea quae dicebantur aestimandas si assertio sequitur.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // nuntius ista quod est in panic stringified pretii expressio est data.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // sit ipsum simplex function
    ///
    /// assert!(some_computation());
    ///
    /// // consuetudinem confirmare sermonem
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline ecclesiam.
    ///
    /// Legi enim [unstable book] usus.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM inline-style ecclesiam.
    ///
    /// Legi enim [unstable book] usus.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Inline amet gradu ecclesiam.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Transierunt vexillum&Manuscripts in tokens output.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Et dat Disables investigabiles viæ functionality propter debugging alia unitas.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Tortor trahunt attributum applicare ad nomen utentis.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Attributum munus tortor applicari ad hoc to turn in unitas test.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Tortor applicantur ad munus est attributum vertere velit fermentum consectetur est in test.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Et ex `#[test]` `#[bench]` unitas implementation in detail.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Vestibulum tortor applicari ad illud attributum, ut subcriptio ut a global allocator.
    ///
    /// Vide et [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Item applicantur suus servat semita ut si is passed figuris, aliud quod aufero is.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Expands `#[cfg_attr]` tribuit, et omnium `#[cfg]` in codice applicari ad fragmentum suus.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Effusus implementation in detail `rustc` compiler: Non utuntur.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Effusus implementation in detail `rustc` compiler: Non utuntur.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}