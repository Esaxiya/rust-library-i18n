//! Componibile asynchronous iteration.
//!
//! Si autem asynchronous futures pendo, tunc sunt asynchronous iterators fluminum.
//! Si inveni te tu cum quadam collectione asynchronous genus suum et praestare necesse est operationem in elementis collectio inquit, cito currere in te 'streams'.
//! Fluminibus asynchronous onerati estis in Rust obtinuit codice, ut de ea cognoscere valet.
//!
//! Interim, antequam aperiam magis, qualiter fiat in cuius moduli rationem Disputatio de Christo est;
//!
//! # Organization
//!
//! Hic lacinia magna late verat per genus;
//!
//! * [Traits] pars media sint hi fluvii traits definire quaenam illa sint quae potes.Quemadmodum autem traits haec dignitas extra pellem pilosam in studio tempus.
//! * Quidam basic functions hac in re utilia vias ad creare fluminum.
//! * Qui saepe types Structs reditus de variis huius modi'straits moduli.Tu enim plurimum vis aspicere creans `struct` modus potiusquam `struct` ipsum.
//! Quod de more detail enim, videbis, [Implementing Fluvius](#foveant, amnis).
//!
//! [Traits]: #traits
//!
//! Id est!Lets usque ad fluenta plenissima.
//!
//! # Stream
//!
//! Cuius moduli est [`Stream`] cor et anima trait.Nucleum [`Stream`] vultus amo huic:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Secus `Iterator`, `Stream` distinguit inter modum quo [`poll_next`] `Stream` adhibetur, cum in effectum ducenda est, quae adhibetur in perussi et (to-be-implemented) `next` modum flumine valles.
//!
//! Consumptores `Stream` tantum postulo `next` considerans quod, cum dicitur, quae tribulos future refert ad `Option<Stream::Item>`.
//!
//! Et future redierat ab `next` non modo cedere `Some(Item)` sicut sunt elementa, et semel hinc omni exhausta esse non cedere `None` indicant iteration Consummatum est.
//! Erant 'expectans asynchronous si quid est in proposito, quod cedere paratus sit future exspectabo amnis ad usque adhuc.
//!
//! Fluminum potest eligere singula concitata ad rebellandum iteration, et ut vocant `next` iterum et iterum `Some(Item)` non cedere tandem in aliquo puncto.
//!
//! [`Stream`] Caesariensi est definitio includit multis aliis modi ut bene, sed default modi ædificavit super [`poll_next`], et sic eas ad vos adepto liberum.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Fluvius Implementing
//!
//! Flumine duobus partum vestri vestigia cursu ad partum `struct` statum et quia `struct` [`Stream`] foveant.
//!
//! Et quod faciamus amnis nomine `Counter` narrauerit `1` ad `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Primum, quod efficere;
//!
//! /// Fluvius autem unus qui a comitibus Quinque
//! struct Counter {
//!     count: usize,
//! }
//!
//! // Nos volo noster comitem incipere unum, ita lets addere new() modum ad auxilium.
//! // Et hoc non est simpliciter necesse, nisi sit convenient.
//! // Notate `count` imus at nulla turpis `poll_next()`'s unde infra videbimus.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Deinde pro nostris autem `Stream` effectum deducendi `Counter`:
//!
//! impl Stream for Counter {
//!     // computatis erimus in usize
//!     type Item = usize;
//!
//!     // poll_next() quod solus modum requiratur
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Incremento nostrae comitem.Hoc est cur interdum at, nulla.
//!         self.count += 1;
//!
//!         // Reprehendo ad animadverto si youve 'perfecti sumus aut non est numerus.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! * * Piger et fluminum.Hoc flumine quod creare non _do_ multus.Nihil vere fit `next` usque ad vocant.
//! Est aliquando cum de creando amnis fontem confusione solum pro sua parte effectus.
//! Et compiler monent Nos autem de hoc genere morum;
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;