//! A opus mutuam Faesulas ad moduli data.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait pro fœnore data.
///
/// In Rust est communis ad genus in ut providere diversis signorum usum diversis casibus.
/// Sicut administratione est et repono locum convenientem valorem pro certo designari posset tamquam elegit usum vel per monstratorem typus ut [`Box<T>`] [`Rc<T>`].
/// Quid ultra haec generis involucris quae potest esse in type, quidam genera providere oculorum lumine ad libitum datis potentia pretiosi functionality.
/// Exemplum enim tam genus quam quod est [`String`] adiungit basic facultatem ad porrigendum confer filum [`str`].
/// Et hoc necesse est simplex requirit observatio additional notitia, aptissima existimatur filum.
///
/// Haec types providere accessum ad notitia underlying quae ad rationem per se data.Qui ait non esse, mutuati 'id genus.
/// Puta, cum sit [`Box<T>`] potest mutuati `T` [`String`] potest `str` mutuati.
///
/// Types exprimunt mutuo acceperam quod aliquid possit esse in type `T` `Borrow<T>` in effectum ducenda, nec sine est ad `T` in modum [`borrow`] trait est.A liber type est diversus typus est quod mutuari.
/// Si velit mutuari et mutabiliter genus-permittens data est fundamentum immutabile, quod potest etiam [`BorrowMut<T>`] effectum deducendi.
///
/// Porro cum providing implementations traits pro additional est, utrum haud animadversa nequeunt ut in illis conversari identical underlying illis autem secundum sensum agendi genus est genus repraesentativum illius subiecti.
/// Buy typically utitur `Borrow<T>` cum codice identical ex sensualibus quae sunt harum mores additional trait implementations.
/// His insuper trait bounds traits verisimile videri.
///
/// Maxime `Eq`, et `Hash` oportet `Ord` equivalent ad cogam adsumptumque owned values: `x.borrow() == y.borrow()` dare debet sicut idem effectus `x == y`.
///
/// Genus codice Quod si modo oportet enim omnia genera opus potest providere a ad genus related `T` est magis saepius quod magis types [`AsRef<T>`] ut salva sit effectum deducendi.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Collectio est data, [`HashMap<K, V>`] claves habet utrumque, et valores.Si enim clavis est notitia Iesu in ipsam administrandi rationem aliquo genere, debet esse autem possibile esse ut quaeram magis quam ad valorem usus est ad key notitia.
/// Nam exempli si key filum est ergo verisimile est veluti ruina pariter Nullam in tabula [`String`] ut, dum possibile sit usus ad quaerere [`&str`][`str`].
/// Sic, oportet `insert` operate in a dum `String` `get` oportet enim vires ut a `&str`.
///
/// Paulo facilior, quaelibet pars `HashMap<K, V>` viderem;
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // omittitur agri
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Nullam totius tabula type clavis super `K` est genus.Nullam condita cum fuerint claves quia haec tabula, hoc est habere non habet genus est key notitia.
/// Par, valorem quando fermentum a key, in tabula tali datum est, et `K` necessitates invenire rectam Nullam et vide si situla clavis iam praesenti secundum quod `K`.`K: Hash + Eq` ergo expedit.
///
/// Ubi investigatione ad valorem in tabula vero habent providere a ad `K` est sicut clavis ad investigandum est non semper requirere est possessio eius ut creare valorem.
/// Quia claves filum, `String` pretii sit quod esse sit necesse est creata iustus pro casibus in quibus tantum quaerere `str` praesto est.
///
/// Sed qui de genere est species `get` modum clavis interiore notitia, dicitur per modum signature `Q` supra.Hoc asserit `K` horum mutuo postularit a magnis postulantes ut `Q` `K: Borrow<Q>`.
/// Praeterea per `Q: Hash + Eq` exigit, ut id, quod doceat `K` et `Q` implementations sunt ad producendum illa `Hash` et `Eq` traits idem praecessi.
///
/// Exsecutionem in `get` relies maxime key ad idem determinandum per implementations `Hash` de situla Nullam scriptor valorem vocando `Hash::hash` in `Q` etiamsi illud clavis adiecimus pretii fundatur super Nullam Intellexi ex dierum ratione `K` pretii.
///
///
/// Ob quae ab Nullam nisi per aperturas murorum map `K` involventes Nullam quam `Q` enim fit alius `Q` valorem.Nam exempli gratia, habeas genus hoc cogitet sed comparatur filum involvit ASCII in suis literis causa ignoratur;
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Quia opus ad producendum eundem, duo valores aequales Nullam valorem, in opus exsequendam `Hash` ignorare ASCII si etiam:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` effectum deducendi `Borrow<str>` potest?Certe non potest conferre ad suum continebat owned per scalpere a linea filum.
/// Sed quia `Hash` alia actio non aliter agit ideo non `str` quidem `Borrow<str>` diam.
/// Si patitur alios aditus ad underlying `str` vult, quod per se non potest facere quae non `AsRef<str>` portare quis extra iudicium.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Horum mutuo postulaverit, et immutabiliter ab owned valorem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait pro fœnore, mu-tabiliter inest data.
///
/// Et haec particeps in [`Borrow<T>`] trait concedit mutuari a genus est genus ut underlying quod dedisset rerum invisibilium visibiliumque referat.
/// Vide [`Borrow<T>`] pro magis notitia ut alius a mutuo petendo genus.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Horum mutuo postulaverit, et owned ex mu-tabiliter inest valorem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}