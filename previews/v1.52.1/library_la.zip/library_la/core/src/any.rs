//! Cuius moduli rationem arma in `Any` trait qui dat `'static` cuiuslibet generis est dynamic typing runtime per reflexionem.
//!
//! `Any` se adhiberi potest accipere `TypeId`, et habeat plures features ut cum trait utendum est.
//! `&dyn Any` est (a mutuo acceperam trait object), id quod habet `is` `downcast_ref` modi, ut probetur potestas est data est de valore continebat generis et pretii ut a ad genus interiore.
//! Ut `&mut dyn Any`, illic est quoque a `downcast_mut` modum, in questus rerum invisibilium visibiliumque interiore ad valorem.
//! `Box<dyn Any>` `downcast` rationem addit, quod conversum in `Box<T>` conatur.
//! [`Box`] documenta videre est plena singula.
//!
//! `&dyn Any` Nota ut tentaret utrum tantummodo esse valorem in genus de re certa, quod non potest esse in type in test instrumentum, sive in trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Dolor indicativam habent `dyn Any`
//!
//! Una pars est animus in mores ut cum usura `Any` sicut object trait, praesertim cum, sicut species vel `Box<dyn Any>` `Arc<dyn Any>`, est simpliciter valorem vocant `.type_id()` in erunt fruges eius in quo est `TypeId`* * et non subditis trait est.
//!
//! Hoc autem non fit per conversionem dolor `&dyn Any` regula, in loco qui in object `TypeId` redabit ad rem.
//! For example:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Plus vestri 'vis ut verisimile est:
//! let actual_id = (&*boxed).type_id();
//! // ... hoc est;
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Considerans enim statu in quo vis valore Transierunt autem log et ad munus.
//! Scimus qui valorem erant 'opus in Notice instructus est, sed nescimus ad certum genus.Volumus ad esse quaedam specialis curatio rationes in hac causa aestimet ante excudendi sicco funiculi longitudine sua pretii.
//! Nescimus debebat verus valorem genus nostrum compile ad tempus, ut non splendor in loco necesse est ut runtime.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger ad munus illius generis instrumentis Notice nihil.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Try ad nostrum convertendum valorem ad `String`.
//!     // Si bene volumus pretium output in tam longa String`.
//!     // Si non: suus alteram rationem: iustus procer eam nudam.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Hoc munus velle log prior ad faciens opus ipsius parametri sunt cum eo.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... alia facies opus
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// quis trait
///////////////////////////////////////////////////////////////////////////////

/// A trait exposito enitar multo dynamic typing.
///
/// Most types `Any` effectum deducendi.Autem, si habet quod genus a non-`'static` non referat.
/// Ecce enim pro magis details [module-level documentation][mod].
///
/// [mod]: crate::any
// Hoc non est periculum trait, etsi impl solus est enim confidunt in speciali suus'sCode `type_id` munus in tutum (eg, `downcast`).Plerumque vocatio illa se quaestio esse: sed quod tantum impl linteamen opertorium de `Any` est implementation, alius potest codice `Any` effectum deducendi.
//
// Hoc tamen probabiliter potuimus trait statio male fida-non est fractio causa, quia omnia control implementations-sed hoc non eligere ad quod suus 'vere non necessarium utrumque users et confundamus ibi circa distinctionem modi et statio male fida traits statio male fida (id est, fore tutum `type_id` esse appellare, sed non indicant, ut verisimile vis talis in documentis).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `TypeId` accipit qui autem `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Extensio enim Any modi trait obiecti.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Ut est effectus eg, typis inde conjunctio rumpat quis filum potest adhiberi cum `unwrap`.
// Tandem amplius operatur upcasting celeritate indigebant.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// `true` refert cohibenti, si eiusdem generis est sicut `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // `TypeId` adepto hoc genus ad hoc munus est instantiated.
        let t = TypeId::of::<T>();

        // Get `TypeId` ad genus in trait object (`self`).
        let concrete = self.type_id();

        // Compare in utraque istarum 'TypeId`s aequalitatem.
        t == concrete
    }

    /// Alicuius refert ad valorem si est genus ad cohibenti, `T` aut `None` si non est.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // UMBRA: sicut sedatus sunt vel ostendere in quanto discrimine recte genus et habentes fiduciam super nos
            // nam quod saluti quaecumque reprehendo amet genera quamque;alius impls non est impl nostra cum repugnat.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Mutabilia autem quidam refert ad valorem cohibenti si genus est `T` aut `None` si non est.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // UMBRA: sicut sedatus sunt vel ostendere in quanto discrimine recte genus et habentes fiduciam super nos
            // nam quod saluti quaecumque reprehendo amet genera quamque;alius impls non est impl nostra cum repugnat.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Genus `Any` perveniat ad modum definitur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Genus `Any` perveniat ad modum definitur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Genus `Any` perveniat ad modum definitur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Genus `Any` perveniat ad modum definitur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Genus `Any` perveniat ad modum definitur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Genus `Any` perveniat ad modum definitur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// Atque modi TypeID
///////////////////////////////////////////////////////////////////////////////

/// Data publisher `TypeId` A repraesentat in generis.
///
/// Singuli obiecti `TypeId` opacum quid patitur inspectio talis operatio interius non permittit prima Clonatio comparatione excudendi ostendens.
///
///
/// A `TypeId` sit amet nisi types qui adorant sculptilia, `'static` praesto est: sed haec remota sunt in future limitatione, constituere potest.
///
/// Dum `TypeId` `Hash` effectum adducit, `PartialOrd` et `Ord`, illud memorabile est quod inter veritatem et sensisse, et ordinis hashes Rust solvo.
/// Freti cave eis de medio vestri codice?
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Refert ad `TypeId` ex genere generis haec est munus apud instantiated.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Et nomen sicut genus refert filum secare.
///
/// # Note
///
/// Hoc in animo diagnostic usum.
/// Exactam contentis in eodem format de filum redierat, et non sunt certa, alia est non-conatus est optimum description de generis.
/// Ut in fidibus `type_name::<Option<String>>()` ut rediret et `"std::option::Option<std::string::String>"` `"Option<String>"` sunt.
///
///
/// Et filum rediit potest considerari non debent esse plures species est genus a unique identifier ut describant ad idem genus nominis.
/// Similiter etiam non spondet de totius generis apparebit in filum rediit, exempli gratia currently sunt non includitur vita species.
/// Praeterea, in in output potest mutare inter versions compiler.
///
/// In current exsecutionem idem utitur in compiler infrastructure et debuginfo diagnostic sed hoc non praestatur.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Refert nomen genus valorem sicut filum-to the pointed scalpere.
/// Haec est sicut `type_name::<T>()`, sed potest esse, ubi non facile praesto, est species quantitatis variabilis.
///
/// # Note
///
/// Hoc animo in diagnostic usum.Nervi ipsis sententiis non certa forma praeter rationem sit genus maxime operam.
/// Eg vel `type_name_of_val::<Option<String>>(None)` non revertetur `"Option<String>"` `"std::option::Option<std::string::String>"`, sed non `"foobar"`.
///
/// Praeterea, in in output potest mutare inter versions compiler.
///
/// Non trait propono Hoc munus obiecti, prout scilicet `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` redire possunt; sed non `"u32"`.
///
/// Identifier a unique nomen generis et considerari debet, ne de generis;
/// types plures sint eiusdem generis nominis.
///
/// In current exsecutionem idem utitur in compiler infrastructure et debuginfo diagnostic sed hoc non praestatur.
///
/// # Examples
///
/// Integer procer per default velut innatant typus.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}