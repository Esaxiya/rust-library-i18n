#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// Et versionem [Unicode](http://www.unicode.org/) est forms `str` modi sunt secundum partes et `char`.
///
/// Novi deinde versions of forms dixit assidue et dimisit omnes modi non sunt in bibliothecam vexillum fretus forms sunt renovata est.
/// Ideo quidam ex mores et `char` `str` modi ac mutat valorem huius constant supra tempus.
/// Hic considerandum est,* * non esse mutationem fractionis.
///
/// Et versionem numerorum exponitur ratio [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Et in usus liballoc non re-exportatarum libstd.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;