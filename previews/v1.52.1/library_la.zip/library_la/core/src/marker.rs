//! Basic representing proprietatibus types traits Primitivae speciesque referebant.
//!
//! Rust specierum sic potest esse in genere varii modi utiles secundum suam partium proprietatibus maxime intrinsecis.
//! traits quorum persona dicitur haec classificationes.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Genera potest transire per terminos filum.
///
/// Adiecta huic trait determinat illud cum ipso impleri oportet.
///
/// Exemplum est genus a non-`Send` referat-block [`rc::Rc`][`Rc`] computatis.
/// Si relatorum duos temptando quidem satis cDNA clone: [`Rc`] dicit quod ipse in parte referat counted-valorem, tentant ut update ut non referat ad comitem simul, quod non est [undefined behavior][ub] [`Rc`] quod uti res nuclei.
///
/// Consobrino suo [`sync::Arc`][arc] nuclei res facit, uti, (quidam supra caput fraude) `Send` est ita.
///
/// Vide [the Nomicon](../../nomicon/send-and-sync.html) pro magis details.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Types motu aequabili magnitudine notum compile ad tempus.
///
/// Omnes implicatum in genus parametris tenetur ex `Sized`.Est specialis syntax `?Sized` adhiberi potest, ut aufero is tenetur, si suus, non usurpare.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // instrúite FooUse(Foo<[i32]>);//error: non implemented amplitudo pro [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Et `Self` implicite rationem una exceptio est in trait.
/// A trait implicatum `Sized` non habet hic tenetur quod non potest habere [object trait] s, ubi per definitionem, in toto opere fieri oportet trait implementors, et sic posset esse aliqua magnitudine.
///
///
/// Cum Rust dabit tibi ad trait `Sized` alligabo, et non potero ad eam formet trait postea object:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // dimittam y: = &dyn Bar &Impl://errorem: et trait `Bar` in obiectum non fecit
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // defectu puta quod requirit `[T]: !Default` evaluatable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Habitasse potest esse mediocri, dynamically "unsized" ad genus.
///
/// Exempli gratia ordinata mediocri genus `[i8; 2]` ad effectum adducit `Unsize<[i8]>` et `Unsize<dyn fmt::Debug>`.
///
/// Omnes artificio implementations `Unsize` compilator providentur.
///
/// `Unsize` est quia implemented:
///
/// - `[T; N]` est `Unsize<[T]>`
/// - `T` Cum autem `Unsize<dyn Trait>` `T: Trait`
/// - `Foo<..., T, ...>` Si enim `Unsize<Foo<..., U, ...>>`;
///   - `T: Unsize<U>`
///   - Foo quod instrúite
///   - Ultimum tantum generis est ager `Foo` involving `T`
///   - `T` Non pars aliqua alia species agri
///   - `Bar<T>: Unsize<Bar<U>>`, si ager `Foo` est ultimum genus `Bar<T>`
///
/// `Unsize` una cum adhibetur [`ops::CoerceUnsized`] "user-defined" patitur ut quae scripta sunt ut [`Rc`] dynamically mediocri-typus.
/// Et videre [DST coercion RFC][RFC982] pro magis details [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Et in exemplum trait requiritur constantium Matches.
///
/// Quia genus trahit `PartialEq` aliquem effectum adducit statim trait est:* * regardless of-genus parametris, sive ad effectum deducendi `Eq`.
///
/// Si enim `const` Item continet aliquid huiusmodi, quae non est effectum deducendi his trait ergo ut genus vel (1.) non est effectum deducendi `PartialEq` (id est assidue nec providere, ut comparationis modum, quem codice generation assumit praesto), vel (2.) ea vasa *sui `PartialEq`* versio (id conforme non est, in qua structuralem aequalitatem collatio).
///
///
/// In missionibus utrumque supra talem damnamus constans usu par exemplum.
///
/// Ecce etiam in [structural match RFC][RFC1445]: et egressi de [issue 63438] quod motivated, secundum proprietatem huic consilio trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Et in exemplum trait requiritur constantium Matches.
///
/// Quod genus hoc trait effectum adducit quis sponte `Eq` pinguia concipiunt,* * regardless of an genus parametris ad effectum deducendi `Eq`.
///
/// Operantur circa haec a hack ratio limitationis nostra generis.
///
/// # Background
///
/// Volumus eget par ratio non est in genere substantiae attributum consts `#[derive(PartialEq, Eq)]`.
///
/// Per idealem magis nos could reprehendo quod postulationem tantum a genus reprehendo quod dedisset et arma `StructuralPartialEq` trait *et* in `Eq` trait.
/// Tamen non possis id ADTS `derive(PartialEq, Eq)`* * faciam, et erit in causa ut compiler volunt accipere, quod constant, et tamen non est genus ad effectum deducendi `Eq`.
///
/// Est enim sic causam;
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Est quaestio de codice super `PartialEq` effectum deducendi non est `Wrap<fn(&())>`, neque `Eq`, quia idem est dictu est < 'a> fn(&'a _)` does not implement those traits.)
///
/// Ergo ipsum non diam ac simplicem `StructuralPartialEq` `Eq` ceptum.
///
/// Gyrum hack ut hec duo traits usum injiciuntur et `#[derive(Eq)]`) reprehendo utroque procedit (`#[derive(PartialEq)]` adsunt utramque partem parem structuralem reprehendo.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Types cuius valores decursu duplicata simpliciter per exscribend testatem bits.
///
/// Per default, sunt vincula variabilis, semantics moventur.In aliis verbis:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` quae movetur in `y`, et ideo non potest esse
///
/// // println! ('}{: ? "x);//error: use of motum valorem
/// ```
///
/// Sed `Copy` Si autem genus instrumenta, has pro suus 'effingo semantics';
///
/// ```
/// // Trahunt enim possumus `Copy` implementation.
/// // `Clone` et hoc requiritur ut suus 'a supertrait de `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` est exemplum `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Est momenti est quod per duo exempla sunt, cum sola differentia, num liceat accedere `x` es post carminibus Marcianis.
/// Sub cucullo et frenos sequitur quod moventur a exemplar memoriam transtulerunt quamuis interdum a dolor.
///
/// ## Quo modo deducendi `Copy`?
///
/// Sunt duo modi `Copy` ad effectum deducendi vestri genus.Est simplicissimum ut `derive`;
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Potes `Copy` effectum deducendi et manually `Clone`;
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Est differentia minima, et super genus parametris tenetur `Copy` `derive` belli est etiam ponere, quod semper est, non desideravit.
///
/// ## Et distinctio `Copy` `Clone` quid?
///
/// Factum tacite Copies, exempli parte sicut de assignatione `y = x`.Mores autem non `Copy` overloadable: et ideo semper aliquis simplex, sapiens exemplum frenum.
///
/// Est actio Cloning expressa, `x.clone()`.Exsecutionem in [`Clone`] praebere potest ullum genus mores, necesse habes duplicare values tuto possent.
/// Exempli gratia, exsecutionem [`Clone`] [`String`] enim necesse est quod effingo ad in-linea quiddam pointed in eum.
/// A valores tantummodo simplex effingo [`String`] bitwise exemplum monstratorem, ducens ad liberum duplici linea descendit.
/// Quapropter [`String`] non est [`Clone`] `Copy`.
///
/// [`Clone`] supertrait de `Copy` est, et quod est omne necesse est et `Copy` [`Clone`] effectum deducendi.
/// Si enim generis est, non indiget redire implementation `*self` `Copy` ergo [`Clone`] ejus (videatur supra, per exemplum).
///
/// ## Non potest meus `Copy` cum genus sit?
///
/// A genus `Copy` possit effectum deducendi si omnes suarum inque novas abiit `Copy` effectum deducendi.Eg `Copy` potest esse quod efficere;
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Instrúite potest `Copy` et [`i32`] `Copy` est igitur ut `Copy` `Point` taxatur.
/// Sed consider
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` non possunt instruere ad effectum deducendi `Copy` quia non [`Vec<T>`] `Copy`.Si enim `Copy` conantur trahunt implementation sumus youll 'adepto an error:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// References participatur (`&T`) quoque `Copy`, sic possunt esse in type `Copy`, et cum illa procedit ex speciebus participatur references `T`*, qui* non `Copy`.
/// Consideret instrúite, `Copy` effectum deducendi, quae possum, quod solum tenet de * * participatur referat ad non-type `Copy` `PointList` desuper:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Cum `Copy`*non* esse genus meum?
///
/// Alii genera copied non recepit.Eg `&mut T` iactat imitari partum se referat an aliased posterius mutari potest.
/// Effingo muneris duplicare ut [`String`] muneribus obeundis sint [`String`] sui quiddam, ducens ad liberum duplex.
///
/// Generalizing in casu generis aliquem effectum deduci non potest esse [`Drop`] `Copy`, quod suus 'administrandi resource aliquid praeter suum bytes [`size_of::<T>`].
///
/// Temptare si `Copy` ad effectum deducendi `Copy` non-notitia continentur in enum vel instrúite, vos mos adepto in errorem [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Cum mea generis * * debet esse `Copy`?
///
/// Et universaliter, si genus tuum _can_ effectum deducendi `Copy`, debet.
/// Memento, quamquam, quod `Copy` in effectum ducenda est pars tui in publicum generis API.
/// Genus fiet, ut, si non `Copy` in future, eam posse praeter prudentiam prudentium reprobabo `Copy` implementation modo ne per praevaricationem API mutatio.
///
/// ## Additional implementors
///
/// Praeterea, ad [implementors listed below][impls], et deducendi `Copy` types quae sequuntur:
///
/// * Item Function types (id est, inter se distincta definiuntur munus types)
/// * Munus monstratorem types (eg, `fn() -> i32`)
/// * Types ordinata; nam omnis magnitudinum, Item si effectum adducit `Copy` etiam generis (eg, `[i32; 123456]`)
/// * Tuple types, si effectum sulum component etiam `Copy` (eg, `()`, `(i32, bool)`)
/// * Agricola genera, pretii si capere non omnium quae a elit vel captum values `Copy` effectum deducendi sui.
///   Nota variables qui participatur captum a referat semper `Copy` effectum deducendi (referent etiam si non facit), in variables captum a mutabilibus non referat `Copy` effectum deducendi.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Non concedit, qui genus iactat imitari in hoc quod effectum deducendi `Copy` vita quiescit in terminis (`A<'_>`, cum a scribendi modo atque `A<'static>: Copy` `A<'_>: Clone`).
// Hie habemus id, nisi quia iam non propter paucos existentium rationibus non satis iam est, quod in `Copy` sunt in bibliothecam vexillum: et illic 'nullo modo mores ad ea confidenter id nunc.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Et impl trahunt ex trait `Copy` generating tortor.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Types cuius est tutum ut relatorum inter participes references.
///
/// Adiecta huic trait determinat illud cum ipso impleri oportet.
///
/// Et precise definitio est: `T` esse in type [`Sync`] si et solum si sit `&T` [`Send`].
/// Id est si adsit possibilitas [undefined behavior][ub] (including gentibus notitia) references cum `&T` transiens inter relatorum.
///
/// Ut debebat primitivam [`u8`] et similibus rationibus sunt [`f64`] [`Sync`] et generis continentium aggregato simplices sicut tuples, et enums structs.
/// Magis exempla basic de [`Sync`] types includit, sicut species "immutable" `&T`, et possederunt simplex mutabile est, sicut [`Box<T>`][box], [`Vec<T>`][vec] et collectio omnium aliorum generum.
///
/// (Generic [`Sync`] parametri esse necesse est esse continens [`Sync`].)
///
/// A surprising ex eo quod aliquantum definitione, quod est `&mut T` `Sync` (si `T` `Sync` est) quamquam nec illud videtur esse, ut providere unsynchronized mutationem.
/// Dolum ad esse rerum invisibilium visibiliumque post reference participatur reference (hoc est, `& &mut T`) fit legere-tantum fuerunt quasi `& &T`.
/// Genus ergo data est periculum.
///
/// Types `Sync` quæ non sunt, ut ea non-filum non-tutum "interior mutability" in forma sicut et [`Cell`][cell] [`RefCell`][refcell].
/// Hae etiam patitur mutationem continent incommutabilem commune secundum.
/// In modum exempli `set` [`Cell<T>`][cell] `&self` se et respectu partis [`&Cell<T>`][cell] Quaerit.
/// Nec modus synchronisation facit haec non [`Cell`][cell] `Sync`.
///
/// `Sync` a non-Accessit alterum virtutis exemplum monstratorem type est referat, computatis [`Rc`][rc].
/// Datum quid referat [`&Rc<T>`][rc] potes novam [`Rc<T>`][rc] clone: duco in a non-nuclei ita moderaretur referat.
///
/// Non enim casibus, ubi opus unum, tutum filum intus mutabilem intentione Rust [atomic data types] praebet, tum profeci, densis expressa per [`sync::Mutex`][mutex], et [`sync::RwLock`][rwlock].
/// Causa istarum ut nullam mutationem non gentibus data, hinc genera sunt `Sync`.
/// Similiter etiam praebet [`sync::Arc`][arc] rumpat quis filum-tutum analogon [`Rc`][rc].
///
/// Etiam intus in species nulla est mutabilitas uti [`cell::UnsafeCell`][unsafecell] serratus circum value(s) mutari potest, qui per participatur referat.
/// Hoc est assecuta [undefined behavior][ub].
/// Eg [`transmute`][CONVERTO]-ing ex `&T` `&mut T` est invalidum.
///
/// Ecce [the Nomicon][nomicon-send-and-sync] pro magis details circa `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): quas ego te terras `rustc_on_unimplemented` per notas addere olim firmamentum in beta et factum est extenditur ad reprehendo utrum est usquam a Agricola postulationem in catena, ita ut rex fieret (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nulla, ut own a mediocri genus solebat mark quae "act like" `T`.
///
/// Addit autem `PhantomData<T>` agrum tuum type genus narrat compiler tua acts ut a dit valorem in genus `T` quamquam, etiamsi non sit realiter.
/// Cum haec notitia adhibetur aliqua computatis salutem proprietatibus.
///
/// Ad altius quam ut explicandum ex `PhantomData<T>`, videbis [the Nomicon](../../nomicon/phantom-data.html).
///
/// # A facie lurida maesta nota 👻👻👻
///
/// Tamen habere FORMIDILOSUS sunt tam nomina, `PhantomData` et 'imago types' se habent, sed non convertitur.A parameter genus larva tantum generis est modularis, quae nusquam usus est.
/// Et Rust, hoc saepe in compiler est queri, et solutio est usus ad addere "dummy" per viam `PhantomData`.
///
/// # Examples
///
/// ## Tulit ludibrium insolens vita parametri
///
/// Causam fortasse maxime communia, quia usu efficere `PhantomData` est vita quam habet in usu iacuit modulo, quod typically aliqua parte statio male fida codice.
/// Eg Ecce instrúite type `Slice` quae a duobus indicibus `*const T`, scilicet ordinata esse in quodam loco significat,
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Ratio data est voluntas quam valere vita `'a` ut `Slice` `'a` superuiuere non debet.
/// Sed hoc non importatur cum in codice isto mente, quia non sunt in vita usum `'a` Et sic patet quod non est notitia, non variatur significatio.
/// Per vera compiler corrigere non possumus id agere * * tamquam per artem efficere `Slice` referat `&'a T` continebat:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Et `T: 'a` adnotatio haec rursus postulat, demonstrato aliquo, quod verum est in vita in Concept `T` `'a`.
///
/// Cum autem initializing `Slice` vos simpliciter ad pretii providere `PhantomData` `phantom` pro agro:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Genus parametris insueta expavisset
///
/// Est interdum fit, ut genus parametris, quae insolita indicant id quod habetis de notitia type instrúite "tied" est ut, etiamsi illa notitia est actu in ipsa efficere.
/// Hic Consequat ut lacus tempus in quo hoc existat apud [FFI].
/// Et alienum usum interface aures quantum ad genus `*mut ()` Rust values diversorum generum.
/// Ad inuestigandum Rust genus sumus uti instrúite phantasma esse in type parametri, quae inducitur per `ExternalResource` cantharus ansa.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Occupatio et stilla represserat
///
/// Addit in agro `PhantomData<T>` type genus of notitia indicat ut vestri generis cuius `T`.Hanc rursus genus est quod, cum vobis id delabatur, ut stillabunt genus unum vel plura de `T`.
/// Hoc est scriptor [drop check] analysis afferentem in Rust compiler.
///
/// Si enim *suum* etenim non instrúite of notitia type `T` est melius, ut referat ad genus, quasi `PhantomData<&'a T>` (ideally) `PhantomData<*const T>` vel (si modo non est vita), et quod non indicant occupavere.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler trait internum, secundum quod significat rationem et discriminants enum.
///
/// trait hic sit implemented statim, quia non addam ultra omnis generis, et ad [`mem::Discriminant`] polliceri.
/// **indefinitum est transmutare mores** inter `DiscriminantKind::Discriminant` et `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Quod de discriminant generis, oportet quod requiritur per `mem::Discriminant` bounds trait satiat.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler internum, trait solebat determinare si quis autem continet genus `UnsafeCell` intrinsecus admovendus sed non in indirection.
///
/// Hoc fit, exempli gratia `static` sive sit genus, quod est ex lege solum in memoria, vel stabilis stabilis memoria writable.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Types qui possit esse in tuto movetur postquam ferrum emineret.
///
/// Rust se habet immobilem aliquam notionem types, et considerat movet (eg, per deputationem sive [`mem::replace`]) semper tutum.
///
/// Quod genus [`Pin`][Pin] ne loco adhibetur ratio movet per genus.Indicium `P<T>` fascia involuta [`Pin<P<T>>`][Pin] non movetur ab.
/// [`pin` module] documenta videre laevo infixa pro magis notitia super.
///
/// `Unpin` trait ad effectum deducentes `T` de stercore erigens ligabat utilium off genus, qui postea concedit `T` moving ex [`Pin<P<T>>`][Pin] tecum munera, ut [`mem::replace`].
///
///
/// `Unpin` minime habet de non-consecutio notitia emineret.
/// Maxime movet [`mem::replace`] feliciter `!Unpin` data (`&mut T` operatur aliquid non iustum `T: Unpin`).
/// Tamen non possis uti [`mem::replace`] separatim involutum de notitia [`Pin<P<T>>`][Pin] intus est quod non potest in `&mut T` vos postulo ut, quod * * quae ratio est huius operis quod facit.
///
/// Igitur hoc est exemplum non modo meis oculis species in effectum ducenda `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Nos postulo ad commutabile `mem::replace` vocant.
/// // (implicitly) invocato `Pin::deref_mut` tali distributione ab habere possumus, sed ut hoc non fieri potest, quia `String` `Unpin` telis conficitur.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Hoc est trait implemented statim, quia prope omnis generis.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Smaller; A type qui non `Unpin` effectum deducendi.
///
/// Si enim per `PhantomPinned` continet genus, ita non per default `Unpin` effectum deducendi.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementations `Copy` quia ex prima genera.
///
/// Apud implementations, quod non potest non implemented in Rust `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Potest participatur references copied, sed mutabilis references * non possumus?
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}