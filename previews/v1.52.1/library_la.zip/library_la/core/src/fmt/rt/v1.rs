//! Haec module usus est internum per ifmt!runtime.Has inter structuras, ducantur ad stabilis nervis praemisit forma precompile vestit usque ad tempus.
//!
//! Ista similia `ct` suo effecerat, ut ea differunt enim dolor immobiliter leviter tribuitur Runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Fieri possit esse gratiae diei et noctis parte petitum quod formatting in mss.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indicium, relinqui contenta perpenduntur.
    Left,
    /// Indicium esse contenta dextro varius.
    Right,
    /// Indication ut centrum, varius sit contentis in eodem.
    Center,
    /// Gratia diei et noctis non esset rogatus.
    Unknown,
}

/// Used by [width](https://doc.rust-lang.org/std/fmt/#width) et species [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Cum certa literae numero, recondit in valorem
    Is(usize),
    /// Et per certa `$` `*` syntaxes, quod indicem in recondit `args`
    Param(usize),
    /// Nihil omnino mercedis
    Implied,
}