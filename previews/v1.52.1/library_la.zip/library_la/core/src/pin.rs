//! Quod acu rationes notitia memoriae situ.
//!
//! Aliquando ad ea quae nullis est movere secundum positionem eorum memoria non mutantur ita niterentur.
//! Ita tamen ut sem esset comparativum aedificationem sui, structs, quod se movere non irritam facit ad object indicibus etiam, ad ea, quae indefinita mores possent facere.
//!
//! Ad altum campester a monstratorem typus [`Pin<P>`] efficit, ut nihil de pointee `P` firmum habet locum in memoriam, intellectum non movetur, et ejus memoria non alibi quam deallocated sudatio, relinquantur.Et est dicendum, quod est pointee "pinned".Rerum plus subtilius disserunt, qui rationes in non-fixus iungere notitia emineret,[see below](#projections-and-structural-pinning) pro magis details.
//!
//! Defectu omnia in figura Rust mobilia.
//! Omnes transeuntes per types Rust sino-valorem et dolor communia monstratorem typus, talis ut repositoque atque motabilem pati `&mut T` [`Box<T>`] et collocationem isthic esse habet: non enim potest moveri ab [`Box<T>`] vel vos can utor [`mem::swap`].
//! [`Pin<P>`] monstratorem type `P` ipsa vestimenta perfundatur, ut [`Pin`]`<`[`Box`] `<T>>`Multa munera velut iusto
//!
//! [`Box<T>`]: when a [`Pin`]`<: [`Box`]`<T>> `Accipit stillarunt, so facere contentis in eodem, et accipit memory
//!
//! deallocated.Item ['Pin`]`<&T mut>' amo multus est `&mut T`.Sed [`Pin<P>`] non sit actu clients ad obtinendam veniam, ad `&mut T` [`Box<T>`] sive notitia, ex quo datur intelligi quod potest non uti res ut [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` needs `&mut T`, sed non pervenit.
//!     // Adhæsit sumus Nos non PERMUTO quae in his p.
//!     // Nos could utor `Pin::get_unchecked_mut`, sed quod non stabilieris tu causa,
//!     // Nos uti liceat ad movere quae sunt extra `Pin`.
//! }
//! ```
//!
//! Ut est dignitas revocat [`Pin<P>`] non fit * * mutata in hoc quod considerat Rust dispositis omnis generis mobilibus, compiler.Manet in quolibet [`mem::swap`] callable `T`.Potius, [`Pin<P>`] prohibet aliquid values * *(a coniectantibus uisum ad indicatores [`Pin<P>`] involutus est) non potest appellare a tali motu ab facit requirere modi, quae in eorum `&mut T` (sicut [`mem::swap`]).
//!
//! [`Pin<P>`] monstratorem typus `P` aliqua involvere possint esse solebat, et quasi [`Deref`] et [`DerefMut`] talia correspondent.A [`Pin<P>`] ubi `P: Deref` potest considerari debet ut veniam ad "`P`-style pointer" `P::Target`-ita per [`Pin`]`<: [`Box`]:<T>>`Ferrum emineret est possessio eius monstratorem a `T` et [`Pin`] `<: [` Rc`]:<T>>`Counted referendum est monstratorem a `T` ferrum emineret.
//! Enim recte, [`Pin<P>`] [`DerefMut`] atque movere nititur [`Deref`] implementations `self` de modulo tantum ultra redeundi veniam monstratorem adfixum in regula data vocatos.
//!
//! # `Unpin`
//!
//! Libero semper mobilem multimodas etiam fixus, stabilis, quia non habebat oratio innititur.Hoc includit basic types omnis (sicut [`bool`], [`i32`],&indiciorum) tam bene quam species constituitur ex solis rebus istarum.Types qui non curant de fibulae est effectum deducendi ab auto-[`Unpin`] trait quod auferret de [`Pin<P>`] ad effectum.
//! Nam `T: Unpin` [Pin``]` <`[` Box`]`<T>> `Munus [`Box<T>`] et idem numero, sicut non [Pin`:]` <&T mut> `&mut T` et predicans.
//!
//! Et nota, quod fixum-cuspis est ut typus `P::Target` [`Unpin`] solam afficit, non autem ipsa got involuta [`Pin<P>`] `P` monstratorem typus.Quia exemplum: vel si non est [`Box<T>`] [`Unpin`] habet effectum in mores de [`Pin`]`<: [`Box`]`<T>>: (Hic `T` cuspis est ut-typus).
//!
//! # Exempli gratia: auto-struct comparativum
//!
//! Ante in imus, consociata cum magis electiones et singula explicare polliceri `Pin<T>`, quaedam exempla de hoc enim quomodo utendum esset.
//! [skip to where the theoretical discussion continues](#drop-guarantee) liberum contactus nos.
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Hoc est quia auto-struct comparativum data segmentum ad agrum agro ostendit.
//! // Certiorem facere non possumus in compiler cum normalis ut referat, quasi exemplaris, non describi potest per mutuum praecepta solito.
//! //
//! // Ut potius uti rudis a monstratorem, quamquam non una, quae nota est etiam nulla, ut sciat de ea desieris extendere ad filum.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Munus autem movet ut elit redit tumulum in quo ponitur pro vita manere obiectum modo per accessum esset regula est.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // non tantum partum in monstratorem olim data est secus locum, et coram te iam non movetur etiam started
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // tuta est possessio mutare nos movet totam artem efficere
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Ut monstratorem rectam ad designandum locum, dummodo instrúite non movetur.
//! //
//! // Interim circa hoc monstratorem possunt moveri.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Quia non est effectum deducendi generis nostri Unpin, id ordinare et deficient:
//! // Mut new_unmoved Unmovable::new("world".to_string()) =let;
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Exempli gratia: duplex MOLESTUS coniunctum album,
//!
//! In duplicibus MOLESTUS coniunctum album, et non facit collectio ad elementa ipsa memoria deducendae agroque diuidundo.
//! Destinatio regitur per clientium possunt artus vivere vita brevior ACERVUS est collectio.
//!
//! Ad hoc opus omnibus suis elementum habet indicium studii successor et praedecessor noster in album.Addi possunt nisi fixus cum enim inter se elementorum motus argumentis tollit.Sed et [`Drop`] implementation non repeciare de coniunctum elementum album of indicia prædecessor et successor eius ad se removendum a album.
//!
//! Crucially Nos niti posse esse quod dicitur [`drop`].Si deallocated ad elementum sit sive non aliter vocant [`drop`] non valet, et in indicium illud a vicina sua elementa non fiet irritum, quod structuram non conteram enim data.
//!
//! Unde et venit et laevo infixa [`drop`]-related spondet.
//!
//! # `Drop` guarantee
//!
//! Fibulae est ad confidunt potest esse est aliquid in Dei notitia, in memoriam collocatione.
//! Ad hoc opus sit restricted notitia est non iustus movere;deallocating, repurposing vel aliter solebat reponunt in memoria notitia infirmatione hoc arctari homo, quoque.
//! Certa definitaque ratione, quia adfixum pugnabant data vobis ut immutatum relinquit *ponere in ejus memoria vel irritari non adepto a repurposed ad momentum, donec veniam sudatio, ubi dicitur [`drop`]*.Semel aut redit [`drop`] panics memória reddi poterit.
//!
//! Memoria potest esse a "invalidated" deallocation, sed etiam est per repositoque a [`Some(v)`] [`None`] vel elementa quaedam "kill" ut vocant [`Vec::set_len`] vector de off.Non utendo possit [`ptr::write`] repurposed ad eam rescribere sine est destructor vocant primum.Licet enim sine hac nemo notitia emineret, [`drop`] vocant.
//!
//! Hoc prorsus genus pignus est coniunctum album MOLESTUS e necessarium ad munus recte priorem sectionem.
//!
//! Notitia est hoc praestaret, quod memoria non Leak *non* sit?Est tamen non omnino bene compactis tignis elementum semper in appellare [`drop`] (eg, in posses adeo [`mem::forget`] vocant [`Pin`]`<: [`Box`]`<T>> ').In Evangelio docet in illo, coniunctum album primum duplices id elementum esset iustus manere in list.Sed ut tibi libera non est aut reuse non sunt repono *vocant [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Si genus laevo infixa usus (ut supra duo exempla), vos have ut exsisto curiosus, cum in effectum ducenda [`Drop`].Et [`drop`] `&mut self` accipit munus sed si tibi dicitur *genus* pilo antea fuit!Est sicut et statim vocavit [`Pin::get_unchecked_mut`] compiler.
//!
//! Hoc potest numquam de causa quaestio in incolumem codice quia foveant est generis que fit nudatum urbibus requirit statio male fida codice, sed ut conscientiam esse decernens facere usu laevo infixa in generis (exempli gratia a foveant aliqua operatio in [`Pin`]`<&ipsum>`seu [`Pin`] `<&mut se> ') habet consequentias pro [`Drop`] implementation etiam, si hoc vestra genus poterant ferrum emineret, oportet te tractare [`Drop`] sicut implicite taking [` Pin`]`<&Ian se> '.
//!
//!
//! Enim, te potest effectum deducendi `Drop` ut sequitur:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` bene usus non est quia est post valorem scitote quod relinquantur.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Huc accedit ipsam stilla codice.
//!         }
//!     }
//! }
//! ```
//!
//! `inner_drop` habet in munus hoc genus [`drop`]* * habere debent, ut is planto certus utor, quod vos non accidens `self`/`this` in conflictu ut in laevo infixa est.
//!
//! Quin etiam si hoc vestra generis `#[repr(packed)]`, in compilator erit circum campis ad statim movere posset stillabunt ad eos.Nam id quidem fieri possit satis arva varius.Actae ob id genus `#[repr(packed)]` non utuntur et laevo infixa.
//!
//! # Ubi incastraturae laterum quod structuralis Pinning
//!
//! Dum operantes compactis tignis ex structs, quaeritur quomodo quis potest accedere ad agros quia instrúite in modum accipit sicut qui [`Pin`]` <Struct mut&> '.
//! Quod solitum adventu est scribere: adiutor modi (ita appellatur ubi incastraturae laterum * *) rursus, quod [`Pin`]`<mut&Struct> 'in agro ad sed id genus quid habes ut referat?Numquid non ['Pin`] `<Field mut&>` seu `&mut Field`?
//! Quaeritur an eodem campis `enum` et qualis generis [`Vec<T>`] container/wrapper praeponderans, [`Box<T>`] vel [`RefCell<T>`].
//! (Quaestio haec utrique mutabilibus participatur agitur, hoc modo magis commune uti causam huc mutabilium references verbi.)
//!
//! Evenit Quod autem est actu ad auctoris de notitia structuram decernere an ferrum emineret, proiectura pro certo agro in vicem ['Pin`]`<&mut Struct>' in [`Pin`] `<&mut Field>` uel `&mut Field`.Sunt quidam cohiberi etsi, et maxime quod magna necessitate * * consistency:
//! * * neque omnes agros esse adfixum proiectus referunt, quae vel parte nudatum proiectio remoti.
//! Utrumque eiusdem fiunt agrum futurus reprehenditur?
//!
//! Ut auctor notitia de singulis provinciis, sive structuram vos adepto ut decernere "propagates" laevo infixa est ipsa cellula compleatur an non.
//! Nudatum urbibus, quae etiam vocatur "structural" propaget est, sequitur quod ad structuram per genus.
//! In his ordinibus distinguitur, ut id describere illa, quae facta est mihi magis quam elegit.
//!
//! ## * * Laevo infixa est enim: sistens descriptiones `field`
//!
//! Quae non potest videri intuitive et fixus in agris artem efficere ut non sit ex compactis tignis: sed expedit quod re facilis arbitrium: si per [`Pin`]`<mut&Field>`non sit creata nihil possunt ire nefas!Ut si illud de agro decernere sistens descriptiones fibulae non habet, omnes autem vos have ad invigilandum, ut non veniam ad partum a emit agrum illum.
//!
//! Agri possunt sine membrorum fibulae est habere modum, qui fit in proiectura [`Pin`]` <Struct mut&> 'in `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Hoc bene `field` est quia ferrum emineret non censetur.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Et `impl Unpin for Struct` ut etiam in * * etsi rationem, non est `field` [`Unpin`].Nudatum urbibus circa cogitat quod non est generis, quod non pertinet quod [`Pin`]`<mut&Field>`semper est, creatum est.
//!
//! ## Laevo infixa est,* * sistens descriptiones pro `field`
//!
//! Alteram optionem non decernere quod sit "structural" fibulae est quia `field`, uti fit, si postea instrúite ei acu affixus est ager est.
//!
//! Proiectura autem scribo hic concedit quod facit [`Pin`]`<mut&Field>`ita ut appellaretur ager testimonium reddente ei acu affixus;
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Hoc est quia bene `field` fixus est cum `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Sed fibulae sistens cum paucis extra metus est;
//!
//! 1. Et artem efficere debent esse [`Unpin`] modo si omnes agri et structuram principalem [`Unpin`].Hoc autem default, sed [`Unpin`] trait est tutum, et quasi auctor *non* et respondens instrúite est addere aliquid simile `impl<T> Unpin for Struct<T>`.
//! (Notitia quod addit in proiectura statio male fida operationem exigit codice, ne hoc quod est tutum [`Unpin`] trait non conteram in principle quod tibi non habent ut fatigo super quisquam huius: Si vos utor unsafe`.)
//! 2. Destructor Quod instrúite non est movere ex agris sistens descriptiones ejus ratio.Quanti Hoc est, quod erexit in [previous section][drop-impl]: `drop` `&mut self` tollit, sed ad artem efficere (et ex hoc habet agrorum) confixi sunt ut prius.
//!     Tibi ad cavendum ut ne quoquam de medio campi tui [`Drop`] implementation.
//!     Et particular, quae antea explicata sunt, haec opes ut vestri *non* sit instruere necesse est `#[repr(packed)]`.
//!     Vide quæ sectionem in viam per quam ad scribere [`drop`] auxiliatus sum tibi, non potest esse accidens conteram nudatum urbibus, compiler.
//! 3. Tu fac ut est nequitia peccatorum et [`Drop` guarantee][drop-guarantee]:
//!     instrúite tui statim fixus, qui habet in memoria et in nullo contentus est overwritten aut deallocated destructors contentus est.
//!     Potest esse captiosam, [`VecDeque<T>`] teste et destructor [`VecDeque<T>`] quin de omnibus quae ad alterum ex [`drop`] destructors panics.[`Drop`] violat vinculum hoc quod sine deallocated destructor dici potest ad elementorum.(Nudatum urbibus incastraturae fient [`VecDeque<T>`] non habet, hic non est causa unsoundness.)
//! 4. Operationes aliud offerre debetis moveri posset notitia typus fixus cujus campis de structuris.Nam exempli gratia, si [`Option<T>`] et ibi continet instrúite, sicut est operatio per `take` `fn(Pin<&mut Struct<T>>) -> Option<T>` generis, quod est movere operationem potest esse `T` est ex compactis tignis `Struct<T>`-nudatum urbibus, quae modo non potest esse tenens: sistens descriptiones in agro isto data.
//!
//!     Nam exempli gratia magis composita ex a moving ex data est genus veniam, quos habebat [`RefCell<T>`] si `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` modum.
//!     Et non potuimus quae sequuntur:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Haec calamitosas, id est primus pin in contentus de [`RefCell<T>`] possumus (per `RefCell::get_pin_mut`) et tunc contentus quod moventur per mutabilem post nos got referat.
//!
//! ## Examples
//!
//! Nam genus est quasi [`Vec<T>`] ambo possibilities (fabrica vel fibulae non) faciunt sensum.
//! A [`Vec<T>`] sistens descriptiones fibulae est cum posse habere impetro ut veniam modi `get_pin`/`get_pin_mut` references to elementa.Tamen, hoc non vocant patitur [`pop`][Vec::pop]* * neque in eo quod se movere ferrum emineret [`Vec<T>`] (structuram ferrum emineret) continent!Nec patitur [`push`][Vec::push], quae reallocate adeoque summa movet.
//!
//! A [`Vec<T>`] sistens descriptiones non potuit `impl<T> Unpin for Vec<T>` fibulae est quia illa quae sunt, non se pilo et [`Vec<T>`] quod movetur, cum sit pulchrum est bene.
//! Fibulae est sicut punctus habet quod in illo vector effectum in omnibus.
//!
//! Vexillum in bibliothecam regula compages fibulae sunt genera plerumque non ita fixum offerre non vestibulum.Ideo tenet `Box<T>: Unpin` `T`.
//! Hoc facit sensu ad hoc faciunt rationes pro regula, quod in `Box<T>` moventes non movent actualiter `T` et [`Box<T>`] sponte potest esse mobile (aka `Unpin`) etiamsi non est `T`.In facto, et ['Pin`]`<: [`Box`] `<T>> 'Et [' Pin`]: <T&mut> [`Unpin`] semper se, propter eandem rationem, contentis in eisdem (sunt `T`) adfixum pugnabant sunt, sed argumentis motus non se movere potest pinned data.
//! Et quia utrumque [`Box<T>`] [`Pin`]`<`['Box`]`<T>> `Fixus an contentus est independens omnino est monstratorem si fixus, hoc est,*non* sistens descriptiones fibulae est.
//!
//! Quando in effectum ducenda [`Future`] combinator, vos mos postulo plerumque nested futures sistens descriptiones pro fibulae est, ut vos postulo impetro ut veniam ad eos vocare references [`poll`].
//! Et si tibi combinator continere alia data est, non opus est ut ferrum emineret, vos can faciunt eos agros non sistens descriptiones ergo gratis accedere et ad rerum invisibilium visibiliumque referat etiam si vos iustus have [`Pin`]`<&mut se>`(quae ut in tuo [`poll`] implementation).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// A monstratorem ferrum emineret.
///
/// Hoc fascia quaedam regula circa id quod facit regula sua pretii "pin" in loco, ne valorem indicatorum referenced ex eo quod movetur, nisi ea ad effectum adducit [`Unpin`].
///
///
/// *Quia documenta videre [`pin` module] vim explicandam conferunt et laevo infixa.*
///
/// [`pin` module]: self
///
// Note: et infra `Clone` trahunt insania est causa quod illud esse ad effectum deducendi
// `Clone` commutabilis p.
// Vide <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> pro magis details.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Sequuntur implementations non accipitur ut ne sanitas proventus.
// `&self.pointer` Ne implementations trait untrusted pervia.
//
// Vide <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> pro magis details.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// `Pin<P>` aliqua notitia de novo fabricare circa monstratorem genus est quod instrumentis [`Unpin`].
    ///
    /// Secus `Pin::new_unchecked`, hic salvus esse modum quoniam monstratorem type `P` dereferences ad [`Unpin`] quod auferret ab laevo infixa polliceri.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // Salutem et cum coniectantibus uisum ad valorem `Unpin` est, et non habet iudicium
        // nudatum urbibus circa.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Unwraps `Pin<P>` reversus est subjecta monstratorem.
    ///
    /// Hoc requirit ab hac notitia intus est `Pin` [`Unpin`] ut possimus ignorare, cum unwrapping invariants laevo infixa est.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// `Pin<P>` circa construere novum aliquid ad genus, quod a data sit vel non effectum deducendi `Unpin`.
    ///
    /// Si `pointer` dereferences ad `Unpin` generis, debet esse pro `Pin::new`.
    ///
    /// # Safety
    ///
    /// Hoc conditor parum tuta nobis pignus quod notitia potest ostendi per `pointer` ei acu, idest ut notitia repono eius non movetur neque valet ad eam sudatio, relinquantur.
    /// Si pignus non elit `P` punctis componi `Pin<P>` fixus est API violato postea contractum perducat (safe) Proin vitae operationes.
    ///
    /// By usus est hoc modo: tibi enim faciens, et promise de `P::Deref` `P::DerefMut` implementations si non est.
    /// Maxime `self` sunt motus ex argumentis et `Pin::as_mut` `Pin::as_ref` beatam spem et regula `DerefMut::deref_mut` et fixus in * `Deref::deref` eae invariants nudatum retinere.
    /// Sed et vos modum promise patronatum appellans hoc quod reference `P` dereferences ut non movetur ab iterum;praecipue impetrare non posset exire `&mut P::Target` et secundum id (uti exempli [`mem::swap`]).
    ///
    ///
    /// Exempli gratia `Pin::new_unchecked` vocant est in `&'a mut T` quia non stabilieris tu dum eam suspenderet non possunt datis vita `'a` te non habes potestatem esse vel petendi ferrum emineret, cum ea non tenentur `'a` terminos:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Etiam hoc intelligo pointee `a` movere poterit.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Mutata in inscriptio est: In `a` b` in acervum socors, et `a` got ferrum emineret, ut antea diximus, etsi motus?API sumus violare laevo infixa est contractus.
    /////
    /// }
    /// ```
    ///
    /// Valorem A, olim fixus: oportet semper fixus remain (nisi sui generis instrumentis `Unpin`).
    ///
    /// Similiter et in vocantem `Pin::new_unchecked` `Rc<T>` non stabilieris tu aliases quod non potest esse subiectum, non ut eodem, quae data est autem casso modum:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Hoc potest intelligi pointee iterum moveretur.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Si `x` secundum aliam nobis data est fixus est mutabilis secundum quod videri posset movere nos exemplo.
    ///     // API violare sumus laevo infixa est contractus.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Quantum recipit ex communi adfixum adfixum monstratorem.
    ///
    /// Haec ad modum generalis est de `&Pin<Pointer<T>>` `Pin<&T>`.
    /// Tuto, ut ex contractu `Pin::new_unchecked` est motivum non pointee `Pin<Pointer<T>>` omnia creavit.
    ///
    /// "Malicious" similiter per contractus `Pointer::Deref` implementations `Pin::new_unchecked` excludi.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // Salutem et videamus hoc munus omnia documenta super
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Unwraps `Pin<P>` reversus est subjecta monstratorem.
    ///
    /// # Safety
    ///
    /// Hoc munus esse tutum.Quam tibi praestare et in regula permanere tractare `P` ut veniam post te hoc munus vocatis, ita ut in invariants `Pin` genus non potest.
    /// Signum inde `P` si uti non retineant invariants nudatum est violatio API postea contractum perducat (safe) Proin vitae operationes.
    ///
    ///
    /// Si enim data [`Unpin`] underlying, [`Pin::into_inner`] debet esse in loco.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Accipit consertus sit mutabilis hoc adfixum pugnabant referat monstratorem.
    ///
    /// Hoc est quoddam ad modum ex `&mut Pin<Pointer<T>>` `Pin<&mut T>` est.
    /// Tuto, ut ex contractu `Pin::new_unchecked` est motivum non pointee `Pin<Pointer<T>>` omnia creavit.
    ///
    /// "Malicious" excluditur per implementations `Pointer::DerefMut` similiter `Pin::new_unchecked` contrahendum.
    ///
    /// Haec methodus utile ubi vocat ad munera multa facitis quae consumunt pinned genus.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // age aliquid
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` `self` consumit, ut in reborrow `Pin<&mut Self>` per `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // Salutem et videamus hoc munus omnia documenta super
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Assignatis suis novam in memoriam valorem post adfixum pugnabant referat.
    ///
    /// Hoc adfixum pugnabant overwrites notitia, sed quod est okay: sudatio currere in conspectu ejus destructor overwritten esse, ut nihil adfertur quo minus violare laevo infixa.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Pin surculis construere novum, destinata ab intus valorem.
    ///
    /// Exempli gratia, si volebant accipere `Pin` quod de agro, vos could utor is ut obvius quod agri est in una linea codice.
    /// Sed cum plures Gotchas "pinning projections";
    /// nam singula illa amplius documenta videre [`pin` module] topic.
    ///
    /// # Safety
    ///
    /// Hoc munus sit tutum.
    /// Debes obligandae fidei in notitia vos revertetur non moventur, ut diu ut ratio movet aestimatione (exempli gratia quia unus ex agris illius valorem) est, et quoque quae non moventur ab argumentum non acceperis possidendam munus autem intus.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // Consulens saluti contractus sit `new_unchecked`
        // 'in nomine alicujus RECENS.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Secundum communem habet de acu.
    ///
    /// Quia licet non sit tutum communis respectu exire.
    /// Sed hic videtur esse causa interiori mutabilitas uero, quam is ex `&RefCell<T>` `T` movere.
    /// Sed quamdiu hoc est non a forsit quod non est eadem notitia etiam est a `Pin<&T>` ostendere in quanto discrimine ac `RefCell<T>` non dimittet vos partum a veniam ad singula contenta in eodem.
    ///
    /// Adhuc enim et vide disputationem a ["pinning projections"] singula.
    ///
    /// Note: `Pin` et ad effectum adducit `Deref` scopum, qua solebat accedere possunt ad interiorem valorem.
    /// Tamen non `Deref` praebet reference Sicut enim vivit quamdiu est in horum mutuo postulaverit `Pin`, non est vita in se `Pin`.
    /// Hoc modum `Pin` concedit transferentes in eisdem referat de vita `Pin` sicut originale.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Hoc eodem vita `Pin<&mut T>` in `Pin<&T>` conuertitur.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Accipit mutabilem uerteretur interius ad hoc data est `Pin`.
    ///
    /// Et hoc requirit, quod in notitia est interius id `Pin` `Unpin`.
    ///
    /// Note: Et `Pin` ad effectum adducit `DerefMut` notitia quae non possunt accedere ad interiorem pretii.
    /// Sed `DerefMut` praebet tantum referat illam in horum mutuo postulaverit, dum vivit, sicut ex `Pin` non est vita in se `Pin`.
    ///
    /// Hoc modum `Pin` concedit transferentes in eisdem referat de vita `Pin` sicut originale.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Accipit mutabilem uerteretur interius ad hoc data est `Pin`.
    ///
    /// # Safety
    ///
    /// Hoc munus sit tutum.
    /// Notitia neminem movere debet praestare de munere mutabilis secundum vos dicitis quod ut in invariants `Pin` generis potest.
    ///
    ///
    /// Si autem data underlying `Unpin`, `Pin::get_mut` debet esse in loco.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Pin novum valorem ab intus fabrica destinata.
    ///
    /// Exempli gratia, si volebant accipere `Pin` quod de agro, vos could utor is ut obvius quod agri est in una linea codice.
    /// Sed cum plures Gotchas "pinning projections";
    /// nam singula illa amplius documenta videre [`pin` module] topic.
    ///
    /// # Safety
    ///
    /// Hoc munus sit tutum.
    /// Debes obligandae fidei in notitia vos revertetur non moventur, ut diu ut ratio movet aestimatione (exempli gratia quia unus ex agris illius valorem) est, et quoque quae non moventur ab argumentum non acceperis possidendam munus autem intus.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // Salutem et non SALUTATOR reus quod instigando
        // value ex hoc referat.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // Salutem sicut est `this` de valore non recepissent
        // motus castra `new_unchecked` vocari necessarium.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Ut a stabilis ex compactis tignis referat referat.
    ///
    /// Hoc incolumi `T` eo sumptum `'static` in vita numquam desinit.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // Salus: A 'static horum mutuo postulaverit non sit notitia salvatur
        // moved/invalidated donec stillaret sudatio (quae est umquam).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// A fixus referat mutabilibus mutabilia sunt ex stabilis referat.
    ///
    /// Hoc incolumi `T` eo sumptum `'static` in vita numquam desinit.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // Salus: A 'static horum mutuo postulaverit non sit notitia salvatur
        // moved/invalidated donec stillaret sudatio (quae est umquam).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: Hoc autem impl `CoerceUnsized` significat quod nulla cogente id concedit ex
// et quod impls `Deref<Target=impl !Unpin>` generis ad genus, quod impls `Deref<Target=Unpin>` est, possumus insaniam vocare.
// Quis tam impl verisimile non prius exploranda finxisset propter alias causas, quamquam, nos iustus postulo ut curam non liceat ei talia impls std in terra.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}