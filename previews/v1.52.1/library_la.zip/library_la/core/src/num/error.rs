//! Error in types integralis ad conversionem typus.

use crate::convert::Infallible;
use crate::fmt;

/// De errore genus rediit integralis cum sedatus conversionem generis defecit,.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Quam aequare poenis coerceri non elevetur sed custodiat in codice super `From<Infallible> for TryFromIntError` simile opus fit, cum per alias `Infallible` `!` est.
        //
        //
        match never {}
    }
}

/// Error rediit cum parsing quod possit integrum.
///
/// Error Error genus hoc adhibetur ut ad integrum `from_str_radix()` munera veteris typus, ut [`i8::from_str_radix`].
///
/// # potentiale causas
///
/// Inter alia causas, possunt `ParseIntError` foras propter seu agmen trahentem ducens whitespace eg in linea cum vexillum initus est adeptus a.
///
/// Per modum [`str::trim()`] dat operam, ut in nullo whitespace permanet coram parsing.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum de causa dispensare potest congregem variis erroribus parsing integer deficere.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Parsed pretium non vacat.
    ///
    /// In reliquis causis haec variant parsing vacuo poterit construi cum nervo.
    Empty,
    /// Digit continet in context irritum.
    ///
    /// Inter alia causas, et construatur cum hoc variant per parsing filum contineat, quod chari litterae non-ASCII.
    ///
    /// Hoc etiam variant `+` construi cum hoc aut erratur in filo `-` sive motu proprio sive plura media.
    ///
    ///
    InvalidDigit,
    /// Tam magnus est numerus integer generis copia Integer in scopum.
    PosOverflow,
    /// Integer est parva copia esse in type scopum integer.
    NegOverflow,
    /// Nulla erat pretii
    ///
    /// Hoc variante ut molli cum ex valore parsing est nulla filum, quod esset nefas per non-nulla species.
    ///
    Zero,
}

impl ParseIntError {
    /// Causa nimia parsing integer outputs singula.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}