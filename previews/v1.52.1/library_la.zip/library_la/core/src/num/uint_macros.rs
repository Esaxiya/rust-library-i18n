macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Minima est numerus integer, quod fieri potest per genus.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Maximum valorem per hanc potest in integrum genus.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// De magnitudine huius generis char apud bits.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// In linea segmentum converts to dato basi integrum.
        ///
        /// Nervi ad libitum `+` signum expectatur post constet.
        ///
        /// Ducit agmen trahentem, et represent whitespace errorem.
        /// Quae restant digitorum qualificatur secundum `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Hoc munus panics si `radix` sit in range de II et XXXVI.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Refert numerus binarii repraesentatione `self` in ones.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Numerus binarii refert ad zeros repraesentatione `self`.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Ducens ad zeros refert numerus binarii repraesentatione `self`.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Refert ad numerum posteriore trahens plexum zeros binarii repraesentatione `self`.
        ///
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Refert numerus binarii, in repraesentationem `self` ducens ones.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// In posteriore trahens plexum numerus binarii refert ones repraesentatione `self`.
        ///
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Frenos per vices sinistram certa quantitate, `n` involvens mutila frena integer finis resultans.
        ///
        ///
        /// Sicut `<<` Placere note quod non est eadem operatio shifting operator?
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Arte cucurrit vestibus extentis analectas ad certum ius moles, `n`, involventes in bits mutilum fit, ut inde initium quemcunque integrum affirmativum.
        ///
        ///
        /// Placere note quod sicut operatio non est simul secum lateque `>>` operator?
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Byte adversarumque ex ordine in integer.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// Sit m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Adversarumque ordo bits in integrum.
        /// Quod fit saltem frenum significant partem maxime significantes, significant, saltem secundum partem, erit summa significant secundam partem, etc.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// Sit m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Converts a magnus numerus integer endian est scriptor scopum endianness.
        ///
        /// De hoc non est magna endian-op.
        /// Bytes in parvo endian sunt tela.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// Si cfg! (=target_endian "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// Aliud}{
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Aliquantulum in endianness integer scopo endian convertit.
        ///
        /// Nulla est op endian parvo.
        /// In magna autem endian bytes tela sunt.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// Si cfg! (=target_endian "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// Aliud}{
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// De proselytis `self` endian magnum est scriptor scopum endianness.
        ///
        /// De hoc non est magna endian-op.
        /// Bytes in parvo endian sunt tela.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// Si cfg! (=target_endian "big"){
        ///     assert_eq!(n.to_be(), n)
        /// { assert_eq!(n.to_be(), n.swap_bytes()) } aliud}
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // aut non sit?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` est scriptor scopum paululum de proselytis endian endianness.
        ///
        /// Nulla est op endian parvo.
        /// In magna autem endian bytes tela sunt.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// Si cfg! (=target_endian "little"){
        ///     assert_eq!(n.to_le(), n)
        /// { assert_eq!(n.to_le(), n.swap_bytes()) } aliud}
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Integer etiam sedatus.
        /// Computus `self + rhs`: Si reversus `None` redundantiam occurrit.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Integri praeter regulam.Computus `self + rhs`, si redundantiam fieri potest.
        /// Hoc praecessi in mores cum indefinita
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // Confidenter RECENS `unchecked_add` contractus debeat sustinere salutem.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Integer sedatus subtractionem.
        /// Computus `self - rhs`: Si reversus `None` redundantiam occurrit.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Integer inoffensum subtractionem.Computus `self - rhs`, si non potest redundantiam fieri.
        /// Hoc praecessi in mores cum indefinita
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // Confidenter RECENS `unchecked_sub` contractus debeat sustinere salutem.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Integer sedatus multiplicatio.
        /// Computus `self * rhs`: Si reversus redundantiam `None` occurrit.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Integer inoffensum multiplicatio.Computus `self * rhs`, si redundantiam fieri non potest.
        /// Hoc praecessi in mores cum indefinita
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // Confidenter RECENS `unchecked_mul` contractus debeat sustinere salutem.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Integer sedatus division.
        /// Computus `self / rhs`: Si reversus `None` `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // Utilitatibus consulens sedatus supra dictum nulla div a et in se habent unsigned types
                // defectum modum divisionis
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Division sedatus Pronunciatum Euclidaeum.
        /// Computus `self.div_euclid(rhs)`: Si reversus `None` `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Sedatus residuum integrum.
        /// Computus `self % rhs`: Si reversus `None` `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // Utilitatibus consulens sedatus supra dictum nulla div a et in se habent unsigned types
                // defectum modum divisionis
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Omnique fœlicissimè gubernandi sedatus Pronunciatum Euclidaeum.
        /// Computus `self.rem_euclid(rhs)`: Si reversus `None` `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Sedatus negationem.Computus `-self`, nisi `None` `reverti se==
        /// 0`.
        ///
        /// Nota negando quod numerus quicunque integer affirmativus redundabunt.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Subcinctus sedatus reliquit.
        /// Computus `self << rhs` rediens `None` `rhs` si maior numerus aequalis `self` frenos.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Subcinctus ius sedatus.
        /// Computus `self >> rhs` rediens `None` `rhs` si maiorem numerum frenos `self` paribus.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Exponentiation sedatus.
        /// Computus `self.pow(exp)`: Si reversus `None` redundantiam occurrit.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // quia exp?=0, postremo per exp I oportet fieri.
            // Benigne aliquantulus of finalis cum exponens se, quia non est necessarium et quadrando basis sic faciam perfusis vano redundantiam.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Praeterea saturating integer.
        /// Computus `self + rhs`, saturating pro inundare consuevit in terminis numerorum.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Integer saturating subtractionem.
        /// Computus `self - rhs`, saturating terminis numerorum in loco circumfluit.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Integer saturating multiplicatio.
        /// Computus `self * rhs`, ad saturating terminis numerorum pro inundare consuevit.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Integer saturating exponentiation.
        /// Computus `self.pow(exp)`, saturating in terminis numerorum pro redundat.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Praeterea (modular) involuti sumus.
        /// Computus `self + rhs`, involventes in terminus de circuitu generis.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Involuti (modular) subtractionem.
        /// Computus `self - rhs`, involventes in terminus de circuitu generis.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Involuti (modular) multiplicatio.
        /// Computus `self * rhs`, involventes in circuitu generis est terminus.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// Cras ut haec genera dividimus Donec.
        /// Et ideo quoque `u8` hic usus est.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Involuti (modular) division.Computus `self / rhs`.
        /// Pannis involutum in unsigned division division types est normalis.
        /// Involuti sumus, non est nullo modo posse accidere.
        /// Munus est, ut in omnibus operibus videntur involutio existimavit.
        ///
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Involventes division Pronunciatum Euclidaeum.Computus `self.div_euclid(rhs)`.
        /// Pannis involutum in unsigned division division types est normalis.
        /// Involuti sumus, non est nullo modo posse accidere.
        /// Munus est, ut in omnibus operibus videntur involutio existimavit.
        /// Cum integris positiva ad omnes aequaliter communi definitione separatio haec `self.wrapping_div(rhs)` par.
        ///
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// (modular) residuum involuti sumus.Computus `self % rhs`.
        /// Reliqua genera unsigned involutum est in ratione regulari ratione reliqua.
        ///
        /// Involuti sumus, non est nullo modo posse accidere.
        /// Munus est, ut in omnibus operibus videntur involutio existimavit.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Omnique fœlicissimè gubernandi involventes Pronunciatum Euclidaeum.Computus `self.rem_euclid(rhs)`.
        /// In reliqua acie tantum genera unsigned pannis modulo ratione calculo.
        /// Involuti sumus, non est nullo modo posse accidere.
        /// Munus est, ut in omnibus operibus videntur involutio existimavit.
        /// Cum enim integris probandum omnibus communem definitionem aequalis divisio haec `self.wrapping_rem(rhs)` par.
        ///
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Involuti (modular) negationem.
        /// Computus `-self`, involventes in circuitu terminus ad genus.
        ///
        /// Quia negatio non adumbrari unsigned omnibus generibus usus munus accingent (exceptis `-0`).
        /// Quia est minor values correspondentes signati generis scriptor maxime noti, quod idem est effectus valorem respondentem signati.
        ///
        /// Equivalent ad `MAX + 1 - (val - MAX - 1)` ubi nulla est maior values `MAX` correspondentes signatum est de maxime genus.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// Cras ut haec genera dividimus Donec.
        /// Quod inde huc `i8` adhibetur.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-left-liberum bitwise subcinctus;
        /// dat `self << mask(rhs)` ubi `mask` summus quo omnis removente bits of `rhs` quod esset in causa excedere bitwidth subcinctus ad genus.
        ///
        /// Ne * * Nota, quod haec eadem est rotate-reliquit;et vermicularis circumdatur a sinistra Amoveo-intra teli genus magis frenos LHS reddito locos ex altero.
        /// Ad effectum deducendi [`rotate_left`](Self::rotate_left) Primum omnia genera integrum munus, quam sit vis in loco.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SALUS et in masking bitsize et non derivare efficit, ut genus
            // ex terminis
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// - Juris-liberum Panic subcinctus bitwise;
        /// dat `self >> mask(rhs)` ubi summus omnis removente `mask` bits of `rhs` Ut faciam, ut non egredi ad subcinctus bitwidth ad genus.
        ///
        /// Nota autem, non *est* pro eodem iure trochus;de iure Amoveo-vermicularis tegmen et intra teli genus magis frenos LHS reddito locos ex altero.
        /// Primum omnium integer types effectum deducendi ad [`rotate_right`](Self::rotate_right) munus, quam sit vis in loco.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SALUS et in masking bitsize et non derivare efficit, ut genus
            // ex terminis
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) exponentiation involuti sumus.
        /// Computus `self.pow(exp)`, in terminus est genus circa involventes.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // quia exp?=0, postremo per exp I oportet fieri.
            // Benigne aliquantulus of finalis cum exponens se, quia non est necessarium et quadrando basis sic faciam perfusis vano redundantiam.
            //
            //
            acc.wrapping_mul(base)
        }

        /// + Determinat `self` `rhs`
        ///
        /// Refert enim tuple ex significat num etiam una est a Boolean arithmetica servabitur redundantiam quam fierent excogitaui.
        /// Si superfluum fuisset tunc involutum est valorem rediit.
        ///
        /// # Examples
        ///
        /// basic usus
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` gradibus pendat, `rhs`
        ///
        /// Commonstrarem redit tuple ex subtractione vel arithmeticam string cum fieret redundantia.
        /// Si superfluum fuisset tunc involutum est valorem rediit.
        ///
        /// # Examples
        ///
        /// basic usus
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Subolem computantem et multiplicatio `self` `rhs`.
        ///
        /// Commonstrarem string redit tuple multiplicationis cum fieret redundantia sive arithmetica.
        /// Si superfluum fuisset tunc involutum est valorem rediit.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// Cras ut haec genera dividimus Donec.
        /// Et ideo quoque hic `u32` adhibetur.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Cum divisor computantem `self` `rhs` dividitur.
        ///
        /// Commonstrarem tuple string redit divisoris cum fieret redundantia sive arithmetica.
        /// Nota, quod unsigned numquam exundabunt integros occurs, et secundum valorem semper `false`.
        ///
        /// # Panics
        ///
        /// Hoc autem munus panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// basic usus
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Quotus enim determinat de Pronunciatum Euclidaeum `self.div_euclid(rhs)` division.
        ///
        /// Commonstrarem tuple string redit divisoris cum fieret redundantia sive arithmetica.
        /// Nota, quod unsigned numquam exundabunt integros occurs, et secundum valorem semper `false`.
        /// Cum enim affirmativum integros omnes aequales partes communes definitiones hoc par `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Hoc autem munus panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// basic usus
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Cum `self` reliquum dividatur `rhs` determinat.
        ///
        /// Redit tuple reliquorum cum divisa sit indicans string arithmetica fieret redundantia.
        /// Nota, quod unsigned numquam exundabunt integros occurs, et secundum valorem semper `false`.
        ///
        /// # Panics
        ///
        /// Hoc autem munus panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// basic usus
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// `self.rem_euclid(rhs)` reputet quasi residuum divisionis Eucli.
        ///
        /// Cum autem tuple remittit modulo string indicatis sive arithmetica divisa inundans cum caderet.
        /// Nota, quod unsigned numquam exundabunt integros occurs, et secundum valorem semper `false`.
        /// Cum integris positivi ad omnem partem communem definitionem aequalis aequalem `self.overflowing_rem(rhs)` prorsus operationem.
        ///
        ///
        /// # Panics
        ///
        /// Hoc autem munus panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// basic usus
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negat se fashion in torrentem inundantem gloriam.
        ///
        /// Uti refert `!self + 1` involuti sumus, ad res redire valorem repraesentat, ut sic negatio pro valore huius unsigned.
        /// Nota ut unsigned positivum values redundantiam, semper sed non facit negationem 0 redundantiam.
        ///
        /// # Examples
        ///
        /// basic usus
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Relictum a se arte cucurrit vestibus extentis `rhs` bits.
        ///
        /// Redit tuple est in una cum se moverit versionem Boolean eius valorem maior subcinctus an demonstras aut quam par numerus bits.
        /// Si subcinctus valorem tam magnus est, tunc illico ereptem agnoscerent (N-1) quo valore non est numerus N addit frena feris sit ergo et valorem usus praestare hebdomadas succedere consueverant.
        ///
        /// # Examples
        ///
        /// basic usus
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Arte cucurrit vestibus extentis ius sui ipsius `rhs` bits.
        ///
        /// Redit tuple est in una cum se moverit versionem Boolean eius valorem maior subcinctus an demonstras aut quam par numerus bits.
        /// Si subcinctus valorem tam magnus est, tunc illico ereptem agnoscerent (N-1) quo valore non est numerus N addit frena feris sit ergo et valorem usus praestare hebdomadas succedere consueverant.
        ///
        /// # Examples
        ///
        /// basic usus
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Ponit se in potestate `exp`, per exponentiation quadrando.
        ///
        /// Commonstrarem redit tuple bool sive per redundantiam exponentiation cum acciderit.
        ///
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (CCXVII, verus));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Scalpe pro repono spatium overflowing_mul eventus.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // quia exp?=0, postremo per exp I oportet fieri.
            // Benigne aliquantulus of finalis cum exponens se, quia non est necessarium et quadrando basis sic faciam perfusis vano redundantiam.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Ponit se in potestate `exp`, per exponentiation quadrando.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // quia exp?=0, postremo per exp I oportet fieri.
            // Benigne aliquantulus of finalis cum exponens se, quia non est necessarium et quadrando basis sic faciam perfusis vano redundantiam.
            //
            //
            acc * base
        }

        /// Division facit Pronunciatum Euclidaeum.
        ///
        /// Cum enim integri positivi omnes aequales partes communes definitiones hoc par `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Hoc autem munus panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Reliquum quidem computantem `self (mod rhs)`.
        ///
        /// Quia secundum numeros positivum, funt communi definitione divisionem hoc par `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Hoc autem munus panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Et si `true` tantum refert `self == 2^k` aliquot `k`.
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Mox redit et minus dupliciter potest.
        // (Nam virtus 8u8 altera duorum est 8u8 et 6u8 est 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() VII==
        // 6u8.one_less_than_next_power_of_two() VII==
        //
        // Modum Haec possumus redundantiam, quod est in `next_power_of_two` redundantiam eius pro casibus tandem reversus ad maximum valorem in genus, et ob 0 0 redire potest.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SALUS: quia `p > 0`, ne possit quidem tota esse ducens zeros.
            // Subcinctus ad id modo semper, et in terminis, et processors (ut pre-Intel Haswell) plus est non-nulla est ratio cum intrinsics ctlz agentibus.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Duae potentiae quam minimum remittit `self` paribus.
        ///
        /// Et reditu valorem inundat (id est, ad genus `self > (1 << (N-1))` `uN`), panics in lusione cum eo et reditus modus release in valore 0 usque involuta est (nisi in situ, in quem modum potest redire 0).
        ///
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Minus redit quam de duobus paribus `n`.
        /// Altera rationem nisi virtus major est duorum scriptor valorem maximum, `None` est rediit, aliud in potestate duos esse involutos `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Minus redit quam de duobus paribus `n`.
        /// Si altera duorum est maior virtus quam genus valorem maximum est, et convoluta est `0` reditus valorem.
        ///
        ///
        /// # Examples
        ///
        /// Basic usus:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Integer ut revertar byte aciem memoriae repraesentare, endian (network) byte ut magna.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Memoriam revocat repraesentare byte integer quasi parum endian byte aciem ordinare.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Byte repraesentare ut memoriter reddere Integer ut byte patriis aciem.
        ///
        /// Platform est scriptor scopum endianness sicut indigena adhibetur, debet utor codice portable [`to_be_bytes`] [`to_le_bytes`] aut, pro opportunitate, loco.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, si cfg! (=target_endian "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// Aliud}{
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // Salutem quia in Const datatypes veteres ita possumus plana integri
        // transmutare eos et vestit bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // Saluti datatypes integros tam veterum possumus plana transmutant ea
            // vestit autem bytes
            unsafe { mem::transmute(self) }
        }

        /// Byte repraesentare ut memoriter reddere Integer ut byte patriis aciem.
        ///
        ///
        /// [`to_ne_bytes`] quotiens hoc potius.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// Sit num.as_ne_bytes() =KB;
        /// assert_eq!(
        ///     bytes, si cfg! (=target_endian "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// Aliud}{
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // Saluti datatypes integros tam veterum possumus plana transmutant ea
            // vestit autem bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Create indigena integer valorem endian ex byte mundis repraesentabat sicut ordinata est in endian magna.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto utuntur;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// Initus rest *=;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Create indigena endian integer valorem parum ab mundis repraesentabat sicut in byte endian ordinata.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto utuntur;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// Initus rest *=;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Create indigena a suo endian integer valorem ordinata in memoria representation quasi indigena endianness byte.
        ///
        /// Platform target scriptor usus sit sicut indigena endianness, portable vult verisimile utor codice [`from_be_bytes`] [`from_le_bytes`] aut, pro opportunitate, loco.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// Aliud}{
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto utuntur;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// Initus rest *=;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // Salutem quia in Const datatypes veteres ita possumus plana integri
        // CONVERTO illis
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // Salutem possumus semper datatypes integri plana transmutare ad veterem
            unsafe { mem::transmute(bytes) }
        }

        /// Ut nova codice potius utar
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Refert ad sensum exhibere potest ut minima huius generis char.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Ut nova codice potius utar
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Refert ad maximum valorem ut potest per hoc genus integer.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}