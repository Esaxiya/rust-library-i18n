//! Fiddling super frenum DCCLIV rati positivae IEEE.Numeros et non opus est ut teneatur manu negans.
//! Numero fluctuetur repraesentabat ac canonicis habent normalis (tfrac, exp) ipsa sit pretii, ut <sup>exp</sup> * II (I + N sum(frac[N-i] / 2<sup>i</sup>)) ubi est numerus bits.
//!
//! Subnormales paulo cerritulus et aliud sed idem adhibetur modus.
//!
//! Hic autem non pro illis represent (sig, k) f positivum est, ita ut ad pretii esse f *
//! II <sup>e.</sup>Praeter quod "hidden bit" aperte facis, huius exponentis mutat, ut dicitur in mantissa hebdomadas succedere consueverant.
//!
//! Posuit alio modo, (1) sed ut Northmanni supernatat scripta sunt hie scripta sunt ut (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! ** ** repraesentatio numeri fracti sunt (2) (1) vocamus, et per ** ** representation integralis.
//!
//! Cuius moduli rationem normalis modo tractamus numeri in multa munera.Et dec2flt consuetudines conservatively universally accipere-patiens viam rectam (Algorithm M) est valde parva et maxima numero.
//! Hoc algorithm next_float() qui facit solum opus et zeros subnormales cantharus ansa.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Adjutor trait vitare duplicatione basically omni codice enim conversionem `f32` et `f64`.
///
/// Vide autem parentis moduli doc scriptor comment in hoc quid opus est.
///
/// Nequaquam ut non umquam ** ** neque alia genera potest implemented esse extra dec2flt moduli.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Typus usus est, et a `to_bits` `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Performs rudis in naturam aliam convertuntur ad integer.
    fn to_bits(self) -> Self::Bits;

    /// Performs rudis in aliqua transmutatio de integer.
    fn from_bits(v: Self::Bits) -> Self;

    /// Praedicamentum per hoc rediens incidit.
    fn classify(self) -> FpCategory;

    /// Mantissa redibit, et exponentem signum integri.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Decodes missi sunt.
    fn unpack(self) -> Unpacked;

    /// Vesalius exacte repraesentari possunt, qui ex parvis integer.
    /// Integer non Panic si repraesentari amet facit aliud quidem umquam fiat in codice.
    fn from_int(x: u64) -> Self;

    /// <sup>E</sup> valorem X gets ad mensam a pre-computentur.
    /// Quia Panics `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Quid nomine dicit.
    /// Suus 'facillimus ut difficile codice quam intrinsics sunt praestigiae et sperans LLVM implicat constant.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Optimatium ex initibus exitibusque numeri A, qui tenetur in decimales vel nullus vel non producendum redundantiam
    /// subnormales.Probabiliter normalis punctum exponentem maximum valorem, inde nomen.
    const MAX_NORMAL_DIGITS: usize;

    /// Cum maxime significantes valore constituo digit major est in loco isto, et numerus rotundus is certe in infinitum.
    ///
    const INF_CUTOFF: i64;

    /// Cum maxime locum habet valorem minus quam significant digit punctum, hoc est numerus rotundatis vel certe nulla.
    ///
    const ZERO_CUTOFF: i64;

    /// Numerus frenos exponens.
    const EXP_BITS: u8;

    /// Numerus de bits in significand, including * * occultatum a frenum.
    const SIG_BITS: u8;

    /// Bits in significand numerus, exceptis * * occultatum a frenum.
    const EXPLICIT_SIG_BITS: u8;

    /// In maximum legalis exponentes sunt numeri fracti sunt in repraesentationem.
    const MAX_EXP: i16;

    /// Et minimam legum exponentes sunt numeri fracti sunt in representation aequiparatis, exclusis subnormales.
    const MIN_EXP: i16;

    /// `MAX_EXP` quia integralis repraesentationis, id est, cum subcinctus applicantur.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` encoded (id est, ad pondus offset)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` quia integralis repraesentationis, id est, cum subcinctus applicantur.
    const MIN_EXP_INT: i16;

    /// In normalized integralis maxime significand suum intelligibile.
    const MAX_SIG: u64;

    /// In normalized significand in integralis minima Co.
    const MIN_SIG: u64;
}

// Plerumque enim Modum habemus quo #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Mantissa redibit, et exponentem signum integri.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // + Dimensiones pondus mantissa subcinctus
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // Vestibulum omnia recte rkruppe incertum `as` modum clauditur.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Mantissa redibit, et exponentem signum integri.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // + Dimensiones pondus mantissa subcinctus
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // Vestibulum omnia recte rkruppe incertum `as` modum clauditur.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Converts to `Fp` et summa genus apparatus supernatet.
/// Subnormali non tractamus results.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f LXIV frenum est ut xe habet LXIII de mantissa subcinctus
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Circum-frenum in LXIV bits in T::SIG_BITS significand ad medium-ad-usque.
/// Non tractamus exponens redundantiam.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Adjust mantissa subcinctus
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverse de normalized numerum enim `RawFloat::unpack()`.
/// Aut si Panics significand exponentes non sunt numeri normalized enim valet.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Removere occultatum aliquantulus
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Adjust pondus et resistentiae exponente resistentiae exponente ad mantissa subcinctus
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Leave a frenum signo 0 ("+") noster numeros omnes positivae
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Subnormali fabrica.0 in A mantissa et constructs nulla conceditur.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // 0 Encoded exponens est unitas, 0 sit signum aliquantulus ut nos iustus have ut in reinterpret bits.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Cum accedere ad bignum Fp.Rounds per medium-ad-inter 0.5 et Ulp.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Nos interficiam omnes off prior ad indicem bits `start`, id est nobis subcinctus a dextra valet `start` est moles, ita etiam exponens nobis necesse est.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Quod mutilum fit per (half-to-even) fretus bits.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Invenit maximum numero fluctuetur per se rationem quam minor.
/// Non tractamus subnormales, nulla, aut underflow resistentiae exponente.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Reperio numero fluctuetur minimis maior quam se ratio.
// Haec operatio est saturating, id est, next_float(inf) ==inf.
// Secus ac pleraque est in codice Cuius moduli non hoc munus nullus manubrio infixum, subnormales et infinite constabit.
// Tamen, ut omnibus aliis Code hic non agere cum NaN et negans numeris.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Videtur quod bonum et verum, facit.
        // 0.0 quod est encoded omnis, nulla est.M m ... ubi est qui subnormales 0x000m mantissa.
        // In particular, et parvulus in hoc 0x0 subnormalis PR ... I ... et maxima est 0x000F F.
        // Minima normalis numerus 0x0010 ... 0, ita operatur etiam causam huius anguli.
        // Si ergo incrementum redundet in mantissa, gesturum ignitos serpentes ad exponentem, ut vis incrementi et bits mantissa facti nulla.
        // Quia absconditae aliquantulus placitum, hoc est etiam quod prorsus non volunt?
        // Denique f64::MAX I + I +=f 7eff ... ... 0==7ff0 f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}