//! Bignum ad utilitatem munera quia non plus sapere ad conversus in modi.

// Hoc est a frenum FIXME moduli nomen infortunatus, cum alia modulorum `core::num` importare.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Quam minores omnes truncating probandum frena minus `ones_place` errorem inducit aliquid aequale aut maius 0.5 Dig.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <Ulp 0.5
        return Less;
    }
    // Quod si reliqua bits nulla sunt, 0.5 suus '=Paul, aliter> Si 0.5 sunt ultra bits (half_bit==0), inferius et ad aequale recte refert.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Converts in ASCII filum quibus numeri ad unicum punctum `u64`.
///
/// Non checks praestare ut litteras vel per redundantiam, ergo si non SALUTATOR diligentia cuncta facite non est bogus et effectus possunt panic (etsi non sit `unsafe`).
/// Donec ut nulla vacua cordis tractata sunt.
/// Hoc munus quod existit
///
/// 1. `FromStr` in usus postulat `&[u8]` `from_utf8_unchecked` quod sit malus ac
/// 2. et eventus `integral.parse()` `fractional.parse()` musivum cum totum hoc munus magis complicated.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Converts rumpat quis filum de ASCII in bignum numeri.
///
/// Velut `from_str_unchecked`, hoc munus parser innititur in de non-esse viriditas numeri.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Et LXIV frenum in unwraps bignum quemcunque integrum affirmativum.Si maior numerus Panics.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extrahit rhoncus lupatis.

/// Index 0 significant est aliquantulus minimum et medium-range est apertum solito.
/// Si autem interrogavit Panics eliciunt bits quam magis idoneum genus in reditu.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}