//! De variis de algorithms charta.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp bits in numero significand
const P: u32 = 64;

// * * Omnium maxime proxime ad reponere corporali sumus simpliciter exponentes, ita consociata et ad condiciones et variabilis "h" omitti potest.
// Ad hoc duobus Kilobytes artium perficiendi ex spatio.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// In summa architectures, fluctuetur res habet partem in mole expressa: ergo subtilitas, in computationem per-operatio constituta sit basis.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// De x86, qui missi ad res adhibetur x87 FPU SSE/SSE2 extensiones sin autem non funguntur.
// Qui operatur FPU x87 praecisione defalta frusta LXXX Qua causa operationum frena circa LXXX cum bonis denique persona fieret duplex Veram
//
// 32/64 values frenum supernatet.Superare hac potestate FPU verbum, quod potest set ita est, et fiunt computationes desideravit textuum servent.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// A ad structuram ex tueri imperium FPU originali valorem ex Verbo, et quod potest redintegrari et compages est factus.
    ///
    ///
    /// In cuius campis x87 FPU est a XVI-subcriptio bits sunt ut sequitur:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Documenta est available in omnibus agris in Developer IA-32 Architectures Software Familia Romana (Latin Edition I).
    ///
    /// Solum agro est, quae pertinet ad sequentia codice PC est, Precision Imperii habere.
    /// Re quidem ab operibus subtilitatem FPU determinet.
    /// Set non potest esse;
    ///  - 0b00, singula accuratius id est, XXXII-bits
    ///  - 0b10, duplici cura id est, LXIV, bits
    ///  - 0b11, duplici cura extensa id est, LXXX-bits (default state) 0b01 valorem et repositum est, et non sit utendum.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // Utilitatibus consulens `fldcw` ad disciplinam esse posse, ut opus bene audited est
        // quis `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Nos sustinere Syntax per ATT LLVM et LLVM VIII IX.
                options(att_syntax, nostack),
            )
        }
    }

    /// FPU ad subtilitatem occidere agro usque ad `FPUControlWord` `T` redit.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Imperium Precision, computato ad valorem pro agro quod oportet `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // XXXII bits
            8 => 0x0200, // LXIV bits
            _ => 0x0300, // defaltam, LXXX bits
        };

        // The original de valore ut imperium ad eum restituere postea, cum in structuram `FPUControlWord` instillatur saluti fuit audiuerit compotum de `fnstcw` disciplinam in omni recte operari possit `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Nos sustinere Syntax per ATT LLVM et LLVM VIII IX.
                options(att_syntax, nostack),
            )
        }

        // Potestatem autem posuit ad ad desideravit textuum servent.
        // Hoc effectum est, per certa annorum masking et auferet (bits VIII et IX, 0x300) et quod per repositoque vexillum cura superius computavimus.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Bellerophontis apparatus usura iter ieiunium-amplitudo ea ratibus integri.
///
/// Hoc in singulari munere et extrahi possit struere bignum intenta.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // MAX_SIG comparatur ad valorem circa finem, haec est velox, cheap rejectionis (liberat, et reliquum ex codice cura underflow).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Decretorio iter ieiunium ab arithmetico esse rectam rotundatis vel sine numero bits medium Veram ea.
    // De x86 (sine seu SSE2 Inter Aquilonem et Zephyrus) requirit hanc praecisionem ad acervum x87 FPU mutata est in rounds, ut non directe ad quorum plagas 64/32.
    // Et munus accipit `set_precision` profecta curam architectures ad praecisionem ab eo profecta commode global mutationem status (sicut verbum ex imperium FPU x87).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Casus e <0 branch non est complicatam in se.
    // Negans vires consequuntur repetita, in binarii in partibus, quae superne rotundata sunt, quae facit realem (significans motibus et saepe satis!) Errores supremum exitum.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithm equitem gravatus Bellerophontem parva non-levis est numerorum analysis codice iustificamini a gratia excidistis.
///
/// Non modum clauditur, `f`` ad LXIV frenum significand est color optimus in proximam continuitatem et multiplicat illa `10^e` (fluctuetur in eadem forma).Saepe satis est ut per verum eventum.
/// Ceterum ita deinceps inter medias prope (ordinary) nanti per approximationem mixto ex duobus promunturiis error sit multiplex per aliquot lupatis.
/// Cum hoc fit, adipisicing ad ilia quae R Algorithm est.
///
/// Et factum est precise per manum "close to halfway" undulato-analysis de charta numerorum.
/// In sermonibus Domini Clinger:
///
/// > Plantam pedis: populus per turmas suas minimis expressit aliquantulus significans: est enim tenetur errorem inclusive
/// > exaggeratus durante natantes puncto X * f ^ e appropinquare in ratione.(Plantam pedis est,
/// > non enim tenetur vera errorem, sed ad approximationem vero terminus, differentia inter z et
/// > optime utitur qui proxime potest bits of significand p.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // In casibus abs(e) <log5(2^N) in fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // PROFUNDO satis magna est ad differentiam ipsorum cum in flectendis promunturiis n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// An iterative algorithm quod approximatio `f * 10^e` improves Quo fluctuetur.
///
/// Fit unum iteratione ultimo singuli propius multo timore quem convergere cursus `z0` si etiam moderatus est.
/// Fortuna, velut cum fallback in usus equitem gravatus Bellerophontem, et incipiens a approximatio off procul plus uno Ulp.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Find `x` numerorum integrorum positivorum, `y` prorsus talis sit `x / y` `(f *10^e) / (m* 2^k)`.
        // Et hoc solum vitat `e` `k` de signis nos et tolli posse `10^e` commune duorum numerorum `2^k` ad minorem.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Hoc est aliquantulus vel vitiose scriptum est quia bignum gloriaris non negans nostra numeri, ut hoc signo + valorem absolutum uti notitia.
        // Cum multiplicitas non m_digits redundabunt.
        // Si `x` aut `y` sunt magna satis ut de redundantiam opus est anxietas, tunc satis magnae sint et a factor, qui `make_ratio` redegerat fraction of LXIV vel II ^.
        //
        //
        let (d2, d_negative) = if x >= y {
            // X. Non ultra nisi clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Adhuc opus y, ut sit exemplum.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Ubi datum `x = f` `y = m` et solet et numeri `m` decimales `f` initus est repraesentare et fluctuetur significand proxime ad rationem `x / y` exaequabo `(f *10^e) / (m* 2^k)` fieri tum bina redegit potestatem habeant.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // X x=f ^*E:* II m ^ v=k, nisi quae ad redigendum potentia aliqua per partes duas.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // X 2^abs(k)*E*^ x=f, y=m hoc non requirit positivum redundantiam, quod `e` `k` negans, et quod non nisi prope fit I ad summa bona quae modo est, et `e` `k` respective minima erit.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // X=f, 10^abs(e)* * y=m II ^ c redundantiam, non potest hoc vel, videatur supra.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k):* y=m 10^abs(e) iterum reducing commune per virtutem duorum.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Cogitatione; M simplicissimum ut convertat Algorithm decimales ad supernatet.
///
/// Ratione formamus `f * 10^e` aequale igitur duabus viribus donec adgesto significand color fortis facit.
/// Quod exponens `k` multiplicatur numerus binarius numeratorem et denominatorem duabus vicibus, id semper `f *10^e` `(u / v)* 2^k` pares.
/// Et adinvenit significand nos sumus per solum opus fiet inspiciendo residuum divisionis, quae est adiutor meus in munera adhuc inferius.
///
///
/// Hoc algorithm enim Super tardum apud ipsum vel apud `quick_start()` descripsit.
/// Tamen suus 'simplicissima algorithms est ad aptet ad redundantiam, underflow et subnormalis PR results.
/// Hoc implementation occupat Algorithm et equitem gravatus Bellerophontem, ubi R laboratae merguntur.
/// Underflow et redundantiam facile detecta est, quod significand Ratio tamen non est in-range, sed est ad exponentem minimum/maximum pervenit.
/// Apud redundantiam a nobis redire infinitum simpliciter.
///
/// Et tractantem underflow subnormalibus trickier.
/// Quod unus magnus forsit cum minimum exponente intelligitur, sit etiam ratio, ut usque ad magnum significand.
/// underflow() pro details videre.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME esse ipsum: ita quod possumus facere generaliter big_to_fp fp_to_float(big_to_fp(u)) sibi parat, hic duplici modo sine Veram.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Nos prohibere ad a minimum ait, si expectare possumus, donec `k < T::MIN_EXP_INT`, deinde nobis per elementum youd 'abi duorum.
            // Significat quod valde dolendum est special-causam habemus cum normalis numerus minimum dimensiones.
            // FIXME formula invenire suavius elegantiusve est, sed `tiny-pow10` test run fac ut suus 'vere recte?
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Longitudo maxima Algorithm M iterations per Skips annotando et frenum.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Quod est aliquantulus longitudinem an estimate basis ex duobus, eiusque log(u / v) = log(u), log(v).
    // Est maxime per aestimationem I sed semper subterraneas estimate et sic error log(u) log(v) repellit signo ejusdem (uterque magnae).
    // Ergo error sit summum log(u / v) provincia.
    // Ubi est ratio u/v scopum amet significand an.Sic finis status sit log2(u / v) significand frena plus/minus est.
    // Vultus procul alter FIXME posse aliquantulus magis amplio estimate: et ne aliquis posset.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Aut Underflow subnormalis.Pelagus munus relinquam illam quærentibus.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Redundantiam.Pelagus relinquam illam quærentibus munus.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ratio significand est non in-range cum minimum exponet, ut nos postulo ut adjust circumducerent excess bits et magister eius.
    // De valore reali modo spectat sic:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    Q trunc.(Repraesentat rem)
    //
    // Itaque frena basi longe= 0.5 Ulp, Veram statuunt sua.
    // Pares cum reliqua non nulla pretium necesse sit rotunda sunt.
    // Reliqua de rotundato frena 1/2 ubi nulla habetur etiam in dimidio locus.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Etiam per vulgares-ut-, ut undique habens ab obfuscated secundum residuum divisionis.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}