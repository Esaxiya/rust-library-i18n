//! Decodes-natantis punctum pretii partes, et singula in errorem uenit.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Componerentur unsigned quovis valore finite, ut sic;
///
/// - Et originali valorem aequales `mant * 2^exp`.
///
/// - Nec ad numerum a `(mant - minus)*2^exp` `(mant + plus)* 2^exp` in circuitu et in originariam virtutem iterum tribuant.
/// Hoc est inclusive cum `inclusive` `true` rhoncus.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Et scaled mantissa.
    pub mant: u64,
    /// Errorem inferiori parte.
    pub minus: u64,
    /// Errorem superiori parte.
    pub plus: u64,
    /// Quod participatur in basi exponentis II.
    pub exp: i16,
    /// Parendum est peccatum quando inclusive.
    ///
    /// Apud DCCLIV IEEE, haec vera cum mantissa etiam originale.
    pub inclusive: bool,
}

/// Componerentur unsigned valorem.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infiniti sive positivus sive negativus.
    Infinite,
    /// Nulla positivus sive negativus.
    Zero,
    /// In numeris finitis adhuc componerentur agris.
    Finite(Decoded),
}

/// Quo fluctuetur decode`d: generis, qui potest esse.
pub trait DecodableFloat: RawFloat + Copy {
    /// In normalized minimum valorem positivum.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Refert ad signum (quando negans vero) `FullDecoded` et datum valorem a numero fluctuetur.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // finitimi (mant, II, exp)-(mant, exp)-(+ II mant, exp)
            // Float::integer_decode semper conservet exponens ita ut inruerent subnormalibus non Mantissa.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // finitimi (maxmant, exp, I)-(minnormmant, exp)-(+ I minnormmant, exp)
                // maxmant=* ubi minnormmant II, I
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // finitimi (mant, I: exp)-(mant: exp)-(+ I mant, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}