//! Fere recta (tenuiter optimized) Rust translation of de Figura III "Printing Floating-Point Numbers, et ueriori" [I ^].
//!
//!
//! [^1]: Burger, G. et Dybvig, Typographia 1996. Barthold numero fluctuetur punctum,
//!   cito et accurate.Non SIGPLAN.XXXI, V (Maias. MCMXCVI), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// precalculated vestit falsi Digit`s ad X ^ (n ^ II)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// Cum `x < 16 * scale` solum utilis;`scaleN` sit `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Brevissima modus implementation pro Draco.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ad numerum `v` noscitur forma;
    // - exaequabo `mant * 2^exp`;
    // - praecesserit `(mant - 2 *minus)* 2^exp` in originali genus;et
    // - sequitur `(mant + 2 *plus)* 2^exp` in originali genus.
    //
    // manifesto, `minus` et `plus` esse nulla potest.(Infinita, simus utimur ex-of-range values.) Et hanc ponamus saltem unius digit generatur, id est, nulla etiam potest esse `mant`.
    //
    // et quod hic est numerus inter omnem `low = (mant - minus)*2^exp` `high = (mant + plus)* 2^exp`, et describite et ad exactiorem huius numero fluctuetur cum terminis inclusa cum mantissa etiam originale (id est, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` est `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `k_0` estimate originale ex initibus exitibusque laicorum `10^(k_0-1) < high <= 10^(k_0+1)`.
    // stricta ad tenetur satisfacere `k` `10^(k-1) < high <= 10^k` postea computatur.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // convertere `{mant, plus, minus} * 2^exp` fractas in forma quod
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` dividat per `10^k`.Nunc `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // Cum fixup `mant + plus > scale` (vel `>=`).
    // actu non `scale` inflexo, quia prima potest skip pro multiplicationem.
    // Nunc ad generandum `scale < mant + plus <= scale * 10` nos constet.
    //
    // * *`d[0]` possunt nota esse quia nulla cum `scale - plus < mant < scale`.
    // Veram in hoc casu, conditio (`up` infra): et Urguet statim.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // equivalent ad X per scalas `scale`
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` generation pro digit.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants qua constet genitum quod tantum `d[0..n-1]`;
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (Sic `mant / scale < 10`) in quo est `d[i..j]` notarius ad d [I] X ^ * (i) ...
        // + D [I-j] X * + d[j]`.

        // digit generate est: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // haec descriptio est, facilior est mutatio Draco algorithm.
        // intermediis omissis multis argumentis derivationes perfectum atque commodum.
        //
        // satus invariants mutatio, ut diximus updated `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `d[0..n-1]` id est brevissima inter `low` repraesentatione et `high`, id est, implet utrumque `d[0..n-1]` non sequuntur sed `d[0..n-2]`:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (Bijectivity: et numeri per `v`);et
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (Ultimis est verum digit).
        //
        // secunda conditio simplifies in `2 * mant <= scale`.
        // solvendo invariants in terms of `mant`, et `low` `high` facit illa simplicior version primae conditio: `-plus < mant < minus`.
        // quia `-plus < 0 <= mant`, recte lineae brevissimae representation quo habemus `mant < minus` et `2 * mant <= scale`.
        // (Original cum mantissa Illud etiam `mant <= minus`.)
        //
        // et cum non facit secundum (II: * mant> scale`) crescat opus, ad extremum digit.
        // haec conditio satis sibi ad id, ut iam in tuto collocat generation nostis quod `0 <= v / 10^(k-n) - d[0..n-1] < 1` digit.
        // in hoc casu prima conditione `-plus < mant - scale < minus` fit.
        // quia post praedictorum generationem `mant < scale`, habemus `scale < mant + plus`.
        // (Iterum, hoc fit `scale <= mant + plus` cum originali etiam mantissa.)
        //
        // in brevi:
        // - et subsisto per `down` (ut servo numeri) cum `mant < minus` (vel `<=`).
        // - et fluere per `up` (proventus extremum digit) Cum `scale < mant + plus` (vel `<=`).
        // - generating ut aliud.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // minima enim repraesentatio procedere Veram

        // invariants et restituet.
        // Inde algorithm semper terminatur: et `minus` `plus` Crescit autem et `mant` tonsa modulo `scale` `scale` figitur.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // Ego congregans accidit) Veram sola conditione utitur sursum vel iii) et utraque utitur quisque muro et congregans malit.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // Si mutare longitudo congregans exponens debet mutari.
        // videtur quod valetudo valde durum satis (esse potest), nisi nos non solum incolumem hic consistent.
        //
        // Salute nostra memoria initialized est.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // Salute nostra memoria initialized est.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Modum statuit Draconi exigere turpis.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `k_0` estimate originale ex initibus exitibusque `10^(k_0-1) < v <= 10^(k_0+1)` imple.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` dividat per `10^k`.Nunc `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // Cum fixup `mant + plus >= scale` ubi `plus / scale = 10^-buf.len() / 2`.
    // ut bignum custodire fixum-amplitudo, ut etiam per `mant + floor(plus) >= scale`.
    // actu non `scale` inflexo, quia prima potest skip pro multiplicationem.
    // iterum proximum algorithm, `d[0]` esse nulla potest nisi erit eventually adsumentesque de vulgo viros.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // equivalent ad X per scalas `scale`
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // si opus sunt nobis ad extremum digiti mensuram, breve quiddam apud nos postulo ut vitare reddens re duplici Veram ea.
    //
    // quod habebimus rursus congregans quiddam accidit dilatari;
    let mut len = if k < limit {
        // Colloquia Latina sumus, et non possumus producendum * * unum digit.
        // hoc est, ubi fieri potest, dices: Comperto rotundatis vel aliquid simile 9.5 et quod suus 'X.
        // et non revertetur vacua quiddam cum exceptio de qua re postea accidit, cum in flectendis promunturiis, et `k == limit` sed unum habet ad producendum digit.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` generation pro digit.
        // (Sumptuosus hoc non potest esse, neque tam vana haec expendite cum quiddam est).
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // sequuntur numeri zeroes omnes nos hinc nolite facere * * ne conari praestare flectendis promunturiis?sed implere reliquis constet.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // Salute nostra memoria initialized est.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // Si media sistere congregans sequenti digitos digitis prorsus (V) si ... Lorem priore quidem digiti circa conetur (id quod prius congregans vitare etiam digit).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // Utilitatibus consulens `buf[len-1]` est initialized.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // Si mutare longitudo congregans exponens debet mutari.
        // sed certum numerum numeri postulavit habuimus ut non uariat speciem quiddam ...
        // Salute nostra memoria initialized est.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... weve 'iam petitum, nisi pro certis certa.
            // nos etiam postulo ut reprehendo: Si enim quiddam originale erat inanis et additional digita cum addita modo `k == limit` (edge causa).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // Salute nostra memoria initialized est.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}