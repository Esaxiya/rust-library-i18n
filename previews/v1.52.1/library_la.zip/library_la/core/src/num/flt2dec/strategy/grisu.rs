//! Rust accommodationem contingit Grisu3 algorithm descripsit per "Printing Floating-Point Numbers, et ueriori modo Integers per" [I ^].
//! Adhibet circa ea in 1KB precomputed mensam, et rursus, suus 'valde pro velox maxime inputs.
//!
//! [^1]: Florian Loitsch.2010. Edition natantis punctum numerus, cito atque
//!   verius sunt numeri integri.Non SIGPLAN.XLV, VI (June MMX), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// videatur in commentarios in `format_shortest_opt` ad rationale.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // **X-I;e* i=IV, LXXX
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (F, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Datum `x > 0`, ita ut `10^k <= x < 10^(k+1)` `(k, 10^k)` redit.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Brevissima modus implementation pro Grisu.
///
/// Non refert `None` revertetur, cum esset secus representation quod improprie loquitur.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // opus autem trifariam additional certe praecisione

    // ad exponentem normalized values satus cum shared
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // `cached = 10^minusk` invenire ita ut `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // Cum `plus` normalised est, id `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // dedimus et arbitrio `ALPHA` `GAMMA`, in `[4, 2^32)` Movet `plus * cached`.
    //
    // manifesto ut maximize `GAMMA - ALPHA` quod est appetibile, ita ut non opus vires in X cached multi, sed sunt quidam respectus;
    //
    //
    // 1. ut `floor(plus * cached)` in `u32` nos volo, sed opus esse pretiosi quia division.
    //    (Hic est vere tamen nolint, quod requiritur ad recte residuum fuerit æstimatum.)
    // 2.
    // reliquo `floor(plus * cached)` saepe sudatio, multiplicentur ex X: ut et flamma non ardebit.
    //
    // dat `64 + GAMMA <= 32` prima, secunda `10 * 2^-ALPHA <= 2^64` tribuit:
    // -60 et -32 est maximum range in hoc vis, V8 et utitur illis.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // Etiam scale.hoc dat maxima error in I Ulp (5.1 pars conclusionis probatur).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-range de re minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | Paul I | Paul I || Paul I | Paul I || Paul I | Paul I |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // `minus` desuper, et `v` `plus` sunt quantized * * approximationes (error <I Ulp).
    // ut non negans, vel per errorem est positivum, utimur aequo et duo distincta approximationes etiam habetur maximum aggregatum ex errore ulps II.
    //
    // ad liberali "unsafe region" est medium quo initio generate.
    // quod est conservativum "safe region" aequali modo accepi.
    // nos satus cum ed bene in regione satis tutum, tentant ut et maxima XII `v` in quibus salvus sit in regionem.
    // si potes deferimus.
    //
    let plus1 = plus.f + 1;
    // et plus0 = plus.f: I://Sit modo explicandum minus0 minus.f + I=;//modo explicandum
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // exponens shared

    // dividimus partes fractas et integras `plus1`.
    // integralis in u32 partes, utpote quae fit ut, cum virtus praestat print `plus < 2^32` et normalized `plus.f` semper minus quam ob subtilitatem `2^64 - 2^4` postulationem.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // quam maxima ratio `10^max_kappa` `plus1` (`plus1 < 10^(max_kappa+1)` sic).
    // quod superius `kappa` infra terminum.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorema 6.2 si maior `k` Integer S.
    // `0 <= y mod 10^k <= y - x`,              et in `V = floor(y / 10^k) * 10^k` `[x, y]` et unus ex repraesentatione proximum (de minima numeri significant numerus) in hoc range.
    //
    //
    // longitudinem inter `(minus1, plus1)` sicut digit invenire `kappa` per tertiam conclusionem 6.2.
    // 6.2 hac conclusione potest excludere `x`, ut adoptionem filiorum per requiring `y mod 10^k < y - x` loco.
    // (Eg, `x` =(XXXII), `y` =(XXXII) DCCLXXVII, y `kappa` quo mod=II=III X ^ DCCLXXVII <y: =x 777`.) Ad tempus algorithm ex sensualibus quae sunt post verificationem ad excludere `y`.
    //
    let delta1 = plus1 - minus1;
    // et delta1int=(e>> delta1) ut usize;//modo explicandum
    let delta1frac = delta1 & ((1 << e) - 1);

    // redde integralis partium, cum diligenter ad reprehendo gradus apud se.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // nondum reddi digitorum
    loop {
        // saltem reddere semper digiti quasi `plus1 >= 10^kappa` invariants:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (Non sequitur quod `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // `remainder` dividat per `10^kappa`.scalis `2^-e` utrumque.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(X% plus1 Kappa ^) * ^ E II
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; `kappa` repperimus rectam.
            let ten_kappa = (ten_kappa as u64) << e; // X, ad communem exponens scandere Alpha
            return round_and_weed(
                // Salute nostra memoria initialized est.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // reddiderunt omnes frangere dum ansam integra constet.
        // ut numerus constet `max_kappa + 1` `plus1 < 10^(max_kappa+1)` sit exacta.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // invariants restituet
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // partes fractus reddant dum accuracy apud reprehendo pro cuiusque gradus.
    // nitimur hoc iteratis multiplicationes quasi certa pars amittet.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // weve expertum esse significans quod tunc sit digit sunt coram solveret invariants, `m = max_kappa + 1` quo (#of numeri in integralis partem)
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // et flamma non ardebit, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder` dividat per `10^kappa`.
        // utrumque scalis `2^e / 10^kappa` ita haec interpretatus est.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // divisorem implicatum
            return round_and_weed(
                // Salute nostra memoria initialized est.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // invariants restituet
        kappa -= 1;
        remainder = r;
    }

    // omnes numeri significant generatae ex `plus1` diximus, sed non bene certus si suus 'unum.
    // exempli gratia, si ... et `minus1` est 3,14153 3,14158 `plus1` est ... sunt brevissimae V diversis 3.14154 repraesentat se, ut non modo maximum sed 3.14158 unum.
    // non enim successive, et vide si haec ie ad extremum digit meliorem ed.
    // IX maxime in candidati sunt (..1 ad ..9), et hoc aequa mente velox.("rounding" tempus)
    //
    // Si autem checks hoc munus etiam in XII "optimal" Ulp septum templi, et fieri potest, ut possit actualiter "second-to-optimal" ed bene in flectendis promunturiis ex errore.
    // vel, in casibus, huius refert `None`.
    // ("weeding" tempus)
    //
    // hie et communi omnium fortium (sed implicitae) `k` pretium ut:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (Et etiam, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (Et etiam, ex `threshold > plus1v` ante invariants)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // producendum approximationes dentur duo `v` (actually `plus1 - v`) 1.5 in ulps.
        // summa resultans esset repraesentatio utramque repraesentationem.
        //
        // hic `plus1 - v` cum adhibetur ad numeros quae fieri quantum ad `plus1` ut ne overflow/underflow matrimonio (unde nomen sicut tela morbis).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (V: I Paul)
        let plus1v_up = plus1v - ulp; // plus1 - (Ulp v + I)

        // et extremum digit subsisto pauci numero in proximam `v + 1 ulp` legationemque.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // cum constet `w(n)` approximari operemur quae initio æquale `plus1 - plus1 % 10^kappa`.accurrunt corpus ansa `n` temporibus `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` profecti (nam cetera '= plus1w(0)`) simpliciorem compescit.
            // `plus1w(n)` quod semper crescit.
            //
            // tribus conditionibus habemus terminare.horum faciet ansa non procedunt, sed tunc innotescat repraesentatio maxime valet saltem `v + 1 ulp` elit.
            // pro illis faciemus ut TC1 per TC3 brevitatis gratia.
            //
            // TC1: `w(n) <= v + 1 ulp`, id est, de hoc ultimo ed qui est maxime unum.
            // hoc est equivalent ad `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // coniuncta TC2 (quae impediunt `w(n+1)` is valid) si hoc vetat fieri ratio `plus1w(n)` redundantia.
            //
            // TC2: `w(n+1) < minus1`, id est, proximo certe XII, non autem per `v`.
            // est equivalent ad `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // in sinistra parte non operient: sed `threshold > plus1v` scio, sic est falsa, si TC1, et `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` si `threshold - plus1w(n) < 10^kappa` test tuto loco.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, id est, in proximo est repr
            // nihil propius esse quam current `v + 1 ulp` ed.
            // `z(n) = plus1v_up - plus1w(n)` dedit, hoc fit `abs(z(n)) <= abs(z(n+1))`.si tamen iterum TC1 esse falsum: habemus `z(n) > 0`.habemus duobus casibus considerare;
            //
            // - Cum `z(n+1) >= 0`: TC3 `z(n) <= z(n+1)` fit.
            // ut `plus1w(n)` sit crescens concupiscentia, si `z(n)` decrescentes esse, quod patet esse falsum.
            // - Cum `z(n+1) < 0`:
            //   - TC3a: `plus1v_up < plus1w(n) + 10^kappa` praevia sit.TC2 si falsum est, ut hoc non redundantiam `threshold >= plus1w(n) + 10^kappa`.
            //   - TC3b: TC3 `z(n) <= -z(n+1)` fit, id est, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   negatum TC1 `plus1v_up > plus1w(n)` dat, ideo non una cum redundantia vel underflow TC3a.
            //
            // Consequenter cum `TC1 || TC2 || (TC3a && TC3b)` sistamus.ita erit et reciproca, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // XII terminus ad proximum non potest `0`
                plus1w += ten_kappa;
            }
        }

        // si summa quoque repraesentationem legationemque `v - 1 ulp` reprehendo.
        //
        // haec est simpliciter ad eosdem terminos ad `v + 1 ulp` condiciones, cum omnis `plus1v_up` reponi pro `plus1v_down`.
        // aeque valet redundat nibh.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // Nunc autem habemus summa legationemque `v` inter `plus1` et `minus1`.
        // Hoc etiam liberales, cum `w(n)` sic rejiciunt inter `plus0` et non `minus0`, id est, aut `plus1 - plus1w(n) <= minus0` `plus1 - plus1w(n) >= plus0`.
        // Et nos uti res `threshold = plus1 - minus1` `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Brevissima modus implementation pro Grisu Draco cum fallback.
///
/// Hic debet adhiberi pluribus.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // Utilitatibus consulens horum mutuo postulaverit checker et non captiosus satis est uti Venite `buf`
    // branch ad alterum, sic ut hic launder in vita sua.
    // Sed modo usurpari `buf` re, si haec ita bene `None` `format_shortest_opt` rediit.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Fixa per modum Grisu turpis exigere.
///
/// Non refert `None` revertetur, cum esset secus representation quod improprie loquitur.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // opus autem trifariam additional certe praecisione
    assert!(!buf.is_empty());

    // Normalize `v` ac magnitudine.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // et fractos `v` integras partes dividimus.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // et `v` et vetera novis `v` (`10^-k` permensus humilioremque) habet ex errore <Ulp I (conclusionem 5.1).
    // quia non noverunt error sit positivus sive negativus, utimur et duas aeque distantes approximationes etiam habetur maximum aggregatum ex errore ulps II (eandem lineam brevissimam causa).
    //
    //
    // quod est propositum exacte rotunda invenire seriem numeri, quae ad commune quod utraque `v - 1 ulp` `v + 1 ulp`, ut maxime autem in cordibus eorum.
    // si haec non sunt possibilia: vincens scientiam nostram quae est in output `v` rectam, ut cadas et nos back up dabit.
    //
    // `err` Hic ponitur `1 ulp * 2^e` (`vfrac` easdem in Paul), et scalis ascendere quotiescumque `v` accumbunt.
    //
    //
    //
    let mut err = 1;

    // quam maxima ratio `10^max_kappa` `v` (sic `v < 10^(max_kappa+1)`).
    // quod superius `kappa` infra terminum.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // si opus sunt nobis ad extremum digiti mensuram, breve quiddam apud nos postulo ut vitare reddens re duplici Veram ea.
    //
    // quod habebimus rursus congregans quiddam accidit dilatari;
    let len = if exp <= limit {
        // Colloquia Latina sumus, et non possumus producendum * * unum digit.
        // hoc est, ubi fieri potest, dices: Comperto rotundatis vel aliquid simile 9.5 et quod suus 'X.
        //
        // In principio immediate `possibly_round` inani quiddam dicimus, quod per scalas `max_ten_kappa << e` X redundat in aliud.
        //
        // ita facti sumus a rhoncus elementum imperito X hic error modos.
        // hoc negans falsum proventus rate, sed ipsum solum:*ipso* leviter;
        // tantum possit esse maior refert quam LX bits funeris cum mantissa.
        //
        // Salutem `len=0` et cum religione memoria initialized movere.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // membra reddant.
    // in error totum deest, ut non postulo reprehendo in hac parte.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // nondum reddi digitorum
    loop {
        // saltem reddere invariants semper digiti;
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (Non sequitur quod `remainder = vint % 10^(kappa+1)`)
        //
        //

        // `remainder` dividat per `10^kappa`.scalis `2^-e` utrumque.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // plenum quiddam est?reliqua rotunditate saltum iret.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(X% ^ v Kappa) * II d functicmem
            // Salutem et diximus multa initialized `len` bytes.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // reddiderunt omnes frangere dum ansam integra constet.
        // ut numerus constet `max_kappa + 1` `plus1 < 10^(max_kappa+1)` sit exacta.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // invariants restituet
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // fractus membra reddant.
    //
    // In principle nobis available potet continire ad extremum digit pro Accuratio et vide.
    // quod valde dolendum non mediocri finito es opus per numeros integros, ut nos postulo redundantiam ad normam deprehendere.
    // V8 `remainder > err` utitur, quod fit falsum ubi numeri significant ex primo `i` `v - 1 ulp` et `v` differunt.
    // Hoc autem respuit multa nimis initus secus valet.
    //
    // post tempus post has redundantiam recta deprehendatur, iudicium: Arctius hoc loco utimur;
    // semper exsuperat `10^kappa / 2` `err` usque ut duo vel rotundatis range inter `v - 1 ulp` et repraesentationum `v + 1 ulp` turpis.
    //
    // similiter hic duo similitudinibus `possibly_round` pro referunt.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants ubi `m = max_kappa + 1` (#of numeri in integralis partem)
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // et flamma non ardebit, `2^e * 10 < 2^64`
        err *= 10; // et flamma non ardebit, `err * 10 < 2^e * 5 < 2^64`

        // `remainder` dividat per `10^kappa`.
        // utrumque scalis `2^e / 10^kappa` ita haec interpretatus est.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // plenum quiddam est?reliqua rotunditate saltum iret.
        if i == len {
            // Salutem et diximus multa initialized `len` bytes.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // invariants restituet
        remainder = r;
    }

    // Frustra etiam ratione (non plane `possibly_round`) sic dabo.
    return None;

    // in omni generato `v` weve postulavit constet quod idem secundum digitos `v - 1 ulp` debent.
    // si iam reprehendo utriusque partis `v - 1 ulp` atque unica `v + 1 ulp` repraesentationis;Idem hoc generaretur vel digitis vel rotundatis usque emendationis eorum constet.
    //
    // Si plures sunt repraesentationum latitudine longitudinis `None` redire non possumus pro certo.
    //
    // hie et communi omnium fortium (sed implicitae) `k` pretium ut:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // Salutem et primus de `len` bytes `buf` sit initialized.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | Paul I | Paul I |;
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (Nam referat et linea data indicat de numero per repraesentationes numeri valorem iustum fieri potest).
        //
        //
        // saltem potest esse error ingens et simulacra inter `v - 1 ulp` `v + 1 ulp`.
        // qui enim non est recte determinare.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | Paul I | Paul I |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // quidem satis 1/2 Ulp est inducere potest duobus intersint.
        // (Ut memini opus in a unique repraesentatione `pariter atque `v - 1 ulp` v + I ulp`.) Redundantiam hoc non ut prius ex `ulp < ten_kappa` reprehendo.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <Kappa-------------------X ^>:
        //     | :   |                           :
        //     | Paul I | Paul I |;
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // Si `v + 1 ulp` est propius ad rotundum-sunt praebere (qui iam `buf`), tum secure possint redire.
        // * *`v - 1 ulp` possint esse nota est minus quam current repraesentatio, sed ut `1 ulp < 10^kappa / 2`, hoc est satis conditio:
        // spatium inter `v - 1 ulp` et vena `10^kappa / 2` repraesentatione `praeterire non poterunt.
        //
        // quod valet conditio, ut `remainder + ulp < 10^kappa / 2`.
        // quoniam exuberant facile primus `remainder < 10^kappa / 2` Check if.
        // Iam ut weve `ulp < 10^kappa / 2` verificatur, sic ut dum `10^kappa` non conteret, after all, is denique secunda reprehendo.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // Salutem nostram memoriam initialized RECENS.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------residuum------> |;
        //   :                          |   :
        //   : <---------Kappa---------X ^>:
        //   :                    |     |   : |
        //   : | Paul I | Paul I |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // altera manus sursum teres si `v - 1 ulp` propius repraesentationis circum redire debet.
        // ideo non indiget `v + 1 ulp` reprehendo.
        //
        // quod valet conditio, ut `remainder - ulp >= 10^kappa / 2`.
        // rursus si primum reprehendo `remainder > ulp` (`remainder >= ulp` nota quod falsum est, quod nulla umquam `10^kappa`).
        //
        // Et notandum quod `remainder - ulp <= 10^kappa` ita quod fuit secunda reprehendo.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // Salutem nostram memoriam initialized oportuit RECENS.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // sed modo aliquid etiam digit rogatus fuerit fixa cum praecisione.
                // et id nos postulo ut reprehendo si autem quiddam erat inanis originale, in quo additional digita modo `exp == limit` addidit (edge causa).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // Salutem memoria nostrorum gistrum initialized.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // nos aliter dolorem (id est, inter `v - 1 ulp` volumus quaedam principia atque flectendis promunturiis `v + 1 ulp` et alii in flectendis promunturiis) et cedere.
        //
        None
    }
}

/// Ad modum statuit exigere Grisu isto dracone fallback turpis.
///
/// Hic debet adhiberi pluribus.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // Utilitatibus consulens horum mutuo postulaverit checker et non captiosus satis est uti Venite `buf`
    // branch ad alterum, sic ut hic launder in vita sua.
    // Sed modo usurpari possunt `buf` re, si haec ita bene `None` `format_exact_opt` rediit.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}