//! XVI frenum Unsigned integer, constantes ad genus.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Ut nova codice directe in primitiva constantes sociis utuntur.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }