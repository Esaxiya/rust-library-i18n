#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Continentur in definitione instrúite compilator aedificatur typis extensione.
//!
//! Possit esse in tuto, in codice, ut scuta de transmutat rudis repraesentationum manipulating recta ad.
//!
//!
//! Definitione definiri semper ABI `rustc_middle::ty::layout` compositus.
//!

/// Sicut obiectum repraesenta trait `&dyn SomeTrait`.
///
/// Haec efficere habeat in figura simile idem layout `&dyn SomeTrait` et `Box<dyn AnotherTrait>`.
///
/// `TraitObject` stabiliri layout est congruit, sed non in trait rationem obiecti (eg, in agris non directe accessible `&dyn SomeTrait`) vel layout ut non sit control (per definitionem non mutantur mutare layout de a `&dyn SomeTrait`).
///
/// Tuta non est utendum in codice est solum disposito occurrit low-level details very molimina corrumpendi.
///
/// Est ut non loquuntur de omnibus rebus trait secundum genus, ut est solus via bona efficere ut huius generis cum [`std::mem::transmute`][transmute] munera.
/// Similiter etiam non est vera via ad partum a trait object `TraitObject` valorem cum `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// In qua nemo summatim trait genera vtable mismatched obiecti rationem non pertinet ad vim, quae maxime probabilis notitia ad indefinitam regula morum.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // in exemplum trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // adiecta sit quod facit trait
/// let object: &dyn Foo = &value;
///
/// // at metus repraesentatio
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // oratio monstratorem est data est de `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // construere novum obiectum `i32` indicat aliud esse sollicita de vtable uti `i32` `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // si autem operari sicut de obiecto struxere trait directe `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}