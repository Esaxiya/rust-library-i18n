/// Accipit causam immutabilem esse operator est versionem ad vocationem acceperit existimare possis.
///
/// Casus quidem `Fn` potest saepe dicitur mutating sine statu.
///
/// *Hoc trait (`Fn`) non est confundendum cum [function pointers] (`fn`).*
///
/// `Fn` sit implemented commissuras quam habes artificio confecta res inmobiles tolle tantum variables references ad captum, aut quid omnino non captis, (safe) [function pointers] tum (cum quidam caveats, videatur in documentis pro magis details).
///
/// Praeterea, cuiuslibet generis `F` enim quod `Fn` arma, arma `&F` `Fn`, quoque.
///
/// Et cum [`FnMut`] et [`FnOnce`] sunt supertraits `Fn` est, si exempli gratia ex `Fn` adhiberi possit a quo ut ex signo aut [`FnMut`] [`FnOnce`] expectat.
///
/// Usus `Fn` cum vis quasi vinctum, ut munus accipere ad parametri generis, et saepe sine necessitate illud appellare mutating statu (eg, quando simul ut vocant).
/// Si autem non talia postulo severus requisitis utere [`FnMut`] [`FnOnce`] sive ut fines.
///
/// Videre magis notitia [chapter on closures in *The Rust Programming Language*][book] aliquamdiu in hoc loco.
///
/// Item ex peculiari nota est Syntax pro `Fn` traits (exempli gratia
/// `Fn(usize, bool) -> usize`).Technical details illis interested in huius potestatis [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Vocans Agricola
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Modulus usura a `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ut regex inde securus est `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Performs vocationem operationem.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Versionem et non accipit rerum invisibilium visibiliumque operator vocationem acceperit existimare possis.
///
/// Casus quidem `FnMut` saepe possunt et vocatur status mutate.
///
/// `FnMut` commissuras posterius mutari potest capere quae sit implemented habes artificio confecta references to captam variables ut bene dispositis omnis generis, quae ad effectum deducendi [`Fn`], eg, (safe) [function pointers] (quod est `FnMut` supertrait de [`Fn`]).
/// Praeterea, cuiuslibet generis est `F` `FnMut` ut instrumento, instrumentum `&mut F` `FnMut`, quoque.
///
/// Cum [`FnOnce`] est supertrait de `FnMut`, potest esse aliqua exempli gratia ex `FnMut` [`FnOnce`] expectat a quo et ex quo est [`Fn`] subtrait de `FnMut`, si exempli esse de quo possumus [`Fn`] `FnMut` expectat.
///
/// Usus est ligatus `FnMut` cum vis accipere munus ad parameter genus, sicut et opus est quod saepe vocant concredat, admissa ad statum uolueris.
/// Si non vis modularis in statu uolueris, utere [`Fn`] est ligatus: Si enim ita vocare non opus est saepe, uti [`FnOnce`].
///
/// Videre magis notitia [chapter on closures in *The Rust Programming Language*][book] aliquamdiu in hoc loco.
///
/// Item ex peculiari nota est Syntax pro `Fn` traits (exempli gratia
/// `Fn(usize, bool) -> usize`).Technical details illis interested in huius potestatis [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Vocans mu-tabiliter inest caperent Agricola
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## A modulus usura `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ut regex inde securus est `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Performs vocationem operationem.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Et versionem esse vocationem operator valorem accipit a per-acceperit existimare possis.
///
/// Exempla `FnOnce` dici, sed ne callable multiple vicis.Propter hoc sciatur si aliquid de sola generis effectum adducit eo quod `FnOnce`, is non aliter vocari potest semel.
///
/// `FnOnce` consumere posset capto artificio impletur purus commissuras atque efficere ut omnium formarum [`FnMut`] eg (safe) [function pointers] (nam de [`FnMut`] supertrait `FnOnce` est).
///
///
/// Quia ex utraque [`Fn`] et [`FnMut`] sunt subtraits `FnOnce`, si exempli gratia ex [`Fn`] [`FnMut`] potest esse vel quo ad `FnOnce` expectat.
///
/// Usus `FnOnce` quasi ligatus, cum vis accipere munus ad parameter genus, sicut olim, et non opus est appellant.
/// Saepe Si vos postulo ad parametrum vocare, uti [`FnMut`] est ligatus: et eam non indigent, si uolueris status utere [`Fn`].
///
/// Videre magis notitia [chapter on closures in *The Rust Programming Language*][book] aliquamdiu in hoc loco.
///
/// Item ex peculiari nota est Syntax pro `Fn` traits (exempli gratia
/// `Fn(usize, bool) -> usize`).Technical details illis interested in huius potestatis [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Modulus usura a `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` variables consumat brachia ejus captum, ita ut ultra non currere simul.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Conanti invocare iterum `func()` et mittent `use of moved value` `func` ad errorem.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` fieri non recordabitur ultra nominis in hac parte
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ut regex inde securus est `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Et postquam rediit generis vocationem operator adhibetur.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Performs vocationem operationem.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}