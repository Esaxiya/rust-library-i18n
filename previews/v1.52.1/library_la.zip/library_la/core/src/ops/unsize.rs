use crate::marker::Unsize;

/// Trait indicat, quod haec regula serratus vel pro: quo fieri possit id unsizing in pointee.
///
/// Et videre [DST coercion RFC][dst-coerce] pro magis details [the nomicon entry on coercion][nomicon-coerce].
///
/// Nam monstratorem typus builtin, `T` indicibusque ut mos cogere ad indicium est `U` `T: Unsize<U>` si convertatur a monstratorem ad nihilum adipem monstratorem.
///
/// Genera mos coactio coercendi `Foo<T>` hic agit ut in impl `CoerceUnsized<Foo<U>> for Foo<T>` `Foo<U>` dummodo sit.
/// Si enim impl tale potest esse nisi unum solum habet `Foo<T>` non-phantomdata involving `T` agro.
/// Si genus non est ager `Bar<T>`, an ex implementation `CoerceUnsized<Bar<U>> for Bar<T>` necesse est.
/// Et erit opus per coactionem coercendos imperitorum `Bar<T>` in agro `Bar<U>` filling et in reliquis agris ab `Foo<T>` `Foo<U>` creare.
/// Hoc agri, et cum effectu exercitio tenus a monstratorem, quod eodem poenis coerceri.
///
/// Fere ad effectum deducendi dolor et indicibusque `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, cum ipsa libitum `T` in `?Sized` tenetur.
/// Nam quae directe fascia types `T` ut embed `Cell<T>` et `RefCell<T>`, te potest directe `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` effectum deducendi.
///
/// Et hoc ex coercions types `Cell<Box<T>>` quasi opus.
///
/// [`Unsize`][unsize] mark cogi posse ad esse generis indicia est a tergo, si DSTs.Est implemented statim per compiler.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> U &mut
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> mut U *
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> U * const
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> U * const
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *Mut T-> U mut*
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *T mut-> U* const
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *Const T-> U* const
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Id est pro salute generis species recipitur in ratione compescere, missus est.
///
/// An example implementation de trait;
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> U &mut
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *Const T-> U* const
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *Mut T-> U mut*
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}