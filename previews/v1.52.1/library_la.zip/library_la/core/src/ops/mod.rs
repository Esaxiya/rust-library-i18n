//! Overloadable operators.
//!
//! Exsequendam haec traits concedit quaedam operators ut onerare.
//!
//! Quidam horum traits sunt importari ad prelude, ut praesto sint in omnibus Rust progressio.Tantum operators subnixum traits potest cumulatur.
//! Exempli gratia etiam in operator (`+`) cumulatur per [`Add`] trait potest: sed quod haec addenda est nihil operator (`=`) trait tergum, illic est nocent via sua semantics.
//! Item providere Cuius moduli non est ulla mechanism creo operators.
//! Si obruuntur vel consuetudine traitless operariorum requirantur oportet respicere extenderet Rust est unitas seu syntaxin compilator volutpat.
//!
//! Ut in cuiusque traits operante implementations unsurprising adiutura solito attentis [operator precedence] significatorum.
//! Exempli gratia in exsequendam [`Mul`], in operationem oportet habere aliquam similitudinem multiplicationem exsurgunt (expected proprietatibus, sicut et participes associativity).
//!
//! Et nota quod `&&` `||` operariorum circuitus brevis seu signi, si modo pretium confert ex altero.Cum urgeri ab traits non moribus, non fulciuntur overloadable `||` `&&` et operariorum.
//!
//! Multi operators ut de sua pretii ab operands.Ambitus genus in non-involving constructum-in figura, plerumque est non a forsit.
//! Tamen, utendo operators in codice generale, aliqui requirit operam ad reddi illius values si operators ut opponitur ad dimittens eos.Una est optio interdum uti [`clone`].
//! Alius typus involved in providing additional optionem rely est ad implementations operator p.
//! Exempli gratia, pro quibus putatur a user definire genus `T` Praeterea subsidium est probabiliter bonum idea ut utrumque `T` `&T` atque ad effectum deducendi traits [`Add<T>`][`Add`] [`Add<&T>`][`Add`] ac ut ex genere codice potest quin scripta necesse Gen.
//!
//!
//! # Examples
//!
//! Hoc `Point` creates a instrúite, ut exemplum et instrumentum [`Add`] [`Sub`], et demonstrativum eius additionem et subtractionem: Point`s duo.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Vide trait omnibus documentis, prout in se est per exemplum implementation.
//!
//! Et [`Fn`], [`FnMut`], et [`FnOnce`] traits es implemented ut invocentur posteritatem millium qui munera.Nota ut [`Fn`] `&self` accipit, et [`FnMut`] accipit `&mut self` [`FnOnce`] `self` accipit.
//! Ratio potest triplex haec correspondent inuocanda exemplum Vocate, quantum per vocetur, mutabilis, per comparationem et valor per appellationem.
//! Plerumque usus est traits gradu superiorem modum agere vel munerum officio compagibus argumenta fiunt.
//!
//! Is cum [`Fn`] tanquam parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Missus a tanquam parameter [`FnMut`]:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Is cum [`FnOnce`] tanquam parameter;
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` variables captum consumat, ut non plus quam semel currunt
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Conanti `func()` fas appellare piumque est `use of moved value` errore adhuc te iacere ad `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` fieri non recordabitur ultra nominis in hac parte
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;