// Ut duos varius bytes
const DATA: [u16; 2] = [u16::from_ne_bytes([0x01, 0x23]), u16::from_ne_bytes([0x45, 0x67])];

const fn unaligned_ptr() -> *const u16 {
    // Cum enim varius DATA.as_ptr() bytes ad duo, addere I byte et producens Unaligned * const u16
    unsafe { (DATA.as_ptr() as *const u8).add(1) as *const u16 }
}

#[test]
fn read() {
    use core::ptr;

    const FOO: i32 = unsafe { ptr::read(&42 as *const i32) };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { ptr::read_unaligned(&42 as *const i32) };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { ptr::read_unaligned(UNALIGNED_PTR) };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn const_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn mut_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32 as *mut i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32 as *mut i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *mut u16 = unaligned_ptr() as *mut u16;

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

// #[test]
// {core::ptr write() n usus;
//
//    Const n write_aligned()-> i32 {res sit mut=0;
//        {statio male fida
//            ptr::write(&mut res as *mut _, 42);
//        }
//        } Const res varius, i32 = write_aligned():
//    assert_eq! (varius; XLII);
//
//    Const n write_unaligned()-> [u16; 2] et mut two_aligned={[0u16; 2];
//        {(two_aligned.as_mut_ptr() quod sit statio male fida unaligned_ptr= * * mut u8).add(1) ut mut u16;
//            ptr: : write_unaligned (unaligned_ptr, u16::from_ne_bytes([0x23, 0x45])), Const Unaligned}} two_aligned: [u16; 2] = write_unaligned();
//
//    assert_eq! (Unaligned, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]):}
//
//
//
//
//
//
//
//
//
//

// #[test]
// {int n mut_ptr_write() n aligned()-> Sit i32 {mut res=0;
//        { (&mut res as *mut i32).write(42); } statio male fida res varius} Const: i32 = aligned(),
//
//    assert_eq! (varius; XLII);
//
//    Const n write_unaligned()-> [u16; 2] et mut two_aligned={[0u16; 2];
//        {(two_aligned.as_mut_ptr() quod sit statio male fida unaligned_ptr= * * mut u8).add(1) ut mut u16;
//            unaligned_ptr.write_unaligned(u16::from_ne_bytes([0x23, 0x45]));
//        }
//        two_aligned} Const Unaligned: [u16; 2] = write_unaligned();
//    assert_eq! (Unaligned, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]):}
//
//
//
//
//
//
//
//
//
//
//