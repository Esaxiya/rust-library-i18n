use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Et hoc est firmum Superficies sed adjuvat arce cheap `?` inter se, etiamsi iam LLVM non semper commodo est.
    //
    // (Tristis Result ADHIBENDO DEQUE FACULTATE conveniunt, et potest non inserere et ControlFlow).

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}