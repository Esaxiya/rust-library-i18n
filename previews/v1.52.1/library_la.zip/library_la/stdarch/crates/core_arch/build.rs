use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Dic nobis `#[assert_instr]` annotationes ad omnia praesto sunt simd intrinsics codegen temptare ejus, quia sunt quidam gatum post `-Ctarget-feature=+unimplemented-simd128` quod extra se non habet aliquam, in equivalent `#[target_feature]` nunc.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}