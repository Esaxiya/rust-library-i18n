#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Vide [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Vide [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Vide [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Vide [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Vide [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Vide [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Cache arcessere ab linea, quae continet oratio `p` uti datis `rw` et `locality`.
///
/// `rw` Quod sit unus est:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): parat in prefetch ad legere.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): et scribes in prefetch parat.
///
/// Et `locality` oportet esse unum:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Vel effusis prefetch non tempore, quia notitia sit, quod tantum semel.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Arcessere est in III campester cache.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Arcessere in gradu II cache.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Arcessere in planum I cache.
///
/// In signum memoriae mandatis memoriae prefetch ratio memoriae aditus ex Communibus future oratio in proximo futura sint.
/// Ratio memoriae respondeat opera sumto memoria aditum opinatis ut acceleraretur fiant, certum est quod Preloading dissertationis välimuistit vel.
///
/// Quia sunt signa insinuat Pentium particulare agere aliquid valet vel a praecepto prefetch nop.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Nos uti `llvm.prefetch` intrinsecae `cache type` tecum=I (cache notitia).
    // `rw` et quae fundatur super `strategy` munus parametri.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}