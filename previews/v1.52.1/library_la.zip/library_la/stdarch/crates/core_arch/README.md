`core::arch` - Rust scriptor core bibliotheca architectura Utilia intrinsics
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

De architectura arma `core::arch` module-dependens intrinsics (eg SIMD).

# Usage 

`core::arch` quod est available pars `libcore` et hoc rursus ab `libstd` exportata.Malo per usura hoc `core::arch` per quam hoc vel `std::arch` crate.
Effusus es features available in nocturnis saepius Rust via ad `feature(stdsimd)`.

`core::arch` usura exigit crate via hac nocte Rust et licet (et) frequenter conteram.Per usura is est tantum casibus, in quibus tu considerans quid crate haec sunt:

* rursus si opus componat `core::arch` te, eg, maxime cum target-enabled features est non enabled per `libcore`/`libstd`.
Note: Si vos postulo ut rursus a non-vexillum ad scopum illum componat, et `xargo` uti mallet placere re-usura is pro componendis `libcore`/`libstd` pro opportunitate crate.
  
* quod esset de usura features praesto esse et a tergo levis Rust features.Nos ad haec tentant ut a minimum.
Si necesse est ut aliquid ex his features: aperire commodo exitus, ut est apud nos et redarguite Rust nocturna quidem carpentes, et inde illis uti.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` primo et distributa leges liceret et MIT Apache Foundation (2.0 Vulgata) in varias partes forent sicut operta dissentiet.

LICENTIA APACHE vide-et-LICENTIA ad singula MIT.

# Contribution

Expressis verbis aliud nisi status, conlationem aliquam consulto inclusion est in summitto `core_arch` a vobis, cum in defined Apache licentia-2.0, dual licensed erit ut supra, verbis vel sine additional conditionibus.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












