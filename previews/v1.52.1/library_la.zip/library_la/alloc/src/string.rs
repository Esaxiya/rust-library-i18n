//! Utf-VIII-encoded A, linea augmentabilis.
//!
//! Haec module in [`String`] continet genus et [`ToString`] trait quod attinet ad conversionem ad timeas, si pluribus opus consequuntur errorem, ut in hoc types [`String`] s.
//!
//!
//! # Examples
//!
//! Plures sunt a via ad partum a linea [`String`] litterales,
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! [`String`] vos can partum a novus est per se existentium, cum concatenating
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Si enim est verum vector UTF-8 bytes potes facere [`String`] ex ea.Vos can operor vicissim nimis.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Scimus enim sunt bytes valet, ut youll uti diximus `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Utf-VIII-encoded A, linea augmentabilis.
///
/// Quod genus `String` est maxime communis type quia linea non habet proprietatem circa ilia quae in filum.Quod habeat arctam cum mutuum sui instar, primo [`str`].
///
/// # Examples
///
/// Vos potest creare ex `String` [a literal string][`str`] cum [`String::from`];
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Potes enim [`char`] adiungerem ad modum `String` cum [`push`] et [`push_str`] appendamus a [`&str`] per modum:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Si enim ex vector UTF-8 bytes, vos can partum a `String` [`from_utf8`] modum ex eo quod sunt;
///
/// ```
/// // quidam bytes, in vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Scimus enim sunt bytes valet, ut youll uti diximus `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// String`s valet: semper UTF-8.Haec pauca effectus est: quarum prima est quod si vos postulo a non-filum utf-VIII, considerans [`OsString`].Est similes, sed UTF-8 sine premendo.Secundum, quod vos non est in `String` index:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indexing in animo est constant, esse tempus operandi, sed non patitur nos ad hoc modum translitterandi UTF-8.Praeterea, non quale puto indicem revertatur a byte et codepoint vel grapheme uvam.
/// Et in [`bytes`] modi [`chars`] revertetur in iterators primum duo, respectively.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// String`s effectum deducendi: [`Deref`]`<Target=str>'Et possidebit omnia [str` `]' modi s.Insuper `String` haec opes ut vos can fiat ad munus [`&str`] quae est in utendo ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Hic mos partum a [`&str`], et consequentes ex `String` in. Hoc est valde insumptuosus conversionem: et ideo plerumque, munera mea suscipiet ['&str`] s nisi ut rationes quaedam specifica opus pro `String` rationis.
///
/// Certis determinatisque casibus Rust non habet conversionem satis notitia ut haec, quae [`Deref`] coacto implantari potest.Hoc est in linea segmentum [`&'a str`][`&str`] ad effectum adducit exemplum trait `TraitExample`, et munus ad effectum adducit eo quod accipit `example_func` trait.
/// Duabus conversionibus implicita esset Rust Hic oportet facere, qui non habet Rust instrumento est tribuendum.
/// Ideo exemplum non congero.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Options Sunt duo, quae in loco hoc opus.Primum fore ut mutandi `example_func(&example_string);` `example_func(example_string.as_str());` linea, et linea per modum [`as_str()`] eliciunt ad scalpere quibus expressis verbis ad filum.
/// Secundum viam ad `example_func(&*example_string);` `example_func(&example_string);` mutat.
/// Hic `String` est ad nos dereferencing [`str`][`&str`] ergo indiciunt in [`str`][`&str`] ad [`&str`].
/// Modo secundum quod est obtinuit, quamvis expressis verbis et operis facere ad conversionem quam conversionem freti vel implicite.
///
/// # Representation
///
/// A `String` ex tribus components est: monstratorem aliqua bytes est, longitudo, et facultatem.In regula demonstrat quiddam `String` est internum ejus utitur congregem data.Et longitudinem currently est numerus repono bytes in quiddam, et quod facultatem magnitudinem in bytes quiddam.
///
/// Ut semper longitudinem paribus minor potentia.
///
/// Hoc semper quiddam repono in acervus erit.
///
/// Intueri potes [`as_ptr`] de his, [`len`] et [`capacity`] modi:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // Update FIXME hoc quod stabilitur vec_into_raw_parts.
/// // Ne statim omissa chorda est scriptor notitia
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // fabula est decem bytes
/// assert_eq!(19, len);
///
/// // Et rursus aedificare Gloria possumus extra ptr: Len, atque facultatem.
/// // Sumus responsible haec omnia tuta et certa pro components est consequentia:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Sufficit enim si habeat `String` facultatem, addendo elementa non ad re-deducendae agroque diuidundo.Eg de verbo hoc progressio,
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Haec voluntatis output sequentibus:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Prius datum nulla memoria, sed adscripsi ut filo auget facultatem recte.Si pro [`with_capacity`] uti modum bene esse facultatem initio deducendae agroque diuidundo:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Nos alium output terminus sursum;
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Hic, ibi est nihil magis placeat opus memoria intra loop.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// A errore fieri convertentes, ubi ad valorem `String` ex UTF-8 vector byte.
///
/// Hoc errore genus est genus [`from_utf8`] ad modum in [`String`].
/// Reallocations disposito est ita ut vitare diligenter et dabo retro ad modum [`into_bytes`] byte vector quae in conatus per conversionem.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Quod genus [`Utf8Error`] provisum est a [`std::str`] est error, ut ne cum fieri convertentes Segmentum placentae [`u8`] [`&str`] ad s.
/// Et isto modo `FromUtf8Error` est suus analogon, et vos can adepto unus ex `FromUtf8Error` per modum [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// // nulli alii bytes, per vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// A error poterit de valore cum convertens `String` ex byte UTF-16 scalpere.
///
/// [`from_utf16`] error sit genus ad modum hoc genus in [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Basic usus:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Nova gignit inanis `String`.
    ///
    /// Datum est inanis `String`, hoc ne quis initial quiddam deducendae agroque diuidundo.Dum significat quod qui primam operationem est valde insumptuosus, ut faciam cum nimia prouinciis deinde add data.
    ///
    /// Si enim data `String` ideam apprehendam quantum spectat [`with_capacity`] modo re prohibere nimio destinatio.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Novam gignit `String` vacua maxime cum facultatem.
    ///
    /// `String`s habere quiddam internum suum tenere data.
    /// Quod sit longitudo facultatem quiddam illius: et cum queried [`capacity`] possit modum.
    /// Ut vacuum `String` modus autem qui habent quiddam initiali `capacity` bytes.
    /// Hic erit utilis tibi cum via Ajax fasciculum `String` data est, non indiget reallocations minuere.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Si enim `0` facultatem dedit, nullum erit destinatio fieri, et ad hunc modum nihil est aliud quam [`new`] modum.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Gloria in chars non habet etiam quod habet facultatem, quia etsi amplius
    /// assert_eq!(s.len(), 0);
    ///
    /// // Hi sunt omnia fieri sine reallocating ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // Hoc potest facere ... sed ad filum reallocate
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cum cfg(test) proprium modum `[T]::to_vec`, quae requiritur ad hunc modum definitio est non available.
    // Cum enim hoc requirere, ne iudicetur modum proposita, ut Exlibris stipulas Et sicut videre slice::hack module in slice.rs pro magis notitia
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Et ex bytes vector converts to a `String`.
    ///
    /// A filum factum est ([`String`]) bytes ([`u8`]), et ex vector ([`Vec<u8>`]) bytes factum est bytes, et proselytis hoc munus inter duas.
    /// Non omnis crustae byte String`s`verum tamen, quod postulat `String` UTF-8 valet.
    /// `from_utf8()` Suspendisse ut sint et valida bytes UTF-8, et non per conversionem.
    ///
    /// Si ut certo valet UTF-8 scalpere byte et non vis penes eosdem peri reprehendo caput de validitate, hoc munus non est statio male fida versio, [`from_utf8_unchecked`], quam habet in extrema plebe quaerit reprehendo, sed etiam morum.
    ///
    ///
    /// Haec te cura est non effingo ad modum vector ad efficientiam eruit.
    ///
    /// Si opus [`&str`] loco `String`, considerans [`str::from_utf8`].
    ///
    /// Hoc inversum sit [`into_bytes`] modum.
    ///
    /// # Errors
    ///
    /// Segmentum [`Err`] si non reddit cur UTF-8 descriptione dummodo non UTF-8 bytes.Quod movetur in vector vobis et quod includitur.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // quidam bytes, in vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Scimus enim sunt bytes valet, ut youll uti diximus `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Non recta bytes:
    ///
    /// ```
    /// // nulli alii bytes, per vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Ecce enim importat soUicitudo de [`FromUtf8Error`] pro magis details in quod potest facere hoc errore.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Segmentum placentae bytes converts ad filum: irritum est inter ingenia.
    ///
    /// Gloria fiunt ex ([`u8`]) bytes, et frustum de bytes bytes ([`&[u8]`][byteslice]) est factus, sic inter duas proselytis hoc munus.Valet, filorum omnes crustae byte Non tamen: non requiratur ad esse valet, filorum UTF-8.
    /// Per hanc conversionem, `from_utf8_lossy()` reponere et irritum UTF-8 sequentia adiungit quid ex [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], quod spectat sicut hoc:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Si enim quoniam segmentum byte valet UTF-8, et non vis ad caput in conversionem incurrit, ibi statio male fida versionem hoc munus, [`from_utf8_unchecked`], et mores, sed etiam in extrema plebe quaerit quod habet checks.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Hoc munus a [`Cow<'a, str>`] refert.Si scalpere byte noster irritum UTF-8, et inserere in opus ad characteres postea, quod mutare linea magnitudinem, et etiam aequalitas `String` est requirere.
    /// UTF-8 si suus 'valet prius, non indigent nova destinatio.
    /// Hoc genus reditu concedit utroque casibus nos tractamus.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // quidam bytes, in vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Non recta bytes:
    ///
    /// ```
    /// // nulli alii bytes
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Utf-a Decode XVI-encoded in vector `v` `String`, reversus [`Err`] `v` Si quis habet irritum data.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Hoc fit: : via collecta <Result<_, _>> () Quoniam perficientur de causis.
        // FIXME: Iterum si ad munus simplicior reddi potest #48994 clausus est.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// A FRUSTUM `v` Decode utf-XVI-encoded in `String`, repositoque [the replacement character (`U+FFFD`)][U+FFFD] irritum data sunt.
    ///
    /// Dissimiles quo [`from_utf8_lossy`] [`Cow<'a, str>`] redit, quia `from_utf16_lossy` redit `String` UTF-16 ad conversionem requiritur memoria UTF-8 destinatio.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Et in eius rudis putrescit `String` components.
    ///
    /// Rudis notitia underlying monstratorem redit et, qui in longitudinem filum (in bytes) et disposuit in notitia facultatem (in bytes).
    /// Eadem eodem ordine hae rationes [`from_raw_parts`].
    ///
    /// Post hæc munus vocantem, in RECENS in memoriam ante administrarentur `String` reus est.
    /// Solum enim hoc faciunt ut ad convertendum rudis monstratorem, longitudo et facultatem in tergum `String` cum [`from_raw_parts`] munus, præbens ad tersus destructor praestare.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Novam gignit `String` ex longitudo, capacity et monstratorem.
    ///
    /// # Safety
    ///
    /// Abhorret tutus invariants secundum numerum qui retentus,
    ///
    /// * In memoriam ante `buf` fuisse necesse est quod ante datum eiusdem bibliotheca allocator vexillum ad illos, et prorsus requiritur membrorum dispositione sub vestibus I.
    /// * `length` paribus `capacity` minus necessaria.
    /// * `capacity` necessitates esse valorem bene.
    /// * Primum `length` ad bytes `buf` UTF-8 opus esse verum.
    ///
    /// Ut si violentia inferatur haec causa problems adulterantes quasi allocator internum scriptor notitia structurae.
    ///
    /// Dominium transferri `String` quae tunc efficaciter `buf` deallocate, ostendit memoriam reallocate mutare contenta in regula vult.
    /// Ut post vocant monstratorem nihil aliud est munus in usus.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // Update FIXME hoc quod stabilitur vec_into_raw_parts.
    ///     // Ne statim omissa chorda est scriptor notitia
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Conuerti fecerit vector ad `String` bytes de non reprehendo quod verum UTF-8 filum contineat.
    ///
    /// Versio videre tutum, [`from_utf8`], pro more details.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Hoc munus tutum est, quod verum est, non reprehendo qui illum ad Transierunt bytes UTF-8.
    /// Si necessitate violatur, ut faciam cum future users in rebus memoriae unsafety `String`, quod reliquum putet significari bibliothecam vexillum `String`s UTF-8 non valet.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // quidam bytes, in vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Conuerti fecerit `String` in vector byte.
    ///
    /// Quod est consumptio ipsius `String`, ita non opus ad effingo singula contenta in eodem.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Quae tota linea `String` extrahit secare.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Converts `String` et posterius mutari potest in linea segmentum.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Data linea a FRUSTUM `String` hoc subdit onto finem.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Refert quod `String` scriptor facultatem in bytes.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Haec est certe efficit, ut: String` facultatem `additional` bytes est maior quam longitudo ejus.
    ///
    /// Capacitatem augeri quam si eligit `additional` bytes ne reallocations saepius.
    ///
    ///
    /// Si quod nolo "at least" mores, videbis [`reserve_exact`] modum.
    ///
    /// # Panics
    ///
    /// Si Panics novo redundat [`usize`] facultatem.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Facultatem ad hoc non proficit actu;
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s II longitudinem habet nunc et in facultatem a X
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Cum iam VIII facultatem habent esse extra, hoc vocant ...
    /// s.reserve(8);
    ///
    /// // ... non proficit actu.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Quod `String` facultatem dat operam, ut in maius est quam longitudo `additional` bytes.
    ///
    /// Et utendi modum considerans [`reserve`] nisi quia omnino melius est quam allocator.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Si facultatem Panics novo redundat `usize`.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Facultatem ad hoc non proficit actu;
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s II longitudinem habet nunc et in facultatem a X
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Cum iam VIII facultatem habent esse extra, hoc vocant ...
    /// s.reserve_exact(8);
    ///
    /// // ... non proficit actu.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Subsidium facultatem saltem conatur ad `additional` pluribus elementis datis `String` inserendas.
    /// Ut ne collectis frequenter reallocations spatium reservare.
    /// Post vocant `reserve`: erit maior quam vel aequalis ad `self.len() + additional` facultatem.
    /// Nihil facit si iam sat facultatem.
    ///
    /// # Errors
    ///
    /// Si facultatem redundat ab anima refert allocator vel per defectum, tunc error non redierat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pre-servat memoriam exierunt si non
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Scimus hoc non autem in medio nostri universa opus oom
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Tries reservare minimam facultatem prorsus `additional` pro pluribus elementis datis `String` inserendas.
    ///
    /// Post `reserve_exact` vocant, esse facultatem maior quam vel aequalis ad `self.len() + additional`.
    /// Quod si non sufficient iam facultatem.
    ///
    /// Nota quod allocator ut dat spatium collectio magis quam hoc postulante impetrari.
    /// Ideo facultatem fides est nec esse potest pressius minimam.
    /// Malo si `reserve` future insertiones expectata.
    ///
    /// # Errors
    ///
    /// Si facultatem redundat ab anima refert allocator vel per defectum, tunc error non redierat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pre-servat memoriam exierunt si non
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Scimus hoc non autem in medio nostri universa opus oom
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Et extenuetur hoc facultatem ad inserere `String` longitudo ejus.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Extenuetur facultatem ad hoc `String` ligatus cum inferioribus.
    ///
    /// Capacitas remanebit saltem quod magnum est tam in longitudine quam in supplevimus valorem.
    ///
    ///
    /// Sit vena minus quam facultatem si minus terminum, hoc est, a nulla-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Hunc finem data [`char`] `String` apponit.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Byte refert a FRUSTUM huius: String` de contentis in eodem.
    ///
    /// Hoc inversum sit [`from_utf8`] modum.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Hoc certum est `String` breviora sunt.
    ///
    /// Si `new_len` sit major quam current longitudinem filum est, hoc habet effectus.
    ///
    ///
    /// Note hunc modum habet effectus in facultatem datum de filum
    ///
    /// # Panics
    ///
    /// Panics `new_len` si non mentior in [`char`] terminus.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Quiddam moribus ultima removet chorda et redit.
    ///
    /// Si redeat [`None`] `String` vacat.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Inde ad `String` byte loco removet [`char`] redit.
    ///
    /// Hoc per Domine * *(*n*) operationem, quasi exscribend testatem omnibus postulat quiddam in elementum.
    ///
    /// # Panics
    ///
    /// Si Panics `idx` maior: aequalis String` aut longa aut jacet [`char`] in finem.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Remove totum `pat` in `String` forma est compositus.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// SEE remota et iterum cognitam fraudem, tam in casibus, ubi forma insidunt, nisi ut primum remota forma;
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // Salutem et satus per finem fore in terminis utf8 byte
        // Docs autem scrutatur
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Certa retinet modo characteres a consortio praedicati.
    ///
    /// Hoc est, removere `c` omnes characteres, qui tam `f(c)` `false` refert.
    /// Haec modum operates in loco, prorsus mores inter se aliquando visitare, in quo originale et quietis rationem servent tenuit in ordine ad ingenia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Externum autem ordo utilem semita quasi indicem.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Hos, ut altera parte integer
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Addit ad rationem `String` byte hanc dignitatem.
    ///
    /// Hoc est, quod *o*(*n*) operationem quasi exscribend testatem omnibus elementum in postulat quiddam.
    ///
    /// # Panics
    ///
    /// `Si maior Panics `idx` String` longa aut jacet [`char`] in finem.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Segmentum inserit nervo `String` ad hunc locum byte.
    ///
    /// Hoc est, quod *o*(*n*) operationem quasi exscribend testatem omnibus elementum in postulat quiddam.
    ///
    /// # Panics
    ///
    /// `Si maior Panics `idx` String` longa aut jacet [`char`] in finem.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Refert ad commutabile quae in hoc `String`.
    ///
    /// # Safety
    ///
    /// Hoc munus tutum est, quod verum est, non reprehendo qui illum ad Transierunt bytes UTF-8.
    /// Si necessitate violatur, ut faciam cum future users in rebus memoriae unsafety `String`, quod reliquum putet significari bibliothecam vexillum `String`s UTF-8 non valet.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Redit hoc `String` in longitudinem, in bytes non [`char`] s vel graphemes.
    /// In aliis verba, quae non licet homini considerat id quod est longitudinem filum.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Si hoc habet longitudinem nulla `String` `true` redit et `false` aliter.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Scinditur in duas chordas dato byte p.
    ///
    /// Refert enim nuper `String` partita imperia.
    /// `self` `[0, at)` bytes habet, et quod habet rediit `String` bytes `[at, len)`.
    /// `at` et in codice punctus est terminus de UTF-8.
    ///
    /// Nota quod facultatem de `self` non mutantur.
    ///
    /// # Panics
    ///
    /// Panics `at` si non est punctus est terminus `UTF-8` codice vel si ultra illud est ultimum punctum in linea codice.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Truncat haec `String` et auferam omne contentis in eodem.
    ///
    /// Ita et habebis longitudinem `String` nulla facultas non attingunt.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// In statutis vero fugerunt state iterator creates a quo etiam removentur range in `String` vero tollit et ad `chars` remota.
    ///
    ///
    /// Note: Elementum rhoncus etsi remota iterator usque non consumitur.
    ///
    /// # Panics
    ///
    /// Si Panics puncto incipiens et finem in puncto non mentior [`char`] terminus, seu si tu ex terminis.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Donec rhoncus auferret β citharizatur
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // A plena range libavit natae filum
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // memoria salutem
        //
        // Gloria in versionem Drain qui non habet salutem quaestiones ex memoria vector version.
        // Data est plane bytes.
        // Quia range remotionem fieri in cupit, quaeque in Drain iterator est, remotionem non fit.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Ut bonis detrahebant mihi duos simultaneous.
        // Gloria in &mut non est super accessed ad iteration in Drop.
        let self_ptr = self as *mut _;
        // Utilitatibus consulens, et `slice::range` `is_char_boundary` oportet fines facere checks.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Tollit speciem rhoncus chordam atque succedit data linea.
    /// Non esse chorda datam latitudinem longitudo.
    ///
    /// # Panics
    ///
    /// Si Panics puncto incipiens et finem in puncto non mentior [`char`] terminus, seu si tu ex terminis.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Pro β citharizatur latitudine usque ad
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // memoria salutem
        //
        // Non ex memoria Replace_range vector Splice salutem exitus.
        // de vector version.Data est plane bytes.

        // MONITUM: ut Inlining hoc variabilis prius exploranda finxisset (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // MONITUM: ut Inlining hoc variabilis prius exploranda finxisset (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Per se prius exploranda finxisset `range` iterum (#81138) super nos relatum per fines `range` manet eadem et in adversaria implementation possit mutare inter vocat
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// In hoc proselytis `String` [`Box`] '<`[' str`] '>: .
    ///
    /// Hoc mos facultatem stillabunt excessus.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Segmentum placentae returns [`u8`] s, ut eorum conatus bytes convertere ad `String`.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // nulli alii bytes, per vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Conati sunt ad convertendos redit `String` KB.
    ///
    /// Hac methodo propter studiose destinatio.
    /// Et devorabit errore, sicco movere bytes, ut est exemplum in bytes non sit necesse est.
    ///
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // nulli alii bytes, per vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Ibitque per `Utf8Error` impetro magis details de conversionem defectum.
    ///
    /// Quod genus [`Utf8Error`] provisum est a [`std::str`] est error, ut ne cum fieri convertentes Segmentum placentae [`u8`] [`&str`] ad s.
    /// In hoc sensu, est analogon `FromUtf8Error` sunt.
    /// Vide eius Documenta singula ad plures usus in illo.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// // nulli alii bytes, per vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // byte irritum hic primus
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Quia nos: iterando super String`s, prouinciis ab una saltem possumus vitare questus prima filum de constructione et ad eam iterator subsequent omnia trahunt.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Quoniam tu iterating super boves (potentially) possumus vitare questus a prima destinatio saltem unus item constructione et ad eam omnes subsequent items.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// A commodo impl qui impl mittere non enim `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// `String` inane facit.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Ad effectum adducit `+` concatenating operator nam duo sunt modulationes uocum.
///
/// `String` est consumptio ipsius a sinistra-manus et latus-utitur re sua quiddam (crescente si opus sit).
/// Haec est totius ne opum novum continet in exscribendis `String` et super omnem operationem, quae esset ducunt ad *o*(* * n ^ II) currit tempus in aedificationem et concatenationem *n*-byte filum sæpius repetitis.
///
///
/// Mutuatus est de funiculo dextris;copied sunt in rediit `String` singula contenta in eodem.
///
/// # Examples
///
/// Per `String`s tollit primum duo Concatenating horum mutuo postulaverit, et secundum valorem:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` non possum esse hic et non movetur.
/// ```
///
/// Si vos volo ut servo usura `String` primis potes et cDNA clone: Cuius est in loco:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` verum etiam hic.
/// ```
///
/// Concatenating `&str` purus `String` fieri a prima conversione;
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `+=` operator est ad effectum adducit appending `String`.
///
/// Hoc idem est ac mores et modum [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// A genus ad alias [`Infallible`].
///
/// Haec enim existit alias retro compatibility et potest eventually vituperabile.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// A trait quod attinet ad conversionem a valore ad `String`.
///
/// Hoc est trait implemented statim ad aliquam speciem, quae ad effectum adducit [`Display`] trait.
/// Ita ut, `ToString` non implemented ut recta;
/// [`Display`] ut implemented in loco, et vos adepto in `ToString` implementation gratis.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Converts datis `String` ad valorem.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// In hoc implementation, ad modum `to_string` si panics implementation `Display` error refert.
/// Haec indicat est quia falsa `Display` implementation `fmt::Write for String` refert numquam se errorem.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // A commune est non sit ratio, weight munera genere.
    // Sed haec ratio rugosa facit removere a `#[inline]` non-regressuum exiguus.
    // Vide <https://github.com/rust-lang/rust/pull/74852> ultimum conatum conantur auferre.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Conuerti fecerit `&mut str` in `String`.
    ///
    /// Effectus in diuisione in eum.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test observabitis libstd, unde errores
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Converts `str` FRUSTUM solere vel ad `String` datis.
    /// Notum est quod `str` FRUSTUM fuit.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Converts datis `String` ad scalpere `str` quod possidetur solere.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Acceperam a linea segmentum converts in variant.
    /// Nulla fit acervus destinatio et non filum in prima ad naturalia.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Gloria in possessores et proselytis et variant.
    /// Nulla fit acervus destinatio et non filum in prima ad naturalia.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Gloria in conuerti fecerit referat acceperam variant.
    /// Nulla fit acervus destinatio et non filum in prima ad naturalia.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Converts datis `String` ad vector `Vec` qui tenet `u8` genus ipsius.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// A fudit residuum ad `String` iterator.
///
/// Hoc est efficere creatus per modum [`drain`] in [`String`].
/// Vide eius pro documentis magis.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Et quod&usum, mut a Gloria in destructor
    string: *mut String,
    /// Ad initium partem remove
    start: usize,
    /// De parte ad removendum End
    end: usize,
    /// Reliqua rhoncus tollere current
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain usus.
            // "Reaffirm" Suspendisse panic codice ne ultra terminos inseratur.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Reliquis redierit! (SUB) iterator hac linea ad scalpere.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: Uncomment AsRef impls cum stabilientem infra.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Uncomment cum stabilientem `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain quia <* sit> {n as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> enim Drain <' a> f {as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}