//! - Flat computatis referat unum-indicibusque.'Rc' stands for 'Reference
//! Counted'.
//!
//! Genus [`Rc<T>`][`Rc`] praebet et valorem de dominio communis generis `T`, datum est in eum.
//! Invocato [`clone`][clone] in [`Rc`] novam regula ad destinatio eiusdem in eum.
//! Ultimo data cum monstratorem a destinatio [`Rc`] dissolvatur, quod destinatio ad valorem conditur (saepe relatum ut ut "inner value") est, qui quærunt te.
//!
//! Rust participatur in Concept disallow mutationem per default et [`Rc`] nulla exceptione: non possis assequi plerumque ad aliquid intus in [`Rc`] mutabilem uerteretur.
//! Si indigent mutabilitate transcurrit, [`RefCell`] posuit [`Cell`] sive intra [`Rc`];[an example of mutability inside an `Rc`][mutability] videatur.
//!
//! [`Rc`] nuclei utitur non-reference est numerus.
//! Olli id nimis sed non mittuntur inter fila [`Rc`] proinde [`Rc`] [`Send`][send] non diam.
//! Qua de causa, quod compiler Rust reprehendo vicis compile * * a te non mitto [`Rc`] s inter relatorum.
//! Si oportet contristari staminea multi-, referat nuclei illa, uti [`sync::Arc`][arc].
//!
//! Et [`downgrade`][downgrade] modum adhiberi possit creare [`Weak`] non-culpa rubet vultus monstratorem.
//! A monstratorem [`Weak`] esse [upgrade` `][upgrade] d ad [`Rc`] sed reddam [`None`] pretii si conditur relatum est jam factus.
//! Praeterea, `Weak` indicatores, quae non servant valorem quod intus vivit de prouinciis permittit,tamen, qui *hoc destinatio ut*(advocatam copia ad interiorem valorem) viveret.
//!
//! A exolvuntur inter [`Rc`] indicibusque numquam deallocated.
//! Idcirco, quod [`Weak`] ad conteram conuersione recurrentium.
//! Ut de ligno posset validis argumentis [`Rc`] nodis parens liberis ac parentibus [`Weak`] indicibusque parvulis restituit.
//!
//! `Rc<T>` statim ut dereferences `T` ([`Deref`] in via trait) ut possis in dicimus `modi'sT` generis et pretii [`Rc<T>`][`Rc`].
//! Ne modi'sT`, cui nomen dedere, methodi ad se [`Rc<T>`][`Rc`] munera consociata sunt, vocatur usus [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! Re: <T>`S implementations de traits sicut `Clone` ut quoque dicitur uti plene qualified syntax.
//! Ut nonnulli potius plene qualified Syntax, cum aliis per modum malo integra vocatio, Syntax.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Modum vocationem, Syntax
//! let rc2 = rc.clone();
//! // Syntax plene qualified
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] non auto-`T` ad dereference, quia interiorem potest habere valorem iam elapsum excidit.
//!
//! # cloning references
//!
//! Destinatio respectu eorumdem creando novum reputantur respectu existente sub regula est et [`Weak<T>`][`Weak`] [`Rc<T>`][`Rc`] `Clone` trait enim amet.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Duo sunt infra syntaxes pi ° instituatur.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // et in puncto ad idem b et a loco in memoriam foo.
//! ```
//!
//! Syntax `Rc::clone(&from)` quod est quod importet plus obtinuit omnium significatione expressis verbis in codice.
//! Exemplo in hac syntaxis quod facilius est quam secundum Codicem hunc creando novum ritum omnem materiam foo.
//!
//! # Examples
//!
//! Gadget`s consider a sem in a paro falsi, quae data est haberet dominum nomine `Owner`.
//! Ut volumus: nobis Gadget`s puncto ad `Owner`.Possumus hoc unique ius est, quod ultra quam ad idem pertinent, ut gadget `Owner`.
//! [`Rc`] per `Gadget`s plures participes inter `Owner` nobis concedit; et dum nullam habent `Owner` remain prouinciae ita `Gadget` punctorum ad illam.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // Alius agros ...
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // Alius agros ...
//! }
//!
//! fn main() {
//!     // Et crea-reference counted `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `Creare Gadget`s ad `gadget_owner`.
//!     // In regula Cloning `Rc<Owner>` a nobis eidem `Owner` destinatio, numerum referendum incrementing comparare.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Animum nostrorum locorum `gadget_owner` variabilis.
//!     drop(gadget_owner);
//!
//!     // Quamvis `gadget_owner` mittentem aera, sumus tamen potest imprimere per `nomen `Owner` Gadget`s.
//!     // Hoc est quia proiecit uno `Rc<Owner>` Ive 'tantum, illud ostendit, non esse `Owner`.
//!     // Quamdiu illic es alius `Rc<Owner>` pointing `Owner` destinatio ad idem, manere eam et vivet.
//!     // Nam facit ut `Owner` dereferences `Rc<Owner>` ipso campo `gadget1.owner.name` proiecturae.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Ad extremum functione `gadget1` `gadget2` succidentur et, quibus ultimus numeratur `Owner` References nostris.
//!     // Tam sero iam gadget perdidit.
//!     //
//! }
//! ```
//!
//! Si nostrum commodum convertere, et etiam oportet esse potest insito percursurum fuisset `Owner` `Gadget` est, faciemus in current problems.
//! An [`Rc`] a monstratorem `Owner` ad `Gadget` inducens exolvuntur.
//! Reference hic modo, ut suum non valet pervenire possit 0, ac de prouinciis in æternum non dissipabitur,
//! memoriam Leak.Et quo ad hoc circuitu nos potest uti indicium [`Weak`].
//!
//! Quia et ipsa Rust aliquantum difficile est loop in primo loco, ad producendum.Ut iam ad finem usque duo bona inter se, quis esset ex eis necessario posterius mutari potest.
//! Nisi quia hoc difficile [`Rc`] dicens communia quae ad salutem dabuntur commemorationem inducitur quanti haec directo non patitur mutationem.
//! Non opus ad involvent partem pretii si vis [`RefCell`] uolueris, in quo intus praebet * * mutabilitate variantibus, ad consequi ad modum participatur per attendatur mutabilitas rei constituunt.
//! [`RefCell`] dabuntur Rust mutuatus est scriptor praecepta in runtime.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // Alius agros ...
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // Alius agros ...
//! }
//!
//! fn main() {
//!     // Et crea-reference counted `Owner`.
//!     // Nota quod 'Owner`quod weve' s intus in `RefCell` Gadget`s vector falsi, ut possimus per eam participatur mutate referat.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // `Creare Gadget`s ad `gadget_owner`, ut prius.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Addere ad ly 'Gadget`s `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` Finit hic admodum postulet.
//!     }
//!
//!     // Iterate super nos: Gadget`s, excudendi singula ex suo.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` `Weak<Gadget>` est.
//!         // Cum argumentis `Weak` destinatio non praestetur adhuc oportet dicere `upgrade` reducit ad `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Scimus Hic relatum adhuc existit, non solum ut in `unwrap` `Option`.
//!         // Progressio est magis complicated Et tu graceful opus est ut in errorem `None` tractantem exitum.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Fine functione `gadget_owner`, `gadget1` et `gadget2` pereunt.
//!     // Sunt autem iam validis argumentis (`Rc`) gadgets et conterentur.
//!     // In hac narratione zeroes referatur Gadget homo perdidit ille tam sero.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Hoc est repr(C) future-probationem enim refectio, in agrum esse, qui aliter tutam intermixti essent transmutabiles [into|from]_raw() ex interiore types.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// A-staminea referat unum, numerus monstratorem.'Rc' stands for 'Reference
/// Counted'.
///
/// Vide autem pro magis details [module-level documentation](./index.html).
///
/// `Rc` modi inhaerentem, et omnes consociata munera, qui tibi opes, ut appellare ad illos eg, [`Rc::get_mut(&mut value)`][get_mut] pro `value.get_mut()`.
/// Hoc genus `T` vitat confligit modi per interiorem.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Hoc unsafety est ok, est quia dum hic vivit Re monstratorem nos spopondissemus interiorem valet.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Surculis construere novum `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Regula infirmata sit amet implicita indicibusque ab omni quod facit cum fortibus debiles destructor destinatio non liberat destructor currit, etiamsi infirmus fortis intus reconditum regula.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Surculis construere novum `Rc<T>` usus infirmi ad ipsum.
    /// Conanti ut upgrade referat infirma antequam munus hoc mihi proveniet in `None` valorem redit.
    ///
    /// Tamen, ut referat infirma sit congregatio sponte et cloned sunt in novissimis temporibus.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // More ... agri
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Constituat "uninitialized" in interiorem statum infirmi et referat unum.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Gravis monstratorem non dare dominium infirmum aut liberabitur memoriam redit `data_fn` tempore.
        // Si fieri uellent dominio monstratorem nos infirmi sumus addit posse, sed etiam accideret updates secundum praescriptum infirmis ne necesse sit.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Ut communiter commune habent debilem fortem Greek Quantum ad senem infirmum ne destructor ordine currunt.
        //
        mem::forget(weak);
        strong
    }

    /// Surculis construere novum `Rc` uninitialized de contentis in eodem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Initialization in diem differatur;
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Cum novas molitur `Rc` uninitialized contenta plenae memoria `0` bytes.
    ///
    ///
    /// Vide [`MaybeUninit::zeroed`][zeroed] ad modum huius usus exempla in recto et falsa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Surculis construere novum `Rc<T>`: Si reversus errorem cadit uocato
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Regula infirmata sit amet implicita indicibusque ab omni quod facit cum fortibus debiles destructor destinatio non liberat destructor currit, etiamsi infirmus fortis intus reconditum regula.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Surculis construere novum `Rc` uninitialized de contentis in eodem nisi destinatio ratio errorem reverti
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Initialization in diem differatur;
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Surculis construere novum `Rc` de contentis in eodem uninitialized cum impleta esse memoriae `0` bytes: Si reversus destinatio ratio an error
    ///
    ///
    /// Vide [`MaybeUninit::zeroed`][zeroed] ad modum huius usus exempla in recto et falsa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Surculis construere novum `Pin<Rc<T>>`.
    /// Si non peragendam `T` `Unpin` igitur `value` fixus erit memoria non commovebitur.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Refert interiore valorem, si `Rc` sed unum est fortis referat.
    ///
    /// Alioquin [`Err`] est in eadem reuertens similiter `Rc` hoc praetextu.
    ///
    ///
    /// Hic erit succedant etiamsi multa sunt eximia infirma p.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // ad effingo continebat object

                // Et non indicavit Weaks promoveretur decrementing fortis comitem, dum manus tollere implicite "strong weak" regula dialectica justo dui innectis fictus infirmis.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Surculis construere novum referat-counted uninitialized FRUSTUM de contentis in eodem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Initialization in diem differatur;
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Segmentum novo construere deputatus est referendum uninitialized contenta plenae memoria `0` bytes.
    ///
    ///
    /// Vide [`MaybeUninit::zeroed`][zeroed] ad modum huius usus exempla in recto et falsa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Proselytis et `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Ut apud [`MaybeUninit::assume_init`] est usque ad obligandae fidei in interiore ma gistrum suum valorem vere in civitate Initialized est.
    ///
    /// Hoc nondum plene initialized causas vocant contentus statim cum indefinita mores.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Initialization in diem differatur;
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Proselytis et `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Ut apud [`MaybeUninit::assume_init`] est usque ad obligandae fidei in interiore ma gistrum suum valorem vere in civitate Initialized est.
    ///
    /// Hoc nondum plene initialized causas vocant contentus statim cum indefinita mores.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Initialization in diem differatur;
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Manducat `Rc`, involvit quod reverti monstratorem.
    ///
    /// Ne memoria reducitur ad Leak `Rc` monstratorem usura [`Rc::from_raw`][from_raw] convertentur.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Praebet rudis monstratorem data.
    ///
    /// Comites ne ullo modo affectus `Rc`, et non combureretur.
    /// Sicut validum diu regula est, quod non valent duco in `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // Salutem: iste non potest Deref::deref vel per quod Rc::inner
        // quo retineant, requiritur talis eg raw/mut provenientia
        // `get_mut` Re est cum monstratorem scribere per `from_raw` recuperauit.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Construit `Rc<T>` a rudis monstratorem.
    ///
    /// Viva regula [`Rc<U>::into_raw`][into_raw] ubi est prius vocationis redit `U` quasi noctis habebunt scalpturaque `T`.
    /// Haec si vera `U` Triviae in modum plantatas `T` est.
    /// Si autem `T` `U` quod non est eadem magnitudine et Gratia diei et noctis, hoc est basically tamquam causam transmutantem de references diversorum generum.
    /// Vide [`mem::transmute`][transmute] pro magis notitia de hac re quae restrictiones competiturum.
    ///
    /// A user has a `from_raw` fac a certis de `T` valorem omissa tantum semel.
    ///
    /// Officium hoc tuta improprietas educere memoriae unsafety etiamsi numquam rediit `Rc<T>` obvius.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Et conversus ad `Rc` ne Leak.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Praeterea vocat memoriam, ut `Rc::from_raw(x_ptr)` esset tutum.
    /// }
    ///
    /// // Cum memoriam liberatus `x` egressus est vis ut nunc `x_ptr` pendere?
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Ut novis epistolis offset invenire originale RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Gignit id est regula ad novum [`Weak`] destinatio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Fac pendet Infirma si non efficiunt
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Fuerit numerus [`Weak`] indicibusque ad destinatio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Accipit hoc indicium firma (`Rc`) destinatio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Vel si alius `Rc` [`Weak`] `true` revertitur ad indicium destinatio.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// In quantum est mutabile `Rc` redeat si nulla alia indicia [`Weak`] `Rc` seu destinatio eiusdem.
    ///
    ///
    /// [`None`] aliter redit, quia ad mutate salvum non participatur ad valorem.
    ///
    /// Vide etiam [`make_mut`][make_mut], quod [`clone`][clone] interiore valorem cum alia indicia sunt.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Reversus est in ordine `Rc` commutabile nihil reprehendo.
    ///
    /// Vide etiam [`get_mut`], qui incolumem non oportet compescit.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Destinatio eiusdem alia indicia non [`Weak`] `Rc` sive durationis dereferenced mutuo rediit.
    ///
    /// Haec Triviae in modum plantatas in causa tali, si nullum indicium est, exempli gratia statim post `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Ut non nos ex * * creare a covering referat "count" agros, ut referat ad hoc repugnat formaliter febrium (eg
        // per `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Si duo Rc`s `true` redit: eadem destinatio ad punctum (in vena autem similis [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Facit referat ad commutabile `Rc` dedit.
    ///
    /// Si quae aliae sunt `Rc` indicibusque ad idem destinatio, deinde interiore valorem [`clone`] `make_mut` erit unique ad novam kardo constituti ensure detentio.
    /// Hoc etiam relatum ut ut est, clone scribam.
    ///
    /// Alia si non argumentis huic `Rc` prouinciis deinde destinatio hoc erit indicium [`Weak`] disassociated.
    ///
    /// Vide etiam [`get_mut`], quod magis deficere quam maxime exquisitis rationibus.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Non clone quicquam
    /// let mut other_data = Rc::clone(&data);    // Nolo clone interiore notitia
    /// *Rc::make_mut(&mut data) += 1;        // Clones interiore notitia
    /// *Rc::make_mut(&mut data) += 1;        // Non clone quicquam
    /// *Rc::make_mut(&mut other_data) *= 2;  // Non clone quicquam
    ///
    /// // Et nunc `data` `other_data` prouinciis referentibus iam diversis.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] indicibusque ut disassociated:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Redditus in data clone: sunt aliae RCS.
            // Pre-deducendae agroque diuidundo memoria sineret scribo ad valorem cloned directe.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Furantur non solum in notitia, suus 'omnes quia egressus est Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Remove interpretatus fortes infirma-gi (non opus ad artem fake hic infirmum-Weaks non scimus aliud in nobis emundare)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Quia haec unsafety est ok modo dubia esse regula rediit * * monstratorem sit quod reddidit umquam potest T-
        // Hoc punctum I ad quod referat ad comitem nostrum certo, quod requiritur ad hoc ipsum ut sint `Rc<T>` `mut` sic erant 'reddens solum possibile ad destinationi.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Qui conturbas me conatus `Rc<dyn Any>` ad certam ac definitam genus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Allocates spatium sat est `RcBox<T>` cum unsized interiorem hominem possibile est pro valore valorem habet ubi provisum layout.
    ///
    /// Munus monstratorem `mem_to_rcbox` quod dicitur et est notitia cum reverteretur retro ad (secundum potentiam adipem)-pointer ad `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Calculate layout utendo valorem layout datis.
        // Previously, in Calculus initus layout expressio `&*(ptr as* const RcBox<T>)` sed creatum est misaligned reference (see #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Allocates `RcBox<T>` est locus apud sufficient ad valorem interiorem hominem possibile est unsized valorem habet ubi provisum layout, in error Si reversus destinatio ratio.
    ///
    ///
    /// Munus monstratorem `mem_to_rcbox` quod dicitur et est notitia cum reverteretur retro ad (secundum potentiam adipem)-pointer ad `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Calculate layout utendo valorem layout datis.
        // Previously, in Calculus initus layout expressio `&*(ptr as* const RcBox<T>)` sed creatum est misaligned reference (see #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Deducendae agroque diuidundo enim at arcu.
        let ptr = allocate(layout)?;

        // RcBox ad initialize
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Allocates in `RcBox<T>` spatium sat sunt ad interiorem unsized in valorem
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Deducendae agroque diuidundo ad `RcBox<T>` uti datis valorem.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Pro valore exemplum bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Non est privata fetu contenta in eodem destinatio liberate
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Per longitudinem datam allocates `RcBox<[T]>`.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Effingo ex elementis fragmen nuper in Re datum <\[T\]>
    ///
    /// Dominium aut accipiat aut ligare tuta `T: Copy` RECENS
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Construit `Rc<[T]>` iterator est ex quadam nota sit magnitudo.
    ///
    /// Temporis ut sit mole sint mores ad iniuriam.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T maxime exquisitis rationibus Panic relicta elementa.
        // In eventu de panic, sunt elementa, quae scripta sunt in novum RcBox erit omissa, tunc memoria liberari.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Indicium est primum elementum
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Omnes patet.Novae militiae, ut non obliviscar liberabo RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializatione trait propter `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` deponat.
    ///
    /// Hoc autem decrement fortis referat ad comitem.
    /// Nisi forte secundum quam nulla spatia comes si aliis (si) [`Weak`] et sic interior `drop` pretium.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Does non procer quicquam
    /// drop(foo2);   // Maps "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // quae rem destruere
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // remove regula vel implicite "strong weak" iam ut weve 'destrui de contentis in eodem.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Facit a clone de `Rc` monstratorem.
    ///
    /// Facit eadem regula destinatio alia augendo forte secundum numerum.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Novam gignit `Rc<T>` cum `Default` valorem pro `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack sineret qui specialiter super `Eq` etsi `Eq` habet modum.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Erant hic agis hic specialis et non a communioribus in `&T` ipsum, quia esset addere aliud sumptus ad aequalitatem refs impediunt.
/// Rc`s super nos habebant quoniam qui ad magnam condo valoribus, qui sunt tardi corde ad clone, sed in gravibus quoque reprehendo pro aequalitatem, ut talis reddere sumptus off facilius.
///
/// Et hoc est verisimile habere plus duas `Rc` clones, quae ad idem punctum pretii, quam duas `&T`s.
///
/// Possumus nisi hoc quod `T: Eq` quasi de industria irreflexive `PartialEq` esset.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// `Rc`s aequalitatem, duabus.
    ///
    /// Duobus internis: Si bona Rc`s funt aequales diuersis prouinciis si latent.
    ///
    /// Si `T` effectum adducit et `Eq` (aequalitatem importat ex reflexivity), qui duorum `Rc`s eodem puncto ad destinationem semper æquales.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// De Inaequalitatibus Quas duas: Rc`s.
    ///
    /// `Duae Rc`s non sunt aequalia, quorum interiorem, si valores sint inaequales.
    ///
    /// Si `T` `Eq` et effectum adducit (reflexivity importet aequalitatem Dei) Rc`s quod`duo puncto ad idem destinatio non sunt inaequales.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Sive partiales collatio duabus: Rc`s.
    ///
    /// Duo vocantem comparentur `partial_cmp()` in interiorem animationem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Minus est comparationis, quia `duo Rc`s.
    ///
    /// Duo sunt, comparari ab vocant `<` in interiore animationem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Minus quam aut aequalis continuationi': collatio duabus Rc`s.
    ///
    /// Duo sunt, comparari per interiorem vocant `<=` in animationem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Comparationis, quia maior quam duas: Rc`s.
    ///
    /// Duo comparari quae ab interiore in values `>` vocant.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Ut maior aut aequalis,: duabus Rc`s collatio.
    ///
    /// Duo sunt vocantem comparari ab `>=` in interiorem animationem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Collatio: nam duo Rc`s.
    ///
    /// Duo sunt in interiorem `cmp()` vocant comparari per animationem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Referendum est cloning placeat numeratur per `secare implevi V` item s.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// In linea segmentum counted referat deducendae agroque diuidundo, et effingo illud in `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// In linea segmentum counted referat deducendae agroque diuidundo, et effingo illud in `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Movendam rem solere nova ordine numerari destinatio.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Referendum est reputabitur de Verre V` placeat: item eam moveri.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Liberum permittit Vec memoria non contenta perdere
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Id est in singulis colligit `Rc<[T]>` `Iterator` elementum.
    ///
    /// # habet euismod
    ///
    /// ## Et casu dux
    ///
    /// In universali coacto fit primum in colligendis in `Rc<[T]>` `Vec<T>`.Hoc est, quando scribebat quae sequuntur:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// iste se tamquam si scripsi:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Primum paro of prouinciis referentibus accidit hic.
    ///     .into(); // A destinatio et secundo fit `Rc<[T]>` hic.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Deducendae agroque diuidundo Hoc erit legitimus: totidem quot et necessariam ad fabricandum `Vec<T>` venerat ad eum et simul deducendae agroque diuidundo `Vec<T>` in `Rc<[T]>`.
    ///
    ///
    /// ## Notae autem Iterators
    ///
    /// Cum `Iterator` effectum adducit `TrustedLen` tua et ex certa magnitudine, ut in unum destinatio pro `Rc<[T]>`.For example:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Fit sicut unum destinatio hic.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// trait propter specializatione in colligendis `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Haec causa est `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SALUS: Nos postulo ut iterator autem habeat rectam et longitudo habeat.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Cadunt ad normalis implementation.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` Est versionem [`Rc`] eodem loco non est, culpa rubet vultus ad managed destinatio.Destinatio enim accessed per [`upgrade`] in `Weak` vocant monstratorem, quae refert ad [`Option`]`<: [`Rc`]`<T>> '.
///
/// Quia non est numerare referat ad `Weak` potest, ne non de valore condita relatum esse depositas, quae non facit `Weak` polliceri se in pretii etiam non praesentis.
/// Ita ut reverteretur cum [`None`] [`upgrade`] d.
/// * * Impedire non tamen nota quod in `Weak` destinatio se referat (advocatam copia) quod ex deallocated.
///
/// A monstratorem `Weak` utilis est ad con tinendam tempus destinatio tractanda [`Rc`] sine quo minus sua pretii ab interioribus quae relinquantur.
/// Et id ad circinum ne [`Rc`] references inter acuunt, quia culpa rubet vultus mutua references nunquam patitur esse vel [`Rc`] est factus.
/// Puta lignum [`Rc`] potuit validis argumentis nodis a parentibus liberis ac parentibus restituit `Weak` indicibusque parvulis.
///
/// Ut modo proprium est regula habeatur `Weak` [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Hoc est patitur `NonNull` optimizing in enums magnitudinem huius generis, sed non necessario validum monstratorem.
    //
    // `Weak::new` Hoc facit ut non opus `usize::MAX` spatio tumulus placeat.
    // Non de valore quod verum erit unquam habebit monstratorem quod habet RcBox dam saltem II.
    // Et hoc modo potest esse cum `T: Sized`;unsized `T` non dangle.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Surculis construere novum `Weak<T>`, sine ullo memoriae allocating.
    /// [`upgrade`] vocant, semper valorem dat [`None`] in reditu.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Paracletus autem accessing typus patitur ut referat comites facere sine notitia ad nihil affirmare agro.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Redit monstratorem quod crudum `T` `Weak<T>` hoc ostendit.
    ///
    /// Ratum tantum, si non est quaedam regula est et fortis p.
    /// In monstratorem vicem obtinere non potest: Unaligned [`null`] vel secus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Tum puncto ad idem object
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Hic fortia detinet causa, ut res adeo.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Sed non quaelibet magis.
    /// // weak.as_ptr() possumus facere, nisi esset accessing Regula in indefinitum ducunt ad mores.
    /// // assert_eq? ("Salve", statio male fida {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Si enim regula pendet, si igitur speculator qui recta revertetur.
            // Electronica valida payload hoc non potest esse quod est minus quam payload RcBox (usize) varius quam.
            ptr as *const T
        } else {
            // SALUS: si is_dangling redeunt falsum, tunc dereferencable monstratorem sit.
            // De potest payload cum egredereris in loco isto, et habebit ponere provenientia ita uti rudis regula manipulation.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Vertit in `Weak<T>` sumit crudum monstratorem.
    ///
    /// Hoc converts rudis et infirmi, in monstratorem monstratorem, dum adhuc conservare ad proprietate infirma referat unum (cum infirma comitem positus non restringitur per hoc operandi).
    /// Potest conversus est retrorsum et [`from_raw`] in `Weak<T>`.
    ///
    /// Idem cum [`as_ptr`] utilium monstratorem accessu scopo convenire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// A monstratorem converts rudis antea [`into_raw`] in `Weak<T>` creata.
    ///
    /// Hoc potest fortis esse tutum ut referat (a later [`upgrade`] vocant) seu ad comitem a Cretensibus `Weak<T>` deallocate autem infirma.
    ///
    /// Infirma suscipit dominium respectu (praeter indicia [`new`] creatura, quae non sibi aliquid operetur eorum tamen ratio).
    ///
    /// # Safety
    ///
    /// Debet esse ex hac tamen regula est [`into_raw`], et ejus potential habent infirma referat.
    ///
    /// Licet non ad esse fortis comitem vocant 0 ad hoc tempus.
    /// Nihilominus venerit istud dominium referat unum currently infirma persona dicitur rudis in regula (infirma in hac operatio non alterari comitem) et igitur eam esse priorem vocationem ad paribus cum [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Decrement ultimum infirma comitem.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Vide quomodo initus monstratorem super Weak::as_ptr in contextu inventa ducuntur.

        let ptr = if is_dangling(ptr as *mut T) {
            // Hoc pendet infirmum.
            ptr as *mut RcBox<T>
        } else {
            // Alioquin fides monstratorem nos ab nondangling sit inualidus.
            // Utilitatibus consulens tutum data_offset sit appellare, quod ptr references verum (cecidit in potentia) A.
            let offset = unsafe { data_offset(ptr) };
            // Ut nos novis epistolis ad universum RcBox offset.
            // SALUS et originated fecit a regula, ut haec offset sit tutum.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // Salútem: si iam recepit ad originale Infirma monstratorem, ita potest creare an in pluribus.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Conatus ad upgrade `Weak` monstratorem [`Rc`] moratur stillatione prodest si interiorem effectum.
    ///
    ///
    /// Si refert [`None`] habet cum interiore valorem omissa sunt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Dissipate universos fortes indicibusque.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Hoc habet demonstrato argumentis (`Rc`) firma destinatio.
    ///
    /// Si `self` creatus per [`Weak::new`], hoc reddet 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Hoc demonstrato argumentis fit numerus `Weak` destinatio.
    ///
    /// Si manent fortis indicium haec revertentur nulla.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // diminuere vel implicite ptr infirmi
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Refert `None` cum monstratorem est datum non esse, et vicem obtinere `RcBox`, (id est, a quo creata est `Weak` `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // * * Ne nos ex ad partum a covering referat "data" est ager, agri et mutari possunt esse simul (exempli gratia, si sit ultima `Rc` stillarunt, etiam notitia in-place agro erit omissa).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Si duo `true` redeunt ad idem punctum: Weak`s destinatio ([`ptr::eq`] similis), vel utrumque non ad designandum destinatio (nam et creata sunt `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// `Weak::new()` quin hoc indicium comparet sibi aequalis, etiamsi non ad designandum destinatio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` comparet.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Deponat `Weak` monstratorem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Does non procer quicquam
    /// drop(foo);        // Maps "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // et infirma incipit ad comitem I et non erit nulla, si omnes fortes ad acuunt quia prima abierunt.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Clone `Weak` regula fit per puncta eadem destinatio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Surculis construere novum `Weak<T>`, dispertientes in memoriam `T` initializing non est.
    /// [`upgrade`] vocant, semper valorem dat [`None`] in reditu.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Nos hic checked_add mem::forget faciam fiducialiter.Praesertim
// si mem::forget RCS (vel Weaks), in-gi possit comitem abundasset, tum de prouinciis cum liberabo vos can outstanding RCS (vel Weaks) inveniantur.
//
// Quod si hoc est privata fetu sem tam stultus, ut non curo quid tamen evenit ipsum-hoc non est verum progressio should quoque perpétuo patrocínia.
//
// Hoc si non exiguus supra caput quoniam non egemus, clone in quantum huiusmodi gratias Rust dominium et movent-semantics.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Redundantiam volumus, abortum esse in loco posito valore.
        // Non erit nulla referat comitem de quo dicitur,
        // nihilominus abort hic adiecimus et admonitus an aliud desiderari LLVM at ipsum.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Redundantiam volumus, abortum esse in loco posito valore.
        // Non erit nulla referat comitem de quo dicitur,
        // nihilominus abort hic adiecimus et admonitus an aliud desiderari LLVM at ipsum.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Get offset quod in tergo est `RcBox` payload pro regula.
///
/// # Safety
///
/// Monstratorem est designandum ad (metadata et est verum) exempli a et valet ante T, sed permissa, ut T omissa tribuni.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Conlineare unsized ad valorem usque ad finem RcBox.
    // Quia RcBox repr(C) est, quod memoria semper erit in novissimis agro.
    // SALUS: ex quo tantum potest unsized genera sint diuisa, trait occurrit:
    // et in externis figuris, quod is currently initus sufficit ad salutem postulationem satisfacies align_of_val_raw;implementation hoc est in detail in linguis fidentem, quae non potest extra std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}