//! A contiguam, ordinata genus augmentabilis in luto aquarum-partita imperia contenta in eodem scriptum `Vec<T>`.
//!
//! Vectors `O(1)` Indexing habent, amortized dis `O(1)` (ut in fine) et `O(1)` pop (e finem).
//!
//!
//! Ensure Vectors deducendae agroque diuidundo quam numquam `isize::MAX` bytes.
//!
//! # Examples
//!
//! Vos potest creare [`Vec`] cum expressis verbis [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... vel tortor utendo ad [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // decem zeroes
//! ```
//!
//! Vos can [`push`] onto finis autem vector pretium (quod est opus crescere in vector)
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Papaver values operatur, in quantum eodem modo;
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors Indexing et firmamentum (et per [`Index`] [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// A contiguam, augmentabilis array typus, quod scripsit `Vec<T>` et 'vector' locutus.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Et provisum est ut [`vec!`] tortor initialization magis convenient;
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Initialize Potest etiam unumquodque elementum cum de `Vec<T>` datum valorem.
/// Et hoc magis potest esse quam efficient faciendo destinatio initialization et separatum per gradus, praesertim cum initializing vector in quotvis cyphris,
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Et haec equivalent est, sed in potentia tardius,
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Pro magis notitia, videre [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Et agentibus uti `Vec<T>` quasi acervus;
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // III Manuscripts: II: I
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Quod genus `Vec` concedit values per accessum ad index quod effectum adducit [`Index`] trait.An example expressa erit amplius:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // et ponam eam '2'
/// ```
///
/// Sed esto careful: Si vos tendo quod accedere ad hoc quod indicem in `Vec` tuus erit panic software?Non potes facere:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Et sis [`get_mut`] [`get`] usus est indice `Vec` inspiciant an.
///
/// # Slicing
///
/// A `Vec` esse mutabilem uerteretur.In alia manu: crustae solum legere rebus ostendis.
/// Ut enim [slice][prim@slice] utere [`&`].exempli gratia:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // Et ... suus all!
/// // sic etiam facerem quod possis;
/// let u: &[usize] = &v;
/// // vel sic,
/// let u: &[_] = &v;
/// ```
///
/// In Rust, suus 'magis communia, ut transiet sicut crustae magis quam argumentis vectors vos iustus volo ut ubi legere providere accessum.Et sic de [`String`] [`&str`].
///
/// # Facultatem et reallocation
///
/// Et vector esse facultatem tantum spatii de egenis elementis future pro aliquo quod erit addidit ad onto vector.* * Longitudo hic non est confundendum cum de vector, quae dat speciem numerum ipsa elementa intra vector.
/// Si vector est longitudinem enim suam facultatem excedit, ad te statim facultatem multiplicari appetis sed ut sua elementa erit reallocated.
///
/// Exempli gratia facultatem a X vector cum vector vana est, et longitudo 0 esset spatium cum X ad plura elementa.Propellentibus ad X vel paucioribus elementa onto vector non mutantur sive facultatem suam causam reallocation fieri.
/// Tamen si vector est longitudinem XI augetur, ita erit reallocate, et non tardabit.Quapropter [`Vec::with_capacity`] commendatur uti quanta fuerit vector expectatur ut dare.
///
/// # Guarantees
///
/// Ob fundamental ejus incredibiliter natura `Vec` facit multum polliceri eius consilio.Ut, Haec est quae humilem supra caput, in quam maxime communem causam et bene potest manipulated in a tuto antiqui credebant.Nota quod spondent `Vec<T>` simpliciter referre.
/// Si autem addit additional genus parametris (eg, ut mos support allocators), ab earundem defaltis in ut mutare mores.
///
/// Maxime ratione disiunctum, `Vec` est, et semper erit (none: facultatem, longitudo) sextus ter geminos.Nec plus nec minus.Quibus incerta regione omnino ordo et apta modis determinari illorum uteretur.
/// In monstratorem nunquam irrita fiat, ut, huius generis nullum none, optimized.
///
/// Sed non actually Regula in memoriam quae ad partita imperia.
/// Et maxime, si `Vec` templo construendo est per facultatem 0 [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], non est inanis in Vec [`shrink_to_fit`] per vocantem, non collocant memoria.Pariter,-sized thesaurizas tibi nulla est in medio figura `Vec`: non enim spatium se deducendae agroque diuidundo.
/// *`Vec` Nota quod in hoc casu non est [`capacity`] referunt* 0 est.
/// `Vec` et erit deducendae agroque diuidundo nisi tantum [`mem: :::size_of<T>`]: (!) * capacity()> 0`.
/// In communem, destinatio: Vec` est scriptor exquisita details sunt-si collocant memoria usus esse in animo uti et `Vec` aliud aliquid (sive in codice haud minus securum putavimus, si lippus memoria tua vel aedificare collectio), cave deallocate ad memoriam per aera et sic `Vec` `from_raw_parts` recuperare.
///
/// Si autem `Vec` has * datum memoria, tunc memoria non ostendit et in congerie (ut definitur in allocator Rust configuratur uti per default), atque regula demonstrat [`len`] initialized, quaque elementa contigua ut (quod vellet vide si coactus ad segmentum), sequitur [`capacity`],`[`len`] logically uninitialized, quaque elementa contigua.
///
///
/// A quibus cum vector elementa `'a'` et `'b'` ad facultatem sicut inferius IV potest esse oculis ipsis subjicitur.Efficere `Vec` teguntur quod continet in monstratorem relatum caput tumulus verbis concepta.
/// In fundo est destinatio tumulum memoria contiguum scandalum.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - ** ** uninit significat quod memoria non initialized, videatur [`MaybeUninit`].
/// - Note: et non ABI `Vec` firmum et ejus memoriam facit non polliceri layout (inter quas ordo agros).
///
/// `Vec` non perform a "small optimization" Ubi enim revera elementa repono in ACERVUS est, duabus de causis:
///
/// * Difficilius enim est bene facere tutum non esset codice manipulate `Vec` est.Contenta `Vec` ne oratio stabili modo si motus et difficilior esset determinare si memoria `Vec` ultro datum.
///
/// * Communia si non esset anguino, incurrere in aliquid etiam omnem aditum branch.
///
/// `Vec` Numquam se sponte cedere etiamsi vacat.Et hoc non est necesse ensures aut prouinciis referentibus deallocations fieri.Usque ad exinanitionem `Vec` simul et illud implere non dico ad allocator [`len`] incurreret.Si uis liberare ignaram memoria aut [`shrink_to`] [`shrink_to_fit`] utuntur.
///
/// [`push`] et non [`insert`] (re) si placeat facultatem nuntiavit sat est.Et erit [`insert`]* *[`push`] (re) sin deducendae agroque diuidundo [`len`]==': [`capacity`].Hoc est, omnino est nuntiata facultatem accurate, atque uti potest.Liberabo manually Potest etiam utendum est datum est memoriae `Vec` ad libitum.
/// * * Ut insertio modi mole reallocate, etiam quando non est necessaria.
///
/// `Vec` maxime si non praestare omni belli reallocating Cum incrementum plenum, neque cum dicitur [`reserve`].Ut probare Romano belli utendum est et basic magis magisque augendum a non-factor.Quicquid enim usus belli voluntatem utique tuto * * O (I) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` et [`Vec::with_capacity(n)`][`Vec::with_capacity`], et omnis vir `Vec` ad producendum prorsus rogatus facultatem.
/// Si ['len`]`==: [`capacity`](sicut est causa est [`vec!`] tortor), deinde `Vec<T>` potest converti atque motabilem aut ex [`Box<[T]>`][owned slice] reallocating non sunt elementa.
///
/// `Vec` non est autem secundum speciem notitia remotus ab omni eam rescribere, sed etiam secundum speciem tueri non est.Uninitialized est memoria ejus VULNUS tamen illud spatium quod potest uti velit.Et fere quidquid est iustus non est, sive aliter agentibus maxime facilis ad effectum deducendi.Non ex operibus ut ne deleri absunt data securitate proposita est.
/// Etiam si stillabunt a `Vec`, habet quiddam ab alio reddi potest simpliciter `Vec`.
/// Si nulla est in memoria: Vec` primum quod non accideret hac parte haud optimizer efficere debet.
/// Quo casu non conteram unum est tamen, uti `unsafe` codice scribere excedens facultatem, et in longitudidem extendenda, ut par est, semper verum.
///
/// Currently, ut quibus fidem facere de elementis `Vec` non relinquantur.
/// Ut mutata est in praeteritis et potest mutare iterum.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// modi sibi inherente,
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Surculis construere novum, efferant universa `Vec<T>`.
    ///
    /// Et non vector deducendae agroque diuidundo ad pushed elementa sunt onto eum.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Novo construere, inanis `Vec<T>` cum certum facultatem.
    ///
    /// Et vector tenere poterit prorsus non reallocating `capacity` elementa.
    /// Si sit 0 `capacity` et non deducendae agroque diuidundo vector.
    ///
    /// Quod est momenti ad note quod etsi vector rediit facultatem habet * * additur, non vector est nulla erit longitudo * *.
    ///
    /// Nam ad explicandum illorum in quo excedunt facultatem inter longitudo, et vide *[De capacitate et reallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Quod non continet items vector, etsi in eam facultatem habeat ultra
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Hi sunt omnia fieri sine reallocating ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Sed ut vector reallocate faciet ...
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Creates a recta `Vec<T>` a rudis vector alia components.
    ///
    /// # Safety
    ///
    /// Abhorret tutus invariants secundum numerum qui retentus,
    ///
    /// * `ptr` et ante datum est, ad necessitates via [`String`]/Vec: <T>`(Saltem, falsa est suus 'altus probabile si non).
    /// * `T` Oportet autem quod datum est `ptr` scalpturaque quod dam.
    ///   (Dam `T` non habens propriam minus sufficiens esse debet aequa dam satis datum erit memoria [`dealloc`] hac eadem deallocated et arcu.)
    ///
    /// * `length` paribus `capacity` minus necessaria.
    /// * `capacity` debet esse regula est quod in facultatem datum est.
    ///
    /// Ut si violentia inferatur haec causa est internum allocator problems quasi data opera corrumpere.Non enim et ** ** aedificare tutum `Vec<u8>` `size_t` tandem instructi a monstratorem `char` C.
    /// Praesent nec tuto aedificationis `Vec<u16>` longitudo ex eo cogitat dam allocator haec duo genera sunt noctis.
    /// Et datum est quiddam apud Gratia diei et noctis II (nam `u16`), sed post illud youll 'verto is in `Vec<u8>` deallocated in I de Gratia diei et noctis.
    ///
    /// Quod dominium `ptr` tunc efficaciter `Vec<T>` deallocate transferri, reallocate mutare contenta in regula digna memoria ad libitum.
    /// Ut post vocant monstratorem nihil aliud est munus in usus.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // Update FIXME hoc quod stabilitur vec_into_raw_parts.
    ///     // Preoccupo est destructor V` currit: sic in integrum imperium de prouinciis permittit.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Et trahere e variis pieces of notitia magna de `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Cum memoriam overwrite IV, V; VI
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Rursus in unum omnia Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Surculis construere novum, efferant universa `Vec<T, A>`.
    ///
    /// Et non vector deducendae agroque diuidundo ad pushed elementa sunt onto eum.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Surculis construere novum, inanis `Vec<T, A>` cum determinato modo facultatem cum allocator.
    ///
    /// Et vector tenere poterit prorsus non reallocating `capacity` elementa.
    /// Si sit 0 `capacity` et non deducendae agroque diuidundo vector.
    ///
    /// Quod est momenti ad note quod etsi vector rediit facultatem habet * * additur, non vector est nulla erit longitudo * *.
    ///
    /// Nam ad explicandum illorum in quo excedunt facultatem inter longitudo, et vide *[De capacitate et reallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Quod non continet items vector, etsi in eam facultatem habeat ultra
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Hi sunt omnia fieri sine reallocating ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Sed ut vector reallocate faciet ...
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// `Vec<T, A>` creates a recta ab alia components vector rudis.
    ///
    /// # Safety
    ///
    /// Abhorret tutus invariants secundum numerum qui retentus,
    ///
    /// * `ptr` et ante datum est, ad necessitates via [`String`]/Vec: <T>`(Saltem, falsa est suus 'altus probabile si non).
    /// * `T` Oportet autem quod datum est `ptr` scalpturaque quod dam.
    ///   (Dam `T` non habens propriam minus sufficiens esse debet aequa dam satis datum erit memoria [`dealloc`] hac eadem deallocated et arcu.)
    ///
    /// * `length` paribus `capacity` minus necessaria.
    /// * `capacity` debet esse regula est quod in facultatem datum est.
    ///
    /// Ut si violentia inferatur haec causa est internum allocator problems quasi data opera corrumpere.Non enim et ** ** aedificare tutum `Vec<u8>` `size_t` tandem instructi a monstratorem `char` C.
    /// Praesent nec tuto aedificationis `Vec<u16>` longitudo ex eo cogitat dam allocator haec duo genera sunt noctis.
    /// Et datum est quiddam apud Gratia diei et noctis II (nam `u16`), sed post illud youll 'verto is in `Vec<u8>` deallocated in I de Gratia diei et noctis.
    ///
    /// Quod dominium `ptr` tunc efficaciter `Vec<T>` deallocate transferri, reallocate mutare contenta in regula digna memoria ad libitum.
    /// Ut post vocant monstratorem nihil aliud est munus in usus.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // Update FIXME hoc quod stabilitur vec_into_raw_parts.
    ///     // Preoccupo est destructor V` currit: sic in integrum imperium de prouinciis permittit.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Et trahere e variis pieces of notitia magna de `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Cum memoriam overwrite IV, V; VI
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Rursus in unum omnia Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Et putrescit `Vec<T>` in eius rudis components.
    ///
    /// Rudis notitia subiecti ad monstratorem redit et ad longitudinem vector (in elementa), et quod facultatem datum de notitia (in elementa).
    /// Eadem eodem ordine hae rationes [`from_raw_parts`].
    ///
    /// Post hoc munus vocant, in RECENS in memoriam ante factu est reus per `Vec`.
    /// Hoc est solum iter ad convertendum rudis monstratorem, longitudo, et in quod facultatem `Vec` cum [`from_raw_parts`] munus, præbens ad tersus destructor praestare.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Nunc possumus facere components mutationes, ut transmutando rudis monstratorem type est compatible.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Et putrescit `Vec<T>` in eius rudis components.
    ///
    /// Redit et rudis monstratorem underlying notitia, in longitudinem vector est (per elementa) et facultatem datum de notitia (in elementa) et allocator.
    /// Haec eadem eodem ordine [`from_raw_parts_in`] argumenta.
    ///
    /// Post hoc munus vocant, in RECENS in memoriam ante factu est reus per `Vec`.
    /// Hoc est solum iter ad convertendum rudis monstratorem, longitudo et facultatem in tergum `Vec` cum [`from_raw_parts_in`] munus, præbens ad tersus destructor praestare.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Nunc possumus facere components mutationes, ut transmutando rudis monstratorem type est compatible.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Extra numerum continere reallocating elementis vector redit.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Quia `additional` plura elementa facultatem reserventur quidem datis `Vec<T>` inserendas.
    /// Ut ne collectis frequenter reallocations spatium reservare.
    /// Post vocant `reserve`: erit maior quam vel aequalis ad `self.len() + additional` facultatem.
    /// Nihil facit si iam sat facultatem.
    ///
    /// # Panics
    ///
    /// Panics si novam facultatem excedit `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Facultatem ad minimum ex subsidiis prorsus `additional` pluribus elementis datis `Vec<T>` inserendas.
    ///
    /// Post `reserve_exact` vocant, esse facultatem maior quam vel aequalis ad `self.len() + additional`.
    /// Quod si non sufficient iam facultatem.
    ///
    /// Nota quod allocator ut dat spatium collectio magis quam hoc postulante impetrari.
    /// Ideo facultatem fides est nec esse potest pressius minimam.
    /// Malo si `reserve` future insertiones expectata.
    ///
    /// # Panics
    ///
    /// Si facultatem Panics novo redundat `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Conatur ad subsidium facultatem saltem elementa plura `additional` datis `Vec<T>` inserendas.
    /// Ut ne collectis frequenter reallocations spatium reservare.
    /// Post `try_reserve` vocant, `self.len() + additional` facultatem fore maior quam est aut aequales.
    /// Nihil facit si iam sat facultatem.
    ///
    /// # Errors
    ///
    /// Si facultatem redundat ab anima refert allocator vel per defectum, tunc error non redierat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-servat memoriam exierunt si non
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Scimus hoc non autem in medio nostri universa opus oom
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // interdum eget ipsum
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Nam prorsus tries reservare minimam facultatem `additional` elementis datis `Vec<T>` inserendas.
    /// Postquam vocant `try_reserve_exact`, si facultatem fore maior quam vel aequalis fuerit `self.len() + additional` `Ok(())` refert.
    ///
    /// Quod si non sufficient iam facultatem.
    ///
    /// Nota quod allocator ut dat spatium collectio magis quam hoc postulante impetrari.
    /// Ideo facultatem fides est nec esse potest pressius minimam.
    /// Malo si `reserve` future insertiones expectata.
    ///
    /// # Errors
    ///
    /// Si facultatem redundat ab anima refert allocator vel per defectum, tunc error non redierat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-servat memoriam exierunt si non
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Scimus hoc non autem in medio nostri universa opus oom
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // interdum eget ipsum
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Extenuetur facultatem vector ut fieri potest.
    ///
    /// Non caligabunt quam proxime certiorem faciat vector allocator nisi longo spatio paucorum esse elementis.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Nusquam minus posse longitudine aequales nihil facere possumus vitare panic `RawVec::shrink_to_fit` tantum fit capacior nominabant.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Extenuetur facultatem ad vector de inferioribus et ligatus.
    ///
    /// Capacitas remanebit saltem quod magnum est tam in longitudine quam in supplevimus valorem.
    ///
    ///
    /// Sit vena minus quam facultatem si minus terminum, hoc est, a nulla-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// De proselytis vector in [`Box<[T]>`][owned slice].
    ///
    /// Note quod non quiscumque excessus fluent facultatem.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Excess facultatem aliqua remota est;
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Breviora vector, `len` prima observatio in reliquis elementis remotis et.
    ///
    /// Si `len` major est scriptor current vector et longitudinem, quod non habet effectum.
    ///
    /// [`drain`] in modum possum `truncate`, nisi pro causa, quare rediit in excess elementis factus.
    ///
    ///
    /// Nota quod habet modum per effectus in facultatem vector partita imperia.
    ///
    /// # Examples
    ///
    /// Truncating elementum vector quinque elementa sunt duo:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Non truncation `len` accidit, cum sit major quam current longitudinem vector est;
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Cum truncating `len == 0` est equivalent ad [`clear`] ad modum vocant.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Hoc est quia salvum,
        //
        // * Transierunt ut segmentum `drop_in_place` valet;nullum creans est segmentum Avoids `len > self.len` se atque
        // * `len` est in conspectu vector medioque refugerit `drop_in_place` vocant: ita ut nihil pretii `drop_in_place` erit omissa essent casu bis in panic iterum (si enim alterum panics, aborts progressio).
        //
        //
        //
        unsafe {
            // Note: Est voluntariam quod `>` non `>=`.
            //       Mutantur `>=` est ad effectus in quibusdam casibus negans perficientur.
            //       Ecce enim #78884 magis.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Quae extrahit segmentum totum vector.
    ///
    /// Equivalent ad `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Segmentum totum mutabilis vector extrahit.
    ///
    /// Equivalent ad `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Rudis est scriptor refert regula ad vector quiddam.
    ///
    /// RECENS vector necesse ut ad hoc munus monstratorem volvens durando redit, vel aliud quod erit terminus sursum urgens quisquiliarum.
    /// vector de immutatione, ut eius causa reallocated quiddam esse debet, quod hoc quoque indicium nec ad eam ut irritum.
    ///
    /// Et ma gistrum suum necesse est ut numquam scriptum est enim memoria monstratorem (non-transitively) demonstrat (nisi intus in `UnsafeCell`) isve index seu per aliquem ex illa regula.
    /// Si postulo mutate ad contenta in dicto FRUSTUM, uti [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Segmentum placentae modum Nos eiusdem nominis umbra perambulabat `deref` vitare, quas gignit referat in medium.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Mutabilis est statio male fida refert regula ad vector quiddam.
    ///
    /// RECENS vector necesse ut ad hoc munus monstratorem volvens durando redit, vel aliud quod erit terminus sursum urgens quisquiliarum.
    ///
    /// vector de immutatione, ut eius causa reallocated quiddam esse debet, quod hoc quoque indicium nec ad eam ut irritum.
    ///
    /// # Examples
    ///
    /// ```
    /// // Satis enim magnum vector deducendae agroque diuidundo IV elementis.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initialize elementa, inquit, via rudis monstratorem: et longitudo constituit.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Nos umbra segmentum eundem modum nomen perambulabat `deref_mut` vitare, quas gignit referat in medium.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Refert ad fundamentum in allocator.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Ad longitudinem vector `new_len` virium.
    ///
    /// Hoc humili gradu ponit operationem communem invariants nullum genus.
    /// Plerumque fit vector mutato longitudo uti securitate pro rebus quae [`truncate`], [`resize`], [`extend`] vel [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] minus esse aequalis.
    /// - Et in elementis esse `old_len..new_len` initialized.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Modum Hoc potest esse utilis est pro casibus in quibus vector servientes quasi quiddam codice alia et praecipue super FFI,
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Et hoc est exemplum minima nuda ossa ad doc;
    /// # // nec in hoc puncto incipiens a bibliotheca realis.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Per'sdocs ad modum FFI; "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // Salutem cum redit `deflateGetDictionary` `Z_OK` tenet illud
    ///     // 1. `dict_length` initialized sunt elementa.
    ///     // 2.
    ///     // `dict_length` <= (32_768) facultatem ad `set_len` qui salvum facit ut vocatio.
    ///     unsafe {
    ///         // Fac enim vocationem ... FFI
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... et longitudinem ut update in quo erat initialized.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Exemplum autem sonus est enim memoria interiore vectors Leak non prius liberatur `set_len` hortatoria
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` inanis est ita necessaria ut absque elementis initialized.
    /// // 2. `0 <= capacity` id est `capacity` tenetur.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Northmanni, hic [`clear`] pro ut recte quis utitur stillabunt ita quae in memoria non Leak.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector redit elementum removet ab ea.
    ///
    /// In novissimo replaced amotus est elementum elementum in vector.
    ///
    /// Hoc non tueri vi hominibvs armatis O(1) est verum.
    ///
    /// # Panics
    ///
    /// Si enim ex terminis Panics `index`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Nobis sui reponere [index] cum ultima elementum.
            // Nota super, ut, si fines pro reprehendo oportet esse ultimum elementum (quae potest esse sui [index] ipsum).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Addit elementum `index` in situ vector incitati posteaquam ius elementum.
    ///
    ///
    /// # Panics
    ///
    /// Si Panics `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // quia spatii elementum novae
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // Quod omnino falli nesciam posuit ad novum macula pretii
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Shift ut per omne spatium.
                // (Ly 'Duplicating elementum in duo loca index`th).
                ptr::copy(p, p.offset(1), len - index);
                // Scribe illam in overwriting prima ly 'exemplum index`th elementum.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Transtulit intra vector redit elementum situ `index` incitati postquam elementum ad sinistram.
    ///
    ///
    /// # Panics
    ///
    /// Si enim ex terminis Panics `index`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // quae pro accipiendis.
                let ptr = self.as_mut_ptr().add(index);
                // effingo illud, in exemplum habens valorem casualiter super ACERVUS et in vector ad idem tempus.
                //
                ret = ptr::read(ptr);

                // Ante omnia explere loci mutationem.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Nisi certa elementa tenet ex parte praedicati.
    ///
    /// In aliis verbis: omnia elementa `e` removere talia quae `f(&e)` `false` refert.
    /// Haec modum operates in loco, prorsus statim visitare per elementum, in quo originale et quietis rationem servent tenuit ordinem in elementis.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Quia sint elementa visited prorsus semel in ordine ad originale, quod elementa externa statum decernere possunt, ut servare.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Et stilla gutta duplici si custodia ne non factum est, cum facit aliquid non potest processus in abditis.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-len processionaliter-> |^-reprehendo proximum sunt
        //                  | <-deleted cnt-> |
        //      | <-original_len-> |Tenentur: Elementa verum quod redit ad predicatum.
        //
        // Rursus foramen motus misere aut ignibus elementum socors.
        // Equus indomitus: inoffensum valet elementa.
        //
        // Haec vocabitur stilla militiae `drop` praedicatum vel de quo elementum panicked.
        // Inoffensum `set_len` foramina et sicut in elementis formas non est operimentum in longitudinem verum.
        // In casibus praedicatum et de quo nunquam `drop` panick est, ut ex optimized.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SALUS: Syrus fine items must exsisto valet quia non possumus eos contingere.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // Salutem cum impleta foramina Next contiguorum in memoriam.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // Utilitatibus consulens Unchecked oportet elementum valet.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Ferte mane vitare duplex stilla si `drop_in_place` panicked.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SALUS: Nos numquam tangere post elementum relinquantur.
                unsafe { ptr::drop_in_place(cur) };
                // Nos iam transiere lorem.
                continue;
            }
            if g.deleted_cnt > 0 {
                // Utilitatibus consulens `deleted_cnt`> 0, sic current concomitantiam oportet elementum socors foraminis.
                // Uti exemplum quia movent nos; et non elementum tangere iterum.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Item quod omnes processus.Hoc est optimized `set_len` per LLVM potest.
        drop(g);
    }

    /// Sed in primis elementa omnis removente continuos vector clades ad quod clavis ad idem.
    ///
    ///
    /// Si obicitur vector enim haec universa effingo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Omnis removente nisi continuati elementa prima, in laicorum autem vector data relatione aequalitatem.
    ///
    /// Et transivit munus `same_bucket` vector references to a duobus utrum elementa conferre debent pares.
    /// Ordinem elementorum ordinem in segmentum prima contraria, sic redit `same_bucket(a, b)` `true`, `a` tollitur.
    ///
    ///
    /// Si obicitur vector enim haec universa effingo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Subiungens quid est retro de elementum collectio.
    ///
    /// # Panics
    ///
    /// Panics si novam facultatem excedit `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Hoc autem panic deducendae agroque diuidundo uel abort si nos> in longitudinem isize::MAX bytes celeritatis incrementum vel mediocri exuberans est, nulla species.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Postremo elementum tollit a vector non redit, vel si [`None`] vacua remansit.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// In elementa movet `other` `Self` relicto `other` inanes.
    ///
    /// # Panics
    ///
    /// Si numerum elementorum in Panics vector `usize` redundaret.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Subiungens quid aliud quiddam ab elementis ad `Self`.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Creates autem residuam iterator quo etiam removentur et ad certum range in vector vero tollit et detracta items.
    ///
    /// ** ** omissa est iterator cum omnes fines removentur ab elementis vector etsi non iterator consumptae.
    /// ** ** iterator si omittenda non est (exempli gratia apud [`mem::forget`]), hoc est, remota sunt incerta, quot elementa.
    ///
    /// # Panics
    ///
    /// Si maior terminus Panics principium vel terminum vector maius spatium.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // A plena range deturbat laxatque vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // memoria salutem
        //
        // Primus cum Drain creatus est, quia verbum abbreviatum et longitudinem fons vector fac uninitialized non movetur aut ex elementis esse, si Drain accessible omnino destructor non accipit scriptor currere.
        //
        //
        // Et Drain ptr::read valores ad removendum.
        // Finito manentes vec caudam ad operiendum foramen exemplatur ac tandem nova vector tandem restituatur.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // set longitudinem self.vec est incipere et potest esse tutum si Drain emanasse:
            self.set_len(start);
            // Utere horum mutuo postulaverit in IterMut indicant ut totum mutuata ab mores Drain iterator (sicut &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Deturbat laxatque vector et auferam omne animationem.
    ///
    /// Nota quod habet modum per effectus in facultatem vector partita imperia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Redit vector in numerus elementa, et ad ut sui 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// `true` redit si non continet vector elementa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Scinditur in duo dati collectis p.
    ///
    /// Nuper datum est in elementis, in quibus refert vector `[at, len)` range.
    /// Post vocationem in vector originali continentur et egressus est prior cum suis elementis `[0, at)` facultatem unum.
    ///
    ///
    /// # Panics
    ///
    /// Si Panics `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // vector can take novum super quiddam et ne originale exemplum
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Et `set_len` enim casualiter items ut effingo `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Ad locum unde in resizes `Vec` `len` `new_len` aequalis.
    ///
    /// Si maior `new_len` `len` et proteletur `Vec` differentia inter foramen plenum ex alia vocans `f` claudetur.
    ///
    /// De reditu `f` erit terminus sursum in a values `Vec` in ordine ad esse generatum.
    ///
    /// Si minus quam `len` `new_len` est, quod est tantum mutila `Vec`.
    ///
    /// Agricola utitur Hoc in modum ex omnibus dis values creo.Si Curabitur data est magis [`Clone`] valorem, uti [`Vec::resize`].
    /// Si vis [`Default`] trait utuntur et generate values potes transiet sicut [`Default::default`] secundum rationem.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` demolitur et libero eu dolor est, reversus ad commutabile praedicationis contenta: `&'a mut [T]`.
    /// Nota quod genus `T` est vita superstes `'a` electi.
    /// Si habeat genus static solum agitur, aut omnino nullam, igitur hoc potest fieri elegit `'static`.
    ///
    /// Officium hoc simile munus [`leak`][Box::leak] [`Box`] quam nullum memoria repetentes emanasse.
    ///
    ///
    /// Maxime notitia utilis est ad hoc munus, quod habitat in reliquo progressio vitam.
    /// Omisso igitur faciam tibi rediit referat memoriam, Leak.
    ///
    /// # Examples
    ///
    /// Simplex usus:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Redit ad reliqua parce capacitatem vector `MaybeUninit<T>` scalpere.
    ///
    /// In FRUSTUM rediit possunt ad replete in notitia vector (eg
    /// legendi a lima per) ante pretium [`set_len`] data est quod per modum initialized.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Deducendae agroque diuidundo vector satis magno pro X elementa.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Replete in primo III elementa.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Mark III primis cum elementis vector ut initialized.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Nec modus secundum amet `split_at_spare_mut` ne ut indicium infirmatione quiddam.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Segmentum `T` contentus vector redit cum reliquis uti concedam frustum `MaybeUninit<T>` vector capacitatem.
    ///
    /// Parce et reddidit facultatem adhiberi poterit fragmen notitia ad replete cum vector (eg a lima lectio) quod ante pretium notitia usura initialized in [`set_len`] modum.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Hoc humili gradu API Nota quod ipsum curam utendum esse.
    /// Si opus `Vec` append notitia vos potest ad [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], aut [`resize`] [`resize_with`], fretus vestri industria.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Subsidium magnum spatium satis ad X additional elementa.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Replete in altera IV elementa.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // IV vector ut notarent sibi elementis esse initialized.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - et mutaverunt non neglecta Len
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Salus: reddidit mutari .2 (&mut usize) idem quod vocant `.set_len(_)` consideretur.
    ///
    /// Haec methodus uti habere unique obvius ad omnes partes simul vec apud `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` certo invalidam esse elementa `len`
        // - `spare_ptr` quiddam sit praeter pointing unum elementum, et hoc non ex LINO `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Ad locum unde in resizes `Vec` `len` `new_len` aequalis.
    ///
    /// Si maior `new_len` `len` et `Vec` extenditur per differentiam inter alia `value` foramen plenum.
    ///
    /// Si minus quam `len` `new_len` est, quod est tantum mutila `Vec`.
    ///
    /// Haec requirit modum `T` [`Clone`] ad effectum deducendi, ut possint clone: Transierunt ad valorem.
    /// Si plus flexibilitate opus (aut [`Default`] vis ad confidunt in loco [`Clone`]), uti [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Subdit in omnibus elementis clones et Segmentum placentae in `Vec`.
    ///
    /// Iterates FRUSTUM de `other`, elementum invicem clones et postea subdit ad huius `Vec`.
    /// `other` autem percurritur, ut vector.
    ///
    /// Nota quod hic functio propria [`extend`] nisi quod opus non purus.
    ///
    /// Et si hoc Rust accipit specialis munus erit verisimile quoque notabilis (sed tamen available).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Exempla sunt elementa extrema vector `src` vagarentur.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` polliceri se verum est, quia datis range Indexing sui
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Hoc codice generalizes `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Praetende vector per `n` values, uti datis etc.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Usus est opus SetLenOnDrop bug in circuitu per compiler non animadverto copia `ptr` self.set_len() ne per alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Scribe praeter ultimum elementum
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Longitudinem enim in omni casu incrementum celeritatis gradum next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Ultimum elementum directe scribere possumus quin cloning frustra
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // posuit in carcere locus len
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Continuas aetates transfert in vector elementa repetantur [`PartialEq`] secundum trait implementation.
    ///
    ///
    /// Si obicitur vector enim haec universa effingo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Et munera modi Internus
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` necesse est quod sit verum index
    /// - `self.capacity() - self.len()` oportet `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - post tantum auctus Len elementa initializing
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - non SALUTATOR guaratees verum est index src
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Sicut dictum elementum initialized in `MaybeUninit::write`, sic suus 'ok ut increace len
            // - post unumquodque elementum ne auctus Len libero eu dolor (see #82533 issue)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - non SALUTATOR guaratees verum est index `src`
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Indicium creata sunt de fragmen tum unique references (`&mut [_]`) ut sint valida et non overlap.
            //
            // - Elementorum sunt: Ad Exemplar sic suus 'OK, ad effingo eorum sine pretio difficultas de originali values
            // - `count` par est de len `source`, sic valet ad fontem `count` legit,
            // - `.reserve(count)` polliceri se in `spare.len() >= count` et parce `count` valet, inquit,
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Sicut elementa sunt in `copy_nonoverlapping` per initialized
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Quia commune trait implementations Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cum cfg(test) proprium modum `[T]::to_vec`, quae requiritur ad hunc modum definitio est non available.
    // Potius munus `slice::to_vec` quod est tantum available ad cfg(test) Nota Bene uti videre slice::hack module in slice.rs pro magis notitia
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // nihil esse quod stillabunt overwritten
        self.truncate(other.len());

        // self.len <=Ex other.len super se truncant, ut in crustae, hic semper in terminis.
        //
        let (init, tail) = other.split_at(self.len());

        // reuse in values continebat allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Facit perussi iterator, id est quod movet se vector valore ex (ab initio usque ad finem.)
    /// Et vector non potest esse post hoc vocant.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s Stabat habet genus non &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // cui variis folium modum SpecFrom/SpecExtend implementations delegare, quando amplius non habent optimizations adhibere
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Et hoc casu non est communis iterator.
        //
        // Equivalent de hoc munus moralis debet esse:
        //
        //      In {item propter iterator
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // Nota Bene quia non poterit esse cum redundantiam inscriptio est in spatio, Alloc
                self.set_len(len + 1);
            }
        }
    }

    /// Quod praefinitum locum splicing creat iterator rhoncus ac in iterator `replace_with` vector datis item concedere detracta.
    ///
    /// `replace_with` erit longitudo `range` non indiget.
    ///
    /// `range` si removeatur usque iterator non consumitur.
    ///
    /// Quot elementa est incerta sunt remota ab vector `Splice` si in valore est, leaked.
    ///
    /// Iterator modo initus est `replace_with` devoratum est a valore `Splice` est factus.
    ///
    /// Si haec bene:
    ///
    /// * Cauda est (after vector elementa in `range`), vacua est:
    /// * nec pauciores `replace_with` cedat longitudinem paribus range` elementari:
    /// * aut minus ex ejus tenetur `size_hint()` est inrogarent.
    ///
    /// Secus, ad tempus vector et in diuisione cauda est alterum movetur.
    ///
    /// # Panics
    ///
    /// Si maior terminus Panics principium vel terminum vector maius spatium.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// In quo utitur Agricola iterator gignit determinare potest si hoc esset remotus.
    ///
    /// Agricola refert nisi vera, et obiit inde elementum est remota.
    /// Si Agricola refert falsum, vector elementum et non remanebit de antememoratus episcopatus Halberstadiensis cum iterator.
    ///
    /// Per hanc viam est equivalent ad hoc code:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // Hic vestra code
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Sed facilius est `drain_filter` ad usum.
    /// `drain_filter` et magis agentibus, quia potest backshift ordinata sunt elementa in mole.
    ///
    /// Nota ut `drain_filter` iuvat etiam te mutate Agricola filter in omni elementum, sive vis ut removendum est or.
    ///
    ///
    /// # Examples
    ///
    /// An odds secta duas, et ordinata in aequalia inaequalibus, ad originale reusing destinatio,
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Incauti a nobis questus quaeque (amplificatione tuæ exitum)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Extend implementation exempla cum autographo onto in elementis ex ea Vec propellentibus de Claudia prius.
///
/// Hoc est specialized quia FRUSTUM implementation iterators, ubi [`copy_from_slice`] utitur videor ut tota simul scalpere.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Arma autem collatio vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Arma vectors ordo, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // ad usum gutta [T] utor a scalpere rudis esse intelligendum de elementis vector necesse est infirmissimus cibarius genus;
            //
            // Quaestiones valet poterat vitare aliqua casibus
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec aures deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// `Vec<T>` inane facit.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test observabitis libstd, unde errores
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test observabitis libstd, unde errores
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Acies contenta in omni imbutus `Vec<T>` si requisitus de magnitudine plane sistat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Tandem si non inserere, `Err` input in redeat;
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Si et tu iustus questus a denique de praepositione `Vec<T>`, vos potest vocare [`.truncate(N)`](Vec::truncate) prius.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // Incolumes `.set_len(0)` semper sonus.
        unsafe { vec.set_len(0) };

        // Salus: A monstratorem est: Vec` varius semper bene ac
        // item eadem alignment ordinata desiderat.
        // Tibi nos, ut antea sedatus sufficient items.
        // Et non items quod geminus-`set_len` gutta stillabunt et non `Vec` narrat eos.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}