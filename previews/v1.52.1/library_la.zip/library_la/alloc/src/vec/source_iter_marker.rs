use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Marker Vec cum specializatione pro colligendis reusing fons in pipeline per iterator prouinciis, id est
/// Pipeline pro exsecutione.
///
/// SourceIter parens trait est necessarium ad accedere ad munus specialiter de prouinciis permittit, quae est ad reddi illius.
/// Sed hoc non sufficit ad hoc quod est specialis valet.
/// Ecce in terminis additional impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Quod internum, std SourceIter/InPlaceIterable traits sunt vincula non implemented per nibh <Adapter<Adapter<IntoIter>>> (Omnes haberet dominum nomine core/std).
// Quoque terminis implementations nibh (ultra `impl<I: Trait> Trait for Adapter<I>`) non ex alia specialis traits traits iam cernitur (Exemplar TrustedRandomAccess, FusedIterator).
//
// I.e. titulus suppleri user-genera non dependet saeculorum.Exemplar modulo foramen plures quam antea rationibus pendeant.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Additional requisita non expressit per trait bounds.Const disp pro confidimus;
        // est) quasi ZSTs non esset ibi neque reuse et kardo constituti essent arithmeticam indicatorum panic b) Quod erat faciendum compositus ex mole contractus, Alloc c) a Alloc gratiae diei et noctis inserere contractus Quod erat faciendum
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // magis in genere, ad implementations fallback
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // quia duplex experiri uti
        // - melior est vectorizes aliquot adapters iterator
        // - dissimilis potissimum internum modi iteration, quod tantum takes a se &mut
        // - thread ecclesiæ scribe in nobis illud lets adepto tergum in regula in intestina eius ac finis
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteration aduersus singulos erat, non capitis stillabunt
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // Si contraxerit fauerit caveat SourceIter reprehendo si non potest hoc non facere
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // reprehendo InPlaceIterable contractum.Hoc maxime modo si iterator proceditur fons none at all.
        // Si illud immoderate utitur TrustedRandomAccess accessum via et regula sit in situ initiali ad fontem, et possumus uti ut referat
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // at reliqua bona stillavit gutta cauda destinatio ipsum et ne aliunde exit scopum IntoIter si quis guttam panics tum etiam RIMA in elementis congregavit dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // Hic InPlaceIterable ad contrahendum omnino probare non sit solum secundum originem try_fold monstratorem reprehendo si tamen possumus omnes visibilis
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}