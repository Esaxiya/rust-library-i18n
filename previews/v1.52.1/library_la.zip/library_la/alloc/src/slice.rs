//! A dynamically-sized visum est in ipsomet tempore suo `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Repraesentantur in memoria visum crustae regula&longitudo scandalum.
//!
//! ```
//! // per violentiam movetur Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // Segmentum placentae ordinata est ad coercendos
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Crustae aut mutabilem participatur.
//! Segmentum placentae genus participatur in est `&[T]`, dum Segmentum posterius mutari potest `&mut [T]` genus est, ubi `T` genus repraesentat elementum.
//! Nam potes mutate secare obstructionum memoriae ostendit quod mutabile;
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Quae sunt aliqui hic de cuius moduli rationem habet;
//!
//! ## Structs
//!
//! Quae utilia structs plura taleolas [`Iter`] quale quod repraesentatur per iterationem secare.
//!
//! ## Trait Implementations
//!
//! Plures enim implementations commune traits purus.Quaedam exempla includit:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], elementum ut purus quorum nec [`Ord`] [`Eq`] generis sunt.
//! * [`Hash`] - cuius generis est purus ut elementum [`Hash`].
//!
//! ## Iteration
//!
//! Segmentis `IntoIterator` effectum deducendi.Et fruges ejus iterator quae ad scalpere elementa.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Et primo fructus mutabilibus mutabilia quae ad segmentum elementa:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Affert slice quae ad mutabilia haec iterator de elementis, ut genus dum elementum `i32` segmentum sit, elementum sit genus ad `&mut i32` iterator.
//!
//!
//! * [`.iter`] et [`.iter_mut`] sunt expressa modi redire iterators per default.
//! * Praeterea modi sunt, ut redire iterators [`.split`], [`.splitn`], [`.chunks`], et [`.windows`].
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Multa de hoc usings moduli sunt in tantum test de configuratione.
// It'siustus est lautus averte unused_imports quam figere sermonem adnuntiabis eis.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Segmentum placentae basic modi extensio
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) opus experiri ad implementation de `vec!` tortor in duabus NB, hoc moduli `hack` video lima pro magis details.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) per probationem opus `Vec::clone` ad exsequendam NB, hoc moduli `hack` video lima pro magis details.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Cum cfg(test) `impl [T]` non adest, faba munera isti tres modi sunt, quae sunt in actu, sed in `impl [T]` `core::slice::SliceExt` nos postulo ut suppleret id, haec munera pro test `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Bold; quaslibet oportet addere quod haec causa maxime&tortor id est in `vec!` pert procedere.
    // Et vide disputationem #71204 ad pert results.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // Signatus tenui sub loop initialized in sunt items
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) necesse sit removere ad fines LLVM checks et codegen magis quam notam ZIP addere.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // initialized esset datum desuper vec saltem et in longitudine.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // datum desuper pollere etiam oportet facultate `s` et `s.len()` ad initialize in ptr::copy_to_non_overlapping inferius.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Speciebus perplura segmentum.
    ///
    /// Generis haec est stable (id est, pari elementis non reorder) et *o*(*n*\*log(* n*)) pessimus-casu.
    ///
    /// Quo pertinet, quod plerumque instabiles diribitio praeponitur citius memoriae stabile alarias nequimus nee voluptua.
    /// Vide [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Current implementation
    ///
    /// In current algorithm est adaptive, adipisicing inspirati [timsort](https://en.wikipedia.org/wiki/Timsort) merge huiusmodi.
    /// In casibus de quo est intentio futurus valde ieiunium coetibus territorialibus fere segmentum sit, seu quasi catenata series coetibus territorialibus ex duabus vel pluribus unum post alterum.
    ///
    ///
    /// Quoque, allocates illud repono tempus medium `self` magnitudinem, sed brevi crustae, et non exerrarent mentibus videntes opum insertionem generis.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Segmentum cum speciebus perplura comparatur munus.
    ///
    /// Generis haec est stable (id est, pari elementis non reorder) et *o*(*n*\*log(* n*)) pessimus-casu.
    ///
    /// Comparator propter quod elementa sunt in munus ordinatione est summa define scalpere.Si non est summa ratio, ordo est in elementis etc.
    /// A totalis ordinem, si ordo non est (nam omnis `a`, et `b` `c`)
    ///
    /// * et summa antisymmetric: `a < b` prorsus unum, `a == b` `a > b` et verum est, et
    /// * transi, et `a < b` `b < c` `a < c` importat.Nam et tenenda eisdem `==` `>`.
    ///
    /// Exempli gratia dum [`f64`] non `NaN != NaN` effectum deducendi [`Ord`] quod, sicut nos nostri generis munus uti `partial_cmp` cum scire FRUSTUM non continet in `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Quo pertinet, quod plerumque instabiles diribitio praeponitur citius memoriae stabile alarias nequimus nee voluptua.
    /// Vide [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Current implementation
    ///
    /// In current algorithm est adaptive, adipisicing inspirati [timsort](https://en.wikipedia.org/wiki/Timsort) merge huiusmodi.
    /// In casibus de quo est intentio futurus valde ieiunium coetibus territorialibus fere segmentum sit, seu quasi catenata series coetibus territorialibus ex duabus vel pluribus unum post alterum.
    ///
    /// Quoque, allocates illud repono tempus medium `self` magnitudinem, sed brevi crustae, et non exerrarent mentibus videntes opum insertionem generis.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // diribitio e converso,
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Segmentum speciebus perplura cum a key munus extraction.
    ///
    /// Haec Seu Rigidorum VOL (ie, non reorder elementa pari) et *o*(*m*\n * **\* log(*n*)) pessimus-casu ubi key munus est *o*(*m*).
    ///
    /// Nam pretiosa munera clavis (eg
    /// munera quae possessionem ne simplex et basic res febrium), verisimile est esse significantly [`sort_by_cached_key`](slice::sort_by_cached_key) citius, quia non Recompute claves elementum.
    ///
    ///
    /// Quo pertinet, quod plerumque instabiles diribitio praeponitur citius memoriae stabile alarias nequimus nee voluptua.
    /// Vide [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Current implementation
    ///
    /// In current algorithm est adaptive, adipisicing inspirati [timsort](https://en.wikipedia.org/wiki/Timsort) merge huiusmodi.
    /// In casibus de quo est intentio futurus valde ieiunium coetibus territorialibus fere segmentum sit, seu quasi catenata series coetibus territorialibus ex duabus vel pluribus unum post alterum.
    ///
    /// Quoque, allocates illud repono tempus medium `self` magnitudinem, sed brevi crustae, et non exerrarent mentibus videntes opum insertionem generis.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Segmentum speciebus perplura cum a key munus extraction.
    ///
    /// Per genus, semel tantum per key munus elementum dicitur.
    ///
    /// Hoc genus est firmum (id est, agit non reorder aequalis elementa) et *o*(*m ^\**n* + *n*\*log(* n *)) pessimus-casu ubi key munus est* o *(* q *) .
    ///
    /// Pro simplex munera clavis (eg, et munera febrium basic res ut res sunt), ut verisimile est [`sort_by_key`](slice::sort_by_key) citius.
    ///
    /// # Current implementation
    ///
    /// In current [pattern-defeating quicksort][pdqsort] algorithm a Orson Petrum fundatur insunt, quae putant ieiunium si mediocris est cum ieiunium randomized quicksort de heapsort Maxime in re, cum tempus achieving in crustae per lineae quaedam exempla.
    /// Non randomization utitur aliqua casibus vitare pravum, et certa semper providere deterministic mores seed.
    ///
    /// Ad deterrima casu allocates in algorithm ad tempus secare ad longitudinem in repono in `Vec<(K, usize)>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Adiutorem nostrum vector ab Macrone indexing genus minimum ad redigendum destinatio.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Unica `indices` elementa, quos iudex ut prima respectu cuiuscumque segmentum erit stabilis.
                // Hic utimur `sort_unstable` minus memoriam postulat quod destinatio.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Idea nova `self` in `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Ecce `s` et `x` immutabile non nocet.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Idea nova `self` in `Vec` cum allocator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Ecce `s` et `x` immutabile non nocet.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // Nota Bene, video lima Hoc pro magis details in `hack` moduli.
        hack::to_vec(self, alloc)
    }

    /// Proselytis `self` in vector sine clones seu destinatio.
    ///
    /// A buxum consequens est vector possunt converti in Vec via: <T>`S modum `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` non amplius adhibetur, quod fuerit factus in `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // Nota Bene, video lima Hoc pro magis details in `hack` moduli.
        hack::into_vec(self)
    }

    /// Segmentum repetita temporibus `n` vector creat.
    ///
    /// # Panics
    ///
    /// Hoc munus panic si non facultatem exuberans.
    ///
    /// # Examples
    ///
    /// Basic usus:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic super inundans
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // `n` si nulla sit maior esse, quod Scinditur `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` possit.
        // `2^expn` numerus per leftmost '1' `n` modicum et reliqua `n` `rem` est.
        //
        //

        // `Vec` per accedere ad `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` repetitio est: duplicando `buf` expn` semel.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` si nulla reliqua leftmost '1' ad frenos.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` de `self.len() * n` habeat facultatem.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` ('=U, ^ II expn`) `rem` repetitio unitatum repetitio fit per prius de `buf` se iactat imitari.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Hoc non-imbricatis quia `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` aequales `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Segmentum placentae in uno valore flattens `T` `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Segmentum flattens `T` simplice in `Self::Output` ponens inter SEPARATOR datam.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Segmentum flattens `T` simplice in `Self::Output` ponens inter SEPARATOR datam.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// De quibus refert vector a FRUSTUM hoc exemplum est: ubi inter se divisi byte equivalent ad suam causam superius ASCII.
    ///
    ///
    /// ASCII epistolas ad 'a' 'z' sunt divisi sunt in 'A' 'Z': litterae non-ASCII sed non mutatur.
    ///
    /// Ut verbo ire ad valorem-sunt in loco, [`make_ascii_uppercase`] utuntur.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// In quibus vector a FRUSTUM redit exemplum hoc est: ubi inter byte casus provisa est equivalent ad ASCII inferioribus.
    ///
    ///
    /// ASCII epistolas ad 'A' 'Z' sunt divisi sunt in 'a' 'z': litterae non-ASCII sed non mutatur.
    ///
    /// Ut ad valorem lowercase in-place utere [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Quia species specifica de notitia in crustae extensio traits
////////////////////////////////////////////////////////////////////////////////

/// Adjutor in trait [`[T]: : concat`](secare::concat).
///
/// Note: et non est utendum in hoc parameter genus `Item` trait, sed non amplius concedit impls esse in genere.
/// Sine qua hunc errorem dabimus tibi;
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Quia haec posse non est `V` types `Borrow<[_]>` impls in plures, quia plures tales rationes non applicare `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Et inde, postquam generis iunctura
    type Output;

    /// Exsequendam ['[T]: : concat`](concat::FRUSTUM)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Adjutor in trait ['[T]: : join`](iungere FRUSTUM::)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Et inde, postquam generis iunctura
    type Output;

    /// Exsequendam [`[T]: : join`](::FRUSTUM iungere)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Latin trait implementations in crustae
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // nihil stillabunt qui non in scopum overwritten
        target.truncate(self.len());

        // target.len <= self.len ex truncatis supra, taleolas ut hic semper, in terminis.
        //
        let (init, tail) = self.split_at(target.len());

        // reuse in values continebat allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Ut omnia in pre-sorted `v[1..]` sequentia adiungit `v[0]` `v[..]` fit fringilla.
///
/// Hoc autem integralis subroutine insertionem modi.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Invenitur enim triplex modus inserere hinc ad effectum deducendi;
            //
            // 1. PERMUTO adjacent elementis usque ad supremum ejus est primum accipit debet.
            //    Tamen, haec notitia iter Nos effingo circa quam est.
            //    Si elementa sint aedificiis magnas (didicï copy), haec erit: tardilocum esse modum.
            //
            // 2. Dextra usque ad iterate locus est primum elementum inventus est.
            // Et mutare locum ita demum ea quae postea in reliquas putei ponerent.
            // Haec bona modum.
            //
            // 3. Effingo primum in elementum ad tempus variabilis.Dextra usque ad locum qui ei iterate inventus est.
            // Ut vado per copia ad omne elementum percursum socors preceding eam.
            // Postremo copia foramine notitia brevis differentia caetera.
            // Hunc modum esse valde bona est.
            // Melius perficientur quam Benchmarks demonstratum est cum ignominia 2 modum.
            //
            // Omnes modi sunt benchmarked et optime ostendit 3 results.Ita quod nobis elegit est.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Statum medium exitus per processus eorundem domitorem investigavi semper `hole`, quod duobus finibus inservire potest:
            // 1. Integritas `v` protegit a panics in `is_less`.
            // 2. Reliquis tandem `v` replet foramen.
            //
            // Panic salutem
            //
            // Si `is_less` processus panics quolibet alio momento, `hole` mos adepto fluens et imple foramen `v` cum `tmp`, ita quod cursus rerum contraxerat `v` adhuc tenet prorsus tenendum sit initio statim.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` sicque fit codicibus omissa `tmp` foramen `v` caetera.
        }
    }

    // Ubi cecidit in transcribit `src` `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Merges fugit `v[..mid]` non-decrescentes et per `v[mid..]` `buf` ad tempus repono principes ciborumque horrea hoc est in `v[..]` effectus.
///
/// # Safety
///
/// Duo peragitato non-esse, oportet `mid` inanis est et in terminis.
/// Est quiddam `buf` segmentum minus sufficit ponere exemplum.
/// Item, nullus `T` necesse est esse, non mediocri genus.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Merge primum processus, in `buf` codicibus breviori currere.
    // Deinde communiat nuper copied enim currere et in futurum iam run (aut retro) comparet comesis illorum deinde elementis et iactat imitari luminare minus (aut maior) `v` in unum.
    //
    // Ut breviore spatio plene consummatus processum est.Si non consumetur cursus sudatio primo debemus imitari residuum reliquis foramen `v` brevioris incurrunt.
    //
    // Medium civitatis processus eorundem domitorem investigavi semper `hole` per quod duobus finibus inservire potest:
    // 1. Integritas `v` protegit a panics in `is_less`.
    // 2. Reliqua plena adhuc foramen cursus nisi sero `v` consumptis prioribus.
    //
    // Panic salutem
    //
    // Si `is_less` panics alicubi durante processu `hole` `v` accipies de foramine fluens implebunt extantibus in rhoncus `buf` sic omnino cupimus, primo statim obiectum `v` omnes tenet.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Sinistro cursu brevior.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Autem initio, indicatores, quae ad haec primordia urbis eorum refe vestit.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Minore latere conficiat.
            // Aequalis, ad sinistram statum tenere cursum.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Ius brevior cursu.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Primum ostendit praeter illa indicia sunt extremitates vestit.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Maiorem partem consumant.
            // Si pares esse stabilem cursum rectum praeponere.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Denique is gets `hole` relinquantur.
    // Brevior cursu si non consumptae quicquid reliquiarum illius foraminis `v` nunc transtulerunt.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Ubi cecidit in `dest..` `start..end` codicibus range.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` non nulla-sized genus, sic suus 'okay ut dividant ex sua magnitudine.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Hoc merge modi aliquid horum mutuo postulaverit (but not all) de TimSort ideas, quae describitur in detail [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// A descen algorithm agnoscit stricte non-subsequences et descendentes, qui dicuntur naturalis fugit.Est adhuc acervus emendationum pendentium fugit confusa sint.
/// Nuper inventum quisque currere pushed onto ACERVUS est, et de iugis quae adjacent merged fugit dum haec duo invariants es satiata:
///
/// 1. nam in omni `i` `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. nam in omni `i` `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Et invariants est *O* cursus ut in summa (n * *\*log(* n*)), si pessimus.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Crustae ad adepto longitudinem haec commoda per insertionem generis.
    const MAX_INSERTION: usize = 20;
    // Ipsum autem fugit brevis extenditur per spatium saltem ad insertionem generis multa huius elementis.
    const MIN_RUN: usize = 10;

    // Significativum habet a priori nulla Sorting-sized types.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Short vestit coetibus territorialibus adepto per in loco insertionem modi, ne prouinciis referentibus.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Uti digitis quiddam collocant memoria.Non possumus servare et custodire ad longitudinem 0 copies de contentis in ea vadum `v` sine exemplaribus in casu si `is_less` panics dtors currit.
    //
    // Cum duo bus currit sorted haec brevior cursu rescriptum continet quiddam, quod semper plurimum `len / 2` longitudine.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // In ut vestibulum `v` natura currit, lustramus retro.
    // Mirum videri posset decreti Merges considera quod plerumque in contrarium magis (forwards).
    // Secundum benchmarks dimidiatum, hoc induci mergebant paulo citius quam posteriorem partem inclinatur.
    // Sic ergo dicendum quod identifying fugit Percurso retro improves perficientur.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Alteram naturalem cursum reperio atque proprie est si retexamus descendendo.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Si suus 'currere quidam ad inserere elementa plus brevior.
        // Insertio generis merge modi est a brevis citius quam secuntur hanc, ut amplio significantly hoc perficientur.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // His ventilabis currere onto ACERVUS.
        runs.push(Run { start, len: end - start });
        end = start;

        // Alii paria Merge adjacent fugit in invariants satiat.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Denique unum run prorsus esse in ACERVUS.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Fugit autem examines ACERVUS et tunc agnoscit, ut par est fugit merge.
    // Specialius si `Some(r)` redeat, significat quod `runs[r]` merged `runs[r + 1]` sit proximus.
    // Si permanere debet algorithm pro aedificationem a procursu, sit `None` rediit.
    //
    // TimSort ignominiosus est et implementations buggy, quod descripsit hic
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Fama est summa: nos urgeant invariants vertice quatuor currit in ACERVUS.
    // Tribus iustis non sufficit statuendo summa invariants tenebit quoniam omnes * Ut in ACERVUS currit.
    //
    // Eorumque quattuor invariants verticem munus recte currit.
    // Additionally, si in summo animi index currere 0, quia semper operatio merge deposcat injuria plene usque ad BIBLIOTHECA corruens oppressit liberos esse, ut generis perficere.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}