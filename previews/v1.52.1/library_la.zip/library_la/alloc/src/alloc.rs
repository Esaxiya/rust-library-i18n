//! Memoria destinatio APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Haec est magia appellare signa in global allocator.Generat rustc vocare `__rg_alloc` etc.
    // Si `#[global_allocator]` attributum est (ut signum eiusdem attributi tortor generet vitales) vel ad defaltam implementations libstd in (c `__rdl_alloc`
    //
    // In `library/std/src/alloc.rs`) aliter.
    // Et rustc fork LLVM etiam in speciali, munus haec nomina casibus esse potest ad optimize eos sicut `malloc`, `realloc` et `free`, respectively.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// A global allocator memoria.
///
/// Hoc genus in [`Allocator`] trait a procuret arma vocat allocator relatus est cum attribuitur `#[global_allocator]` si est unum, aut `std` crate praeselecta.
///
///
/// Note: dum huius generis obvenit instabile est in functionality non possunt accessed per [free functions in `alloc`](self#functions) praebet.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Cum memoriam deducendae agroque diuidundo global allocator.
///
/// Hoc munus ventus urens vocat ad [`GlobalAlloc::alloc`] allocator relatus ad modum apud `#[global_allocator]` se attribute, si ibi est, vel `std` crate praeselecta.
///
///
/// Hoc munus `alloc` expectat modum est vituperabile in gratiam cum et ad genus [`Global`] [`Allocator`] firmum trait facti sunt.
///
/// # Safety
///
/// Vide [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Cum memoriam Deallocate global allocator.
///
/// Hoc munus allocator relatus ad modum procedit vocat ad [`GlobalAlloc::dealloc`] `#[global_allocator]` apud se attribute, si ibi est, vel `std` crate praeselecta.
///
///
/// Hoc munus deprecatus expectat ut per gratiam Dei in [`Global`] `dealloc` modum generis, cum eam et facti sunt [`Allocator`] trait firmum.
///
/// # Safety
///
/// Vide [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Cum memoriam Reallocate global allocator.
///
/// Hoc munus [`GlobalAlloc::realloc`] ad modum priorem vocat allocator relatus est per accidens `#[global_allocator]` si est unum, aut `std` crate praeselecta.
///
///
/// Deprecatus est in gratiam ex hoc munus expectat ut `realloc` ad modum generis, cum [`Global`] et facti sunt [`Allocator`] trait firmum.
///
/// # Safety
///
/// Vide [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Deducendae agroque diuidundo nulla memoria Initialized, cum global allocator.
///
/// Haec [`GlobalAlloc::alloc_zeroed`] ad munus vocat progressivo ad modum allocator descripserunt `#[global_allocator]` apud se attribute, si ibi est, vel `std` crate praeselecta.
///
///
/// Hoc munus, in gratiam Dei expectat vituperabile `alloc_zeroed` [`Global`] ad modum generis, cum eam et facti sunt [`Allocator`] trait firmum.
///
/// # Safety
///
/// Vide [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // Utilitatibus consulens `layout` nulla est in non-size:
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // Salutem et eadem `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // Utilitatibus consulens `new_size` est non-Est `old_size` ut nulla maior quam vel aequalis `new_size`
            // salutem exigente conditionibus.Alii debet fultum esse condiciones in RECENS
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` quia verisimile checks `new_size >= old_layout.size()` vel aliquid simile.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // Salutem quia maior sit `new_layout.size()` `old_size` paribus,
            // et veteris et novae destinatio non valet ad memoriam legit et scribit ad `old_size` bytes.
            // Etiam, quia vetus deallocated tamen destinatio non est: quia non overlap `new_ptr`.
            // Ita tuto `copy_nonoverlapping` vocant.
            // Salutem esse defensam contractus `dealloc` RECENS.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // Utilitatibus consulens `layout` nulla est in non-size:
            // aliter esse defensam RECENS
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // Salutem conditiones debet RECENS sustentatur
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // Salutem conditiones debet RECENS sustentatur
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // Salutem et conditionibus debet teneri in RECENS
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // Utilitatibus consulens `new_size` est non-nulla.Alias condiciones a ma gistrum suum necesse habere poterit,
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` checks `new_size <= old_layout.size()` verisimile ad esse memini.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // Salutem quia `new_size` minorem vel aequalem esse `old_layout.size()`;
            // et destinatio in memoriam veteris et novi enim valet quod scribit et legit bytes `new_size`.
            // Etiam, quia vetus deallocated tamen destinatio non est: quia non overlap `new_ptr`.
            // Ita tuto `copy_nonoverlapping` vocant.
            // Salutem esse defensam contractus `dealloc` RECENS.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Allocator est pro unique indicibusque.
// Oportet hoc munus semet explicare.Si enim uillulis suis codegen non deficient.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Haec signature `Box` sicut idem habet esse, aliter esse REFRIGERO ventura.
// An additional sit modulo additum `Box` Cum autem (sicut `A: Allocator`) Hoc necesse est adicere quia hic bene.
// Exempli gratia, si `Box` `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` est mutatum esse, hoc munus habet non ut mutata etiam `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Destinatio errorem orci

extern "Rust" {
    // Hoc vocant magicae in signum populorum global alloe errorem tracto.
    // Ut si generat rustc `__rg_oom` est `#[alloc_error_handler]` vocant, aut aliter appellare a default implementations (`__rdl_oom`) inferius.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Destinatio Abort memori errore elit.
///
/// Memoriae salutetur APIs destinatio ad dicendam uellet favete destinatio ratio erroris munere incitamur ad quam se similis vel `panic!` invocatur.
///
///
/// De habitus a priori huius munus est ad vexillum ut procer a nuntius errorem abort processus.
/// Potest referri ad [`set_alloc_error_hook`] et [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Nam alloe test `std::alloc::handle_alloc_error` potest directe usus.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // vocavit per generatae `__rust_alloc_error_handler`

    // Si non est `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // si est `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Lorem pre-clones in diuisione, uninitialized memoria.
/// Used by `Box::clone` et `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // His partita imperia * * prima est permittere potest cloned optimizer creare valorem, est in loco, omissis ad locorum et moventur.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Locus effingo semper in-possumus, quin semper habeat in se locus valorem.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}