#![stable(feature = "rust1", since = "1.0.0")]

//! Thread-referat-tutum est numerus indicibusque.
//!
//! Ecce in documentis pro magis details [`Arc<T>`][Arc].

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// A finis mollis in copia factum est, ut bonorum esse potest ad `Arc`.
///
/// Eo quod supra terminus progressio et fetu omnem tua (etsi non necessario) _exactly_ ad `MAX_REFCOUNT + 1` p.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer non support memoria sepibus.
// Ne falsum tradit positivum in arc/infirmum implementation pro synchronization in usus nuclei onerat.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// A filo subtegminis, salvus est numerus-reference monstratorem.'Arc' stands for 'atomically Reference counted.
///
/// Quod genus praebet `Arc<T>` communiter sunt per dominium et valorem `T` genus, quod tribuitur in eum.Invocato [`clone`][clone] in `Arc` novam `Arc` exempli gratia, quae demonstrat destinatio eiusdem in acervus erit sicut fons `Arc`, cum plus referat ad comitem.
/// Cum ultimum destinatio `Arc` monstratorem a datum est regio, quae destinatio valorem conditur (saepe relatum ut ut "inner value") est, qui quærunt te.
///
/// Rust disallow mutationem in Concept participatur per default et `Arc` nulla exceptione: non possis assequi plerumque ad aliquid intus in `Arc` mutabilem uerteretur.Si vos postulo ut mutate est per `Arc` utere [`Mutex`][mutex], [`RwLock`][rwlock], aut unum ex [`Atomic`][atomic] types.
///
/// ## Post Safety
///
/// Secus [`Rc<T>`], `Arc<T>` utitur nuclei referat res eius est numerus.Id est linum, ut tutum.Ordinarii locorum est magis carus quam atomi operationes memoriae aditus.Si autem referat, nullius multitudine numerari inter relatorum prouinciis referentibus, considerans enim [`Rc<T>`] inferiore uti supra caput.
/// [`Rc<T>`] defectus tutum est enim conprehendam compilator [`Rc<T>`] mittam inter fila conaretur.
/// Sed `Arc<T>` a bibliotheca, ut eligere ad bibliothecam in ordinem consumers ultra flexibilitate.
///
/// `Arc<T>` et quamdiu effectum deducendi [`Send`] et [`Sync`] ut `T` [`Send`] et [`Sync`] telis conficitur.
/// Quare non potes posuit non-tutum filum-type `T` `Arc<T>` per eam fila essent salvum facere?Hoc sit primo paulum intuitive, after all, is non filum parte `Arc<T>` salutem?The key hoc: `Arc<T>` salvum fecerit eum habere multa rerum thread eadem notitia et notitia eius non addere filo subtegminis usque ad salutem.
///
/// 'Arcus considerans <`[` RefCell<T>`] '>'.
/// [`RefCell<T>`] Non [`Sync`] et `Arc<T>` si [`Send`] semper est: Arcum <: [`RefCell<T>`] '>' Tum fore.
/// Sed tunc est quaestio volumus;
/// [`RefCell<T>`] Non thread tutum;servat semita usura non-esse comitem a mutuo petendo res nuclei.
///
/// In finem; Capit hoc consilii, qui necesse est in aliqua par `Arc<T>` generis [`std::sync`] genus, plerumque [`Mutex<T>`][mutex].
///
/// ## Cycles fractionis cum `Weak`
///
/// Et [`downgrade`][downgrade] modum esse posse creare [`Weak`] non-culpa rubet vultus monstratorem.A potest esse regula [`Weak`] [`upgrade`][Upgrade] d ad `Arc` sed reddam tibi condita [`None`] pretii si iam relatum est factus.
/// Id est: ut nec ad valorem `Weak` indicatores, quae intus vivit de prouinciis permittit,tamen *relatum ut ut*(veniatis in copia ad valorem) viveret.
///
/// A exolvuntur inter `Arc` indicibusque numquam deallocated.
/// Propter hoc, [`Weak`] est ad conteram conuersione recurrentium.Nam `Arc` arborem validis argumentis haberet nodos a parentibus liberis ac parentibus restituit [`Weak`] indicium parvulis.
///
/// # cloning references
///
/// Est de creando novo referat counted existentium quos referendum est regula usus ad `Clone` trait implemented pro [`Arc<T>`][Arc] et [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Duo sunt infra syntaxes pi ° instituatur.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a: b, et in eodem loco memoriae locus foo sunt omnia, quae sive Arcus,
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` statim ut dereferences `T` ([`Deref`][deref] in via trait), ideo non dicimus `modi'sT` in valore ex `Arc<T>` generis.T` 's repugnat, cui nomen eius modi ut ne in `Arc<T>` modi de se consociata sunt munera: [fully qualified syntax] vocatur usus;
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// 'Arcus;<T>`S implementations de traits sicut `Clone` potest etiam usura dicitur esse plene qualified Syntax.
/// Ut nonnulli potius plene qualified Syntax, cum aliis per modum malo integra vocatio, Syntax.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Modum vocationem, Syntax
/// let arc2 = arc.clone();
/// // Syntax plene qualified
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] non auto-`T` ad dereference, quia interiorem potest habere valorem iam elapsum excidit.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Quaedam participatio notitia inter relatorum res immobiles:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// ** ** currere isti nec Nota quod hic probat.
// Super windows in cementariis ut si filum manet infelix exitus pelagus filum et tunc simul (quod Deadlocks), sic isto modo ne omnino neque per currentem istis examinationibus.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Sharing rerum invisibilium visibiliumque [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Ecce enim [`rc` documentation][rc_examples] enim exempla magis arbitrantes, generatim de referat.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` Est versionem [`Arc`] a non-culpa rubet vultus ad quod se tenet managed destinatio.
/// Destinatio enim [`upgrade`] accessed per vocant monstratorem super `Weak`, postquam vestis est [`Option`]`<: [`Arc`]`<T>> '.
///
/// Quia non est numerare referat ad `Weak` potest, ne non de valore condita relatum esse depositas, quae non facit `Weak` polliceri se in pretii etiam non praesentis.
///
/// Ita ut reverteretur cum [`None`] [`upgrade`] d.
/// * * Impedire non tamen nota quod in `Weak` destinatio se referat (advocatam copia) quod ex deallocated.
///
/// A `Weak` contentus pro perseverantia ad tempus utile sit regula ad destinatio tractanda [`Arc`] sine quo minus sua pretii ab interioribus quae relinquantur.
/// Et ne ad indicium [`Arc`] est inter circulum references: quoniam culpa rubet vultus mutua references nunquam patitur esse omitteretur institutum aut [`Arc`].
/// Nam [`Arc`] arbor potuit validis argumentis nodos a parentibus liberis ac parentibus restituit `Weak` indicibusque parvulis.
///
/// Modum proprium dicimus obtinere `Weak` [`Arc::downgrade`] est regula.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Hoc est patitur `NonNull` optimizing in enums magnitudinem huius generis, sed non necessario validum monstratorem.
    //
    // `Weak::new` Hoc facit ut non opus `usize::MAX` spatio tumulus placeat.
    // Non de valore quod verum erit unquam habebit monstratorem quod habet RcBox dam saltem II.
    // Et hoc modo potest esse cum `T: Sized`;unsized `T` non dangle.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Hoc est repr(C) future-probationem enim refectio, in agrum esse, qui aliter tutam intermixti essent transmutabiles [into|from]_raw() ex interiore types.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // acts ut ad valorem usize::MAX hominis speculatorem "locking" tempus upgrade facultatem ad infirma et downgrade indicibusque primi temporis: ad vitare `make_mut` et gentibus, in quo `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Surculis construere novum `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // In regula satus infirma comitem velut I, qui sit infirma suus tenuit in regula, quod omnis fortis indicia (kinda), videatur std/rc.rs pro magis info
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Surculis construere novum `Arc<T>` ad infirma est per ipsum.
    /// Conanti ut upgrade referat infirma antequam munus hoc mihi proveniet in `None` valorem redit.
    /// Tamen, ut referat infirma sit congregatio sponte et cloned sunt in novissimis temporibus.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Constituat "uninitialized" in interiorem statum infirmi et referat unum.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Gravis monstratorem non dare dominium infirmum aut liberabitur memoriam redit `data_fn` tempore.
        // Si fieri uellent dominio monstratorem nos infirmi sumus addit posse, sed etiam accideret updates secundum praescriptum infirmis ne necesse sit.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Iam turn nos possumus recte initialize interiore valorem et fortis in infirma referat referat.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Et data est ecclesiæ scribe super huiusmodi, ager debet esse visibilis ad relatorum a non-nulla comitem fortis.
            // Ergo saltem opus "Release" Hæ vices synchronize ut cum `compare_exchange_weak` in `Weak::upgrade`.
            //
            // "Acquire" ordo est non requiritur.
            // Si modo consideratur, fieri `data_fn` partum of vultus procul opus quod facere cum ad a non-upgradeable `Weak`:
            //
            // - Non enim possumus * *`Weak` cDNA clone: et infirma augendae referat comitem.
            // - Potest fluent eorum clones, minuere comitem infirma reference (to sed nulla umquam).
            //
            // Ne qua in parte effectus incursum atque incolumi aliud signum detur effectus est.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Ut communiter commune habent debilem fortem Greek Quantum ad senem infirmum ne destructor ordine currunt.
        //
        mem::forget(weak);
        strong
    }

    /// Surculis construere novum `Arc` uninitialized de contentis in eodem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Initialization in diem differatur;
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Novo construere `Arc` uninitialized de contentis memoria `0` bytes repletus.
    ///
    ///
    /// Vide [`MaybeUninit::zeroed`][zeroed] ad modum huius usus exempla in recto et falsa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Surculis construere novum `Pin<Arc<T>>`.
    /// Si instrumentum non `T` `Unpin` igitur `data` fixus erit memoria non ferentur.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Surculis construere novum `Arc<T>`: redeuntem sed error nisi destinatio non sufficit.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // In regula satus infirma comitem velut I, qui sit infirma suus tenuit in regula, quod omnis fortis indicia (kinda), videatur std/rc.rs pro magis info
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Cum surculis construere novum `Arc` uninitialized contentis in eodem, sed error reversus nisi destinatio ratio de utroque.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Initialization in diem differatur;
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Cum surculis construere novum `Arc` uninitialized contenta in eodem cum impleta esse memoriae `0` bytes: Si reversus errorem destinatio ratio.
    ///
    ///
    /// Vide [`MaybeUninit::zeroed`][zeroed] ad modum huius usus exempla in recto et falsa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Interiorem refert ad valorem si `Arc` sed unum habeat fortis referat.
    ///
    /// Alioquin [`Err`] hoc est, eadem reuertens similiter `Arc` hoc praetextu.
    ///
    ///
    /// Hic erit succedant etiamsi multa sunt eximia infirma p.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Infirma mundi faciunt implicite monstratorem respectu fortis debilem
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Surculis construere novum atomically-reference counted FRUSTUM de uninitialized contentis in eodem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Initialization in diem differatur;
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Segmentum atomically referuntur in novo construere numeratur uninitialized contenta plenae memoria `0` bytes.
    ///
    ///
    /// Vide [`MaybeUninit::zeroed`][zeroed] ad modum huius usus exempla in recto et falsa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Proselytis et `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Ut apud [`MaybeUninit::assume_init`] est usque ad obligandae fidei in interiore ma gistrum suum valorem vere in civitate Initialized est.
    ///
    /// Hoc nondum plene initialized causas vocant contentus statim cum indefinita mores.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Initialization in diem differatur;
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Proselytis et `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Ut apud [`MaybeUninit::assume_init`] est usque ad obligandae fidei in interiore ma gistrum suum valorem vere in civitate Initialized est.
    ///
    /// Hoc nondum plene initialized causas vocant contentus statim cum indefinita mores.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Initialization in diem differatur;
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Manducat `Arc`, depositum involvit reversus est monstratorem.
    ///
    /// Ne ad memoriam reduxit `Arc` Leak per monstratorem [`Arc::from_raw`] convertentur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Praebet rudis monstratorem data.
    ///
    /// Comites ne ullo modo affectus `Arc`, et non combureretur.
    /// In monstratorem diu non valent quantum valet pro duco in `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // Salutem: iste RcBoxPtr::inner quod non potest ire propter Deref::deref
        // quo retineant, requiritur talis eg raw/mut provenientia
        // `get_mut` Re est cum monstratorem scribere per `from_raw` recuperauit.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// `Arc<T>` construit a rudis monstratorem.
    ///
    /// Prius viva regula est vocatio [`Arc<U>::into_raw`][into_raw] redit `U` ubi oportet ut `T` scalpturaque dam.
    /// Haec si vera `U` Triviae in modum plantatas `T` est.
    /// Si autem `T` `U` quod non est eadem magnitudine et Gratia diei et noctis, hoc est basically tamquam causam transmutantem de references diversorum generum.
    /// Vide [`mem::transmute`][transmute] pro magis notitia de hac re quae restrictiones competiturum.
    ///
    /// A user has a `from_raw` fac a certis de `T` valorem omissa tantum semel.
    ///
    /// Hoc munere tuta memoriae improprietas ducat unsafety etiamsi numquam rediit `Arc<T>` obvius.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Et conversus ad `Arc` ne Leak.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Praeterea vocat memoriam, ut `Arc::from_raw(x_ptr)` esse tutum.
    /// }
    ///
    /// // Cum memoriam liberatus `x` egressus est vis ut nunc `x_ptr` pendere?
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Ut novis epistolis offset invenire originale ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Gignit id est regula ad novum [`Weak`] destinatio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Bene est propter nos remisit reprehendo in ad valorem infra CAS.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // Si is reprehendo "locked" contra infirmos;Sic nent.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: codice isto currently in oblivionem detur facultatem redundantiam
            // in usize::MAX;Re Arcus; et generatim tam redundantiam opus ad agam cum ad esse Moderatis.
            //

            // Secus ac in Clone(), hoc non est opus ut synchronize cum legitur Acquire ex `is_unique` ecclesiæ scribe: ita certe ut ante ut fit ante hoc legere scribentes iniustitiam.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Fac pendet Infirma si non efficiunt
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Fuerit numerus [`Weak`] indicibusque ad destinatio.
    ///
    /// # Safety
    ///
    /// Et hoc tutum est ipsum per modum sed bene utendo quod extra cura requirit.
    /// Alius filum potest mutare ad infirma quando comitem, inter vocant in potentia inter hunc modum agendi, et per exitum.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Quia non participat'Anima deterministico `Arc` `Weak` inter fila vel.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Si infirma currently comitem clausum est, et clausum in valore ipsius comitis, antequam esset 0.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Huic indicium firma habet (`Arc`) destinatio.
    ///
    /// # Safety
    ///
    /// Et hoc tutum est ipsum per modum sed bene utendo quod extra cura requirit.
    /// Alii quando filum potest convertere ad comitem fortis, inter hanc vocant in potentia inter modum agendi, et per exitum.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Quia'Anima deterministico inter fila `Arc` non adfuerint.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Cum referant forti numerabat incrementa `Arc<T>` dummodo a regula.
    ///
    /// # Safety
    ///
    /// In monstratorem per adeptus est `Arc::into_raw` sunt, et consociata `Arc` valet, exempli gratia esse oportet (id
    /// ad comitem oportet saltem fortis I), ad modum status hujus durationem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Quia'Anima deterministico inter fila `Arc` non adfuerint.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arcus retinere nolite tangere in refcount involvendo ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Nunc refcount auget, sed refcount non stillabunt novam aut
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Cum ordine `Arc<T>` numerabat fortis decrementa dummodo a monstratorem.
    ///
    /// # Safety
    ///
    /// In monstratorem per adeptus est `Arc::into_raw` sunt, et consociata `Arc` valet, exempli gratia esse oportet (id
    /// ad comitem fortes necesse est saltem I) cum invocabant modum.
    /// Modum hoc esse potest dimittere `Arc`, et veniatis ad ultima repono, neque ** ** at cum dicitur esse quod est supremum `Arc` dimisit.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Qui nullum deterministico quia inter fila `Arc` non adfuerint.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Et hoc est ok unsafety quia dum erant 'vivens arcus est spopondissemus interiorem valet regula.
        // Ceterum compages `ArcInner` scimus esse, quia ipsa `Sync` interiore notitia `Sync` tum est, ut haec regula ad incommutabilem sumus ok loaning de contentis in eodem.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Non inlined parte `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Data Attero ad hoc tempus, etsi non sumus arca archa destinatio liberabo ipso (nihil adhuc infirmi sint indicia circa iacentem).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Iacta infirmus fortia ref ab omnibus communiter References
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true` duo redit, si ad idem punctum: Arc`s destinatio (in vena autem similis [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Quod satis allocates `ArcInner<T>` locus in quo valore in interiorem hominem possibile est unsized valorem habet layout provisum.
    ///
    /// Et munus `mem_to_arcinner` cum dicitur data est reverterentur retro et in regula (in potentia, adipem)-pointer ad `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Calculate layout utendo valorem layout datis.
        // Previously, omnibus et conputatis layout de `&*(ptr as* const ArcInner<T>)` expressio sed misaligned referat creatus est (see #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Allocates `ArcInner<T>` per spatium sat est pro valore interiorem hominem possibile est unsized valorem habet ubi provisum layout, in error reversus nisi destinatio ratio.
    ///
    ///
    /// Et munus `mem_to_arcinner` cum dicitur data est reverterentur retro et in regula (in potentia, adipem)-pointer ad `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Calculate layout utendo valorem layout datis.
        // Previously, omnibus et conputatis layout de `&*(ptr as* const ArcInner<T>)` expressio sed misaligned referat creatus est (see #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner ad initialize
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Allocates `ArcInner<T>` est cum spatii sufficient ad interiorem unsized ad valorem.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Deducendae agroque diuidundo ad `ArcInner<T>` uti datis valorem.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Pro valore exemplum bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Non est privata fetu contenta in eodem destinatio liberate
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Per longitudinem datam allocates `ArcInner<[T]>`.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Segmentum placentae in effingo ex elementis nuper datum Arcum <\[T\]>
    ///
    /// Auferre dominium aut ligabis vel `T: Copy` tuta RECENS.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Construit iterator `Arc<[T]>` est de nota esse cujusdam magnitudine.
    ///
    /// Temporis ut sit mole sint mores ad iniuriam.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // T maxime exquisitis rationibus Panic relicta elementa.
        // In eventu de panic, elementa, quae scripta sunt in nova ArcInner erit omissa, tunc memoria liberari.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Indicium est primum elementum
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Omnes patet.Ita non obliviscaris narrantes somnia liberabo novum ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializatione trait propter `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Facit a clone de `Arc` monstratorem.
    ///
    /// Facit eadem regula destinatio alia augendo forte secundum numerum.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Licet enim per vices dissolutum hic facit aliam scientiam referant, unde male Deletis primi obiecti.
        //
        // Ut in [Boost documentation][1]: Prole Augenda contra referat fieri non potest, semper cum memory_order_relaxed: Novi references to object non est nisi existentium esse potest ex referat, et transeuntes ad existentium referat a filo subtegminis usque ad alium, oportet providere quis iam requiritur synchronization.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Sed contra massive refcounts servare necesse est ut si aliquis est: Arcus Ordinatim forget`ing::Mem.
        // Si enim hoc non potest, inundans, et comitem utuntur, eam post-free.
        // Nos autem racily saturatas `isize::MAX` ~2 billion in assumptione et non est relatorum incrementing referat ad comitem simul.
        //
        // Hoc non branch in aliquo componendus est ordo rerum.
        //
        // , Abortum quod nos tam malesuada pravum progressio est et nos non pertinet ad senatum veni mane.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Referat ad `Arc` dedit facit mutabilem uerteretur.
    ///
    /// Si `Arc` sunt et alia eiusdem [`Weak`] indicibus etiam, ad destinatio, tunc partum a novus `make_mut` et destinatio in interiorem et invocate [`clone`][clone] valorem unique ad invigilandum, proprium transcriberentur.
    /// Hoc etiam relatum ut ut est, clone scribam.
    ///
    /// Notate quod differt a moribus [`Rc::make_mut`] disassociates ullo `Weak` indicibusque.
    ///
    /// Vide etiam [`get_mut`][get_mut], quod querimonia quam maxime exquisitis rationibus.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Non clone quicquam
    /// let mut other_data = Arc::clone(&data); // Nolo clone interiore notitia
    /// *Arc::make_mut(&mut data) += 1;         // Clones interiore notitia
    /// *Arc::make_mut(&mut data) += 1;         // Non clone quicquam
    /// *Arc::make_mut(&mut other_data) *= 2;   // Non clone quicquam
    ///
    /// // Et nunc `data` `other_data` prouinciis referentibus iam diversis.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Sciendum uero infirmi et secundum utramque secundum validus.
        // Sic dimittere fortes nostri non dicitur nisi ex ipsa memoria sit deallocated faciat.
        //
        // Ut videmus aliquem usum acquirere cialis scribat Domino factum est in conspectu release `weak`, inquit (id est, decrementa) ad `strong`.
        // Tenemus enim mollius Comitem ArcInner forte ipse esset deallocated nulla.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Alius regula fortis existit, clone ita et nos.
            // Pre-deducendae agroque diuidundo memoria sineret scribo ad valorem cloned directe.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Hoc est quod supra ostendit hoc ipsum in altero remissa sibi sufficiat, et nos infirmi sumus in certamine cursus currit indicatores, quae semper relinquantur.
            // Maxime in re nos terminus sursum per novus partita imperia Arcus sit necessarium.
            //

            // Ref novissimis fortes nobis remota, sed infirmi sunt additional refs uno tempore.
            // Nos youll movere novam continent in Arcus iste, cuam irritum alia infirma refs.
            //

            // Ut notam faceret usize::MAX `weak` legunt non possunt (id conclusi) quoniam infirmus ad filum comiti tantum clauditur quantum forti.
            //
            //

            // Materia infirma nostra implicita monstratorem, qui possit ita ut tersus sursum opus ArcInner.
            //
            let _weak = Weak { ptr: this.ptr };

            // Furantur non solum in notitia, suus 'omnes quia egressus est Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Fuimus una respectu utriusque;ad comitem gibba validos Ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Ut `get_mut()` est quia quantum potero unsafety incipere vel unus vel una cloning contenta est.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Mutabilis est in quantum `Arc` revertitur, aut si aliud `Arc` [`Weak`] indicibusque destinatio eiusdem.
    ///
    ///
    /// [`None`] aliter redit, quia ad mutate salvum non participatur ad valorem.
    ///
    /// Vide etiam [`make_mut`][make_mut], quod [`clone`][clone] interiore valorem cum alia indicia sunt.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Quia haec unsafety est ok modo dubia esse regula rediit * * monstratorem sit quod reddidit umquam potest T-
            // I nostra referat in hac parte comitem esse certo atque non requiritur ipsum esse `mut` Arcus iste, ut erant 'reddens solum possibile ad interiore notitia.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Reversus est in quantum `Arc` commutabile sine reprehendo.
    ///
    /// Vide etiam [`get_mut`], qui incolumem non oportet compescit.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Destinatio eiusdem `Arc` alia indicia non dereferenced [`Weak`] sive durationis postulet rediit.
    ///
    /// Apud talem Triviae in modum plantatas si nullum est indicium est, exempli gratia statim post `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Ut referat partum a covering * * ne nos ex "count" per agros, quasi hic vellet alias simul cum aditus valet ad reference (eg
        // per `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Sive unique determinare hoc quod reference (including infirma refs) ad underlying data.
    ///
    ///
    /// Nota quod obfirmatis sera requirit infirmi comitem ref.
    fn is_unique(&mut self) -> bool {
        // clauditis infirmis infirmus monstratorem comes unica regula videtur si possessor.
        //
        // Durum praestat hic titulus est, antequam fit cum aliqua scribat `strong` necessitudinem (maxime in `Weak::upgrade`) ante `weak` comitem et decrementis (`Weak::drop` via, quam release utitur).
        // Si upgraded infirma ref numquam stillarunt, etiam hic erit CAS, et deficere non curamus ut synchronize.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Et hoc est quod necessitates `Acquire` ut synchronize et decrementum in `strong` contra `drop`-nulli nisi claudo, quod fit ultimo referat quis autem est factus.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Et conformiter est hic release ecclesiæ scribe in `downgrade` legere, efficaciter reprimatur in superius post fieri ex `strong` legere et scribere.
            //
            //
            self.inner().weak.store(1, Release); // et dimittere cincinno
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` deponat.
    ///
    /// Hoc autem decrement fortis referat ad comitem.
    /// Nisi forte secundum quam nulla spatia comes si aliis (si) [`Weak`] et sic interior `drop` pretium.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Does non procer quicquam
    /// drop(foo2);   // Maps "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Quia iam `fetch_sub` nuclei, non indigent nisi ut synchronize sumus iens ut relatorum cum aliis delere est.
        // Eandem habet rationem ad `fetch_sub` `weak` comiti infra.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Haec saepes reordering ne necesse est ut in notitia et usu ad deletionem data.
        // Quod alibi `Release`, et decrescentis conformiter ad hoc referat comitem `Acquire` cadit.
        // Hic modo notitia quae fit in usum referat ad comitem prius decrescentes quam ante hac saepe fit, quod fit antequam deletionem data.
        //
        // Ut patet in [Boost documentation][1],
        //
        // > Illud quod per accessum ad quaslibet rerum
        // > filo subtegminis (existentium et per reference) fiet ut prius * * deleting
        // > alia res filum.Hoc effectum per "release"
        // > post operationem omittendae delationis reference (accessum ad res quis
        // > per talem esse manifesto antea factum erat), et
        // > "acquire" ante operationem deleting est.
        //
        // In particular dum Summa Arcus enim plerumque res est, sic possibile est ut aliquid intus, inquit, sicut Mutex<T>.
        // Cum autem Mutex acquiritur si non deletum est, ut ratio synchronization auri dicit, non potest non confidunt in sua sequela visibilis A ad B. destructor currit e sequela
        //
        //
        // Acquire etiam note quod hic saepe verisimile esse poterat cum Acquire onus reponit, quae non sunt in altus-perficientur meliorem adiunctis contendit.Vide [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Qui conturbas me conatus `Arc<dyn Any + Send + Sync>` induit pro determinata genus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Surculis construere novum `Weak<T>`, sine ullo memoriae allocating.
    /// [`upgrade`] vocant, semper valorem dat [`None`] in reditu.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Paracletus autem accessing typus patitur ut referat comites facere sine notitia ad nihil affirmare agro.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Redit monstratorem quod crudum `T` `Weak<T>` hoc ostendit.
    ///
    /// Ratum tantum, si non est quaedam regula est et fortis p.
    /// In monstratorem vicem obtinere non potest: Unaligned [`null`] vel secus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Tum puncto ad idem object
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Hic fortia detinet causa, ut res adeo.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Sed non quaelibet magis.
    /// // weak.as_ptr() possumus facere, nisi esset accessing Regula in indefinitum ducunt ad mores.
    /// // assert_eq? ("Salve", statio male fida {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Si enim regula pendet, si igitur speculator qui recta revertetur.
            // Hoc payload inscriptio electronica valida non esse quod est minus quam payload ArcInner (usize) varius quam.
            ptr as *const T
        } else {
            // SALUS: si is_dangling redeunt falsum, tunc dereferencable monstratorem sit.
            // De potest payload cum egredereris in loco isto, et habebit ponere provenientia ita uti rudis regula manipulation.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Vertit in `Weak<T>` sumit crudum monstratorem.
    ///
    /// Hoc converts rudis et infirmi, in monstratorem monstratorem, dum adhuc conservare ad proprietate infirma referat unum (cum infirma comitem positus non restringitur per hoc operandi).
    /// Potest conversus est retrorsum et [`from_raw`] in `Weak<T>`.
    ///
    /// Idem cum [`as_ptr`] utilium monstratorem accessu scopo convenire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// A monstratorem converts rudis antea [`into_raw`] in `Weak<T>` creata.
    ///
    /// Hoc potest fortis esse tutum ut referat (a later [`upgrade`] vocant) seu ad comitem a Cretensibus `Weak<T>` deallocate autem infirma.
    ///
    /// Infirma suscipit dominium respectu (praeter indicia [`new`] creatura, quae non sibi aliquid operetur eorum tamen ratio).
    ///
    /// # Safety
    ///
    /// Debet esse ex hac tamen regula est [`into_raw`], et ejus potential habent infirma referat.
    ///
    /// Licet non ad esse fortis comitem vocant 0 ad hoc tempus.
    /// Nihilominus venerit istud dominium referat unum currently infirma persona dicitur rudis in regula (infirma in hac operatio non alterari comitem) et igitur eam esse priorem vocationem ad paribus cum [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Decrement ultimum infirma comitem.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Vide quomodo initus monstratorem super Weak::as_ptr in contextu inventa ducuntur.

        let ptr = if is_dangling(ptr as *mut T) {
            // Hoc pendet infirmum.
            ptr as *mut ArcInner<T>
        } else {
            // Alioquin fides monstratorem nos ab nondangling sit inualidus.
            // Utilitatibus consulens tutum data_offset sit appellare, quod ptr references verum (cecidit in potentia) A.
            let offset = unsafe { data_offset(ptr) };
            // Ut nos novis epistolis ad universum RcBox offset.
            // SALUS et originated fecit a regula, ut haec offset sit tutum.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // Salútem: si iam recepit ad originale Infirma monstratorem, ita potest creare an in pluribus.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Conatus est monstratorem `Weak` upgrade [`Arc`] moratur iactura si interiorem vim eu.
    ///
    ///
    /// Si refert [`None`] habet cum interiore valorem omissa sunt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Dissipate universos fortes indicibusque.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Non utor a Centera loop incremento comitem est fortis sicut fetch_add loco hoc munus accipere non debere se referat ad comitem a nulla.
        //
        //
        let inner = self.inner()?;

        // Quia onus remissa ulla 0 scribere ut nos quoque possumus experiri, nullus relinquat statum perpetuum in agro (sic enim legit "stale" fine de 0 est), et alia via confirmata est super CAS infra valorem.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Ecce enim commentarios in `Arc::clone` cur hoc (nam `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Remissioribus est finis propter defectum ex causa quia non habent spem de statu novo.
            // Durum est pro victoria casus ut synchronize `Arc::new_cyclic` sunt cum interiore valorem potest initialized `Weak` references cum iam creata est.
            // In hoc casu, non exspectare oportet observare initialized plene valorem.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // nullum est repressit
                Err(old) => n = old,
            }
        }
    }

    /// Hoc ulterius quaeritur firma indicibusque (`Arc`) destinatio.
    ///
    /// Si `self` creatus per [`Weak::new`], hoc reddet 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Demonstrato argumentis `Weak` habet ad numerum proxime destinationem.
    ///
    /// Quod si per [`Weak::new`] `self` creatus, aut si quae residua sunt fortes, Romane, memento huius reddet 0.
    ///
    /// # Accuracy
    ///
    /// Ob implementation singula, rediit ad valorem possit I abi ab utraque parte altera, cum omnem relatorum non abusionibus Arc`s 'seu`digito Weak`s destinatio eiusdem.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Quia dictum quod saltem firma regula lecto infirmus comitem scimus implicita infirma ordine (quae cum omne spectant viveret) tamen inter dum vidimus infirmum comitis et ideo securi demere.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Refert `None` cum sit regula pendet et non est datum `ArcInner`, (id est, a quo creata est `Weak` `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // * * Neque enim facientes feceritis partum a covering referat "data" est ager, agri ac simul mutari potest (exempli gratia, si ultimum `Arc` est cælique ac data est ager, et aliquid in aqua uitale).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Si duo `true` redeunt ad idem punctum: Weak`s destinatio ([`ptr::eq`] similis), vel utrumque non ad designandum destinatio (nam et creata sunt `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// `Weak::new()` quin hoc indicium comparet sibi aequalis, etiamsi non ad designandum destinatio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` comparet.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Clone `Weak` regula fit per puncta eadem destinatio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Vide quid id ad quod solvit commentarios in Arc::clone().
        // Hoc autem fetch_add potest (culturalis ignorans pondus cincinno), quia *ubi nullus alius* clausum infirma comitem tantum infirma indicium esset.
        //
        // (Sic enim in eo codice isto casu non currit).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Vide quid faciemus haec commentarios in Arc::clone() enim (nam mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Surculis construere novum `Weak<T>` sine opum memoria.
    /// [`upgrade`] vocant, semper valorem dat [`None`] in reditu.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Deponat `Weak` monstratorem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Does non procer quicquam
    /// drop(foo);        // Maps "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Si quod cognoscetis quia nos infirmi orbe terrarum vix monstratorem ergo tempus habet in notitia plane deallocate.Ecce Arc::drop() discursus memoriae circa ordines
        //
        // Non necesse reprehendo clausa status quia infirma comiti tantum claudatur Si enim ob unius putabuntur ref idest declinatio nisi postea currere manente infirma ref quod nonnisi post sera dimitti.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Erant hic agis hic specialis et non a communioribus in `&T` ipsum, quia esset addere aliud sumptus ad aequalitatem refs impediunt.
/// Supponimus hic `magnam condo valoribus sunt Arc`s ut viventes, segnius ad clone, sed etiam gravis ad reprehendo propter aequalitatem, inde est reddere sumptus off facilius.
///
/// Est `Arc` quoque magis verisimile habere duas clones, quae ad idem punctum pretii, quam duas `&T`s.
///
/// Possumus nisi hoc quod `T: Eq` quasi de industria irreflexive `PartialEq` esset.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Aequalitatem duabus: Arc`s.
    ///
    /// Arc`s: si intra duos valores aequales funt, licet diuersis prouinciis latent.
    ///
    /// Si `T` et effectum adducit `Eq` (importet aequalitatem reflexivity est) duo puncto ad idem: quia Arc`s destinationem semper æquales.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// De Inaequalitatibus Quas duas `Arc`s.
    ///
    /// `Duae Arc`s inaequales esse ad invicem interiorem eorum Si valores sint inaequales.
    ///
    /// Si `T` effectum adducit `Eq` quoque (ab importat aequalitatem reflexivity) duo in eodem loco esse: Arc`s pretii non sunt inaequales.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Sive partiales collatio: nam duo Arc`s.
    ///
    /// Duo vocantem comparentur `partial_cmp()` in interiorem animationem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Minus comparationis est, quia `duo Arc`s.
    ///
    /// Duo sunt, comparari ab vocant `<` in interiore animationem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Minus quam aequalis, Arc`s: collatio duos.
    ///
    /// Duo sunt, comparari per interiorem vocant `<=` in animationem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// , Maior quam Arc`s: collatio ad duo.
    ///
    /// Duo comparari quae ab interiore in values `>` vocant.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Maior quam vel aequalis ad duo: collatio ad Arc`s.
    ///
    /// Duo sunt vocantem comparari ab `>=` in interiorem animationem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Collatio: nam duo Arc`s.
    ///
    /// Duo sunt in interiorem `cmp()` vocant comparari per animationem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `Arc<T>` novum gignit, cum ad valorem `Default` `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Referendum est cloning placeat numeratur per `secare implevi V` item s.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Reference, et reputatum est deducendae agroque diuidundo `str` effingo illud in `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Reference, et reputatum est deducendae agroque diuidundo `str` effingo illud in `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Moueatur solere obiecti noua uocato reputantur referuntur.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Referendum est reputabitur de Verre V` placeat: item eam moveri.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Liberum permittit Vec memoria non contenta perdere
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Unusquisque enim in se colligit `Arc<[T]>` `Iterator` elementum.
    ///
    /// # habet euismod
    ///
    /// ## Et casu dux
    ///
    /// In casu, in `Arc<[T]>` colligendis fit primis in colligendis `Vec<T>`.Quod est scribens, et quae sequuntur,
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// iste se tamquam si scripsi:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Primum paro of prouinciis referentibus accidit hic.
    ///     .into(); // A destinatio et secundo `Arc<[T]>` hic fiunt.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Hoc autem necessariam ad fabricandum `Vec<T>` deducendae agroque diuidundo legitimus: totidem quot ego et sic enim aliquando conversus `Vec<T>` in `Arc<[T]>` deducendae agroque diuidundo.
    ///
    ///
    /// ## Notae autem Iterators
    ///
    /// Cum `Iterator` tuum et ad effectum adducit `TrustedLen` est, an magnitudo, unum et factum est destinatio pro `Arc<[T]>`.For example:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Fit sicut unum destinatio hic.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specializatione in colligendis trait propter `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Haec causa est `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SALUS: Nos postulo ut iterator autem habeat rectam et longitudo habeat.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Cadunt ad normalis implementation.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Get ex offset `ArcInner` propter quod in tergo est regula payload.
///
/// # Safety
///
/// Monstratorem est designandum ad (metadata et est verum) exempli a et valet ante T, sed permissa, ut T omissa tribuni.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Conlineare usque ad valorem finis unsized ArcInner.
    // Quia RcBox repr(C) est, quod memoria semper erit in novissimis agro.
    // SALUS: ex quo tantum potest unsized genera sint diuisa, trait occurrit:
    // et in externis figuris, quod is currently initus sufficit ad salutem postulationem satisfacies align_of_val_raw;implementation hoc est in detail in linguis fidentem, quae non potest extra std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}