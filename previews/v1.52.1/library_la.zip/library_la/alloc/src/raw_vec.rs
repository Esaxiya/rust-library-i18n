#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Illa quae novae sunt memoriae uninitialized.
    Uninitialized,
    /// Nova zeroed in memoria sit praestitum.
    Zeroed,
}

/// Opum plus utilitatis ergonomically humili gradu, reallocating et quiddam memoriae super cumulum deallocating sine cura omnes angulos casibus implicatur.
///
/// Hoc genus structurae, sicut Vec est optimum in aedificationem data, et VecDeque tua.
/// Praesertim:
///
/// * `Unique::dangling()` ipsius fit in-sized types nulla.
/// * Tandem in prouinciis `Unique::dangling()` nulla profert.
/// * Avoids `Unique::dangling()` liberans.
/// * Scatet facultatem ex omni calculo ("capacity overflow" ae promoveat ad panics).
/// * XXXII bits systems custodibus contra opum plus isize::MAX bytes.
/// * Gratulatio vestra contra conantur.
/// * De prouinciis referentibus `handle_alloc_error` vocat fallibilis.
/// * `ptr::Unique` ita contineat in user toto related beneficia impendat.
/// * In excess allocator utitur rediit ut ex maxima praesto facultatem.
///
/// In Hoc genus non est memoria, quae usquam inspicere procurat.Liberabo te * * non tegeret cum eius memoria, et ea * * non tentant fluent ad singula contenta in eodem.
/// Est autem usque in user `RawVec` ut ad rem ipsam quae intra * * stored de `RawVec`.
///
/// Utpote nullius magnae rationes amplitudo est infinitum et semper `capacity()` `usize::MAX` redit.
/// Diligenter cum per id opus cum ventitabas `Box<[T]>` hac cum longitudine `capacity()` non obsequeretur.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Quia non congruit existit `#[unstable]` fn`s `min_const_fn` int: unde dicitur: min_const_fn`s non possunt.
    ///
    /// Si mutare `RawVec<T>::new` aut meritis colligati cura placere non inducere ad hoc quod aliquid contra veritatem `min_const_fn`.
    ///
    /// NOTE: Non reprehendo conformance potuit hanc necessitatem vitare saginantur, de qua praedicatur aliquid `#[rustc_force_min_const_fn]` conformance requirit necessario patitur ex `min_const_fn` vocantem, non autem in `stable(...) const fn`/user codice non enabling `foo` `#[rustc_const_unstable(feature = "foo", issue = "01234")]` cum praesens est.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Creates esse maximus `RawVec` (in acervum lapidum systema) opum sine.
    /// Si magnitudinem positive `T` est ergo cum `RawVec` fecerit hanc facultatem `0`.
    /// Si `T` nullus est-amplitudo, tunc non fecerit `RawVec` `usize::MAX` cum facultatem.
    /// Utile effectum dilatio destinatio.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Creates a `RawVec` (de congeries systematis) cum in facultatem prorsus Gratia diei et noctis: et requisita in `[T; capacity]`.
    /// Haec equivalent ad vocantem `RawVec::new` cum `capacity` est `0` `T` vel mediocri, nulla sit.
    /// Nota ut si `T`-sized est nulla erit hoc tibi modo *non* rogatus a `RawVec` cum facultatem.
    ///
    /// # Panics
    ///
    /// Si rogatus Panics `isize::MAX` bytes facultatem excedit.
    ///
    /// # Aborts
    ///
    /// Aborts est oom.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Velut `with_capacity` sed spondent zeroed quod est quiddam.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Quas cylindrus non est regula et `RawVec` de facultatem.
    ///
    /// # Safety
    ///
    /// Quod partita sit `ptr` (in systema acervum petrarum), et ex datis `capacity`.
    /// In mediocri figura `capacity` ad `isize::MAX` qui praeterire non poterunt.(Nisi de die XXXII frenum ratio).
    /// Ut haberet facultatem ZST vectors ad `usize::MAX`.
    /// De `RawVec` `ptr` et `capacity` Si ergo fides est.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecs minima es muta.Skip to:
    // - Si enim magnitudinem I elementum VIII, quod nihil est Tumulus allocators de minus quam VIII bytes petitionem est verisimile coge ut saltem VIII bytes.
    //
    // - IV Si enim modica elementa (<=MiB I).
    // - I secus, spatium ne nimium vastantes quia paululum Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Velut `new` sed Parameterized per arbitrium a allocator ad `RawVec` reddidit.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` significat "unallocated".-sized nulla sint, neglecta sunt.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` sicut et in Parameterized elegit ex allocator ad rediit `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Velut `with_capacity_zeroed` sed Parameterized allocator nam per arbitrium a rediit `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Conuerti fecerit `Box<[T]>` in `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Est quiddam totum convertitur in `Box<[MaybeUninit<T>]>` `len` determinatis.
    ///
    /// Nota: et quod mutationes, ut potest bene `cap` noviter constituere aliquem locutum fuisse credamus.(Vide autem descriptio generis for details.)
    ///
    /// # Safety
    ///
    /// * `len` maior esse debet quam vel aequalis ad plus Nuper rogatus facultatem et
    /// * `len` minus esse `self.capacity()` paribus.
    ///
    /// Notandum, quod aliter non petitam facultatem `self.capacity()` velut memoriae impedimentum maius quam allocator posse reverti overallocate postulavit.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanitatem salutemque Baal perquirite medium oportet (non sustineret dimidium).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Quod hic nobis vitare `unwrap_or_else` bloats moles LLVM IR factam.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// `RawVec` quas cylindrus non est ex regula: facultatem et allocator.
    ///
    /// # Safety
    ///
    /// Et datum sit `ptr` (per allocator datis `alloc`), et ex datis `capacity`.
    /// Quod enim mediocri `isize::MAX` types `capacity` qui praeterire non poterunt.
    /// (Tantum XXXII spectat a frenum ratio).
    /// Ut haberet facultatem ZST vectors ad `usize::MAX`.
    /// Si `ptr` et `capacity` venit ex via `alloc` `RawVec` creatus est ergo quod praestatur.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Accipit rudis monstratorem est initium destinatio.
    /// Nota quod nullus sit `Unique::dangling()` `T`, si vel mediocri `capacity == 0`.
    /// In priori casu vos oportet esse cautior.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Destinatio gets facultatem.
    ///
    /// Haec tibi semper `usize::MAX` si `T`-sized nulla est.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Redit ad communem allocator `RawVec` hoc patrocinium.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Nos datum FRUSTUM habere memoriam, ut nos can bypass checks runtime ut nostrum current layout.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Saltem habere quiddam efficit dilatavit `len + additional` elementum.
    /// Si ea non satis facultatem habeas, sufficit tibi reallocate plus spatii ad spatium impetro comfortable inutilis amortized * * O (I) mores.
    ///
    /// Frustra se velle facere terminet panic moribus.
    ///
    /// Si `len` `self.capacity()` excedit, haec ad ipsum deficere potest deducendae agroque diuidundo rogatus spatium.
    /// Hoc parum tuta non realiter sed *tutam ambulantibus codice enim vos* in mores huius scribis Veronae relies ut conteram munus.
    ///
    /// Apta mole effectum ducenda est per operationem, velut dis `extend`.
    ///
    /// # Panics
    ///
    /// Panics si novam facultatem excedit `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborts est oom.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // Fetus et si utique condicione attonitus `isize::MAX` ita excedere necessarium non tenuisse len nunc.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Et sicut `reserve` sed redit in errorem aut abortum pro TREPIDANS.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Saltem habere quiddam efficit dilatavit `len + additional` elementum.
    /// Si non prius, quantum fieri et reallocate ad minimum memoriae necesse est.
    /// Hoc prorsus esse memoriae fere quantum opus est, sed quod in principle allocator liberum est dare quam nos back poposcit.
    ///
    ///
    /// Si `len` `self.capacity()` excedit, haec ad ipsum deficere potest deducendae agroque diuidundo rogatus spatium.
    /// Hoc parum tuta non realiter sed *tutam ambulantibus codice enim vos* in mores huius scribis Veronae relies ut conteram munus.
    ///
    /// # Panics
    ///
    /// Panics si novam facultatem excedit `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborts est oom.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Sicut `reserve_exact` est, sed in errore pro redit et TREPIDANS abortum fecisse.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Destinatio ad Shrinks placitos quantitate.
    /// 0 si data est copia, omnino deallocates actually.
    ///
    /// # Panics
    ///
    /// Panics si data est copia maior * * quam current facultatem.
    ///
    /// # Aborts
    ///
    /// Aborts est oom.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Si germinare redit quiddam necessitates, ad explendum opus extra facultatem.
    /// Maxime usus ut inlining Subsidium vocat, non potest inlining `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Instantiated modus saepe solet.Itaque si volo ut sicut parvum, sicut fieri potest ut amplio compile temporibus.
    // Sed etiam vis ad singula contenta in eodem esse immobiliter Computable tantum fieri potest, qui facit procursu citius in codice generatae.
    // Unde enim diligenter hunc modum scripsit in codice, ut omnia, quae in eo est positum super `T`: ut dum ex codice, quod non dependet in quantum fieri potest `T` est munera, quae in genere non-`T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Hoc procuratur per vocantem contextibus.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Cum autem revertetur `usize::MAX` facultatem ex quo est `elem_size`
            // 0, necessario est questus est `RawVec` huc onerata.
            return Err(CapacityOverflow);
        }

        // Nihil enim de his checks potest realiter facere Infelix,.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Hic promittit abibit incrementum.
        // Quod autem vidisti secundo `cap <= isize::MAX` non conteret, et species est `cap` `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` non autem in genere, in `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // De angustia hunc modum et in eodem tanta est, ut illos `grow_amortized`, sed minus saepe hoc modus est ut suus 'plerumque instantiated minus discrimine.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Cum facultatem reverteretur a magnitudine enim et genus cum `usize::MAX`
            // 0, necessario est questus est `RawVec` huc onerata.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` non autem in genere, in `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Praeter munus `RawVec` Compile obscuratis tempore.Ecce enim singula `RawVec::grow_amortized` cum comment supra.
// (`A` parameter est non significant, videatur in praxi types `A` aliud quod numerus multo minor quam numerus `T` types).
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Reprehendo huc ad circumscribendam propter errorem magnitudinem `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Gratia diei et noctis et allocator ad aequalitatem checks
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Et non liberet memoriam amet `RawVec`* * stillabunt conatur ad singula contenta in eodem.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Central munus in subsidiis posuit errorem pertractatio.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Opus praestare quae sequuntur:
// * Non umquam `> isize::MAX` deducendae agroque diuidundo-byte mole obiecti.
// * Non autem in suo actu circa deducendae agroque diuidundo redundantiam `usize::MAX` reperit minus: .
//
// Nos iustus postulo ut reprehendo in LXIV frenum, quia quaerit redundantiam deducendae agroque diuidundo `> isize::MAX` bytes quod omnino deficient.
// De XXXII-bit and-XVI frenum in opus addere extra stationes hoc in casu erant 'currit in suggestum quod, in user potest 4GB omni spatio, ut nec PAE x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Media una reporting munus reus facultatem redundat.
// Generationi huic signum te ut nulla ut affinium panics realitas quam unum situm in fasciculum panics amet quam.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}