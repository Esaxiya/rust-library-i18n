//! Utilitas pro excudendi: et String`s formatting.
//!
//! Syntax pro extensio [`format!`] cuius moduli rationem habet runtime subsidium.
//! Hoc macro is implemented in compiler emittere quasdam rationes vocat ad cuius moduli rationem ut in forma, in runtime trahunt.
//!
//! # Usage
//!
//! Et nota [`format!`] tortor esse in animo est illis ex C in `printf`/`fprintf` munera, aut in Python `str.format` munus.
//!
//! Quidam ex [`format!`] extensio sunt exempla;
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" ducens secum zeros
//! ```
//!
//! Ex his, vos can animadverto is qui primo argumentum de forma filum.Requiritur autem factum est per filum compiler hanc esse litteram;et non erit variabilis in Transierunt (ut praestare valet reprehendo).
//! Parse compilator erit utrum forma nervo dummodo idonea ad hunc numerum rationes format filum.
//!
//! Unum valorem convertere ad filum, uti [`to_string`] modum.Hoc formatting mos utor [`Display`] trait.
//!
//! ## ambitum secundum situm
//!
//! Quisque formatting argumentum conceditur quod ad valorem ratio specificare indiciunt suus: et si ea omissa sit ponere "the next argument".
//! Nam forma ligamen capiebatque tria `{} {} {}` parametri et eodem ordine se formatae Dantur.
//! Format de filum `{2} {1} {0}` vero converso ordine essent rationes format.
//!
//! Rerum can adepto paulo quondam vos satus inde perflatus ancipiti captioni isse obviam in duo genera, species secundum situm.Species cogitari potest iterator "next argument" est ut in argumentum.
//! Quisque enim tunc "next argument" specie videri, quod advances iterator.Moribus hic perducit;
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iterator internum per non est ratio quae ex tempore `{}` esse videtur primum, ut prima ratio procer.Tum iterum `{}` attingens et iterator profecta ad secundam rationem.
//! Per se, Opsum expressis esset vocabulum afficit rationem non Opsum dolor tu honorificentia nominandus famulus rationem termini secundum situm in species.
//!
//! A format filum opus est uti omnes eius rationes, aliter est, tunc compile errore.Vos may refer to the same ratio magis quam semel in format filum.
//!
//! ## named parametri
//!
//! Rust de se non habet, sicut equivalent de Python nomine parametri ad munus, sed tortor [`format!`] est extensio Syntax concedit, quae ad ambitum nomine leverage.
//! Parametris nominatur ratio quae enumerantur in finem album et syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Nam exemplum hoc [`format!`] nomine dicta omnis ratio usus:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Non valet, situm ad induendum Simulacri parametris (videlicet nomina eorum absque) argumentis, quorum nomina post.Situm et quasi Maecenas lacus pede, non sit verum in forma insolita Opsum dolor nomine providere linea.
//!
//! # Figuram posuere tristique
//!
//! Formatae esse oporteat formatting transfigurari potest pluribus ambitum (in [the syntax](#syntax)) `format_spec` secundum. Quae res quid repraesentatio formatae parametri chordae pertinent.
//!
//! ## Width
//!
//! ```
//! // Omnes hi "Hello x !" Print
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Quod forma sit "minimum width" ad parametrum tolleret.
//! Si non filum in valore huius multa sunt characters imple, et tunc ex fill/alignment color certa esse non requiratur ad sursum in spatio (vide infra).
//!
//! Width ad valorem et quoque provisum est, ut sit in [`usize`] album of Maecenas lacus pede a enim postfix `$` addit, testimonium ut secunda ratio est [`usize`] requirentis mensuram latitudinis templi.
//!
//! Ad rationem non mutat syntaxis "next argument" pupa in calculo et rationibus solet utilem ad loci nomen esse aut.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Plerumque satiatus morum disciplinæ dam provisum adiunctis [`width`](#width) modularis.Sic esse definiendum ante `width`, ius post `:`.
//! Ad valorem quae formatae esse hanc indicat, si minor sit extra `width` aliqui characteres et typis circuitu ejus.
//! Replens venit in sequentibus alte cadere est et noctis;
//!
//! * `[fill]<` - egressus est ratio est, columnas varius in `width`
//! * `[fill]^` - et ratio est, centrum varius `width` in columnas
//! * `[fill]>` - varius, apud `width` ratio est recta super columnas
//!
//! Quod per default [fill/alignment](#fillalignment) Numerics non est spatium-et left-varius.Quod per default formatters ordo numerorum et spatium iustum, sed mores Gratia diei et noctis.
//! Si laxa `0` (vide infra) Numerics specificatum est et saturati implicitum `0` mores.
//!
//! Gratia diei et noctis non erit implemented Nota quod per quosdam speciesque referebant.Et maxime: nam non est plerumque implemented `Debug` trait.
//! Nullam A bonus via ut applicari hoc est initus format tuo: unde ergo huic codex filum output adipisci;
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Salve Some("hi")
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Haec sunt vexilla omnia ad formatter mutare mores.
//!
//! * `+` - Hoc signum ostendit intentum semper imprimi genera numerorum.Signa nunquam defectum Typis et sumptibus annum in modo negativo `Signed` trait.
//! Haec indicat vexillum rectam signum (seu `+` `-`) typis debet esse semper.
//! * `-` - Currently not used
//! * `#` - Haec indicat vexillum "alternate" quod forma debet esse printing.Alternis sint;
//!     * `#?` - pulchra forma [`Debug`] imprimendi concessis,
//!     * `#x` - et ratio praecedat `0x`
//!     * `#X` - et ratio praecedat `0x`
//!     * `#b` - cum ratio prior est `0b`
//!     * `#o` - et ratio praecedat `0o`
//! * `0` - Nullam enim ponitur id quod est forma Integer `width` utrumque fieri potest etiam per rationem signi `0` conscius.
//! Format enim `00000001` Integer `1` cederet `{:08}` ut dum ad integrum eadem forma `-0000001` `-1` cederet.
//! Notitia negans version est quod nullus est paucioribus quam positivum version.
//!         Nullam semper cyphris signum notatu postponitur (if any) antequam constet.Uti cum una `#` apud vexillum, vir similis erit dicendum: zeros Nullam sed ante inseruntur cum praepositione numeri.
//!         Solon dixit se senem summa est includitur in latitudine.
//!
//! ## Precision
//!
//! Nam non-ordo numerorum generibus hic "maximum width" enim potest considerari.
//! Latitudo linea longior est si ex tunc descenderunt multi characteribus et dimidiato emittitur valorem proprium `fill` mutilum, si `alignment` `width` parametri et positi sunt.
//!
//! Nam integralis types, id est praetermittenda sunt.
//!
//! Nam iam pendebat, types, quot numeri indicat quod potest typis post punctum relinqui debet.
//!
//! Sunt tres vias fieri potest dare `precision` desideravit:
//!
//! 1. Integrum `.N`:
//!
//!    in ipsa enim adipiscing integer `N` textuum servent.
//!
//! 2. Per nomen et signum `.N$` pupa integrum;
//!
//!    * *`N` forma usus argumentum (quae debet esse `usize`) cum praecisione.
//!
//! 3. Asterisco `.*`:
//!
//!    `.*` `{...}` hoc modo invenitur in forma initibus exitibusque * * magis quam duo: primo initus `usize` tenet omnino, quod est secundum valorem tenet figuras.
//!    Nota est in hac re si quis utitur ad `{<arg>:<spec>.*}` format filum, tunc `<arg>` partem pretii** refertur ad ea typis imprimi, et venient in initus est `precision` preceding `<arg>`.
//!
//! Eg vocat omnia haec ad eandem rem `Hello x is 0.01000` imprimendi concessis,
//!
//! ```
//! // Salve {arg 0 ("x")} est {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Salve {arg 1 ("x")} est {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Salve {arg 0 ("x")} est {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Salve {next arg ("x")} est {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Salve {next arg ("x")} est {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Salve {next arg ("x")} est {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Dum haec
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! Tres figuras significantly diversis rerum,
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Aliquam libero in aliquid, ex mores filum positum in munera formatting scriptor operating ratio Joomla.
//! Provisum est per Rust format munera et vexillum locus et bibliotheca non est producendum aliquem conceptum de omni motu perspicuum idem praecessi regardless of user configuratione.
//!
//! Nam hoc codice semper figuras decimales separator `1.5` etsi systema utitur locus quam aliis dat.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Et litteris comprehensa `}` `{` litteralis et cum eodem filo procedendo.Nam et `}` `{` mores moribus evasit `{{` `}}` effugit.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Summatim, hic autem vobis invenire plenam grammatica forma trahunt.
//! Syntax formatting de verbis usus est; tum ex aliis linguis, ita etiam debet esse aliena.Quae formatae sunt ex argumentis, quasi Syntax Python, ad designandum quod cincta sunt rationes ad C, ut pro `{}` `%`.
//! In ipsa grammatica Syntax pro formatting est;
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! In grammatica supra, `text` non continent, aut nihil `'{'` `'}'` ingenia.
//!
//! # Figuram traits
//!
//! Cum id petentibus, maxime cum et ratio est quae formatae sint generis, quae quidem non petentes, assignat rationem certo trait.
//! Haec ipsa concedit multa quae formatae sint ut generum `{:x}` via (ut tum [`i8`] [`isize`]).Vena est typus ut Dei tabularum faciendarum traits est:
//!
//! * *Nihil* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` Ex minoribus habet veste hexadecimali ostendentur integri ⇒ [`Debug`]
//! * `X?` ⇒ [`Debug`]-causa superius per numeros integros veste hexadecimali ostendentur
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Hic modo quod quid est, quod quisquam rationem ratio esse ad effectum adducit [`fmt::Binary`][`Binary`] trait quae formatae sunt et non `{:b}`.Implementations sunt, provisum est traits sunt in bibliothecam vexillum numerus per typos primitivos sicut bene.
//!
//! Quod si nulla forma sit specified (`{}` sive ut in `{:6}`), tum forma usus sit trait [`Display`] trait.
//!
//! Cum in effectum ducenda trait forma propter propriam rationem, et effectum deducendi ad modum et a signature:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // more generis nostri,
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Transierunt tuum type sicut `self` by-reference voluntas tua, ut mittere output function et tunc in `f.buf` amnis.Hoc autem est forma unicuique implementation trait sunt antecedenti adhærentium continenter postulavit formatting bene parametri.
//! Determinatis hoc pacto valoribus haec parametri sunt: et erit enumerantur ad agros [`Formatter`] instrúite.In ut auxilium hoc, ab aliquo [`Formatter`] adiutorium praebet et artem efficere modi.
//!
//! Accedit de valore huius reditus munus est [`fmt::Result`] alias genus de quo est [`Result`]`<(): [`std::::fmt Error`] '>:.
//! Non propagetur; ut implementations Formatting ut a risu digna [`Formatter`] (eg, quod vocant [`write!`]).
//! Sed si illi errores spuriously redire nunquam.
//! Id est ut non reverteretur a formatting actio est ac si Transierunt error-in errorem [`Formatter`] refert.
//! Hoc est quia, quod contra id munus esset signature suadeant, filum forma est operatio omnino falli nesciam.
//! Hæc scribo, quia munus effectus est in tantum referat quae illis subiacent, ut amnis deficient, et providere est via in errorem inciderunt, ut mens ad hoc quod tergum sursum ACERVUS.
//!
//! Ut tamquam ad effectum deducendi praecepta traits formatting An example:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Et vasa ad valorem `f` `Write` trait, quae est quod scribam?tortor exspectat.
//!         // Nota, quod iste ignorat varii vexillum forma est forma provisum trahunt.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Permittit alium traits sunt voces quae Episcopos a output type.
//! // Quod haec significatio est forma vector de magnitudine imprimendi.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Patere formatting carecto per auxilium in modum `pad_integral` Formatter est.
//!         // Ecce modum documenta enim singula et ad munus `pad` posse codex trahunt.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` nos `fmt::Debug`
//!
//! Haec formatting traits habeat duos proposita distincta;
//!
//! - [`fmt::Display`][`Display`] asserentes implementations UTF-8 filum oblata sit generis fideliter semper.** ** existimabant dispositis omnis generis tormentis non est [`Display`] trait ad effectum deducendi.
//! - [`fmt::Debug`][`Debug`] ** ** omnes publicas rationes implementations debet amet enim.
//!   Output typically autem fideliter repraesentabant cultum internum in civitate fieri.
//!   Ex facilitate debugging ad [`Debug`] trait Rust codice est.In pluribus, uti `#[derive(Debug)]` sat est commendare.
//!
//! Quaedam exempla de output traits ab utroque;
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Related Oppugnatio
//!
//! Illic es unitas ad numerum related [`format!`] familia.Ones es implemented currently sunt,
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Et hic [`writeln!`] sint duo, quae sunt unitas certa est, ut emittat in format filum amnis.Hoc prouinciis referentibus ad medium format ne pro cymbalis bene scribere directe ad output.
//! Sub cucullo, hoc munus proprium hominis actualiter in Deum inuocans [`write_fmt`] munus [`std::io::Write`] trait defined.
//! Exemplum usus est:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Et hoc est quod [`println!`] edere output stdout.Similiter ad [`write!`] Macro medius terminus de prouinciis cum unitas vitatis excudendi output.Exemplum usus est:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Et in [`eprint!`] [`eprintln!`] Oppugnatio egiptiam [`print!`] [`println!`] et respective ad output edere stderr nisi.
//!
//! ### `format_args!`
//!
//! Curiosa est circa tuto ad umbrosum tortor describit linea format.Hoc non eget object aliqua congeries prouinciis referentibus ad partum, et tantum informationem references in ACERVUS.
//! Sub cucullo, qui omnes ad implemented macros in related terms sunt.
//! Primum, quod usus alicuius exempli gratia,
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Et propter [`format_args!`] qui macro est de valore [`fmt::Arguments`] genus.
//! Hoc ergo potest esse structuram [`format`] Transierunt et munera ad [`write`] interius format filum ad cuius moduli rationem in ordine ad aliquid.
//! Et finis est huius vel tortor ne ultra medium prouinciis referentibus agens formatting trahunt.
//!
//! Exempli gratia, a Explotación bibliotheca uti vexillum formatting Syntax posset, nisi esset intrinsecus admovendus transiet circa structuram ad hoc absurdum visum est, ut ad ubi output.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Et `format` munus accipit [`Arguments`] et instruere, et inde refert filum Formatted.
///
///
/// Quod exempli gratia [`Arguments`] creatus possit cum [`format_args!`] tortor.
///
/// # Examples
///
/// Basic usus:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Placere note quod usura [`format!`] potior esset.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}