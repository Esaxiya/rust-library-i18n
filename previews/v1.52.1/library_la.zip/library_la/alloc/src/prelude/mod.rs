//! Et alloe Prelude
//!
//! Ad sublevare cuius moduli rationem importat de communiter usus est in addere items in a glob `alloc` crate import a summo usque ad modules:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;