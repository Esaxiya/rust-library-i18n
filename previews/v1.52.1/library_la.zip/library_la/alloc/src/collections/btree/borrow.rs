use core::marker::PhantomData;
use core::ptr::NonNull;

/// Exempla monstrabit autem reborrow de quibusdam unique referat quando scitis quod reborrow, et omnibus posteris (id est, universa indicatores,&indiciorum ex hoc) non esse ultra procul aliquo puncto, post quem vos volo utor originale unique referat iterum .
///
///
/// Haec fere tractantem motionem Sedatus ex mutuo detrahebant tibi sed quod istud imperium manat stacking compilator nimis intricata sunt secuti.
/// Non concedit `DormantMutRef` A reprehendo in ipsum mutuo petendo, cum adhuc expressing comprehenderit acervos ejus natura est, et unicus qui rudis regula codice ad hoc opus mores sine Proin enim.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// A unique capere horum mutuo postularit et reborrow eam protinus.
    /// Adiecta est, vivat secundum nova vita originali secundum idem, sed uti promise breviore percurrant.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // Salutem in tenemus postulet a per `_marker` et redarguite
        // respectum solum ita singularis.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Horum mutuo postularit ad dominum unique initio capi.
    ///
    /// # Safety
    ///
    /// Quod est reborrow enim finivit, id est, rediit a referat `new` et universa indicatores,&indiciorum ex illo, est non amplius esse.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // Salutem nostram salutem pertinent conditionem referendum est hoc singulare.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;