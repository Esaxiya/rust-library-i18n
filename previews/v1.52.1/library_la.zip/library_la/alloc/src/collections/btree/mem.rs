use core::intrinsics;
use core::mem;
use core::ptr;

/// Hoc locum tenet valorem post `v` vocant a unique referat ad munus pertinet.
///
///
/// Si occurrat panic `change` claudetur omnis processus Fetus.
#[allow(dead_code)] // custodi ut exemplo et usu future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Hoc valore notificata locum tenet post `v` reference a unique quod vocant munus pertinet, et per viam refert ad exitum adeptus.
///
///
/// Si occurrat panic `change` claudetur omnis processus Fetus.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}