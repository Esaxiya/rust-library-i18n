use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Tenet aliam immutabilis nituerunt instar.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Marginibus foliorum aliud invenit arborem delimiting certum rhoncus.
    /// Aut redire aut par pari aliud tractat eandem vacantem arbore bene.
    ///
    /// # Safety
    ///
    /// Nisi `BorrowType` est `Immut`, non uti aures duplicata visitare KV bis idem.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Equivalent ad `(root1.first_leaf_edge(), sed magis root2.last_leaf_edge())` efficient.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Invenit par folium arboris in a range marginibus delimiting est specifica.
    ///
    /// In tantum eventum suum habebit sensum clavis in ligno voluntatis ordinatur, ut ligni in `BTreeMap` sit.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Utilitatibus consulens generis horum mutuo postulaverit nostri mutabilis est.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Par foliorum marginibus delimiting invenit totam arborem.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Quantum in marginibus foliorum delimiting unicum par scindit certum rhoncus.
    /// - Effectus sunt non permittens unique references (some) mutationem, qui debet esse diligenter.
    ///
    /// In tantum eventum suum habebit sensum clavis in ligno voluntatis ordinatur, ut ligni in `BTreeMap` sit.
    ///
    ///
    /// # Safety
    /// Atqui idem K. aures ne ad alterum.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// A unique referat bipartito finditur in marginibus delimiting par folium arboris in a plenus range.
    /// Eventus unique es non-references mutationem permittens (nisi ex values), sic cum curae esse debent.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Duplicare NodeRef hic radix Nos-idem K. numquam visitare bis silicem, egressæ sunt imbricatis nusquam terminus sursum valorem v.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// A unique referat bipartito finditur in marginibus delimiting par folium arboris in a plenus range.
    /// Eventus autem non unique-references massively perniciosius mutationem patitur, ita utendum est quam diligentissime.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Nos duplicare hic radix NodeRef-neque enim est accedere in quam viam nactus overlaps references ex radix.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Folium ansam dedit edge revertitur contra ansam [`Result::Ok`] KV dextris proximam, sive in eodem folio nodum nodus antecessoris.
    ///
    /// Si autem novissimis folium edge unum in arbore, est radix node [`Result::Err`] refert.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Datum folium edge capulum rediit finitimos ansam [`Result::Ok`] KV ad sinistram, sive eiusdem sive foliis nodum nodus antecessoris.
    ///
    /// Si folium de arbore edge est primum, refert [`Result::Err`] cum nodi radix.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Internum ansam dedit edge redit cum manubrio [`Result::Ok`] KV proximis hinc, sive in eodem nodo antecessoris node interius.
    ///
    /// Si edge internum enim est ultimum in unum lignum, cum radix nodi [`Result::Err`] refert.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Folium arboris posita edge manubrio infixum in moriens, tunc refert folium edge in dextera parte, et inter par value-key, quod in eadem folium aut nodi in nodi alicuius antecessoris, vel nullus foret.
    ///
    ///
    /// Pertingit etiam deallocates node(s) fine ulla methodo.
    /// Si key Ex hiis insinuatur quod ultra valorem-existit par et totum residuum de ligno autem deallocated sunt, et nihil est in reditu.
    ///
    /// # Safety
    /// Quod non est datum edge quomodo reputati sunt in `deallocating_next_back` ante redierat.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Datum et folium arboris mori edge in manubrio, tunc refert folium edge a sinistra parte, et inter par value-key, quod in eadem folium aut nodi in nodi alicuius antecessoris, vel nullus foret.
    ///
    ///
    /// Pertingit etiam deallocates node(s) fine ulla methodo.
    /// Si key Ex hiis insinuatur quod ultra valorem-existit par et totum residuum de ligno autem deallocated sunt, et nihil est in reditu.
    ///
    /// # Safety
    /// Et datum est edge non fuisse antea `deallocating_next` quomodo reputati sunt iuxta rediit.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Deallocates lignorum Nodorum à folium ad radix.
    /// Hoc modo et arbor `deallocating_next` deallocate reliquum fuerit et tacito utrimque `deallocating_next_back` ligno edge ipsum tetigerunt.
    /// Sicut dictum est solum in animo, cum omnia dicta sunt claves and values rediit, nulla tersus est de quolibet aut claves values.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Folium edge movet auricula usque ad proximum: et folium edge redit quae ad valorem inter clavis.
    ///
    ///
    /// # Safety
    /// Iter versus KV sit alia.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Folium caudam movet edge ad proximam clavem: et folium edge quae ad valorem inter redit.
    ///
    ///
    /// # Safety
    /// Iter versus KV sit alia.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Folium edge movet auricula usque ad proximum: et folium edge redit quae ad valorem inter clavis.
    ///
    ///
    /// # Safety
    /// Iter versus KV sit alia.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Hoc enim faciens tandem citius, ex benchmarks.
        kv.into_kv_valmut()
    }

    /// Cauda movet folium edge ad priorem redit quae ad clavis et folium inter valorem.
    ///
    ///
    /// # Safety
    /// Iter versus KV sit alia.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Hoc enim faciens tandem citius, ex benchmarks.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Folium edge movet ad auricula usque altera folium edge redit atque valorem inter key, deallocating nodi nullam reliquisset in suo post tergum relicto parente et correspondentes edge nodi pendentia.
    ///
    /// # Safety
    /// - Iter versus KV sit alia.
    /// - K. Quod ante non redierat ab reputati `next_back_unchecked` in exemplum omnis ligni ab auriculis ad Libyae lustrare.
    ///
    /// Auris updated sola tuta comparare procedere, iaciant vocate ad eundem modum ea salute et incolumitate status subiecti `next_back_unchecked` instar vocant.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Et folium caudam movet edge ad proximam folium edge redit atque valorem inter key, deallocating nodi nullam reliquit post tergum manente in suo parente in correspondentes edge nodi pendentia.
    ///
    /// # Safety
    /// - Iter versus KV sit alia.
    /// - Quod folium edge non fuit ante redit instar `next_unchecked` in exemplum omnibus in auriculis usus est etiam transire in ligno.
    ///
    /// Auris incedere updated solum tutum comparare, satis est vocare ad eundem modum ea salute et securitate conditione subiecti `next_unchecked` instar vocant.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Qui redit in leftmost folium edge aut nodi et fossa humo operui: id est, ad navigare, ubi primum progredi edge opus (aut ultimis quando navigando retrorsum.)
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Aut redit rightmost folium edge in nodi substratam, hoc est, quando ultimum quod vos postulo edge ante navigium (vel ubi primum navigandi retrorsum).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Visitationibus interior nodos folia KVS ascendendi in clavibus et salutationes in altitudinem internam nodis totam primam, scilicet interiorem hominem KVS et praecedere puerum nodorum lymphaticorum.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Calculates numerus in elementis (sub) arbore.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Redit ad medium folium edge navigationem KV ad proximum.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Cum redeunt ad proxime folium edge KV est retrorsum navigation.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}