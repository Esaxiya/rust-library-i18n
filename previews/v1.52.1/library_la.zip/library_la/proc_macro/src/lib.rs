//! A auxilio cum bibliotheca enim tortor auctores nova unitas definiens.
//!
//! Haec bibliotheca, provisum est a vexillum distribution, providet autem exercitii varietates tendebant interfaces procedurally defined tortor consumantur cadavera patrum in definitionibus, sicut unitas `#[proc_macro]` munus ut, tortor ac attributa `#[proc_macro_attribute]` trahunt attributes`#consuetudo [proc_macro_derive]`.
//!
//!
//! Ecce enim [the book] magis.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Num decernit proc_macro est factum intellegibile progressio est currently currit.
///
/// Et proc_macro crate tantum animo intus ad usu exsecutionem unitas quae ad rationem procedendi.Munera crate panic si omnes in invocantis de foris processualis praescriptum a tortor, vel unitas test aut Ordinarius ut a scriptor constructum Rust binarii.
///
/// Nam quae ordinantur ad considerationem libraries Cum Rust uictum et tortor tortor non-usum casibus `proc_macro::is_available()` praebet ut deprehendere non-TREPIDANS infrastructure postulo utor an API proc_macro est available statim receptum est.
/// Intus redeat si procedendi invocantis de Macro falsum appellari binarii ab alio.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Et principalis huius generis provisum est a crate est, ac repraesentabat abstracte ab tokens amnis, aut, specialius, token ligna eas in sequens quadrichordum.
/// Et in ea generis providere interfaces iterando token ligna quoniam et e contrario, qui sunt in colligendis multis arboribus token amnis.
///
///
/// Hoc et tum ad input et output `#[proc_macro]`, et `#[proc_macro_attribute]` `#[proc_macro_derive]` definitiones.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Error redierat ab `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Qua nihil inane `TokenStream` token arboribus redeunt.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Suspendisse nisi `TokenStream` vacat.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Et conteram in tokens et parse conatus filum his in tokens token amnis.
/// Et deficere possunt a multis de causis, exempli gratia, si filum contineat vel characteres delimiters non libratae sunt, non in lingua.
///
/// All palmis `Span::call_site()` ut tokens in parsed amnis.
///
/// NOTE: quidam errores panics faciam loco `LexError` reverti.Mutantur reservat ius in nos errores: deinde LexError`s.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// AB, ponte praebet `to_string` tantum, `fmt::Display` effectum deducendi secundum illud (inter duos contrarios solito necessitudinem).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Ut per fluvium vestigia filo token losslessly putatur converti in eodem flumine token (modulo palmis): nisi forte cum TokenTree::Group`s `Delimiter::None` delimiters numerum literals negativa.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Maps token quoniam debugging in forma convenient.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// A quibus token amnis token gignit unum lignum.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// In plures arbores dumtaxat token colligit.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// A "flattening" fluminum operationem in token, collects token arboribus ab uno in plures token fluunt impetu amnis.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Uti est optimized implementation if/when potest.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Publica enim `TokenStream` implementation singula type sicut iterators.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// An iterator: per'sTokenStream`TokenTree`s.
    /// Et iteration "shallow" est, eg, per iterator recurse non terminatur in coetus et coetus redit tota sicut token ligna.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` accipit arbitrariam tokens dilatatur et in describendis `TokenStream` input.
/// Exempli gratia `quote!(a + b)`: producam ergo expressio, qui, cum expenduntur, `TokenStream` `[Ident("a") fabricare, Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting `$` fit per omnia secundum unam tollendo ident unquoted ad terminum.
/// Loca adducere prolixum se `$` utere `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Source codice A regione, Macrone per expansion notitia.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Nova gignit `Diagnostic` cum `message` ad dedit spatium `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// A ad spatium definitionem macronum, qui proposito concepto site.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// De spatio utilitatem eorum qui current quae ad rationem procedendi tortor.
    /// Identifiers spatium ut creatus huic certus non quasi directe scripta sunt in tortor in loco vocationem (vocatio-MUNDITIA situ) et in alio codice tortor locum non posse vocationem etiam pertinet ad eos.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Spatium `macro_rules` sunt ei adjunctæ, sanitas, educatio et numquam proponit per definitionem macronum situ (variables loci, pittacia, `$crate`) et in tortor interdum ad locum voca (caeteris paribus).
    ///
    /// Spatio loco in locum, qui ex vocationem.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Original file fonte et in hoc spatio quo puncta.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Dilatatio enim tortor tokens `Span` in priore ex quo generatur `self` si.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Quod spatium `self` enim originis fons, qui fuit generatae ex codice.
    /// Hoc igitur `Span` non generantur ex tortor expansiones `*self` reditum idem.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Incipiens line/column fons est, in hoc enim spatium accipit lima.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Accipit prope iam amentie suspectus line/column file fontem in hoc spatium.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Nova spatium comprehendens complexum `self` `other` et gignit.
    ///
    /// Si autem `other` `self` `None` redit atque ex diversis patuit.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Cum idem spatium novam gignit line/column `self` notitia pro signo proposito concepto, sed qui tanquam in `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Animi habitu novo creat cognomines palmi `self` sed line/column `other` indicium.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Comparat si haerent aequalis palmis.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Post spatium illud fons refert.
    /// Haec fontem retinet originale codice, et spatia inter comment.
    /// Si eventus non tantum referat ad verum correspondet spatio source codice.
    ///
    /// Note: Observabilis tokens tantum confidunt in effectus sit a tortor nec in hoc textu fons.
    ///
    /// Effectus conatus ad hoc munus optimum est diagnostic adhiberi tantum.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Prints spatium per debugging in forma convenient.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Linea initium vel finis, agmen duo `Span` repraesentans.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// I-in linea iudex ad fontem file animi seu ultimum in quod span (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Columnae iudex 0 A-(in UTF-8 characters) in qua source file nec spatium animi terminos (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Et dedit `Span` a fonte lima.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Gets semita ut lima est fons.
    ///
    /// ### Note
    /// Si codice spatium `SourceFile` consociata cum hoc erat per aliquod agens extrinsecum generatae tortor, id tortor, hoc non potest esse in re viam filesystem.
    /// [`is_real`] uti reprehendo.
    ///
    /// `is_real` refert Item nota quod si `true` si `--remap-path-prefix` imperio lata est, in linea data, ut semita quod actu non sit verum.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Refert `true` si hoc est verum lima fonte source file: nec generatur ab externa est expansion tortor.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Hoc saginantur intercrate ad palmos habere potest non implemented et verus fons generatae in externa palmorum existere files est unitas.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// A una serie token ligna token vel definitive (eg, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// A flumine token bracket delimiters circumdatum.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Et identifier.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// A distinctio unius ingenii (+ '': `,`, `$`, etc.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Materiale (`'a'`) rationem Salve (`"hello"`) numero (`2.3`) c
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Redit lignum in hoc spatium, delegante ad `span` modum terminata est continebat token aut amnis.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// * * token hoc solum conformat ad spatium.
    ///
    /// Si ergo haec quae nota token est `Group` hunc modum, non erit ad configurare rationi spatium se ad internum tokens, solum hoc delegare ut `set_span` modum inter se variant.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Maps token debugging arbor in forma accommodata.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ex his quisque habeat nomen in instrúite type Integrum est in lusione cum derived, et cave ne pugnes contra cum an susicivus layer ex indirection
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// AB, ponte praebet `to_string` tantum, `fmt::Display` effectum deducendi secundum illud (inter duos contrarios solito necessitudinem).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Per lignum filo vestigia token losslessly conuertitur in idem putatur token ligno (palmis modulo): nisi forte::TokenTree Group`s `Delimiter::None` delimiters cum numerica literals negativa.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// A definitur token amnis.
///
/// In quo circumdatur: Delimiter`s `TokenStream` `Group` intus contineat.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Describitur quomodo token eas in sequens quadrichordum quod ligna terminatae.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Delimiter implicatum, quod possunt, eg, et apparent circum tokens ex "macro variable" `$var`.
    /// Serva Aliquam sit amet operator est qualis ordo in casibus in quibus `$var * 3` `$var` `1 + 2` est.
    /// Implicatos, a roundtrip delimiters non superesse token amnis per filum.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Nova gignit `Group` de datis et delimiter token amnis.
    ///
    /// Hoc autem conditor non posuit spatium huius coetus ad `Span::call_site()`.
    /// Ut autem spatio mutantur `set_span` vos can utor infra modum.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Delimiter refert ad hoc `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Et redit in `TokenStream` tokens sunt in hoc terminata `Group`.
    ///
    /// Nota token amnis reddidit, ut non includere delimiter supra rediit.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Redit ad Chinese spatium token hoc flumine `Group` pugillare totum.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Refert ad foramen spatium qed PROPOSITIO delimiter de hoc coetus.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// De redit spatium claudunt delimiter arte conexa perhibent de hoc coetus.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Hoc est delimiters `Group` conformat spatio, non autem internum ejus tokens.
    ///
    /// Haec methodus non ** ** tokens mensa posuit spatium internum ab istis omnibus, sed in eam tantum spatium ad gradum delimiter tokens `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// AB, ponte praebet `to_string` tantum, `fmt::Display` effectum deducendi secundum illud (inter duos contrarios solito necessitudinem).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tanquam filo vestigia coetus losslessly convertibilia esse in eodem genere (modulo palmis): nisi forte cum `Delimiter::None` delimiters Group`s TokenTree::.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// An `Punct` est distinctio unius `+` sicut character, vel `-` `#`.
///
/// Multi-operators mores `+=` quorum persona dicitur quasi per diversas formas `Punct` duo exempla ex `Spacing` rediit.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// An statim `Punct` token vel alio alius whitespace `Punct` ambulaverunt.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// eg, `+` est in `Alone` `+ =`, aut `+ident` `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// eg, `+` est in `Joint` `+=` aut `'#`.
    /// Praeterea una cum identifiers quote `'` iungere potest esse forma `'ident` diebus.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Spatio dato `Punct` creat novum moribus.
    /// `ch` argumentum quod debet esse validum licet character distinctio in verbis, aliud autem est munus panic.
    ///
    /// Et rediit `Punct` erit amplius unam figuram potest quod per default spatium `Span::call_site()` `set_span` per modum inferius.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Huius ingenium est distinctio `char` refert ad valorem.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Redibit spacing haec distinctio ratione declaratur, utrum eam subinde alia `Punct` in token fluminis possunt potentia compositae ad multi-natura operante (`Joint`) aut eam per aliam token sive whitespace (`Alone`) ita operante certe finita.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Ingenium redit spatium hic distinctio.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Nam distinctio ratione configurare palmi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// AB, ponte praebet `to_string` tantum, `fmt::Display` effectum deducendi secundum illud (inter duos contrarios solito necessitudinem).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Losslessly nullos esse convertibilia interpunctionem filo prout in similibus.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// An identifier (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Dedit novum gignit `Ident` cum `string` tum ex certa `span`.
    /// Quod argumentum `string` identifier debet esse validum licet in linguis (including keywords, eg an `self` `fn`).Alioquin munus erit panic.
    ///
    /// Nota quod `span`, currently in rustc, configurat MUNDITIA De hoc identifier.
    ///
    /// Quia hoc tempus `Span::call_site()` expressis opts, ut "call-site" hygiene significatione quod identifiers creatum hoc spatium non erit certus ac si scripta directe ad locum tortor vocationem et alio codice at tortor vocationem situm esse potest ad ad et as well.
    ///
    ///
    /// `Span::def_site()` optet-in ut patitur te palmorum existere similem deinde valetudinis curandae "definition-site" identifiers creatum, quod est in hoc spatio et certus locus ad definitionem macronum de codice, et alius ad vocationem tortor locum non poterit ad eos.
    ///
    /// Ob hoc MUNDITIA conditor et vena est momenti: dissimilis tokens aliis, exigit ut per certa `Span` in constructione.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Sicut `Ident::new` et gignit et rudis identifier (`r#ident`).
    /// Et ratio `string` esse validum licet in lingua identifier (including keywords, eg `fn`).
    /// Keywords quae adhiberi per viam segments (exempli gratia
    /// `self`, `Super`) non valet autem, panic est et facere.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Hoc spatium `Ident` redit gyro totius chordae [`to_string`](Self::to_string) rediit.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configurat hoc spatium `Ident` possum vel valetudinis curandae context mutantur ejus.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// AB, ponte praebet `to_string` tantum, `fmt::Display` effectum deducendi secundum illud (inter duos contrarios solito necessitudinem).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Nullos fieri Identifier losslessly convertuntur sicut in eodem filo identificador.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Materiale (`"hello"`) linea, byte filum (`b"hello"`), (`'a'`) mores, mores byte (`b'a'`), integra vel cum aut sine numero fluctuetur que ('1`, `1u8`, `2.3`, `2.3f32`).
///
/// Et quasi literals string `true` `false` non sunt hic Ident`s factae sunt.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Integer suffixed nova gignit certa de valore litterae.
        ///
        /// Hoc munus integra erit sicut creare valorem certa `1u32` integri in qua prima pars est integralis token et quoque in fine suffixed.
        /// Negans Literals creata a numero superesse non possunt, vel circum-trinus `TokenStream` in cymbalis bene potest esse in duobus tokens confringetur (positive et proprie `-`).
        ///
        ///
        /// Literals creata est, per modum habent `Span::call_site()` spatium per default, quod potest set per modum `set_span` inferius.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Novam gignit unsuffixed cum certa litterae integer valorem.
        ///
        /// Hoc munus erit creare valorem integro integrum quasi certa `1` in qua prima pars token.
        /// Non est certa in his que token, id est equivalent ad alias antiphonas sicut sunt `Literal::i8_unsuffixed(1)` `Literal::u32_unsuffixed(1)`.
        /// Literals creatum non potest a numeris superesse rountrips negans, vel per `TokenStream` in cymbalis bene potest duobus tokens confringetur (positive et proprie `-`).
        ///
        ///
        /// Literals creata est, per modum habent `Span::call_site()` spatium per default, quod potest set per modum `set_span` inferius.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Novam gignit unsuffixed-punctum fluens propria.
    ///
    /// Hæc conditor `Literal::i8_unsuffixed` similes illis sicut in quo supernatet est scriptor valorem emittitur, sed non protinus ad token que adhibetur, sic concludi potest esse `f64` postea in compiler.
    ///
    /// Literals creatum non potest a numeris superesse rountrips negans, vel per `TokenStream` in cymbalis bene potest duobus tokens confringetur (positive et proprie `-`).
    ///
    /// # Panics
    ///
    /// Supernatet certa ad hoc munus requirit, quod est finitum, aut infinitum est, exempli gratia, si hoc munus erit NaN panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// - Punctum fluens suffixed creates a propria.
    ///
    /// Hoc autem conditor creare valorem proprie sicut `1.0f32` qua precedente certa sit pars que est ex token et `f32` token.
    /// Hoc token semper esse potest, quod in `f32` compiler.
    /// Literals creatum non potest a numeris superesse rountrips negans, vel per `TokenStream` in cymbalis bene potest duobus tokens confringetur (positive et proprie `-`).
    ///
    ///
    /// # Panics
    ///
    /// Supernatet certa ad hoc munus requirit, quod est finitum, aut infinitum est, exempli gratia, si hoc munus erit NaN panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Novam gignit unsuffixed-punctum fluens propria.
    ///
    /// Hæc conditor `Literal::i8_unsuffixed` similes illis sicut in quo supernatet est scriptor valorem emittitur, sed non protinus ad token que adhibetur, sic concludi potest esse `f64` postea in compiler.
    ///
    /// Literals creatum non potest a numeris superesse rountrips negans, vel per `TokenStream` in cymbalis bene potest duobus tokens confringetur (positive et proprie `-`).
    ///
    /// # Panics
    ///
    /// Supernatet certa ad hoc munus requirit, quod est finitum, aut infinitum est, exempli gratia, si hoc munus erit NaN panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// - Punctum fluens suffixed creates a propria.
    ///
    /// Hoc simile `1.0f64` litteralem ubi conditor erit creare valorem preceding certa sit pars que est ex token et `f64` token.
    /// Hoc token semper fieri potest, quod in `f64` compiler.
    /// Literals creatum non potest a numeris superesse rountrips negans, vel per `TokenStream` in cymbalis bene potest duobus tokens confringetur (positive et proprie `-`).
    ///
    ///
    /// # Panics
    ///
    /// Supernatet certa ad hoc munus requirit, quod est finitum, aut infinitum est, exempli gratia, si hoc munus erit NaN panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Filum propria.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Character proprie.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte filum propria.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Refert spatium ad hanc novam ambientes propria.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configurat spatium consociata huius litterae.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Refert ad `Span` hoc est `self.span()` restant adhuc de quibus modo fons bytes `range` in range.
    /// Refert `None`, si esset spatium et ornaverunt est extra fines `self`.
    ///
    // FIXME(SergioBenitez): reprehendo quod byte UTF-8 rhoncus sit terminus a quo incipit et desinit.
    // aliud: per panic suus 'verisimile quod non alibi fieri fons, cum textu typis est.
    // FIXME(SergioBenitez): ita ut nulla user est vere scio quod maps est `self.span()`, ut currently hunc modum non solum dicitur esse caeca.
    // Nam `to_string()` indole 'c' "'\u{63}'" redit;non est via cognoscendi de usuario vel fons textus fuit sive fuit sive 'c' '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) aliquid simile `Option::cloned`, sed `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// AB, ponte praebet `to_string` tantum, `fmt::Display` effectum deducendi secundum illud (inter duos contrarios solito necessitudinem).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Velut filo vestigia litterae sit convertibilis in eadem littera losslessly (nam praeter quam fluctuetur rotunditatis literals).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Eorundem domitorem investigavi aditum ad amet purus.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Recuperare variabilis quod amet facere id quod dependet info add.
    /// Ratio compiler Ædificate ergo humanae erit scitis quod in accessed cum compilation variabilis, et possit cum rerun in extructione mutat valorem variabilis illius.
    ///
    /// Praeter sequi munus esse dependentia a Sacra bibliotheca `env::var` aequiparantur, nisi UTF-8 dicendum.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}