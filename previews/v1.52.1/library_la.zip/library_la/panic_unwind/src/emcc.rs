//! Quia emscripten rudentis explicatio * * scopum.
//!
//! Solito cum Rust scriptor rudentis explicatio ad Unix implementation platforms vocat in libunwind APIs directe in loco Emscripten nos vocant ad C++ unwinding APIs.
//! Hoc est quia Emscripten in runtime expedience et semper ad effectum deducendi his APIs et non libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Hoc aequet layout de std::type_info ++ in C
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Et hie quidem magica ducens `\x01` byte LLVM est in signo * * adhibere, non sicut alia mutilati et `_` mores praepositam.
    //
    //
    // Hoc est symbolum adhiberi vtable C++ per's `std::type_info`.
    // `std::type_info` obiecti est genus, generis descriptors, in regula ad hanc mensam.
    // Type descriptors sunt referenced C++ ad EH defined opera constitue super nos, et infra.
    //
    // Nota autem, quod magnitudo est maior quam III usize realis, sed tantum opus nostrum vtable ad punctum in tertio elementum.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info in genere rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Fore ut Northmanni uti .as_ptr().add(2) sed hoc non operatur in context Const.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Intentionally non uti normalis hoc nomen res, quod mutilati non vis ad producendum vel potest esse C++ , apprehéndat Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Hoc est quod nostra capere potes C codice++ execption std::exception_ptr et apud eum plures temporibus rethrow, fortasse etiam alia in fila telarum.
    //
    //
    caught: AtomicBool,

    // Id quod indiget vita esse bene sequitur C++ Semántica nam cum praeter arcam de catch_unwind movet nisi objectum sit valida civitate quia nihilominus tamen ad invocandum __cxa_end_catch destructor.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try hoc nobis opus esse regula.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Cum cleanup() panic non licere, et nos pro modo privata fetu suo.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}