//! Veris Dulcis rudentis explicatio ad panics.
use alloc::boxed::Box;
use core::any::Any;

// Quod enim genus payload engine propagatur per unwinding Veris Dulcis est nobis.
// Oportet monstratorem-sized.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Veris Dulcis provisum extra-incipere munus unwinding.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Et payload vadimus baud prorsus sunt `miri_start_panic` erit ratio ut in nobis `cleanup` inferius.
    // Iustum est ut arca archa eam aliquando, ut aliqua monstratorem-sized.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Ad recuperandam underlying `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}