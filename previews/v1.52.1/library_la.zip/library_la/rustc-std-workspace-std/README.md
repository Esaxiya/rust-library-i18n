# Et `rustc-std-workspace-std` crate

Ecce enim `rustc-std-workspace-core` crate documenta.