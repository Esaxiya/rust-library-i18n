use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // To nie jest stabilna powierzchnia, ale pomaga utrzymać tanią `?` między nimi, nawet jeśli LLVM nie zawsze może teraz z niego skorzystać.
    //
    // (Niestety wynik i opcja są niespójne, więc ControlFlow nie może dopasować obu).

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}