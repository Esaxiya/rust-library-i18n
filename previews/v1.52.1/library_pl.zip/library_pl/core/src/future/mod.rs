#![stable(feature = "futures_api", since = "1.36.0")]

//! Wartości asynchroniczne.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Ten typ jest potrzebny, ponieważ:
///
/// a) Generatory nie mogą implementować `for<'a, 'b> Generator<&'a mut Context<'b>>`, więc musimy przekazać surowy wskaźnik (patrz <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Surowe wskaźniki i `NonNull` nie są `Send` ani `Sync`, więc każdy pojedynczy future non-Send/Sync również byłby, a tego nie chcemy.
///
/// Upraszcza również obniżenie HIR `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Owiń generator w future.
///
/// Ta funkcja zwraca `GenFuture` pod spodem, ale ukrywa go w `impl Trait`, aby zapewnić lepsze komunikaty o błędach (`impl Future` zamiast `GenFuture<[closure.....]>`).
///
// To jest `const`, aby uniknąć dodatkowych błędów po odzyskaniu z `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Opieramy się na fakcie, że async/await futures są nieruchome, aby tworzyć pożyczki odwołujące się do siebie w generatorze bazowym.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // BEZPIECZEŃSTWO: Bezpieczne, ponieważ jesteśmy !Unpin + !Drop, a to tylko projekcja pola.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Wznów generator, zmieniając `&mut Context` w surowy wskaźnik `NonNull`.
            // Obniżenie `.await` bezpiecznie rzuci to z powrotem na `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `cx.0` jest prawidłowym wskaźnikiem
    // który spełnia wszystkie wymagania dotyczące zmiennego odniesienia.
    unsafe { &mut *cx.0.as_ptr().cast() }
}