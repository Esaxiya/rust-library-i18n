#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future reprezentuje obliczenia asynchroniczne.
///
/// future to wartość, która mogła jeszcze nie zakończyć obliczeń.
/// Ten rodzaj "asynchronous value" umożliwia wątkowi kontynuowanie użytecznej pracy podczas oczekiwania na udostępnienie wartości.
///
///
/// # Metoda `poll`
///
/// Podstawowa metoda future, `poll`,*próbuje* zamienić future na wartość końcową.
/// Ta metoda nie blokuje, jeśli wartość nie jest gotowa.
/// Zamiast tego, bieżące zadanie jest zaplanowane do wybudzenia, gdy będzie można zrobić dalsze postępy przez ponowne " sondowanie`.
/// `context` przekazany do metody `poll` może dostarczyć [`Waker`], który jest uchwytem do wybudzania bieżącego zadania.
///
/// Używając future, generalnie nie wywołujesz `poll` bezpośrednio, ale zamiast tego `.await` wartość.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Rodzaj wartości wytworzonej po ukończeniu.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Spróbuj rozwiązać future do wartości końcowej, rejestrując bieżące zadanie do wznowienia, jeśli wartość nie jest jeszcze dostępna.
    ///
    /// # Wartość zwracana
    ///
    /// Ta funkcja zwraca:
    ///
    /// - [`Poll::Pending`] jeśli future nie jest jeszcze gotowy
    /// - [`Poll::Ready(val)`] z wynikiem `val` tego future, jeśli zakończy się pomyślnie.
    ///
    /// Po zakończeniu future klienci nie powinni go ponownie `poll`.
    ///
    /// Kiedy future nie jest jeszcze gotowe, `poll` zwraca `Poll::Pending` i przechowuje klon [`Waker`] skopiowany z bieżącego [`Context`].
    /// Ten [`Waker`] jest następnie budzony, gdy future może zrobić postęp.
    /// Na przykład, future czekający, aż gniazdo stanie się czytelne, wywoła `.clone()` na [`Waker`] i zapisze go.
    /// Gdy gdzie indziej nadejdzie sygnał wskazujący, że gniazdo jest czytelne, wywoływane jest [`Waker::wake`], a zadanie gniazda future zostaje przebudzone.
    /// Po obudzeniu zadania powinno ono ponownie spróbować `poll` future, co może, ale nie musi, dać ostateczną wartość.
    ///
    /// Należy pamiętać, że w przypadku wielu połączeń z `poll` tylko [`Waker`] z [`Context`] przekazany do ostatniego połączenia powinien zostać zaplanowany, aby otrzymać przebudzenie.
    ///
    /// # Charakterystyka czasu działania
    ///
    /// Same Futures są *obojętne*;muszą być *aktywnie* ankietowane, aby osiągnąć postęp, co oznacza, że za każdym razem, gdy bieżące zadanie zostanie pobudzone, powinno aktywnie ponownie wykonać `poll` w oczekiwaniu na futures, którym nadal się interesuje.
    ///
    /// Funkcja `poll` nie jest wywoływana wielokrotnie w ciasnej pętli-zamiast tego powinna być wywoływana tylko wtedy, gdy future wskazuje, że jest gotowa do wykonania postępu (wywołując `wake()`).
    /// Jeśli znasz wywołania systemowe `poll(2)` lub `select(2)` na Unix, warto zauważyć, że futures zazwyczaj *nie* ma te same problemy co "all wakeups must poll all events";są bardziej jak `epoll(4)`.
    ///
    /// Implementacja `poll` powinna dążyć do szybkiego powrotu i nie powinna blokować.Szybki powrót zapobiega niepotrzebnemu zapychaniu wątków lub pętli zdarzeń.
    /// Jeśli wiadomo z wyprzedzeniem, że wywołanie `poll` może zająć trochę czasu, praca powinna zostać przeniesiona do puli wątków (lub czegoś podobnego), aby zapewnić, że `poll` może szybko powrócić.
    ///
    /// # Panics
    ///
    /// Gdy future zakończy się (zwróciło `Ready` z `poll`), ponowne wywołanie metody `poll` może panic, zablokować się na zawsze lub spowodować inne rodzaje problemów;`Future` trait nie stawia żadnych wymagań co do efektów takiego wywołania.
    /// Jednakże, ponieważ metoda `poll` nie jest oznaczona jako `unsafe`, obowiązują zwykłe reguły Rust: wywołania nigdy nie mogą powodować nieokreślonego zachowania (uszkodzenie pamięci, nieprawidłowe użycie funkcji `unsafe` itp.), Niezależnie od stanu future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}