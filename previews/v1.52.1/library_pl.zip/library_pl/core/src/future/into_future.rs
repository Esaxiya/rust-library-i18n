use crate::future::Future;

/// Konwersja do `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Dane wyjściowe, które future wygeneruje po zakończeniu.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// W jaki rodzaj future to zmieniamy?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Tworzy future z wartości.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}