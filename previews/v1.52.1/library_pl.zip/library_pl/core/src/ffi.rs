#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Narzędzia związane z powiązaniami (FFI) interfejsu funkcji obcych.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Odpowiednik typu C `void`, gdy jest używany jako [pointer].
///
/// W istocie `*const c_void` jest odpowiednikiem C `const void*`, a `*mut c_void` jest odpowiednikiem C `void*`.
/// To powiedziawszy, to *nie* to samo, co typ powrotu C `void`, który jest typem `()` Rust.
///
/// Aby modelować wskaźniki do nieprzezroczystych typów w FFI, do czasu ustabilizowania `extern type`, zaleca się użycie opakowania newtype wokół pustej tablicy bajtów.
///
/// Zobacz [Nomicon], aby uzyskać szczegółowe informacje.
///
/// Można by użyć `std::os::raw::c_void`, jeśli chcą obsługiwać stary kompilator Rust aż do 1.1.0.
/// Po Rust 1.30.0 został ponownie wyeksportowany zgodnie z tą definicją.
/// Aby uzyskać więcej informacji, przeczytaj [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, aby LLVM rozpoznawał typ wskaźnika void i przez funkcje rozszerzające, takie jak malloc(), musimy mieć reprezentowany jako i8 * w kodzie bitowym LLVM.
// Zastosowane tutaj wyliczenie zapewnia to i zapobiega niewłaściwemu użyciu typu "raw", mając tylko prywatne warianty.
// Potrzebujemy dwóch wariantów, ponieważ w przeciwnym razie kompilator narzeka na atrybut repr i potrzebujemy co najmniej jednego wariantu, ponieważ w przeciwnym razie wyliczenie byłoby niezamieszkane, a przynajmniej dereferencja takich wskaźników byłaby UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Podstawowa implementacja `va_list`.
// Nazywa się WIP, na razie używam `VaListImpl`.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Niezmienny w stosunku do `'f`, więc każdy obiekt `VaListImpl<'f>` jest powiązany z regionem funkcji, w której jest zdefiniowany
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Implementacja ABI `va_list`.
/// Zobacz [AArch64 Procedure Call Standard], aby uzyskać więcej informacji.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Implementacja ABI `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Implementacja ABI `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Opakowanie dla `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Konwertuj `VaListImpl` na `VaList`, który jest binarnie kompatybilny z `va_list` C.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Konwertuj `VaListImpl` na `VaList`, który jest binarnie kompatybilny z `va_list` C.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait musi być używany w interfejsach publicznych, jednak sam trait nie może być używany poza tym modułem.
// Zezwolenie użytkownikom na zaimplementowanie trait dla nowego typu (pozwalając w ten sposób na użycie funkcji wewnętrznej va_arg w nowym typie) prawdopodobnie spowoduje niezdefiniowane zachowanie.
//
// FIXME(dlrobertson): Aby korzystać z VaArgSafe trait w interfejsie publicznym, ale także mieć pewność, że nie będzie można go używać w innym miejscu, trait musi być publiczny w module prywatnym.
// Po wdrożeniu RFC 2145 należy to poprawić.
//
//
//
//
mod sealed_trait {
    /// Trait, który pozwala na używanie dozwolonych typów z [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Przejdź do następnego argumentu.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Kopiuje `va_list` w bieżącej lokalizacji.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // BEZPIECZEŃSTWO: piszemy do `MaybeUninit`, więc jest on zainicjowany, a `assume_init` jest legalny
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: powinno to wywołać `va_end`, ale nie ma na to prostego sposobu
        // gwarantują, że `drop` zawsze zostanie wbudowany w wywołującego, więc `va_end` zostanie wywołany bezpośrednio z tej samej funkcji, co odpowiadający mu `va_copy`.
        // `man va_end` stwierdza, że C tego wymaga, a LLVM zasadniczo podąża za semantyką C, więc musimy upewnić się, że `va_end` jest zawsze wywoływany z tej samej funkcji co `va_copy`.
        //
        // Po więcej szczegółów, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // To działa na razie, ponieważ `va_end` nie działa na wszystkie obecne cele LLVM.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Zniszcz arglistę `ap` po inicjalizacji za pomocą `va_start` lub `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Kopiuje bieżącą lokalizację arglist `src` do arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Ładuje argument typu `T` z `va_list` `ap` i zwiększa argument, na który wskazuje `ap`.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}