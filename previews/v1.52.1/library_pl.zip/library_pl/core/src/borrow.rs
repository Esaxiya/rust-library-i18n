//! Moduł do pracy z wypożyczonymi danymi.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait do wypożyczania danych.
///
/// W Rust często zapewnia się różne reprezentacje typu dla różnych przypadków użycia.
/// Na przykład miejsce przechowywania i zarządzanie wartością mogą być specjalnie wybrane jako odpowiednie dla konkretnego zastosowania za pomocą typów wskaźników, takich jak [`Box<T>`] lub [`Rc<T>`].
/// Oprócz tych ogólnych opakowań, które mogą być używane z dowolnym typem, niektóre typy zapewniają opcjonalne aspekty zapewniające potencjalnie kosztowną funkcjonalność.
/// Przykładem takiego typu jest [`String`], który dodaje możliwość rozszerzenia łańcucha do podstawowego [`str`].
/// Wymaga to przechowywania dodatkowych informacji niepotrzebnych w przypadku prostego, niezmiennego ciągu.
///
/// Te typy zapewniają dostęp do danych źródłowych za pośrednictwem odwołań do typu tych danych.Mówi się, że są " pożyczone` jako tego typu.
/// Na przykład [`Box<T>`] można wypożyczyć jako `T`, a [`String`] jako `str`.
///
/// Typy wyrażają, że mogą być pożyczane jako jakiś typ `T` poprzez implementację `Borrow<T>`, zapewniając odniesienie do `T` w metodzie [`borrow`] trait.Typ można wypożyczyć jako kilka różnych typów.
/// Jeśli chce zapożyczać zmiennie jako typ-umożliwiając modyfikację danych bazowych, może dodatkowo zaimplementować [`BorrowMut<T>`].
///
/// Ponadto, dostarczając implementacje dla dodatkowych traits, należy rozważyć, czy powinny one zachowywać się identycznie jak te typu bazowego w wyniku działania jako reprezentacja tego typu bazowego.
/// Kod ogólny zazwyczaj używa `Borrow<T>`, gdy opiera się na identycznym zachowaniu tych dodatkowych implementacji trait.
/// Te traits prawdopodobnie pojawią się jako dodatkowe trait bounds.
///
/// W szczególności `Eq`, `Ord` i `Hash` muszą być równoważne dla pożyczonych i posiadanych wartości: `x.borrow() == y.borrow()` powinno dawać taki sam wynik jak `x == y`.
///
/// Jeśli kod ogólny musi tylko działać dla wszystkich typów, które mogą zawierać odniesienie do pokrewnego typu `T`, często lepiej jest użyć [`AsRef<T>`], ponieważ więcej typów może go bezpiecznie zaimplementować.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Jako zbiór danych [`HashMap<K, V>`] jest właścicielem zarówno kluczy, jak i wartości.Jeśli rzeczywiste dane klucza są opakowane w jakiś rodzaj zarządzający, powinno być jednak możliwe wyszukiwanie wartości przy użyciu odniesienia do danych klucza.
/// Na przykład, jeśli klucz jest łańcuchem, prawdopodobnie jest przechowywany z mapą skrótów jako [`String`], podczas gdy wyszukiwanie przy użyciu [`&str`][`str`] powinno być możliwe.
/// Dlatego `insert` musi działać na `String`, podczas gdy `get` musi mieć możliwość korzystania z `&str`.
///
/// Nieco uproszczone, odpowiednie części `HashMap<K, V>` wyglądają następująco:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // pola pominięte
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Cała mapa skrótów jest ogólna dla klucza typu `K`.Ponieważ te klucze są przechowywane z mapą skrótów, ten typ musi być właścicielem danych klucza.
/// Podczas wstawiania pary klucz-wartość mapa otrzymuje taki `K` i musi znaleźć właściwy zasobnik mieszania i sprawdzić, czy klucz jest już obecny na podstawie tego `K`.Dlatego wymaga `K: Hash + Eq`.
///
/// Jednak podczas wyszukiwania wartości na mapie konieczność podania odwołania do `K` jako klucza do wyszukania wymagałaby zawsze utworzenia takiej posiadanej wartości.
/// W przypadku kluczy łańcuchowych oznaczałoby to, że wartość `String` musi zostać utworzona tylko w celu wyszukiwania przypadków, w których dostępny jest tylko `str`.
///
/// Zamiast tego metoda `get` jest ogólna w stosunku do typu podstawowych danych klucza, zwanych `Q` w sygnaturze metody powyżej.Stwierdza, że `K` pożycza jako `Q`, wymagając tego `K: Borrow<Q>`.
/// Wymagając dodatkowo `Q: Hash + Eq`, sygnalizuje wymaganie, że `K` i `Q` mają implementacje `Hash` i `Eq` traits, które dają identyczne wyniki.
///
/// Implementacja `get` polega w szczególności na identycznych implementacjach `Hash` poprzez określenie przedziału mieszania klucza przez wywołanie `Hash::hash` na wartości `Q`, mimo że wstawił klucz na podstawie wartości skrótu obliczonej z wartości `K`.
///
///
/// W rezultacie mapa skrótów jest przerywana, jeśli `K` opakowujący wartość `Q` daje inny hash niż `Q`.Na przykład wyobraź sobie, że masz typ, który zawija ciąg, ale porównuje litery ASCII, ignorując ich wielkość:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Ponieważ dwie równe wartości muszą generować tę samą wartość skrótu, implementacja `Hash` musi również ignorować wielkość liter ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Czy `CaseInsensitiveString` może zaimplementować `Borrow<str>`?Z pewnością może dostarczyć odniesienie do wycinka łańcucha poprzez znajdujący się w nim łańcuch.
/// Ale ponieważ jego implementacja `Hash` różni się, zachowuje się inaczej niż `str` i dlatego w rzeczywistości nie może implementować `Borrow<str>`.
/// Jeśli chce umożliwić innym dostęp do bazowego `str`, może to zrobić za pośrednictwem `AsRef<str>`, który nie ma żadnych dodatkowych wymagań.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Niezmiennie pożycza od posiadanej wartości.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait do wielokrotnego pożyczania danych.
///
/// Jako dodatek do [`Borrow<T>`], ten trait umożliwia typowi pożyczenie jako typ bazowy poprzez zapewnienie zmiennego odniesienia.
/// Aby uzyskać więcej informacji na temat wypożyczania jako innego rodzaju, patrz [`Borrow<T>`].
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Bezsprzecznie pożycza od posiadanej wartości.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}