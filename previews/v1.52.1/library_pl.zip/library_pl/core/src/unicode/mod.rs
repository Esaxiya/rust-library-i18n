#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// Wersja [Unicode](http://www.unicode.org/), na której są oparte części Unicode metod `char` i `str`.
///
/// Nowe wersje Unicode są wydawane regularnie, a następnie wszystkie metody w bibliotece standardowej w zależności od Unicode są aktualizowane.
/// Dlatego zachowanie niektórych metod `char` i `str` oraz wartość tej stałej zmienia się w czasie.
/// To *nie* jest uważane za przełomową zmianę.
///
/// Schemat numerowania wersji jest wyjaśniony w [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Do użytku w liballoc, nie są ponownie eksportowane w libstd.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;