//! Implementacja SipHash.

#![allow(deprecated)] // typy w tym module są przestarzałe

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// Implementacja SipHash 1-3.
///
/// Obecnie jest to domyślna funkcja haszująca używana przez bibliotekę standardową (np. `collections::HashMap` używa jej domyślnie).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// Implementacja SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// Implementacja SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash to funkcja haszująca ogólnego przeznaczenia: działa z dobrą prędkością (konkurencyjna w przypadku Spooky i City) i pozwala na mocne mieszanie _keyed_.
///
/// Pozwala to na kluczowanie tabel skrótów z silnego RNG, takiego jak [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// Chociaż algorytm SipHash jest ogólnie uważany za silny, nie jest przeznaczony do celów kryptograficznych.
/// W związku z tym wszystkie zastosowania kryptograficzne tej implementacji to _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // ile bajtów przetworzyliśmy
    state: State,  // stan skrótu
    tail: u64,     // nieprzetworzone bajty le
    ntail: usize,  // ile bajtów w tailu jest ważnych
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 i v1, v3 pojawiają się parami w algorytmie, a implementacje simd SipHash będą używać wektorów Z0Z v02 i v13.
    //
    // Umieszczając je w tej kolejności w strukturze, kompilator może sam wykryć tylko kilka optymalizacji simd.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Ładuje liczbę całkowitą żądanego typu ze strumienia bajtów w kolejności LE.
/// Używa `copy_nonoverlapping`, aby umożliwić kompilatorowi wygenerowanie najbardziej wydajnego sposobu załadowania go z prawdopodobnie niewyrównanego adresu.
///
///
/// Niebezpieczne, ponieważ: niezaznaczone indeksowanie w i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// Ładuje u64, używając do 7 bajtów segmentu bajtów.
/// Wygląda niezgrabnie, ale wszystkie wywołania `copy_nonoverlapping` (przez `load_int_le!`) mają stałe rozmiary i unikają wywoływania `memcpy`, co jest dobre dla szybkości.
///
///
/// Niebezpieczne, ponieważ: niezaznaczone indeksowanie na początku..start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // aktualny indeks bajtu (z LSB) na wyjściu u64
    let mut out = 0;
    if i + 3 < len {
        // BEZPIECZEŃSTWO: `i` nie może być większe niż `len`, a dzwoniący musi zagwarantować
        // że indeks start..start + len jest w granicach.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // BEZPIECZEŃSTWO: jak wyżej.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // BEZPIECZEŃSTWO: jak wyżej.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Tworzy nowy `SipHasher` z dwoma początkowymi kluczami ustawionymi na 0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Tworzy `SipHasher`, który jest kluczowany na podstawie dostarczonych kluczy.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Tworzy nowy `SipHasher13` z dwoma początkowymi kluczami ustawionymi na 0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Tworzy `SipHasher13`, który jest kluczowany na podstawie dostarczonych kluczy.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: nie zdefiniowano żadnych metod mieszania liczb całkowitych (`write_u *`, `write_i*`)
    // dla tego typu.
    // Moglibyśmy je dodać, skopiować implementację `short_write` w librustc_data_structures/sip128.rs i dodać metody `write_u *`/`write_i*` do `SipHasher`, `SipHasher13` i `DefaultHasher`.
    //
    // To znacznie przyspieszyłoby mieszanie liczb całkowitych przez te funkcje mieszające, kosztem nieznacznego spowolnienia szybkości kompilacji w niektórych testach porównawczych.
    // Aby uzyskać szczegółowe informacje, patrz #69152.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // BEZPIECZEŃSTWO: `cmp::min(length, needed)` na pewno nie przekroczy `length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Buforowany ogon jest teraz wypłukany, przetwarza nowe dane wejściowe.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // BEZPIECZEŃSTWO: ponieważ `len - left` to największa wielokrotność 8 poniżej
            // `len`, a ponieważ `i` zaczyna się od `needed`, gdzie `len` jest `length - needed`, gwarantuje się, że `i + 8` będzie mniejsze lub równe `length`.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // BEZPIECZEŃSTWO: `i` to teraz `needed + len.div_euclid(8) * 8`,
        // więc `i + left` = `needed + len` = `length`, co z definicji jest równe `msg.len()`.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// Tworzy `Hasher<S>` z dwoma kluczami początkowymi ustawionymi na 0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}