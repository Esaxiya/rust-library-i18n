// ignore-tidy-filelength Ten plik zawiera prawie wyłącznie definicję `Iterator`.
// Nie możemy podzielić tego na wiele plików.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Interfejs do obsługi iteratorów.
///
/// To jest główny iterator trait.
/// Aby uzyskać więcej informacji na temat ogólnej koncepcji iteratorów, zobacz [module-level documentation].
/// W szczególności możesz chcieć wiedzieć, jak [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Typ iterowanych elementów.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Zwiększa iterator i zwraca następną wartość.
    ///
    /// Zwraca [`None`] po zakończeniu iteracji.
    /// Poszczególne implementacje iteratorów mogą zdecydować się na wznowienie iteracji, więc ponowne wywołanie `next()` może w końcu w pewnym momencie ponownie zacząć zwracać [`Some(Item)`].
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Wywołanie next() zwraca następną wartość ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... a potem None, gdy to się skończy.
    /// assert_eq!(None, iter.next());
    ///
    /// // Więcej połączeń może, ale nie musi, zwrócić `None`.Tutaj zawsze będą.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Zwraca granice pozostałej długości iteratora.
    ///
    /// W szczególności `size_hint()` zwraca krotkę, w której pierwszy element jest dolną granicą, a drugi element jest górną granicą.
    ///
    /// Druga połowa zwracanej krotki to [`Option`]`<`[`usize`] `>`.
    /// [`None`] oznacza tutaj, że albo nie ma znanej górnej granicy, albo górna granica jest większa niż [`usize`].
    ///
    /// # Uwagi dotyczące wdrożenia
    ///
    /// Nie jest wymuszone, że implementacja iteratora daje zadeklarowaną liczbę elementów.Błędny iterator może dawać mniej niż dolna granica lub więcej niż górna granica elementów.
    ///
    /// `size_hint()` jest przeznaczony przede wszystkim do optymalizacji, takich jak rezerwowanie miejsca dla elementów iteratora, ale nie można mu ufać, że np. pomija sprawdzanie granic w niebezpiecznym kodzie.
    /// Nieprawidłowa implementacja `size_hint()` nie powinna prowadzić do naruszenia bezpieczeństwa pamięci.
    ///
    /// To powiedziawszy, implementacja powinna zapewnić poprawne oszacowanie, ponieważ w przeciwnym razie byłoby to naruszenie protokołu trait.
    ///
    /// Domyślna implementacja zwraca " (0," [" Brak`] " )" , co jest poprawne dla każdego iteratora.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Bardziej złożony przykład:
    ///
    /// ```
    /// // Liczby parzyste od zera do dziesięciu.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Możemy iterować od zera do dziesięciu razy.
    /// // Wiedza, że jest to dokładnie pięć, nie byłaby możliwa bez wykonania filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Dodajmy jeszcze pięć liczb za pomocą chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // teraz obie granice zostały zwiększone o pięć
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Zwracanie `None` dla górnej granicy:
    ///
    /// ```
    /// // nieskończony iterator nie ma górnej granicy i maksymalnej możliwej dolnej granicy
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Zużywa iterator, zlicza liczbę iteracji i zwraca go.
    ///
    /// Ta metoda będzie wywoływać [`next`] wielokrotnie, aż napotka [`None`], zwracając liczbę razy, gdy zobaczyła [`Some`].
    /// Zauważ, że [`next`] musi zostać wywołany przynajmniej raz, nawet jeśli iterator nie ma żadnych elementów.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Zachowanie związane z przepełnieniem
    ///
    /// Metoda nie chroni przed przepełnieniem, więc zliczanie elementów iteratora z większą liczbą elementów niż [`usize::MAX`] daje albo zły wynik, albo panics.
    ///
    /// Jeśli asercje debugowania są włączone, gwarantowane jest panic.
    ///
    /// # Panics
    ///
    /// Ta funkcja może panic, jeśli iterator ma więcej niż [`usize::MAX`] elementów.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Zużywa iterator, zwracając ostatni element.
    ///
    /// Ta metoda będzie oceniać iterator, dopóki nie zwróci [`None`].
    /// Robiąc to, śledzi bieżący element.
    /// Po zwróceniu [`None`] `last()` zwróci ostatni widziany element.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Rozszerza iterator o elementy `n`.
    ///
    /// Ta metoda chętnie pominie elementy `n`, wywołując [`next`] do `n` razy, aż do napotkania [`None`].
    ///
    /// `advance_by(n)` zwróci [`Ok(())`][Ok], jeśli iterator pomyślnie przejdzie przez elementy `n`, lub [`Err(k)`][Err], jeśli napotkano [`None`], gdzie `k` to liczba elementów, o które iterator jest przesuwany, zanim skończą się elementy (tj.
    /// długość iteratora).
    /// Zauważ, że `k` jest zawsze mniejsze niż `n`.
    ///
    /// Wywołanie `advance_by(0)` nie zużywa żadnych elementów i zawsze zwraca [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // tylko `&4` został pominięty
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Zwraca " n` element iteratora.
    ///
    /// Podobnie jak w przypadku większości operacji indeksowania licznik zaczyna się od zera, więc `nth(0)` zwraca pierwszą wartość, `nth(1)` drugą i tak dalej.
    ///
    /// Zwróć uwagę, że wszystkie poprzednie elementy, a także zwracany element, zostaną zużyte z iteratora.
    /// Oznacza to, że poprzednie elementy zostaną odrzucone, a także wielokrotne wywołanie `nth(0)` w tym samym iteratorze zwróci różne elementy.
    ///
    ///
    /// `nth()` zwróci [`None`], jeśli `n` jest większe lub równe długości iteratora.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Wielokrotne wywołanie `nth()` nie przewija iteratora:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Zwracanie `None`, jeśli jest mniej niż `n + 1` elementów:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Tworzy iterator zaczynający się w tym samym punkcie, ale przy każdej iteracji krok po kroku.
    ///
    /// Uwaga 1: Pierwszy element iteratora będzie zawsze zwracany, niezależnie od podanego kroku.
    ///
    /// Uwaga 2: Czas, w którym ignorowane elementy są wyciągane, nie jest ustalony.
    /// `StepBy` zachowuje się jak sekwencja `next(), nth(step-1), nth(step-1),…`, ale może również zachowywać się jak sekwencja
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// To, który sposób jest używany, może ulec zmianie w przypadku niektórych iteratorów ze względu na wydajność.
    /// Drugi sposób przyspieszy iterator wcześniej i może zużywać więcej elementów.
    ///
    /// `advance_n_and_return_first` jest odpowiednikiem:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metoda będzie panic, jeśli dany krok to `0`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Pobiera dwa iteratory i tworzy po kolei nowy iterator dla obu.
    ///
    /// `chain()` zwróci nowy iterator, który najpierw iteruje po wartościach z pierwszego iteratora, a następnie po wartościach z drugiego iteratora.
    ///
    /// Innymi słowy, łączy ze sobą dwa iteratory w łańcuchu.🔗
    ///
    /// [`once`] jest powszechnie używany do adaptacji pojedynczej wartości w łańcuchu innych rodzajów iteracji.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ponieważ argument `chain()` używa [`IntoIterator`], możemy przekazać wszystko, co można przekonwertować na [`Iterator`], a nie tylko sam [`Iterator`].
    /// Na przykład plasterki (`&[T]`) implementują [`IntoIterator`], więc można je przekazać bezpośrednio do `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Jeśli pracujesz z Windows API, możesz chcieć przekonwertować [`OsStr`] na `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// " Zsuwa` dwa iteratory w jeden iterator par.
    ///
    /// `zip()` zwraca nowy iterator, który będzie iterował po dwóch innych iteratorach, zwracając krotkę, w której pierwszy element pochodzi z pierwszego iteratora, a drugi element pochodzi z drugiego iteratora.
    ///
    ///
    /// Innymi słowy, łączy ze sobą dwa iteratory w jeden.
    ///
    /// Jeśli którykolwiek z iteratorów zwróci [`None`], [`next`] z iteratora spakowanego zwróci [`None`].
    /// Jeśli pierwszy iterator zwróci [`None`], `zip` spowoduje zwarcie, a `next` nie zostanie wywołany na drugim iteratorze.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ponieważ argument `zip()` używa [`IntoIterator`], możemy przekazać wszystko, co można przekonwertować na [`Iterator`], a nie tylko sam [`Iterator`].
    /// Na przykład plasterki (`&[T]`) implementują [`IntoIterator`], więc można je przekazać bezpośrednio do `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` jest często używany do spakowania nieskończonego iteratora do skończonego.
    /// Działa to, ponieważ skończony iterator w końcu zwróci [`None`], kończąc suwak.Pakowanie za pomocą `(0..)` może wyglądać bardzo podobnie do [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Tworzy nowy iterator, który umieszcza kopię `separator` między sąsiednimi elementami oryginalnego iteratora.
    ///
    /// W przypadku, gdy `separator` nie implementuje [`Clone`] lub musi być obliczane za każdym razem, użyj [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Pierwszy element z `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separator.
    /// assert_eq!(a.next(), Some(&1));   // Kolejny element z `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separator.
    /// assert_eq!(a.next(), Some(&2));   // Ostatni element z `a`.
    /// assert_eq!(a.next(), None);       // Iterator jest zakończony.
    /// ```
    ///
    /// `intersperse` może być bardzo przydatne do łączenia elementów iteratora przy użyciu wspólnego elementu:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Tworzy nowy iterator, który umieszcza element wygenerowany przez `separator` między sąsiednimi elementami oryginalnego iteratora.
    ///
    /// Zamknięcie zostanie wywołane dokładnie raz za każdym razem, gdy element zostanie umieszczony między dwoma sąsiednimi elementami z bazowego iteratora;
    /// w szczególności zamknięcie nie jest wywoływane, jeśli iterator bazowy daje mniej niż dwa elementy i po uzyskaniu ostatniego elementu.
    ///
    ///
    /// Jeśli element iteratora implementuje [`Clone`], może być łatwiejsze użycie [`intersperse`].
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Pierwszy element z `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separator.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Kolejny element z `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separator.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Ostatni element z `v`.
    /// assert_eq!(it.next(), None);               // Iterator jest zakończony.
    /// ```
    ///
    /// `intersperse_with` może być używany w sytuacjach, w których trzeba obliczyć separator:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Zamknięcie na zmianę zapożycza swój kontekst, aby wygenerować element.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Pobiera zamknięcie i tworzy iterator, który wywołuje to zamknięcie dla każdego elementu.
    ///
    /// `map()` przekształca jeden iterator w inny za pomocą argumentu:
    /// coś, co implementuje [`FnMut`].Tworzy nowy iterator, który wywołuje to zamknięcie dla każdego elementu oryginalnego iteratora.
    ///
    /// Jeśli jesteś dobry w myśleniu w typach, możesz pomyśleć o `map()` w ten sposób:
    /// Jeśli masz iterator, który daje elementy pewnego typu `A`, i potrzebujesz iteratora innego typu `B`, możesz użyć `map()`, przekazując zamknięcie, które przyjmuje `A` i zwraca `B`.
    ///
    ///
    /// `map()` jest koncepcyjnie podobny do pętli [`for`].Ponieważ jednak `map()` jest leniwy, najlepiej jest go używać, gdy już pracujesz z innymi iteratorami.
    /// Jeśli wykonujesz jakąś pętlę dla efektu ubocznego, uważane jest za bardziej idiomatyczne użycie [`for`] niż `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Jeśli robisz jakiś efekt uboczny, preferuj [`for`] od `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // nie rób tego:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // nie zostanie nawet wykonany, ponieważ jest leniwy.Rust ostrzeże Cię o tym.
    ///
    /// // Zamiast tego użyj dla:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Wywołuje zamknięcie każdego elementu iteratora.
    ///
    /// Jest to równoważne użyciu pętli [`for`] na iteratorze, chociaż `break` i `continue` nie są możliwe po zamknięciu.
    /// Generalnie bardziej idiomatyczne jest użycie pętli `for`, ale `for_each` może być bardziej czytelny podczas przetwarzania elementów na końcu dłuższych łańcuchów iteratorów.
    ///
    /// W niektórych przypadkach `for_each` może być również szybszy niż pętla, ponieważ użyje wewnętrznej iteracji na adapterach takich jak `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// W tak małym przykładzie pętla `for` może być czystsza, ale `for_each` może być lepszym rozwiązaniem, aby zachować funkcjonalny styl z dłuższymi iteratorami:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Tworzy iterator, który używa zamknięcia, aby określić, czy element powinien zostać zwrócony.
    ///
    /// Podany element zamknięcie musi zwrócić `true` lub `false`.Zwrócony iterator zwróci tylko te elementy, dla których zamknięcie zwraca prawdę.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ponieważ zamknięcie przekazane do `filter()` pobiera referencję, a wiele iteratorów iteruje po referencjach, prowadzi to do prawdopodobnie zagmatwanej sytuacji, w której typ zamknięcia jest podwójnym odwołaniem:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // potrzebujesz dwóch * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Często zamiast tego używa się destrukturyzacji w argumencie, aby usunąć jeden z nich:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // oboje i *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// lub obydwa:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dwa &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// tych warstw.
    ///
    /// Zauważ, że `iter.filter(f).next()` jest odpowiednikiem `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Tworzy iterator, który filtruje i mapuje.
    ///
    /// Zwrócony iterator zwraca tylko " wartość`, dla której podane zamknięcie zwraca `Some(value)`.
    ///
    /// `filter_map` może być użyty do uczynienia łańcuchów [`filter`] i [`map`] bardziej zwięzłym.
    /// Poniższy przykład pokazuje, jak `map().filter().map()` można skrócić do pojedynczego wywołania `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Oto ten sam przykład, ale z [`filter`] i [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Tworzy iterator, który podaje bieżącą liczbę iteracji oraz następną wartość.
    ///
    /// Zwrócony iterator daje pary `(i, val)`, gdzie `i` jest bieżącym indeksem iteracji, a `val` jest wartością zwracaną przez iterator.
    ///
    ///
    /// `enumerate()` zachowuje licznik jako [`usize`].
    /// Jeśli chcesz liczyć według liczby całkowitej o innej wielkości, funkcja [`zip`] zapewnia podobną funkcjonalność.
    ///
    /// # Zachowanie związane z przepełnieniem
    ///
    /// Metoda nie chroni przed przepełnieniem, więc wyliczenie więcej niż elementów [`usize::MAX`] albo daje błędny wynik, albo panics.
    /// Jeśli asercje debugowania są włączone, gwarantowane jest panic.
    ///
    /// # Panics
    ///
    /// Zwrócony iterator może panic, jeśli indeks, który ma zostać zwrócony, przepełniłby [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Tworzy iterator, który może używać [`peek`] do przeglądania następnego elementu iteratora bez jego zużywania.
    ///
    /// Dodaje metodę [`peek`] do iteratora.Zobacz dokumentację, aby uzyskać więcej informacji.
    ///
    /// Zauważ, że bazowy iterator jest nadal zaawansowany, gdy [`peek`] jest wywoływany po raz pierwszy: aby pobrać następny element, [`next`] jest wywoływany na bazowym iteratorze, stąd wszelkie efekty uboczne (tj.
    ///
    /// cokolwiek innego niż pobranie następnej wartości) metody [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() pozwala nam zajrzeć do future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // możemy peek() wiele razy, iterator nie przejdzie dalej
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // po zakończeniu iteratora jest peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Tworzy iterator, który [`pomija`] elementy na podstawie predykatu.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` przyjmuje zamknięcie jako argument.Wywoła to zamknięcie na każdym elemencie iteratora i ignoruje elementy, dopóki nie zwróci `false`.
    ///
    /// Po zwróceniu `false` zadanie `skip_while()`'s jest zakończone, a pozostałe elementy są zwracane.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ponieważ zamknięcie przekazane do `skip_while()` pobiera odwołanie, a wiele iteratorów iteruje po odwołaniach, prowadzi to do prawdopodobnie zagmatwanej sytuacji, w której typ argumentu zamknięcia jest podwójnym odwołaniem:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // potrzebujesz dwóch * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zatrzymywanie po początkowym `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // chociaż byłoby to fałszem, ponieważ otrzymaliśmy już fałsz, skip_while() nie jest już używany
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Tworzy iterator, który zwraca elementy na podstawie predykatu.
    ///
    /// `take_while()` przyjmuje zamknięcie jako argument.Wywoła to zamknięcie na każdym elemencie iteratora i zwróci elementy podczas zwracania `true`.
    ///
    /// Po zwróceniu `false` zadanie `take_while()`'s jest zakończone, a pozostałe elementy są ignorowane.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ponieważ zamknięcie przekazane do `take_while()` pobiera referencję, a wiele iteratorów iteruje po referencjach, prowadzi to do prawdopodobnie zagmatwanej sytuacji, w której typ zamknięcia jest podwójnym odwołaniem:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // potrzebujesz dwóch * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zatrzymywanie po początkowym `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Mamy więcej elementów, które są mniejsze od zera, ale ponieważ mamy już fałsz, take_while() nie jest już używany
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ponieważ `take_while()` musi spojrzeć na wartość, aby zobaczyć, czy powinna być uwzględniona, czy nie, używanie iteratorów spowoduje, że zostanie usunięta:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` już tam nie ma, ponieważ został zużyty w celu sprawdzenia, czy iteracja powinna się zatrzymać, ale nie została ponownie umieszczona w iteratorze.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Tworzy iterator, który zwraca elementy na podstawie predykatu i map.
    ///
    /// `map_while()` przyjmuje zamknięcie jako argument.
    /// Wywoła to zamknięcie na każdym elemencie iteratora i zwróci elementy podczas zwracania [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Oto ten sam przykład, ale z [`take_while`] i [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zatrzymywanie po początkowym [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Mamy więcej elementów, które mogłyby zmieścić się w u32 (4, 5), ale `map_while` zwrócił `None` dla `-3` (ponieważ `predicate` zwrócił `None`), a `collect` zatrzymuje się na pierwszym napotkanym `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Ponieważ `map_while()` musi spojrzeć na wartość, aby zobaczyć, czy powinna być uwzględniona, czy nie, używanie iteratorów spowoduje, że zostanie usunięta:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` już tam nie ma, ponieważ został zużyty w celu sprawdzenia, czy iteracja powinna się zatrzymać, ale nie została ponownie umieszczona w iteratorze.
    ///
    /// Zauważ, że w przeciwieństwie do [`take_while`] ten iterator **nie** jest połączony.
    /// Nie jest również określone, co ten iterator zwraca po zwróceniu pierwszego [`None`].
    /// Jeśli potrzebujesz połączonego iteratora, użyj [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Tworzy iterator, który pomija pierwsze elementy `n`.
    ///
    /// Po ich zużyciu reszta pierwiastków zostaje wydana.
    /// Zamiast zastępować tę metodę bezpośrednio, zamiast tego zastąp metodę `nth`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Tworzy iterator, który zwraca pierwsze elementy `n`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` jest często używany z nieskończonym iteratorem, aby uczynić go skończonym:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Jeśli dostępnych jest mniej elementów niż `n`, `take` ograniczy się do rozmiaru bazowego iteratora:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Adapter iteratora podobny do [`fold`], który przechowuje stan wewnętrzny i tworzy nowy iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` przyjmuje dwa argumenty: wartość początkową, która zasiewa stan wewnętrzny, oraz zamknięcie z dwoma argumentami, z których pierwszy jest zmiennym odniesieniem do stanu wewnętrznego, a drugi jest elementem iteratora.
    ///
    /// Zamknięcie można przypisać do stanu wewnętrznego, aby udostępniać stan między iteracjami.
    ///
    /// W iteracji zamknięcie zostanie zastosowane do każdego elementu iteratora, a wartość zwracana z zamknięcia, [`Option`], zostanie zwrócona przez iterator.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // w każdej iteracji pomnożymy stan przez element
    ///     *state = *state * x;
    ///
    ///     // wtedy damy zaprzeczenie stanu
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Tworzy iterator, który działa jak map, ale spłaszcza zagnieżdżoną strukturę.
    ///
    /// Adapter [`map`] jest bardzo przydatny, ale tylko wtedy, gdy argument zamknięcia generuje wartości.
    /// Jeśli zamiast tego tworzy iterator, istnieje dodatkowa warstwa pośrednich.
    /// `flat_map()` usunie tę dodatkową warstwę samodzielnie.
    ///
    /// Możesz myśleć o `flat_map(f)` jako o semantycznym odpowiedniku pinga [`map`], a następnie [`flatten`], jak w `map(f).flatten()`.
    ///
    /// Inny sposób myślenia o `flat_map()`: zamknięcie [" mapy`] zwraca jedną pozycję dla każdego elementu, a zamknięcie `flat_map()`'s zwraca iterator dla każdego elementu.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() zwraca iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Tworzy iterator, który spłaszcza zagnieżdżoną strukturę.
    ///
    /// Jest to przydatne, gdy masz iterator iteratorów lub iterator rzeczy, które można przekształcić w iteratory i chcesz usunąć jeden poziom pośredni.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapowanie, a następnie spłaszczanie:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() zwraca iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Możesz również przepisać to na [`flat_map()`], co jest lepsze w tym przypadku, ponieważ lepiej przekazuje intencje:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() zwraca iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Spłaszczanie usuwa jednocześnie tylko jeden poziom zagnieżdżenia:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Tutaj widzimy, że `flatten()` nie wykonuje spłaszczania "deep".
    /// Zamiast tego usuwany jest tylko jeden poziom zagnieżdżenia.Oznacza to, że jeśli `flatten()` trójwymiarową tablicę, wynik będzie dwuwymiarowy, a nie jednowymiarowy.
    /// Aby uzyskać jednowymiarową strukturę, musisz ponownie `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Tworzy iterator, który kończy się po pierwszym [`None`].
    ///
    /// Po tym, jak iterator zwróci [`None`], wywołania future mogą, ale nie muszą, ponownie dać [`Some(T)`].
    /// `fuse()` dostosowuje iterator, zapewniając, że po podaniu [`None`] zawsze zwróci [`None`] na zawsze.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // iterator, który przełącza się między Some i None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // jeśli jest równy, Some(i32), w przeciwnym razie Brak
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // widzimy, jak nasz iterator porusza się tam iz powrotem
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // jednak kiedy już to połączymy ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // zawsze zwróci `None` za pierwszym razem.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Robi coś z każdym elementem iteratora, przekazując wartość dalej.
    ///
    /// Używając iteratorów, często łączysz ze sobą kilka z nich.
    /// Pracując nad takim kodem, możesz chcieć sprawdzić, co się dzieje w różnych częściach potoku.Aby to zrobić, wprowadź wywołanie do `inspect()`.
    ///
    /// `inspect()` jest częściej używany jako narzędzie do debugowania niż w końcowym kodzie, ale aplikacje mogą uznać to za przydatne w niektórych sytuacjach, gdy błędy muszą być rejestrowane przed odrzuceniem.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ta sekwencja iteratora jest złożona.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // dodajmy kilka wywołań inspect(), aby zbadać, co się dzieje
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Spowoduje to wydrukowanie:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Rejestrowanie błędów przed ich odrzuceniem:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Spowoduje to wydrukowanie:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Pożycza iterator, zamiast go zużywać.
    ///
    /// Jest to przydatne, aby umożliwić stosowanie adapterów iteratorów przy jednoczesnym zachowaniu własności oryginalnego iteratora.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // jeśli spróbujemy ponownie użyć itera, to nie zadziała.
    /// // Poniższy wiersz zawiera " błąd: użycie przesuniętej wartości: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // spróbujmy jeszcze raz
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // zamiast tego dodajemy .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // teraz jest dobrze:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Przekształca iterator w kolekcję.
    ///
    /// `collect()` może wziąć wszystko, co jest iterowalne i przekształcić to w odpowiednią kolekcję.
    /// Jest to jedna z potężniejszych metod w bibliotece standardowej, używana w różnych kontekstach.
    ///
    /// Najbardziej podstawowym wzorcem, w którym używany jest `collect()`, jest przekształcenie jednej kolekcji w drugą.
    /// Bierzesz kolekcję, wywołujesz na niej [`iter`], wykonujesz kilka transformacji, a na końcu `collect()`.
    ///
    /// `collect()` może również tworzyć wystąpienia typów, które nie są typowymi kolekcjami.
    /// Na przykład [`String`] można zbudować z [`char`] s, a iterator elementów [`Result<T, E>`][`Result`] można zebrać do `Result<Collection<T>, E>`.
    ///
    /// Zobacz przykłady poniżej, aby uzyskać więcej informacji.
    ///
    /// Ponieważ `collect()` jest tak ogólny, może powodować problemy podczas wnioskowania o typie.
    /// W związku z tym `collect()` jest jednym z nielicznych przypadków, w których zobaczysz czule znaną składnię jako 'turbofish': `::<>`.
    /// Pomaga to algorytmowi wnioskowania dokładnie zrozumieć, do której kolekcji próbujesz zebrać.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Zauważ, że potrzebowaliśmy `: Vec<i32>` po lewej stronie.Dzieje się tak, ponieważ zamiast tego moglibyśmy zebrać na przykład do [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Używanie 'turbofish' zamiast dodawania adnotacji do `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Ponieważ `collect()` dba tylko o to, do czego zbierasz, nadal możesz użyć częściowej podpowiedzi typu, `_`, z turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Używanie `collect()` do tworzenia [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Jeśli masz listę [`Result<T, E>`][`Result`] s, możesz użyć `collect()`, aby sprawdzić, czy któryś z nich się nie powiódł:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // daje nam pierwszy błąd
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // daje nam listę odpowiedzi
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Zużywa iterator, tworząc z niego dwie kolekcje.
    ///
    /// Predykat przekazany do `partition()` może zwrócić `true` lub `false`.
    /// `partition()` zwraca parę, wszystkie elementy, dla których zwrócił `true`, oraz wszystkie elementy, dla których zwrócił `false`.
    ///
    ///
    /// Zobacz także [`is_partitioned()`] i [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Zmienia kolejność elementów tego iteratora *w miejscu* zgodnie z podanym predykatem, tak aby wszystkie zwracające `true` poprzedzały wszystkie zwracające `false`.
    ///
    /// Zwraca liczbę znalezionych elementów `true`.
    ///
    /// Względna kolejność elementów podzielonych na partycje nie jest zachowywana.
    ///
    /// Zobacz także [`is_partitioned()`] i [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Podział na miejscu między liczbami parzystymi i szansami
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: czy powinniśmy się martwić o przepełnienie licznika?Jedyny sposób, aby mieć więcej niż
        // `usize::MAX` zmienne odniesienia są z ZST, które nie są przydatne do partycjonowania ...

        // Te funkcje zamknięcia "factory" istnieją, aby uniknąć ogólności w `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Kilkakrotnie znajdź pierwszy `false` i zamień go na ostatni `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Sprawdza, czy elementy tego iteratora są podzielone na partycje zgodnie z podanym predykatem, tak że wszystkie zwracające `true` poprzedzają wszystkie zwracające `false`.
    ///
    ///
    /// Zobacz także [`partition()`] i [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Albo wszystkie elementy testują `true`, albo pierwsza klauzula kończy się na `false` i sprawdzamy, czy po tym nie ma już elementów `true`.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Metoda iteratora, która stosuje funkcję tak długo, jak długo zwraca ona pomyślnie, generując pojedynczą, końcową wartość.
    ///
    /// `try_fold()` przyjmuje dwa argumenty: wartość początkową i zamknięcie z dwoma argumentami: 'accumulator' i elementem.
    /// Zamknięcie albo powróci pomyślnie, z wartością, którą akumulator powinien mieć dla następnej iteracji, albo zwraca błąd, z wartością błędu, która jest natychmiast propagowana z powrotem do wywołującego (short-circuiting).
    ///
    ///
    /// Wartość początkowa to wartość, jaką akumulator będzie miał przy pierwszym wywołaniu.Jeśli zamknięcie powiodło się w odniesieniu do każdego elementu iteratora, `try_fold()` zwraca ostateczny akumulator jako sukces.
    ///
    /// Zwijanie jest przydatne, gdy masz jakąś kolekcję i chcesz uzyskać z niej jedną wartość.
    ///
    /// # Uwaga do wykonawców
    ///
    /// Kilka innych metod (forward) ma domyślne implementacje pod względem tej metody, więc spróbuj zaimplementować to jawnie, jeśli może zrobić coś lepszego niż domyślna implementacja pętli `for`.
    ///
    /// W szczególności spróbuj wywołać `try_fold()` w częściach wewnętrznych, z których składa się ten iterator.
    /// Jeśli potrzeba wielu wywołań, operator `?` może być wygodny do łączenia wartości akumulatora w łańcuch, ale uważaj na wszelkie niezmienniki, które muszą zostać utrzymane przed tymi wczesnymi zwrotami.
    /// Jest to metoda `&mut self`, więc po pojawieniu się błędu w tym miejscu należy wznowić iterację.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // sprawdzona suma wszystkich elementów tablicy
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Suma ta przepływa podczas dodawania elementu 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Ponieważ nastąpiło zwarcie, pozostałe elementy są nadal dostępne przez iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metoda iteratora, która stosuje omylną funkcję do każdego elementu w iteratorze, zatrzymując się na pierwszym błędzie i zwracając ten błąd.
    ///
    ///
    /// Można to również traktować jako omylną formę [`for_each()`] lub bezstanową wersję [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Nastąpiło zwarcie, więc pozostałe elementy nadal znajdują się w iteratorze:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Składa każdy element do akumulatora, wykonując operację, zwracając wynik końcowy.
    ///
    /// `fold()` przyjmuje dwa argumenty: wartość początkową i zamknięcie z dwoma argumentami: 'accumulator' i elementem.
    /// Zamknięcie zwraca wartość, którą akumulator powinien mieć dla następnej iteracji.
    ///
    /// Wartość początkowa to wartość, jaką akumulator będzie miał przy pierwszym wywołaniu.
    ///
    /// Po zastosowaniu tego zamknięcia do każdego elementu iteratora `fold()` zwraca akumulator.
    ///
    /// Ta operacja jest czasami nazywana 'reduce' lub 'inject'.
    ///
    /// Zwijanie jest przydatne, gdy masz jakąś kolekcję i chcesz uzyskać z niej jedną wartość.
    ///
    /// Note: `fold()` i podobne metody, które przechodzą przez cały iterator, mogą nie kończyć się dla nieskończonych iteratorów, nawet na traits, dla których wynik jest możliwy do określenia w skończonym czasie.
    ///
    /// Note: [`reduce()`] może służyć do użycia pierwszego elementu jako wartości początkowej, jeśli typ akumulatora i typ elementu są takie same.
    ///
    /// # Uwaga do wykonawców
    ///
    /// Kilka innych metod (forward) ma domyślne implementacje pod względem tej metody, więc spróbuj zaimplementować to jawnie, jeśli może zrobić coś lepszego niż domyślna implementacja pętli `for`.
    ///
    ///
    /// W szczególności spróbuj wywołać `fold()` w częściach wewnętrznych, z których składa się ten iterator.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // suma wszystkich elementów tablicy
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Przejdźmy przez każdy krok iteracji tutaj:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Tak więc, nasz ostateczny wynik, `6`.
    ///
    /// Często zdarza się, że ludzie, którzy nie używali zbyt często iteratorów, używają pętli `for` z listą rzeczy do zbudowania wyniku.Można je zamienić na `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // dla pętli:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // są takie same
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Redukuje elementy do jednego, poprzez wielokrotne stosowanie operacji redukcyjnej.
    ///
    /// Jeśli iterator jest pusty, zwraca [`None`];w przeciwnym razie zwraca wynik redukcji.
    ///
    /// W przypadku iteratorów z co najmniej jednym elementem jest to to samo, co [`fold()`] z pierwszym elementem iteratora jako wartością początkową, składając do niego każdy kolejny element.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Znajdź maksymalną wartość:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Sprawdza, czy każdy element iteratora pasuje do predykatu.
    ///
    /// `all()` przyjmuje zamknięcie, które zwraca `true` lub `false`.Stosuje to zamknięcie do każdego elementu iteratora, a jeśli wszystkie zwracają `true`, to samo robi `all()`.
    /// Jeśli którykolwiek z nich zwróci `false`, zwróci `false`.
    ///
    /// `all()` zwiera;innymi słowy, przerwie przetwarzanie, gdy tylko znajdzie `false`, biorąc pod uwagę, że bez względu na to, co się stanie, wynikiem będzie również `false`.
    ///
    ///
    /// Pusty iterator zwraca `true`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Zatrzymanie się na pierwszym `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // nadal możemy używać `iter`, ponieważ elementów jest więcej.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Sprawdza, czy którykolwiek element iteratora pasuje do predykatu.
    ///
    /// `any()` przyjmuje zamknięcie, które zwraca `true` lub `false`.Stosuje to zamknięcie do każdego elementu iteratora, a jeśli którykolwiek z nich zwraca `true`, to samo robi `any()`.
    /// Jeśli wszystkie zwracają `false`, zwraca `false`.
    ///
    /// `any()` zwiera;innymi słowy, przerwie przetwarzanie, gdy tylko znajdzie `true`, biorąc pod uwagę, że bez względu na to, co się stanie, wynikiem będzie również `true`.
    ///
    ///
    /// Pusty iterator zwraca `false`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Zatrzymanie się na pierwszym `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // nadal możemy używać `iter`, ponieważ elementów jest więcej.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Wyszukuje element iteratora, który spełnia predykat.
    ///
    /// `find()` przyjmuje zamknięcie, które zwraca `true` lub `false`.
    /// Stosuje to zamknięcie do każdego elementu iteratora, a jeśli którykolwiek z nich zwraca `true`, to `find()` zwraca [`Some(element)`].
    /// Jeśli wszystkie zwracają `false`, zwraca [`None`].
    ///
    /// `find()` zwiera;innymi słowy, przerwie przetwarzanie, gdy tylko zamknięcie zwróci `true`.
    ///
    /// Ponieważ `find()` pobiera odwołanie, a wiele iteratorów iteruje po odwołaniach, prowadzi to do prawdopodobnie zagmatwanej sytuacji, w której argument jest podwójnym odwołaniem.
    ///
    /// Możesz zobaczyć ten efekt na poniższych przykładach, z `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Zatrzymanie się na pierwszym `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // nadal możemy używać `iter`, ponieważ elementów jest więcej.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Zauważ, że `iter.find(f)` jest odpowiednikiem `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Stosuje funkcję do elementów iteratora i zwraca pierwszy wynik inny niż brak.
    ///
    ///
    /// `iter.find_map(f)` jest odpowiednikiem `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Stosuje funkcję do elementów iteratora i zwraca pierwszy prawdziwy wynik lub pierwszy błąd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Wyszukuje element w iteratorze, zwracając jego indeks.
    ///
    /// `position()` przyjmuje zamknięcie, które zwraca `true` lub `false`.
    /// Stosuje to zamknięcie do każdego elementu iteratora, a jeśli jeden z nich zwraca `true`, to `position()` zwraca [`Some(index)`].
    /// Jeśli wszystkie zwracają `false`, zwraca [`None`].
    ///
    /// `position()` zwiera;innymi słowy, przerwie przetwarzanie, gdy tylko znajdzie `true`.
    ///
    /// # Zachowanie związane z przepełnieniem
    ///
    /// Metoda nie chroni przed przepełnieniem, więc jeśli jest więcej niż [`usize::MAX`] niepasujących elementów, to albo daje błędny wynik, albo panics.
    ///
    /// Jeśli asercje debugowania są włączone, gwarantowane jest panic.
    ///
    /// # Panics
    ///
    /// Ta funkcja może panic, jeśli iterator ma więcej niż `usize::MAX` niepasujących elementów.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Zatrzymanie się na pierwszym `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // nadal możemy używać `iter`, ponieważ elementów jest więcej.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Zwrócony indeks zależy od stanu iteratora
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Wyszukuje element w iteratorze od prawej, zwracając jego indeks.
    ///
    /// `rposition()` przyjmuje zamknięcie, które zwraca `true` lub `false`.
    /// Stosuje to zamknięcie do każdego elementu iteratora, zaczynając od końca, a jeśli jeden z nich zwraca `true`, to `rposition()` zwraca [`Some(index)`].
    ///
    /// Jeśli wszystkie zwracają `false`, zwraca [`None`].
    ///
    /// `rposition()` zwiera;innymi słowy, przerwie przetwarzanie, gdy tylko znajdzie `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Zatrzymanie się na pierwszym `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // nadal możemy używać `iter`, ponieważ elementów jest więcej.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Nie ma tu potrzeby sprawdzania przepełnienia, ponieważ `ExactSizeIterator` oznacza, że liczba elementów mieści się w `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Zwraca maksymalny element iteratora.
    ///
    /// Jeśli kilka elementów jest jednakowo maksymalnych, zwracany jest ostatni element.
    /// Jeśli iterator jest pusty, zwracany jest [`None`].
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Zwraca minimalny element iteratora.
    ///
    /// Jeśli kilka elementów jest równie minimalnych, zwracany jest pierwszy element.
    /// Jeśli iterator jest pusty, zwracany jest [`None`].
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Zwraca element, który daje maksymalną wartość z określonej funkcji.
    ///
    ///
    /// Jeśli kilka elementów jest jednakowo maksymalnych, zwracany jest ostatni element.
    /// Jeśli iterator jest pusty, zwracany jest [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Zwraca element, który daje maksymalną wartość w odniesieniu do określonej funkcji porównawczej.
    ///
    ///
    /// Jeśli kilka elementów jest jednakowo maksymalnych, zwracany jest ostatni element.
    /// Jeśli iterator jest pusty, zwracany jest [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Zwraca element, który daje minimalną wartość z określonej funkcji.
    ///
    ///
    /// Jeśli kilka elementów jest równie minimalnych, zwracany jest pierwszy element.
    /// Jeśli iterator jest pusty, zwracany jest [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Zwraca element, który daje minimalną wartość w odniesieniu do określonej funkcji porównawczej.
    ///
    ///
    /// Jeśli kilka elementów jest równie minimalnych, zwracany jest pierwszy element.
    /// Jeśli iterator jest pusty, zwracany jest [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Odwraca kierunek iteratora.
    ///
    /// Zwykle iteratory wykonują iterację od lewej do prawej.
    /// Po użyciu `rev()` iterator będzie wykonywał iterację od prawej do lewej.
    ///
    /// Jest to możliwe tylko wtedy, gdy iterator ma koniec, więc `rev()` działa tylko na [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Konwertuje iterator par na parę kontenerów.
    ///
    /// `unzip()` zużywa cały iterator par, tworząc dwie kolekcje: jedną z lewych elementów par i jedną z prawych elementów.
    ///
    ///
    /// Ta funkcja jest w pewnym sensie przeciwieństwem [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Tworzy iterator, który kopiuje wszystkie jego elementy.
    ///
    /// Jest to przydatne, gdy masz iterator na `&T`, ale potrzebujesz iteratora na `T`.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // skopiowany jest taki sam jak .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Tworzy iterator, który [`klon`] jest wszystkimi jego elementami.
    ///
    /// Jest to przydatne, gdy masz iterator na `&T`, ale potrzebujesz iteratora na `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // sklonowany jest taki sam jak .map(|&x| x), dla liczb całkowitych
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Powtarza iterator bez końca.
    ///
    /// Zamiast zatrzymywać się na [`None`], iterator zacznie zamiast tego od nowa, od początku.Po ponownym wykonaniu iteracji rozpocznie się ponownie od początku.I znowu.
    /// I znowu.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Sumuje elementy iteratora.
    ///
    /// Pobiera każdy element, dodaje je do siebie i zwraca wynik.
    ///
    /// Pusty iterator zwraca zerową wartość typu.
    ///
    /// # Panics
    ///
    /// Podczas wywoływania `sum()` i zwracania pierwotnego typu liczby całkowitej, ta metoda zwróci panic, jeśli obliczenia przepełnią się i zostaną włączone asercje debugowania.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iteruje po całym iteratorze, mnożąc wszystkie elementy
    ///
    /// Pusty iterator zwraca jedną wartość typu.
    ///
    /// # Panics
    ///
    /// Podczas wywoływania `product()` i zwracania pierwotnego typu liczby całkowitej, metoda panic, jeśli obliczenia przepełnią się i zostaną włączone asercje debugowania.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porównuje elementy tego [`Iterator`] z innymi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porównuje elementy tego [`Iterator`] z elementami innego w odniesieniu do określonej funkcji porównania.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porównuje elementy tego [`Iterator`] z innymi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porównuje elementy tego [`Iterator`] z elementami innego w odniesieniu do określonej funkcji porównania.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Określa, czy elementy tego [`Iterator`] są równe innym.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Określa, czy elementy tego [`Iterator`] są równe innym w odniesieniu do określonej funkcji równości.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Określa, czy elementy tego [`Iterator`] są nierówne z innymi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Określa, czy elementy tego [`Iterator`] są o [lexicographically](Ord#lexicographical-comparison) mniejsze niż inne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Określa, czy elementy tego [`Iterator`] są [lexicographically](Ord#lexicographical-comparison) mniejsze lub równe elementom innego.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Określa, czy elementy tego [`Iterator`] są [lexicographically](Ord#lexicographical-comparison) większe niż inne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Określa, czy elementy tego [`Iterator`] są [lexicographically](Ord#lexicographical-comparison) większe lub równe innym.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Sprawdza, czy elementy tego iteratora są posortowane.
    ///
    /// Oznacza to, że dla każdego elementu `a` i następującego po nim elementu `b`, `a <= b` musi się utrzymywać.Jeśli iterator daje dokładnie zero lub jeden element, zwracany jest `true`.
    ///
    /// Zauważ, że jeśli `Self::Item` to tylko `PartialOrd`, ale nie `Ord`, powyższa definicja oznacza, że ta funkcja zwraca `false`, jeśli jakiekolwiek dwa kolejne elementy nie są porównywalne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Sprawdza, czy elementy tego iteratora są posortowane przy użyciu podanej funkcji komparatora.
    ///
    /// Zamiast używać `PartialOrd::partial_cmp`, ta funkcja używa podanej funkcji `compare` do określenia kolejności dwóch elementów.
    /// Poza tym jest odpowiednikiem [`is_sorted`];zobacz dokumentację, aby uzyskać więcej informacji.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Sprawdza, czy elementy tego iteratora są posortowane przy użyciu podanej funkcji wyodrębniania klucza.
    ///
    /// Zamiast bezpośrednio porównywać elementy iteratora, ta funkcja porównuje klucze elementów, określone przez `f`.
    /// Poza tym jest odpowiednikiem [`is_sorted`];zobacz dokumentację, aby uzyskać więcej informacji.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Zobacz [TrustedRandomAccess]
    // Niezwykła nazwa ma na celu uniknięcie kolizji nazw w rozdzielczości metod, patrz #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}