use crate::ops::{ControlFlow, Try};

/// Iterator zdolny do generowania elementów z obu końców.
///
/// Coś, co implementuje `DoubleEndedIterator`, ma jedną dodatkową zdolność w stosunku do czegoś, co implementuje [`Iterator`]: możliwość wzięcia również " Przedmiotu` z tyłu, jak iz przodu.
///
///
/// Ważne jest, aby pamiętać, że zarówno tam, jak i z powrotem pracują w tym samym zakresie i nie krzyżują się: iteracja kończy się, gdy spotykają się w środku.
///
/// Podobnie jak w przypadku protokołu [`Iterator`], gdy `DoubleEndedIterator` zwraca [`None`] z [`next_back()`], ponowne wywołanie go może, ale nie musi, zwrócić ponownie [`Some`].
/// [`next()`] i [`next_back()`] są w tym celu wymienne.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Usuwa i zwraca element z końca iteratora.
    ///
    /// Zwraca `None`, gdy nie ma więcej elementów.
    ///
    /// Dokumentacja [trait-level] zawiera więcej szczegółów.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Elementy dostarczane przez metody `DoubleEndedIterator` mogą różnić się od tych dostarczanych przez metody [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Zwiększa iterator od tyłu o elementy `n`.
    ///
    /// `advance_back_by` jest odwrotną wersją [`advance_by`].Ta metoda chętnie pominie elementy `n`, zaczynając od tyłu, wywołując [`next_back`] aż do `n` razy, aż do napotkania [`None`].
    ///
    /// `advance_back_by(n)` zwróci [`Ok(())`], jeśli iterator pomyślnie przejdzie do przodu o elementy `n` lub [`Err(k)`], jeśli napotkano [`None`], gdzie `k` to liczba elementów, o które iterator jest przesuwany, zanim skończą się elementy (tj.
    /// długość iteratora).
    /// Zauważ, że `k` jest zawsze mniejsze niż `n`.
    ///
    /// Wywołanie `advance_back_by(0)` nie zużywa żadnych elementów i zawsze zwraca [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // tylko `&3` został pominięty
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Zwraca " n` element od końca iteratora.
    ///
    /// Jest to zasadniczo odwrócona wersja [`Iterator::nth()`].
    /// Chociaż podobnie jak w przypadku większości operacji indeksowania, licznik zaczyna się od zera, więc `nth_back(0)` zwraca pierwszą wartość od końca, `nth_back(1)` drugą i tak dalej.
    ///
    ///
    /// Zwróć uwagę, że wszystkie elementy między końcem a zwróconym elementem zostaną zużyte, w tym zwrócony element.
    /// Oznacza to również, że wielokrotne wywoływanie `nth_back(0)` w tym samym iteratorze zwróci różne elementy.
    ///
    /// `nth_back()` zwróci [`None`], jeśli `n` jest większe lub równe długości iteratora.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Wielokrotne wywołanie `nth_back()` nie przewija iteratora:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Zwracanie `None`, jeśli jest mniej niż `n + 1` elementów:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// To jest odwrotna wersja [`Iterator::try_fold()`]: pobiera elementy zaczynające się z tyłu iteratora.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Ponieważ nastąpiło zwarcie, pozostałe elementy są nadal dostępne przez iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metoda iteratora, która redukuje elementy iteratora do pojedynczej, końcowej wartości, zaczynając od tyłu.
    ///
    /// To jest odwrotna wersja [`Iterator::fold()`]: pobiera elementy zaczynające się z tyłu iteratora.
    ///
    /// `rfold()` przyjmuje dwa argumenty: wartość początkową i zamknięcie z dwoma argumentami: 'accumulator' i elementem.
    /// Zamknięcie zwraca wartość, którą akumulator powinien mieć dla następnej iteracji.
    ///
    /// Wartość początkowa to wartość, jaką akumulator będzie miał przy pierwszym wywołaniu.
    ///
    /// Po zastosowaniu tego zamknięcia do każdego elementu iteratora `rfold()` zwraca akumulator.
    ///
    /// Ta operacja jest czasami nazywana 'reduce' lub 'inject'.
    ///
    /// Zwijanie jest przydatne, gdy masz jakąś kolekcję i chcesz uzyskać z niej jedną wartość.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // suma wszystkich elementów a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ten przykład tworzy ciąg, zaczynając od wartości początkowej i kontynuując każdy element od tyłu do przodu:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Wyszukuje od tyłu element iteratora, który spełnia predykat.
    ///
    /// `rfind()` przyjmuje zamknięcie, które zwraca `true` lub `false`.
    /// Stosuje to zamknięcie do każdego elementu iteratora, zaczynając od końca, a jeśli którykolwiek z nich zwraca `true`, to `rfind()` zwraca [`Some(element)`].
    /// Jeśli wszystkie zwracają `false`, zwraca [`None`].
    ///
    /// `rfind()` zwiera;innymi słowy, przerwie przetwarzanie, gdy tylko zamknięcie zwróci `true`.
    ///
    /// Ponieważ `rfind()` pobiera odwołanie, a wiele iteratorów iteruje po odwołaniach, prowadzi to do prawdopodobnie zagmatwanej sytuacji, w której argument jest podwójnym odwołaniem.
    ///
    /// Możesz zobaczyć ten efekt na poniższych przykładach, z `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Zatrzymanie się na pierwszym `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // nadal możemy używać `iter`, ponieważ elementów jest więcej.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}