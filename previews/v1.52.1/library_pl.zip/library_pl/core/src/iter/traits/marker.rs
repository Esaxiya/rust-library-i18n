/// Iterator, który zawsze dostarcza `None` po wyczerpaniu.
///
/// Wywołanie next na połączonym iteratorze, który raz zwrócił `None`, gwarantuje ponowne zwrócenie [`None`].
/// Ten trait powinien być implementowany przez wszystkie iteratory, które zachowują się w ten sposób, ponieważ pozwala na optymalizację [`Iterator::fuse()`].
///
///
/// Note: Ogólnie rzecz biorąc, nie powinieneś używać `FusedIterator` w ogólnych granicach, jeśli potrzebujesz połączonego iteratora.
/// Zamiast tego powinieneś po prostu wywołać [`Iterator::fuse()`] w iteratorze.
/// Jeśli iterator jest już połączony, dodatkowe opakowanie [`Fuse`] nie będzie działać bez utraty wydajności.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterator, który zgłasza dokładną długość za pomocą parametru size_hint.
///
/// Iterator zgłasza wskazówkę dotyczącą rozmiaru, która jest albo dokładna (dolna granica jest równa górnej granicy), albo górna granica to [`None`].
///
/// Górna granica musi wynosić [`None`] tylko wtedy, gdy rzeczywista długość iteratora jest większa niż [`usize::MAX`].
/// W takim przypadku dolna granica musi wynosić [`usize::MAX`], co daje [`Iterator::size_hint()`] równe `(usize::MAX, None)`.
///
/// Iterator musi wygenerować dokładnie taką liczbę elementów, które zgłosił lub różni się przed osiągnięciem końca.
///
/// # Safety
///
/// Ten trait należy wdrożyć tylko wtedy, gdy umowa jest utrzymana.
/// Konsumenci tego trait muszą sprawdzić górną granicę [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Iterator, który podczas generowania elementu pobierze co najmniej jeden element z bazowego [`SourceIter`].
///
/// Wywołanie dowolnej metody, która rozszerza iterator, np
/// [`next()`] lub [`try_fold()`], gwarantuje, że dla każdego kroku co najmniej jedna wartość źródła będącego podstawą iteratora została usunięta, a wynik łańcucha iteratora można wstawić w jego miejsce, przy założeniu, że ograniczenia strukturalne źródła pozwalają na takie wstawienie.
///
/// Innymi słowy, ten trait wskazuje, że potok iteratora można zebrać w miejscu.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}