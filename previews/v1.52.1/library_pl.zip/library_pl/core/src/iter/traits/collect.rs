/// Konwersja z [`Iterator`].
///
/// Implementując `FromIterator` dla typu, definiujesz, w jaki sposób zostanie utworzony z iteratora.
/// Jest to typowe dla typów, które opisują jakiś zbiór.
///
/// [`FromIterator::from_iter()`] jest rzadko wywoływany jawnie i zamiast tego jest używany przez metodę [`Iterator::collect()`].
///
/// Więcej przykładów znajdziesz w dokumentacji [`Iterator::collect()`]'s.
///
/// Zobacz też: [`IntoIterator`].
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Używanie [`Iterator::collect()`] do niejawnego używania `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Wdrażanie `FromIterator` dla Twojego typu:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Kolekcja próbek, to tylko opakowanie na Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Podajmy mu kilka metod, abyśmy mogli go stworzyć i dodać do niego różne rzeczy.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // i zaimplementujemy FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Teraz możemy stworzyć nowy iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... i utwórz z niego MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // zbierać też działa!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Tworzy wartość z iteratora.
    ///
    /// Zobacz [module-level documentation] po więcej.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Konwersja do [`Iterator`].
///
/// Implementując `IntoIterator` dla typu, definiujesz, w jaki sposób będzie on konwertowany na iterator.
/// Jest to typowe dla typów, które opisują jakiś zbiór.
///
/// Jedną z korzyści wynikających z wdrożenia `IntoIterator` jest to, że Twój typ będzie [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Zobacz też: [`FromIterator`].
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Wdrażanie `IntoIterator` dla Twojego typu:
///
/// ```
/// // Kolekcja próbek, to tylko opakowanie na Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Podajmy mu kilka metod, abyśmy mogli go stworzyć i dodać do niego różne rzeczy.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // i zaimplementujemy IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Teraz możemy stworzyć nową kolekcję ...
/// let mut c = MyCollection::new();
///
/// // ... dodaj do tego trochę rzeczy ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... a następnie przekształć go w iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Często używa się `IntoIterator` jako trait bound.Pozwala to na zmianę typu kolekcji danych wejściowych, o ile nadal jest to iterator.
/// Dodatkowe granice można określić, ograniczając
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Typ iterowanych elementów.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// W jaki iterator to zmieniamy?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Tworzy iterator z wartości.
    ///
    /// Zobacz [module-level documentation] po więcej.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Rozszerz kolekcję o zawartość iteratora.
///
/// Iteratory tworzą serie wartości, a kolekcje można również traktować jako serie wartości.
/// `Extend` trait wypełnia tę lukę, umożliwiając rozszerzenie kolekcji o zawartość tego iteratora.
/// Podczas rozszerzania kolekcji o już istniejący klucz ten wpis jest aktualizowany lub, w przypadku kolekcji, które zezwalają na wiele wpisów z jednakowymi kluczami, ten wpis jest wstawiany.
///
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// // Możesz rozszerzyć String o kilka znaków:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Wdrażanie `Extend`:
///
/// ```
/// // Kolekcja próbek, to tylko opakowanie na Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Podajmy mu kilka metod, abyśmy mogli go stworzyć i dodać do niego różne rzeczy.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ponieważ MyCollection ma listę i32s, wdrażamy Extend dla i32
/// impl Extend<i32> for MyCollection {
///
///     // Jest to trochę prostsze z konkretną sygnaturą typu: możemy wywołać rozszerzenie na wszystkim, co można przekształcić w Iterator, który daje nam i32.
///     // Ponieważ potrzebujemy i32, aby umieścić je w MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Implementacja jest bardzo prosta: zapętlaj iterator i add() każdy element do siebie.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // poszerzmy naszą kolekcję o trzy kolejne numery
/// c.extend(vec![1, 2, 3]);
///
/// // dodaliśmy te elementy na końcu
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Rozszerza kolekcję o zawartość iteratora.
    ///
    /// Ponieważ jest to jedyna wymagana metoda dla tego trait, dokumenty [trait-level] zawierają więcej szczegółów.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // Możesz rozszerzyć String o kilka znaków:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Rozszerza kolekcję o dokładnie jeden element.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Rezerwuje pojemność w kolekcji dla określonej liczby dodatkowych elementów.
    ///
    /// Domyślna implementacja nic nie robi.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}