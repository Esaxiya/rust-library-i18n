/// Iterator, który zna dokładną długość.
///
/// Wiele [`Iteratorów`] nie wie, ile razy będą iterować, ale niektórzy tak robią.
/// Jeśli iterator wie, ile razy może iterować, zapewnienie dostępu do tych informacji może być przydatne.
/// Na przykład, jeśli chcesz wykonać iterację wstecz, dobrym początkiem jest wiedzieć, gdzie jest koniec.
///
/// Implementując `ExactSizeIterator`, musisz również zaimplementować [`Iterator`].
/// Robiąc to, implementacja [`Iterator::size_hint`]*musi* zwracać dokładny rozmiar iteratora.
///
/// Metoda [`len`] ma domyślną implementację, więc zwykle nie należy jej implementować.
/// Możesz jednak zapewnić bardziej wydajną implementację niż domyślna, więc zastąpienie jej w tym przypadku ma sens.
///
///
/// Zauważ, że ten trait jest bezpiecznym trait i jako taki *nie* i *nie* może * zagwarantować, że zwracana długość jest poprawna.
/// Oznacza to, że kod `unsafe`**nie może** polegać na poprawności [`Iterator::size_hint`].
/// Niestabilny i niebezpieczny [`TrustedLen`](super::marker::TrustedLen) trait daje tę dodatkową gwarancję.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// // skończony zakres dokładnie wie, ile razy będzie iterować
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// W [module-level docs] wdrożyliśmy [`Iterator`], `Counter`.
/// Zaimplementujmy również do tego `ExactSizeIterator`:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Możemy łatwo obliczyć pozostałą liczbę iteracji.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // A teraz możemy to wykorzystać!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Zwraca dokładną długość iteratora.
    ///
    /// Implementacja zapewnia, że iterator zwróci dokładnie `len()` więcej razy wartość [`Some(T)`], zanim zwróci [`None`].
    ///
    /// Ta metoda ma domyślną implementację, więc zwykle nie należy jej implementować bezpośrednio.
    /// Jeśli jednak możesz zapewnić bardziej wydajną implementację, możesz to zrobić.
    /// Przykład można znaleźć w dokumentacji [trait-level].
    ///
    /// Ta funkcja ma takie same gwarancje bezpieczeństwa jak funkcja [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // skończony zakres dokładnie wie, ile razy będzie iterować
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: To twierdzenie jest zbyt obronne, ale sprawdza niezmiennik
        // gwarantowane przez trait.
        // Gdyby ten trait był rust-internal, moglibyśmy użyć debug_assert !;assert_eq!sprawdzi również wszystkie implementacje użytkowników Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Zwraca `true`, jeśli iterator jest pusty.
    ///
    /// Ta metoda ma domyślną implementację przy użyciu [`ExactSizeIterator::len()`], więc nie musisz jej implementować samodzielnie.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}