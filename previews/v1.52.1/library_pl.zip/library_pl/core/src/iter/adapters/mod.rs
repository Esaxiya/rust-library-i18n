use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Ten trait zapewnia przechodni dostęp do etapu źródłowego w potoku międzyator-adapter w warunkach, które
/// * Samo źródło iteratora `S` implementuje `SourceIter<Source = S>`
/// * istnieje implementacja delegująca tego trait dla każdego adaptera w potoku między źródłem a odbiorcą potoku.
///
/// Gdy źródłem jest struktura iteratora będąca właścicielem (powszechnie nazywana `IntoIter`), może to być przydatne do specjalizacji implementacji [`FromIterator`] lub odzyskiwania pozostałych elementów po częściowym wyczerpaniu iteratora.
///
///
/// Należy zauważyć, że implementacje niekoniecznie muszą zapewniać dostęp do najbardziej wewnętrznego źródła potoku.Stanowy adapter pośredni może chętnie ocenić część potoku i ujawnić swoją pamięć wewnętrzną jako źródło.
///
/// trait jest niebezpieczne, ponieważ wdrażający muszą zachować dodatkowe właściwości bezpieczeństwa.
/// Aby uzyskać szczegółowe informacje, patrz [`as_inner`].
///
/// # Examples
///
/// Pobieranie częściowo zużytego źródła:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Etap źródłowy w potoku iteratora.
    type Source: Iterator;

    /// Pobierz źródło potoku iteratora.
    ///
    /// # Safety
    ///
    /// Implementacje muszą zwracać to samo zmienne odwołanie przez cały okres istnienia, chyba że zostanie zastąpione przez obiekt wywołujący.
    /// Wywołujące mogą zastąpić odwołanie tylko wtedy, gdy zatrzymały iterację i porzuciły potok iteratora po wyodrębnieniu źródła.
    ///
    /// Oznacza to, że adaptery iteratorów mogą polegać na źródle nie zmieniającym się podczas iteracji, ale nie mogą polegać na nim w swoich implementacjach Drop.
    ///
    /// Wdrożenie tej metody oznacza, że adaptery zrzekają się dostępu do swojego źródła tylko do celów prywatnych i mogą polegać tylko na gwarancjach utworzonych w oparciu o typy odbiorników metod.
    /// Brak ograniczonego dostępu wymaga również, aby adaptery utrzymywały publiczny interfejs API źródła, nawet jeśli mają dostęp do jego wewnętrznych elementów.
    ///
    /// Z kolei wywołujący muszą oczekiwać, że źródło będzie w dowolnym stanie zgodnym z jego publicznym interfejsem API, ponieważ adaptery znajdujące się między nim a źródłem mają ten sam dostęp.
    /// W szczególności adapter mógł zużywać więcej elementów niż jest to absolutnie konieczne.
    ///
    /// Ogólnym celem tych wymagań jest umożliwienie konsumentowi korzystania z rurociągu
    /// * cokolwiek pozostaje w źródle po zatrzymaniu iteracji
    /// * pamięć, która stała się nieużywana przez rozwijanie zużywającego iteratora
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Adapter iteratora, który generuje dane wyjściowe, o ile bazowy iterator wytwarza wartości `Result::Ok`.
///
///
/// W przypadku napotkania błędu iterator zatrzymuje się, a błąd zostaje zapisany.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Przetwarzaj podany iterator tak, jakby zwracał `T` zamiast `Result<T, _>`.
/// Wszelkie błędy zatrzymają wewnętrzny iterator, a ogólny wynik będzie błędem.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}