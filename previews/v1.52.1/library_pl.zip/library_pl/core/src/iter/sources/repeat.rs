use crate::iter::{FusedIterator, TrustedLen};

/// Tworzy nowy iterator, który w nieskończoność powtarza pojedynczy element.
///
/// Funkcja `repeat()` powtarza w kółko jedną wartość.
///
/// Nieskończone iteratory, takie jak `repeat()`, są często używane z adapterami takimi jak [`Iterator::take()`], aby uczynić je skończonymi.
///
/// Jeśli typ elementu iteratora, którego potrzebujesz, nie implementuje `Clone` lub jeśli nie chcesz przechowywać powtarzanego elementu w pamięci, możesz zamiast tego użyć funkcji [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::iter;
///
/// // numer cztery 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // tak, wciąż cztery
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Koniec z [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // tym ostatnim przykładem było zbyt wiele czwórek.Miejmy tylko cztery czworo.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... a teraz skończyliśmy
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Iterator, który w nieskończoność powtarza element.
///
/// Ten `struct` jest tworzony przez funkcję [`repeat()`].Więcej informacji można znaleźć w dokumentacji.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}