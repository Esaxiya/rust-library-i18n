use crate::fmt;

/// Tworzy nowy iterator, w którym każda iteracja wywołuje podane zamknięcie `F: FnMut() -> Option<T>`.
///
/// Pozwala to na stworzenie niestandardowego iteratora z dowolnym zachowaniem bez używania bardziej szczegółowej składni tworzenia dedykowanego typu i implementowania dla niego [`Iterator`] trait.
///
/// Należy zauważyć, że iterator `FromFn` nie przyjmuje założeń dotyczących zachowania zamknięcia, a zatem konserwatywnie nie implementuje [`FusedIterator`] ani nie zastępuje [`Iterator::size_hint()`] z jego domyślnego `(0, None)`.
///
///
/// Zamknięcie może używać przechwytywania i jego środowiska do śledzenia stanu w kolejnych iteracjach.W zależności od tego, jak używany jest iterator, może to wymagać określenia słowa kluczowego [`move`] na zamknięciu.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Zaimplementujmy ponownie iterator licznika z [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Zwiększ naszą liczbę.Dlatego zaczęliśmy od zera.
///     count += 1;
///
///     // Sprawdź, czy zakończyliśmy liczenie, czy nie.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iterator, w którym każda iteracja wywołuje podane zamknięcie `F: FnMut() -> Option<T>`.
///
/// Ten `struct` jest tworzony przez funkcję [`iter::from_fn()`].
/// Więcej informacji można znaleźć w dokumentacji.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}