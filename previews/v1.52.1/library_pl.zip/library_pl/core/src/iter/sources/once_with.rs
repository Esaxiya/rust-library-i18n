use crate::iter::{FusedIterator, TrustedLen};

/// Tworzy iterator, który leniwie generuje wartość dokładnie raz, wywołując podane zamknięcie.
///
/// Jest to powszechnie używane do adaptacji generatora pojedynczej wartości do [`chain()`] innych rodzajów iteracji.
/// Może masz iterator, który obejmuje prawie wszystko, ale potrzebujesz dodatkowego specjalnego przypadku.
/// Może masz funkcję, która działa na iteratorach, ale potrzebujesz przetworzyć tylko jedną wartość.
///
/// W przeciwieństwie do [`once()`], ta funkcja leniwie generuje wartość na żądanie.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::iter;
///
/// // jeden jest najbardziej samotną liczbą
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // tylko jeden, to wszystko, co otrzymujemy
/// assert_eq!(None, one.next());
/// ```
///
/// Łączenie w łańcuch z innym iteratorem.
/// Powiedzmy, że chcemy iterować po każdym pliku katalogu `.foo`, ale także po pliku konfiguracyjnym,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // musimy przekonwertować z iteratora DirEntry-s na iterator PathBufs, więc używamy map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // teraz nasz iterator tylko dla naszego pliku konfiguracyjnego
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // połącz oba iteratory razem w jeden duży iterator
/// let files = dirs.chain(config);
///
/// // to da nam wszystkie pliki w .foo oraz .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iterator, który zwraca pojedynczy element typu `A` przez zastosowanie dostarczonego zamknięcia `F: FnOnce() -> A`.
///
///
/// Ten `struct` jest tworzony przez funkcję [`once_with()`].
/// Więcej informacji można znaleźć w dokumentacji.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}