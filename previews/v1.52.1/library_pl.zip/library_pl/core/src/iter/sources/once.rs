use crate::iter::{FusedIterator, TrustedLen};

/// Tworzy iterator, który zwraca element dokładnie raz.
///
/// Jest to powszechnie używane do dostosowania pojedynczej wartości do [`chain()`] innych rodzajów iteracji.
/// Może masz iterator, który obejmuje prawie wszystko, ale potrzebujesz dodatkowego specjalnego przypadku.
/// Może masz funkcję, która działa na iteratorach, ale potrzebujesz przetworzyć tylko jedną wartość.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::iter;
///
/// // jeden jest najbardziej samotną liczbą
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // tylko jeden, to wszystko, co otrzymujemy
/// assert_eq!(None, one.next());
/// ```
///
/// Łączenie w łańcuch z innym iteratorem.
/// Powiedzmy, że chcemy iterować po każdym pliku katalogu `.foo`, ale także po pliku konfiguracyjnym,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // musimy przekonwertować z iteratora DirEntry-s na iterator PathBufs, więc używamy map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // teraz nasz iterator tylko dla naszego pliku konfiguracyjnego
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // połącz oba iteratory razem w jeden duży iterator
/// let files = dirs.chain(config);
///
/// // to da nam wszystkie pliki w .foo oraz .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iterator, który zwraca element dokładnie raz.
///
/// Ten `struct` jest tworzony przez funkcję [`once()`].Więcej informacji można znaleźć w dokumentacji.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}