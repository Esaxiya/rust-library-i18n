use crate::iter::{FusedIterator, TrustedLen};

/// Tworzy nowy iterator, który w nieskończoność powtarza elementy typu `A`, stosując dostarczone zamknięcie, repeater, `F: FnMut() -> A`.
///
/// Funkcja `repeat_with()` ciągle wywołuje przemiennik.
///
/// Nieskończone iteratory, takie jak `repeat_with()`, są często używane z adapterami takimi jak [`Iterator::take()`], aby uczynić je skończonymi.
///
/// Jeśli typ elementu iteratora, którego potrzebujesz, implementuje [`Clone`] i możesz zachować element źródłowy w pamięci, powinieneś zamiast tego użyć funkcji [`repeat()`].
///
///
/// Iterator wyprodukowany przez `repeat_with()` nie jest [`DoubleEndedIterator`].
/// Jeśli potrzebujesz `repeat_with()` do zwrotu [`DoubleEndedIterator`], otwórz problem GitHub wyjaśniający Twój przypadek użycia.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::iter;
///
/// // załóżmy, że mamy jakąś wartość typu innego niż `Clone` lub której nie chcemy jeszcze mieć w pamięci, ponieważ jest droga:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // szczególna wartość na zawsze:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Korzystanie z mutacji i dążenie do skończenia:
///
/// ```rust
/// use std::iter;
///
/// // Od zera do trzeciej potęgi dwóch:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... a teraz skończyliśmy
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iterator, który w nieskończoność powtarza elementy typu `A` poprzez zastosowanie dostarczonego zamknięcia `F: FnMut() -> A`.
///
///
/// Ten `struct` jest tworzony przez funkcję [`repeat_with()`].
/// Więcej informacji można znaleźć w dokumentacji.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}