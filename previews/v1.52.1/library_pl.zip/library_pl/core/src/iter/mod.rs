//! Komponowalna iteracja zewnętrzna.
//!
//! Jeśli znalazłeś jakąś kolekcję i musiałeś wykonać operację na elementach tej kolekcji, szybko natkniesz się na 'iterators'.
//! Iteratory są mocno wykorzystywane w idiomatycznym kodzie Rust, dlatego warto się z nimi zapoznać.
//!
//! Zanim wyjaśnimy więcej, porozmawiajmy o strukturze tego modułu:
//!
//! # Organization
//!
//! Ten moduł jest w dużej mierze zorganizowany według typu:
//!
//! * [Traits] są podstawową częścią: te traits definiują, jakie typy iteratorów istnieją i co można z nimi zrobić.Warto poświęcić trochę czasu na naukę metod tych traits.
//! * [Functions] zawierają przydatne sposoby tworzenia podstawowych iteratorów.
//! * [Structs] są często typami zwracanymi przez różne metody w traits tego modułu.Zwykle będziesz chciał przyjrzeć się metodzie, która tworzy `struct`, a nie samemu `struct`.
//! Aby uzyskać więcej informacji o tym, dlaczego, zobacz " [Implementing Iterator](#Implementing-iterator)`.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Otóż to!Przyjrzyjmy się iteratorom.
//!
//! # Iterator
//!
//! Sercem i duszą tego modułu jest [`Iterator`] trait.Rdzeń [`Iterator`] wygląda następująco:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iterator ma metodę [`next`], która po wywołaniu zwraca [`Option`]`<Item>`.
//! [`next`] zwróci [`Some(Item)`], o ile istnieją elementy, a gdy wszystkie zostaną wyczerpane, zwróci `None`, aby wskazać, że iteracja została zakończona.
//! Poszczególne iteratory mogą zdecydować się na wznowienie iteracji, więc ponowne wywołanie [`next`] może w końcu w pewnym momencie ponownie zacząć zwracać [`Some(Item)`] (na przykład zobacz [`TryIter`]).
//!
//!
//! Pełna definicja programu [`Iterator`] zawiera również szereg innych metod, ale są to metody domyślne, zbudowane na [`next`], więc otrzymujesz je za darmo.
//!
//! Iteratory również można komponować i często łączy się je ze sobą w celu wykonania bardziej złożonych form przetwarzania.Zobacz sekcję [Adapters](#adapters) poniżej, aby uzyskać więcej informacji.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Trzy formy iteracji
//!
//! Istnieją trzy typowe metody, które mogą tworzyć iteratory z kolekcji:
//!
//! * `iter()`, który iteruje po `&T`.
//! * `iter_mut()`, który iteruje po `&mut T`.
//! * `into_iter()`, który iteruje po `T`.
//!
//! W stosownych przypadkach różne rzeczy w bibliotece standardowej mogą implementować jedną lub więcej z trzech z nich.
//!
//! # Wdrażanie Iteratora
//!
//! Tworzenie własnego iteratora obejmuje dwa kroki: utworzenie `struct` do przechowywania stanu iteratora, a następnie zaimplementowanie [`Iterator`] dla tego `struct`.
//! Dlatego w tym module jest tak wiele struktur: jest jedna dla każdego iteratora i adaptera iteratora.
//!
//! Zróbmy iterator o nazwie `Counter`, który liczy od `1` do `5`:
//!
//! ```
//! // Najpierw struktura:
//!
//! /// Iterator liczący od jednego do pięciu
//! struct Counter {
//!     count: usize,
//! }
//!
//! // chcemy, aby nasza liczba zaczynała się od jednego, więc dodajmy metodę new(), aby pomóc.
//! // Nie jest to bezwzględnie konieczne, ale jest wygodne.
//! // Zauważ, że zaczynamy `count` od zera, zobaczymy dlaczego w implementacji `next()`'s poniżej.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Następnie wdrażamy `Iterator` dla naszego `Counter`:
//!
//! impl Iterator for Counter {
//!     // będziemy liczyć z usize
//!     type Item = usize;
//!
//!     // next() jest jedyną wymaganą metodą
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Zwiększ naszą liczbę.Dlatego zaczęliśmy od zera.
//!         self.count += 1;
//!
//!         // Sprawdź, czy zakończyliśmy liczenie, czy nie.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // A teraz możemy to wykorzystać!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Wywołanie [`next`] w ten sposób staje się powtarzalne.Rust ma konstrukcję, która może wywoływać [`next`] w twoim iteratorze, dopóki nie osiągnie `None`.Przejdźmy teraz do tego.
//!
//! Należy również zauważyć, że `Iterator` zapewnia domyślną implementację metod, takich jak `nth` i `fold`, które wewnętrznie wywołują `next`.
//! Możliwe jest jednak również napisanie niestandardowej implementacji metod, takich jak `nth` i `fold`, jeśli iterator może je obliczać wydajniej bez wywoływania `next`.
//!
//! # `for` pętle i `IntoIterator`
//!
//! Składnia pętli `for` w Rust jest właściwie cukrem dla iteratorów.Oto podstawowy przykład `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Spowoduje to wydrukowanie liczb od 1 do 5, każda w osobnym wierszu.Ale zauważysz tutaj coś: nigdy nie wywołaliśmy niczego w naszym vector, aby stworzyć iterator.Co daje?
//!
//! W standardowej bibliotece znajduje się trait do konwersji czegoś na iterator: [`IntoIterator`].
//! Ten trait ma jedną metodę, [`into_iter`], która przekształca rzecz implementującą [`IntoIterator`] w iterator.
//! Przyjrzyjmy się ponownie tej pętli `for` i temu, na co kompilator ją konwertuje:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust usuwa cukry do:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Najpierw wywołujemy `into_iter()` na wartości.Następnie dopasowujemy iterator, który powraca, wywołując [`next`] w kółko, aż zobaczymy `None`.
//! W tym momencie `break` wychodzi z pętli i kończymy iterację.
//!
//! Jest tu jeszcze jeden subtelny fragment: standardowa biblioteka zawiera interesującą implementację [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Innymi słowy, wszystkie [`Iteratory`] implementują [`IntoIterator`], po prostu zwracając się.Oznacza to dwie rzeczy:
//!
//! 1. Jeśli piszesz [`Iterator`], możesz go używać z pętlą `for`.
//! 2. Jeśli tworzysz kolekcję, zaimplementowanie dla niej [`IntoIterator`] pozwoli na użycie Twojej kolekcji z pętlą `for`.
//!
//! # Iterowanie przez odniesienie
//!
//! Ponieważ [`into_iter()`] przyjmuje `self` według wartości, użycie pętli `for` do iteracji po kolekcji zużywa tę kolekcję.Często możesz chcieć iterować kolekcję bez jej zużywania.
//! Wiele kolekcji oferuje metody, które zapewniają iteratory w odniesieniu do odwołań, umownie nazywane odpowiednio `iter()` i `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` nadal jest własnością tej funkcji.
//! ```
//!
//! Jeśli typ kolekcji `C` zapewnia `iter()`, zwykle implementuje również `IntoIterator` dla `&C`, z implementacją, która po prostu wywołuje `iter()`.
//! Podobnie kolekcja `C`, która zapewnia `iter_mut()`, zazwyczaj implementuje `IntoIterator` dla `&mut C`, delegując do `iter_mut()`.Umożliwia to wygodny skrót:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // tak samo jak `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // tak samo jak `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Chociaż wiele kolekcji oferuje `iter()`, nie wszystkie oferują `iter_mut()`.
//! Na przykład mutacja kluczy [`HashSet<T>`] lub [`HashMap<K, V>`] może wprowadzić kolekcję w niespójny stan, jeśli zmienią się skróty kluczy, więc te kolekcje oferują tylko `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funkcje, które pobierają [`Iterator`] i zwracają inny [`Iterator`], są często nazywane " adapterami iteratora`, ponieważ są formą " adaptera`
//! pattern'.
//!
//! Typowe adaptery iteratorów to [`map`], [`take`] i [`filter`].
//! Więcej informacji znajdziesz w ich dokumentacji.
//!
//! Jeśli adapter iteratora panics, iterator będzie w nieokreślonym (ale bezpiecznym dla pamięci) stanie.
//! Nie ma również gwarancji, że ten stan pozostanie taki sam we wszystkich wersjach Rust, więc należy unikać polegania na dokładnych wartościach zwracanych przez iterator, który spanikował.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratory (i iterator [adapters](#adapters)) są *leniwe*. Oznacza to, że samo utworzenie iteratora nie wymaga _do_ zbyt wiele. Tak naprawdę nic się nie dzieje, dopóki nie wywołasz [`next`].
//! Czasami jest to źródłem nieporozumień podczas tworzenia iteratora wyłącznie ze względu na jego skutki uboczne.
//! Na przykład metoda [`map`] wywołuje zamknięcie każdego elementu, po którym iteruje:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! To nie wypisze żadnych wartości, ponieważ stworzyliśmy tylko iterator, zamiast go używać.Kompilator ostrzeże nas przed tego typu zachowaniem:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Idiomatycznym sposobem napisania [`map`] dla jego efektów ubocznych jest użycie pętli `for` lub wywołanie metody [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Innym powszechnym sposobem oceny iteratora jest użycie metody [`collect`] do utworzenia nowej kolekcji.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratory nie muszą być skończone.Na przykład zakres otwarty jest nieskończoną iteratorem:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Często używa się adaptera iteratora [`take`], aby zamienić nieskończony iterator w skończony:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Spowoduje to wydrukowanie liczb od `0` do `4`, każda w osobnym wierszu.
//!
//! Należy pamiętać, że metody na nieskończonych iteratorach, nawet te, dla których wynik można określić matematycznie w skończonym czasie, mogą się nie zakończyć.
//! W szczególności metody takie jak [`min`], które w ogólnym przypadku wymagają przejścia przez każdy element w iteratorze, prawdopodobnie nie powrócą pomyślnie dla żadnych nieskończonych iteratorów.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // O nie!Nieskończona pętla!
//! // `ones.min()` powoduje nieskończoną pętlę, więc nie osiągniemy tego punktu!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;