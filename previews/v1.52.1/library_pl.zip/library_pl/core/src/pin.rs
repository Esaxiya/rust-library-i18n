//! Typy, które przypinają dane do ich lokalizacji w pamięci.
//!
//! Czasami przydatne jest posiadanie obiektów, które na pewno się nie poruszają, w tym sensie, że ich umieszczenie w pamięci się nie zmienia, a zatem można na nich polegać.
//! Doskonałym przykładem takiego scenariusza byłoby budowanie struktur odwołujących się do samego siebie, ponieważ przesunięcie obiektu ze wskaźnikami do siebie spowoduje ich unieważnienie, co może spowodować nieokreślone zachowanie.
//!
//! Na wysokim poziomie [`Pin<P>`] zapewnia, że wskaźnik dowolnego typu wskaźnika `P` ma stabilną lokalizację w pamięci, co oznacza, że nie można go przenieść w inne miejsce, a jego pamięć nie może zostać zwolniona, dopóki nie zostanie upuszczona.Mówimy, że pointee to "pinned".Sprawy stają się bardziej subtelne podczas omawiania typów, które łączą przypięte z nieprzypiętymi danymi;[see below](#projections-and-structural-pinning), aby uzyskać więcej informacji.
//!
//! Domyślnie wszystkie typy w Rust są ruchome.
//! Rust umożliwia przekazywanie wszystkich typów według wartości, a popularne typy inteligentnych wskaźników, takie jak [`Box<T>`] i `&mut T`, umożliwiają zastępowanie i przenoszenie wartości, które zawierają: możesz wyjść z [`Box<T>`] lub możesz użyć [`mem::swap`].
//! [`Pin<P>`] otacza wskaźnik typu `P`, więc [`Pin`]`<`[`Box`] `<T>>`działa podobnie jak zwykły
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`zostaje upuszczony, podobnie jak jego zawartość, a pamięć zostaje
//!
//! zwolniono.Podobnie, [`Pin`]`<&mut T>`jest bardzo podobne do `&mut T`.Jednak [`Pin<P>`] nie pozwala klientom faktycznie uzyskać [`Box<T>`] lub `&mut T` do przypiętych danych, co oznacza, że nie można używać operacji takich jak [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` potrzebuje `&mut T`, ale nie możemy go dostać.
//!     // Utknęliśmy, nie możemy zamienić treści tych odniesień.
//!     // Moglibyśmy użyć `Pin::get_unchecked_mut`, ale jest to niebezpieczne z jakiegoś powodu:
//!     // nie wolno nam go używać do przenoszenia rzeczy z `Pin`.
//! }
//! ```
//!
//! Warto powtórzyć, że [`Pin<P>`]*nie* zmienia faktu, że kompilator Rust uważa wszystkie typy za ruchome.[`mem::swap`] pozostaje wywoływalne dla każdego `T`.Zamiast tego [`Pin<P>`] zapobiega przenoszeniu pewnych *wartości*(wskazywanych przez wskaźniki zawarte w [`Pin<P>`]), uniemożliwiając wywołanie metod, które wymagają na nich `&mut T` (np. [`mem::swap`]).
//!
//! [`Pin<P>`] może być używany do zawijania dowolnego typu wskaźnika `P` i jako taki współdziała z [`Deref`] i [`DerefMut`].[`Pin<P>`], gdzie `P: Deref` należy traktować jako "`P`-style pointer" do przypiętego `P::Target`-a więc [`Pin`]`<`[`Box`] `<T>>`jest posiadanym wskaźnikiem do przypiętego `T`, a [`Pin`] `<` [`Rc`]`<T>>`jest wskaźnikiem liczonym jako odniesienie do przypiętego `T`.
//! Aby zapewnić poprawność, [`Pin<P>`] polega na implementacjach [`Deref`] i [`DerefMut`], aby nie wychodzić z ich parametru `self` i tylko zawsze zwracać wskaźnik do przypiętych danych, gdy są wywoływane na przypiętym wskaźniku.
//!
//! # `Unpin`
//!
//! Wiele typów można zawsze swobodnie przenosić, nawet gdy są przypięte, ponieważ nie wymagają stabilnego adresu.Obejmuje to wszystkie podstawowe typy (takie jak [`bool`], [`i32`] i odniesienia), a także typy składające się wyłącznie z tych typów.Typy, które nie dbają o przypinanie, wdrażają [`Unpin`] auto-trait, co anuluje efekt [`Pin<P>`].
//! W przypadku `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`i [`Box<T>`] działają identycznie, podobnie jak [`Pin`] `<&mut T>` i `&mut T`.
//!
//! Zauważ, że przypinanie i [`Unpin`] wpływają tylko na wskazany typ `P::Target`, a nie na sam typ wskaźnika `P`, który został zawinięty w [`Pin<P>`].Na przykład to, czy [`Box<T>`] jest [`Unpin`], nie ma wpływu na zachowanie [`Pin`]`<`[`Box`] `<T>>`(tutaj `T` jest typem wskazującym).
//!
//! # Przykład: struktura odwołująca się do samego siebie
//!
//! Zanim przejdziemy do dalszych szczegółów, aby wyjaśnić gwarancje i wybory związane z `Pin<T>`, omówimy kilka przykładów, w jaki sposób może być używany.
//! Zapraszam do [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Jest to struktura odwołująca się do siebie, ponieważ pole wycinka wskazuje na pole danych.
//! // Nie możemy o tym poinformować kompilatora za pomocą normalnego odwołania, ponieważ tego wzorca nie można opisać zwykłymi regułami wypożyczania.
//! //
//! // Zamiast tego używamy surowego wskaźnika, chociaż wiadomo, że nie jest zerowy, ponieważ wiemy, że wskazuje na łańcuch.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Aby upewnić się, że dane nie zostaną przeniesione po powrocie funkcji, umieszczamy je na stercie, na którym pozostaną przez cały okres istnienia obiektu, a jedynym sposobem na uzyskanie do nich dostępu byłoby użycie wskaźnika do niego.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // tworzymy wskaźnik tylko wtedy, gdy dane są na miejscu, w przeciwnym razie zostaną już przeniesione, zanim jeszcze zaczęliśmy
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // wiemy, że jest to bezpieczne, ponieważ modyfikacja pola nie powoduje przesunięcia całej struktury
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Wskaźnik powinien wskazywać właściwą lokalizację, o ile struktura nie została przesunięta.
//! //
//! // W międzyczasie możemy swobodnie poruszać wskaźnikiem.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Ponieważ nasz typ nie implementuje Unpin, kompilacja nie powiedzie się:
//! // niech mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Przykład: natrętna lista podwójnie połączona
//!
//! W przypadku natrętnej podwójnie połączonej listy kolekcja w rzeczywistości nie przydziela pamięci dla samych elementów.
//! Alokacja jest kontrolowana przez klientów, a elementy mogą żyć w ramce stosu, która żyje krócej niż kolekcja.
//!
//! Aby to zadziałało, każdy element ma na liście wskaźniki do swojego poprzednika i następcy.Elementy można dodawać tylko wtedy, gdy są przypięte, ponieważ przesuwanie elementów dookoła unieważniłoby wskaźniki.Co więcej, implementacja [`Drop`] połączonego elementu listy załatuje wskaźniki swojego poprzednika i następcy, aby usunąć się z listy.
//!
//! Co najważniejsze, musimy móc polegać na wywołaniu [`drop`].Gdyby element mógł zostać zwolniony lub w inny sposób unieważniony bez wywołania [`drop`], wskaźniki do niego z sąsiednich elementów stałyby się nieważne, co spowodowałoby uszkodzenie struktury danych.
//!
//! Dlatego też przypinanie jest objęte gwarancją związaną z [" drop`].
//!
//! # `Drop` guarantee
//!
//! Celem przypinania jest możliwość polegania na umieszczeniu niektórych danych w pamięci.
//! Aby to działało, nie tylko przenoszenie danych jest ograniczone;Zwolnienie, zmiana przeznaczenia lub inne unieważnienie pamięci używanej do przechowywania danych jest również ograniczone.
//! Konkretnie, w przypadku przypiętych danych musisz zachować niezmiennik, że *jego pamięć nie zostanie unieważniona ani zmieniona od momentu przypięcia do momentu wywołania [`drop`]*.Dopiero po powrocie [`drop`] lub panics pamięć może być ponownie wykorzystana.
//!
//! Pamięć może być "invalidated" przez zwolnienie alokacji, ale także przez zastąpienie [`Some(v)`] przez [`None`] lub wywołanie [`Vec::set_len`] do "kill" niektórych elementów z vector.Można go zmienić, używając [`ptr::write`] do nadpisania go bez wcześniejszego wywoływania destruktora.Żadne z tych działań nie jest dozwolone w przypadku przypiętych danych bez wywołania [`drop`].
//!
//! To jest dokładnie taka gwarancja, że natrętna lista połączona z poprzednią sekcją musi działać poprawnie.
//!
//! Zwróć uwagę, że ta gwarancja *nie* oznacza, że pamięć nie wycieka!Nadal jest całkowicie w porządku, aby nigdy nie dzwonić do [`drop`] na przypiętym elemencie (np. Nadal możesz dzwonić do [`mem::forget`] na [`Pin`]`<`[`Box`] `<T>>`).W przykładzie listy podwójnie połączonej ten element po prostu pozostałby na liście.Jednak nie możesz zwolnić lub ponownie użyć magazynu *bez wywołania [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Jeśli twój typ używa przypinania (tak jak w dwóch powyższych przykładach), musisz zachować ostrożność podczas implementacji [`Drop`].Funkcja [`drop`] przyjmuje `&mut self`, ale nazywa się to *, nawet jeśli Twój typ został wcześniej przypięty*!To tak, jakby kompilator automatycznie wywołał [`Pin::get_unchecked_mut`].
//!
//! To nigdy nie może spowodować problemu w bezpiecznym kodzie, ponieważ implementacja typu, który opiera się na przypinaniu, wymaga niebezpiecznego kodu, ale pamiętaj, że decydując się na użycie przypinania w swoim typie (na przykład zaimplementując jakąś operację na [`Pin`]`<&Self>`lub [`Pin`] `<&mut Self>`) ma również konsekwencje dla implementacji [`Drop`]: jeśli element Twojego typu mógł zostać przypięty, musisz traktować [`Drop`] jako niejawnie pobierające [`Pin`]`<&mut Ja>`.
//!
//!
//! Na przykład możesz zaimplementować `Drop` w następujący sposób:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` jest w porządku, ponieważ wiemy, że ta wartość nigdy nie jest używana ponownie po jej odrzuceniu.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Rzeczywisty kod upuszczenia jest tutaj.
//!         }
//!     }
//! }
//! ```
//!
//! Funkcja `inner_drop` ma typ, który [`drop`]*powinien* mieć, więc zapewnia to, że nie przypadkowo użyjesz `self`/`this` w sposób, który jest w konflikcie z przypinaniem.
//!
//! Co więcej, jeśli twój typ to `#[repr(packed)]`, kompilator automatycznie przesunie pola, aby móc je upuścić.Może to zrobić nawet w przypadku pól, które są dostatecznie wyrównane.W konsekwencji nie można używać przypinania z typem `#[repr(packed)]`.
//!
//! # Projekcje i przypinanie strukturalne
//!
//! Podczas pracy z przypiętymi strukturami pojawia się pytanie, w jaki sposób można uzyskać dostęp do pól tej struktury w metodzie, która pobiera tylko [`Pin`]`<&mut Struct>`.
//! Typowym podejściem jest napisanie metod pomocniczych (tak zwanych *projekcji*), które zamieniają [`Pin`]`<&mut Struct>`w odniesienie do pola, ale jaki typ powinno mieć to odniesienie?Czy to [`Pin`]`<&mut Field>`czy `&mut Field`?
//! To samo pytanie pojawia się w przypadku pól `enum`, a także przy rozważaniu typów container/wrapper, takich jak [`Vec<T>`], [`Box<T>`] lub [`RefCell<T>`].
//! (To pytanie dotyczy zarówno zmiennych, jak i współdzielonych odniesień, dla ilustracji używamy tutaj po prostu bardziej powszechnego przypadku zmiennych odniesień).
//!
//! Okazuje się, że do autora struktury danych należy decyzja, czy przypięta projekcja dla określonego pola zamieni [`Pin`]`<&mut Struct>`na [`Pin`] `<&mut Field>` lub `&mut Field`.Istnieją jednak pewne ograniczenia, a najważniejszym z nich jest *spójność*:
//! każde pole może być *albo* rzutowane na przypięte odniesienie *lub* może mieć usunięte przypinanie jako część projekcji.
//! Jeśli oba zostaną wykonane dla tego samego pola, prawdopodobnie nie będzie to rozsądne!
//!
//! Jako autor struktury danych możesz zdecydować dla każdego pola, czy przypiąć "propagates" do tego pola, czy nie.
//! Rozchodzące się przypinanie jest również nazywane "structural", ponieważ jest zgodne ze strukturą typu.
//! W kolejnych podrozdziałach opisujemy kwestie, które należy wziąć pod uwagę przy każdym z tych wyborów.
//!
//! ## Przypinanie *nie jest* strukturalne dla `field`
//!
//! Może się wydawać sprzeczne z intuicją, że pole przypiętej struktury może nie zostać przypięte, ale w rzeczywistości jest to najłatwiejszy wybór: jeśli [`Pin`]`<&mut Field>`nigdy nie zostanie utworzone, nic nie może pójść źle!Tak więc, jeśli zdecydujesz, że jakieś pole nie ma przypinania strukturalnego, musisz tylko upewnić się, że nigdy nie utworzysz przypiętego odniesienia do tego pola.
//!
//! Pola bez przypinania strukturalnego mogą mieć metodę rzutowania, która zamienia [`Pin`]`<&mut Struct>`na `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Jest to w porządku, ponieważ `field` nigdy nie jest uważany za przypięty.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Możesz także `impl Unpin for Struct`*, nawet jeśli* typ `field` jest inny niż [`Unpin`].To, co ten typ myśli o przypinaniu, nie ma znaczenia, jeśli nigdy nie zostanie utworzone żadne [`Pin`]`<&mut Field>`.
//!
//! ## Przypinanie *jest* strukturalne dla `field`
//!
//! Inną opcją jest zdecydowanie, że przypinanie to "structural" dla `field`, co oznacza, że jeśli struktura jest przypięta, to samo dotyczy pola.
//!
//! Pozwala to na napisanie projekcji, która tworzy [`Pin`]`<&mut Field>`, dając w ten sposób dowód, że pole jest przypięte:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // To jest w porządku, ponieważ `field` jest przypięty, gdy `self` jest.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Jednak przypinanie strukturalne wiąże się z kilkoma dodatkowymi wymaganiami:
//!
//! 1. Struct musi mieć wartość [`Unpin`] tylko wtedy, gdy wszystkie pola strukturalne mają wartość [`Unpin`].Jest to ustawienie domyślne, ale [`Unpin`] jest bezpiecznym trait, więc jako autor struktury Twoim obowiązkiem *nie* jest dodanie czegoś takiego jak `impl<T> Unpin for Struct<T>`.
//! (Zauważ, że dodanie operacji projekcji wymaga niebezpiecznego kodu, więc fakt, że [`Unpin`] jest bezpiecznym trait, nie łamie zasady, że musisz się o to martwić tylko wtedy, gdy używasz " niebezpiecznego`.)
//! 2. Destruktor struktury nie może usuwać pól strukturalnych ze swojego argumentu.To jest dokładny punkt, który został podniesiony w [previous section][drop-impl]: `drop` przyjmuje `&mut self`, ale struktura (a tym samym jej pola) mogła zostać przypięta wcześniej.
//!     Musisz zagwarantować, że nie przenosisz pola wewnątrz swojej implementacji [`Drop`].
//!     W szczególności, jak wyjaśniono wcześniej, oznacza to, że twoja struktura nie może *być*`#[repr(packed)]`.
//!     Zobacz tę sekcję, aby dowiedzieć się, jak napisać [`drop`] w taki sposób, aby kompilator mógł pomóc Ci uniknąć przypadkowego przerwania przypinania.
//! 3. Musisz upewnić się, że podtrzymujesz [`Drop` guarantee][drop-guarantee]:
//!     po przypięciu struktury pamięć zawierająca zawartość nie jest nadpisywana ani zwalniana bez wywołania destruktorów zawartości.
//!     Może to być trudne, o czym świadczy [`VecDeque<T>`]: destruktor [`VecDeque<T>`] może nie wywołać [`drop`] na wszystkich elementach, jeśli jeden z destruktorów panics.Narusza to gwarancję [`Drop`], ponieważ może prowadzić do cofnięcia przydziału elementów bez wywołania ich destruktora.([`VecDeque<T>`] nie ma występów kołków, więc nie powoduje to problemów.)
//! 4. Nie możesz oferować żadnych innych operacji, które mogłyby doprowadzić do przeniesienia danych z pól strukturalnych, gdy Twój typ jest przypięty.Na przykład, jeśli struktura zawiera [`Option<T>`] i istnieje operacja podobna do `take` z typem `fn(Pin<&mut Struct<T>>) -> Option<T>`, ta operacja może być użyta do przeniesienia `T` z przypiętego `Struct<T>`-co oznacza, że przypinanie nie może być strukturalne dla pola, które to posiada dane.
//!
//!     Aby uzyskać bardziej złożony przykład przenoszenia danych z typu przypiętego, wyobraź sobie, że [`RefCell<T>`] miałby metodę `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Następnie możemy wykonać następujące czynności:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Jest to katastrofalne, oznacza to, że możemy najpierw przypiąć zawartość [`RefCell<T>`] (używając `RefCell::get_pin_mut`), a następnie przenieść tę zawartość za pomocą mutowalnego odniesienia, które otrzymaliśmy później.
//!
//! ## Examples
//!
//! W przypadku typu takiego jak [`Vec<T>`] obie możliwości (przypinanie strukturalne lub nie) mają sens.
//! [`Vec<T>`] z przypinaniem strukturalnym może mieć metody `get_pin`/`get_pin_mut` do uzyskiwania przypiętych odniesień do elementów.Jednak może *nie* pozwolić na wywołanie [`pop`][Vec::pop] na przypiętym [`Vec<T>`], ponieważ spowodowałoby to przesunięcie (przypiętej strukturalnie) zawartości!Nie może też pozwolić [`push`][Vec::push], który mógłby ponownie przydzielić, a tym samym przenieść zawartość.
//!
//! [`Vec<T>`] bez przypinania strukturalnego może `impl<T> Unpin for Vec<T>`, ponieważ zawartość nigdy nie jest przypięta, a sam [`Vec<T>`] również jest w porządku, gdy można go przenosić.
//! W tym momencie przypinanie po prostu nie ma żadnego wpływu na vector.
//!
//! W bibliotece standardowej typy wskaźników generalnie nie mają przypinania strukturalnego, a zatem nie oferują przypinania rzutów.Dlatego `Box<T>: Unpin` dotyczy wszystkich `T`.
//! Ma to sens w przypadku typów wskaźników, ponieważ przesuwanie `Box<T>` w rzeczywistości nie przesuwa `T`: [`Box<T>`] można swobodnie przesuwać (aka `Unpin`), nawet jeśli `T` nie jest.W rzeczywistości nawet [`Pin`]`<`[`Box`] `<T>>`i [`Pin`] `<&mut T>` są zawsze [`Unpin`], z tego samego powodu: ich zawartość (`T`) jest przypięta, ale same wskaźniki można przenosić bez przenoszenia przypiętych danych.
//! Zarówno dla [`Box<T>`], jak i [`Pin`]`<`[`Box`] `<T>>`, to, czy treść jest przypięta, jest całkowicie niezależne od tego, czy wskaźnik jest przypięty, co oznacza, że przypinanie *nie* jest strukturalne.
//!
//! Podczas implementacji kombinatora [`Future`] zwykle będziesz potrzebować przypinania strukturalnego zagnieżdżonego futures, ponieważ musisz uzyskać przypięte odniesienia do nich, aby wywołać [`poll`].
//! Ale jeśli twój kombinator zawiera inne dane, które nie muszą być przypinane, możesz sprawić, że te pola nie będą strukturalne, a tym samym swobodnie uzyskaj do nich dostęp za pomocą zmiennego odniesienia, nawet jeśli masz tylko [`Pin`]`<&mut Self>`(takie jak we własnej implementacji [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Przypięty wskaźnik.
///
/// Jest to otoka wokół pewnego rodzaju wskaźnika, który sprawia, że wskaźnik "pin" ma swoją wartość na miejscu, zapobiegając przenoszeniu wartości, do której odwołuje się ten wskaźnik, chyba że implementuje [`Unpin`].
///
///
/// *Zobacz dokumentację [`pin` module], aby uzyskać wyjaśnienie dotyczące przypinania.*
///
/// [`pin` module]: self
///
// Note: wyprowadzenie `Clone` poniżej powoduje problemy, ponieważ można je zaimplementować
// `Clone` dla zmiennych odniesień.
// Aby uzyskać więcej informacji, zobacz <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Poniższe implementacje nie są wyprowadzane w celu uniknięcia problemów z poprawnością.
// `&self.pointer` nie powinny być dostępne dla niezaufanych implementacji trait.
//
// Aby uzyskać więcej informacji, zobacz <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Skonstruuj nowy `Pin<P>` wokół wskaźnika do pewnych danych typu, który implementuje [`Unpin`].
    ///
    /// W przeciwieństwie do `Pin::new_unchecked`, ta metoda jest bezpieczna, ponieważ wskaźnik `P` odwołuje się do typu [`Unpin`], co anuluje gwarancję przypięcia.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // BEZPIECZEŃSTWO: wskazywana wartość to `Unpin`, więc nie ma żadnych wymagań
        // wokół przypinania.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Rozpina ten `Pin<P>`, zwracając podstawowy wskaźnik.
    ///
    /// Wymaga to, aby dane wewnątrz tego `Pin` to [`Unpin`], abyśmy mogli zignorować niezmienniki przypinania podczas rozpakowywania.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Skonstruuj nowy `Pin<P>` wokół odniesienia do pewnych danych typu, który może implementować `Unpin` lub nie.
    ///
    /// Jeśli `pointer` odwołuje się do typu `Unpin`, zamiast tego należy użyć `Pin::new`.
    ///
    /// # Safety
    ///
    /// Ten konstruktor jest niebezpieczny, ponieważ nie możemy zagwarantować, że dane wskazywane przez `pointer` są przypięte, co oznacza, że dane nie zostaną przeniesione lub ich pamięć zostanie unieważniona, dopóki nie zostaną upuszczone.
    /// Jeśli skonstruowany `Pin<P>` nie gwarantuje, że dane, na które wskazuje `P`, są przypięte, jest to naruszenie kontraktu API i może prowadzić do nieokreślonego zachowania w późniejszych operacjach (safe).
    ///
    /// Korzystając z tej metody, tworzysz promise na temat implementacji `P::Deref` i `P::DerefMut`, jeśli istnieją.
    /// Co najważniejsze, nie mogą wyjść poza swoje argumenty `self`: `Pin::as_mut` i `Pin::as_ref` wywołają `DerefMut::deref_mut` i `Deref::deref`*na wskaźniku przypiętym* i będą oczekiwać, że te metody utrzymają niezmienniki przypinania.
    /// Co więcej, przez wywołanie tej metody promise, odwołanie do odwołania `P` nie zostanie ponownie usunięte;w szczególności nie może być możliwe uzyskanie `&mut P::Target`, a następnie wyjście poza to odniesienie (używając na przykład [`mem::swap`]).
    ///
    ///
    /// Na przykład wywołanie `Pin::new_unchecked` na `&'a mut T` jest niebezpieczne, ponieważ chociaż możesz go przypiąć na dany okres życia `'a`, nie masz kontroli nad tym, czy jest on przypięty po zakończeniu `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Powinno to oznaczać, że pointee `a` już nigdy się nie poruszy.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adres `a` został zmieniony na miejsce stosu `b`, więc `a` został przeniesiony, mimo że wcześniej go przypięliśmy!Naruszyliśmy umowę dotyczącą przypinania interfejsu API.
    /////
    /// }
    /// ```
    ///
    /// Wartość, raz przypięta, musi pozostać przypięta na zawsze (chyba że jej typ implementuje `Unpin`).
    ///
    /// Podobnie wywołanie `Pin::new_unchecked` na `Rc<T>` jest niebezpieczne, ponieważ mogą istnieć aliasy do tych samych danych, które nie podlegają ograniczeniom przypinania:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Powinno to oznaczać, że pointee już nigdy się nie poruszy.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Teraz, jeśli `x` był jedynym odniesieniem, mamy zmienne odniesienie do danych, które przypięliśmy powyżej, których moglibyśmy użyć do przeniesienia ich, jak widzieliśmy w poprzednim przykładzie.
    ///     // Naruszyliśmy umowę dotyczącą przypinania interfejsu API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Pobiera przypięte udostępnione odwołanie z tego przypiętego wskaźnika.
    ///
    /// Jest to ogólna metoda przejścia z `&Pin<Pointer<T>>` do `Pin<&T>`.
    /// Jest to bezpieczne, ponieważ w ramach kontraktu `Pin::new_unchecked` pointee nie może się poruszać po utworzeniu `Pin<Pointer<T>>`.
    ///
    /// "Malicious" implementacje `Pointer::Deref` są również wykluczone przez kontrakt `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // BEZPIECZEŃSTWO: patrz dokumentacja dotycząca tej funkcji
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Rozpina ten `Pin<P>`, zwracając podstawowy wskaźnik.
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna.Musisz zagwarantować, że po wywołaniu tej funkcji nadal będziesz traktować wskaźnik `P` jako przypięty, aby można było zachować niezmienniki typu `Pin`.
    /// Jeśli kod korzystający z wynikowego `P` nie zachowuje niezmienników przypinania, jest to naruszenie kontraktu API i może prowadzić do niezdefiniowanego zachowania w późniejszych operacjach (safe).
    ///
    ///
    /// Jeśli dane bazowe to [`Unpin`], należy zamiast tego użyć [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Pobiera przypięte mutowalne odwołanie z tego przypiętego wskaźnika.
    ///
    /// Jest to ogólna metoda przejścia z `&mut Pin<Pointer<T>>` do `Pin<&mut T>`.
    /// Jest to bezpieczne, ponieważ w ramach kontraktu `Pin::new_unchecked` pointee nie może się poruszać po utworzeniu `Pin<Pointer<T>>`.
    ///
    /// "Malicious" implementacje `Pointer::DerefMut` są również wykluczone przez kontrakt `Pin::new_unchecked`.
    ///
    /// Ta metoda jest przydatna podczas wykonywania wielu wywołań funkcji, które używają przypiętego typu.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // Zrób coś
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` zużywa `self`, więc ponownie wypożycz `Pin<&mut Self>` przez `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // BEZPIECZEŃSTWO: patrz dokumentacja dotycząca tej funkcji
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Przypisuje nową wartość do pamięci za przypiętym odwołaniem.
    ///
    /// Spowoduje to nadpisanie przypiętych danych, ale to jest w porządku: jego destruktor jest uruchamiany przed nadpisaniem, więc nie jest naruszana gwarancja przypinania.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Tworzy nowy pin, mapując wartość wewnętrzną.
    ///
    /// Na przykład, jeśli chcesz uzyskać `Pin` jakiegoś pola, możesz użyć tego, aby uzyskać dostęp do tego pola w jednej linii kodu.
    /// Jednak z "pinning projections" wiąże się kilka problemów;
    /// Więcej informacji na ten temat można znaleźć w dokumentacji [`pin` module].
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna.
    /// Musisz zagwarantować, że zwrócone dane nie zostaną przeniesione, dopóki wartość argumentu nie zostanie przesunięta (na przykład, ponieważ jest to jedno z pól tej wartości), a także, że nie wyjdziesz z argumentu, który otrzymujesz do funkcja wewnętrzna.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // BEZPIECZEŃSTWO: umowa bezpieczeństwa dla `new_unchecked` musi być
        // podtrzymane przez dzwoniącego.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Pobiera udostępnione odwołanie z pinezki.
    ///
    /// Jest to bezpieczne, ponieważ nie można wyjść z udostępnionego odniesienia.
    /// Może się wydawać, że występuje tu problem z wewnętrzną zmiennością: w rzeczywistości *jest* możliwe przeniesienie `T` z `&RefCell<T>`.
    /// Nie stanowi to jednak problemu, o ile nie istnieje również `Pin<&T>` wskazujący na te same dane, a `RefCell<T>` nie pozwala na utworzenie przypiętego odniesienia do jego zawartości.
    ///
    /// Więcej szczegółów można znaleźć w dyskusji na temat ["pinning projections"].
    ///
    /// Note: `Pin` implementuje również `Deref` do celu, którego można użyć do uzyskania dostępu do wartości wewnętrznej.
    /// Jednak `Deref` zapewnia tylko odniesienie, które trwa tak długo, jak pożyczka `Pin`, a nie żywotność samego `Pin`.
    /// Ta metoda umożliwia przekształcenie `Pin` w urządzenie referencyjne o takiej samej żywotności jak oryginalny `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Konwertuje `Pin<&mut T>` na `Pin<&T>` o tej samej żywotności.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Pobiera zmienne odniesienie do danych w tym `Pin`.
    ///
    /// Wymaga to, aby dane w tym `Pin` to `Unpin`.
    ///
    /// Note: `Pin` implementuje również `DerefMut` do danych, których można użyć do uzyskania dostępu do wartości wewnętrznej.
    /// Jednak `DerefMut` zapewnia tylko odniesienie, które trwa tak długo, jak pożyczka `Pin`, a nie żywotność samego `Pin`.
    ///
    /// Ta metoda umożliwia przekształcenie `Pin` w urządzenie referencyjne o takiej samej żywotności jak oryginalny `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Pobiera zmienne odniesienie do danych w tym `Pin`.
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna.
    /// Musisz zagwarantować, że nigdy nie przeniesiesz danych poza zmienne odniesienie, które otrzymasz, gdy wywołasz tę funkcję, aby można było zachować niezmienniki typu `Pin`.
    ///
    ///
    /// Jeśli dane bazowe to `Unpin`, należy zamiast tego użyć `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Skonstruuj nowy pin, mapując wartość wewnętrzną.
    ///
    /// Na przykład, jeśli chcesz uzyskać `Pin` jakiegoś pola, możesz użyć tego, aby uzyskać dostęp do tego pola w jednej linii kodu.
    /// Jednak z "pinning projections" wiąże się kilka problemów;
    /// Więcej informacji na ten temat można znaleźć w dokumentacji [`pin` module].
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna.
    /// Musisz zagwarantować, że zwrócone dane nie zostaną przeniesione, dopóki wartość argumentu nie zostanie przesunięta (na przykład, ponieważ jest to jedno z pól tej wartości), a także, że nie wyjdziesz z argumentu, który otrzymujesz do funkcja wewnętrzna.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // BEZPIECZEŃSTWO: dzwoniący jest odpowiedzialny za nieprzesuwanie
        // wartość z tego odniesienia.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // BEZPIECZEŃSTWO: ponieważ wartość `this` na pewno nie ma
        // został przeniesiony, to połączenie z `new_unchecked` jest bezpieczne.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Pobierz przypięte odwołanie z odwołania statycznego.
    ///
    /// Jest to bezpieczne, ponieważ `T` jest pożyczany na okres eksploatacji `'static`, który nigdy się nie kończy.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // BEZPIECZEŃSTWO: " pożyczka statyczna gwarantuje, że dane nie będą
        // moved/invalidated dopóki nie zostanie upuszczony (co nigdy nie jest).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Pobierz przypięte zmienne odwołanie ze statycznego, zmiennego odwołania.
    ///
    /// Jest to bezpieczne, ponieważ `T` jest pożyczany na okres eksploatacji `'static`, który nigdy się nie kończy.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // BEZPIECZEŃSTWO: " pożyczka statyczna gwarantuje, że dane nie będą
        // moved/invalidated dopóki nie zostanie upuszczony (co nigdy nie jest).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: oznacza to, że każdy plik impl z `CoerceUnsized`, który pozwala na wymuszanie
// typ, który implikuje `Deref<Target=impl !Unpin>` do typu, który implikuje `Deref<Target=Unpin>`, jest niewłaściwy.
// Każdy taki implik byłby prawdopodobnie nieuzasadniony z innych powodów, więc musimy po prostu uważać, aby nie pozwolić takim implikom wylądować w std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}