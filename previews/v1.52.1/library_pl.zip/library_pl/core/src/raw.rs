#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Zawiera definicje struktur dla układu typów wbudowanych kompilatora.
//!
//! Mogą być używane jako cele transmutacji w niebezpiecznym kodzie do bezpośredniego manipulowania surowymi reprezentacjami.
//!
//!
//! Ich definicja powinna zawsze być zgodna z ABI zdefiniowanym w `rustc_middle::ty::layout`.
//!

/// Reprezentacja obiektu trait, takiego jak `&dyn SomeTrait`.
///
/// Ta struktura ma taki sam układ jak typy takie jak `&dyn SomeTrait` i `Box<dyn AnotherTrait>`.
///
/// `TraitObject` gwarantuje dopasowanie układów, ale nie jest to typ obiektów trait (np. pola nie są bezpośrednio dostępne na `&dyn SomeTrait`) ani nie kontroluje tego układu (zmiana definicji nie zmieni układu `&dyn SomeTrait`).
///
/// Jest przeznaczony tylko do użycia przez niebezpieczny kod, który musi manipulować szczegółami niskiego poziomu.
///
/// Nie ma możliwości ogólnego odniesienia się do wszystkich obiektów trait, więc jedynym sposobem tworzenia wartości tego typu są funkcje takie jak [`std::mem::transmute`][transmute].
/// Podobnie, jedynym sposobem na utworzenie prawdziwego obiektu trait z wartości `TraitObject` jest `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Zsyntetyzowanie obiektu trait z niedopasowanymi typami-takimi, w których vtable nie odpowiada typowi wartości, na którą wskazuje wskaźnik danych-z dużym prawdopodobieństwem doprowadzi do niezdefiniowanego zachowania.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // przykład trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // niech kompilator utworzy obiekt trait
/// let object: &dyn Foo = &value;
///
/// // spójrz na surową reprezentację
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // wskaźnik danych to adres `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // skonstruuj nowy obiekt, wskazując na inny `i32`, uważając, aby użyć tabeli vtable `i32` z `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // powinno działać tak, jakbyśmy zbudowali obiekt trait bezpośrednio z `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}