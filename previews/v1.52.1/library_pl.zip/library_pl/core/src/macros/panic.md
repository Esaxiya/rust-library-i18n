Panics bieżący wątek.

Umożliwia to natychmiastowe zakończenie programu i przekazanie informacji zwrotnej osobie wywołującej program.
`panic!` powinno być używane, gdy program osiągnie stan niemożliwy do odzyskania.

To makro jest doskonałym sposobem na zapewnienie warunków w przykładowym kodzie i testach.
`panic!` jest ściśle powiązany z metodą `unwrap` wyliczeń [`Option`][ounwrap] i [`Result`][runwrap].
Obie implementacje wywołują `panic!`, gdy są ustawione na warianty [`None`] lub [`Err`].

Używając `panic!()`, można określić ładunek w postaci łańcucha, który jest tworzony przy użyciu składni [`format!`].
Ten ładunek jest używany podczas wstrzykiwania panic do wywołującego wątku Rust, powodując całkowite przeniesienie wątku na panic.

Zachowanie domyślnego `std` hook, tj
kod, który działa bezpośrednio po wywołaniu panic, to wydrukowanie ładunku komunikatu do `stderr` wraz z informacją file/line/column wywołania `panic!()`.

Możesz nadpisać panic hook używając [`std::panic::set_hook()`].
Wewnątrz hook do panic można uzyskać dostęp jako `&dyn Any + Send`, który zawiera `&str` lub `String` dla zwykłych wywołań `panic!()`.
Do panic z wartością innego innego typu można użyć [`panic_any`].

[`Result`] enum jest często lepszym rozwiązaniem do odzyskiwania po błędach niż użycie makra `panic!`.
Tego makra należy używać, aby uniknąć używania nieprawidłowych wartości, na przykład ze źródeł zewnętrznych.
Szczegółowe informacje na temat obsługi błędów można znaleźć w [book].

Zobacz także makro [`compile_error!`], do zgłaszania błędów podczas kompilacji.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Bieżąca realizacja

Jeśli główny wątek panics zakończy wszystkie twoje wątki i zakończy program z kodem `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





