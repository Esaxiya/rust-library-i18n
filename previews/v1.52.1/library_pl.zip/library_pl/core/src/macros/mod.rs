#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Rozwija się do `$crate::panic::panic_2015` lub `$crate::panic::panic_2021` w zależności od edycji dzwoniącego.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Potwierdza, że dwa wyrażenia są sobie równe (przy użyciu [`PartialEq`]).
///
/// Na panic to makro wydrukuje wartości wyrażeń wraz z ich reprezentacjami debugowania.
///
///
/// Podobnie jak [`assert!`], to makro ma drugą postać, w której można dostarczyć niestandardową wiadomość panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ponowne pożyczki poniżej są zamierzone.
                    // Bez nich miejsce na stos pożyczki jest inicjowane jeszcze przed porównaniem wartości, co prowadzi do zauważalnego spowolnienia.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ponowne pożyczki poniżej są zamierzone.
                    // Bez nich miejsce na stos pożyczki jest inicjowane jeszcze przed porównaniem wartości, co prowadzi do zauważalnego spowolnienia.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Twierdzi, że dwa wyrażenia nie są sobie równe (przy użyciu [`PartialEq`]).
///
/// Na panic to makro wydrukuje wartości wyrażeń wraz z ich reprezentacjami debugowania.
///
///
/// Podobnie jak [`assert!`], to makro ma drugą postać, w której można dostarczyć niestandardową wiadomość panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ponowne pożyczki poniżej są zamierzone.
                    // Bez nich miejsce na stos pożyczki jest inicjowane jeszcze przed porównaniem wartości, co prowadzi do zauważalnego spowolnienia.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ponowne pożyczki poniżej są zamierzone.
                    // Bez nich miejsce na stos pożyczki jest inicjowane jeszcze przed porównaniem wartości, co prowadzi do zauważalnego spowolnienia.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Potwierdza, że wyrażenie boolowskie to `true` w czasie wykonywania.
///
/// Spowoduje to wywołanie makra [`panic!`], jeśli podane wyrażenie nie może zostać ocenione na `true` w czasie wykonywania.
///
/// Podobnie jak [`assert!`], to makro ma również drugą wersję, w której można dostarczyć niestandardowy komunikat panic.
///
/// # Uses
///
/// W przeciwieństwie do [`assert!`], instrukcje `debug_assert!` są domyślnie włączone tylko w niezoptymalizowanych kompilacjach.
/// Zoptymalizowana kompilacja nie wykona instrukcji `debug_assert!`, chyba że `-C debug-assertions` zostanie przekazane do kompilatora.
/// To sprawia, że `debug_assert!` jest przydatny do sprawdzeń, które są zbyt drogie, aby były obecne w kompilacji wydania, ale mogą być pomocne podczas programowania.
/// Wynik rozszerzania `debug_assert!` jest zawsze sprawdzany jako typ.
///
/// Asercja niesprawdzona pozwala programowi w niespójnym stanie kontynuować działanie, co może mieć nieoczekiwane konsekwencje, ale nie wprowadza zagrożenia, o ile dzieje się to tylko w bezpiecznym kodzie.
///
/// Koszt wykonania asercji nie jest jednak ogólnie mierzalny.
/// Zastąpienie [`assert!`] `debug_assert!` jest zatem zalecane tylko po dokładnym profilowaniu, a co ważniejsze, tylko w bezpiecznym kodzie!
///
/// # Examples
///
/// ```
/// // komunikat panic dla tych twierdzeń jest podaną w postaci ciągu wartości podanego wyrażenia.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // bardzo prosta funkcja
/// debug_assert!(some_expensive_computation());
///
/// // potwierdzić za pomocą niestandardowej wiadomości
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Twierdzi, że dwa wyrażenia są sobie równe.
///
/// Na panic to makro wydrukuje wartości wyrażeń wraz z ich reprezentacjami debugowania.
///
/// W przeciwieństwie do [`assert_eq!`], instrukcje `debug_assert_eq!` są domyślnie włączone tylko w niezoptymalizowanych kompilacjach.
/// Zoptymalizowana kompilacja nie wykona instrukcji `debug_assert_eq!`, chyba że `-C debug-assertions` zostanie przekazane do kompilatora.
/// To sprawia, że `debug_assert_eq!` jest przydatny do sprawdzeń, które są zbyt drogie, aby były obecne w kompilacji wydania, ale mogą być pomocne podczas programowania.
///
/// Wynik rozszerzania `debug_assert_eq!` jest zawsze sprawdzany jako typ.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Twierdzi, że dwa wyrażenia nie są sobie równe.
///
/// Na panic to makro wydrukuje wartości wyrażeń wraz z ich reprezentacjami debugowania.
///
/// W przeciwieństwie do [`assert_ne!`], instrukcje `debug_assert_ne!` są domyślnie włączone tylko w niezoptymalizowanych kompilacjach.
/// Zoptymalizowana kompilacja nie wykona instrukcji `debug_assert_ne!`, chyba że `-C debug-assertions` zostanie przekazane do kompilatora.
/// To sprawia, że `debug_assert_ne!` jest przydatny do sprawdzeń, które są zbyt drogie, aby były obecne w kompilacji wydania, ale mogą być pomocne podczas programowania.
///
/// Wynik rozszerzania `debug_assert_ne!` jest zawsze sprawdzany jako typ.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Zwraca czy dane wyrażenie pasuje do któregokolwiek z podanych wzorców.
///
/// Podobnie jak w wyrażeniu `match`, po wzorcu może opcjonalnie następować `if` i wyrażenie ochronne, które ma dostęp do nazw powiązanych wzorcem.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Rozpakowuje wynik lub propaguje jego błąd.
///
/// Operator `?` został dodany w celu zastąpienia `try!` i powinien być używany w zamian.
/// Ponadto `try` jest słowem zastrzeżonym w Rust 2018, więc jeśli musisz go użyć, będziesz musiał użyć [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` pasuje do podanego [`Result`].W przypadku wariantu `Ok` wyrażenie przyjmuje wartość opakowanej wartości.
///
/// W przypadku wariantu `Err` pobiera błąd wewnętrzny.Następnie `try!` przeprowadza konwersję przy użyciu `From`.
/// Zapewnia to automatyczną konwersję między błędami specjalistycznymi a bardziej ogólnymi.
/// Wynikowy błąd jest następnie natychmiast zwracany.
///
/// Ze względu na wczesny zwrot `try!` może być używany tylko w funkcjach, które zwracają [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Preferowana metoda szybkiego zwracania błędów
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Poprzednia metoda szybkiego zwracania błędów
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Jest to równoważne z:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Zapisuje sformatowane dane w buforze.
///
/// To makro akceptuje 'writer', łańcuch formatu i listę argumentów.
/// Argumenty zostaną sformatowane zgodnie z określonym ciągiem formatu, a wynik zostanie przekazany do programu zapisującego.
/// Zapisujący może być dowolną wartością z metodą `write_fmt`;generalnie pochodzi to z implementacji [`fmt::Write`] lub [`io::Write`] trait.
/// Makro zwraca wszystko, co zwraca metoda `write_fmt`;zwykle [`fmt::Result`] lub [`io::Result`].
///
/// Zobacz [`std::fmt`], aby uzyskać więcej informacji na temat składni ciągu formatu.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Moduł może importować zarówno `std::fmt::Write`, jak i `std::io::Write` i wywoływać `write!` na obiektach implementujących oba, ponieważ obiekty zazwyczaj nie implementują obu.
///
/// Jednak moduł musi zaimportować kwalifikację traits, aby ich nazwy nie powodowały konfliktu:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // używa fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // używa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: To makro może być również używane w konfiguracjach `no_std`.
/// W konfiguracji `no_std` jesteś odpowiedzialny za szczegóły implementacji komponentów.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Zapisz sformatowane dane w buforze z dołączonym znakiem nowej linii.
///
/// Na wszystkich platformach nowa linia to sam znak LINE FEED (`\n`/`U+000A`) (bez dodatkowego CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Aby uzyskać więcej informacji, zobacz [`write!`].Aby uzyskać informacje na temat składni ciągu formatu, zobacz [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Moduł może importować zarówno `std::fmt::Write`, jak i `std::io::Write` i wywoływać `write!` na obiektach implementujących oba, ponieważ obiekty zazwyczaj nie implementują obu.
/// Jednak moduł musi zaimportować kwalifikację traits, aby ich nazwy nie powodowały konfliktu:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // używa fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // używa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Wskazuje nieosiągalny kod.
///
/// Jest to przydatne za każdym razem, gdy kompilator nie może określić, że jakiś kod jest nieosiągalny.Na przykład:
///
/// * Dopasuj broń do warunków gardy.
/// * Pętle, które kończą się dynamicznie.
/// * Iteratory, które kończą się dynamicznie.
///
/// Jeśli ustalenie, że kod jest nieosiągalny okaże się niepoprawne, program natychmiast kończy pracę z [`panic!`].
///
/// Niebezpiecznym odpowiednikiem tego makra jest funkcja [`unreachable_unchecked`], która po osiągnięciu kodu spowoduje niezdefiniowane zachowanie.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// To zawsze będzie [`panic!`].
///
/// # Examples
///
/// Ramiona meczowe:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // błąd kompilacji w przypadku wykomentowania
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // jedna z najgorszych implementacji x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Wskazuje niezaimplementowany kod przez panikę z komunikatem "not implemented".
///
/// Pozwala to Twojemu kodowi na sprawdzanie typu, co jest przydatne, jeśli tworzysz prototyp lub implementujesz trait, który wymaga wielu metod, z których nie planujesz używać wszystkich.
///
/// Różnica między `unimplemented!` i [`todo!`] polega na tym, że podczas gdy `todo!` przekazuje zamiar późniejszego zaimplementowania tej funkcji, a komunikat to "not yet implemented", `unimplemented!` nie zgłasza takich roszczeń.
/// Jego przesłaniem jest "not implemented".
/// Również niektóre IDE będą oznaczać `todo!` S.
///
/// # Panics
///
/// To zawsze będzie [`panic!`], ponieważ `unimplemented!` jest tylko skrótem dla `panic!` ze stałym, konkretnym komunikatem.
///
/// Podobnie jak `panic!`, to makro ma drugą formę do wyświetlania wartości niestandardowych.
///
/// # Examples
///
/// Powiedzmy, że mamy trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Chcemy zaimplementować `Foo` dla 'MyStruct', ale z jakiegoś powodu ma sens tylko implementacja funkcji `bar()`.
/// `baz()` i `qux()` nadal będą musiały zostać zdefiniowane w naszej implementacji `Foo`, ale możemy użyć `unimplemented!` w ich definicjach, aby umożliwić kompilację naszego kodu.
///
/// Nadal chcemy, aby nasz program przestał działać, jeśli zostaną osiągnięte niezaimplementowane metody.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // To nie ma sensu dla `baz` a `MyStruct`, więc nie mamy tutaj żadnej logiki.
/////
///         // Spowoduje to wyświetlenie "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Mamy tu trochę logiki, możemy dodać wiadomość do niezaimplementowanych!aby pokazać nasze zaniedbanie.
///         // Spowoduje to wyświetlenie: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Wskazuje niedokończony kod.
///
/// Może to być przydatne, jeśli tworzysz prototypy i chcesz tylko sprawdzić typ kodu.
///
/// Różnica między [`unimplemented!`] i `todo!` polega na tym, że podczas gdy `todo!` przekazuje zamiar późniejszego zaimplementowania tej funkcji, a komunikat to "not yet implemented", `unimplemented!` nie zgłasza takich roszczeń.
/// Jego przesłaniem jest "not implemented".
/// Również niektóre IDE będą oznaczać `todo!` S.
///
/// # Panics
///
/// To zawsze będzie [`panic!`].
///
/// # Examples
///
/// Oto przykład kodu w toku.Mamy trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Chcemy zaimplementować `Foo` na jednym z naszych typów, ale chcemy też najpierw pracować tylko na `bar()`.Aby nasz kod się skompilował, musimy zaimplementować `baz()`, więc możemy użyć `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementacja jest tutaj
///     }
///
///     fn baz(&self) {
///         // nie martwmy się na razie o implementacji baz()
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // nie używamy nawet baz(), więc to jest w porządku.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definicje wbudowanych makr.
///
/// Większość właściwości makr (stabilność, widoczność itp.) Pochodzi z kodu źródłowego, z wyjątkiem funkcji rozszerzających przekształcających wejścia makr w wyjścia, funkcje te są dostarczane przez kompilator.
///
///
pub(crate) mod builtin {

    /// Po napotkaniu powoduje niepowodzenie kompilacji z podanym komunikatem o błędzie.
    ///
    /// To makro powinno być używane, gdy crate używa strategii kompilacji warunkowej, aby zapewnić lepsze komunikaty o błędach dla błędnych warunków.
    ///
    /// Jest to forma [`panic!`] na poziomie kompilatora, ale emituje błąd podczas *kompilacji*, a nie w *czasie wykonywania*.
    ///
    /// # Examples
    ///
    /// Dwa takie przykłady to makra i środowiska `#[cfg]`.
    ///
    /// Emituj lepszy błąd kompilatora, jeśli makro ma przekazane nieprawidłowe wartości.
    /// Bez końcowego branch kompilator nadal emitowałby błąd, ale komunikat o błędzie nie wymieniałby dwóch prawidłowych wartości.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emituj błąd kompilatora, jeśli jedna z wielu funkcji jest niedostępna.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konstruuje parametry dla innych makr formatujących ciągi.
    ///
    /// To makro działa, przyjmując formatujący literał ciągu zawierający `{}` dla każdego przekazanego dodatkowego argumentu.
    /// `format_args!` przygotowuje dodatkowe parametry, aby zapewnić, że dane wyjściowe mogą być zinterpretowane jako ciąg i kanonizuje argumenty do jednego typu.
    /// Dowolna wartość, która implementuje [`Display`] trait, może zostać przekazana do `format_args!`, podobnie jak każda implementacja [`Debug`] może zostać przekazana do `{:?}` w ciągu formatującym.
    ///
    ///
    /// To makro generuje wartość typu [`fmt::Arguments`].Tę wartość można przekazać do makr w [`std::fmt`] w celu wykonania przydatnego przekierowania.
    /// Wszystkie inne makra formatujące ([`format!`], [`write!`], [`println!`], itd.) Są przez to zastępowane.
    /// `format_args!`, w przeciwieństwie do makr pochodnych unika alokacji sterty.
    ///
    /// Możesz użyć wartości [`fmt::Arguments`], którą `format_args!` zwraca w kontekstach `Debug` i `Display`, jak pokazano poniżej.
    /// Przykład pokazuje również, że `Debug` i `Display` formatują to samo: interpolowany ciąg formatu w `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Więcej informacji można znaleźć w dokumentacji [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// To samo co `format_args`, ale na końcu dodaje nową linię.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Sprawdza zmienną środowiskową w czasie kompilacji.
    ///
    /// To makro rozwinie się do wartości nazwanej zmiennej środowiskowej w czasie kompilacji, dając wyrażenie typu `&'static str`.
    ///
    ///
    /// Jeśli zmienna środowiskowa nie jest zdefiniowana, zostanie wyemitowany błąd kompilacji.
    /// Aby nie emitować błędu kompilacji, użyj zamiast tego makra [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Możesz dostosować komunikat o błędzie, przekazując ciąg jako drugi parametr:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Jeśli zmienna środowiskowa `documentation` nie jest zdefiniowana, pojawi się następujący błąd:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Opcjonalnie sprawdza zmienną środowiskową w czasie kompilacji.
    ///
    /// Jeśli nazwana zmienna środowiskowa jest obecna w czasie kompilacji, rozwinie się do wyrażenia typu `Option<&'static str>`, którego wartość to `Some` wartości zmiennej środowiskowej.
    /// Jeśli zmienna środowiskowa nie jest obecna, rozwinie się do `None`.
    /// Więcej informacji na temat tego typu można znaleźć w [`Option<T>`][Option].
    ///
    /// Podczas korzystania z tego makra nigdy nie jest emitowany błąd czasu kompilacji, niezależnie od tego, czy zmienna środowiskowa jest obecna, czy nie.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Łączy identyfikatory w jeden identyfikator.
    ///
    /// To makro pobiera dowolną liczbę identyfikatorów oddzielonych przecinkami i łączy je wszystkie w jeden, dając wyrażenie, które jest nowym identyfikatorem.
    /// Zwróć uwagę, że higiena sprawia, że to makro nie może przechwytywać zmiennych lokalnych.
    /// Ponadto, zgodnie z ogólną zasadą, makra są dozwolone tylko w pozycji pozycji, instrukcji lub wyrażenia.
    /// Oznacza to, że chociaż możesz używać tego makra do odwoływania się do istniejących zmiennych, funkcji lub modułów itp., Nie możesz za jego pomocą zdefiniować nowego.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (new, fun, name) { }//nie do użytku w ten sposób!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Łączy literały w statyczny wycinek ciągu.
    ///
    /// To makro pobiera dowolną liczbę literałów oddzielonych przecinkami, dając wyrażenie typu `&'static str`, które reprezentuje wszystkie literały połączone od lewej do prawej.
    ///
    ///
    /// Literały całkowite i zmiennoprzecinkowe są umieszczane w łańcuchach w celu ich konkatenacji.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Rozwija się do numeru wiersza, w którym został wywołany.
    ///
    /// W przypadku [`column!`] i [`file!`] te makra zapewniają programistom informacje debugowania dotyczące lokalizacji w źródle.
    ///
    /// Wyrażenie rozszerzone ma typ `u32` i jest oparte na 1, więc pierwsza linia w każdym pliku ma wartość 1, druga-2 itd.
    /// Jest to zgodne z komunikatami o błędach publikowanymi przez typowe kompilatory lub popularne edytory.
    /// Zwracany wiersz jest *niekoniecznie* wierszem samego wywołania `line!`, ale raczej pierwszym wywołaniem makra prowadzącym do wywołania makra `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Rozwija się do numeru kolumny, przy której został wywołany.
    ///
    /// W przypadku [`line!`] i [`file!`] te makra zapewniają programistom informacje debugowania dotyczące lokalizacji w źródle.
    ///
    /// Wyrażenie rozszerzone ma typ `u32` i jest oparte na 1, więc pierwsza kolumna w każdym wierszu ma wartość 1, druga-2 itd.
    /// Jest to zgodne z komunikatami o błędach publikowanymi przez typowe kompilatory lub popularne edytory.
    /// Zwracana kolumna jest *niekoniecznie* wierszem samego wywołania `column!`, ale raczej pierwszym wywołaniem makra prowadzącym do wywołania makra `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Rozwija się do nazwy pliku, w którym został wywołany.
    ///
    /// W przypadku [`line!`] i [`column!`] te makra zapewniają programistom informacje debugowania dotyczące lokalizacji w źródle.
    ///
    /// Wyrażenie rozszerzone ma typ `&'static str`, a zwrócony plik nie jest wywołaniem samego makra `file!`, ale raczej pierwszym wywołaniem makra prowadzącym do wywołania makra `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringify swoje argumenty.
    ///
    /// To makro zwróci wyrażenie typu `&'static str`, które jest stringifikacją wszystkich tokens przekazanych do makra.
    /// Nie nakłada się żadnych ograniczeń na składnię samego wywołania makra.
    ///
    /// Zauważ, że rozszerzone wyniki wejścia tokens mogą ulec zmianie w future.Powinieneś być ostrożny, jeśli polegasz na wynikach.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Zawiera plik zakodowany w formacie UTF-8 jako ciąg.
    ///
    /// Plik jest zlokalizowany względem bieżącego pliku (podobnie jak w przypadku znajdowania modułów).
    /// Podana ścieżka jest interpretowana w sposób specyficzny dla platformy w czasie kompilacji.
    /// Na przykład wywołanie ze ścieżką Windows zawierającą odwrotne ukośniki `\` nie skompilowałoby się poprawnie na Unix.
    ///
    ///
    /// To makro zwróci wyrażenie typu `&'static str`, które jest zawartością pliku.
    ///
    /// # Examples
    ///
    /// Załóżmy, że w tym samym katalogu znajdują się dwa pliki o następującej zawartości:
    ///
    /// Plik 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Plik 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Kompilacja 'main.rs' i uruchomienie wynikowego pliku binarnego spowoduje wydruk "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Zawiera plik jako odniesienie do tablicy bajtów.
    ///
    /// Plik jest zlokalizowany względem bieżącego pliku (podobnie jak w przypadku znajdowania modułów).
    /// Podana ścieżka jest interpretowana w sposób specyficzny dla platformy w czasie kompilacji.
    /// Na przykład wywołanie ze ścieżką Windows zawierającą odwrotne ukośniki `\` nie skompilowałoby się poprawnie na Unix.
    ///
    ///
    /// To makro zwróci wyrażenie typu `&'static [u8; N]`, które jest zawartością pliku.
    ///
    /// # Examples
    ///
    /// Załóżmy, że w tym samym katalogu znajdują się dwa pliki o następującej zawartości:
    ///
    /// Plik 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Plik 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Kompilacja 'main.rs' i uruchomienie wynikowego pliku binarnego spowoduje wydruk "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Rozwija się do ciągu, który reprezentuje bieżącą ścieżkę modułu.
    ///
    /// Bieżącą ścieżkę modułu można traktować jako hierarchię modułów prowadzącą z powrotem do crate root.
    /// Pierwszym zwracanym składnikiem ścieżki jest nazwa aktualnie kompilowanego crate.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Oblicza logiczne kombinacje flag konfiguracji w czasie kompilacji.
    ///
    /// Oprócz atrybutu `#[cfg]` to makro jest udostępniane, aby umożliwić obliczanie flag konfiguracji przez wyrażenie boolowskie.
    /// Często prowadzi to do mniejszej liczby duplikatów kodu.
    ///
    /// Składnia podana dla tego makra jest taka sama, jak w przypadku atrybutu [`cfg`].
    ///
    /// `cfg!`, w przeciwieństwie do `#[cfg]` nie usuwa żadnego kodu i ocenia tylko jako prawda lub fałsz.
    /// Na przykład wszystkie bloki w wyrażeniu if/else muszą być prawidłowe, gdy `cfg!` jest używany jako warunek, niezależnie od tego, co ocenia `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analizuje plik jako wyrażenie lub element zgodnie z kontekstem.
    ///
    /// Plik jest zlokalizowany względem bieżącego pliku (podobnie jak w przypadku znajdowania modułów).Podana ścieżka jest interpretowana w sposób specyficzny dla platformy w czasie kompilacji.
    /// Na przykład wywołanie ze ścieżką Windows zawierającą odwrotne ukośniki `\` nie skompilowałoby się poprawnie na Unix.
    ///
    /// Używanie tego makra jest często złym pomysłem, ponieważ jeśli plik jest analizowany jako wyrażenie, zostanie umieszczony w otaczającym go kodzie w niehigieniczny sposób.
    /// Może to spowodować, że zmienne lub funkcje będą się różnić od oczekiwanych w pliku, jeśli istnieją zmienne lub funkcje o tej samej nazwie w bieżącym pliku.
    ///
    ///
    /// # Examples
    ///
    /// Załóżmy, że w tym samym katalogu znajdują się dwa pliki o następującej zawartości:
    ///
    /// Plik 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Plik 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Kompilacja 'main.rs' i uruchomienie wynikowego pliku binarnego spowoduje wydruk "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Potwierdza, że wyrażenie boolowskie to `true` w czasie wykonywania.
    ///
    /// Spowoduje to wywołanie makra [`panic!`], jeśli podane wyrażenie nie może zostać ocenione na `true` w czasie wykonywania.
    ///
    /// # Uses
    ///
    /// Asercje są zawsze sprawdzane w kompilacjach debugowania i wydania i nie można ich wyłączyć.
    /// Zobacz [`debug_assert!`], aby uzyskać potwierdzenia, które nie są domyślnie włączone w kompilacjach wydania.
    ///
    /// Niebezpieczny kod może polegać na `assert!` w celu wymuszenia niezmienników czasu wykonywania, których naruszenie może prowadzić do zagrożenia.
    ///
    /// Inne przypadki użycia `assert!` obejmują testowanie i wymuszanie niezmienników czasu wykonywania w bezpiecznym kodzie (którego naruszenie nie może skutkować brakiem bezpieczeństwa).
    ///
    ///
    /// # Wiadomości niestandardowe
    ///
    /// To makro ma drugą postać, w której niestandardowy komunikat panic może być dostarczony z argumentami formatowania lub bez nich.
    /// Zobacz [`std::fmt`], aby zapoznać się ze składnią tego formularza.
    /// Wyrażenia używane jako argumenty formatu zostaną ocenione tylko wtedy, gdy potwierdzenie nie powiedzie się.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // komunikat panic dla tych twierdzeń jest podaną w postaci ciągu wartości podanego wyrażenia.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // bardzo prosta funkcja
    ///
    /// assert!(some_computation());
    ///
    /// // potwierdzić za pomocą niestandardowej wiadomości
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Montaż w linii.
    ///
    /// Przeczytaj [unstable book] do użytkowania.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Montaż liniowy w stylu LLVM.
    ///
    /// Przeczytaj [unstable book] do użytkowania.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Montaż liniowy na poziomie modułu.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Wydruki przekazały tokens na standardowe wyjście.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Włącza lub wyłącza funkcję śledzenia używaną do debugowania innych makr.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Makro atrybutu używane do stosowania makr pochodnych.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Makro atrybutu zastosowane do funkcji w celu przekształcenia jej w test jednostkowy.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Makro atrybutu zastosowane do funkcji, aby przekształcić ją w test porównawczy.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Szczegóły implementacji makr `#[test]` i `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Makro atrybutu zastosowane do statycznej, aby zarejestrować ją jako globalny alokator.
    ///
    /// Zobacz także [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Zachowuje element, do którego jest zastosowany, jeśli przekazana ścieżka jest dostępna, i usuwa ją w przeciwnym razie.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Rozwija wszystkie atrybuty `#[cfg]` i `#[cfg_attr]` w fragmencie kodu, do którego jest stosowany.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Niestabilne szczegóły implementacji kompilatora `rustc`, nie używaj.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Niestabilne szczegóły implementacji kompilatora `rustc`, nie używaj.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}