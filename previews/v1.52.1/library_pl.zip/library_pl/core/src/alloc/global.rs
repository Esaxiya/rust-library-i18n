use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Alokator pamięci, który można zarejestrować jako domyślną bibliotekę standardową za pomocą atrybutu `#[global_allocator]`.
///
/// Niektóre metody wymagają, aby blok pamięci był *aktualnie przydzielony* przez alokator.To znaczy że:
///
/// * adres początkowy dla tego bloku pamięci został wcześniej zwrócony przez poprzednie wywołanie metody alokacji, takiej jak `alloc`, i
///
/// * blok pamięci nie został następnie zwolniony, przy czym bloki są zwalniane albo przez przekazanie ich do metody zwalniania, takiej jak `dealloc`, lub przez przekazanie do metody ponownej alokacji, która zwraca wskaźnik niezerowy.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait to `unsafe` trait z wielu powodów, a firmy wdrażające muszą zapewnić przestrzeganie tych umów:
///
/// * Jest to niezdefiniowane zachowanie, jeśli rozwijają się globalne alokatory.To ograniczenie może zostać zniesione w future, ale obecnie panic z którejkolwiek z tych funkcji może prowadzić do braku bezpieczeństwa pamięci.
///
/// * `Layout` zapytania i obliczenia w ogóle muszą być poprawne.Osoby wywołujące to trait mogą polegać na kontraktach zdefiniowanych dla każdej metody, a implementatorzy muszą zapewnić, że takie kontrakty pozostaną prawdziwe.
///
/// * Nie można polegać na faktycznie zachodzących alokacjach, nawet jeśli w źródle istnieją jawne alokacje sterty.
/// Optymalizator może wykryć nieużywane alokacje, które może całkowicie wyeliminować lub przenieść na stos, a tym samym nigdy nie wywołać alokatora.
/// Optymalizator może ponadto założyć, że alokacja jest nieomylna, więc kod, który wcześniej zawodził z powodu awarii alokatora, może teraz nagle zadziałać, ponieważ optymalizator obejrzał potrzebę alokacji.
/// Mówiąc konkretniej, poniższy przykład kodu nie jest rozsądny, niezależnie od tego, czy Twój niestandardowy program przydzielający pozwala zliczać, ile przydziałów się wydarzyło.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Należy pamiętać, że wspomniane powyżej optymalizacje nie są jedyną optymalizacją, którą można zastosować.Zasadniczo nie można polegać na alokacjach sterty, jeśli można je usunąć bez zmiany zachowania programu.
///   To, czy alokacje mają miejsce, czy nie, nie jest częścią zachowania programu, nawet jeśli można to wykryć za pomocą alokatora, który śledzi alokacje przez drukowanie lub w inny sposób wywołujący skutki uboczne.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Przydziel pamięć zgodnie z opisem podanym `layout`.
    ///
    /// Zwraca wskaźnik do nowo przydzielonej pamięci lub null, aby wskazać błąd alokacji.
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna, ponieważ niezdefiniowane zachowanie może wystąpić, jeśli obiekt wywołujący nie upewni się, że `layout` ma niezerowy rozmiar.
    ///
    /// (Cechy podrzędne rozszerzenia mogą zapewniać bardziej szczegółowe granice zachowania, np. Gwarantować adres wartownika lub pusty wskaźnik w odpowiedzi na żądanie alokacji o zerowym rozmiarze).
    ///
    /// Przydzielony blok pamięci może, ale nie musi, zostać zainicjowany.
    ///
    /// # Errors
    ///
    /// Zwrócenie pustego wskaźnika oznacza, że pamięć jest wyczerpana lub `layout` nie spełnia ograniczeń rozmiaru lub wyrównania tego alokatora.
    ///
    /// Implementacje są zachęcane do zwracania wartości null w przypadku wyczerpania pamięci zamiast przerywania, ale nie jest to ścisłe wymaganie.
    /// (W szczególności:*legalne* jest zaimplementowanie tego trait na wierzchu bazowej natywnej biblioteki alokacji, która przerywa działanie po wyczerpaniu pamięci.)
    ///
    /// Klienci, którzy chcą przerwać obliczenia w odpowiedzi na błąd alokacji, są zachęcani do wywoływania funkcji [`handle_alloc_error`] zamiast bezpośredniego wywoływania `panic!` lub podobnego.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Zwolnij blok pamięci przy danym wskaźniku `ptr` z podanym `layout`.
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna, ponieważ niezdefiniowane zachowanie może wystąpić, jeśli obiekt wywołujący nie zapewni wszystkich następujących czynności:
    ///
    ///
    /// * `ptr` musi oznaczać blok pamięci aktualnie przydzielonej przez ten alokator,
    ///
    /// * `layout` musi mieć ten sam układ, który został użyty do przydzielenia tego bloku pamięci.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Zachowuje się jak `alloc`, ale zapewnia również, że przed zwróceniem zawartość jest ustawiona na zero.
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna z tych samych powodów, co `alloc`.
    /// Gwarantuje się jednak, że przydzielony blok pamięci zostanie zainicjowany.
    ///
    /// # Errors
    ///
    /// Zwrócenie pustego wskaźnika oznacza, że pamięć jest wyczerpana lub `layout` nie spełnia ograniczeń rozmiaru lub wyrównania alokatora, tak jak w `alloc`.
    ///
    /// Klienci, którzy chcą przerwać obliczenia w odpowiedzi na błąd alokacji, są zachęcani do wywoływania funkcji [`handle_alloc_error`] zamiast bezpośredniego wywoływania `panic!` lub podobnego.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać umowy dotyczącej bezpieczeństwa dla `alloc`.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // BEZPIECZEŃSTWO: ponieważ alokacja się powiodła, region z `ptr`
            // o rozmiarze `size` gwarantuje ważność do zapisu.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Zmniejsz lub powiększ blok pamięci do danego `new_size`.
    /// Blok jest opisywany przez podany wskaźnik `ptr` i `layout`.
    ///
    /// Jeśli zwraca to niezerowy wskaźnik, wówczas własność bloku pamięci, do którego odwołuje się `ptr`, została przeniesiona na ten alokator.
    /// Pamięć mogła zostać zwolniona lub nie, i powinna być uważana za bezużyteczną (chyba że została ponownie przesłana z powrotem do wywołującego przez wartość zwracaną przez tę metodę).
    /// Nowy blok pamięci jest przydzielany za pomocą `layout`, ale z `size` zaktualizowanym do `new_size`.
    /// Ten nowy układ powinien być używany podczas zwalniania nowego bloku pamięci za pomocą `dealloc`.
    /// Zakres `0..min(layout.size(), nowy_rozmiar) `nowego bloku pamięci ma te same wartości, co oryginalny blok.
    ///
    /// Jeśli ta metoda zwróci wartość null, wówczas własność bloku pamięci nie została przeniesiona do tego alokatora, a zawartość bloku pamięci pozostaje niezmieniona.
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna, ponieważ niezdefiniowane zachowanie może wystąpić, jeśli obiekt wywołujący nie zapewni wszystkich następujących czynności:
    ///
    /// * `ptr` muszą być aktualnie przydzielone przez ten alokator,
    ///
    /// * `layout` musi mieć ten sam układ, który został użyty do przydzielenia tego bloku pamięci,
    ///
    /// * `new_size` musi być większa od zera.
    ///
    /// * `new_size`, po zaokrągleniu w górę do najbliższej wielokrotności `layout.align()` nie może się przepełniać (tj. zaokrąglona wartość musi być mniejsza niż `usize::MAX`).
    ///
    /// (Cechy podrzędne rozszerzenia mogą zapewniać bardziej szczegółowe granice zachowania, np. Gwarantować adres wartownika lub pusty wskaźnik w odpowiedzi na żądanie alokacji o zerowym rozmiarze).
    ///
    /// # Errors
    ///
    /// Zwraca wartość null, jeśli nowy układ nie spełnia ograniczeń rozmiaru i wyrównania alokatora lub jeśli ponowna alokacja nie powiedzie się w inny sposób.
    ///
    /// Implementacje są zachęcane do zwracania wartości null w przypadku wyczerpania pamięci zamiast paniki lub przerywania pracy, ale nie jest to ścisłe wymaganie.
    /// (W szczególności:*legalne* jest zaimplementowanie tego trait na wierzchu bazowej natywnej biblioteki alokacji, która przerywa działanie po wyczerpaniu pamięci.)
    ///
    /// Klientów, którzy chcą przerwać obliczenia w odpowiedzi na błąd realokacji, zachęca się do wywoływania funkcji [`handle_alloc_error`] zamiast bezpośredniego wywoływania `panic!` lub podobnego.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // BEZPIECZEŃSTWO: dzwoniący musi upewnić się, że `new_size` nie przepełnia się.
        // `layout.align()` pochodzi z `Layout` i dlatego jest gwarantowany.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // BEZPIECZEŃSTWO: dzwoniący musi upewnić się, że `new_layout` jest większe od zera.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // BEZPIECZEŃSTWO: poprzednio przydzielony blok nie może pokrywać się z nowo przydzielonym blokiem.
            // Osoba dzwoniąca musi przestrzegać umowy dotyczącej bezpieczeństwa dla `dealloc`.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}