use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Chociaż ta funkcja jest używana w jednym miejscu, a jej implementacja mogłaby być wbudowana, poprzednie próby spowalniały rustc:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Układ bloku pamięci.
///
/// Instancja `Layout` opisuje określony układ pamięci.
/// Budujesz `Layout` jako dane wejściowe, które mają być przekazane alokatorowi.
///
/// Wszystkie układy mają skojarzony rozmiar i potęgę dwóch wyrównania.
///
/// (Zauważ, że układy *nie* muszą mieć niezerowego rozmiaru, mimo że `GlobalAlloc` wymaga, aby wszystkie żądania pamięci miały rozmiar niezerowy.
/// Wzywający musi albo upewnić się, że takie warunki są spełnione, użyć określonych alokatorów z mniejszymi wymaganiami lub użyć łagodniejszego interfejsu `Allocator`).
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // rozmiar żądanego bloku pamięci, mierzony w bajtach.
    size_: usize,

    // wyrównanie żądanego bloku pamięci, mierzone w bajtach.
    // zapewniamy, że jest to zawsze potęga dwóch, ponieważ wymagają tego interfejsy API, takie jak `posix_memalign`, i jest to rozsądne ograniczenie, które można narzucić konstruktorom układu.
    //
    //
    // (Jednak analogicznie nie wymagamy `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Konstruuje `Layout` z danego `size` i `align` lub zwraca `LayoutError`, jeśli nie jest spełniony którykolwiek z poniższych warunków:
    ///
    /// * `align` nie może wynosić zero,
    ///
    /// * `align` musi być potęgą dwóch,
    ///
    /// * `size`, po zaokrągleniu w górę do najbliższej wielokrotności `align` nie może się przepełniać (tj. zaokrąglona wartość musi być mniejsza lub równa `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (potęga-dwóch implikuje wyrównanie!=0)

        // Zaokrąglony rozmiar to:
        //   size_rounded_up=(rozmiar + align, 1)&! (align, 1);
        //
        // Wiemy z góry, że wyrównaj!=0.
        // Jeśli dodawanie (wyrównaj, 1) nie spowoduje przepełnienia, zaokrąglenie w górę będzie w porządku.
        //
        // I odwrotnie,&-masking z! (Align, 1) odejmuje tylko bity o najniższej kolejności.
        // Zatem jeśli wystąpi przepełnienie sumy,&-mask nie może odjąć wystarczająco dużo, aby cofnąć to przepełnienie.
        //
        //
        // Powyższe oznacza, że sprawdzenie przepełnienia sumy jest zarówno konieczne, jak i wystarczające.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // BEZPIECZEŃSTWO: warunki dla `from_size_align_unchecked` były takie
        // zaznaczone powyżej.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Tworzy układ, pomijając wszystkie sprawdzenia.
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna, ponieważ nie weryfikuje warunków wstępnych z [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // BEZPIECZEŃSTWO: dzwoniący musi upewnić się, że `align` jest większe od zera.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Minimalny rozmiar w bajtach dla bloku pamięci tego układu.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Minimalne wyrównanie bajtów dla bloku pamięci o tym układzie.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Konstruuje `Layout` odpowiedni do przechowywania wartości typu `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // BEZPIECZEŃSTWO: wyrównanie jest gwarantowane przez Rust jako potęga dwóch i
        // kombinacja rozmiar + wyrównaj na pewno zmieści się w naszej przestrzeni adresowej.
        // W rezultacie użyj tutaj niezaznaczonego konstruktora, aby uniknąć wstawiania kodu panics, jeśli nie jest wystarczająco dobrze zoptymalizowany.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Tworzy układ opisujący rekord, który może być użyty do przydzielenia struktury podkładowej dla `T` (która może być trait lub innym nietypowym typem, takim jak wycinek).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // BEZPIECZEŃSTWO: zobacz uzasadnienie w `new`, aby dowiedzieć się, dlaczego używa się niebezpiecznego wariantu
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Tworzy układ opisujący rekord, który może być użyty do przydzielenia struktury podkładowej dla `T` (która może być trait lub innym nietypowym typem, takim jak wycinek).
    ///
    /// # Safety
    ///
    /// Ta funkcja jest bezpieczna tylko wtedy, gdy są spełnione następujące warunki:
    ///
    /// - Jeśli `T` to `Sized`, wywołanie tej funkcji jest zawsze bezpieczne.
    /// - Jeśli niewymiarowy ogon `T` to:
    ///     - a [slice], wówczas długość końca wycinka musi być zintializowaną liczbą całkowitą, a rozmiar *całej wartości*(dynamiczna długość ogona + statyczny prefiks) musi mieścić się w `isize`.
    ///     - a [trait object], to część vtable wskaźnika musi wskazywać na prawidłową tabelę vtable dla typu `T` uzyskaną przez zmianę rozmiaru, a rozmiar *całej wartości*(dynamiczna długość ogona + statyczny prefiks) musi mieścić się w `isize`.
    ///
    ///     - (unstable) [extern type], to ta funkcja jest zawsze bezpieczna do wywołania, ale może panic lub w inny sposób zwrócić nieprawidłową wartość, ponieważ układ typu zewnętrznego nie jest znany.
    ///     Jest to takie samo zachowanie jak [`Layout::for_value`] w odniesieniu do ogona typu zewnętrznego.
    ///     - w przeciwnym razie nie wolno wywoływać tej funkcji.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // BEZPIECZEŃSTWO: przekazujemy dzwoniącemu warunki wstępne tych funkcji
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // BEZPIECZEŃSTWO: zobacz uzasadnienie w `new`, aby dowiedzieć się, dlaczego używa się niebezpiecznego wariantu
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Tworzy `NonNull`, który jest wiszący, ale dobrze dopasowany do tego układu.
    ///
    /// Zauważ, że wartość wskaźnika może potencjalnie reprezentować prawidłowy wskaźnik, co oznacza, że nie może być używana jako wartość wartownicza "not yet initialized".
    /// Typy, które leniwie alokują, muszą śledzić inicjalizację w inny sposób.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // BEZPIECZEŃSTWO: wyrównanie jest niezerowe
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Tworzy układ opisujący rekord, który może przechowywać wartość tego samego układu co `self`, ale jest również wyrównany do wyrównania `align` (mierzony w bajtach).
    ///
    ///
    /// Jeśli `self` już spełnia określone wyrównanie, zwraca `self`.
    ///
    /// Należy zauważyć, że ta metoda nie dodaje żadnego wypełnienia do całkowitego rozmiaru, niezależnie od tego, czy zwrócony układ ma inne wyrównanie.
    /// Innymi słowy, jeśli `K` ma rozmiar 16, `K.align_to(32)`*nadal* będzie miał rozmiar 16.
    ///
    /// Zwraca błąd, jeśli kombinacja `self.size()` i danego `align` narusza warunki wymienione w [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Zwraca ilość wypełnienia, którą musimy wstawić po `self`, aby upewnić się, że następujący adres spełni `align` (mierzony w bajtach).
    ///
    /// np. jeśli `self.size()` to 9, to `self.padding_needed_for(4)` zwraca 3, ponieważ jest to minimalna liczba bajtów wypełnienia wymagana do uzyskania adresu wyrównanego do 4 (zakładając, że odpowiedni blok pamięci zaczyna się od adresu wyrównanego do 4).
    ///
    ///
    /// Wartość zwracana przez tę funkcję nie ma znaczenia, jeśli `align` nie jest potęgą dwóch.
    ///
    /// Zauważ, że użyteczność zwróconej wartości wymaga, aby `align` było mniejsze lub równe wyrównaniu adresu początkowego dla całego przydzielonego bloku pamięci.Jednym ze sposobów spełnienia tego ograniczenia jest zapewnienie `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Wartość zaokrąglona w górę to:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // a następnie zwracamy różnicę wypełnienia: `len_rounded_up - len`.
        //
        // Używamy arytmetyki modularnej w całym:
        //
        // 1. align ma wartość> 0, więc align, 1 jest zawsze poprawne.
        //
        // 2.
        // `len + align - 1` może przepełnić co najwyżej `align - 1`, więc&-mask z `!(align - 1)` zapewni, że w przypadku przepełnienia `len_rounded_up` sam będzie równy 0.
        //
        //    Zatem zwrócone wypełnienie, po dodaniu do `len`, daje 0, co w trywialny sposób spełnia wyrównanie `align`.
        //
        // (Oczywiście próby alokacji bloków pamięci, których rozmiar i wypełnienie są przepełnione w powyższy sposób powinny i tak spowodować, że alokator i tak zwróci błąd).
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Tworzy układ, zaokrąglając rozmiar tego układu do wielokrotności wyrównania układu.
    ///
    ///
    /// Jest to równoważne dodaniu wyniku `padding_needed_for` do bieżącego rozmiaru układu.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // To nie może się przepełnić.Cytowanie z niezmiennika układu:
        // > `size`, po zaokrągleniu w górę do najbliższej wielokrotności `align`,
        // > nie może się przepełniać (tj. zaokrąglona wartość musi być mniejsza niż
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Tworzy układ opisujący rekord dla wystąpień `n` `self`, z odpowiednią ilością wypełnienia między nimi, aby zapewnić, że każdemu wystąpieniu zostanie nadany żądany rozmiar i wyrównanie.
    /// Po pomyślnym zakończeniu zwraca `(k, offs)`, gdzie `k` to układ tablicy, a `offs` to odległość między początkiem każdego elementu tablicy.
    ///
    /// W przypadku przepełnienia arytmetycznego zwraca `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // To nie może się przepełnić.Cytowanie z niezmiennika układu:
        // > `size`, po zaokrągleniu w górę do najbliższej wielokrotności `align`,
        // > nie może się przepełniać (tj. zaokrąglona wartość musi być mniejsza niż
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // BEZPIECZEŃSTWO: self.align jest już znany jako poprawny i przydzielony_rozmiar został
        // już wyściełane.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Tworzy układ opisujący rekord dla `self`, po którym następuje `next`, w tym wszelkie niezbędne dopełnienie, aby zapewnić prawidłowe wyrównanie `next`, ale *bez dopełnienia końcowego*.
    ///
    /// Aby dopasować układ reprezentacji C do `repr(C)`, po rozszerzeniu układu o wszystkie pola należy wywołać `pad_to_align`.
    /// (Nie ma możliwości dopasowania domyślnego układu reprezentacji Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Należy zauważyć, że wyrównanie wynikowego układu będzie maksymalne z wyrównania `self` i `next`, aby zapewnić wyrównanie obu części.
    ///
    /// Zwraca `Ok((k, offset))`, gdzie `k` to układ połączonego rekordu, a `offset` to względne położenie w bajtach początku `next` osadzonego w połączonym rekordzie (zakładając, że sam rekord zaczyna się od przesunięcia 0).
    ///
    ///
    /// W przypadku przepełnienia arytmetycznego zwraca `LayoutError`.
    ///
    /// # Examples
    ///
    /// Aby obliczyć układ struktury `#[repr(C)]` i przesunięcia pól z układów ich pól:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Pamiętaj, aby sfinalizować z `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // sprawdź, czy to działa
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Tworzy układ opisujący rekord dla instancji `n` `self`, bez dopełnienia między każdą instancją.
    ///
    /// Zauważ, że w przeciwieństwie do `repeat`, `repeat_packed` nie gwarantuje, że powtarzające się wystąpienia `self` zostaną prawidłowo wyrównane, nawet jeśli dana instancja `self` jest prawidłowo wyrównana.
    /// Innymi słowy, jeśli układ zwrócony przez `repeat_packed` jest używany do alokacji tablicy, nie ma gwarancji, że wszystkie elementy w tablicy zostaną odpowiednio wyrównane.
    ///
    /// W przypadku przepełnienia arytmetycznego zwraca `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Tworzy układ opisujący rekord dla `self`, po którym następuje `next` bez dodatkowego wypełnienia między nimi.
    /// Ponieważ nie jest wstawiane wypełnienie, wyrównanie `next` jest nieistotne i nie jest *w ogóle* włączane do wynikowego układu.
    ///
    ///
    /// W przypadku przepełnienia arytmetycznego zwraca `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Tworzy układ opisujący rekord dla `[T; n]`.
    ///
    /// W przypadku przepełnienia arytmetycznego zwraca `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parametry podane `Layout::from_size_align` lub innemu konstruktorowi `Layout` nie spełniają jego udokumentowanych ograniczeń.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (potrzebujemy tego do dalszego implantu błędu trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}