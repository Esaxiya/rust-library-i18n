//! Interfejsy API alokacji pamięci

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Błąd `AllocError` wskazuje na błąd alokacji, który może być spowodowany wyczerpaniem zasobów lub czymś złym podczas łączenia podanych argumentów wejściowych z tym alokatorem.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (potrzebujemy tego do dalszego implantu błędu trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Implementacja `Allocator` może przydzielać, powiększać, zmniejszać i zwalniać dowolne bloki danych opisane przez [`Layout`][].
///
/// `Allocator` jest zaprojektowany do implementacji w ZST, referencjach lub inteligentnych wskaźnikach, ponieważ posiadanie alokatora, takiego jak `MyAlloc([u8; N])`, nie może być przenoszone bez aktualizacji wskaźników do przydzielonej pamięci.
///
/// W przeciwieństwie do [`GlobalAlloc`][], w `Allocator` dozwolone są alokacje o zerowej wielkości.
/// Jeśli bazowy alokator nie obsługuje tego (jak jemalloc) lub zwraca pusty wskaźnik (na przykład `libc::malloc`), musi to zostać przechwycone przez implementację.
///
/// ### Aktualnie przydzielona pamięć
///
/// Niektóre metody wymagają, aby blok pamięci był *aktualnie przydzielony* przez alokator.To znaczy że:
///
/// * adres początkowy dla tego bloku pamięci został wcześniej zwrócony przez [`allocate`], [`grow`] lub [`shrink`] i
///
/// * blok pamięci nie został następnie zwolniony, gdzie bloki są zwalniane bezpośrednio przez przekazanie do [`deallocate`] lub zostały zmienione przez przekazanie do [`grow`] lub [`shrink`], który zwraca `Ok`.
///
/// Jeśli `grow` lub `shrink` zwróciły `Err`, przekazany wskaźnik pozostaje ważny.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Dopasowanie pamięci
///
/// Niektóre metody wymagają, aby układ *pasował* do bloku pamięci.
/// To, co oznacza dla układu "fit" blok pamięci (lub równoważnie, dla bloku pamięci dla układu "fit"), to, że muszą spełniać następujące warunki:
///
/// * Blok musi mieć takie samo wyrównanie jak [`layout.align()`] i
///
/// * Podany [`layout.size()`] musi mieścić się w zakresie `min ..= max`, gdzie:
///   - `min` jest rozmiarem układu ostatnio używanego do przydzielenia bloku, a
///   - `max` to ostatni rzeczywisty rozmiar zwrócony z [`allocate`], [`grow`] lub [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Bloki pamięci zwrócone z alokatora muszą wskazywać na prawidłową pamięć i zachować swoją ważność do momentu usunięcia instancji i wszystkich jej klonów,
///
/// * klonowanie lub przenoszenie alokatora nie może unieważniać bloków pamięci zwróconych z tego alokatora.Sklonowany alokator musi zachowywać się jak ten sam alokator, a
///
/// * każdy wskaźnik do bloku pamięci, który jest [*currently allocated*], może być przekazany do dowolnej innej metody alokatora.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Próbuje przydzielić blok pamięci.
    ///
    /// Po pomyślnym zakończeniu zwraca [`NonNull<[u8]>`][NonNull] spełniający gwarancje rozmiaru i wyrównania `layout`.
    ///
    /// Zwracany blok może mieć większy rozmiar niż określony przez `layout.size()` i może, ale nie musi, mieć zainicjowaną zawartość.
    ///
    /// # Errors
    ///
    /// Zwracanie `Err` oznacza, że pamięć jest wyczerpana lub `layout` nie spełnia ograniczeń rozmiaru lub wyrównania alokatora.
    ///
    /// Implementacje są zachęcane do zwracania `Err` w przypadku wyczerpania pamięci zamiast paniki lub przerywania pracy, ale nie jest to ścisłe wymaganie.
    /// (W szczególności:*legalne* jest zaimplementowanie tego trait na wierzchu bazowej natywnej biblioteki alokacji, która przerywa działanie po wyczerpaniu pamięci.)
    ///
    /// Klienci, którzy chcą przerwać obliczenia w odpowiedzi na błąd alokacji, są zachęcani do wywoływania funkcji [`handle_alloc_error`] zamiast bezpośredniego wywoływania `panic!` lub podobnego.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Zachowuje się jak `allocate`, ale zapewnia również, że zwracana pamięć jest inicjalizowana na zero.
    ///
    /// # Errors
    ///
    /// Zwracanie `Err` oznacza, że pamięć jest wyczerpana lub `layout` nie spełnia ograniczeń rozmiaru lub wyrównania alokatora.
    ///
    /// Implementacje są zachęcane do zwracania `Err` w przypadku wyczerpania pamięci zamiast paniki lub przerywania pracy, ale nie jest to ścisłe wymaganie.
    /// (W szczególności:*legalne* jest zaimplementowanie tego trait na wierzchu bazowej natywnej biblioteki alokacji, która przerywa działanie po wyczerpaniu pamięci.)
    ///
    /// Klienci, którzy chcą przerwać obliczenia w odpowiedzi na błąd alokacji, są zachęcani do wywoływania funkcji [`handle_alloc_error`] zamiast bezpośredniego wywoływania `panic!` lub podobnego.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // BEZPIECZEŃSTWO: `alloc` zwraca prawidłowy blok pamięci
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Zwalnia pamięć, do której odwołuje się `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` musi oznaczać blok pamięci [*currently allocated*] za pośrednictwem tego alokatora, a
    /// * `layout` musi [*fit*] tego bloku pamięci.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Próbuje rozszerzyć blok pamięci.
    ///
    /// Zwraca nowe [`NonNull<[u8]>`][NonNull] zawierające wskaźnik i rzeczywisty rozmiar przydzielonej pamięci.Wskaźnik nadaje się do przechowywania danych opisanych przez `new_layout`.
    /// Aby to osiągnąć, alokator może rozszerzyć alokację, do której odwołuje się `ptr`, aby dopasować ją do nowego układu.
    ///
    /// Jeśli to zwróci `Ok`, wówczas własność bloku pamięci, do którego odwołuje się `ptr`, została przeniesiona na ten alokator.
    /// Pamięć mogła zostać zwolniona lub nie, i powinna być uważana za bezużyteczną, chyba że została ponownie przesłana do obiektu wywołującego za pośrednictwem wartości zwracanej tej metody.
    ///
    /// Jeśli ta metoda zwraca `Err`, wówczas własność bloku pamięci nie została przeniesiona do tego alokatora, a zawartość bloku pamięci pozostaje niezmieniona.
    ///
    /// # Safety
    ///
    /// * `ptr` musi oznaczać blok pamięci [*currently allocated*] za pośrednictwem tego alokatora.
    /// * `old_layout` musi [*fit*] tego bloku pamięci (argument `new_layout` nie musi do niego pasować).
    /// * `new_layout.size()` musi być większa lub równa `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Zwraca `Err`, jeśli nowy układ nie spełnia rozmiaru alokatora i ograniczeń wyrównania alokatora lub jeśli wzrost nie powiedzie się w inny sposób.
    ///
    /// Implementacje są zachęcane do zwracania `Err` w przypadku wyczerpania pamięci zamiast paniki lub przerywania pracy, ale nie jest to ścisłe wymaganie.
    /// (W szczególności:*legalne* jest zaimplementowanie tego trait na wierzchu bazowej natywnej biblioteki alokacji, która przerywa działanie po wyczerpaniu pamięci.)
    ///
    /// Klienci, którzy chcą przerwać obliczenia w odpowiedzi na błąd alokacji, są zachęcani do wywoływania funkcji [`handle_alloc_error`] zamiast bezpośredniego wywoływania `panic!` lub podobnego.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // BEZPIECZEŃSTWO: ponieważ `new_layout.size()` musi być większe lub równe
        // `old_layout.size()`, zarówno stary, jak i nowy przydział pamięci są ważne dla odczytów i zapisów dla `old_layout.size()` bajtów.
        // Ponadto, ponieważ stara alokacja nie została jeszcze cofnięta, nie może pokrywać się z `new_ptr`.
        // Dzięki temu połączenie z `copy_nonoverlapping` jest bezpieczne.
        // Osoba dzwoniąca musi przestrzegać umowy dotyczącej bezpieczeństwa dla `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Zachowuje się jak `grow`, ale zapewnia również, że nowa zawartość jest ustawiona na zero przed zwróceniem.
    ///
    /// Blok pamięci będzie zawierał następującą zawartość po udanym wywołaniu
    /// `grow_zeroed`:
    ///   * Bajty `0..old_layout.size()` są zachowywane z pierwotnego przydziału.
    ///   * Bajty `old_layout.size()..old_size` zostaną zachowane lub wyzerowane, w zależności od implementacji alokatora.
    ///   `old_size` odnosi się do rozmiaru bloku pamięci przed wywołaniem `grow_zeroed`, który może być większy niż rozmiar, który był pierwotnie żądany, gdy został przydzielony.
    ///   * Bajty `old_size..new_size` są zerowane.`new_size` odnosi się do rozmiaru bloku pamięci zwróconego przez wywołanie `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` musi oznaczać blok pamięci [*currently allocated*] za pośrednictwem tego alokatora.
    /// * `old_layout` musi [*fit*] tego bloku pamięci (argument `new_layout` nie musi do niego pasować).
    /// * `new_layout.size()` musi być większa lub równa `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Zwraca `Err`, jeśli nowy układ nie spełnia rozmiaru alokatora i ograniczeń wyrównania alokatora lub jeśli wzrost nie powiedzie się w inny sposób.
    ///
    /// Implementacje są zachęcane do zwracania `Err` w przypadku wyczerpania pamięci zamiast paniki lub przerywania pracy, ale nie jest to ścisłe wymaganie.
    /// (W szczególności:*legalne* jest zaimplementowanie tego trait na wierzchu bazowej natywnej biblioteki alokacji, która przerywa działanie po wyczerpaniu pamięci.)
    ///
    /// Klienci, którzy chcą przerwać obliczenia w odpowiedzi na błąd alokacji, są zachęcani do wywoływania funkcji [`handle_alloc_error`] zamiast bezpośredniego wywoływania `panic!` lub podobnego.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // BEZPIECZEŃSTWO: ponieważ `new_layout.size()` musi być większe lub równe
        // `old_layout.size()`, zarówno stary, jak i nowy przydział pamięci są ważne dla odczytów i zapisów dla `old_layout.size()` bajtów.
        // Ponadto, ponieważ stara alokacja nie została jeszcze cofnięta, nie może pokrywać się z `new_ptr`.
        // Dzięki temu połączenie z `copy_nonoverlapping` jest bezpieczne.
        // Osoba dzwoniąca musi przestrzegać umowy dotyczącej bezpieczeństwa dla `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Próbuje zmniejszyć blok pamięci.
    ///
    /// Zwraca nowe [`NonNull<[u8]>`][NonNull] zawierające wskaźnik i rzeczywisty rozmiar przydzielonej pamięci.Wskaźnik nadaje się do przechowywania danych opisanych przez `new_layout`.
    /// Aby to osiągnąć, alokator może zmniejszyć przydział, do którego odwołuje się `ptr`, aby dopasować go do nowego układu.
    ///
    /// Jeśli to zwróci `Ok`, wówczas własność bloku pamięci, do którego odwołuje się `ptr`, została przeniesiona na ten alokator.
    /// Pamięć mogła zostać zwolniona lub nie, i powinna być uważana za bezużyteczną, chyba że została ponownie przesłana do obiektu wywołującego za pośrednictwem wartości zwracanej tej metody.
    ///
    /// Jeśli ta metoda zwraca `Err`, wówczas własność bloku pamięci nie została przeniesiona do tego alokatora, a zawartość bloku pamięci pozostaje niezmieniona.
    ///
    /// # Safety
    ///
    /// * `ptr` musi oznaczać blok pamięci [*currently allocated*] za pośrednictwem tego alokatora.
    /// * `old_layout` musi [*fit*] tego bloku pamięci (argument `new_layout` nie musi do niego pasować).
    /// * `new_layout.size()` musi być mniejsza lub równa `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Zwraca `Err`, jeśli nowy układ nie spełnia ograniczeń rozmiaru i wyrównania alokatora lub jeśli zmniejszanie w inny sposób nie powiedzie się.
    ///
    /// Implementacje są zachęcane do zwracania `Err` w przypadku wyczerpania pamięci zamiast paniki lub przerywania pracy, ale nie jest to ścisłe wymaganie.
    /// (W szczególności:*legalne* jest zaimplementowanie tego trait na wierzchu bazowej natywnej biblioteki alokacji, która przerywa działanie po wyczerpaniu pamięci.)
    ///
    /// Klienci, którzy chcą przerwać obliczenia w odpowiedzi na błąd alokacji, są zachęcani do wywoływania funkcji [`handle_alloc_error`] zamiast bezpośredniego wywoływania `panic!` lub podobnego.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // BEZPIECZEŃSTWO: ponieważ `new_layout.size()` musi być mniejszy lub równy
        // `old_layout.size()`, zarówno stary, jak i nowy przydział pamięci są ważne dla odczytów i zapisów dla `new_layout.size()` bajtów.
        // Ponadto, ponieważ stara alokacja nie została jeszcze cofnięta, nie może pokrywać się z `new_ptr`.
        // Dzięki temu połączenie z `copy_nonoverlapping` jest bezpieczne.
        // Osoba dzwoniąca musi przestrzegać umowy dotyczącej bezpieczeństwa dla `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Tworzy adapter "by reference" dla tej instancji `Allocator`.
    ///
    /// Zwrócony adapter również implementuje `Allocator` i po prostu go pożyczy.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać umowy dotyczącej bezpieczeństwa
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać umowy dotyczącej bezpieczeństwa
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać umowy dotyczącej bezpieczeństwa
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać umowy dotyczącej bezpieczeństwa
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}