//! Funkcje wewnętrzne kompilatora.
//!
//! Odpowiednie definicje znajdują się w `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Odpowiednie implementacje const są w `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: wszelkie zmiany w stałości elementów wewnętrznych należy omówić z zespołem językowym.
//! Obejmuje to zmiany stabilności stałej.
//!
//! Aby uczynić wewnętrzną użyteczną w czasie kompilacji, należy skopiować implementację z <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> do `compiler/rustc_mir/src/interpret/intrinsics.rs` i dodać `#[rustc_const_unstable(feature = "foo", issue = "01234")]` do wewnętrznej.
//!
//!
//! Jeśli ma być używany element wewnętrzny z `const fn` z atrybutem `rustc_const_stable`, atrybut wewnętrzny również musi mieć wartość `rustc_const_stable`.
//! Taka zmiana nie powinna odbywać się bez konsultacji T-lang, ponieważ wprowadza ona do języka funkcję, której nie można powielić w kodzie użytkownika bez wsparcia kompilatora.
//!
//! # Volatiles
//!
//! Niestabilne elementy wewnętrzne zapewniają operacje przeznaczone do działania w pamięci I/O, które na pewno nie zostaną ponownie uporządkowane przez kompilator w innych niestabilnych elementach wewnętrznych.Zobacz dokumentację LLVM na [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Wewnętrzne elementy atomowe zapewniają typowe operacje atomowe na słowach maszynowych z wieloma możliwymi porządkami pamięci.Stosują się do tej samej semantyki co C++ 11.Zobacz dokumentację LLVM na [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Szybkie przypomnienie o zamawianiu pamięci:
//!
//! * Zdobądź, barierę dla zdobycia zamka.Kolejne odczyty i zapisy odbywają się za szlabanem.
//! * Zwolnij, bariera do zwolnienia blokady.Poprzedzające odczyty i zapisy odbywają się przed barierą.
//! * Sekwencyjnie spójne, sekwencyjnie spójne operacje są wykonywane w kolejności.Jest to standardowy tryb pracy z typami atomowymi i jest odpowiednikiem `volatile` w Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Importy te służą do uproszczenia łączy w dokumentach
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // BEZPIECZEŃSTWO: patrz `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Uwaga, te elementy wewnętrzne przyjmują surowe wskaźniki, ponieważ mutują pamięć z aliasem, co nie jest poprawne ani dla `&`, ani dla `&mut`.
    //

    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange`, przekazując [`Ordering::SeqCst`] jako parametry `success` i `failure`.
    ///
    /// Na przykład, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange`, przekazując [`Ordering::Acquire`] jako parametry `success` i `failure`.
    ///
    /// Na przykład, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange`, przekazując [`Ordering::Release`] jako `success` i [`Ordering::Relaxed`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange`, przekazując [`Ordering::AcqRel`] jako `success` i [`Ordering::Acquire`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange`, przekazując [`Ordering::Relaxed`] jako parametry `success` i `failure`.
    ///
    /// Na przykład, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange`, przekazując [`Ordering::SeqCst`] jako `success` i [`Ordering::Relaxed`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange`, przekazując [`Ordering::SeqCst`] jako `success` i [`Ordering::Acquire`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange`, przekazując [`Ordering::Acquire`] jako `success` i [`Ordering::Relaxed`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange`, przekazując [`Ordering::AcqRel`] jako `success` i [`Ordering::Relaxed`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange_weak`, przekazując [`Ordering::SeqCst`] jako parametry `success` i `failure`.
    ///
    /// Na przykład, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange_weak`, przekazując [`Ordering::Acquire`] jako parametry `success` i `failure`.
    ///
    /// Na przykład, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange_weak`, przekazując [`Ordering::Release`] jako `success` i [`Ordering::Relaxed`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange_weak`, przekazując [`Ordering::AcqRel`] jako `success` i [`Ordering::Acquire`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange_weak`, przekazując [`Ordering::Relaxed`] jako parametry `success` i `failure`.
    ///
    /// Na przykład, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange_weak`, przekazując [`Ordering::SeqCst`] jako `success` i [`Ordering::Relaxed`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange_weak`, przekazując [`Ordering::SeqCst`] jako `success` i [`Ordering::Acquire`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange_weak`, przekazując [`Ordering::Acquire`] jako `success` i [`Ordering::Relaxed`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Przechowuje wartość, jeśli bieżąca wartość jest taka sama jak wartość `old`.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `compare_exchange_weak`, przekazując [`Ordering::AcqRel`] jako `success` i [`Ordering::Relaxed`] jako parametry `failure`.
    /// Na przykład, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Ładuje bieżącą wartość wskaźnika.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `load`, przekazując [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Ładuje bieżącą wartość wskaźnika.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `load`, przekazując [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Ładuje bieżącą wartość wskaźnika.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `load`, przekazując [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Przechowuje wartość w określonej lokalizacji pamięci.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `store`, przekazując [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Przechowuje wartość w określonej lokalizacji pamięci.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `store`, przekazując [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Przechowuje wartość w określonej lokalizacji pamięci.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `store`, przekazując [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Przechowuje wartość w określonej lokalizacji pamięci, zwracając starą wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `swap`, przekazując [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Przechowuje wartość w określonej lokalizacji pamięci, zwracając starą wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `swap`, przekazując [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Przechowuje wartość w określonej lokalizacji pamięci, zwracając starą wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `swap`, przekazując [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Przechowuje wartość w określonej lokalizacji pamięci, zwracając starą wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `swap`, przekazując [`Ordering::AcqRel`] jako `order`.
    /// Na przykład, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Przechowuje wartość w określonej lokalizacji pamięci, zwracając starą wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `swap`, przekazując [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Dodaje do bieżącej wartości, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_add`, przekazując [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dodaje do bieżącej wartości, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_add`, przekazując [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dodaje do bieżącej wartości, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_add`, przekazując [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dodaje do bieżącej wartości, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_add`, przekazując [`Ordering::AcqRel`] jako `order`.
    /// Na przykład, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dodaje do bieżącej wartości, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_add`, przekazując [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Odejmij od bieżącej wartości, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_sub`, przekazując [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odejmij od bieżącej wartości, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_sub`, przekazując [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odejmij od bieżącej wartości, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_sub`, przekazując [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odejmij od bieżącej wartości, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_sub`, przekazując [`Ordering::AcqRel`] jako `order`.
    /// Na przykład, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odejmij od bieżącej wartości, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_sub`, przekazując [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitowo i z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_and`, przekazując [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo i z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_and`, przekazując [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo i z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_and`, przekazując [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo i z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_and`, przekazując [`Ordering::AcqRel`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo i z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_and`, przekazując [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitowo nand z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typie [`AtomicBool`] za pomocą metody `fetch_nand`, przekazując [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo nand z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typie [`AtomicBool`] za pomocą metody `fetch_nand`, przekazując [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo nand z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typie [`AtomicBool`] za pomocą metody `fetch_nand`, przekazując [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo nand z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typie [`AtomicBool`] za pomocą metody `fetch_nand`, przekazując [`Ordering::AcqRel`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo nand z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typie [`AtomicBool`] za pomocą metody `fetch_nand`, przekazując [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitowo lub z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_or`, przekazując [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo lub z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_or`, przekazując [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo lub z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_or`, przekazując [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo lub z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_or`, przekazując [`Ordering::AcqRel`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowo lub z bieżącą wartością, zwracając poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_or`, przekazując [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitowe xor z bieżącą wartością, zwracające poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_xor`, przekazując [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowe xor z bieżącą wartością, zwracające poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_xor`, przekazując [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowe xor z bieżącą wartością, zwracające poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_xor`, przekazując [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowe xor z bieżącą wartością, zwracające poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_xor`, przekazując [`Ordering::AcqRel`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitowe xor z bieżącą wartością, zwracające poprzednią wartość.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach [`atomic`] za pomocą metody `fetch_xor`, przekazując [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksymalna z bieżącą wartością przy użyciu podpisanego porównania.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna dla typów całkowitych ze znakiem [`atomic`] za pośrednictwem metody `fetch_max`, przekazując [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksymalna z bieżącą wartością przy użyciu podpisanego porównania.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w przypadku typów całkowitych ze znakiem [`atomic`] za pośrednictwem metody `fetch_max`, przekazując [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksymalna z bieżącą wartością przy użyciu podpisanego porównania.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna dla typów całkowitych ze znakiem [`atomic`] za pośrednictwem metody `fetch_max`, przekazując [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksymalna z bieżącą wartością przy użyciu podpisanego porównania.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna dla typów całkowitych ze znakiem [`atomic`] za pośrednictwem metody `fetch_max`, przekazując [`Ordering::AcqRel`] jako `order`.
    /// Na przykład, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum z aktualną wartością.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna dla typów całkowitych ze znakiem [`atomic`] za pośrednictwem metody `fetch_max`, przekazując [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum z bieżącą wartością przy użyciu podpisanego porównania.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna dla typów całkowitych ze znakiem [`atomic`] za pośrednictwem metody `fetch_min`, przekazując [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum z bieżącą wartością przy użyciu podpisanego porównania.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna dla typów całkowitych ze znakiem [`atomic`] za pośrednictwem metody `fetch_min`, przekazując [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum z bieżącą wartością przy użyciu podpisanego porównania.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna dla typów całkowitych ze znakiem [`atomic`] za pośrednictwem metody `fetch_min`, przekazując [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum z bieżącą wartością przy użyciu podpisanego porównania.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna dla typów całkowitych ze znakiem [`atomic`] za pośrednictwem metody `fetch_min`, przekazując [`Ordering::AcqRel`] jako `order`.
    /// Na przykład, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum z bieżącą wartością przy użyciu podpisanego porównania.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna dla typów całkowitych ze znakiem [`atomic`] za pośrednictwem metody `fetch_min`, przekazując [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum z bieżącą wartością przy użyciu porównania bez znaku.
    ///
    /// Ustabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach liczb całkowitych bez znaku [`atomic`] za pośrednictwem metody `fetch_min` przez przekazanie [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum z bieżącą wartością przy użyciu porównania bez znaku.
    ///
    /// Ustabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach liczb całkowitych bez znaku [`atomic`] za pośrednictwem metody `fetch_min` przez przekazanie [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum z bieżącą wartością przy użyciu porównania bez znaku.
    ///
    /// Ustabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach liczb całkowitych bez znaku [`atomic`] za pośrednictwem metody `fetch_min` przez przekazanie [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum z bieżącą wartością przy użyciu porównania bez znaku.
    ///
    /// Ustabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach liczb całkowitych bez znaku [`atomic`] za pośrednictwem metody `fetch_min` przez przekazanie [`Ordering::AcqRel`] jako `order`.
    /// Na przykład, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum z bieżącą wartością przy użyciu porównania bez znaku.
    ///
    /// Ustabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach liczb całkowitych bez znaku [`atomic`] za pośrednictwem metody `fetch_min` przez przekazanie [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum z bieżącą wartością przy użyciu porównania bez znaku.
    ///
    /// Ustabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach liczb całkowitych bez znaku [`atomic`] za pośrednictwem metody `fetch_max` przez przekazanie [`Ordering::SeqCst`] jako `order`.
    /// Na przykład, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum z bieżącą wartością przy użyciu porównania bez znaku.
    ///
    /// Ustabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach liczb całkowitych bez znaku [`atomic`] za pośrednictwem metody `fetch_max` przez przekazanie [`Ordering::Acquire`] jako `order`.
    /// Na przykład, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum z bieżącą wartością przy użyciu porównania bez znaku.
    ///
    /// Ustabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach liczb całkowitych bez znaku [`atomic`] za pośrednictwem metody `fetch_max` przez przekazanie [`Ordering::Release`] jako `order`.
    /// Na przykład, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum z bieżącą wartością przy użyciu porównania bez znaku.
    ///
    /// Ustabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach liczb całkowitych bez znaku [`atomic`] za pośrednictwem metody `fetch_max` przez przekazanie [`Ordering::AcqRel`] jako `order`.
    /// Na przykład, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum z bieżącą wartością przy użyciu porównania bez znaku.
    ///
    /// Ustabilizowana wersja tej funkcji wewnętrznej jest dostępna w typach liczb całkowitych bez znaku [`atomic`] za pośrednictwem metody `fetch_max` przez przekazanie [`Ordering::Relaxed`] jako `order`.
    /// Na przykład, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` intrinsic jest wskazówką dla generatora kodu, aby wstawił instrukcję pobierania wstępnego, jeśli jest obsługiwana;w przeciwnym razie nie jest to operacja.
    /// Pobieranie wstępne nie ma wpływu na zachowanie programu, ale może zmienić jego charakterystykę wydajności.
    ///
    /// Argument `locality` musi być stałą liczbą całkowitą i jest tymczasowym specyfikatorem lokalizacji w zakresie od (0), brak lokalizacji, do (3), niezwykle lokalne przechowywanie w pamięci podręcznej.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` intrinsic jest wskazówką dla generatora kodu, aby wstawił instrukcję pobierania wstępnego, jeśli jest obsługiwana;w przeciwnym razie nie jest to operacja.
    /// Pobieranie wstępne nie ma wpływu na zachowanie programu, ale może zmienić jego charakterystykę wydajności.
    ///
    /// Argument `locality` musi być stałą liczbą całkowitą i jest tymczasowym specyfikatorem lokalizacji w zakresie od (0), brak lokalizacji, do (3), niezwykle lokalne przechowywanie w pamięci podręcznej.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` intrinsic jest wskazówką dla generatora kodu, aby wstawił instrukcję pobierania wstępnego, jeśli jest obsługiwana;w przeciwnym razie nie jest to operacja.
    /// Pobieranie wstępne nie ma wpływu na zachowanie programu, ale może zmienić jego charakterystykę wydajności.
    ///
    /// Argument `locality` musi być stałą liczbą całkowitą i jest tymczasowym specyfikatorem lokalizacji w zakresie od (0), brak lokalizacji, do (3), niezwykle lokalne przechowywanie w pamięci podręcznej.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` intrinsic jest wskazówką dla generatora kodu, aby wstawił instrukcję pobierania wstępnego, jeśli jest obsługiwana;w przeciwnym razie nie jest to operacja.
    /// Pobieranie wstępne nie ma wpływu na zachowanie programu, ale może zmienić jego charakterystykę wydajności.
    ///
    /// Argument `locality` musi być stałą liczbą całkowitą i jest tymczasowym specyfikatorem lokalizacji w zakresie od (0), brak lokalizacji, do (3), niezwykle lokalne przechowywanie w pamięci podręcznej.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Ogrodzenie atomowe.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w [`atomic::fence`] po przejściu [`Ordering::SeqCst`] jako `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Ogrodzenie atomowe.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w [`atomic::fence`] po przejściu [`Ordering::Acquire`] jako `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Ogrodzenie atomowe.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w [`atomic::fence`] po przejściu [`Ordering::Release`] jako `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Ogrodzenie atomowe.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w [`atomic::fence`] po przejściu [`Ordering::AcqRel`] jako `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Bariera pamięci dostępna tylko dla kompilatora.
    ///
    /// Dostęp do pamięci nigdy nie zostanie zmieniony przez tę barierę przez kompilator, ale żadne instrukcje nie będą dla niego emitowane.
    /// Jest to odpowiednie dla operacji w tym samym wątku, który może być wywłaszczany, na przykład podczas interakcji z programami obsługi sygnałów.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w [`atomic::compiler_fence`] po przejściu [`Ordering::SeqCst`] jako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Bariera pamięci dostępna tylko dla kompilatora.
    ///
    /// Dostęp do pamięci nigdy nie zostanie zmieniony przez tę barierę przez kompilator, ale żadne instrukcje nie będą dla niego emitowane.
    /// Jest to odpowiednie dla operacji w tym samym wątku, który może być wywłaszczany, na przykład podczas interakcji z programami obsługi sygnałów.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w [`atomic::compiler_fence`] po przejściu [`Ordering::Acquire`] jako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Bariera pamięci dostępna tylko dla kompilatora.
    ///
    /// Dostęp do pamięci nigdy nie zostanie zmieniony przez tę barierę przez kompilator, ale żadne instrukcje nie będą dla niego emitowane.
    /// Jest to odpowiednie dla operacji w tym samym wątku, który może być wywłaszczany, na przykład podczas interakcji z programami obsługi sygnałów.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w [`atomic::compiler_fence`] po przejściu [`Ordering::Release`] jako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Bariera pamięci dostępna tylko dla kompilatora.
    ///
    /// Dostęp do pamięci nigdy nie zostanie zmieniony przez tę barierę przez kompilator, ale żadne instrukcje nie będą dla niego emitowane.
    /// Jest to odpowiednie dla operacji w tym samym wątku, który może być wywłaszczany, na przykład podczas interakcji z programami obsługi sygnałów.
    ///
    /// Stabilizowana wersja tej funkcji wewnętrznej jest dostępna w [`atomic::compiler_fence`] po przejściu [`Ordering::AcqRel`] jako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magia wewnętrzna, której znaczenie wywodzi się z atrybutów przypisanych do funkcji.
    ///
    /// Na przykład przepływ danych używa tego do wprowadzania statycznych asercji, aby `rustc_peek(potentially_uninitialized)` faktycznie dwukrotnie sprawdził, czy przepływ danych rzeczywiście obliczył, że nie został zainicjowany w tym punkcie przepływu sterowania.
    ///
    ///
    /// Ta wewnętrzna funkcja nie powinna być używana poza kompilatorem.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Przerywa wykonywanie procesu.
    ///
    /// Bardziej przyjazną dla użytkownika i stabilną wersją tej operacji jest [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informuje optymalizator, że ten punkt w kodzie jest nieosiągalny, umożliwiając dalsze optymalizacje.
    ///
    /// NB, to bardzo różni się od makra `unreachable!()`: w przeciwieństwie do makra, które jest wykonywane przez panics, zachowaniem *niezdefiniowanym* jest dotarcie do kodu oznaczonego tą funkcją.
    ///
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informuje optymalizator, że warunek jest zawsze prawdziwy.
    /// Jeśli warunek jest fałszywy, zachowanie jest niezdefiniowane.
    ///
    /// Żaden kod nie jest generowany dla tego elementu wewnętrznego, ale optymalizator będzie próbował zachować go (i jego stan) między przebiegami, co może zakłócać optymalizację otaczającego kodu i zmniejszać wydajność.
    /// Nie należy go używać, jeśli niezmiennik może zostać wykryty przez optymalizator samodzielnie lub jeśli nie umożliwia on żadnych znaczących optymalizacji.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Wskazuje kompilatorowi, że warunek branch prawdopodobnie jest prawdziwy.
    /// Zwraca przekazaną wartość.
    ///
    /// Każde użycie inne niż z instrukcjami `if` prawdopodobnie nie przyniesie efektu.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Wskazuje kompilatorowi, że warunek branch prawdopodobnie będzie fałszywy.
    /// Zwraca przekazaną wartość.
    ///
    /// Każde użycie inne niż z instrukcjami `if` prawdopodobnie nie przyniesie efektu.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Wykonuje pułapkę punktu przerwania w celu sprawdzenia przez debuger.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn breakpoint();

    /// Rozmiar typu w bajtach.
    ///
    /// Mówiąc dokładniej, jest to przesunięcie w bajtach między kolejnymi elementami tego samego typu, w tym wypełnienie wyrównaniem.
    ///
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Minimalne wyrównanie typu.
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Preferowane wyrównanie typu.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Rozmiar przywoływanej wartości w bajtach.
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Wymagane wyrównanie wartości odniesienia.
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Pobiera statyczny fragment ciągu zawierający nazwę typu.
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Pobiera identyfikator, który jest globalnie unikatowy dla określonego typu.
    /// Ta funkcja zwróci tę samą wartość dla typu, niezależnie od tego, w której crate została wywołana.
    ///
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Ochrona przed niebezpiecznymi funkcjami, których nigdy nie można wykonać, jeśli `T` jest niezamieszkany:
    /// Spowoduje to statycznie albo panic, albo nic nie zrobi.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Ochrona przed niebezpiecznymi funkcjami, których nigdy nie można wykonać, jeśli `T` nie pozwala na zerową inicjalizację: Spowoduje to statycznie albo panic, albo nic nie zrobi.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn assert_zero_valid<T>();

    /// Ochrona przed niebezpiecznymi funkcjami, których nigdy nie można wykonać, jeśli `T` ma nieprawidłowe wzorce bitów: spowoduje to statycznie albo panic, albo nic nie zrobi.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn assert_uninit_valid<T>();

    /// Pobiera odwołanie do statycznego `Location` wskazującego, gdzie został wywołany.
    ///
    /// Zamiast tego rozważ użycie [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Przenosi wartość poza zakres bez użycia kleju.
    ///
    /// To istnieje wyłącznie dla [`mem::forget_unsized`];normalny `forget` zamiast tego używa `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterpretuje bity wartości jednego typu jako innego typu.
    ///
    /// Oba typy muszą mieć ten sam rozmiar.
    /// Ani oryginał, ani wynik nie może być [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` jest semantycznie równoważne z bitowym przeniesieniem jednego typu do innego.Kopiuje bity z wartości źródłowej do wartości docelowej, a następnie zapomina o oryginale.
    /// Jest odpowiednikiem C's `memcpy` pod maską, podobnie jak `transmute_copy`.
    ///
    /// Ponieważ `transmute` jest operacją według wartości, wyrównanie *samych przekształconych wartości* nie stanowi problemu.
    /// Podobnie jak w przypadku każdej innej funkcji, kompilator zapewnia już prawidłowe wyrównanie `T` i `U`.
    /// Jednak podczas transmisji wartości, które *wskazują gdzie indziej*(takich jak wskaźniki, odwołania, pola…), wywołujący musi zapewnić prawidłowe wyrównanie wskazanych wartości.
    ///
    /// `transmute` jest **niewiarygodnie** niebezpieczne.Istnieje wiele sposobów wywołania [undefined behavior][ub] za pomocą tej funkcji.`transmute` powinien być absolutną ostatecznością.
    ///
    /// [nomicon](../../nomicon/transmutes.html) ma dodatkową dokumentację.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Jest kilka rzeczy, do których `transmute` jest naprawdę przydatny.
    ///
    /// Zamiana wskaźnika na wskaźnik funkcji.Jest to *nie* przenośne na komputery, na których wskaźniki funkcji i wskaźniki danych mają różne rozmiary.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Przedłużenie życia lub skrócenie niezmiennego czasu życia.To jest zaawansowany, bardzo niebezpieczny Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Nie rozpaczaj: wiele zastosowań `transmute` można osiągnąć innymi sposobami.
    /// Poniżej znajdują się typowe zastosowania `transmute`, które można zastąpić bezpieczniejszymi konstrukcjami.
    ///
    /// Toczenie surowego bytes(`&[u8]`) do `u32`, `f64` itp .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // zamiast tego użyj `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // lub użyj `u32::from_le_bytes` lub `u32::from_be_bytes`, aby określić endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Zamiana wskaźnika w `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Zamiast tego użyj rzutowania `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Przekształcanie `*mut T` w `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Zamiast tego użyj ponownego wypożyczenia
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Przekształcanie `&mut T` w `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Teraz połącz `as` i ponowne pożyczanie, zauważ, że łańcuch `as` `as` nie jest przechodni
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Przekształcanie `&str` w `&[u8]`:
    ///
    /// ```
    /// // to nie jest dobry sposób, aby to zrobić.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Możesz użyć `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Lub po prostu użyj ciągu bajtów, jeśli masz kontrolę nad literałem ciągu
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Przekształcanie `Vec<&T>` w `Vec<Option<&T>>`.
    ///
    /// Aby przekształcić wewnętrzny typ zawartości kontenera, musisz upewnić się, że nie naruszysz żadnych niezmienników tego kontenera.
    /// W przypadku `Vec` oznacza to, że zarówno rozmiar *, jak i wyrównanie* typów wewnętrznych muszą być zgodne.
    /// Inne kontenery mogą zależeć od rozmiaru typu, wyrównania, a nawet `TypeId`, w którym to przypadku transmutacja nie byłaby w ogóle możliwa bez naruszenia niezmienników kontenera.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // sklonuj vector, ponieważ użyjemy ich ponownie później
    /// let v_clone = v_orig.clone();
    ///
    /// // Korzystanie z transmute: opiera się na nieokreślonym układzie danych `Vec`, co jest złym pomysłem i może spowodować niezdefiniowane zachowanie.
    /////
    /// // Jednak nie jest to kopia.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // To jest sugerowany, bezpieczny sposób.
    /// // Jednak kopiuje cały vector do nowej tablicy.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Jest to właściwy sposób bez kopiowania, niebezpieczny dla "transmuting" a `Vec`, bez polegania na układzie danych.
    /// // Zamiast dosłownie wywoływać `transmute`, wykonujemy rzutowanie wskaźnika, ale pod względem konwersji oryginalnego typu wewnętrznego (`&i32`) na nowy (`Option<&i32>`) ma to wszystkie te same zastrzeżenia.
    /////
    /// // Oprócz informacji podanych powyżej zapoznaj się również z dokumentacją [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Zaktualizuj to po ustabilizowaniu vec_into_raw_parts.
    ///     // Upewnij się, że oryginalny vector nie został upuszczony.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Wdrażanie `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Można to zrobić na wiele sposobów, az następującą metodą (transmute) wiąże się wiele problemów.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // po pierwsze: transmute nie jest bezpieczny dla typów;wszystko co sprawdza to to, że T i
    ///         // U są tego samego rozmiaru.
    ///         // Po drugie, tutaj masz dwie zmienne referencje wskazujące na tę samą pamięć.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // To eliminuje problemy związane z bezpieczeństwem typu;`&mut *` zapewni* tylko *`&mut T` z `&mut T` lub `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // jednak nadal masz dwa zmienne odniesienia wskazujące na tę samą pamięć.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // W ten sposób robi to biblioteka standardowa.
    /// // To najlepsza metoda, jeśli musisz zrobić coś takiego
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Ma teraz trzy zmienne odniesienia wskazujące na tę samą pamięć.`slice`, rvalue ret.0 i rvalue ret.1.
    ///         // `slice` nie jest nigdy używany po `let ptr = ...`, więc można go traktować jako "dead", a zatem masz tylko dwa prawdziwe zmienne wycinki.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Chociaż sprawia to, że wewnętrzna stała jest stabilna, mamy pewien niestandardowy kod w const fn
    // kontrole, które uniemożliwiają jego użycie w `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Zwraca `true`, jeśli rzeczywisty typ podany jako `T` wymaga kleju kroplowego;zwraca `false`, jeśli rzeczywisty typ podany dla `T` implementuje `Copy`.
    ///
    ///
    /// Jeśli rzeczywisty typ nie wymaga kleju ani nie implementuje `Copy`, to wartość zwracana przez tę funkcję jest nieokreślona.
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Oblicza przesunięcie na podstawie wskaźnika.
    ///
    /// Jest to implementowane jako nieodłączne, aby uniknąć konwersji na i z liczby całkowitej, ponieważ konwersja spowodowałaby odrzucenie informacji o aliasingu.
    ///
    /// # Safety
    ///
    /// Zarówno początkowy, jak i wynikowy wskaźnik muszą znajdować się w granicach lub jeden bajt za końcem przydzielonego obiektu.
    /// Jeśli którykolwiek wskaźnik znajduje się poza granicami lub wystąpi przepełnienie arytmetyczne, dalsze użycie zwróconej wartości spowoduje niezdefiniowane zachowanie.
    ///
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Oblicza przesunięcie ze wskaźnika, potencjalnie zawijając.
    ///
    /// Jest to implementowane jako nieodłączne, aby uniknąć konwersji na i z liczby całkowitej, ponieważ konwersja blokuje pewne optymalizacje.
    ///
    /// # Safety
    ///
    /// W przeciwieństwie do `offset` intrinsic, ten wewnętrzny wskaźnik nie ogranicza wynikowego wskaźnika do wskazywania końca lub jeden bajt poza koniec przydzielonego obiektu i jest zawijany z arytmetyką dopełniającą do dwóch.
    /// Wynikowa wartość niekoniecznie jest prawidłowa, aby można ją było użyć do rzeczywistego dostępu do pamięci.
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Odpowiednik odpowiedniego wewnętrznego `llvm.memcpy.p0i8.0i8.*`, o rozmiarze `count`*`size_of::<T>()` i wyrównaniu
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametr volatile jest ustawiony na `true`, więc nie zostanie zoptymalizowany, chyba że rozmiar jest równy zero.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Odpowiednik odpowiedniego wewnętrznego `llvm.memmove.p0i8.0i8.*`, z rozmiarem `count* size_of::<T>()` i wyrównaniem
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametr volatile jest ustawiony na `true`, więc nie zostanie zoptymalizowany, chyba że rozmiar jest równy zero.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Odpowiednik odpowiedniego wewnętrznego `llvm.memset.p0i8.*`, z rozmiarem `count* size_of::<T>()` i wyrównaniem `min_align_of::<T>()`.
    ///
    ///
    /// Parametr volatile jest ustawiony na `true`, więc nie zostanie zoptymalizowany, chyba że rozmiar jest równy zero.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Wykonuje ulotne ładowanie ze wskaźnika `src`.
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Wykonuje ulotny zapis wskaźnika `dst`.
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Wykonuje zmienne obciążenie ze wskaźnika `src`. Wskaźnik nie musi być wyrównywany.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Wykonuje ulotny zapis wskaźnika `dst`.
    /// Wskaźnik nie musi być wyrównany.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Zwraca pierwiastek kwadratowy z `f32`
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Zwraca pierwiastek kwadratowy z `f64`
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Podnosi `f32` do potęgi całkowitej.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Podnosi `f64` do potęgi całkowitej.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Zwraca sinus `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Zwraca sinus `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Zwraca cosinus `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Zwraca cosinus `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Podnosi `f32` do mocy `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Podnosi `f64` do mocy `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Zwraca wykładniczą wartość `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Zwraca wykładniczą wartość `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Zwraca 2 podniesione do potęgi `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Zwraca 2 podniesione do potęgi `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Zwraca logarytm naturalny `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Zwraca logarytm naturalny `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Zwraca logarytm dziesiętny z `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Zwraca logarytm dziesiętny z `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Zwraca logarytm o podstawie 2 z `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Zwraca logarytm o podstawie 2 z `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Zwraca `a * b + c` dla wartości `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Zwraca `a * b + c` dla wartości `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Zwraca wartość bezwzględną `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Zwraca wartość bezwzględną `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Zwraca co najmniej dwie wartości `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Zwraca co najmniej dwie wartości `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Zwraca maksymalnie dwie wartości `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Zwraca maksymalnie dwie wartości `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopiuje znak z `y` do `x` dla wartości `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopiuje znak z `y` do `x` dla wartości `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Zwraca największą liczbę całkowitą mniejszą lub równą `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Zwraca największą liczbę całkowitą mniejszą lub równą `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Zwraca najmniejszą liczbę całkowitą większą lub równą `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Zwraca najmniejszą liczbę całkowitą większą lub równą `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Zwraca część całkowitą `f32`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Zwraca część całkowitą `f64`.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Zwraca najbliższą liczbę całkowitą do `f32`.
    /// Może zgłosić niedokładny wyjątek zmiennoprzecinkowy, jeśli argument nie jest liczbą całkowitą.
    pub fn rintf32(x: f32) -> f32;
    /// Zwraca najbliższą liczbę całkowitą do `f64`.
    /// Może zgłosić niedokładny wyjątek zmiennoprzecinkowy, jeśli argument nie jest liczbą całkowitą.
    pub fn rintf64(x: f64) -> f64;

    /// Zwraca najbliższą liczbę całkowitą do `f32`.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Zwraca najbliższą liczbę całkowitą do `f64`.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Zwraca najbliższą liczbę całkowitą do `f32`.Zaokrągla przypadki w połowie drogi od zera.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Zwraca najbliższą liczbę całkowitą do `f64`.Zaokrągla przypadki w połowie drogi od zera.
    ///
    /// Ustabilizowaną wersją tego nieodłącznego jest
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Dodatek pływający, który umożliwia optymalizacje w oparciu o reguły algebraiczne.
    /// Można założyć, że dane wejściowe są ograniczone.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Odejmowanie zmiennoprzecinkowe, które umożliwia optymalizację w oparciu o reguły algebraiczne.
    /// Można założyć, że dane wejściowe są ograniczone.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Mnożenie liczb zmiennoprzecinkowych, które umożliwia optymalizację w oparciu o reguły algebraiczne.
    /// Można założyć, że dane wejściowe są ograniczone.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Dzielenie zmiennoprzecinkowe, które umożliwia optymalizacje na podstawie reguł algebraicznych.
    /// Można założyć, że dane wejściowe są ograniczone.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Reszta zmiennoprzecinkowa, która umożliwia optymalizacje w oparciu o reguły algebraiczne.
    /// Można założyć, że dane wejściowe są ograniczone.
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konwertuj za pomocą fptoui/fptosi LLVM, co może zwrócić undef dla wartości spoza zakresu
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilizowany jako [`f32::to_int_unchecked`] i [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Zwraca liczbę bitów ustawioną w typie liczby całkowitej `T`
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `count_ones`.
    /// Na przykład,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Zwraca liczbę początkowych nieustawionych bitów (zeroes) w liczbie całkowitej typu `T`.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `leading_zeros`.
    /// Na przykład,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` o wartości `0` zwróci szerokość bitową `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Podobnie jak `ctlz`, ale wyjątkowo niebezpieczne, ponieważ zwraca `undef`, gdy otrzyma `x` o wartości `0`.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Zwraca liczbę końcowych nieustawionych bitów (zeroes) w liczbie całkowitej typu `T`.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `trailing_zeros`.
    /// Na przykład,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` o wartości `0` zwróci szerokość bitową `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Podobnie jak `cttz`, ale wyjątkowo niebezpieczne, ponieważ zwraca `undef`, gdy otrzyma `x` o wartości `0`.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Odwraca bajty w typie liczby całkowitej `T`.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `swap_bytes`.
    /// Na przykład,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Odwraca bity w liczbach całkowitych typu `T`.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne na prymitywach całkowitoliczbowych za pośrednictwem metody `reverse_bits`.
    /// Na przykład,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Wykonuje sprawdzane dodawanie liczb całkowitych.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `overflowing_add`.
    /// Na przykład,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Wykonuje sprawdzone odejmowanie liczb całkowitych
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `overflowing_sub`.
    /// Na przykład,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Wykonuje sprawdzone mnożenie liczb całkowitych
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne na prymitywach całkowitych za pośrednictwem metody `overflowing_mul`.
    /// Na przykład,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Wykonuje dokładny podział, co powoduje niezdefiniowane zachowanie, w którym `x % y != 0` lub `y == 0` lub `x == T::MIN && y == -1`
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Wykonuje niesprawdzone dzielenie, co powoduje niezdefiniowane zachowanie, w którym `y == 0` lub `x == T::MIN && y == -1`
    ///
    ///
    /// Bezpieczne opakowania dla tego elementu wewnętrznego są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `checked_div`.
    /// Na przykład,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Zwraca pozostałą część niesprawdzonego dzielenia, co powoduje niezdefiniowane zachowanie, gdy `y == 0` lub `x == T::MIN && y == -1`
    ///
    ///
    /// Bezpieczne opakowania dla tego elementu wewnętrznego są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `checked_rem`.
    /// Na przykład,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Wykonuje niesprawdzone przesunięcie w lewo, powodując niezdefiniowane zachowanie, gdy `y < 0` lub `y >= N`, gdzie N jest szerokością T w bitach.
    ///
    ///
    /// Bezpieczne opakowania dla tego elementu wewnętrznego są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `checked_shl`.
    /// Na przykład,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Wykonuje niesprawdzone przesunięcie w prawo, powodując niezdefiniowane zachowanie, gdy `y < 0` lub `y >= N`, gdzie N jest szerokością T w bitach.
    ///
    ///
    /// Bezpieczne opakowania dla tego elementu wewnętrznego są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `checked_shr`.
    /// Na przykład,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Zwraca wynik niesprawdzonego dodawania, co powoduje niezdefiniowane zachowanie, gdy `x + y > T::MAX` lub `x + y < T::MIN`.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Zwraca wynik niesprawdzonego odejmowania, co powoduje niezdefiniowane zachowanie, gdy `x - y > T::MAX` lub `x - y < T::MIN`.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Zwraca wynik niesprawdzonego mnożenia, co powoduje niezdefiniowane zachowanie, gdy `x *y > T::MAX` lub `x* y < T::MIN`.
    ///
    ///
    /// Ta wewnętrzna cecha nie ma stabilnego odpowiednika.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Wykonuje obrót w lewo.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `rotate_left`.
    /// Na przykład,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Wykonuje obrót w prawo.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `rotate_right`.
    /// Na przykład,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Zwraca (a + b) mod 2 <sup>N</sup>, gdzie N to szerokość T w bitach.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `wrapping_add`.
    /// Na przykład,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Zwraca (a, b) mod 2 <sup>N</sup>, gdzie N jest szerokością T w bitach.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `wrapping_sub`.
    /// Na przykład,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Zwraca (a * b) mod 2 <sup>N</sup>, gdzie N jest szerokością T w bitach.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `wrapping_mul`.
    /// Na przykład,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Oblicza `a + b`, nasycając w granicach liczbowych.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `saturating_add`.
    /// Na przykład,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Oblicza `a - b`, nasycając w granicach liczbowych.
    ///
    /// Ustabilizowane wersje tej funkcji wewnętrznej są dostępne dla prymitywów całkowitoliczbowych za pośrednictwem metody `saturating_sub`.
    /// Na przykład,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Zwraca wartość dyskryminatora dla wariantu w 'v';
    /// jeśli `T` nie ma dyskryminatora, zwraca `0`.
    ///
    /// Stabilizowaną wersją tej funkcji wewnętrznej jest [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Zwraca liczbę wariantów rzutowania typu `T` na `usize`;
    /// jeśli `T` nie ma wariantów, zwraca `0`.Liczone będą niezamieszkane warianty.
    ///
    /// Wersja tej funkcji, która ma zostać ustabilizowana, to [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Konstrukcja "try catch" w Rust, która wywołuje wskaźnik funkcji `try_fn` ze wskaźnikiem danych `data`.
    ///
    /// Trzecim argumentem jest funkcja wywoływana, jeśli wystąpi panic.
    /// Ta funkcja pobiera wskaźnik danych i wskaźnik do przechwyconego obiektu wyjątku specyficznego dla celu.
    ///
    /// Aby uzyskać więcej informacji, zobacz źródło kompilatora, a także implementację catch std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emituje sklep `!nontemporal` zgodnie z LLVM (zobacz ich dokumentację).
    /// Prawdopodobnie nigdy się nie ustabilizuje.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Szczegółowe informacje można znaleźć w dokumentacji `<*const T>::offset_from`.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Szczegółowe informacje można znaleźć w dokumentacji `<*const T>::guaranteed_eq`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Szczegółowe informacje można znaleźć w dokumentacji `<*const T>::guaranteed_ne`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Przydzielaj w czasie kompilacji.Nie powinno być wywoływane w czasie wykonywania.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Niektóre funkcje są zdefiniowane tutaj, ponieważ przypadkowo zostały udostępnione w tym module na stabilnej.
// Zobacz <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` również należy do tej kategorii, ale nie można go opakować ze względu na sprawdzenie, czy `T` i `U` mają ten sam rozmiar).
//

/// Sprawdza, czy `ptr` jest prawidłowo wyrównany względem `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopiuje bajty `count *size_of::<T>()` z `src` do `dst`.Źródło i miejsce docelowe* nie * mogą się pokrywać.
///
/// W przypadku obszarów pamięci, które mogą się nakładać, użyj zamiast tego [`copy`].
///
/// `copy_nonoverlapping` jest semantycznie odpowiednikiem [`memcpy`] w C, ale z zamienioną kolejnością argumentów.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `src` musi wynosić [valid] do odczytu bajtów `count * size_of::<T>()`.
///
/// * `dst` musi wynosić [valid] dla zapisów `count * size_of::<T>()` bajtów.
///
/// * Zarówno `src`, jak i `dst` muszą być odpowiednio wyrównane.
///
/// * Obszar pamięci rozpoczynający się od `src` i o rozmiarze `count *
///   rozmiar: :<T>() `bajty *nie* mogą pokrywać się z obszarem pamięci rozpoczynającym się od `dst` o tym samym rozmiarze.
///
/// Podobnie jak [`read`], `copy_nonoverlapping` tworzy bitową kopię `T`, niezależnie od tego, czy `T` to [`Copy`].
/// Jeśli `T` nie jest [`Copy`], użycie *obu* wartości w regionie rozpoczynającym się od `*src` i regionie rozpoczynającym się od `* dst` może [violate memory safety][read-ownership].
///
///
/// Zauważ, że nawet jeśli efektywnie skopiowany rozmiar (`count * size_of: :<T>()`) to `0`, wskaźniki muszą być inne niż NULL i odpowiednio wyrównane.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ręcznie zaimplementuj [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Przenosi wszystkie elementy `src` do `dst`, pozostawiając `src` puste.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Upewnij się, że `dst` ma wystarczającą pojemność, aby pomieścić wszystkie `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Wywołanie offset jest zawsze bezpieczne, ponieważ `Vec` nigdy nie przydzieli więcej niż `isize::MAX` bajtów.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Obetnij `src` bez upuszczania jego zawartości.
///         // Robimy to najpierw, aby uniknąć problemów w przypadku czegoś dalej w dół panics.
///         src.set_len(0);
///
///         // Te dwa regiony nie mogą się pokrywać, ponieważ zmienne odwołania nie mają aliasów, a dwa różne wektory Z0Z nie mogą posiadać tej samej pamięci.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Powiadom `dst`, że teraz przechowuje zawartość `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Wykonuj te testy tylko w czasie wykonywania
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Nie panikuj, by zmniejszyć wpływ codegen.
        abort();
    }*/

    // BEZPIECZEŃSTWO: umowa bezpieczeństwa dla `copy_nonoverlapping` musi być
    // podtrzymane przez dzwoniącego.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopiuje bajty `count * size_of::<T>()` z `src` do `dst`.Źródło i miejsce docelowe mogą się pokrywać.
///
/// Jeśli źródło i miejsce docelowe *nigdy* się nie pokrywają, można zamiast tego użyć [`copy_nonoverlapping`].
///
/// `copy` jest semantycznie odpowiednikiem [`memmove`] w C, ale z zamienioną kolejnością argumentów.
/// Kopiowanie odbywa się tak, jakby bajty zostały skopiowane z `src` do tymczasowej tablicy, a następnie skopiowane z tablicy do `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `src` musi wynosić [valid] do odczytu bajtów `count * size_of::<T>()`.
///
/// * `dst` musi wynosić [valid] dla zapisów `count * size_of::<T>()` bajtów.
///
/// * Zarówno `src`, jak i `dst` muszą być odpowiednio wyrównane.
///
/// Podobnie jak [`read`], `copy` tworzy bitową kopię `T`, niezależnie od tego, czy `T` to [`Copy`].
/// Jeśli `T` nie jest [`Copy`], użycie obu wartości z regionu rozpoczynającego się od `*src` i regionu rozpoczynającego się od `* dst` może [violate memory safety][read-ownership].
///
///
/// Zauważ, że nawet jeśli efektywnie skopiowany rozmiar (`count * size_of: :<T>()`) to `0`, wskaźniki muszą być inne niż NULL i odpowiednio wyrównane.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Wydajnie utwórz Rust vector z niebezpiecznego bufora:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` musi być poprawnie wyrównany dla swojego typu i niezerowy.
/// /// * `ptr` musi być ważna dla odczytów ciągłych elementów `elts` typu `T`.
/// /// * Te elementy nie mogą być używane po wywołaniu tej funkcji, chyba że `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // BEZPIECZEŃSTWO: Nasz warunek wstępny gwarantuje, że źródło jest wyrównane i ważne,
///     // a `Vec::with_capacity` zapewnia, że mamy dostępną przestrzeń do ich zapisania.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // BEZPIECZEŃSTWO: Stworzyliśmy go z tak dużą pojemnością wcześniej,
///     // a poprzedni `copy` zainicjował te elementy.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Wykonuj te testy tylko w czasie wykonywania
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Nie panikuj, by zmniejszyć wpływ codegen.
        abort();
    }*/

    // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać umowy dotyczącej bezpieczeństwa dla `copy`.
    unsafe { copy(src, dst, count) }
}

/// Ustawia `count * size_of::<T>()` bajtów pamięci, zaczynając od `dst` do `val`.
///
/// `write_bytes` jest podobny do [`memset`] w C, ale ustawia bajty `count * size_of::<T>()` na `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `dst` musi wynosić [valid] dla zapisów `count * size_of::<T>()` bajtów.
///
/// * `dst` muszą być odpowiednio wyrównane.
///
/// Ponadto wywołujący musi upewnić się, że zapisanie bajtów `count * size_of::<T>()` do danego obszaru pamięci skutkuje poprawną wartością `T`.
/// Używanie obszaru pamięci wpisanego jako `T`, który zawiera nieprawidłową wartość `T`, jest niezdefiniowanym zachowaniem.
///
/// Zauważ, że nawet jeśli efektywnie skopiowany rozmiar (`count * size_of: :<T>()`) to `0`, wskaźnik musi mieć wartość różną od NULL i być odpowiednio wyrównany.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Tworzenie nieprawidłowej wartości:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Wycieka poprzednio trzymaną wartość przez nadpisanie `Box<T>` wskaźnikiem zerowym.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // W tym momencie użycie lub porzucenie `v` skutkuje niezdefiniowanym zachowaniem.
/// // drop(v); // ERROR
///
/// // Nawet przecieka `v` "uses" to, a zatem jest niezdefiniowanym zachowaniem.
/// // mem::forget(v); // ERROR
///
/// // W rzeczywistości `v` jest nieprawidłowy zgodnie z niezmiennikami układu typu podstawowego, więc *każda* operacja dotykająca go jest niezdefiniowanym zachowaniem.
/////
/// // niech v2 =v;//BŁĄD
///
/// unsafe {
///     // Zamiast tego wprowadźmy prawidłową wartość
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Teraz pudełko jest w porządku
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać umowy dotyczącej bezpieczeństwa dla `write_bytes`.
    unsafe { write_bytes(dst, val, count) }
}