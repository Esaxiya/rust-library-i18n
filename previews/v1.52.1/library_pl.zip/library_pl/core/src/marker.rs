//! Prymitywne traits i typy reprezentujące podstawowe właściwości typów.
//!
//! Typy Rust można klasyfikować na różne użyteczne sposoby w zależności od ich wewnętrznych właściwości.
//! Klasyfikacje te są reprezentowane jako traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Typy, które można przenosić przez granice wątków.
///
/// Ten trait jest automatycznie implementowany, gdy kompilator ustali, że jest odpowiedni.
///
/// Przykładem typu innego niż " Wyślij` jest wskaźnik zliczający odwołania [`rc::Rc`][`Rc`].
/// Jeśli dwa wątki próbują sklonować [`Rc`], które wskazują na tę samą wartość zliczaną przez odwołanie, mogą próbować zaktualizować liczbę odwołań w tym samym czasie, czyli [undefined behavior][ub], ponieważ [`Rc`] nie używa operacji atomowych.
///
/// Jego kuzyn [`sync::Arc`][arc] używa operacji atomowych (ponosząc pewne koszty ogólne), a zatem jest `Send`.
///
/// Aby uzyskać więcej informacji, zobacz [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Typy o stałym rozmiarze znane w czasie kompilacji.
///
/// Wszystkie parametry typu mają niejawne ograniczenie `Sized`.Jeśli nie jest to właściwe, można użyć specjalnej składni `?Sized`, aby usunąć to ograniczenie.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//błąd: rozmiar nie jest zaimplementowany dla [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Jedynym wyjątkiem jest niejawny typ `Self` trait.
/// trait nie ma niejawnego powiązania `Sized`, ponieważ jest to niezgodne z [obiektem trait] s, gdzie z definicji trait musi współpracować ze wszystkimi możliwymi implementatorami, a zatem może mieć dowolny rozmiar.
///
///
/// Chociaż Rust pozwoli ci powiązać `Sized` z trait, nie będziesz mógł go później użyć do utworzenia obiektu trait:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // let y: &dyn Bar= &Impl;//błąd: trait `Bar` nie można przekształcić w obiekt
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // na przykład dla Default, co wymaga, aby `[T]: !Default` był możliwy do oszacowania
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Typy, które mogą być "unsized" na typ o rozmiarze dynamicznym.
///
/// Na przykład typ tablicy o rozmiarze `[i8; 2]` implementuje `Unsize<[i8]>` i `Unsize<dyn fmt::Debug>`.
///
/// Wszystkie implementacje `Unsize` są dostarczane automatycznie przez kompilator.
///
/// `Unsize` jest realizowany dla:
///
/// - `[T; N]` to `Unsize<[T]>`
/// - `T` jest `Unsize<dyn Trait>`, gdy `T: Trait`
/// - `Foo<..., T, ...>` to `Unsize<Foo<..., U, ...>>`, jeśli:
///   - `T: Unsize<U>`
///   - Foo jest strukturą
///   - Tylko ostatnie pole `Foo` ma typ obejmujący `T`
///   - `T` nie jest częścią typu żadnego innego pola
///   - `Bar<T>: Unsize<Bar<U>>`, jeśli ostatnie pole `Foo` ma typ `Bar<T>`
///
/// `Unsize` jest używany wraz z [`ops::CoerceUnsized`], aby umożliwić kontenerom "user-defined", takim jak [`Rc`], przechowywanie typów o rozmiarze dynamicznym.
/// Aby uzyskać więcej informacji, zobacz [DST coercion RFC][RFC982] i [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Wymagane trait dla stałych używanych w dopasowaniach wzorców.
///
/// Każdy typ, który wywodzi `PartialEq`, automatycznie implementuje ten trait,*niezależnie* od tego, czy jego parametry typu implementują `Eq`.
///
/// Jeśli element `const` zawiera typ, który nie implementuje tego trait, to ten typ (1.) nie implementuje `PartialEq` (co oznacza, że stała nie zapewni tej metody porównania, która zakłada, że generowanie kodu jest dostępna) lub (2.), który implementuje *własną* wersja `PartialEq` (która, jak zakładamy, nie jest zgodna z porównaniem równości strukturalnej).
///
///
/// W każdym z dwóch powyższych scenariuszy odrzucamy użycie takiej stałej w dopasowaniu do wzorca.
///
/// Zobacz także [structural match RFC][RFC1445] i [issue 63438], które motywowały migrację z projektowania opartego na atrybutach do tego trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Wymagane trait dla stałych używanych w dopasowaniach wzorców.
///
/// Każdy typ, który wywodzi `Eq`, automatycznie implementuje ten trait,*niezależnie* od tego, czy jego parametry typu implementują `Eq`.
///
/// To sztuczka mająca obejść ograniczenie w naszym systemie typów.
///
/// # Background
///
/// Chcemy wymagać, aby typy stałych używanych w dopasowywaniu wzorców miały atrybut `#[derive(PartialEq, Eq)]`.
///
/// W bardziej idealnym świecie moglibyśmy sprawdzić to wymaganie, po prostu sprawdzając, czy dany typ implementuje zarówno `StructuralPartialEq` trait *, jak i*`Eq` trait.
/// Jednak możesz mieć ADT, które *robią*`derive(PartialEq, Eq)` i być przypadkiem, który chcemy, aby kompilator zaakceptował, a mimo to typ stałej nie może zaimplementować `Eq`.
///
/// Mianowicie przypadek taki jak ten:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Problem w powyższym kodzie polega na tym, że `Wrap<fn(&())>` nie implementuje `PartialEq` ani `Eq`, ponieważ `dla <'a> fn(&'a _)` does not implement those traits.)
///
/// Dlatego nie możemy polegać na naiwnym czeku dla `StructuralPartialEq` i zwykłego `Eq`.
///
/// Aby obejść ten problem, używamy dwóch oddzielnych traits wstrzykniętych przez każde z dwóch pochodnych (`#[derive(PartialEq)]` i `#[derive(Eq)]`) i sprawdzamy, czy oba z nich są obecne w ramach sprawdzania dopasowania strukturalnego.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Typy, których wartości można powielić, po prostu kopiując bity.
///
/// Domyślnie zmienne powiązania mają " semantykę przenoszenia`.Innymi słowy:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` przeniósł się do `y`, więc nie może być używany
///
/// // println! ("{: ?}", x);//błąd: użycie przeniesionej wartości
/// ```
///
/// Jeśli jednak typ implementuje `Copy`, zamiast tego ma `` semantykę kopiowania '':
///
/// ```
/// // Możemy wyprowadzić implementację `Copy`.
/// // `Clone` jest również wymagane, ponieważ jest to cecha charakterystyczna `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` jest kopią `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Należy zauważyć, że w tych dwóch przykładach jedyną różnicą jest to, czy masz dostęp do `x` po przypisaniu.
/// Pod maską zarówno kopia, jak i ruch mogą powodować kopiowanie bitów do pamięci, chociaż czasami jest to zoptymalizowane.
///
/// ## Jak mogę wdrożyć `Copy`?
///
/// Istnieją dwa sposoby zaimplementowania `Copy` w twoim typie.Najprościej jest użyć `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Możesz również zaimplementować `Copy` i `Clone` ręcznie:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Jest między nimi niewielka różnica: strategia `derive` będzie również wiązać `Copy` z parametrami typu, co nie zawsze jest pożądane.
///
/// ## Jaka jest różnica między `Copy` i `Clone`?
///
/// Kopie odbywają się niejawnie, na przykład jako część przydziału `y = x`.Zachowanie `Copy` nie jest przeciążalne;jest to zawsze prosta kopia bitowa.
///
/// Klonowanie to jawna czynność, `x.clone()`.Implementacja [`Clone`] może zapewnić dowolne zachowanie specyficzne dla typu, niezbędne do bezpiecznego duplikowania wartości.
/// Na przykład implementacja [`Clone`] dla [`String`] wymaga skopiowania wskazanego buforu ciągu w stercie.
/// Prosta bitowa kopia wartości [`String`] po prostu skopiowałaby wskaźnik, prowadząc do podwójnego zwolnienia w dół wiersza.
/// Z tego powodu [`String`] to [`Clone`], ale nie `Copy`.
///
/// [`Clone`] jest zaletą `Copy`, więc wszystko, co jest `Copy`, musi również implementować [`Clone`].
/// Jeśli typ to `Copy`, jego implementacja [`Clone`] musi tylko zwrócić `*self` (patrz przykład powyżej).
///
/// ## Kiedy mój typ to `Copy`?
///
/// Typ może implementować `Copy`, jeśli wszystkie jego komponenty implementują `Copy`.Na przykład ta struktura może być `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Strukturą może być `Copy`, a [`i32`] to `Copy`, dlatego `Point` kwalifikuje się jako `Copy`.
/// Rozważmy natomiast
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struktura `PointList` nie może zaimplementować `Copy`, ponieważ [`Vec<T>`] to nie `Copy`.Jeśli spróbujemy wyprowadzić implementację `Copy`, otrzymamy błąd:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Odniesienia współdzielone (`&T`) to również `Copy`, więc typem może być `Copy`, nawet jeśli zawiera odniesienia współdzielone typu `T`, które *nie są*`Copy`.
/// Rozważmy następującą strukturę, która może zaimplementować `Copy`, ponieważ zawiera tylko *współdzielone odniesienie* do naszego typu `PointList` nie będącego kopią:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kiedy *nie* mój typ to `Copy`?
///
/// Niektórych typów nie można bezpiecznie skopiować.Na przykład skopiowanie `&mut T` utworzyłoby aliasowane, modyfikowalne odniesienie.
/// Skopiowanie [`String`] zduplikowałoby odpowiedzialność za zarządzanie buforem [`String`], prowadząc do podwójnego zwolnienia.
///
/// Uogólniając ten drugi przypadek, każdy typ implementujący [`Drop`] nie może być `Copy`, ponieważ zarządza niektórymi zasobami oprócz własnych bajtów [`size_of::<T>`].
///
/// Jeśli spróbujesz zaimplementować `Copy` na strukturze lub wyliczeniu zawierającym dane inne niż " Kopiuj`, pojawi się błąd [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kiedy *powinien* mój typ to `Copy`?
///
/// Ogólnie rzecz biorąc, jeśli Twój typ _can_ implementuje `Copy`, powinien.
/// Pamiętaj jednak, że implementacja `Copy` jest częścią publicznego API twojego typu.
/// Jeśli typ może stać się inny niż `Copy` w future, rozsądnie byłoby teraz pominąć implementację `Copy`, aby uniknąć zepsutej zmiany interfejsu API.
///
/// ## Dodatkowi realizatorzy
///
/// Oprócz [implementors listed below][impls] w `Copy` są również stosowane następujące typy:
///
/// * Typy elementów funkcji (tj. Różne typy zdefiniowane dla każdej funkcji)
/// * Typy wskaźników funkcji (np. `fn() -> i32`)
/// * Typy tablic dla wszystkich rozmiarów, jeśli typ elementu również implementuje `Copy` (np. `[i32; 123456]`)
/// * Typy krotek, jeśli każdy komponent implementuje również `Copy` (np. `()`, `(i32, bool)`)
/// * Typy zamknięć, jeśli nie wychwytują żadnej wartości ze środowiska lub jeśli wszystkie takie przechwycone wartości same implementują `Copy`.
///   Zwróć uwagę, że zmienne przechwycone przez wspólne odwołanie zawsze implementują `Copy` (nawet jeśli odwołanie tego nie robi), podczas gdy zmienne przechwycone przez mutowalne odwołanie nigdy nie implementują `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Pozwala to na skopiowanie typu, który nie implementuje `Copy` z powodu niezaspokojonych granic czasu życia (kopiowanie `A<'_>`, gdy tylko `A<'static>: Copy` i `A<'_>: Clone`).
// Na razie mamy ten atrybut tylko dlatego, że istnieje kilka istniejących specjalizacji `Copy`, które już istnieją w bibliotece standardowej i nie ma sposobu, aby w tej chwili bezpiecznie mieć to zachowanie.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Wyprowadź makro generując implik z trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Typy, dla których można bezpiecznie udostępniać odwołania między wątkami.
///
/// Ten trait jest automatycznie implementowany, gdy kompilator ustali, że jest odpowiedni.
///
/// Dokładna definicja to: typ `T` to [`Sync`] wtedy i tylko wtedy, gdy `&T` to [`Send`].
/// Innymi słowy, jeśli nie ma możliwości [undefined behavior][ub] (w tym wyścigów danych) podczas przekazywania odwołań `&T` między wątkami.
///
/// Jak można by się spodziewać, wszystkie typy pierwotne, takie jak [`u8`] i [`f64`], to [`Sync`], podobnie jak proste typy agregujące zawierające je, takie jak krotki, struktury i wyliczenia.
/// Więcej przykładów podstawowych typów [`Sync`] obejmuje typy "immutable", takie jak `&T`, i te z prostą dziedziczną zmiennością, takie jak [`Box<T>`][box], [`Vec<T>`][vec] i większość innych typów kolekcji.
///
/// (Parametry ogólne muszą mieć wartość [`Sync`], aby ich kontener był [" Synchronizacja`].)
///
/// Dość zaskakującą konsekwencją definicji jest to, że `&mut T` to `Sync` (jeśli `T` to `Sync`), chociaż wydaje się, że może to powodować niezsynchronizowaną mutację.
/// Sztuczka polega na tym, że zmienne odniesienie za wspólnym odniesieniem (to jest `& &mut T`) staje się tylko do odczytu, tak jakby to było `& &T`.
/// Dlatego nie ma ryzyka wyścigu danych.
///
/// Typy inne niż `Sync` to te, które mają "interior mutability" w postaci niegwintowanej, na przykład [`Cell`][cell] i [`RefCell`][refcell].
/// Te typy pozwalają na mutację ich zawartości nawet poprzez niezmienne, współdzielone odniesienie.
/// Na przykład metoda `set` w [`Cell<T>`][cell] przyjmuje `&self`, więc wymaga tylko współdzielonego odniesienia [`&Cell<T>`][cell].
/// Metoda nie przeprowadza synchronizacji, dlatego [`Cell`][cell] nie może być `Sync`.
///
/// Innym przykładem typu innego niż " Synchronizacja` jest wskaźnik zliczający odwołania [`Rc`][rc].
/// Mając dowolne odniesienie [`&Rc<T>`][rc], możesz sklonować nowy [`Rc<T>`][rc], modyfikując liczniki odniesień w sposób nieatomowy.
///
/// W przypadkach, gdy potrzebna jest wewnętrzna zmienność zabezpieczona wątkami, Rust zapewnia [atomic data types], a także jawne blokowanie przez [`sync::Mutex`][mutex] i [`sync::RwLock`][rwlock].
/// Te typy zapewniają, że żadna mutacja nie może powodować wyścigów danych, dlatego są to typy `Sync`.
/// Podobnie [`sync::Arc`][arc] zapewnia bezpieczny dla wątków odpowiednik [`Rc`][rc].
///
/// Wszystkie typy ze zmiennością wewnętrzną muszą również używać opakowania [`cell::UnsafeCell`][unsafecell] wokół value(s), które można mutować za pomocą współdzielonego odniesienia.
/// W przeciwnym razie [undefined behavior][ub].
/// Na przykład, [`transmute`][transmute]-ing z `&T` do `&mut T` jest niepoprawne.
///
/// Zobacz [the Nomicon][nomicon-send-and-sync], aby uzyskać więcej informacji o `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): gdy obsługa dodawania notatek w `rustc_on_unimplemented` ląduje w wersji beta i została rozszerzona, aby sprawdzić, czy zamknięcie znajduje się w dowolnym miejscu w łańcuchu wymagań, rozszerz je tak, jak (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Typ o zerowym rozmiarze używany do oznaczania rzeczy, które "act like" posiadają, a `T`.
///
/// Dodanie pola `PhantomData<T>` do twojego typu mówi kompilatorowi, że twój typ zachowuje się tak, jakby przechował wartość typu `T`, mimo że tak naprawdę tak nie jest.
/// Informacje te są wykorzystywane podczas obliczania pewnych właściwości bezpieczeństwa.
///
/// Aby uzyskać bardziej szczegółowe wyjaśnienie, jak używać `PhantomData<T>`, zobacz [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Upiorna notatka 👻👻👻
///
/// Chociaż oba mają przerażające nazwy, `PhantomData` i " typy fantomowe` są ze sobą powiązane, ale nie identyczne.Parametr typu fantom to po prostu parametr typu, który nigdy nie jest używany.
/// W Rust często powoduje to narzekanie kompilatora, a rozwiązaniem jest dodanie użycia "dummy" za pośrednictwem `PhantomData`.
///
/// # Examples
///
/// ## Nieużywane parametry żywotności
///
/// Być może najczęstszym przypadkiem użycia `PhantomData` jest struktura, która ma nieużywany parametr czasu życia, zwykle jako część niebezpiecznego kodu.
/// Na przykład, oto struktura `Slice`, która ma dwa wskaźniki typu `*const T`, prawdopodobnie wskazujące gdzieś na tablicę:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Intencją jest, aby dane bazowe były ważne tylko przez cały okres życia `'a`, więc `Slice` nie powinien przeżyć `'a`.
/// Jednak zamiar ten nie jest wyrażony w kodzie, ponieważ nie ma zastosowań okresu życia `'a`, a zatem nie jest jasne, do jakich danych on się odnosi.
/// Możemy to naprawić, nakazując kompilatorowi działanie *tak, jakby* struktura `Slice` zawierała odniesienie `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// To z kolei wymaga adnotacji `T: 'a`, wskazującej, że wszelkie odniesienia w `T` są ważne przez cały okres eksploatacji `'a`.
///
/// Podczas inicjalizacji `Slice` wystarczy podać wartość `PhantomData` dla pola `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Nieużywane parametry typu
///
/// Czasami zdarza się, że masz nieużywane parametry typu, które wskazują, do jakiego typu danych należy struktura "tied", nawet jeśli dane te w rzeczywistości nie zostały znalezione w samej strukturze.
/// Oto przykład, w którym dzieje się to w przypadku [FFI].
/// Interfejs obcy używa uchwytów typu `*mut ()` do odwoływania się do wartości Rust różnych typów.
/// Śledzimy typ Rust za pomocą parametru typu phantom w strukturze `ExternalResource`, który otacza uchwyt.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Własność i kontrola spadku
///
/// Dodanie pola typu `PhantomData<T>` wskazuje, że Twój typ jest właścicielem danych typu `T`.To z kolei oznacza, że gdy twój typ zostanie odrzucony, może upuścić jedno lub więcej wystąpień typu `T`.
/// Ma to wpływ na analizę [drop check] kompilatora Rust.
///
/// Jeśli twoja struktura w rzeczywistości *nie posiada* danych typu `T`, lepiej jest użyć typu referencyjnego, takiego jak `PhantomData<&'a T>` (ideally) lub `PhantomData<*const T>` (jeśli nie ma zastosowania czas życia), aby nie wskazywać własności.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Wewnętrzne trait kompilatora używane do wskazania typu dyskryminatorów wyliczeniowych.
///
/// Ten trait jest automatycznie implementowany dla każdego typu i nie dodaje żadnych gwarancji do [`mem::Discriminant`].
/// Transmutacja między `DiscriminantKind::Discriminant` i `mem::Discriminant` jest **niezdefiniowanym zachowaniem**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Typ dyskryminatora, który musi spełniać trait bounds wymagane przez `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Wewnętrzne trait kompilatora używane do określenia, czy typ zawiera wewnętrznie `UnsafeCell`, ale nie przez pośredni.
///
/// Ma to wpływ na przykład na to, czy `static` tego typu jest umieszczony w pamięci statycznej tylko do odczytu, czy w zapisywalnej pamięci statycznej.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Typy, które można bezpiecznie przenosić po przypięciu.
///
/// Sam Rust nie ma pojęcia o nieruchomych typach i uważa ruchy (np. Przez przypisanie lub [`mem::replace`]) za zawsze bezpieczne.
///
/// Zamiast tego używany jest typ [`Pin`][Pin], aby zapobiec przemieszczaniu się przez system czcionek.Wskaźniki `P<T>` zawinięte w opakowanie [`Pin<P<T>>`][Pin] nie mogą być usunięte.
/// Więcej informacji na temat przypinania można znaleźć w dokumentacji [`pin` module].
///
/// Wdrożenie `Unpin` trait dla `T` znosi ograniczenia związane z unieruchamianiem typu, co następnie umożliwia przeniesienie `T` z [`Pin<P<T>>`][Pin] za pomocą funkcji takich jak [`mem::replace`].
///
///
/// `Unpin` nie ma żadnego wpływu na niepięte dane.
/// W szczególności [`mem::replace`] szczęśliwie przenosi dane `!Unpin` (działa z każdym `&mut T`, nie tylko wtedy, gdy `T: Unpin`).
/// Jednak nie możesz używać [`mem::replace`] na danych zapakowanych w [`Pin<P<T>>`][Pin], ponieważ nie możesz uzyskać `&mut T`, którego potrzebujesz do tego, i *to* sprawia, że ten system działa.
///
/// Na przykład można to zrobić tylko na typach implementujących `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Potrzebujemy zmiennego odwołania, aby wywołać `mem::replace`.
/// // Możemy uzyskać takie odniesienie, wywołując `Pin::deref_mut` przez (implicitly), ale jest to możliwe tylko dlatego, że `String` implementuje `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Ten trait jest automatycznie implementowany dla prawie każdego typu.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Typ znacznika, który nie implementuje `Unpin`.
///
/// Jeśli typ zawiera `PhantomPinned`, domyślnie nie będzie implementował `Unpin`.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementacje `Copy` dla typów pierwotnych.
///
/// Implementacje, których nie można opisać w Rust, są zaimplementowane w `traits::SelectionContext::copy_clone_conditions()` w `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Współużytkowane odniesienia można kopiować, ale zmienne odniesienia *nie*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}