#![stable(feature = "core_hint", since = "1.27.0")]

//! Wskazówki dla kompilatora, które mają wpływ na sposób emisji lub optymalizacji kodu.
//! Wskazówki mogą dotyczyć czasu kompilacji lub czasu wykonania.

use crate::intrinsics;

/// Informuje kompilator, że ten punkt w kodzie jest nieosiągalny, umożliwiając dalsze optymalizacje.
///
/// # Safety
///
/// Osiągnięcie tej funkcji jest całkowicie *niezdefiniowanym zachowaniem*(UB).W szczególności kompilator zakłada, że żadne UB nie może się nigdy wydarzyć i dlatego wyeliminuje wszystkie gałęzie, które docierają do wywołania `unreachable_unchecked()`.
///
/// Podobnie jak we wszystkich przypadkach UB, jeśli to założenie okaże się błędne, tj. Wywołanie `unreachable_unchecked()` jest faktycznie osiągalne wśród wszystkich możliwych przepływów sterowania, kompilator zastosuje niewłaściwą strategię optymalizacji, a czasami może nawet uszkodzić pozornie niepowiązany kod, powodując trudne-problemy z debugowaniem.
///
///
/// Użyj tej funkcji tylko wtedy, gdy możesz udowodnić, że kod nigdy jej nie wywoła.
/// W przeciwnym razie rozważ użycie makra [`unreachable!`], które nie pozwala na optymalizację, ale po wykonaniu panic.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` jest zawsze dodatnia (nie zero), dlatego `checked_div` nigdy nie zwróci `None`.
/////
///     // Dlatego inny branch jest nieosiągalny.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // BEZPIECZEŃSTWO: umowa bezpieczeństwa dla `intrinsics::unreachable` musi
    // być podtrzymane przez dzwoniącego.
    unsafe { intrinsics::unreachable() }
}

/// Emituje instrukcję maszynową, aby zasygnalizować procesorowi, że działa w pętli zajętości oczekiwania (" blokada spinu`).
///
/// Po odebraniu sygnału pętli spinu procesor może zoptymalizować swoje zachowanie, na przykład przez oszczędzanie energii lub przełączanie wątków hyper.
///
/// Ta funkcja różni się od [`thread::yield_now`], który bezpośrednio podlega harmonogramowi systemu, podczas gdy `spin_loop` nie współdziała z systemem operacyjnym.
///
/// Typowym przypadkiem użycia `spin_loop` jest implementacja ograniczonego optymistycznego wirowania w pętli CAS w elementach pierwotnych synchronizacji.
/// Aby uniknąć problemów, takich jak odwrócenie priorytetu, zdecydowanie zaleca się zakończenie pętli spinowej po skończonej liczbie iteracji i wykonaniu odpowiedniego blokującego wywołania systemowego.
///
///
/// **Uwaga**: Na platformach, które nie obsługują odbierania wskazówek dotyczących spin-loop, ta funkcja w ogóle nic nie robi.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Współdzielona wartość atomowa, której będą używać wątki do koordynowania
/// let live = Arc::new(AtomicBool::new(false));
///
/// // W wątku w tle ostatecznie ustawimy wartość
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Zrób trochę pracy, a potem spraw, by wartość była żywa
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Wracając do naszego aktualnego wątku, czekamy na ustawienie wartości
/// while !live.load(Ordering::Acquire) {
///     // Pętla spinowa jest wskazówką dla procesora, na który czekamy, ale prawdopodobnie nie trwa to długo
/////
///     hint::spin_loop();
/// }
///
/// // Wartość jest teraz ustawiona
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // BEZPIECZEŃSTWO: atr `cfg` zapewnia, że wykonujemy to tylko na celach x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // BEZPIECZEŃSTWO: atr `cfg` zapewnia, że wykonujemy to tylko na celach x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // BEZPIECZEŃSTWO: atr `cfg` zapewnia, że wykonujemy to tylko na celach aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // BEZPIECZEŃSTWO: atr `cfg` zapewnia, że wykonujemy to tylko na celach uzbrojonych
            // z obsługą funkcji v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Funkcja tożsamości, która *__ wskazuje __* kompilatorowi, aby był maksymalnie pesymistyczny w kwestii tego, co może zrobić `black_box`.
///
/// W przeciwieństwie do [`std::convert::identity`], kompilator Rust jest zachęcany do założenia, że `black_box` może używać `dummy` w każdy możliwy prawidłowy sposób, na jaki zezwala kod Rust, bez wprowadzania niezdefiniowanego zachowania w kodzie wywołującym.
///
/// Ta właściwość sprawia, że `black_box` jest przydatny do pisania kodu, w którym pewne optymalizacje nie są pożądane, takie jak testy wzorcowe.
///
/// Należy jednak pamiętać, że `black_box` jest (i może być tylko) dostarczane na podstawie "best-effort".Stopień, w jakim może blokować optymalizacje, może się różnić w zależności od używanej platformy i zaplecza genów kodu.
/// Programy nie mogą w żaden sposób polegać na `black_box` pod względem *poprawności*.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Musimy "use" argument w jakiś sposób, w jaki LLVM nie może introspekować, a w przypadku celów, które go obsługują, możemy zwykle wykorzystać do tego asemblację inline.
    // Interpretacja LLVM montażu inline jest taka, że jest to czarna skrzynka.
    // To nie jest najlepsza implementacja, ponieważ prawdopodobnie zmniejsza optymalizację bardziej niż chcemy, ale jak dotąd jest wystarczająco dobra.
    //
    //

    #[cfg(not(miri))] // To tylko wskazówka, więc w Miri można pominąć.
    // BEZPIECZEŃSTWO: montaż inline nie działa.
    unsafe {
        // FIXME: Nie można użyć `asm!`, ponieważ nie obsługuje MIPS i innych architektur.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}