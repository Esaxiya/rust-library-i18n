//! Rust adaptacja algorytmu Grisu3 opisana w " Szybkie i dokładne drukowanie liczb zmiennoprzecinkowych za pomocą liczb całkowitych` [^ 1].
//! Wykorzystuje około 1 KB wstępnie obliczonej tabeli, co z kolei jest bardzo szybkie dla większości danych wejściowych.
//!
//! [^1]: Florian Loitsch.2010. Szybkie drukowanie liczb zmiennoprzecinkowych i
//!   dokładnie za pomocą liczb całkowitych.SIGPLAN Nie.45, 6 (czerwiec 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// uzasadnienie w komentarzach w `format_shortest_opt`.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Biorąc pod uwagę `x > 0`, zwraca `(k, 10^k)` takie, że `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Najkrótsza implementacja trybu dla Grisu.
///
/// Zwraca `None`, jeśli w przeciwnym razie zwróciłby niedokładną reprezentację.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // potrzebujemy co najmniej trzech bitów dodatkowej precyzji

    // zacznij od znormalizowanych wartości ze wspólnym wykładnikiem
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // znajdź dowolny `cached = 10^minusk` taki, że `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // ponieważ `plus` jest znormalizowany, oznacza to `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // biorąc pod uwagę nasz wybór `ALPHA` i `GAMMA`, umieszcza to `plus * cached` w `[4, 2^32)`.
    //
    // jest oczywiście pożądane, aby zmaksymalizować `GAMMA - ALPHA`, abyśmy nie potrzebowali wielu buforowanych potęg 10, ale są pewne kwestie:
    //
    //
    // 1. chcemy zachować `floor(plus * cached)` w `u32`, ponieważ wymaga to kosztownego podziału.
    //    (nie da się tego naprawdę uniknąć, reszta jest wymagana do oszacowania dokładności).
    // 2.
    // pozostała część `floor(plus * cached)` jest wielokrotnie mnożona przez 10 i nie powinna się przepełniać.
    //
    // pierwsza daje `64 + GAMMA <= 32`, a druga `10 * 2^-ALPHA <= 2^64`;
    // -60 a -32 to maksymalny zakres z tym ograniczeniem, a V8 również ich używa.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skalowanie fps.daje to maksymalny błąd 1 ulp (udowodniony na podstawie Twierdzenia 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-rzeczywisty zakres minusa
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // powyżej `minus`, `v` i `plus` są *kwantowanymi* przybliżeniami (błąd <1 ulp).
    // ponieważ nie wiemy, czy błąd jest dodatni czy ujemny, używamy dwóch przybliżeń rozmieszczonych w równych odstępach i maksymalny błąd wynosi 2 ulps.
    //
    // "unsafe region" to liberalny przedział, który początkowo generujemy.
    // "safe region" to konserwatywny przedział, który akceptujemy tylko.
    // zaczynamy od prawidłowego powtórzenia w niebezpiecznym regionie i próbujemy znaleźć najbliższy repr do `v`, który również znajduje się w bezpiecznym regionie.
    // jeśli nie możemy, poddajemy się.
    //
    let plus1 = plus.f + 1;
    // niech plus0 = plus.f, 1;//tylko dla wyjaśnienia niech minus0 = minus.f + 1;//tylko dla wyjaśnienia
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // wspólny wykładnik

    // podziel `plus1` na części integralne i ułamkowe.
    // Integralne części gwarantują dopasowanie do u32, ponieważ buforowana moc gwarantuje, że `plus < 2^32`, a znormalizowany `plus.f` jest zawsze mniejszy niż `2^64 - 2^4` ze względu na wymaganą precyzję.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // obliczyć największy `10^max_kappa` nie więcej niż `plus1` (a więc `plus1 < 10^(max_kappa+1)`).
    // jest to górna granica `kappa` poniżej.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Twierdzenie 6.2: jeśli `k` jest największą liczbą całkowitą st
    // `0 <= y mod 10^k <= y - x`,              to `V = floor(y / 10^k) * 10^k` znajduje się w `[x, y]` i jest jedną z najkrótszych reprezentacji (z minimalną liczbą cyfr znaczących) w tym zakresie.
    //
    //
    // znajdź długość cyfry `kappa` między `(minus1, plus1)` zgodnie z Twierdzeniem 6.2.
    // Twierdzenie 6.2 można przyjąć, aby wykluczyć `x`, wymagając zamiast tego `y mod 10^k < y - x`.
    // (np. `x` =32000, `y` =32777; `kappa` =2 od `y mod 10 ^ 3=777 <y, x=777`.) algorytm opiera się na późniejszej fazie weryfikacji, aby wykluczyć `y`.
    //
    let delta1 = plus1 - minus1;
    // niech delta1int=(delta1>> e) as usize;//tylko dla wyjaśnienia
    let delta1frac = delta1 & ((1 << e) - 1);

    // renderuj integralne części, sprawdzając dokładność na każdym kroku.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // cyfry jeszcze do renderowania
    loop {
        // zawsze mamy co najmniej jedną cyfrę do renderowania, jako niezmienniki `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (wynika, że `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // podziel `remainder` przez `10^kappa`.oba są skalowane przez `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; znaleźliśmy właściwy `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // wyskaluj 10 ^ kappa z powrotem do wspólnego wykładnika
            return round_and_weed(
                // BEZPIECZEŃSTWO: zainicjowaliśmy tę pamięć powyżej.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // przerwać pętlę, gdy wyrenderowaliśmy wszystkie cyfry całkowite.
        // dokładna liczba cyfr to `max_kappa + 1` jako `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // przywrócić niezmienniki
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // renderuj części ułamkowe, sprawdzając dokładność na każdym kroku.
    // tym razem polegamy na wielokrotnych mnożeniach, ponieważ dzielenie straci precyzję.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // następna cyfra powinna być znacząca, ponieważ przetestowaliśmy ją przed wyłamaniem niezmienników, gdzie `m = max_kappa + 1` (liczba cyfr w części integralnej):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // nie przelewa się, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // podziel `remainder` przez `10^kappa`.
        // oba są skalowane przez `2^e / 10^kappa`, więc ta ostatnia jest tutaj niejawna.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // niejawny dzielnik
            return round_and_weed(
                // BEZPIECZEŃSTWO: zainicjowaliśmy tę pamięć powyżej.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // przywrócić niezmienniki
        kappa -= 1;
        remainder = r;
    }

    // wygenerowaliśmy wszystkie znaczące cyfry `plus1`, ale nie jesteśmy pewni, czy jest to optymalna.
    // na przykład, jeśli `minus1` to 3,14153 ... a `plus1` to 3,14158 ..., istnieje 5 różnych najkrótszych reprezentacji od 3.14154 do 3.14158, ale mamy tylko największą.
    // musimy sukcesywnie zmniejszać ostatnią cyfrę i sprawdzać, czy jest to optymalna repr.
    // jest maksymalnie 9 kandydatów (od ..1 do ..9), więc jest to dość szybkie.(Faza "rounding")
    //
    // funkcja sprawdza, czy ten "optimal" repr faktycznie mieści się w zakresach ulp, a także jest możliwe, że "second-to-optimal" repr może być rzeczywiście optymalny ze względu na błąd zaokrąglenia.
    // w obu przypadkach zwraca `None`.
    // (Faza "weeding")
    //
    // wszystkie argumenty są tutaj skalowane według wspólnej (ale niejawnej) wartości `k`, tak że:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (a także `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (a także `threshold > plus1v` z poprzednich niezmienników)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // wykonaj dwa przybliżenia do `v` (właściwie `plus1 - v`) w ramach ulps 1.5.
        // wynikowa reprezentacja powinna być najbliższa obu.
        //
        // tutaj `plus1 - v` jest używany, ponieważ obliczenia są wykonywane w odniesieniu do `plus1` w celu uniknięcia overflow/underflow (stąd pozornie zamienione nazwy).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // zmniejsz ostatnią cyfrę i zatrzymaj się na reprezentacji najbliższej `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // pracujemy z przybliżonymi cyframi `w(n)`, które początkowo są równe `plus1 - plus1 % 10^kappa`.po uruchomieniu korpusu pętli razy `n`, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // ustawiamy `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (stąd `reszta= plus1w(0)`), aby uprościć sprawdzanie.
            // zauważ, że `plus1w(n)` zawsze rośnie.
            //
            // mamy trzy warunki do rozwiązania.każdy z nich uniemożliwi kontynuowanie pętli, ale i tak mamy co najmniej jedną prawidłową reprezentację, o której wiadomo, że jest najbliższa `v + 1 ulp`.
            // oznaczymy je jako TC1 do TC3 dla zwięzłości.
            //
            // TC1: `w(n) <= v + 1 ulp`, czyli jest to ostatni repr, który może być najbliższy.
            // jest to odpowiednik `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // w połączeniu z TC2 (który sprawdza, czy `w(n+1)` is valid), zapobiega to ewentualnemu przepełnieniu przy obliczaniu `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, tj. Następny repr zdecydowanie nie zaokrągla się do `v`.
            // jest to odpowiednik `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // lewa strona może się przepełnić, ale znamy `threshold > plus1v`, więc jeśli TC1 jest fałszywe, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` i możemy bezpiecznie przetestować, czy zamiast tego `threshold - plus1w(n) < 10^kappa`.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, czyli następny repr to
            // nie bliżej `v + 1 ulp` niż obecny repr.
            // biorąc pod uwagę `z(n) = plus1v_up - plus1w(n)`, staje się to `abs(z(n)) <= abs(z(n+1))`.ponownie zakładając, że TC1 jest fałszywe, mamy `z(n) > 0`.mamy do rozważenia dwa przypadki:
            //
            // - kiedy `z(n+1) >= 0`: TC3 staje się `z(n) <= z(n+1)`.
            // gdy `plus1w(n)` rośnie, `z(n)` powinno maleć i jest to oczywiście nieprawda.
            // - kiedy `z(n+1) < 0`:
            //   - TC3a: warunek wstępny to `plus1v_up < plus1w(n) + 10^kappa`.zakładając, że TC2 jest fałszywe, `threshold >= plus1w(n) + 10^kappa` więc nie może się przepełnić.
            //   - TC3b: TC3 staje się `z(n) <= -z(n+1)`, tj. `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   zanegowany TC1 daje `plus1v_up > plus1w(n)`, więc nie może przepełniać ani niedomiar w połączeniu z TC3a.
            //
            // w konsekwencji powinniśmy zatrzymać się, gdy `TC1 || TC2 || (TC3a && TC3b)`.następujący jest równy jego odwrotności, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // najkrótsze powtórzenie nie może kończyć się na `0`
                plus1w += ten_kappa;
            }
        }

        // sprawdź, czy ta reprezentacja jest również najbliższą reprezentacją `v - 1 ulp`.
        //
        // jest to po prostu takie samo jak warunki zakończenia dla `v + 1 ulp`, gdzie wszystkie `plus1v_up` zostały zastąpione przez `plus1v_down`.
        // analiza przepełnienia jest równie ważna.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // teraz mamy najbliższą reprezentację `v` między `plus1` i `minus1`.
        // jest to jednak zbyt liberalne, więc odrzucamy każdy `w(n)` nie między `plus0` a `minus0`, tj. `plus1 - plus1w(n) <= minus0` lub `plus1 - plus1w(n) >= plus0`.
        // wykorzystujemy fakty, że `threshold = plus1 - minus1` i `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Najkrótsza implementacja trybu dla Grisu z rezerwą Dragon.
///
/// Powinno to być używane w większości przypadków.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // BEZPIECZEŃSTWO: narzędzie do sprawdzania pożyczek nie jest wystarczająco inteligentne, aby pozwolić nam korzystać z `buf`
    // w drugim branch, więc tutaj pierzemy całe życie.
    // Ale ponownie używamy `buf` tylko wtedy, gdy `format_shortest_opt` zwrócił `None`, więc jest to w porządku.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Dokładna i ustalona implementacja trybu Grisu.
///
/// Zwraca `None`, jeśli w przeciwnym razie zwróciłby niedokładną reprezentację.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // potrzebujemy co najmniej trzech bitów dodatkowej precyzji
    assert!(!buf.is_empty());

    // normalizuj i skaluj `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // podziel `v` na części integralne i ułamkowe.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // zarówno stary `v`, jak i nowy `v` (skalowany przez `10^-k`) mają błąd <1 ulp (Twierdzenie 5.1).
    // ponieważ nie wiemy, czy błąd jest dodatni czy ujemny, używamy dwóch przybliżeń rozmieszczonych w równych odstępach i mamy maksymalny błąd 2 ulps (taki sam jak w najkrótszym przypadku).
    //
    //
    // celem jest znalezienie dokładnie zaokrąglonej serii cyfr, które są wspólne dla `v - 1 ulp` i `v + 1 ulp`, abyśmy byli maksymalnie pewni.
    // jeśli nie jest to możliwe, nie wiemy, który z nich jest prawidłowym wyjściem dla `v`, więc poddajemy się i wycofujemy.
    //
    // `err` jest tutaj zdefiniowany jako `1 ulp * 2^e` (tak samo jak ulp w `vfrac`) i będziemy go skalować za każdym razem, gdy `v` zostanie przeskalowany.
    //
    //
    //
    let mut err = 1;

    // obliczyć największy `10^max_kappa` nie więcej niż `v` (a więc `v < 10^(max_kappa+1)`).
    // jest to górna granica `kappa` poniżej.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // jeśli pracujemy z ograniczeniem do ostatniej cyfry, musimy skrócić bufor przed faktycznym renderowaniem, aby uniknąć podwójnego zaokrąglania.
    //
    // zwróć uwagę, że musimy ponownie powiększyć bufor, gdy nastąpi zaokrąglenie w górę!
    let len = if exp <= limit {
        // Ups, nie możemy nawet wyprodukować *jednej* cyfry.
        // jest to możliwe, gdy, powiedzmy, mamy coś takiego jak 9.5 i jest zaokrąglane do 10.
        //
        // w zasadzie możemy natychmiast wywołać `possibly_round` z pustym buforem, ale skalowanie `max_ten_kappa << e` o 10 może spowodować przepełnienie.
        //
        // w ten sposób jesteśmy niechlujni i poszerzamy zakres błędu o współczynnik 10.
        // zwiększy to współczynnik fałszywie ujemnych wyników, ale tylko bardzo,*bardzo* nieznacznie;
        // może to mieć znaczenie tylko wtedy, gdy mantysa jest większa niż 60 bitów.
        //
        // BEZPIECZEŃSTWO: `len=0`, więc obowiązek zainicjowania tej pamięci jest trywialny.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // renderować integralne części.
    // błąd jest całkowicie ułamkowy, więc nie musimy go sprawdzać w tej części.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // cyfry jeszcze do renderowania
    loop {
        // zawsze mamy co najmniej jedną cyfrę do renderowania niezmienników:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (wynika, że `remainder = vint % 10^(kappa+1)`)
        //
        //

        // podziel `remainder` przez `10^kappa`.oba są skalowane przez `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // czy bufor jest pełny?uruchom przebieg zaokrąglania z pozostałą częścią.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // BEZPIECZEŃSTWO: zainicjowaliśmy `len` wiele bajtów.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // przerwać pętlę, gdy wyrenderowaliśmy wszystkie cyfry całkowite.
        // dokładna liczba cyfr to `max_kappa + 1` jako `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // przywrócić niezmienniki
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // renderuj części ułamkowe.
    //
    // w zasadzie możemy przejść do ostatniej dostępnej cyfry i sprawdzić poprawność.
    // niestety pracujemy z liczbami całkowitymi o skończonej wielkości, więc potrzebujemy jakiegoś kryterium, aby wykryć przepełnienie.
    // V8 używa `remainder > err`, które staje się fałszywe, gdy pierwsze cyfry znaczące `i` `v - 1 ulp` i `v` różnią się.
    // jednak to odrzuca zbyt wiele innych poprawnych danych wejściowych.
    //
    // ponieważ późniejsza faza ma poprawne wykrywanie przepełnienia, zamiast tego używamy ściślejszego kryterium:
    // kontynuujemy, aż `err` przekroczy `10^kappa / 2`, tak aby zakres między `v - 1 ulp` i `v + 1 ulp` zdecydowanie zawierał dwie lub więcej zaokrąglonych reprezentacji.
    //
    // jest to to samo, co w przypadku pierwszych dwóch porównań z `possibly_round`, w celach informacyjnych.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // niezmienniki, gdzie `m = max_kappa + 1` (liczba cyfr w części integralnej):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // nie przelewa się, `2^e * 10 < 2^64`
        err *= 10; // nie przelewa się, `err * 10 < 2^e * 5 < 2^64`

        // podziel `remainder` przez `10^kappa`.
        // oba są skalowane przez `2^e / 10^kappa`, więc ta ostatnia jest tutaj niejawna.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // czy bufor jest pełny?uruchom przebieg zaokrąglania z pozostałą częścią.
        if i == len {
            // BEZPIECZEŃSTWO: zainicjowaliśmy `len` wiele bajtów.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // przywrócić niezmienniki
        remainder = r;
    }

    // dalsze obliczenia są bezużyteczne (`possibly_round` zdecydowanie się nie udaje), więc poddajemy się.
    return None;

    // wygenerowaliśmy wszystkie żądane cyfry `v`, które powinny być takie same jak odpowiednie cyfry `v - 1 ulp`.
    // teraz sprawdzamy, czy istnieje unikalna reprezentacja wspólna zarówno dla `v - 1 ulp`, jak i `v + 1 ulp`;może to być to samo co wygenerowane cyfry lub zaokrąglona wersja tych cyfr.
    //
    // jeśli zakres zawiera wiele reprezentacji o tej samej długości, nie możemy być tego pewni i zamiast tego powinniśmy zwrócić `None`.
    //
    // wszystkie argumenty są tutaj skalowane według wspólnej (ale niejawnej) wartości `k`, tak że:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // BEZPIECZEŃSTWO: pierwsze bajty `len` `buf` muszą zostać zainicjowane.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (w celach informacyjnych linia przerywana wskazuje dokładną wartość możliwych reprezentacji w podanej liczbie cyfr).
        //
        //
        // błąd jest zbyt duży, że istnieją co najmniej trzy możliwe reprezentacje między `v - 1 ulp` i `v + 1 ulp`.
        // nie możemy określić, który z nich jest poprawny.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // w rzeczywistości 1/2 ulp wystarczy, aby wprowadzić dwie możliwe reprezentacje.
        // (pamiętaj, że potrzebujemy unikalnej reprezentacji zarówno dla `v - 1 ulp`, jak i `v + 1 ulp`). To nie przepełni, jak `ulp < ten_kappa` z pierwszego sprawdzenia.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // jeśli `v + 1 ulp` jest bliżej reprezentacji zaokrąglonej w dół (która jest już w `buf`), to możemy bezpiecznie wrócić.
        // zwróć uwagę, że `v - 1 ulp`*może* być mniejsze niż bieżąca reprezentacja, ale jako `1 ulp < 10^kappa / 2` ten warunek jest wystarczający:
        // odległość między `v - 1 ulp` a bieżącą reprezentacją nie może przekraczać `10^kappa / 2`.
        //
        // warunek jest równy `remainder + ulp < 10^kappa / 2`.
        // ponieważ może to łatwo się przepełnić, najpierw sprawdź, czy `remainder < 10^kappa / 2`.
        // już sprawdziliśmy, że `ulp < 10^kappa / 2`, więc dopóki `10^kappa` nie przepełniło się mimo wszystko, drugie sprawdzenie jest w porządku.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // BEZPIECZEŃSTWO: nasz rozmówca zainicjował tę pamięć.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------pozostała część------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // z drugiej strony, jeśli `v - 1 ulp` jest bliżej zaokrąglonej reprezentacji, powinniśmy zaokrąglić w górę i wrócić.
        // z tego samego powodu nie musimy sprawdzać `v + 1 ulp`.
        //
        // warunek jest równy `remainder - ulp >= 10^kappa / 2`.
        // ponownie najpierw sprawdzamy, czy `remainder > ulp` (zauważ, że to nie jest `remainder >= ulp`, ponieważ `10^kappa` nigdy nie jest zerem).
        //
        // Zauważ też, że `remainder - ulp <= 10^kappa`, więc drugie sprawdzenie nie przepełnia.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // BEZPIECZEŃSTWO: nasz rozmówca musiał zainicjować tę pamięć.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // dodaj dodatkową cyfrę tylko wtedy, gdy zażądano od nas stałej precyzji.
                // musimy również sprawdzić, czy jeśli oryginalny bufor był pusty, dodatkową cyfrę można dodać tylko wtedy, gdy `exp == limit` (przypadek edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // BEZPIECZEŃSTWO: my i nasz rozmówca zainicjowaliśmy tę pamięć.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // w przeciwnym razie jesteśmy skazani na porażkę (np. niektóre wartości między `v - 1 ulp` i `v + 1 ulp` są zaokrąglane w dół, a inne w górę) i poddajemy się.
        //
        None
    }
}

/// Dokładna i ustalona implementacja trybu Grisu z funkcją awaryjną Dragon.
///
/// Powinno to być używane w większości przypadków.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // BEZPIECZEŃSTWO: narzędzie do sprawdzania pożyczek nie jest wystarczająco inteligentne, aby pozwolić nam korzystać z `buf`
    // w drugim branch, więc tutaj pierzemy całe życie.
    // Ale ponownie używamy `buf` tylko wtedy, gdy `format_exact_opt` zwrócił `None`, więc jest to w porządku.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}