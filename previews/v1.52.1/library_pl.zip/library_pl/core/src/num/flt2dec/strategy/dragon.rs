//! Prawie bezpośrednie (ale nieco zoptymalizowane) tłumaczenie Rust rysunku 3 " Szybkie i dokładne drukowanie liczb zmiennoprzecinkowych` [^ 1].
//!
//!
//! [^1]: Burger, RG i Dybvig, RK 1996. Drukowanie liczb zmiennoprzecinkowych
//!   szybko i dokładnie.SIGPLAN Nie.31,5 (maj 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// wstępnie obliczone tablice " cyfr` dla 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// do użytku tylko wtedy, gdy `x < 16 * scale`;`scaleN` powinno być `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Najkrótsza implementacja trybu dla Smoka.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // numer `v` do sformatowania to:
    // - równe `mant * 2^exp`;
    // - poprzedzone `(mant - 2 *minus)* 2^exp` w oryginalnym typie;i
    // - po którym następuje `(mant + 2 *plus)* 2^exp` w oryginalnym typie.
    //
    // oczywiście `minus` i `plus` nie mogą wynosić zero.(w przypadku nieskończoności używamy wartości spoza zakresu.) również zakładamy, że jest generowana co najmniej jedna cyfra, tj. `mant` też nie może być zerem.
    //
    // oznacza to również, że każda liczba między `low = (mant - minus)*2^exp` a `high = (mant + plus)* 2^exp` będzie mapowana na tę dokładną liczbę zmiennoprzecinkową, z granicami zawartymi, gdy oryginalna mantysa była parzysta (tj. `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` to `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // oszacuj `k_0` na podstawie oryginalnych wejść spełniających `10^(k_0-1) < high <= 10^(k_0+1)`.
    // ścisłe powiązanie `k` spełniające `10^(k-1) < high <= 10^k` jest obliczane później.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // przekonwertuj `{mant, plus, minus} * 2^exp` na postać ułamkową, tak aby:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // podziel `mant` przez `10^k`.teraz `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // fixup, gdy `mant + plus > scale` (lub `>=`).
    // w rzeczywistości nie modyfikujemy `scale`, ponieważ zamiast tego możemy pominąć początkowe mnożenie.
    // teraz `scale < mant + plus <= scale * 10` i jesteśmy gotowi do generowania cyfr.
    //
    // zwróć uwagę, że `d[0]`*może* wynosić zero, gdy `scale - plus < mant < scale`.
    // w tym przypadku warunek zaokrąglania w górę (`up` poniżej) zostanie wywołany natychmiast.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // odpowiednik skalowania `scale` o 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // pamięć podręczna `(2, 4, 8) * scale` do generowania cyfr.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // niezmienniki, gdzie `d[0..n-1]` to cyfry wygenerowane do tej pory:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (stąd `mant / scale < 10`) gdzie `d[i..j]` jest skrótem od `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // wygeneruj jedną cyfrę: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // to jest uproszczony opis zmodyfikowanego algorytmu Smoka.
        // dla wygody pominięto wiele pośrednich wyprowadzeń i argumentów dotyczących kompletności.
        //
        // zacznij od zmodyfikowanych niezmienników, ponieważ zaktualizowaliśmy `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // załóżmy, że `d[0..n-1]` jest najkrótszą reprezentacją między `low` i `high`, tj. `d[0..n-1]` spełnia oba poniższe warunki, ale `d[0..n-2]` nie:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijektywność: cyfry zaokrąglone do `v`);i
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (ostatnia cyfra jest poprawna).
        //
        // drugi warunek upraszcza się do `2 * mant <= scale`.
        // rozwiązanie niezmienników w kategoriach `mant`, `low` i `high` daje prostszą wersję pierwszego warunku: `-plus < mant < minus`.
        // od `-plus < 0 <= mant` mamy poprawną najkrótszą reprezentację, gdy `mant < minus` i `2 * mant <= scale`.
        // (pierwsza staje się `mant <= minus`, gdy oryginalna mantysa jest parzysta).
        //
        // gdy druga nie trzyma się (`2 * mant> scale`), musimy zwiększyć ostatnią cyfrę.
        // to wystarczy do przywrócenia tego stanu: już wiemy, że generacja cyfr gwarantuje `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // w tym przypadku pierwszym warunkiem jest `-plus < mant - scale < minus`.
        // od `mant < scale` po generacji mamy `scale < mant + plus`.
        // (ponownie staje się `scale <= mant + plus`, gdy oryginalna mantysa jest parzysta).
        //
        // w skrócie:
        // - zatrzymaj i zaokrąglij `down` (zachowaj cyfry bez zmian), gdy `mant < minus` (lub `<=`).
        // - zatrzymaj i zaokrąglij `up` (zwiększ ostatnią cyfrę), gdy `scale < mant + plus` (lub `<=`).
        // - generuj w przeciwnym razie.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // mamy najkrótszą reprezentację, przejdź do zaokrąglania

        // przywrócić niezmienniki.
        // to sprawia, że algorytm zawsze się kończy: `minus` i `plus` zawsze rośnie, ale `mant` jest obcinany modulo `scale` i `scale` jest ustalony.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // zaokrąglanie w górę ma miejsce, gdy i) został spełniony tylko warunek zaokrąglania lub ii) oba warunki zostały uruchomione i zerwanie remisu preferuje zaokrąglanie w górę.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // jeśli zaokrąglenie w górę zmienia długość, wykładnik również powinien się zmienić.
        // wydaje się, że ten warunek jest bardzo trudny do spełnienia (być może niemożliwy), ale tutaj jesteśmy po prostu bezpieczni i konsekwentni.
        //
        // BEZPIECZEŃSTWO: zainicjowaliśmy tę pamięć powyżej.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // BEZPIECZEŃSTWO: zainicjowaliśmy tę pamięć powyżej.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Dokładna i ustalona implementacja trybu Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // oszacuj `k_0` na podstawie oryginalnych wejść spełniających `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // podziel `mant` przez `10^k`.teraz `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fixup when `mant + plus >= scale`, gdzie `plus / scale = 10^-buf.len() / 2`.
    // aby zachować bignum o stałym rozmiarze, w rzeczywistości używamy `mant + floor(plus) >= scale`.
    // w rzeczywistości nie modyfikujemy `scale`, ponieważ zamiast tego możemy pominąć początkowe mnożenie.
    // znowu z najkrótszym algorytmem `d[0]` może wynosić zero, ale ostatecznie zostanie zaokrąglone w górę.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // odpowiednik skalowania `scale` o 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // jeśli pracujemy z ograniczeniem do ostatniej cyfry, musimy skrócić bufor przed faktycznym renderowaniem, aby uniknąć podwójnego zaokrąglania.
    //
    // zwróć uwagę, że musimy ponownie powiększyć bufor, gdy nastąpi zaokrąglenie w górę!
    let mut len = if k < limit {
        // Ups, nie możemy nawet wyprodukować *jednej* cyfry.
        // jest to możliwe, gdy, powiedzmy, mamy coś takiego jak 9.5 i jest zaokrąglane do 10.
        // zwracamy pusty bufor, z wyjątkiem późniejszego przypadku zaokrągleń, który ma miejsce, gdy `k == limit` i musi dać dokładnie jedną cyfrę.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // pamięć podręczna `(2, 4, 8) * scale` do generowania cyfr.
        // (może to być kosztowne, więc nie obliczaj ich, gdy bufor jest pusty).
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // wszystkie kolejne cyfry są zerami, zatrzymujemy się tutaj *nie* próbuj wykonywać zaokrąglania!raczej wypełnij pozostałe cyfry.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // BEZPIECZEŃSTWO: zainicjowaliśmy tę pamięć powyżej.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // zaokrąglanie w górę, jeśli zatrzymamy się w środku cyfr, jeśli kolejne cyfry mają dokładnie 5000 ..., sprawdź poprzednią cyfrę i spróbuj zaokrąglić do parzystości (tj. unikaj zaokrąglania w górę, gdy poprzednia cyfra jest parzysta).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // BEZPIECZEŃSTWO: `buf[len-1]` jest inicjalizowany.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // jeśli zaokrąglenie w górę zmienia długość, wykładnik również powinien się zmienić.
        // ale poproszono nas o ustaloną liczbę cyfr, więc nie zmieniaj bufora ...
        // BEZPIECZEŃSTWO: zainicjowaliśmy tę pamięć powyżej.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... chyba że zamiast tego zażądano stałej precyzji.
            // musimy również sprawdzić, czy jeśli oryginalny bufor był pusty, dodatkową cyfrę można dodać tylko wtedy, gdy `k == limit` (przypadek edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // BEZPIECZEŃSTWO: zainicjowaliśmy tę pamięć powyżej.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}