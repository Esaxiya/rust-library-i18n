//! Dekoduje wartość zmiennoprzecinkową na poszczególne części i zakresy błędów.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Zdekodowana wartość skończona bez znaku, taka że:
///
/// - Oryginalna wartość to `mant * 2^exp`.
///
/// - Każda liczba od `(mant - minus)*2^exp` do `(mant + plus)* 2^exp` zostanie zaokrąglona do pierwotnej wartości.
/// Zakres obejmuje tylko `inclusive` i `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Łuskowata mantysa.
    pub mant: u64,
    /// Dolny zakres błędu.
    pub minus: u64,
    /// Górny zakres błędu.
    pub plus: u64,
    /// Współdzielony wykładnik o podstawie 2.
    pub exp: i16,
    /// Prawda, gdy zakres błędu jest włącznie.
    ///
    /// W IEEE 754 jest to prawdą, gdy oryginalna mantysa była parzysta.
    pub inclusive: bool,
}

/// Odszyfrowana wartość bez znaku.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Nieskończoności, pozytywne lub negatywne.
    Infinite,
    /// Zero, pozytywne lub negatywne.
    Zero,
    /// Liczby skończone z dalszymi zdekodowanymi polami.
    Finite(Decoded),
}

/// Typ zmiennoprzecinkowy, którym może być " decode` d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Minimalna dodatnia znormalizowana wartość.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Zwraca znak (prawda, gdy jest ujemny) i wartość `FullDecoded` z podanej liczby zmiennoprzecinkowej.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // sąsiedzi: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode zawsze zachowuje wykładnik, więc mantysa jest skalowana pod kątem wartości podrzędnych.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // sąsiedzi: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // gdzie maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // sąsiedzi: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}