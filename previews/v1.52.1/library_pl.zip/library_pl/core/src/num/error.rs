//! Typy błędów do konwersji na typy całkowite.

use crate::convert::Infallible;
use crate::fmt;

/// Typ błędu zwracany, gdy sprawdzona konwersja typu całkowitego nie powiedzie się.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Dopasuj zamiast wymuszać, aby upewnić się, że kod taki jak `From<Infallible> for TryFromIntError` powyżej będzie działał, gdy `Infallible` stanie się aliasem `!`.
        //
        //
        match never {}
    }
}

/// Błąd, który może zostać zwrócony podczas analizowania liczby całkowitej.
///
/// Ten błąd jest używany jako typ błędu dla funkcji `from_str_radix()` w typach pierwotnych liczb całkowitych, takich jak [`i8::from_str_radix`].
///
/// # Potencjalne przyczyny
///
/// Między innymi `ParseIntError` może zostać wyrzucony z powodu wiodących lub końcowych białych znaków w łańcuchu, np. Gdy jest pobierany ze standardowego wejścia.
///
/// Użycie metody [`str::trim()`] zapewnia, że przed analizą nie pozostaną żadne białe znaki.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Wyliczenie do przechowywania różnych typów błędów, które mogą spowodować niepowodzenie analizowania liczby całkowitej.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Analizowana wartość jest pusta.
    ///
    /// Wariant ten zostanie między innymi skonstruowany podczas analizowania pustego ciągu.
    Empty,
    /// Zawiera nieprawidłową cyfrę w swoim kontekście.
    ///
    /// Wariant ten zostanie między innymi skonstruowany podczas analizowania łańcucha zawierającego znak inny niż ASCII.
    ///
    /// Ten wariant jest również konstruowany, gdy `+` lub `-` jest niewłaściwie umieszczony w ciągu, samodzielnie lub w środku liczby.
    ///
    ///
    InvalidDigit,
    /// Liczba całkowita jest zbyt duża, aby przechowywać ją w docelowej liczbie całkowitej.
    PosOverflow,
    /// Liczba całkowita jest zbyt mała, aby przechowywać ją w docelowym typie liczby całkowitej.
    NegOverflow,
    /// Wartość wynosiła zero
    ///
    /// Ten wariant zostanie wyemitowany, gdy łańcuch analizy ma wartość zero, co byłoby niedozwolone w przypadku typów niezerowych.
    ///
    Zero,
}

impl ParseIntError {
    /// Wyświetla szczegółową przyczynę niepowodzenia analizy liczby całkowitej.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}