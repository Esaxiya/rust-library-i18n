//! Stałe dla 128-bitowych liczb całkowitych ze znakiem.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Nowy kod powinien używać powiązanych stałych bezpośrednio w typie pierwotnym.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }