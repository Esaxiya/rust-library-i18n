//! Stałe dla 8-bitowych liczb całkowitych bez znaku.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Nowy kod powinien używać powiązanych stałych bezpośrednio w typie pierwotnym.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }