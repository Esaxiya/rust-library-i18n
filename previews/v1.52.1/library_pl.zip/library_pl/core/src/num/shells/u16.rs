//! Stałe dla 16-bitowych liczb całkowitych bez znaku.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Nowy kod powinien używać powiązanych stałych bezpośrednio w typie pierwotnym.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }