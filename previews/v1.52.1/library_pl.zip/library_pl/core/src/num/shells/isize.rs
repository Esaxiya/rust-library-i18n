//! Stałe dla typu liczby całkowitej ze znakiem o rozmiarze wskaźnika.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Nowy kod powinien używać powiązanych stałych bezpośrednio w typie pierwotnym.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }