//! Stałe dla 16-bitowych liczb całkowitych ze znakiem.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Nowy kod powinien używać powiązanych stałych bezpośrednio w typie pierwotnym.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }