//! Funkcje użytkowe do bignum, które nie mają zbytniego sensu, aby przekształcić je w metody.

// FIXME Nazwa tego modułu jest trochę niefortunna, ponieważ inne moduły również importują `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Sprawdź, czy obcięcie wszystkich bitów mniej znaczących niż `ones_place` wprowadza względny błąd mniejszy, równy lub większy niż 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Jeśli wszystkie pozostałe bity są równe zero, to= 0.5 ULP, w przeciwnym razie> 0.5 Jeśli nie ma więcej bitów (połowa_bitu==0), poniżej również poprawnie zwraca Równe.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Konwertuje ciąg ASCII zawierający tylko cyfry dziesiętne na `u64`.
///
/// Nie sprawdza przepełnienia lub nieprawidłowych znaków, więc jeśli wywołujący nie jest ostrożny, wynik jest fałszywy i może panic (chociaż nie będzie to `unsafe`).
/// Dodatkowo puste ciągi są traktowane jako zero.
/// Ta funkcja istnieje, ponieważ
///
/// 1. używanie `FromStr` na `&[u8]` wymaga `from_utf8_unchecked`, co jest złe i
/// 2. łączenie wyników `integral.parse()` i `fractional.parse()` jest bardziej skomplikowane niż cała ta funkcja.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Konwertuje ciąg cyfr ASCII na bignum.
///
/// Podobnie jak `from_str_unchecked`, ta funkcja polega na analizatorze składni, który usuwa niecyfrowe wartości.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Rozpakowuje bignum w 64-bitową liczbę całkowitą.Panics, jeśli liczba jest za duża.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Wyodrębnia zakres bitów.

/// Indeks 0 jest najmniej znaczącym bitem, a zakres jest jak zwykle w połowie otwarty.
/// Panics jeśli zostanie poproszony o wyodrębnienie większej liczby bitów niż mieści się w zwracanym typie.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}