//! Nieco majstrować przy dodatnich pływakach IEEE 754.Liczby ujemne nie są i nie muszą być obsługiwane.
//! Normalne liczby zmiennoprzecinkowe mają reprezentację kanoniczną jako (frac, exp), tak że wartość wynosi 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), gdzie N to liczba bitów.
//!
//! Subnormalne są nieco inne i dziwne, ale obowiązuje ta sama zasada.
//!
//! Tutaj jednak reprezentujemy je jako (sig, k) z f dodatnim, tak że wartość jest f *
//! 2 <sup>e</sup> .Oprócz uczynienia "hidden bit" jawnym, zmienia to wykładnik poprzez tak zwane przesunięcie mantysy.
//!
//! Innymi słowy, normalnie zmiennoprzecinkowe są zapisywane jako (1), ale tutaj są zapisywane jako (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Nazywamy (1)**reprezentacją ułamkową**, a (2)**reprezentacją całkowitą**.
//!
//! Wiele funkcji tego modułu obsługuje tylko normalne liczby.Procedury dec2flt zachowawczo przyjmują uniwersalnie poprawną wolną ścieżkę (algorytm M) dla bardzo małych i bardzo dużych liczb.
//! Ten algorytm potrzebuje tylko next_float(), który obsługuje wartości podrzędne i zera.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Pomocnik trait, aby uniknąć powielania w zasadzie całego kodu konwersji dla `f32` i `f64`.
///
/// Zobacz komentarz do dokumentacji modułu nadrzędnego, aby dowiedzieć się, dlaczego jest to konieczne.
///
/// **Nigdy, przenigdy** nie powinien być implementowany dla innych typów ani używany poza modułem dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Typ używany przez `to_bits` i `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Dokonuje surowej transmutacji do liczby całkowitej.
    fn to_bits(self) -> Self::Bits;

    /// Wykonuje surową transmutację z liczby całkowitej.
    fn from_bits(v: Self::Bits) -> Self;

    /// Zwraca kategorię, do której należy ta liczba.
    fn classify(self) -> FpCategory;

    /// Zwraca mantysę, wykładnik i znak jako liczby całkowite.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Odszyfrowuje pływak.
    fn unpack(self) -> Unpacked;

    /// Rzuty z małej liczby całkowitej, którą można dokładnie przedstawić.
    /// Panic jeśli liczba całkowita nie może być reprezentowana, inny kod w tym module gwarantuje, że nigdy do tego nie dojdzie.
    fn from_int(x: u64) -> Self;

    /// Pobiera wartość 10 <sup>e</sup> z wstępnie obliczonej tabeli.
    /// Panics dla `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Co mówi nazwa.
    /// Łatwiej jest wykonać twardy kod niż żonglowanie elementami wewnętrznymi i mieć nadzieję, że stała LLVM to zawali.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Konserwatywne ograniczenie cyfr dziesiętnych danych wejściowych, które nie mogą powodować przepełnienia lub zera lub
    /// podnormalne.Prawdopodobnie dziesiętny wykładnik maksymalnej wartości normalnej, stąd nazwa.
    const MAX_NORMAL_DIGITS: usize;

    /// Gdy najbardziej znacząca cyfra dziesiętna ma wartość miejsca większą niż ta, liczba jest z pewnością zaokrąglana do nieskończoności.
    ///
    const INF_CUTOFF: i64;

    /// Gdy najbardziej znacząca cyfra dziesiętna ma wartość miejsca mniejszą niż ta, liczba jest z pewnością zaokrąglana do zera.
    ///
    const ZERO_CUTOFF: i64;

    /// Liczba bitów wykładnika.
    const EXP_BITS: u8;

    /// Liczba bitów w mechanizmie *łącznie z* bitem ukrytym.
    const SIG_BITS: u8;

    /// Liczba bitów w mantysie,*wyłączając* bit ukryty.
    const EXPLICIT_SIG_BITS: u8;

    /// Maksymalny prawniczy wykładnik w reprezentacji ułamkowej.
    const MAX_EXP: i16;

    /// Minimalny prawniczy wykładnik w reprezentacji ułamkowej, z wyłączeniem podnormalnych.
    const MIN_EXP: i16;

    /// `MAX_EXP` dla reprezentacji całkowej, tj. z zastosowanym przesunięciem.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` zakodowane (tj. z przesunięciem offsetowym)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` dla reprezentacji całkowej, tj. z zastosowanym przesunięciem.
    const MIN_EXP_INT: i16;

    /// Maksymalne znormalizowane znaczenie w reprezentacji integralnej.
    const MAX_SIG: u64;

    /// Minimalne znormalizowane znaczenie w reprezentacji integralnej.
    const MIN_SIG: u64;
}

// Głównie obejście dla #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Zwraca mantysę, wykładnik i znak jako liczby całkowite.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Odchylenie wykładnika + przesunięcie mantysy
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe nie jest pewien, czy `as` zaokrągla prawidłowo na wszystkich platformach.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Zwraca mantysę, wykładnik i znak jako liczby całkowite.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Odchylenie wykładnika + przesunięcie mantysy
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe nie jest pewien, czy `as` zaokrągla prawidłowo na wszystkich platformach.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Konwertuje `Fp` na najbliższy typ maszyny zmiennoprzecinkowej.
/// Nie obsługuje wyników odbiegających od normy.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f jest 64-bitowy, więc xe ma przesunięcie mantysy o 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Zaokrąglij 64-bitowy znacznik do T::SIG_BITS bitów z połową do parzystości.
/// Nie obsługuje przepełnienia wykładnika.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Dostosuj przesunięcie mantysy
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Odwrotność `RawFloat::unpack()` dla znormalizowanych liczb.
/// Panics, jeśli wartość statystyczna lub wykładnik nie są poprawne dla liczb znormalizowanych.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Usuń ukryty kawałek
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Dostosuj wykładnik dla odchylenia wykładnika i przesunięcia mantysy
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Zostaw bit znaku na 0 ("+"), wszystkie nasze liczby są dodatnie
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Skonstruuj subnormal.Mantysa 0 jest dozwolona i tworzy zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Zakodowany wykładnik to 0, bit znaku to 0, więc musimy tylko ponownie zinterpretować bity.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// W przybliżeniu bignum z Fp.Zaokrągla w 0.5 ULP z połową do parzystości.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Odcinamy wszystkie bity przed indeksem `start`, tj. Skutecznie przesuwamy w prawo o wartość `start`, więc jest to również wykładnik, którego potrzebujemy.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Zaokrąglij (half-to-even) w zależności od obciętych bitów.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Znajduje największą liczbę zmiennoprzecinkową dokładnie mniejszą niż argument.
/// Nie obsługuje podnormalnych, zerowych ani niedomiarów wykładników.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Znajdź najmniejszą liczbę zmiennoprzecinkową, która jest ściśle większa niż argument.
// Ta operacja jest nasycająca, tj. next_float(inf) ==inf.
// W przeciwieństwie do większości kodu w tym module, ta funkcja obsługuje zero, podnormalne i nieskończoności.
// Jednak, podobnie jak każdy inny kod tutaj, nie dotyczy NaN i liczb ujemnych.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Wydaje się to zbyt piękne, aby mogło być prawdziwe, ale działa.
        // 0.0 jest zakodowane jako słowo całkowicie zerowe.Podnormalne to 0x000m ... m, gdzie m to mantysa.
        // W szczególności najmniejszy podnormalny to 0x0 ... 01, a największy to 0x000F ... F.
        // Najmniejsza normalna liczba to 0x0010 ... 0, więc ten przypadek narożny również działa.
        // Jeśli przyrost przekracza mantysę, bit przenoszenia zwiększa wykładnik tak, jak chcemy, a bity mantysy stają się zerowe.
        // Ze względu na konwencję bitów ukrytych jest to dokładnie to, czego chcemy!
        // Wreszcie f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}