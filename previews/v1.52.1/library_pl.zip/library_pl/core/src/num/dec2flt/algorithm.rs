//! Różne algorytmy z artykułu.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Liczba bitów istotności w Fp
const P: u32 = 64;

// Po prostu przechowujemy najlepsze przybliżenie dla *wszystkich* wykładników, więc zmienną "h" i związane z nią warunki można pominąć.
// To oznacza zamianę wydajności na kilka kilobajtów przestrzeni.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// W większości architektur operacje zmiennoprzecinkowe mają wyraźny rozmiar bitu, dlatego precyzja obliczeń jest określana na podstawie operacji.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// W x86 x87 FPU jest używany do operacji zmiennoprzecinkowych, jeśli rozszerzenia SSE/SSE2 nie są dostępne.
// x87 FPU domyślnie działa z 80-bitową precyzją, co oznacza, że operacje będą zaokrąglane do 80 bitów, powodując podwójne zaokrąglanie, gdy wartości zostaną ostatecznie przedstawione jako
//
// 32/64 bitowe wartości zmiennoprzecinkowe.Aby temu zaradzić, słowo sterujące FPU można ustawić tak, aby obliczenia były wykonywane z wymaganą precyzją.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Struktura używana do zachowania pierwotnej wartości słowa sterującego FPU, tak aby można ją było przywrócić, gdy struktura zostanie usunięta.
    ///
    ///
    /// x87 FPU to 16-bitowy rejestr, którego pola są następujące:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokumentacja dla wszystkich pól jest dostępna w podręczniku programisty IA-32 Architectures Software Developer's Manual (tom 1).
    ///
    /// Jedynym polem, które ma znaczenie dla poniższego kodu, jest PC, Precision Control.
    /// To pole określa precyzję operacji wykonywanych przez FPU.
    /// Można ustawić na:
    ///  - 0b00, pojedyncza precyzja, tj. 32 bity
    ///  - 0b10, podwójna precyzja, czyli 64 bity
    ///  - 0b11, podwójna rozszerzona precyzja, tj. 80 bitów (stan domyślny) Wartość 0b01 jest zarezerwowana i nie powinna być używana.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // BEZPIECZEŃSTWO: instrukcja `fldcw` została poddana audytowi, aby móc poprawnie współpracować z
        // dowolny `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Używamy składni ATT do obsługi LLVM 8 i LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Ustawia pole precyzji FPU na `T` i zwraca `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Oblicz wartość pola Precision Control, która jest odpowiednia dla `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bity
            8 => 0x0200, // 64 bity
            _ => 0x0300, // domyślnie 80 bitów
        };

        // Uzyskaj oryginalną wartość słowa kontrolnego, aby przywrócić je później, gdy struktura `FPUControlWord` zostanie usunięta BEZPIECZEŃSTWO: instrukcja `fnstcw` została poddana audytowi, aby móc poprawnie współpracować z dowolnym `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Używamy składni ATT do obsługi LLVM 8 i LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Ustaw słowo sterujące na żądaną dokładność.
        // Osiąga się to poprzez zamaskowanie starej precyzji (bity 8 i 9, 0x300) i zastąpienie jej flagą precyzji obliczoną powyżej.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Szybka ścieżka Bellerophon przy użyciu liczb całkowitych o rozmiarze maszynowym i liczb zmiennoprzecinkowych.
///
/// Jest to wydzielone do osobnej funkcji, dzięki czemu można spróbować przed skonstruowaniem bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Porównujemy dokładną wartość z MAX_SIG pod koniec, jest to po prostu szybkie, tanie odrzucenie (a także uwalnia resztę kodu od martwienia się o niedomiar).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Szybka ścieżka w dużej mierze zależy od zaokrąglenia arytmetyki do prawidłowej liczby bitów bez żadnego zaokrąglania pośredniego.
    // Na x86 (bez SSE lub SSE2) wymaga to zmiany precyzji stosu x87 FPU, tak aby był on bezpośrednio zaokrąglany do bitu 64/32.
    // Funkcja `set_precision` dba o ustawienie precyzji na architekturach, które wymagają ustawienia poprzez zmianę stanu globalnego (jak słowo sterujące w x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Przypadku e <0 nie można złożyć do drugiego odgałęzienia Z0.
    // Ujemne moce powodują powtarzanie się części ułamkowej w systemie binarnym, które są zaokrąglane, co powoduje rzeczywiste (i czasami dość znaczące!) Błędy w wyniku końcowym.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorytm Bellerophon to trywialny kod uzasadniony nietrywialną analizą numeryczną.
///
/// Zaokrągla `` f '' do liczby zmiennoprzecinkowej z 64-bitową istotnością i mnoży ją przez najlepsze przybliżenie `10^e` (w tym samym formacie zmiennoprzecinkowym).To często wystarcza, aby uzyskać prawidłowy wynik.
/// Jednak gdy wynik jest bliski połowy odległości między dwoma sąsiednimi pływakami (ordinary), złożony błąd zaokrąglania z pomnożenia dwóch przybliżeń oznacza, że wynik może być odbiegający o kilka bitów.
/// Kiedy tak się dzieje, iteracyjny algorytm R naprawia sytuację.
///
/// Ręcznie falowane "close to halfway" jest precyzyjne dzięki analizie numerycznej w artykule.
/// Słowami Clingera:
///
/// > Slop, wyrażony w jednostkach najmniej znaczącego bitu, stanowi ograniczenie dla błędu
/// > skumulowane podczas obliczania zmiennoprzecinkowego przybliżenia do f * 10 ^ e.(Slop jest
/// > nie jest granicą prawdziwego błędu, ale ogranicza różnicę między aproksymacją zi
/// > najlepsze możliwe przybliżenie, które wykorzystuje bity istotności).
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Przypadki abs(e) <log5(2^N) znajdują się w fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Czy slop jest wystarczająco duży, aby mieć znaczenie przy zaokrąglaniu do n bitów?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Iteracyjny algorytm poprawiający przybliżenie zmiennoprzecinkowe `f * 10^e`.
///
/// Każda iteracja przybliża jedną jednostkę na ostatnim miejscu, co oczywiście zajmuje bardzo dużo czasu, aby zbiegać się, jeśli `z0` jest nawet lekko wyłączony.
/// Na szczęście, gdy jest używany jako rezerwowy dla Bellerophon, początkowe przybliżenie jest wyłączone o co najwyżej jeden ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Znajdź dodatnie liczby całkowite `x`, `y` takie, że `x / y` jest dokładnie `(f *10^e) / (m* 2^k)`.
        // To nie tylko pozwala uniknąć zajmowania się znakami `e` i `k`, ale także eliminuje moc dwóch wspólnych dla `10^e` i `2^k`, aby zmniejszyć liczby.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Jest to napisane trochę niezręcznie, ponieważ nasze bignum nie obsługują liczb ujemnych, więc używamy informacji o wartości bezwzględnej + znaku.
        // Mnożenie przez m_digits nie może się przepełnić.
        // Jeśli `x` lub `y` są na tyle duże, że musimy się martwić przepełnieniem, to są również na tyle duże, że `make_ratio` zmniejszył ułamek o współczynnik 2 ^ 64 lub więcej.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Nie potrzebujesz już x, zachowaj clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Nadal potrzebuję, zrób kopię.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Biorąc pod uwagę `x = f` i `y = m`, gdzie `f` reprezentuje wejściowe cyfry dziesiętne jak zwykle, a `m` jest znacznikiem aproksymacji zmiennoprzecinkowej, spraw, aby stosunek `x / y` był równy `(f *10^e) / (m* 2^k)`, prawdopodobnie zmniejszony o potęgę dwóch, które mają wspólną wartość.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, z tym wyjątkiem, że zmniejszamy ułamek o pewną potęgę dwóch.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m To nie może się przepełnić, ponieważ wymaga dodatniego `e` i ujemnego `k`, co może się zdarzyć tylko dla wartości bardzo bliskich 1, co oznacza, że `e` i `k` będą stosunkowo małe.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k To też nie może się przepełnić, patrz wyżej.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), ponownie zmniejszając o wspólną potęgę dwóch.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Koncepcyjnie algorytm M to najprostszy sposób zamiany liczby dziesiętnej na liczbę zmiennoprzecinkową.
///
/// Tworzymy stosunek, który jest równy `f * 10^e`, a następnie wrzucamy potęgę dwóch, aż da prawidłową wartość zmiennoprzecinkową.
/// Binarny wykładnik `k` to liczba razy, kiedy pomnożyliśmy licznik lub mianownik przez dwa, tj. Zawsze `f *10^e` równa się `(u / v)* 2^k`.
/// Kiedy ustalimy znaczenie, musimy tylko zaokrąglić, sprawdzając pozostałą część podziału, co jest wykonywane w funkcjach pomocniczych poniżej.
///
///
/// Ten algorytm działa bardzo wolno, nawet przy optymalizacji opisanej w `quick_start()`.
/// Jednak jest to najprostszy z algorytmów do dostosowania do przepełnienia, niedomiaru i wyników poniżej normy.
/// Ta implementacja przejmuje kontrolę, gdy Bellerophon i Algorithm R są przeciążone.
/// Wykrywanie niedomiaru i przepełnienia jest łatwe: współczynnik nadal nie jest istotnym zakresem, ale został osiągnięty wykładnik minimum/maximum.
/// W przypadku przepełnienia zwracamy po prostu nieskończoność.
///
/// Obsługa niedomiarów i wartości podrzędnych jest trudniejsza.
/// Jeden duży problem polega na tym, że przy minimalnym wykładniku stosunek może być nadal zbyt duży dla istotności.
/// Aby uzyskać szczegółowe informacje, patrz underflow().
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME możliwa optymalizacja: uogólnij big_to_fp tak, abyśmy mogli zrobić tutaj odpowiednik fp_to_float(big_to_fp(u)), tylko bez podwójnego zaokrąglania.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Musimy zatrzymać się na minimalnym wykładniku, jeśli poczekamy do `k < T::MIN_EXP_INT`, to wypadniemy dwukrotnie.
            // Niestety oznacza to, że musimy specjalizować się w liczbach normalnych z minimalnym wykładnikiem.
            // FIXME znajdź bardziej elegancką formułę, ale uruchom test `tiny-pow10`, aby upewnić się, że jest rzeczywiście poprawny!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Pomija większość M iteracji algorytmów, sprawdzając długość bitów.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Długość bitu jest oszacowaniem logarytmu o podstawie dwa, a log(u / v) = log(u), log(v).
    // Oszacowanie różni się co najwyżej o 1, ale zawsze jest niedoszacowane, więc błąd na log(u) i log(v) ma ten sam znak i anuluje się (jeśli oba są duże).
    // Dlatego błąd dla log(u / v) wynosi co najwyżej jeden.
    // Współczynnik docelowy to taki, w którym u/v znajduje się w zakresie istotności.Zatem naszym warunkiem zakończenia jest log2(u / v) będący bitami istotnymi, a jeden plus/minus.
    // FIXME Analiza drugiego fragmentu może poprawić oszacowanie i uniknąć dalszych podziałów.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Niedomiar lub poniżej normy.Zostaw to dla głównej funkcji.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Przelewowy.Zostaw to dla głównej funkcji.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Stosunek nie jest wartością istotną w zakresie z minimalnym wykładnikiem, więc musimy zaokrąglić nadmiarowe bity i odpowiednio dostosować wykładnik.
    // Rzeczywista wartość wygląda teraz następująco:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q obetnij.(reprezentowany przez rem)
    //
    // Dlatego też, gdy zaokrąglone bity mają wartość!= 0.5 ULP, same decydują o zaokrągleniu.
    // Gdy są równe, a reszta jest różna od zera, wartość nadal wymaga zaokrąglenia w górę.
    // Dopiero gdy zaokrąglone bity mają wartość 1/2, a reszta wynosi zero, mamy sytuację w połowie do parzystości.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Zwykłe okrągłe do równych, zaciemnione przez konieczność zaokrąglania w oparciu o pozostałą część dywizji.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}