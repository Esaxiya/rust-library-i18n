//! Sprawdzanie poprawności i dekomponowanie ciągu dziesiętnego w postaci:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Innymi słowy, standardowa składnia zmiennoprzecinkowa, z dwoma wyjątkami: brak znaku i brak obsługi "inf" i "NaN".Obsługiwane są one przez funkcję sterownika (super::dec2flt).
//!
//! Chociaż rozpoznawanie prawidłowych danych wejściowych jest stosunkowo łatwe, ten moduł musi również odrzucić niezliczone nieprawidłowe zmiany, nigdy panic, i wykonać liczne sprawdzenia, na których inne moduły polegają, aby nie panic (lub przepełnienie) po kolei.
//!
//! Co gorsza, wszystko to dzieje się w jednym przejściu przez wejście.
//! Dlatego zachowaj ostrożność podczas modyfikowania czegokolwiek i sprawdź ponownie z innymi modułami.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Ciekawe części ciągu dziesiętnego.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Wykładnik dziesiętny, który ma mniej niż 18 cyfr dziesiętnych.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Sprawdza, czy ciąg wejściowy jest prawidłową liczbą zmiennoprzecinkową, a jeśli tak, zlokalizuj w nim część całkowitą, część ułamkową i wykładnik.
/// Nie obsługuje znaków.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Brak cyfr przed 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Wymagamy co najmniej jednej cyfry przed lub po kropce.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Końcowe śmieci po części ułamkowej
            }
        }
        _ => Invalid, // Końcowe śmieci po pierwszym ciągu cyfrowym
    }
}

/// Odcina cyfry dziesiętne do pierwszego znaku niebędącego cyfrą.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Ekstrakcja wykładników i sprawdzanie błędów.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Końcowe śmieci po wykładniku
    }
    if number.is_empty() {
        return Invalid; // Pusty wykładnik
    }
    // W tym momencie z pewnością mamy prawidłowy ciąg cyfr.Może to być zbyt długie, aby umieścić je w `i64`, ale jeśli jest tak duże, wejście z pewnością wynosi zero lub nieskończoność.
    // Ponieważ każde zero w cyfrach dziesiętnych dostosowuje wykładnik tylko o +/-1, przy exp=10 ^ 18 wartość wejściowa musiałaby mieć 17 eksabajtów (!) zer, aby być nawet bliżej bycia skończonym.
    //
    // Nie jest to dokładnie przypadek użycia, którym musimy się zająć.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}