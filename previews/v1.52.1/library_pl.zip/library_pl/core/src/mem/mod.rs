//! Podstawowe funkcje postępowania z pamięcią.
//!
//! Ten moduł zawiera funkcje do sprawdzania rozmiaru i wyrównania typów, inicjowania i manipulowania pamięcią.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Przejmuje własność i "forgets" o wartości **bez uruchamiania jego destruktora**.
///
/// Wszelkie zasoby, którymi zarządza wartość, takie jak pamięć sterty lub uchwyt pliku, pozostaną na zawsze w stanie nieosiągalnym.Jednak nie gwarantuje, że wskaźniki do tej pamięci pozostaną aktualne.
///
/// * Jeśli chcesz wyciekać pamięć, zobacz [`Box::leak`].
/// * Jeśli chcesz uzyskać surowy wskaźnik do pamięci, zobacz [`Box::into_raw`].
/// * Jeśli chcesz odpowiednio pozbyć się wartości, uruchamiając jej destruktor, zobacz [`mem::drop`].
///
/// # Safety
///
/// `forget` nie jest oznaczony jako `unsafe`, ponieważ gwarancje bezpieczeństwa Rust nie obejmują gwarancji, że destruktory będą zawsze działać.
/// Na przykład program może utworzyć cykl odniesienia za pomocą [`Rc`][rc] lub wywołać [`process::exit`][exit], aby zakończyć bez uruchamiania destruktorów.
/// Zatem zezwolenie `mem::forget` na bezpieczny kod nie zmienia zasadniczo gwarancji bezpieczeństwa Rust.
///
/// To powiedziawszy, wyciek zasobów, takich jak pamięć lub obiekty I/O, jest zwykle niepożądany.
/// Potrzeba pojawia się w niektórych wyspecjalizowanych przypadkach użycia FFI lub niebezpiecznego kodu, ale nawet wtedy [`ManuallyDrop`] jest zwykle preferowany.
///
/// Ponieważ zapomnienie wartości jest dozwolone, każdy napisany kod `unsafe` musi umożliwiać taką możliwość.Nie można zwrócić wartości i oczekiwać, że obiekt wywołujący koniecznie uruchomi destruktor wartości.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Kanoniczne bezpieczne użycie `mem::forget` polega na obejściu destruktora wartości zaimplementowanego przez `Drop` trait.Na przykład spowoduje to wyciek `File`, tj
/// odzyskaj miejsce zajmowane przez zmienną, ale nigdy nie zamykaj podstawowego zasobu systemowego:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Jest to przydatne, gdy własność podstawowego zasobu została wcześniej przeniesiona do kodu poza Rust, na przykład przez przesłanie surowego deskryptora pliku do kodu C.
///
/// # Relacja z `ManuallyDrop`
///
/// Chociaż `mem::forget` może być również używany do przenoszenia *własności* pamięci *, jest to podatne na błędy.
/// [`ManuallyDrop`] należy użyć zamiast tego.Rozważmy na przykład ten kod:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Zbuduj `String`, używając zawartości `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // wyciek `v`, ponieważ jego pamięć jest teraz zarządzana przez `s`
/// mem::forget(v);  // BŁĄD, v jest niepoprawne i nie może zostać przekazane do funkcji
/// assert_eq!(s, "Az");
/// // `s` jest niejawnie usuwany, a jego pamięć zwalniana.
/// ```
///
/// Z powyższym przykładem wiążą się dwa problemy:
///
/// * Gdyby dodać więcej kodu między konstrukcją `String` a wywołaniem `mem::forget()`, znajdujący się w nim panic spowodowałby podwójne zwolnienie, ponieważ ta sama pamięć jest obsługiwana przez `v` i `s`.
/// * Po wywołaniu `v.as_mut_ptr()` i przesłaniu własności danych do `s` wartość `v` jest nieprawidłowa.
/// Nawet jeśli wartość zostanie właśnie przeniesiona do `mem::forget` (co nie będzie jej sprawdzać), niektóre typy mają ścisłe wymagania dotyczące swoich wartości, które powodują, że są one nieważne, gdy wiszą lub nie są już posiadane.
/// Używanie w jakikolwiek sposób nieprawidłowych wartości, w tym przekazywanie ich do funkcji lub zwracanie ich z funkcji, stanowi niezdefiniowane zachowanie i może złamać założenia przyjęte przez kompilator.
///
/// Przejście na `ManuallyDrop` pozwala uniknąć obu problemów:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Zanim zdemontujemy `v` na jego surowe części, upewnij się, że nie zostanie upuszczony!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Teraz zdemontuj `v`.Te operacje nie mogą panic, więc nie może być przecieku.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Na koniec zbuduj `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` jest niejawnie usuwany, a jego pamięć zwalniana.
/// ```
///
/// `ManuallyDrop` solidnie zapobiega podwójnemu zwalnianiu, ponieważ wyłączamy destruktor `v`, zanim zrobimy cokolwiek innego.
/// `mem::forget()` nie pozwala na to, ponieważ zużywa swój argument, zmuszając nas do wywoływania go dopiero po wyodrębnieniu wszystkiego, czego potrzebujemy z `v`.
/// Nawet jeśli panic zostałby wprowadzony między budowaniem `ManuallyDrop` a budowaniem łańcucha (co nie może się zdarzyć w kodzie, jak pokazano), spowodowałoby to wyciek, a nie podwójne zwolnienie.
/// Innymi słowy, `ManuallyDrop` popełnia błędy po stronie wycieku zamiast po stronie (podwójnego) upuszczenia.
///
/// Ponadto `ManuallyDrop` uniemożliwia nam przejście na "touch" `v` po przeniesieniu własności na `s`-ostatni krok interakcji z `v` w celu pozbycia się go bez uruchamiania jego destruktora jest całkowicie wyeliminowany.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Podobnie jak [`forget`], ale akceptuje również wartości bez rozmiaru.
///
/// Ta funkcja to tylko podkładka, którą należy usunąć, gdy funkcja `unsized_locals` zostanie ustabilizowana.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Zwraca rozmiar typu w bajtach.
///
/// Mówiąc dokładniej, jest to przesunięcie w bajtach między kolejnymi elementami w tablicy z tym typem elementu, w tym dopełnienie wyrównaniem.
///
/// Zatem dla każdego typu `T` i długości `n` `[T; n]` ma rozmiar `n * size_of::<T>()`.
///
/// Ogólnie rzecz biorąc, rozmiar typu nie jest stabilny we wszystkich kompilacjach, ale określone typy, takie jak prymitywy, są.
///
/// W poniższej tabeli podano rozmiary prymitywów.
///
/// Wpisz |rozmiar: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 znaków |4
///
/// Ponadto `usize` i `isize` mają ten sam rozmiar.
///
/// Wszystkie typy `*const T`, `&T`, `Box<T>`, `Option<&T>` i `Option<Box<T>>` mają ten sam rozmiar.
/// Jeśli `T` ma rozmiar, wszystkie te typy mają ten sam rozmiar co `usize`.
///
/// Zmienność wskaźnika nie zmienia jego rozmiaru.W związku z tym `&T` i `&mut T` mają ten sam rozmiar.
/// Podobnie dla `*const T` i `* mut T`.
///
/// # Rozmiar elementów `#[repr(C)]`
///
/// Reprezentacja `C` dla elementów ma zdefiniowany układ.
/// W tym układzie rozmiar elementów jest również stabilny, o ile wszystkie pola mają stabilny rozmiar.
///
/// ## Rozmiar struktur
///
/// W przypadku `structs` rozmiar jest określany przez następujący algorytm.
///
/// Dla każdego pola w strukturze uporządkowanej według kolejności deklaracji:
///
/// 1. Dodaj rozmiar pola.
/// 2. Zaokrąglij bieżący rozmiar do najbliższej wielokrotności wartości [alignment] następnego pola.
///
/// Na koniec zaokrąglij rozmiar struktury do najbliższej wielokrotności jej [alignment].
/// Wyrównanie struktury jest zwykle największym wyrównaniem ze wszystkich jej pól;można to zmienić za pomocą `repr(align(N))`.
///
/// W przeciwieństwie do `C`, struktury o rozmiarze zerowym nie są zaokrąglane w górę do jednego bajtu.
///
/// ## Rozmiar wyliczeń
///
/// Wyliczenia, które nie zawierają danych innych niż dyskryminator, mają ten sam rozmiar co wyliczenia C na platformie, dla której są kompilowane.
///
/// ## Wielkość związków
///
/// Rozmiar związku to wielkość jego największego pola.
///
/// W przeciwieństwie do `C`, związki o zerowej wielkości nie są zaokrąglane w górę do jednego bajtu.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Niektóre prymitywy
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Niektóre tablice
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Równość rozmiaru wskaźnika
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Korzystanie z `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Rozmiar pierwszego pola to 1, więc dodaj 1 do rozmiaru.Rozmiar to 1.
/// // Wyrównanie drugiego pola wynosi 2, więc dodaj 1 do rozmiaru wypełnienia.Rozmiar to 2.
/// // Rozmiar drugiego pola to 2, więc dodaj 2 do rozmiaru.Rozmiar to 4.
/// // Wyrównanie trzeciego pola wynosi 1, więc dodaj 0 do rozmiaru wypełnienia.Rozmiar to 4.
/// // Rozmiar trzeciego pola to 1, więc dodaj 1 do rozmiaru.Rozmiar to 5.
/// // Na koniec wyrównanie struktury wynosi 2 (ponieważ największe wyrównanie wśród jej pól to 2), więc dodaj 1 do rozmiaru wypełnienia.
/// // Rozmiar to 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Struktury krotki podlegają tym samym regułom.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Pamiętaj, że zmiana kolejności pól może zmniejszyć rozmiar.
/// // Możemy usunąć oba bajty wypełniające, umieszczając `third` przed `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Wielkość związku to wielkość największego pola.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Zwraca rozmiar wskazanej wartości w bajtach.
///
/// Zwykle jest to to samo, co `size_of::<T>()`.
/// Jeśli jednak `T`*nie ma* znanego statycznie rozmiaru, np. Wycinka [`[T]`][slice] lub [trait object], wówczas `size_of_val` może zostać użyty do uzyskania dynamicznie znanego rozmiaru.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // BEZPIECZEŃSTWO: `val` jest odniesieniem, więc jest prawidłowym surowym wskaźnikiem
    unsafe { intrinsics::size_of_val(val) }
}

/// Zwraca rozmiar wskazanej wartości w bajtach.
///
/// Zwykle jest to to samo, co `size_of::<T>()`.Jeśli jednak `T`*nie ma* znanego statycznie rozmiaru, np. Wycinka [`[T]`][slice] lub [trait object], wówczas `size_of_val_raw` może zostać użyty do uzyskania dynamicznie znanego rozmiaru.
///
/// # Safety
///
/// Ta funkcja jest bezpieczna tylko wtedy, gdy są spełnione następujące warunki:
///
/// - Jeśli `T` to `Sized`, wywołanie tej funkcji jest zawsze bezpieczne.
/// - Jeśli niewymiarowy ogon `T` to:
///     - a [slice], wówczas długość końca wycinka musi być zainicjowaną liczbą całkowitą, a rozmiar *całej wartości*(dynamiczna długość ogona + statyczny prefiks) musi mieścić się w `isize`.
///     - a [trait object], to część vtable wskaźnika musi wskazywać na prawidłową tabelę vtable uzyskaną przez wymuszenie zmiany rozmiaru, a rozmiar *całej wartości*(dynamiczna długość ogona + statyczny prefiks) musi mieścić się w `isize`.
///
///     - (unstable) [extern type], to ta funkcja jest zawsze bezpieczna do wywołania, ale może panic lub w inny sposób zwrócić nieprawidłową wartość, ponieważ układ typu zewnętrznego nie jest znany.
///     Jest to takie samo zachowanie, jak [`size_of_val`] w odniesieniu do typu z zewnętrzną końcówką typu.
///     - w przeciwnym razie nie wolno wywoływać tej funkcji.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // BEZPIECZEŃSTWO: wywołujący musi dostarczyć poprawny surowy wskaźnik
    unsafe { intrinsics::size_of_val(val) }
}

/// Zwraca minimalne wyrównanie typu wymagane przez [ABI].
///
/// Każde odwołanie do wartości typu `T` musi być wielokrotnością tej liczby.
///
/// To jest wyrównanie używane dla pól strukturalnych.Może być mniejsze niż preferowane wyrównanie.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Zwraca wymagane [ABI] minimalne wyrównanie typu wartości, na którą wskazuje `val`.
///
/// Każde odwołanie do wartości typu `T` musi być wielokrotnością tej liczby.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // BEZPIECZEŃSTWO: val jest referencją, więc jest prawidłowym wskaźnikiem surowym
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Zwraca minimalne wyrównanie typu wymagane przez [ABI].
///
/// Każde odwołanie do wartości typu `T` musi być wielokrotnością tej liczby.
///
/// To jest wyrównanie używane dla pól strukturalnych.Może być mniejsze niż preferowane wyrównanie.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Zwraca wymagane [ABI] minimalne wyrównanie typu wartości, na którą wskazuje `val`.
///
/// Każde odwołanie do wartości typu `T` musi być wielokrotnością tej liczby.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // BEZPIECZEŃSTWO: val jest referencją, więc jest prawidłowym wskaźnikiem surowym
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Zwraca wymagane [ABI] minimalne wyrównanie typu wartości, na którą wskazuje `val`.
///
/// Każde odwołanie do wartości typu `T` musi być wielokrotnością tej liczby.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ta funkcja jest bezpieczna tylko wtedy, gdy są spełnione następujące warunki:
///
/// - Jeśli `T` to `Sized`, wywołanie tej funkcji jest zawsze bezpieczne.
/// - Jeśli niewymiarowy ogon `T` to:
///     - a [slice], wówczas długość końca wycinka musi być zainicjowaną liczbą całkowitą, a rozmiar *całej wartości*(dynamiczna długość ogona + statyczny prefiks) musi mieścić się w `isize`.
///     - a [trait object], to część vtable wskaźnika musi wskazywać na prawidłową tabelę vtable uzyskaną przez wymuszenie zmiany rozmiaru, a rozmiar *całej wartości*(dynamiczna długość ogona + statyczny prefiks) musi mieścić się w `isize`.
///
///     - (unstable) [extern type], to ta funkcja jest zawsze bezpieczna do wywołania, ale może panic lub w inny sposób zwrócić nieprawidłową wartość, ponieważ układ typu zewnętrznego nie jest znany.
///     Jest to takie samo zachowanie, jak [`align_of_val`] w odniesieniu do typu z zewnętrzną końcówką typu.
///     - w przeciwnym razie nie wolno wywoływać tej funkcji.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // BEZPIECZEŃSTWO: wywołujący musi dostarczyć poprawny surowy wskaźnik
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Zwraca `true`, jeśli porzucenie wartości typu `T` ma znaczenie.
///
/// To jest czysto wskazówka dotycząca optymalizacji i można ją zaimplementować konserwatywnie:
/// może zwrócić `true` dla typów, których w rzeczywistości nie trzeba usuwać.
/// W związku z tym zawsze zwracanie `true` byłoby prawidłową implementacją tej funkcji.Jeśli jednak ta funkcja faktycznie zwraca `false`, możesz być pewien, że upuszczenie `T` nie ma żadnego efektu ubocznego.
///
/// Niskopoziomowe implementacje rzeczy, takich jak kolekcje, które muszą ręcznie upuszczać swoje dane, powinny używać tej funkcji, aby uniknąć niepotrzebnych prób upuszczenia całej ich zawartości, gdy zostaną zniszczone.
///
/// Może to nie mieć wpływu na kompilacje wydań (gdzie pętla, która nie ma skutków ubocznych, jest łatwo wykrywana i eliminowana), ale często jest dużą wygraną w przypadku kompilacji debugowania.
///
/// Zauważ, że [`drop_in_place`] już wykonuje to sprawdzenie, więc jeśli obciążenie można zmniejszyć do niewielkiej liczby wywołań [`drop_in_place`], używanie tego jest niepotrzebne.
/// W szczególności zwróć uwagę, że możesz [`drop_in_place`] wycinka, a to wykona pojedynczy test need_drop dla wszystkich wartości.
///
/// Dlatego typy takie jak Vec to tylko `drop_in_place(&mut self[..])` bez jawnego używania `needs_drop`.
/// Z drugiej strony typy takie jak [`HashMap`] muszą porzucać wartości pojedynczo i powinny używać tego interfejsu API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Oto przykład tego, jak kolekcja może korzystać z `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // upuść dane
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Zwraca wartość typu `T` reprezentowaną przez zerowy wzorzec bajtowy.
///
/// Oznacza to, że na przykład bajt wypełniający w `(u8, u16)` niekoniecznie jest zerowany.
///
/// Nie ma gwarancji, że zerowy wzorzec bajtowy reprezentuje prawidłową wartość pewnego typu `T`.
/// Na przykład zerowy wzorzec bajtów nie jest prawidłową wartością dla typów odwołań (" &T`, `&mut T`) i wskaźników do funkcji.
/// Użycie `zeroed` na takich typach powoduje natychmiastowe [undefined behavior][ub], ponieważ [the Rust compiler assumes][inv], że zawsze istnieje poprawna wartość w zmiennej, którą uważa za zainicjowaną.
///
///
/// Ma to taki sam efekt jak [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Czasami jest to przydatne dla FFI, ale generalnie należy go unikać.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Prawidłowe użycie tej funkcji: inicjalizacja liczby całkowitej od zera.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Nieprawidłowe* użycie tej funkcji: inicjalizacja odniesienia z zerem.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Nieokreślone zachowanie!
/// let _y: fn() = unsafe { mem::zeroed() }; // I znowu!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że wartość zerowa jest ważna dla `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Pomija normalne sprawdzanie inicjalizacji pamięci przez Rust, udając, że generuje wartość typu `T`, nie robiąc nic.
///
/// **Ta funkcja jest przestarzała.** Zamiast tego użyj [`MaybeUninit<T>`].
///
/// Powodem wycofania jest to, że funkcja w zasadzie nie może być używana poprawnie: ma taki sam efekt jak [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Jak wyjaśnia [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] te wartości są poprawnie zainicjalizowane.
/// W konsekwencji dzwoniąc np
/// `mem::uninitialized::<bool>()` powoduje natychmiastowe niezdefiniowane zachowanie w przypadku zwracania `bool`, który nie jest definitywnie `true` lub `false`.
/// Co gorsza, prawdziwie niezainicjowana pamięć, taka jak ta, która jest tutaj zwracana, jest wyjątkowa, ponieważ kompilator wie, że nie ma ona ustalonej wartości.
/// To sprawia, że niezdefiniowane zachowanie ma niezainicjowane dane w zmiennej, nawet jeśli ta zmienna ma typ całkowity.
/// (Zwróć uwagę, że reguły dotyczące niezainicjowanych liczb całkowitych nie są jeszcze sfinalizowane, ale zanim się pojawią, zaleca się ich unikanie).
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że zjednostkowana wartość jest ważna dla `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Zamienia wartości w dwóch zmiennych lokalizacjach, bez deinicjalizacji żadnej z nich.
///
/// * Jeśli chcesz zamienić na wartość domyślną lub fikcyjną, zobacz [`take`].
/// * Jeśli chcesz zamienić z przekazaną wartością, zwracając starą wartość, zobacz [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // BEZPIECZEŃSTWO: surowe wskaźniki zostały utworzone z bezpiecznych mutowalnych odniesień spełniających wszystkie
    // ograniczenia na `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Zastępuje `dest` domyślną wartością `T`, zwracając poprzednią wartość `dest`.
///
/// * Jeśli chcesz zamienić wartości dwóch zmiennych, zobacz [`swap`].
/// * Jeśli chcesz zastąpić przekazaną wartością zamiast wartości domyślnej, zobacz [`replace`].
///
/// # Examples
///
/// Prosty przykład:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` umożliwia przejęcie na własność pola struct poprzez zastąpienie go wartością "empty".
/// Bez `take` możesz napotkać takie problemy:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Zauważ, że `T` niekoniecznie implementuje [`Clone`], więc nie może nawet klonować i resetować `self.buf`.
/// Ale `take` można użyć do oddzielenia pierwotnej wartości `self.buf` od `self`, umożliwiając jej zwrócenie:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Przenosi `src` do przywoływanego `dest`, zwracając poprzednią wartość `dest`.
///
/// Żadna wartość nie jest pomijana.
///
/// * Jeśli chcesz zamienić wartości dwóch zmiennych, zobacz [`swap`].
/// * Jeśli chcesz zamienić na wartość domyślną, zobacz [`take`].
///
/// # Examples
///
/// Prosty przykład:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` umożliwia użycie pola struct poprzez zastąpienie go inną wartością.
/// Bez `replace` możesz napotkać takie problemy:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Zauważ, że `T` niekoniecznie implementuje [`Clone`], więc nie możemy nawet sklonować `self.buf[i]`, aby uniknąć tego ruchu.
/// Ale `replace` można użyć do oddzielenia pierwotnej wartości w tym indeksie od `self`, umożliwiając jej zwrócenie:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // BEZPIECZEŃSTWO: Czytamy z `dest`, ale później bezpośrednio zapisujemy w nim `src`,
    // tak, że stara wartość nie zostanie zduplikowana.
    // Nic nie jest upuszczone i nic tutaj nie może panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Usuwa wartość.
///
/// Odbywa się to przez wywołanie implementacji argumentu [`Drop`][drop].
///
/// To skutecznie nie robi nic dla typów, które implementują `Copy`, np
/// integers.
/// Takie wartości są kopiowane i _then_ przenoszone do funkcji, więc wartość pozostaje po wywołaniu funkcji.
///
///
/// Ta funkcja nie jest magiczna;jest dosłownie zdefiniowany jako
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Ponieważ `_x` jest przenoszony do funkcji, jest automatycznie usuwany przed powrotem funkcji.
///
/// [drop]: Drop
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // jawnie upuść vector
/// ```
///
/// Ponieważ [`RefCell`] wymusza reguły wypożyczania w czasie wykonywania, `drop` może zwolnić pożyczkę [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // porzuć zmienną pożyczkę na tym slocie
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// `drop` nie ma wpływu na liczby całkowite i inne typy implementujące [`Copy`].
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // kopia `x` jest przenoszona i upuszczana
/// drop(y); // kopia `y` jest przenoszona i upuszczana
///
/// println!("x: {}, y: {}", x, y.0); // wciąż dostępne
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpretuje `src` jako typ `&U`, a następnie odczytuje `src` bez przenoszenia zawartej wartości.
///
/// Ta funkcja w niebezpieczny sposób zakłada, że wskaźnik `src` jest poprawny dla bajtów [`size_of::<U>`][size_of], transmitując `&T` do `&U`, a następnie odczytując `&U` (z wyjątkiem tego, że odbywa się to w sposób, który jest poprawny, nawet jeśli `&U` stawia bardziej rygorystyczne wymagania wyrównania niż `&T`).
/// Spowoduje również utworzenie kopii zawartej wartości zamiast przenoszenia się z `src`.
///
/// Nie jest to błąd czasu kompilacji, jeśli `T` i `U` mają różne rozmiary, ale zdecydowanie zaleca się wywoływanie tej funkcji tylko wtedy, gdy `T` i `U` mają ten sam rozmiar.Ta funkcja wyzwala [undefined behavior][ub], jeśli `U` jest większy niż `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Skopiuj dane z 'foo_array' i potraktuj je jako 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Zmodyfikuj skopiowane dane
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Zawartość 'foo_array' nie powinna się zmienić
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Jeśli U ma wyższe wymagania dotyczące wyrównania, src może nie być odpowiednio wyrównane.
    if align_of::<U>() > align_of::<T>() {
        // BEZPIECZEŃSTWO: `src` to odniesienie, które gwarantuje ważność przy odczytach.
        // Dzwoniący musi zagwarantować, że rzeczywista transmutacja jest bezpieczna.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // BEZPIECZEŃSTWO: `src` to odniesienie, które gwarantuje ważność przy odczytach.
        // Właśnie sprawdziliśmy, czy `src as *const U` jest prawidłowo wyrównany.
        // Dzwoniący musi zagwarantować, że rzeczywista transmutacja jest bezpieczna.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Nieprzezroczysty typ reprezentujący dyskryminację wyliczenia.
///
/// Aby uzyskać więcej informacji, zobacz funkcję [`discriminant`] w tym module.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Tych implementacji trait nie można wyprowadzić, ponieważ nie chcemy żadnych ograniczeń w T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Zwraca wartość jednoznacznie identyfikującą wariant wyliczenia w `v`.
///
/// Jeśli `T` nie jest wyliczeniem, wywołanie tej funkcji nie spowoduje niezdefiniowanego zachowania, ale wartość zwracana jest nieokreślona.
///
///
/// # Stability
///
/// Dyskryminator wariantu wyliczenia może ulec zmianie, jeśli zmieni się definicja wyliczenia.
/// Wyróżnik jakiegoś wariantu nie zmieni się między kompilacjami z tym samym kompilatorem.
///
/// # Examples
///
/// Można tego użyć do porównania wyliczeń, które zawierają dane, z pominięciem rzeczywistych danych:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Zwraca liczbę wariantów w typie wyliczenia `T`.
///
/// Jeśli `T` nie jest wyliczeniem, wywołanie tej funkcji nie spowoduje niezdefiniowanego zachowania, ale wartość zwracana jest nieokreślona.
/// Podobnie, jeśli `T` jest wyliczeniem z większą liczbą wariantów niż `usize::MAX`, wartość zwracana jest nieokreślona.
/// Liczone będą niezamieszkane warianty.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}