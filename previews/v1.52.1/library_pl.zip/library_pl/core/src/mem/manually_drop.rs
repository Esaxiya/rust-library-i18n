use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Opakowanie uniemożliwiające kompilatorowi automatyczne wywoływanie destruktora `T`.
/// To opakowanie nie kosztuje.
///
/// `ManuallyDrop<T>` podlega takim samym optymalizacjom układu jak `T`.
/// W konsekwencji *nie ma to wpływu* na założenia, które kompilator dokonuje odnośnie jego zawartości.
/// Na przykład inicjalizacja `ManuallyDrop<&mut T>` za pomocą [`mem::zeroed`] jest niezdefiniowanym zachowaniem.
/// Jeśli potrzebujesz obsługiwać niezainicjowane dane, użyj zamiast tego [`MaybeUninit<T>`].
///
/// Zauważ, że dostęp do wartości wewnątrz `ManuallyDrop<T>` jest bezpieczny.
/// Oznacza to, że `ManuallyDrop<T>`, którego zawartość została upuszczona, nie może zostać ujawniona za pośrednictwem publicznego bezpiecznego interfejsu API.
/// W związku z tym `ManuallyDrop::drop` jest niebezpieczny.
///
/// # `ManuallyDrop` i upuść zamówienie.
///
/// Rust ma dobrze zdefiniowane [drop order] wartości.
/// Aby upewnić się, że pola lub ustawienia lokalne są usuwane w określonej kolejności, zmień kolejność deklaracji tak, aby niejawna kolejność usuwania była poprawna.
///
/// Możliwe jest użycie `ManuallyDrop` do kontrolowania kolejności upuszczania, ale wymaga to niebezpiecznego kodu i jest trudne do wykonania poprawnie w przypadku odwijania.
///
///
/// Na przykład, jeśli chcesz mieć pewność, że określone pole zostanie usunięte po innych, ustaw je jako ostatnie pole struktury:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` zostanie usunięty po `children`.
///     // Rust gwarantuje, że pola są usuwane w kolejności deklaracji.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Zawiń wartość, która ma zostać ręcznie usunięta.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Nadal możesz bezpiecznie operować na wartości
    /// assert_eq!(*x, "Hello");
    /// // Ale `Drop` nie zostanie tutaj uruchomiony
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Wyodrębnia wartość z kontenera `ManuallyDrop`.
    ///
    /// Pozwala to na ponowne usunięcie wartości.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // To upuszcza `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Pobiera wartość z kontenera `ManuallyDrop<T>`.
    ///
    /// Ta metoda jest przeznaczona głównie do przenoszenia wartości w spadku.
    /// Zamiast używać [`ManuallyDrop::drop`] do ręcznego usuwania wartości, możesz użyć tej metody, aby pobrać wartość i użyć jej w dowolny sposób.
    ///
    /// O ile to możliwe, lepiej jest zamiast tego używać [`into_inner`][`ManuallyDrop::into_inner`], co zapobiega powielaniu zawartości `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Ta funkcja semantycznie przenosi zawartą wartość bez zapobiegania dalszemu użyciu, pozostawiając niezmieniony stan tego kontenera.
    /// Twoim obowiązkiem jest upewnienie się, że `ManuallyDrop` nie zostanie ponownie użyty.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // BEZPIECZEŃSTWO: czytamy z referencji, co jest gwarantowane
        // do odczytu.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Ręcznie obniża zawartą wartość.Jest to dokładnie równoważne wywołaniu [`ptr::drop_in_place`] ze wskaźnikiem do zawartej wartości.
    /// W związku z tym, o ile zawarta wartość nie jest strukturą spakowaną, destruktor zostanie wywołany w miejscu bez przenoszenia wartości, a zatem może zostać użyty do bezpiecznego usunięcia danych [pinned].
    ///
    /// Jeśli posiadasz własność wartości, możesz zamiast tego użyć [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Ta funkcja uruchamia destruktor zawartej wartości.
    /// Poza zmianami dokonanymi przez sam destruktor, pamięć pozostaje niezmieniona, a jeśli chodzi o kompilator, nadal przechowuje wzorzec bitów, który jest ważny dla typu `T`.
    ///
    ///
    /// Jednak ta wartość "zombie" nie powinna być narażona na bezpieczny kod, a ta funkcja nie powinna być wywoływana więcej niż jeden raz.
    /// Użycie wartości po jej upuszczeniu lub wielokrotne upuszczenie wartości może spowodować niezdefiniowane zachowanie (w zależności od tego, co robi `drop`).
    /// Zwykle zapobiega temu system typów, ale użytkownicy `ManuallyDrop` muszą zachować te gwarancje bez pomocy kompilatora.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // BEZPIECZEŃSTWO: pomijamy wartość wskazywaną przez zmienne odniesienie
        // który jest gwarantowany jako ważny dla zapisów.
        // To dzwoniący musi upewnić się, że `slot` nie zostanie ponownie usunięty.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}