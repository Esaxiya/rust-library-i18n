use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Typ opakowania służący do konstruowania niezainicjowanych wystąpień `T`.
///
/// # Niezmiennik inicjalizacji
///
/// Generalnie kompilator zakłada, że zmienna jest poprawnie zainicjowana zgodnie z wymaganiami typu zmiennej.Na przykład zmienna typu referencyjnego musi być wyrównana i nie może mieć wartości NULL.
/// Jest to niezmiennik, który *zawsze* musi być przestrzegany, nawet w niebezpiecznym kodzie.
/// W konsekwencji zerowanie zmiennej typu referencyjnego powoduje natychmiastowe [undefined behavior][ub], bez względu na to, czy odwołanie to kiedykolwiek zostanie użyte do uzyskania dostępu do pamięci:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // niezdefiniowane zachowanie!⚠️
/// // Odpowiedni kod z `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // niezdefiniowane zachowanie!⚠️
/// ```
///
/// Jest to wykorzystywane przez kompilator do różnych optymalizacji, takich jak eliminowanie kontroli w czasie wykonywania i optymalizacja układu `enum`.
///
/// Podobnie, całkowicie niezainicjowana pamięć może mieć dowolną zawartość, podczas gdy `bool` musi zawsze być `true` lub `false`.Dlatego tworzenie niezainicjowanego `bool` jest niezdefiniowanym zachowaniem:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // niezdefiniowane zachowanie!⚠️
/// // Odpowiedni kod z `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // niezdefiniowane zachowanie!⚠️
/// ```
///
/// Ponadto niezainicjowana pamięć jest wyjątkowa, ponieważ nie ma stałej wartości ("fixed" oznacza "it won't change without being written to").Wielokrotne czytanie tego samego niezainicjowanego bajtu może dać różne wyniki.
/// To sprawia, że niezdefiniowane zachowanie ma niezainicjowane dane w zmiennej, nawet jeśli ta zmienna ma typ całkowity, który w przeciwnym razie może przechowywać dowolny *stały* wzorzec bitowy:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // niezdefiniowane zachowanie!⚠️
/// // Odpowiedni kod z `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // niezdefiniowane zachowanie!⚠️
/// ```
/// (Zwróć uwagę, że reguły dotyczące niezainicjowanych liczb całkowitych nie są jeszcze sfinalizowane, ale zanim się pojawią, zaleca się ich unikanie).
///
/// Ponadto pamiętaj, że większość typów ma dodatkowe niezmienniki, poza zwykłym uznaniem ich za zainicjowane na poziomie typu.
/// Na przykład [`Vec<T>`] zainicjowany " 1` jest uważany za zainicjowany (w ramach bieżącej implementacji; nie stanowi to stabilnej gwarancji), ponieważ jedynym wymaganiem, o którym wie kompilator, jest to, że wskaźnik danych nie może mieć wartości NULL.
/// Utworzenie takiego `Vec<T>` nie powoduje *natychmiastowego* niezdefiniowanego zachowania, ale spowoduje niezdefiniowane zachowanie przy większości bezpiecznych operacji (w tym porzucenie go).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` służy do umożliwienia niebezpiecznemu kodowi radzenia sobie z niezainicjowanymi danymi.
/// Jest to sygnał dla kompilatora wskazujący, że dane tutaj mogą *nie* zostać zainicjowane:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Utwórz jawnie niezainicjowane odwołanie.
/// // Kompilator wie, że dane wewnątrz `MaybeUninit<T>` mogą być nieprawidłowe i dlatego nie jest to UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Ustaw prawidłową wartość.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Wyodrębnij zainicjowane dane-jest to dozwolone tylko *po* prawidłowym zainicjowaniu `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Kompilator wie wtedy, aby nie dokonywać żadnych nieprawidłowych założeń ani optymalizacji w tym kodzie.
///
/// Możesz myśleć o `MaybeUninit<T>` jako trochę podobnym do `Option<T>`, ale bez żadnego śledzenia w czasie wykonywania i bez żadnych kontroli bezpieczeństwa.
///
/// ## out-pointers
///
/// Możesz użyć `MaybeUninit<T>` do zaimplementowania "out-pointers": zamiast zwracać dane z funkcji, przekaż jej wskaźnik do jakiejś pamięci (uninitialized), aby umieścić wynik w.
/// Może to być przydatne, gdy dzwoniący musi kontrolować sposób przydzielania pamięci, w której jest przechowywany wynik, i chcesz uniknąć niepotrzebnych ruchów.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` nie upuszcza starej zawartości, co jest ważne.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Teraz wiemy, że `v` jest zainicjowany!Zapewnia to również prawidłowe upuszczenie vector.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicjowanie tablicy element po elemencie
///
/// `MaybeUninit<T>` można użyć do zainicjowania dużej tablicy element po elemencie:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Utwórz niezainicjowaną tablicę `MaybeUninit`.
///     // `assume_init` jest bezpieczny, ponieważ typ, o którym twierdzimy, że został tutaj zainicjowany, to zbiór `MaybeUninit`, które nie wymagają inicjalizacji.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Upuszczenie `MaybeUninit` nic nie daje.
///     // Zatem użycie surowego przypisania wskaźnika zamiast `ptr::write` nie powoduje usunięcia starej niezainicjowanej wartości.
/////
///     // Również jeśli w tej pętli występuje panic, mamy wyciek pamięci, ale nie ma problemu z bezpieczeństwem pamięci.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Wszystko jest zainicjalizowane.
///     // Przekształć tablicę do zainicjowanego typu.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Można również pracować z częściowo zainicjowanymi macierzami, które można znaleźć w strukturach danych niskiego poziomu.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Utwórz niezainicjowaną tablicę `MaybeUninit`.
/// // `assume_init` jest bezpieczny, ponieważ typ, o którym twierdzimy, że został tutaj zainicjowany, to zbiór `MaybeUninit`, które nie wymagają inicjalizacji.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Policz liczbę przypisanych przez nas elementów.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Dla każdego elementu w tablicy upuść, jeśli go przydzieliliśmy.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inicjowanie struktury pole po polu
///
/// Możesz użyć `MaybeUninit<T>` i makra [`std::ptr::addr_of_mut`], aby zainicjować strukturę pole po polu:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicjalizacja pola `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inicjalizacja pola `list` Jeśli w tym miejscu znajduje się panic, to `String` w polu `name` przecieka.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Wszystkie pola są inicjalizowane, więc wywołujemy `assume_init`, aby uzyskać zainicjowane Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ma taki sam rozmiar, wyrównanie i ABI jak `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Jednak pamiętaj, że typ *zawierający*`MaybeUninit<T>` niekoniecznie jest tym samym układem;Rust generalnie nie gwarantuje, że pola `Foo<T>` mają taką samą kolejność jak `Foo<U>`, nawet jeśli `T` i `U` mają ten sam rozmiar i wyrównanie.
///
/// Ponadto, ponieważ każda wartość bitowa jest prawidłowa dla `MaybeUninit<T>`, kompilator nie może zastosować optymalizacji non-zero/niche-filling, co może spowodować większy rozmiar:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Jeśli `T` jest bezpieczny dla FFI, tak samo jest z `MaybeUninit<T>`.
///
/// Chociaż `MaybeUninit` to `#[repr(transparent)]` (co oznacza, że gwarantuje taki sam rozmiar, wyrównanie i ABI jak `T`),*nie* zmienia to żadnego z poprzednich zastrzeżeń.
/// `Option<T>` a `Option<MaybeUninit<T>>` mogą nadal mieć różne rozmiary, a typy zawierające pole typu `T` mogą być rozmieszczone (i mieć inne rozmiary), niż gdyby to pole miało wartość `MaybeUninit<T>`.
/// `MaybeUninit` jest typem unii, a `#[repr(transparent)]` na złączach jest niestabilny (patrz [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Z biegiem czasu dokładne gwarancje `#[repr(transparent)]` dla złączy mogą ewoluować, a `MaybeUninit` może, ale nie musi, pozostać `#[repr(transparent)]`.
/// To powiedziawszy, `MaybeUninit<T>`*zawsze* gwarantuje, że ma taki sam rozmiar, wyrównanie i ABI jak `T`;po prostu sposób, w jaki `MaybeUninit` implementuje tę gwarancję, może ewoluować.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang, abyśmy mogli zawinąć w niego inne typy.Jest to przydatne w przypadku generatorów.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Nie wywołując `T::clone()`, nie możemy wiedzieć, czy jesteśmy do tego wystarczająco zainicjowani.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Tworzy nowy `MaybeUninit<T>` zainicjowany podaną wartością.
    /// Można bezpiecznie wywołać [`assume_init`] na wartości zwracanej przez tę funkcję.
    ///
    /// Zauważ, że upuszczenie `MaybeUninit<T>` nigdy nie wywoła kodu upuszczenia `T`.
    /// Twoim obowiązkiem jest upewnić się, że `T` zostanie usunięty, jeśli został zainicjowany.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Tworzy nowy `MaybeUninit<T>` w stanie niezainicjowanym.
    ///
    /// Zauważ, że upuszczenie `MaybeUninit<T>` nigdy nie wywoła kodu upuszczenia `T`.
    /// Twoim obowiązkiem jest upewnić się, że `T` zostanie usunięty, jeśli został zainicjowany.
    ///
    /// Zobacz [type-level documentation][MaybeUninit] po kilka przykładów.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Utwórz nową tablicę elementów `MaybeUninit<T>` w stanie niezainicjowanym.
    ///
    /// Note: w wersji future Rust ta metoda może stać się niepotrzebna, gdy składnia literału tablicowego zezwala na [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Poniższy przykład może wtedy użyć `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Zwraca (prawdopodobnie mniejszy) wycinek danych, który został faktycznie odczytany
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // BEZPIECZEŃSTWO: Niezainicjowany `[MaybeUninit<_>; LEN]` jest ważny.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Tworzy nowy `MaybeUninit<T>` w stanie niezainicjowanym, z pamięcią wypełnioną bajtami `0`.Od `T` zależy, czy to już zapewnia prawidłową inicjalizację.
    ///
    /// Na przykład `MaybeUninit<usize>::zeroed()` jest inicjowany, ale `MaybeUninit<&'static i32>::zeroed()` nie, ponieważ odwołania nie mogą być puste.
    ///
    /// Zauważ, że upuszczenie `MaybeUninit<T>` nigdy nie wywoła kodu upuszczenia `T`.
    /// Twoim obowiązkiem jest upewnić się, że `T` zostanie usunięty, jeśli został zainicjowany.
    ///
    /// # Example
    ///
    /// Prawidłowe użycie tej funkcji: inicjalizacja struktury z zerem, gdzie wszystkie pola struktury mogą przechowywać wzorzec bitowy 0 jako prawidłową wartość.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Nieprawidłowe* użycie tej funkcji: wywołanie `x.zeroed().assume_init()`, gdy `0` nie jest prawidłowym wzorcem bitowym dla typu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Wewnątrz pary tworzymy `NotZero`, który nie ma ważnego dyskryminatora.
    /// // To jest niezdefiniowane zachowanie.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // BEZPIECZEŃSTWO: `u.as_mut_ptr()` punktów na przydzieloną pamięć.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Ustawia wartość `MaybeUninit<T>`.
    /// Spowoduje to nadpisanie poprzedniej wartości bez jej odrzucania, więc uważaj, aby nie użyć tego dwukrotnie, chyba że chcesz pominąć uruchomienie destruktora.
    ///
    /// Dla Twojej wygody zwraca to również zmienne odniesienie do (teraz bezpiecznie zainicjowanej) zawartości `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // BEZPIECZEŃSTWO: Właśnie zainicjowaliśmy tę wartość.
        unsafe { self.assume_init_mut() }
    }

    /// Pobiera wskaźnik do zawartej wartości.
    /// Czytanie z tego wskaźnika lub przekształcanie go w odniesienie jest niezdefiniowanym zachowaniem, chyba że `MaybeUninit<T>` zostanie zainicjowany.
    /// Zapis do pamięci, na który wskazuje ten wskaźnik (non-transitively), jest niezdefiniowanym zachowaniem (z wyjątkiem wewnątrz `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Prawidłowe użycie tej metody:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Utwórz odniesienie do `MaybeUninit<T>`.To jest w porządku, ponieważ go zainicjowaliśmy.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Nieprawidłowe* użycie tej metody:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Stworzyliśmy odniesienie do niezainicjowanego vector!To jest niezdefiniowane zachowanie.⚠️
    /// ```
    ///
    /// (Zwróć uwagę, że zasady dotyczące odwołań do niezainicjowanych danych nie są jeszcze sfinalizowane, ale zanim to nastąpi, zaleca się ich unikanie).
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` i `ManuallyDrop` to `repr(transparent)`, więc możemy rzutować wskaźnik.
        self as *const _ as *const T
    }

    /// Pobiera zmienny wskaźnik do zawartej wartości.
    /// Czytanie z tego wskaźnika lub przekształcanie go w odniesienie jest niezdefiniowanym zachowaniem, chyba że `MaybeUninit<T>` zostanie zainicjowany.
    ///
    /// # Examples
    ///
    /// Prawidłowe użycie tej metody:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Utwórz odniesienie do `MaybeUninit<Vec<u32>>`.
    /// // To jest w porządku, ponieważ go zainicjowaliśmy.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Nieprawidłowe* użycie tej metody:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Stworzyliśmy odniesienie do niezainicjowanego vector!To jest niezdefiniowane zachowanie.⚠️
    /// ```
    ///
    /// (Zwróć uwagę, że zasady dotyczące odwołań do niezainicjowanych danych nie są jeszcze sfinalizowane, ale zanim to nastąpi, zaleca się ich unikanie).
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` i `ManuallyDrop` to `repr(transparent)`, więc możemy rzutować wskaźnik.
        self as *mut _ as *mut T
    }

    /// Wyodrębnia wartość z kontenera `MaybeUninit<T>`.To świetny sposób, aby upewnić się, że dane zostaną upuszczone, ponieważ wynikowy `T` podlega zwykłej obsłudze upuszczania.
    ///
    /// # Safety
    ///
    /// Od wywołującego zależy, czy `MaybeUninit<T>` naprawdę jest w stanie zainicjalizowanym.Wywołanie tego, gdy zawartość nie jest jeszcze w pełni zainicjowana, powoduje natychmiastowe niezdefiniowane zachowanie.
    /// [type-level documentation][inv] zawiera więcej informacji o tym niezmienniku inicjalizacji.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Ponadto pamiętaj, że większość typów ma dodatkowe niezmienniki, poza zwykłym uznaniem ich za zainicjowane na poziomie typu.
    /// Na przykład [`Vec<T>`] zainicjowany " 1` jest uważany za zainicjowany (w ramach bieżącej implementacji; nie stanowi to stabilnej gwarancji), ponieważ jedynym wymaganiem, o którym wie kompilator, jest to, że wskaźnik danych nie może mieć wartości NULL.
    ///
    /// Utworzenie takiego `Vec<T>` nie powoduje *natychmiastowego* niezdefiniowanego zachowania, ale spowoduje niezdefiniowane zachowanie przy większości bezpiecznych operacji (w tym porzucenie go).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Prawidłowe użycie tej metody:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Nieprawidłowe* użycie tej metody:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` nie został jeszcze zainicjowany, więc ta ostatnia linia powodowała niezdefiniowane zachowanie.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` jest zainicjowany.
        // Oznacza to również, że `self` musi być wariantem `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Odczytuje wartość z kontenera `MaybeUninit<T>`.Powstały `T` podlega zwykłej obsłudze upuszczania.
    ///
    /// O ile to możliwe, lepiej jest zamiast tego używać [`assume_init`], co zapobiega powielaniu zawartości `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Od wywołującego zależy, czy `MaybeUninit<T>` naprawdę jest w stanie zainicjalizowanym.Wywołanie tego, gdy zawartość nie jest jeszcze w pełni zainicjowana, powoduje niezdefiniowane zachowanie.
    /// [type-level documentation][inv] zawiera więcej informacji o tym niezmienniku inicjalizacji.
    ///
    /// Co więcej, pozostawia to kopię tych samych danych w `MaybeUninit<T>`.
    /// W przypadku korzystania z wielu kopii danych (poprzez wielokrotne wywoływanie `assume_init_read` lub najpierw dzwonienie do `assume_init_read`, a następnie do [`assume_init`]), Twoim obowiązkiem jest upewnienie się, że dane te mogą zostać zduplikowane.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Prawidłowe użycie tej metody:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` to `Copy`, więc możemy czytać wiele razy.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Powielanie wartości `None` jest w porządku, więc możemy czytać wiele razy.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Nieprawidłowe* użycie tej metody:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Utworzyliśmy teraz dwie kopie tego samego vector, co prowadzi do podwójnego zwolnienia ⚠️, gdy oba zostaną upuszczone!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` jest zainicjowany.
        // Odczyt z `self.as_ptr()` jest bezpieczny, ponieważ `self` powinien zostać zainicjalizowany.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Porzuca zawartą wartość w miejscu.
    ///
    /// Jeśli posiadasz `MaybeUninit`, możesz zamiast tego użyć [`assume_init`].
    ///
    /// # Safety
    ///
    /// Od wywołującego zależy, czy `MaybeUninit<T>` naprawdę jest w stanie zainicjalizowanym.Wywołanie tego, gdy zawartość nie jest jeszcze w pełni zainicjowana, powoduje niezdefiniowane zachowanie.
    ///
    /// Ponadto wszystkie dodatkowe niezmienniki typu `T` muszą być spełnione, ponieważ implementacja `Drop` `T` (lub jej elementów członkowskich) może na tym polegać.
    /// Na przykład [`Vec<T>`] zainicjowany " 1` jest uważany za zainicjowany (w ramach bieżącej implementacji; nie stanowi to stabilnej gwarancji), ponieważ jedynym wymaganiem, o którym wie kompilator, jest to, że wskaźnik danych nie może mieć wartości NULL.
    ///
    /// Upuszczenie takiego `Vec<T>` spowoduje jednak niezdefiniowane zachowanie.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` jest zainicjowany i
        // spełnia wszystkie niezmienniki `T`.
        // Porzucenie wartości w miejscu jest w takim przypadku bezpieczne.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Pobiera udostępnione odwołanie do zawartej wartości.
    ///
    /// Może to być przydatne, gdy chcemy uzyskać dostęp do `MaybeUninit`, który został zainicjowany, ale nie mamy prawa własności do `MaybeUninit` (uniemożliwiając użycie `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Wywołanie tego, gdy zawartość nie jest jeszcze w pełni zainicjowana, powoduje niezdefiniowane zachowanie: wywołujący musi zagwarantować, że `MaybeUninit<T>` naprawdę jest w stanie zainicjalizowanym.
    ///
    ///
    /// # Examples
    ///
    /// ### Prawidłowe użycie tej metody:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Zainicjuj `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Teraz, gdy wiadomo, że nasz `MaybeUninit<_>` został zainicjowany, można utworzyć do niego współdzielone odniesienie:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // BEZPIECZEŃSTWO: `x` został zainicjowany.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Nieprawidłowe* zastosowania tej metody:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Stworzyliśmy odniesienie do niezainicjowanego vector!To jest niezdefiniowane zachowanie.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Zainicjuj `MaybeUninit` za pomocą `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Odniesienie do niezainicjowanego `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` jest zainicjowany.
        // Oznacza to również, że `self` musi być wariantem `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Pobiera zmienne odwołanie (unique) do zawartej wartości.
    ///
    /// Może to być przydatne, gdy chcemy uzyskać dostęp do `MaybeUninit`, który został zainicjowany, ale nie mamy prawa własności do `MaybeUninit` (uniemożliwiając użycie `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Wywołanie tego, gdy zawartość nie jest jeszcze w pełni zainicjowana, powoduje niezdefiniowane zachowanie: wywołujący musi zagwarantować, że `MaybeUninit<T>` naprawdę jest w stanie zainicjalizowanym.
    /// Na przykład `.assume_init_mut()` nie może być użyty do zainicjowania `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Prawidłowe użycie tej metody:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicjuje *wszystkie* bajty buforu wejściowego.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Zainicjuj `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Teraz wiemy, że `buf` został zainicjowany, więc możemy go `.assume_init()`.
    /// // Jednak użycie `.assume_init()` może wyzwolić `memcpy` z 2048 bajtów.
    /// // Aby potwierdzić, że nasz bufor został zainicjowany bez kopiowania go, aktualizujemy `&mut MaybeUninit<[u8; 2048]>` do `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // BEZPIECZEŃSTWO: `buf` został zainicjowany.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Teraz możemy użyć `buf` jako normalnego wycinka:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Nieprawidłowe* zastosowania tej metody:
    ///
    /// Nie można użyć `.assume_init_mut()` do zainicjowania wartości:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Stworzyliśmy odniesienie (mutable) do niezainicjowanego `bool`!
    ///     // To jest niezdefiniowane zachowanie.⚠️
    /// }
    /// ```
    ///
    /// Na przykład nie możesz [`Read`] do niezainicjowanego bufora:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) odniesienie do niezainicjowanej pamięci!
    ///                             // To jest niezdefiniowane zachowanie.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Nie można też używać bezpośredniego dostępu do pola do stopniowej inicjalizacji pola po polu:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) odniesienie do niezainicjowanej pamięci!
    ///                  // To jest niezdefiniowane zachowanie.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) odniesienie do niezainicjowanej pamięci!
    ///                  // To jest niezdefiniowane zachowanie.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Obecnie polegamy na tym, że powyższe jest nieprawidłowe, tj. Mamy odniesienia do niezainicjowanych danych (np. W `libcore/fmt/float.rs`).
    // Ostateczną decyzję o zasadach powinniśmy podjąć przed stabilizacją.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` jest zainicjowany.
        // Oznacza to również, że `self` musi być wariantem `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Wyodrębnia wartości z tablicy kontenerów `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Obiekt wywołujący musi zagwarantować, że wszystkie elementy tablicy są w stanie zainicjowanym.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // BEZPIECZEŃSTWO: Teraz bezpieczne, ponieważ zainicjowaliśmy wszystkie elementy
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Obiekt wywołujący gwarantuje, że wszystkie elementy tablicy zostały zainicjowane
        // * `MaybeUninit<T>` i T na pewno mają ten sam układ
        // * Może Unint nie spada, więc nie ma podwójnych zwolnień, a zatem konwersja jest bezpieczna
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Zakładając, że wszystkie elementy są zainicjowane, pobierz do nich wycinek.
    ///
    /// # Safety
    ///
    /// Od wywołującego zależy, czy elementy `MaybeUninit<T>` są rzeczywiście w stanie zainicjowanym.
    ///
    /// Wywołanie tego, gdy zawartość nie jest jeszcze w pełni zainicjowana, powoduje niezdefiniowane zachowanie.
    ///
    /// Zobacz [`assume_init_ref`], aby uzyskać więcej szczegółów i przykładów.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // BEZPIECZEŃSTWO: rzucanie plastra na `*const [T]` jest bezpieczne, ponieważ dzwoniący gwarantuje to
        // `slice` jest zainicjowany, a " MaybeUninit` ma zapewniony taki sam układ jak `T`.
        // Uzyskany wskaźnik jest prawidłowy, ponieważ odnosi się do pamięci należącej do `slice`, która jest odniesieniem, a zatem gwarantuje poprawność odczytu.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Zakładając, że wszystkie elementy są zainicjowane, pobierz do nich zmienny wycinek.
    ///
    /// # Safety
    ///
    /// Od wywołującego zależy, czy elementy `MaybeUninit<T>` są rzeczywiście w stanie zainicjowanym.
    ///
    /// Wywołanie tego, gdy zawartość nie jest jeszcze w pełni zainicjowana, powoduje niezdefiniowane zachowanie.
    ///
    /// Zobacz [`assume_init_mut`], aby uzyskać więcej szczegółów i przykładów.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // BEZPIECZEŃSTWO: podobne do uwag bezpieczeństwa dla `slice_get_ref`, ale mamy plik
        // zmienne odniesienie, które jest gwarantowane również dla zapisów.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Pobiera wskaźnik do pierwszego elementu tablicy.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Pobiera mutowalny wskaźnik do pierwszego elementu tablicy.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopiuje elementy z `src` do `this`, zwracając zmienne odwołanie do zainicjalizowanej teraz zawartości `this`.
    ///
    /// Jeśli `T` nie implementuje `Copy`, użyj [`write_slice_cloned`]
    ///
    /// Jest to podobne do [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ta funkcja spowoduje panic, jeśli dwa plastry mają różne długości.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // BEZPIECZEŃSTWO: właśnie skopiowaliśmy wszystkie elementy len do wolnych mocy produkcyjnych
    /// // pierwsze elementy src.len() vec są już ważne.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // BEZPIECZEŃSTWO: &[T] i&[MaybeUninit<T>] mają ten sam układ
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // BEZPIECZEŃSTWO: Prawidłowe elementy zostały właśnie skopiowane do `this`, więc zostało zainicjalizowane
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonuje elementy z `src` do `this`, zwracając zmienne odniesienie do zainicjalizowanej teraz zawartości `this`.
    /// Żadne już zainicjowane elementy nie zostaną usunięte.
    ///
    /// Jeśli `T` implementuje `Copy`, użyj [`write_slice`]
    ///
    /// Jest to podobne do [`slice::clone_from_slice`], ale nie powoduje usunięcia istniejących elementów.
    ///
    /// # Panics
    ///
    /// Ta funkcja będzie panic, jeśli dwa wycinki mają różne długości lub jeśli implementacja `Clone` panics.
    ///
    /// Jeśli istnieje panic, już sklonowane elementy zostaną usunięte.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // BEZPIECZEŃSTWO: właśnie sklonowaliśmy wszystkie elementy len w wolne moce produkcyjne
    /// // pierwsze elementy src.len() vec są już ważne.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // w przeciwieństwie do copy_from_slice nie wywołuje clone_from_slice na wycinku, ponieważ `MaybeUninit<T: Clone>` nie implementuje Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // BEZPIECZEŃSTWO: ten surowy wycinek będzie zawierał tylko zainicjalizowane obiekty
                // dlatego wolno go upuścić.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Musimy wyraźnie pokroić je na taką samą długość
        // aby sprawdzanie granic zostało wyeliminowane, a optymalizator wygeneruje memcpy dla prostych przypadków (na przykład T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // potrzebna jest osłona b/c panic może się zdarzyć podczas klonowania
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // BEZPIECZEŃSTWO: Prawidłowe elementy zostały właśnie zapisane w `this`, więc jest inicjalizowany
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}