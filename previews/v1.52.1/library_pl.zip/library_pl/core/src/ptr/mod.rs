//! Ręcznie zarządzaj pamięcią za pomocą surowych wskaźników.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Wiele funkcji w tym module przyjmuje surowe wskaźniki jako argumenty i odczytuje je lub zapisuje do nich.Aby było to bezpieczne, te wskaźniki muszą być *ważne*.
//! To, czy wskaźnik jest prawidłowy, zależy od operacji, do której jest używany (do odczytu lub zapisu) oraz od rozmiaru dostępnej pamięci (tj. Ile bajtów to read/written).
//! Większość funkcji używa `*mut T` i `* const T` do uzyskiwania dostępu tylko do pojedynczej wartości, w którym to przypadku dokumentacja pomija rozmiar i domyślnie zakłada, że jest to `size_of::<T>()` bajtów.
//!
//! Dokładne zasady obowiązywania nie są jeszcze określone.Gwarancje, które są udzielane w tym momencie, są bardzo minimalne:
//!
//! * Wskaźnik [null]*nigdy* nie jest poprawny, nawet w przypadku dostępu do [size zero][zst].
//! * Aby wskaźnik był poprawny, konieczne jest, ale nie zawsze wystarczające, aby wskaźnik był *dereferencjonowalny*: zakres pamięci o podanym rozmiarze, zaczynając od wskaźnika, musi w całości znajdować się w granicach pojedynczego przydzielonego obiektu.
//!
//! Zauważ, że w Rust każda zmienna (stack-allocated) jest uważana za oddzielny przydzielony obiekt.
//! * Nawet w przypadku operacji [size zero][zst] wskaźnik nie może wskazywać na zwolnioną pamięć, tj. Cofnięcie alokacji powoduje, że wskaźniki są nieważne nawet w przypadku operacji o zerowej wielkości.
//! Jednak rzutowanie dowolnej niezerowej liczby całkowitej *literału* na wskaźnik jest poprawne dla dostępów o zerowej wielkości, nawet jeśli część pamięci istnieje pod tym adresem i zostanie zwolniona.
//! Odpowiada to pisaniu własnego alokatora: przydzielanie obiektów o zerowej wielkości nie jest trudne.
//! Kanonicznym sposobem uzyskania wskaźnika, który jest prawidłowy dla dostępów o zerowej wielkości, jest [`NonNull::dangling`].
//! * Wszystkie dostępy wykonywane przez funkcje w tym module są *nieatomowe* w sensie [atomic operations] używanym do synchronizacji między wątkami.
//! Oznacza to, że wykonywanie dwóch jednoczesnych dostępów do tej samej lokalizacji z różnych wątków jest niezdefiniowanym zachowaniem, chyba że oba uzyskują dostęp tylko do odczytu z pamięci.
//! Należy zauważyć, że obejmuje to jawnie [`read_volatile`] i [`write_volatile`]: Dostępów lotnych nie można używać do synchronizacji między wątkami.
//! * Wynik rzutowania odwołania do wskaźnika jest ważny tak długo, jak obiekt bazowy jest aktywny i żadne odwołanie (tylko surowe wskaźniki) nie jest używane w celu uzyskania dostępu do tej samej pamięci.
//!
//! Te aksjomaty, wraz z ostrożnym użyciem [`offset`] do arytmetyki wskaźników, wystarczą, aby poprawnie zaimplementować wiele przydatnych rzeczy w niebezpiecznym kodzie.
//! W końcu zostaną zapewnione silniejsze gwarancje, ponieważ reguły [aliasing] są określane.
//! Aby uzyskać więcej informacji, zobacz [book], a także sekcję w dokumentacji poświęconej [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Prawidłowe surowe wskaźniki, jak zdefiniowano powyżej, niekoniecznie muszą być odpowiednio wyrównane (gdzie wyrównanie "proper" jest zdefiniowane przez typ pointee, tj. `*const T` musi być wyrównane do `mem::align_of::<T>()`).
//! Jednak większość funkcji wymaga odpowiedniego wyrównania argumentów i wyraźnie określa to wymaganie w swojej dokumentacji.
//! Godnymi uwagi wyjątkami od tej reguły są [`read_unaligned`] i [`write_unaligned`].
//!
//! Gdy funkcja wymaga odpowiedniego wyrównania, robi to nawet jeśli dostęp ma rozmiar 0, tj. Nawet jeśli pamięć nie jest faktycznie dotykana.W takich przypadkach rozważ użycie [`NonNull::dangling`].
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Wykonuje destruktor (jeśli istnieje) wskazanej wartości.
///
/// Jest to semantycznie równoważne wywołaniu [`ptr::read`] i odrzuceniu wyniku, ale ma następujące zalety:
///
/// * *Wymagane jest* użycie `drop_in_place` do usuwania nietypowych typów, takich jak obiekty trait, ponieważ nie można ich odczytać na stos i normalnie upuścić.
///
/// * Jest to bardziej przyjazne dla optymalizatora, aby zrobić to przez [`ptr::read`], gdy porzuca ręcznie przydzieloną pamięć (np. W implementacjach `Box`/`Rc`/`Vec`), ponieważ kompilator nie musi udowadniać, że usunięcie kopii jest rozsądne.
///
///
/// * Można go użyć do upuszczenia danych [pinned], gdy `T` nie jest `repr(packed)` (przypiętych danych nie można przenosić przed upuszczeniem).
///
/// Wartości niewyrównanych nie można upuszczać na miejscu, należy je najpierw skopiować do wyrównanego miejsca przy użyciu [`ptr::read_unaligned`].W przypadku struktur spakowanych ten ruch jest wykonywany automatycznie przez kompilator.
/// Oznacza to, że pola zapakowanych struktur nie są upuszczane na miejscu.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `to_drop` musi mieć wartość [valid] zarówno dla odczytu, jak i zapisu.
///
/// * `to_drop` muszą być odpowiednio wyrównane.
///
/// * Wartość `to_drop` punktów musi być ważna do usunięcia, co może oznaczać, że musi uwzględniać dodatkowe niezmienniki, jest to zależne od typu.
///
/// Ponadto, jeśli `T` nie jest [`Copy`], użycie wskazanej wartości po wywołaniu `drop_in_place` może spowodować niezdefiniowane zachowanie.Zauważ, że `*to_drop = foo` liczy się jako użycie, ponieważ spowoduje ponowne odrzucenie wartości.
/// [`write()`] może służyć do nadpisywania danych bez powodowania ich upuszczenia.
///
/// Zauważ, że nawet jeśli `T` ma rozmiar `0`, wskaźnik musi być różny od NULL i odpowiednio wyrównany.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ręcznie usuń ostatni element z vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Uzyskaj nieprzetworzony wskaźnik do ostatniego elementu w `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Skróć `v`, aby zapobiec upuszczeniu ostatniego przedmiotu.
///     // Robimy to najpierw, aby zapobiec problemom, jeśli `drop_in_place` jest poniżej panics.
///     v.set_len(1);
///     // Bez wywołania `drop_in_place` ostatni element nigdy nie zostałby upuszczony, a pamięć, którą zarządza, zostałaby ujawniona.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Upewnij się, że ostatni element został upuszczony.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Zauważ, że kompilator wykonuje tę kopię automatycznie podczas usuwania spakowanych struktur, tj. Zwykle nie musisz się martwić takimi problemami, chyba że ręcznie wywołasz `drop_in_place`.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kod tutaj nie ma znaczenia, jest on zastępowany przez prawdziwy klej kroplowy przez kompilator.
    //

    // BEZPIECZEŃSTWO: patrz komentarz powyżej
    unsafe { drop_in_place(to_drop) }
}

/// Tworzy pusty wskaźnik nieprzetworzony.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Tworzy zerowy, zmienny wskaźnik nieprzetworzony.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Ręczny impl potrzebny, aby uniknąć wiązania `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Ręczny impl potrzebny, aby uniknąć wiązania `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Tworzy surowy plasterek ze wskaźnika i długości.
///
/// Argument `len` to liczba **elementów**, a nie liczba bajtów.
///
/// Ta funkcja jest bezpieczna, ale w rzeczywistości używanie wartości zwracanej jest niebezpieczne.
/// Zapoznaj się z dokumentacją [`slice::from_raw_parts`], aby zapoznać się z wymaganiami dotyczącymi bezpieczeństwa plasterków.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // utwórz wskaźnik plasterka, zaczynając od wskaźnika do pierwszego elementu
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // BEZPIECZEŃSTWO: Dostęp do wartości z unii `Repr` jest bezpieczny od * const [T]
        //
        // i FatPtr mają te same układy pamięci.Tylko std może dać tę gwarancję.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Pełni te same funkcje co [`slice_from_raw_parts`], z tą różnicą, że zwracany jest nieprzetworzony, zmienny wycinek, w przeciwieństwie do surowego niezmiennego wycinka.
///
///
/// Więcej informacji można znaleźć w dokumentacji [`slice_from_raw_parts`].
///
/// Ta funkcja jest bezpieczna, ale w rzeczywistości używanie wartości zwracanej jest niebezpieczne.
/// Zapoznaj się z dokumentacją [`slice::from_raw_parts_mut`], aby zapoznać się z wymaganiami bezpieczeństwa plastra.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // przypisać wartość do indeksu w wycinku
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // BEZPIECZEŃSTWO: Dostęp do wartości z unii `Repr` jest bezpieczny od * mut [T]
        // i FatPtr mają te same układy pamięci
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Zamienia wartości w dwóch zmiennych lokalizacjach tego samego typu, również bez deinicjalizacji.
///
/// Ale z następującymi dwoma wyjątkami ta funkcja jest semantycznie równoważna [`mem::swap`]:
///
///
/// * Działa na surowych wskaźnikach zamiast na referencjach.
/// Jeśli dostępne są referencje, preferowany powinien być [`mem::swap`].
///
/// * Dwie wskazane wartości mogą się pokrywać.
/// Jeśli wartości nakładają się, zostanie użyty nakładający się obszar pamięci z `x`.
/// Pokazuje to drugi przykład poniżej.
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * Zarówno `x`, jak i `y` muszą być [valid] zarówno do odczytu, jak i do zapisu.
///
/// * Zarówno `x`, jak i `y` muszą być odpowiednio wyrównane.
///
/// Zauważ, że nawet jeśli `T` ma rozmiar `0`, wskaźniki muszą być inne niż NULL i odpowiednio wyrównane.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Zamiana dwóch nie nakładających się regionów:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // to jest `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // to jest `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Zamiana dwóch nakładających się regionów:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // to jest `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // to jest `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indeksy `1..3` wycinka nakładają się na `x` i `y`.
///     // Rozsądne wyniki byłyby dla nich `[2, 3]`, więc indeksy `0..3` to `[1, 2, 3]` (pasujące do `y` przed `swap`);lub aby były `[0, 1]`, tak aby indeksy `1..4` były `[0, 1, 2]` (pasujące do `x` przed `swap`).
/////
///     // Ta implementacja jest zdefiniowana w celu dokonania drugiego wyboru.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Daj sobie trochę miejsca na zarysowania do pracy.
    // Nie musimy się martwić kroplami: `MaybeUninit` nic nie robi po upuszczeniu.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Wykonaj swap BEZPIECZEŃSTWO: wywołujący musi zagwarantować, że `x` i `y` są prawidłowe dla zapisów i odpowiednio wyrównane.
    // `tmp` nie może zachodzić na `x` ani `y`, ponieważ `tmp` został właśnie przydzielony na stosie jako oddzielny przydzielony obiekt.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` i `y` mogą się pokrywać
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Zamienia bajty `count * size_of::<T>()` między dwoma regionami pamięci, zaczynając od `x` i `y`.
/// Te dwa regiony *nie* mogą się pokrywać.
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * Zarówno `x`, jak i `y` muszą być [valid] zarówno dla odczytu, jak i zapisu `count *
///   rozmiar: :<T>() `bajtów.
///
/// * Zarówno `x`, jak i `y` muszą być odpowiednio wyrównane.
///
/// * Obszar pamięci rozpoczynający się od `x` i o rozmiarze `count *
///   rozmiar: :<T>() `bajty *nie* mogą pokrywać się z obszarem pamięci rozpoczynającym się od `y` o tym samym rozmiarze.
///
/// Zauważ, że nawet jeśli efektywnie skopiowany rozmiar (`count * size_of: :<T>()`) to `0`, wskaźniki muszą być inne niż NULL i odpowiednio wyrównane.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `x` i `y` są
    // ważne dla zapisów i odpowiednio wyrównane.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // W przypadku typów mniejszych niż optymalizacja bloku poniżej, po prostu zamień bezpośrednio, aby uniknąć pesymizacji codegen.
    //
    if mem::size_of::<T>() < 32 {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `x` i `y` są ważne
        // do zapisów, prawidłowo wyrównane i nie nakładające się.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Podejście tutaj polega na wykorzystaniu simd do wydajnej zamiany x&y.
    // Testy pokazują, że zamiana 32 lub 64 bajtów naraz jest najbardziej wydajna w przypadku procesorów Intel Haswell E.
    // LLVM jest bardziej w stanie zoptymalizować, jeśli nadamy strukturze #[repr(simd)], nawet jeśli w rzeczywistości nie używamy tej struktury bezpośrednio.
    //
    //
    // FIXME repr(simd) uszkodzony na emscripten i redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Pętla przez x&y, kopiując je `Block` na raz Optymalizator powinien całkowicie rozwinąć pętlę dla większości typów NB
    // Nie możemy użyć pętli for, ponieważ `range` impl wywołuje `mem::swap` rekurencyjnie
    //
    let mut i = 0;
    while i + block_size <= len {
        // Stwórz trochę niezainicjowanej pamięci jako miejsce na zarysowania Zadeklarowanie `t` tutaj pozwala uniknąć wyrównywania stosu gdy ta pętla nie jest używana
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // BEZPIECZEŃSTWO: Jako `i < len` i jako dzwoniący musi zagwarantować, że `x` i `y` są ważne
        // dla bajtów `len` `x + i` i `y + i` muszą być prawidłowymi adresami, co spełnia warunki umowy bezpieczeństwa dla `add`.
        //
        // Ponadto dzwoniący musi zagwarantować, że `x` i `y` są prawidłowe dla zapisów, prawidłowo wyrównane i nie pokrywają się, co jest zgodne z umową bezpieczeństwa dla `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Zamień blok bajtów x i y, używając t jako tymczasowego bufora Powinien być zoptymalizowany pod kątem wydajnych operacji SIMD, jeśli są dostępne
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Zamień wszystkie pozostałe bajty
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // BEZPIECZEŃSTWO: patrz poprzedni komentarz dotyczący bezpieczeństwa.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Przenosi `src` do wskazanego `dst`, zwracając poprzednią wartość `dst`.
///
/// Żadna wartość nie jest pomijana.
///
/// Ta funkcja jest semantycznie równoważna [`mem::replace`] z tym wyjątkiem, że działa na surowych wskaźnikach zamiast na referencjach.
/// Jeśli dostępne są referencje, preferowany powinien być [`mem::replace`].
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `dst` musi mieć wartość [valid] zarówno dla odczytu, jak i zapisu.
///
/// * `dst` muszą być odpowiednio wyrównane.
///
/// * `dst` musi wskazywać na prawidłowo zainicjowaną wartość typu `T`.
///
/// Zauważ, że nawet jeśli `T` ma rozmiar `0`, wskaźnik musi być różny od NULL i odpowiednio wyrównany.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` miałoby ten sam skutek bez konieczności wykonania niebezpiecznej blokady.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `dst` jest ważny
    // rzutowane na zmienne odniesienie (ważne dla zapisów, wyrównane, zainicjowane) i nie może nakładać się na `src`, ponieważ `dst` musi wskazywać na odrębny przydzielony obiekt.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // nie mogą się pokrywać
    }
    src
}

/// Odczytuje wartość z `src` bez jej przenoszenia.Pozostawia to pamięć w `src` bez zmian.
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `src` do odczytu musi być [valid].
///
/// * `src` muszą być odpowiednio wyrównane.Jeśli tak nie jest, użyj [`read_unaligned`].
///
/// * `src` musi wskazywać na prawidłowo zainicjowaną wartość typu `T`.
///
/// Zauważ, że nawet jeśli `T` ma rozmiar `0`, wskaźnik musi być różny od NULL i odpowiednio wyrównany.
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ręcznie zaimplementuj [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Utwórz bitową kopię wartości w `a` w `tmp`.
///         let tmp = ptr::read(a);
///
///         // Wyjście w tym momencie (albo przez jawne zwrócenie, albo przez wywołanie funkcji, którą panics) spowodowałoby odrzucenie wartości w `tmp`, podczas gdy `a` wciąż odwołuje się do tej samej wartości.
///         // Może to wywołać niezdefiniowane zachowanie, jeśli `T` nie jest `Copy`.
/////
/////
///
///         // Utwórz bitową kopię wartości w `b` w `a`.
///         // Jest to bezpieczne, ponieważ zmienne odwołania nie mogą być aliasami.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Jak powyżej, wyjście w tym miejscu może wywołać niezdefiniowane zachowanie, ponieważ `a` i `b` odwołują się do tej samej wartości.
/////
///
///         // Przenieś `tmp` do `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` został przeniesiony (`write` przejmuje na własność swój drugi argument), więc nic nie jest tu domyślnie upuszczane.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Własność zwróconej wartości
///
/// `read` tworzy bitową kopię `T`, niezależnie od tego, czy `T` to [`Copy`].
/// Jeśli `T` nie jest [`Copy`], użycie zarówno wartości zwróconej, jak i wartości w `*src` może naruszyć bezpieczeństwo pamięci.
/// Zauważ, że przypisanie do `*src` liczy się jako użycie, ponieważ spowoduje próbę obniżenia wartości na `* src`.
///
/// [`write()`] może służyć do nadpisywania danych bez powodowania ich upuszczenia.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` teraz wskazuje na tę samą pamięć podstawową co `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Przypisanie do `s2` powoduje usunięcie jego pierwotnej wartości.
///     // Poza tym punktem `s` nie może być dłużej używane, ponieważ podstawowa pamięć została zwolniona.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Przypisanie do `s` spowodowałoby ponowne odrzucenie starej wartości, co spowodowałoby niezdefiniowane zachowanie.
/////
///     // s= String::from("bar");//BŁĄD
///
///     // `ptr::write` można użyć do nadpisania wartości bez jej porzucania.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `src` jest poprawny do odczytu.
    // `src` nie może nakładać się na `tmp`, ponieważ `tmp` został właśnie przydzielony na stosie jako oddzielny przydzielony obiekt.
    //
    //
    // Ponadto, ponieważ właśnie zapisaliśmy prawidłową wartość w `tmp`, gwarantujemy, że zostanie ona poprawnie zainicjowana.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Odczytuje wartość z `src` bez jej przenoszenia.Pozostawia to pamięć w `src` bez zmian.
///
/// W przeciwieństwie do [`read`], `read_unaligned` działa z niewyrównanymi wskaźnikami.
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `src` do odczytu musi być [valid].
///
/// * `src` musi wskazywać na prawidłowo zainicjowaną wartość typu `T`.
///
/// Podobnie jak [`read`], `read_unaligned` tworzy bitową kopię `T`, niezależnie od tego, czy `T` to [`Copy`].
/// Jeśli `T` nie jest [`Copy`], użycie zarówno wartości zwróconej, jak i wartości w `*src` może [violate memory safety][read-ownership].
///
/// Zauważ, że nawet jeśli `T` ma rozmiar `0`, wskaźnik nie może mieć wartości NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## W strukturach `packed`
///
/// Obecnie nie jest możliwe tworzenie surowych wskaźników do niewyrównanych pól upakowanej struktury.
///
/// Próba utworzenia surowego wskaźnika do pola struktury `unaligned` za pomocą wyrażenia, takiego jak `&packed.unaligned as *const FieldType`, powoduje utworzenie pośredniego niewyrównanego odniesienia przed konwersją go do surowego wskaźnika.
///
/// To, że to odwołanie jest tymczasowe i natychmiast rzutowane, nie ma znaczenia, ponieważ kompilator zawsze oczekuje, że odwołania będą odpowiednio wyrównane.
/// W rezultacie użycie `&packed.unaligned as *const FieldType` powoduje natychmiastowe* niezdefiniowane zachowanie * w programie.
///
/// Przykładem tego, czego nie robić i jak to się ma do `read_unaligned`, jest:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Tutaj próbujemy wziąć adres 32-bitowej liczby całkowitej, która nie jest wyrównana.
///     let unaligned =
///         // Tworzone jest tutaj tymczasowe niewyrównane odniesienie, które skutkuje niezdefiniowanym zachowaniem, niezależnie od tego, czy odniesienie jest używane, czy nie.
/////
///         &packed.unaligned
///         // Rzutowanie na surowy wskaźnik nie pomaga;błąd już się wydarzył.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Dostęp do niewyrównanych pól bezpośrednio za pomocą np. `packed.unaligned` jest jednak bezpieczny.
///
///
///
///
///
///
// FIXME: Zaktualizuj dokumenty na podstawie wyników RFC #2582 i znajomych.
/// # Examples
///
/// Odczytaj wartość usize z bufora bajtowego:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `src` jest poprawny do odczytu.
    // `src` nie może nakładać się na `tmp`, ponieważ `tmp` został właśnie przydzielony na stosie jako oddzielny przydzielony obiekt.
    //
    //
    // Ponadto, ponieważ właśnie zapisaliśmy prawidłową wartość w `tmp`, gwarantujemy, że zostanie ona poprawnie zainicjowana.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Zastępuje lokalizację pamięci podaną wartością bez odczytywania lub upuszczania starej wartości.
///
/// `write` nie upuszcza zawartości `dst`.
/// Jest to bezpieczne, ale może spowodować wyciek przydziałów lub zasobów, dlatego należy uważać, aby nie nadpisać obiektu, który powinien zostać upuszczony.
///
///
/// Dodatkowo nie upuszcza `src`.Semantycznie `src` jest przenoszony do lokalizacji wskazywanej przez `dst`.
///
/// Jest to odpowiednie do inicjowania niezainicjowanej pamięci lub nadpisywania pamięci, z której poprzednio pochodziła [`read`].
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `dst` musi być [valid] do zapisu.
///
/// * `dst` muszą być odpowiednio wyrównane.Jeśli tak nie jest, użyj [`write_unaligned`].
///
/// Zauważ, że nawet jeśli `T` ma rozmiar `0`, wskaźnik musi być różny od NULL i odpowiednio wyrównany.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ręcznie zaimplementuj [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Utwórz bitową kopię wartości w `a` w `tmp`.
///         let tmp = ptr::read(a);
///
///         // Wyjście w tym momencie (albo przez jawne zwrócenie, albo przez wywołanie funkcji, którą panics) spowodowałoby odrzucenie wartości w `tmp`, podczas gdy `a` wciąż odwołuje się do tej samej wartości.
///         // Może to wywołać niezdefiniowane zachowanie, jeśli `T` nie jest `Copy`.
/////
/////
///
///         // Utwórz bitową kopię wartości w `b` w `a`.
///         // Jest to bezpieczne, ponieważ zmienne odwołania nie mogą być aliasami.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Jak powyżej, wyjście w tym miejscu może wywołać niezdefiniowane zachowanie, ponieważ `a` i `b` odwołują się do tej samej wartości.
/////
///
///         // Przenieś `tmp` do `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` został przeniesiony (`write` przejmuje na własność swój drugi argument), więc nic nie jest tu domyślnie upuszczane.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Wołamy elementy wewnętrzne bezpośrednio, aby uniknąć wywołań funkcji w generowanym kodzie, ponieważ `intrinsics::copy_nonoverlapping` jest funkcją opakowującą.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `dst` jest ważny dla zapisów.
    // `dst` nie może nakładać się na `src`, ponieważ wywołujący ma modyfikowalny dostęp do `dst`, podczas gdy `src` jest własnością tej funkcji.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Zastępuje lokalizację pamięci podaną wartością bez odczytywania lub upuszczania starej wartości.
///
/// W przeciwieństwie do [`write()`], wskaźnik może być niewyrównany.
///
/// `write_unaligned` nie upuszcza zawartości `dst`.Jest to bezpieczne, ale może spowodować wyciek przydziałów lub zasobów, dlatego należy uważać, aby nie nadpisać obiektu, który powinien zostać upuszczony.
///
/// Dodatkowo nie upuszcza `src`.Semantycznie `src` jest przenoszony do lokalizacji wskazywanej przez `dst`.
///
/// Jest to odpowiednie do inicjowania niezainicjowanej pamięci lub nadpisywania pamięci, która została wcześniej odczytana za pomocą [`read_unaligned`].
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `dst` musi być [valid] do zapisu.
///
/// Zauważ, że nawet jeśli `T` ma rozmiar `0`, wskaźnik nie może mieć wartości NULL.
///
/// [valid]: self#safety
///
/// ## W strukturach `packed`
///
/// Obecnie nie jest możliwe tworzenie surowych wskaźników do niewyrównanych pól upakowanej struktury.
///
/// Próba utworzenia surowego wskaźnika do pola struktury `unaligned` za pomocą wyrażenia, takiego jak `&packed.unaligned as *const FieldType`, powoduje utworzenie pośredniego niewyrównanego odniesienia przed konwersją go do surowego wskaźnika.
///
/// To, że to odwołanie jest tymczasowe i natychmiast rzutowane, nie ma znaczenia, ponieważ kompilator zawsze oczekuje, że odwołania będą odpowiednio wyrównane.
/// W rezultacie użycie `&packed.unaligned as *const FieldType` powoduje natychmiastowe* niezdefiniowane zachowanie * w programie.
///
/// Przykładem tego, czego nie robić i jak to się ma do `write_unaligned`, jest:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Tutaj próbujemy wziąć adres 32-bitowej liczby całkowitej, która nie jest wyrównana.
///     let unaligned =
///         // Tworzone jest tutaj tymczasowe niewyrównane odniesienie, które skutkuje niezdefiniowanym zachowaniem, niezależnie od tego, czy odniesienie jest używane, czy nie.
/////
///         &mut packed.unaligned
///         // Rzutowanie na surowy wskaźnik nie pomaga;błąd już się wydarzył.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Dostęp do niewyrównanych pól bezpośrednio za pomocą np. `packed.unaligned` jest jednak bezpieczny.
///
///
///
///
///
///
///
///
///
// FIXME: Zaktualizuj dokumenty na podstawie wyników RFC #2582 i znajomych.
/// # Examples
///
/// Zapisz wartość usize do bufora bajtowego:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `dst` jest ważny dla zapisów.
    // `dst` nie może nakładać się na `src`, ponieważ wywołujący ma modyfikowalny dostęp do `dst`, podczas gdy `src` jest własnością tej funkcji.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Wołamy element wewnętrzny bezpośrednio, aby uniknąć wywołań funkcji w wygenerowanym kodzie.
        intrinsics::forget(src);
    }
}

/// Dokonuje ulotnego odczytu wartości z `src` bez jej przenoszenia.Pozostawia to pamięć w `src` bez zmian.
///
/// Operacje ulotne mają działać na pamięci I/O i gwarantuje, że kompilator nie usunie ich ani nie zmieni ich kolejności w innych operacjach ulotnych.
///
/// # Notes
///
/// Rust nie ma obecnie rygorystycznie i formalnie zdefiniowanego modelu pamięci, więc precyzyjna semantyka tego, co oznacza tutaj "volatile", może się zmieniać w czasie.
/// Biorąc to pod uwagę, semantyka prawie zawsze będzie bardzo podobna do [C11's definition of volatile][c11].
///
/// Kompilator nie powinien zmieniać względnej kolejności ani liczby operacji na pamięci ulotnej.
/// Jednak operacje na pamięci ulotnej na typach o rozmiarze zerowym (np. Jeśli typ o rozmiarze zerowym jest przesyłany do `read_volatile`) są nieudane i mogą być ignorowane.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `src` do odczytu musi być [valid].
///
/// * `src` muszą być odpowiednio wyrównane.
///
/// * `src` musi wskazywać na prawidłowo zainicjowaną wartość typu `T`.
///
/// Podobnie jak [`read`], `read_volatile` tworzy bitową kopię `T`, niezależnie od tego, czy `T` to [`Copy`].
/// Jeśli `T` nie jest [`Copy`], użycie zarówno wartości zwróconej, jak i wartości w `*src` może [violate memory safety][read-ownership].
/// Jednak przechowywanie typów innych niż [`Copy`] w pamięci ulotnej jest prawie na pewno nieprawidłowe.
///
/// Zauważ, że nawet jeśli `T` ma rozmiar `0`, wskaźnik musi być różny od NULL i odpowiednio wyrównany.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Podobnie jak w C, to, czy operacja jest niestabilna, nie ma żadnego wpływu na pytania dotyczące równoczesnego dostępu z wielu wątków.Dostęp zmienny zachowuje się pod tym względem dokładnie tak samo, jak dostępy nieatomowe.
///
/// W szczególności wyścig między `read_volatile` a jakąkolwiek operacją zapisu w tej samej lokalizacji jest niezdefiniowanym zachowaniem.
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Nie panikuj, by zmniejszyć wpływ codegen.
        abort();
    }
    // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Wykonuje ulotny zapis lokalizacji pamięci z podaną wartością bez odczytywania lub porzucania starej wartości.
///
/// Operacje ulotne mają działać na pamięci I/O i gwarantuje, że kompilator nie usunie ich ani nie zmieni ich kolejności w innych operacjach ulotnych.
///
/// `write_volatile` nie upuszcza zawartości `dst`.Jest to bezpieczne, ale może spowodować wyciek przydziałów lub zasobów, dlatego należy uważać, aby nie nadpisać obiektu, który powinien zostać upuszczony.
///
/// Dodatkowo nie upuszcza `src`.Semantycznie `src` jest przenoszony do lokalizacji wskazywanej przez `dst`.
///
/// # Notes
///
/// Rust nie ma obecnie rygorystycznie i formalnie zdefiniowanego modelu pamięci, więc precyzyjna semantyka tego, co oznacza tutaj "volatile", może się zmieniać w czasie.
/// Biorąc to pod uwagę, semantyka prawie zawsze będzie bardzo podobna do [C11's definition of volatile][c11].
///
/// Kompilator nie powinien zmieniać względnej kolejności ani liczby operacji na pamięci ulotnej.
/// Jednak operacje na pamięci ulotnej na typach o rozmiarze zerowym (np. Jeśli typ o rozmiarze zerowym jest przesyłany do `write_volatile`) są nieudane i mogą być ignorowane.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `dst` musi być [valid] do zapisu.
///
/// * `dst` muszą być odpowiednio wyrównane.
///
/// Zauważ, że nawet jeśli `T` ma rozmiar `0`, wskaźnik musi być różny od NULL i odpowiednio wyrównany.
///
/// [valid]: self#safety
///
/// Podobnie jak w C, to, czy operacja jest niestabilna, nie ma żadnego wpływu na pytania dotyczące równoczesnego dostępu z wielu wątków.Dostęp zmienny zachowuje się pod tym względem dokładnie tak samo, jak dostępy nieatomowe.
///
/// W szczególności wyścig między `write_volatile` a jakąkolwiek inną operacją (odczyt lub zapis) w tej samej lokalizacji jest niezdefiniowanym zachowaniem.
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Nie panikuj, by zmniejszyć wpływ codegen.
        abort();
    }
    // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Wyrównaj wskaźnik `p`.
///
/// Oblicz przesunięcie (w kategoriach elementów kroku `stride`), które należy zastosować do wskaźnika `p`, aby wskaźnik `p` został wyrównany do `a`.
///
/// Note: Ta implementacja została starannie dostosowana, aby nie panic.To jest UB dla tego do panic.
/// Jedyną prawdziwą zmianą, jaką można tu wprowadzić, jest zmiana `INV_TABLE_MOD_16` i powiązanych stałych.
///
/// Jeśli kiedykolwiek zdecydujemy się umożliwić wywoływanie tego, co jest nieodłączne w `a`, które nie jest potęgą dwóch, prawdopodobnie rozsądniej będzie po prostu zmienić implementację na naiwną, zamiast próbować dostosować ją, aby dostosować się do tej zmiany.
///
///
/// Wszelkie pytania kieruj do@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Bezpośrednie użycie tych elementów wewnętrznych znacznie poprawia kodowanie na poziomie opt-level <=
    // 1, gdzie wersje metod tych operacji nie są wstawione.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Oblicz multiplikatywną modularną odwrotność `x` modulo `m`.
    ///
    /// Ta implementacja jest dostosowana do `align_offset` i ma następujące warunki wstępne:
    ///
    /// * `m` jest potęgą dwóch;
    /// * `x < m`; (jeśli `x ≥ m`, zamiast tego podaj `x % m`)
    ///
    /// Realizacja tej funkcji nie panic.Zawsze.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikatywna modularna tablica odwrotna modulo 2⁴=16.
        ///
        /// Zwróć uwagę, że ta tabela nie zawiera wartości, w przypadku których odwrotność nie istnieje (tj. Dla `0⁻¹ mod 16`, `2⁻¹ mod 16` itp.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo, do którego przeznaczony jest `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // BEZPIECZEŃSTWO: `m` musi być potęgą dwójki, a więc niezerową.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Iterujemy "up" za pomocą następującego wzoru:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // aż do 2²ⁿ ≥ m.Następnie możemy zredukować do naszego pożądanego `m`, biorąc wynik `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Zauważ, że celowo używamy tutaj operacji zawijania-oryginalna formuła używa np. Odejmowania `mod n`.
                // Całkowicie w porządku jest zamiast tego zrobić je `mod usize::MAX`, ponieważ i tak bierzemy wynik `mod n` na końcu.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // BEZPIECZEŃSTWO: `a` to potęga dwójki, a więc niezerowa.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` przypadek można obliczyć w prostszy sposób za pomocą `-p (mod a)`, ale takie postępowanie ogranicza zdolność LLVM do wybierania instrukcji, takich jak `lea`.Zamiast tego obliczamy
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // który rozdziela operacje wokół nośnika, ale wystarczająco pesymizując `and`, aby LLVM mógł wykorzystać różne optymalizacje, o których wie.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Już wyrównane.Yay!
        return 0;
    } else if stride == 0 {
        // Jeśli wskaźnik nie jest wyrównany, a element ma rozmiar zerowy, żadna liczba elementów nigdy nie wyrówna wskaźnika.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // BEZPIECZEŃSTWO: a jest potęgą dwójki, a więc niezerową.stride==0 sprawa jest opisana powyżej.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // BEZPIECZEŃSTWO: gcdpow ma górną granicę, która jest najwyżej liczbą bitów w usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // BEZPIECZEŃSTWO: gcd jest zawsze większe lub równe 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Ten branch rozwiązuje następujące liniowe równanie kongruencji:
        //
        // ` p + so = 0 mod a `
        //
        // `p` tutaj jest wartość wskaźnika, `s`, krok `T`, przesunięcie `o` w `T`s i `a`, żądane wyrównanie.
        //
        // Mając `g = gcd(a, s)` i powyższy warunek stwierdzający, że `p` jest również podzielny przez `g`, możemy oznaczyć `a' = a/g`, `s' = s/g`, `p' = p/g`, wtedy staje się to równoważne z:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Pierwszy składnik to "the relative alignment of `p` to `a`" (podzielony przez `g`), drugi składnik to "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (ponownie podzielony przez `g`).
        //
        // Dzielenie przez `g` jest konieczne, aby odwrotność była dobrze utworzona, jeśli `a` i `s` nie są równoległe.
        //
        // Ponadto wynik uzyskany przez to rozwiązanie nie jest "minimal", więc konieczne jest przyjęcie wyniku `o mod lcm(s, a)`.Możemy zastąpić `lcm(s, a)` tylko `a'`.
        //
        //
        //
        //
        //

        // BEZPIECZEŃSTWO: `gcdpow` ma górną granicę nie większą niż liczba końcowych 0-bitów w `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // BEZPIECZEŃSTWO: `a2` jest niezerowe.Przesunięcie `a` przez `gcdpow` nie może przesunąć żadnego z ustawionych bitów
        // w `a` (z których ma dokładnie jeden).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // BEZPIECZEŃSTWO: `gcdpow` ma górną granicę nie większą niż liczba końcowych 0-bitów w `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // BEZPIECZEŃSTWO: `gcdpow` ma górną granicę nie większą niż liczba końcowych 0-bitów w
        // `a`.
        // Ponadto odejmowanie nie może się przepełnić, ponieważ `a2 = a >> gcdpow` zawsze będzie ściśle większe niż `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // BEZPIECZEŃSTWO: `a2` to potęga dwóch, jak udowodniono powyżej.`s2` jest ściśle mniejsze niż `a2`
        // ponieważ `(s % a) >> gcdpow` jest ściśle mniejszy niż `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // W ogóle nie można wyrównać.
    usize::MAX
}

/// Porównuje surowe wskaźniki równości.
///
/// To jest to samo, co użycie operatora `==`, ale mniej ogólne:
/// argumenty muszą być surowymi wskaźnikami `*const T`, a nie niczym, co implementuje `PartialEq`.
///
/// Można to wykorzystać do porównania odwołań `&T` (które pośrednio wymuszają na `*const T`) według ich adresu, zamiast porównywać wartości, na które wskazują (co robi implementacja `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Plastry są również porównywane według ich długości (wskaźniki tłuszczu):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits są również porównywane poprzez ich implementację:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Wskaźniki mają równe adresy.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Obiekty mają równe adresy, ale `Trait` ma różne implementacje.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Konwersja odwołania do `*const u8` porównuje według adresu.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash nieprzetworzony wskaźnik.
///
/// Może to służyć do haszowania odwołania `&T` (które pośrednio wymusza na `*const T`) na podstawie jego adresu, a nie wartości, na którą wskazuje (co jest tym, co robi implementacja `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls dla wskaźników funkcji
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Dla AVR wymagany jest odlew pośredni jako usize
                // tak, że przestrzeń adresowa wskaźnika funkcji źródłowej jest zachowana w końcowym wskaźniku funkcji.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Dla AVR wymagany jest odlew pośredni jako usize
                // tak, że przestrzeń adresowa wskaźnika funkcji źródłowej jest zachowana w końcowym wskaźniku funkcji.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Brak funkcji wariadycznych z 0 parametrami
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Utwórz nieprzetworzony wskaźnik `const` do miejsca bez tworzenia pośredniego odniesienia.
///
/// Tworzenie odwołania za pomocą `&`/`&mut` jest dozwolone tylko wtedy, gdy wskaźnik jest prawidłowo wyrównany i wskazuje na zainicjowane dane.
/// W przypadkach, w których te wymagania nie są spełnione, należy zamiast tego użyć wskaźników surowych.
/// Jednak `&expr as *const _` tworzy odniesienie przed rzutowaniem go na surowy wskaźnik, a odniesienie to podlega tym samym regułom, co wszystkie inne odwołania.
///
/// To makro może utworzyć nieprzetworzony wskaźnik *bez* tworzenia najpierw odniesienia.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` stworzy niewyrównane odniesienie, a tym samym będzie niezdefiniowanym zachowaniem!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Utwórz nieprzetworzony wskaźnik `mut` do miejsca bez tworzenia pośredniego odniesienia.
///
/// Tworzenie odwołania za pomocą `&`/`&mut` jest dozwolone tylko wtedy, gdy wskaźnik jest prawidłowo wyrównany i wskazuje na zainicjowane dane.
/// W przypadkach, w których te wymagania nie są spełnione, należy zamiast tego użyć wskaźników surowych.
/// Jednak `&mut expr as *mut _` tworzy odniesienie przed rzutowaniem go na surowy wskaźnik, a odniesienie to podlega tym samym regułom, co wszystkie inne odwołania.
///
/// To makro może utworzyć nieprzetworzony wskaźnik *bez* tworzenia najpierw odniesienia.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` stworzy niewyrównane odniesienie, a tym samym będzie niezdefiniowanym zachowaniem!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` wymusza kopiowanie pola zamiast tworzenia odniesienia.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}