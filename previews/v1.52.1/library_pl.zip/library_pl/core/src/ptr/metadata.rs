#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Udostępnia typ metadanych wskaźnika dowolnego typu wskazanego.
///
/// # Metadane wskaźnika
///
/// Surowe typy wskaźników i typy referencyjne w Rust można traktować jako złożone z dwóch części:
/// wskaźnik danych zawierający adres pamięci wartości i niektóre metadane.
///
/// W przypadku typów o rozmiarze statycznym (które implementują `Sized` traits), a także w przypadku typów `extern`, mówi się, że wskaźniki są " cienkie`: metadane mają rozmiar zerowy, a ich typ to `()`.
///
///
/// Wskaźniki do [dynamically-sized types][dst] są określane jako " szerokie`lub " grube`, mają metadane o rozmiarze różnym od zera:
///
/// * W przypadku struktur, których ostatnim polem jest czas letni, metadane to metadane ostatniego pola
/// * W przypadku typu `str` metadane to długość w bajtach `usize`
/// * W przypadku typów wycinków, takich jak `[T]`, metadane to długość elementów równa `usize`
/// * W przypadku obiektów trait, takich jak `dyn SomeTrait`, metadane to [`DynMetadata<Self>`][DynMetadata] (np. `DynMetadata<dyn SomeTrait>`)
///
/// W future język Rust może zyskać nowe rodzaje typów, które mają różne metadane wskaźników.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Celem tego trait jest jego typ powiązany z `Metadata`, którym jest `()` lub `usize` lub `DynMetadata<_>`, jak opisano powyżej.
/// Jest automatycznie wdrażany dla każdego typu.
/// Można założyć, że zostanie zaimplementowany w kontekście ogólnym, nawet bez odpowiedniego ograniczenia.
///
/// # Usage
///
/// Surowe wskaźniki można rozłożyć na adres danych i składniki metadanych za pomocą metody [`to_raw_parts`].
///
/// Alternatywnie, same metadane można wyodrębnić za pomocą funkcji [`metadata`].
/// Odwołanie może zostać przekazane do [`metadata`] i niejawnie wymuszone.
///
/// Wskaźnik (possibly-wide) można złożyć z powrotem na podstawie jego adresu i metadanych za pomocą [`from_raw_parts`] lub [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Typ metadanych we wskaźnikach i odwołaniach do `Self`.
    #[lang = "metadata_type"]
    // NOTE: Zachowaj trait bounds w `static_assert_expected_bounds_for_metadata`
    //
    // w `library/core/src/ptr/metadata.rs` zsynchronizowany z tymi tutaj:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Wskaźniki do typów implementujących ten alias trait są " cienkie`.
///
/// Obejmuje to statyczne typy " Sized` i typy `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: nie ustabilizować tego, zanim aliasy trait staną się stabilne w języku?
pub trait Thin = Pointee<Metadata = ()>;

/// Wyodrębnij składnik metadanych wskaźnika.
///
/// Wartości typu `*mut T`, `&T` lub `&mut T` mogą być przekazywane bezpośrednio do tej funkcji, ponieważ niejawnie przekształcają się w `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // BEZPIECZEŃSTWO: Dostęp do wartości z unii `PtrRepr` jest bezpieczny, ponieważ * const T
    // i PtrComponents<T>mają te same układy pamięci.
    // Tylko std może dać tę gwarancję.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Tworzy nieprzetworzony wskaźnik (possibly-wide) na podstawie adresu danych i metadanych.
///
/// Ta funkcja jest bezpieczna, ale zwracany wskaźnik niekoniecznie jest bezpieczny do wyłuskiwania.
/// W przypadku plasterków zapoznaj się z dokumentacją [`slice::from_raw_parts`], aby poznać wymagania dotyczące bezpieczeństwa.
/// W przypadku obiektów trait metadane muszą pochodzić ze wskaźnika do tego samego podstawowego typu ereased.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // BEZPIECZEŃSTWO: Dostęp do wartości z unii `PtrRepr` jest bezpieczny, ponieważ * const T
    // i PtrComponents<T>mają te same układy pamięci.
    // Tylko std może dać tę gwarancję.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Wykonuje tę samą funkcjonalność co [`from_raw_parts`], z tą różnicą, że zwracany jest surowy wskaźnik `*mut`, w przeciwieństwie do surowego wskaźnika `* const`.
///
///
/// Więcej informacji można znaleźć w dokumentacji [`from_raw_parts`].
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // BEZPIECZEŃSTWO: Dostęp do wartości z unii `PtrRepr` jest bezpieczny, ponieważ * const T
    // i PtrComponents<T>mają te same układy pamięci.
    // Tylko std może dać tę gwarancję.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Ręczny impl potrzebny, aby uniknąć wiązania `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Ręczny impl potrzebny, aby uniknąć wiązania `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadane dla typu obiektu `Dyn = dyn SomeTrait` trait.
///
/// Jest to wskaźnik do tabeli vtable (wirtualnej tablicy wywołań), która reprezentuje wszystkie informacje niezbędne do manipulowania konkretnym typem przechowywanym w obiekcie trait.
/// Tabela zawiera w szczególności:
///
/// * rozmiar typu
/// * wyrównanie typu
/// * wskaźnik do implantu `drop_in_place` typu (może nie być opcją dla zwykłych starych danych)
/// * wskazuje na wszystkie metody implementacji typu trait
///
/// Zauważ, że pierwsze trzy są specjalne, ponieważ są niezbędne do przydzielania, usuwania i zwalniania dowolnego obiektu trait.
///
/// Możliwe jest nazwanie tej struktury parametrem typu, który nie jest obiektem `dyn` trait (na przykład `DynMetadata<u64>`), ale nie można uzyskać znaczącej wartości tej struktury.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Wspólny przedrostek wszystkich vtables.Po nim znajdują się wskaźniki funkcji dla metod trait.
///
/// Szczegóły prywatnej implementacji `DynMetadata::size_of` itp.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Zwraca rozmiar typu skojarzonego z tą tabelą vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Zwraca wyrównanie typu skojarzonego z tą tabelą vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Zwraca rozmiar i wyrównanie razem jako `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // BEZPIECZEŃSTWO: kompilator wyemitował tę tabelę dla konkretnego typu Rust, który
        // wiadomo, że ma prawidłowy układ.To samo uzasadnienie, co w `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Ręczne implikacje potrzebne do uniknięcia ograniczeń `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}