use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Opakowanie wokół surowego niezerowego `*mut T`, które wskazuje, że właściciel tego opakowania jest właścicielem desygnatu.
/// Przydatne do tworzenia abstrakcji, takich jak `Box<T>`, `Vec<T>`, `String` i `HashMap<K, V>`.
///
/// W przeciwieństwie do `*mut T`, `Unique<T>` zachowuje się "as if", to była instancja `T`.
/// Implementuje `Send`/`Sync`, jeśli `T` to `Send`/`Sync`.
/// Implikuje również rodzaj silnego aliasingu, który gwarantuje wystąpienie `T`:
/// desygnator wskaźnika nie powinien być modyfikowany bez unikalnej ścieżki do jego posiadacza Unique.
///
/// Jeśli nie masz pewności, czy poprawnie używać `Unique` do swoich celów, rozważ użycie `NonNull`, który ma słabszą semantykę.
///
///
/// W przeciwieństwie do `*mut T`, wskaźnik musi zawsze mieć wartość różną od null, nawet jeśli wskaźnik nigdy nie jest wyłuskiwany.
/// Dzieje się tak, aby wyliczenia mogły używać tej niedozwolonej wartości jako dyskryminatora-`Option<Unique<T>>` ma taki sam rozmiar jak `Unique<T>`.
/// Jednak wskaźnik może nadal zwisać, jeśli nie jest wyłuskany.
///
/// W przeciwieństwie do `*mut T`, `Unique<T>` jest kowariantny względem `T`.
/// Powinno to zawsze być poprawne dla każdego typu, który spełnia wymagania dotyczące aliasingu Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ten znacznik nie ma konsekwencji dla wariancji, ale jest konieczny
    // aby dropck zrozumiał, że logicznie posiadamy `T`.
    //
    // Aby uzyskać szczegółowe informacje, zobacz:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` wskaźniki to `Send`, jeśli `T` to `Send`, ponieważ dane, do których się odnoszą, nie mają przypisanej wartości.
/// Zauważ, że ten niezmiennik aliasingu nie jest wymuszany przez system typów;abstrakcja używająca `Unique` musi to wymusić.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` wskaźniki to `Sync`, jeśli `T` to `Sync`, ponieważ dane, do których się odnoszą, nie mają przypisanej wartości.
/// Zauważ, że ten niezmiennik aliasingu nie jest wymuszany przez system typów;abstrakcja używająca `Unique` musi to wymusić.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Tworzy nowy `Unique`, który zwisa, ale jest dobrze wyrównany.
    ///
    /// Jest to przydatne do inicjowania typów, które leniwie alokują, tak jak robi to `Vec::new`.
    ///
    /// Zauważ, że wartość wskaźnika może potencjalnie reprezentować prawidłowy wskaźnik do `T`, co oznacza, że nie może być używana jako wartość wartownicza "not yet initialized".
    /// Typy, które leniwie alokują, muszą śledzić inicjalizację w inny sposób.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // BEZPIECZEŃSTWO: mem::align_of() zwraca prawidłowy, niezerowy wskaźnik.Plik
        // warunki wywołania new_unchecked() są w ten sposób przestrzegane.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Tworzy nowy `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` musi mieć wartość różną od null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `ptr` nie jest zerowy.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Tworzy nowy `Unique`, jeśli `ptr` ma wartość różną od null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // BEZPIECZEŃSTWO: Wskaźnik został już sprawdzony i nie jest pusty.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Uzyskuje bazowy wskaźnik `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Wybiera zawartość.
    ///
    /// Wynikowy czas życia jest związany z sobą, więc zachowuje się "as if", w rzeczywistości była to instancja T, która jest pożyczana.
    /// Jeśli wymagana jest dłuższa żywotność (unbound), użyj `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` spełnia wszystkie wymagania
        // wymagania dotyczące odniesienia.
        unsafe { &*self.as_ptr() }
    }

    /// Bezsprzecznie usuwa odwołanie do treści.
    ///
    /// Wynikowy czas życia jest związany z sobą, więc zachowuje się "as if", w rzeczywistości była to instancja T, która jest pożyczana.
    /// Jeśli wymagana jest dłuższa żywotność (unbound), użyj `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` spełnia wszystkie wymagania
        // wymagania dotyczące zmiennego odniesienia.
        unsafe { &mut *self.as_ptr() }
    }

    /// Rzuca na wskaźnik innego typu.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // BEZPIECZEŃSTWO: Unique::new_unchecked() tworzy nową wyjątkowość i potrzeby
        // podany wskaźnik nie ma wartości NULL.
        // Ponieważ przekazujemy siebie jako wskaźnik, nie może być zerowe.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // BEZPIECZEŃSTWO: Zmienne odniesienie nie może mieć wartości NULL
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}