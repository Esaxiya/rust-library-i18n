use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ale niezerowe i kowariantne.
///
/// Często jest to właściwe rozwiązanie podczas budowania struktur danych przy użyciu surowych wskaźników, ale ostatecznie jest bardziej niebezpieczne ze względu na dodatkowe właściwości.Jeśli nie jesteś pewien, czy powinieneś używać `NonNull<T>`, po prostu użyj `*mut T`!
///
/// W przeciwieństwie do `*mut T`, wskaźnik musi zawsze mieć wartość różną od null, nawet jeśli wskaźnik nigdy nie jest wyłuskiwany.Dzieje się tak, aby wyliczenia mogły używać tej niedozwolonej wartości jako dyskryminatora-`Option<NonNull<T>>` ma taki sam rozmiar jak `* mut T`.
/// Jednak wskaźnik może nadal zwisać, jeśli nie jest wyłuskany.
///
/// W przeciwieństwie do `*mut T`, `NonNull<T>` został wybrany jako kowariantny względem `T`.Umożliwia to użycie `NonNull<T>` podczas budowania typów kowariantnych, ale wprowadza ryzyko nieuzasadnienia, jeśli zostanie użyty w typie, który w rzeczywistości nie powinien być kowariantny.
/// (W przypadku `*mut T` dokonano wyboru odwrotnego, mimo że z technicznego punktu widzenia problem mógł być spowodowany jedynie wywołaniem niebezpiecznych funkcji).
///
/// Kowariancja jest poprawna dla większości bezpiecznych abstrakcji, takich jak `Box`, `Rc`, `Arc`, `Vec` i `LinkedList`.Dzieje się tak, ponieważ zapewniają one publiczny interfejs API, który jest zgodny ze zwykłymi współdzielonymi regułami mutowalności XOR Rust.
///
/// Jeśli twój typ nie może być bezpiecznie kowariantny, musisz upewnić się, że zawiera dodatkowe pole, aby zapewnić niezmienność.Często to pole będzie typu [`PhantomData`], np. `PhantomData<Cell<T>>` lub `PhantomData<&'a mut T>`.
///
/// Zauważ, że `NonNull<T>` ma instancję `From` dla `&T`.Nie zmienia to jednak faktu, że mutowanie przez (wskaźnik pochodzący z a) współdzielonego odwołania jest niezdefiniowanym zachowaniem, chyba że mutacja zachodzi wewnątrz [`UnsafeCell<T>`].To samo dotyczy tworzenia zmiennego odniesienia ze współdzielonego odniesienia.
///
/// Używając tej instancji `From` bez `UnsafeCell<T>`, Twoim obowiązkiem jest upewnienie się, że `as_mut` nie jest nigdy wywoływany, a `as_ptr` nigdy nie jest używany do mutacji.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` wskaźniki nie są `Send`, ponieważ dane, do których się odnoszą, mogą mieć aliasy.
// Uwaga, ten plik impl jest niepotrzebny, ale powinien zapewnić lepsze komunikaty o błędach.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` wskaźniki nie są `Sync`, ponieważ dane, do których się odnoszą, mogą mieć aliasy.
// Uwaga, ten plik impl jest niepotrzebny, ale powinien zapewnić lepsze komunikaty o błędach.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Tworzy nowy `NonNull`, który zwisa, ale jest dobrze wyrównany.
    ///
    /// Jest to przydatne do inicjowania typów, które leniwie alokują, tak jak robi to `Vec::new`.
    ///
    /// Zauważ, że wartość wskaźnika może potencjalnie reprezentować prawidłowy wskaźnik do `T`, co oznacza, że nie może być używana jako wartość wartownicza "not yet initialized".
    /// Typy, które leniwie alokują, muszą śledzić inicjalizację w inny sposób.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // BEZPIECZEŃSTWO: mem::align_of() zwraca niezerowe użycie, które jest następnie rzutowane
        // do * mut T.
        // Dlatego `ptr` nie jest zerowy i spełnione są warunki wywołania new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Zwraca wspólne odwołania do wartości.W przeciwieństwie do [`as_ref`] nie wymaga to inicjalizacji wartości.
    ///
    /// Zmienny odpowiednik, patrz [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że spełnione są wszystkie poniższe warunki:
    ///
    /// * Wskaźnik musi być odpowiednio wyrównany.
    ///
    /// * Musi to być "dereferencable" w sensie określonym w [the module documentation].
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///
    ///   W szczególności, w czasie trwania tego życia, pamięć wskazywana przez wskaźnik nie może zostać zmutowana (z wyjątkiem wewnątrz `UnsafeCell`).
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` spełnia wszystkie wymagania
        // wymagania dotyczące odniesienia.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Zwraca unikalne odniesienia do wartości.W przeciwieństwie do [`as_mut`] nie wymaga to inicjalizacji wartości.
    ///
    /// Udostępniony odpowiednik, patrz [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że spełnione są wszystkie poniższe warunki:
    ///
    /// * Wskaźnik musi być odpowiednio wyrównany.
    ///
    /// * Musi to być "dereferencable" w sensie określonym w [the module documentation].
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///
    ///   W szczególności, przez cały czas trwania tego życia, pamięć, na którą wskazuje wskaźnik, nie może być dostępna (odczytywana ani zapisywana) przez żaden inny wskaźnik.
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` spełnia wszystkie wymagania
        // wymagania dotyczące odniesienia.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Tworzy nowy `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` musi mieć wartość różną od null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `ptr` nie jest zerowy.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Tworzy nowy `NonNull`, jeśli `ptr` ma wartość różną od null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // BEZPIECZEŃSTWO: Wskaźnik jest już sprawdzony i nie jest zerowy
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Wykonuje tę samą funkcjonalność co [`std::ptr::from_raw_parts`], z tą różnicą, że zwracany jest wskaźnik `NonNull`, w przeciwieństwie do surowego wskaźnika `*const`.
    ///
    ///
    /// Więcej informacji można znaleźć w dokumentacji [`std::ptr::from_raw_parts`].
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // BEZPIECZEŃSTWO: Wynik `ptr::from::raw_parts_mut` jest różny od zera, ponieważ `data_address` jest.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Zdekomponuj (możliwie szeroki) wskaźnik na komponenty adresu i metadanych.
    ///
    /// Wskaźnik można później zrekonstruować za pomocą [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Uzyskuje bazowy wskaźnik `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Zwraca udostępnione odniesienie do wartości.Jeśli wartość może być niezainicjowana, należy zamiast tego użyć [`as_uninit_ref`].
    ///
    /// Zmienny odpowiednik, patrz [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że spełnione są wszystkie poniższe warunki:
    ///
    /// * Wskaźnik musi być odpowiednio wyrównany.
    ///
    /// * Musi to być "dereferencable" w sensie określonym w [the module documentation].
    ///
    /// * Wskaźnik musi wskazywać na zainicjowaną instancję `T`.
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///
    ///   W szczególności, w czasie trwania tego życia, pamięć wskazywana przez wskaźnik nie może zostać zmutowana (z wyjątkiem wewnątrz `UnsafeCell`).
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    /// (Część dotycząca inicjalizacji nie jest jeszcze w pełni ustalona, ale dopóki tak się nie stanie, jedynym bezpiecznym podejściem jest upewnienie się, że są one rzeczywiście zainicjowane).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` spełnia wszystkie wymagania
        // wymagania dotyczące odniesienia.
        unsafe { &*self.as_ptr() }
    }

    /// Zwraca unikalne odniesienie do wartości.Jeśli wartość może być niezainicjowana, należy zamiast tego użyć [`as_uninit_mut`].
    ///
    /// Udostępniony odpowiednik, patrz [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że spełnione są wszystkie poniższe warunki:
    ///
    /// * Wskaźnik musi być odpowiednio wyrównany.
    ///
    /// * Musi to być "dereferencable" w sensie określonym w [the module documentation].
    ///
    /// * Wskaźnik musi wskazywać na zainicjowaną instancję `T`.
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///
    ///   W szczególności, przez cały czas trwania tego życia, pamięć, na którą wskazuje wskaźnik, nie może być dostępna (odczytywana ani zapisywana) przez żaden inny wskaźnik.
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    /// (Część dotycząca inicjalizacji nie jest jeszcze w pełni ustalona, ale dopóki tak się nie stanie, jedynym bezpiecznym podejściem jest upewnienie się, że są one rzeczywiście zainicjowane).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` spełnia wszystkie wymagania
        // wymagania dotyczące zmiennego odniesienia.
        unsafe { &mut *self.as_ptr() }
    }

    /// Rzuca na wskaźnik innego typu.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // BEZPIECZEŃSTWO: `self` jest wskaźnikiem `NonNull`, który z konieczności musi mieć wartość różną od null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Tworzy niezerowy nieprzetworzony plasterek z cienkiego wskaźnika i długości.
    ///
    /// Argument `len` to liczba **elementów**, a nie liczba bajtów.
    ///
    /// Ta funkcja jest bezpieczna, ale wyłuskiwanie wartości zwracanej jest niebezpieczne.
    /// Zapoznaj się z dokumentacją [`slice::from_raw_parts`], aby zapoznać się z wymaganiami dotyczącymi bezpieczeństwa plasterków.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // utwórz wskaźnik plasterka, zaczynając od wskaźnika do pierwszego elementu
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Zauważ, że ten przykład sztucznie demonstruje użycie tej metody, ale `niech slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // BEZPIECZEŃSTWO: `data` jest wskaźnikiem `NonNull`, który musi mieć wartość różną od zerowej
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Zwraca długość niezerowego surowego wycinka.
    ///
    /// Zwracana wartość to liczba **elementów**, a nie liczba bajtów.
    ///
    /// Ta funkcja jest bezpieczna, nawet jeśli wycinek nieprzetworzony bez wartości zerowej nie może być dereferencjonowany do wycinka, ponieważ wskaźnik nie ma prawidłowego adresu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Zwraca niezerowy wskaźnik do bufora wycinka.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // BEZPIECZEŃSTWO: wiemy, że `self` nie jest zerowe.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Zwraca surowy wskaźnik do bufora wycinka.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Zwraca udostępnione odniesienie do wycinka potencjalnie niezainicjowanych wartości.W przeciwieństwie do [`as_ref`] nie wymaga to inicjalizacji wartości.
    ///
    /// Zmienny odpowiednik, patrz [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że spełnione są wszystkie poniższe warunki:
    ///
    /// * Wskaźnik musi mieć wartość [valid] dla odczytów `ptr.len() * mem::size_of::<T>()` wiele bajtów i musi być odpowiednio wyrównany.Oznacza to w szczególności:
    ///
    ///     * Cały zakres pamięci tego wycinka musi być zawarty w jednym przydzielonym obiekcie!
    ///       Plasterki nigdy nie mogą obejmować wielu przydzielonych obiektów.
    ///
    ///     * Wskaźnik musi być wyrównany nawet w przypadku plasterków o zerowej długości.
    ///     Jednym z powodów jest to, że optymalizacje układu wyliczenia mogą polegać na odniesieniach (w tym wycinkach o dowolnej długości), które są wyrównane i niezerowe, aby odróżnić je od innych danych.
    ///
    ///     Możesz uzyskać wskaźnik, który jest używany jako `data` dla wycinków o zerowej długości przy użyciu [`NonNull::dangling()`].
    ///
    /// * Całkowity rozmiar `ptr.len() * mem::size_of::<T>()` wycinka nie może być większy niż `isize::MAX`.
    ///   Zobacz dokumentację dotyczącą bezpieczeństwa [`pointer::offset`].
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///   W szczególności, w czasie trwania tego życia, pamięć wskazywana przez wskaźnik nie może zostać zmutowana (z wyjątkiem wewnątrz `UnsafeCell`).
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    ///
    /// Zobacz także [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Zwraca unikalne odniesienie do wycinka potencjalnie niezainicjowanych wartości.W przeciwieństwie do [`as_mut`] nie wymaga to inicjalizacji wartości.
    ///
    /// Udostępniony odpowiednik, patrz [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że spełnione są wszystkie poniższe warunki:
    ///
    /// * Wskaźnik musi mieć wartość [valid] dla odczytów i zapisów dla wielu bajtów `ptr.len() * mem::size_of::<T>()` i musi być odpowiednio wyrównany.Oznacza to w szczególności:
    ///
    ///     * Cały zakres pamięci tego wycinka musi być zawarty w jednym przydzielonym obiekcie!
    ///       Plasterki nigdy nie mogą obejmować wielu przydzielonych obiektów.
    ///
    ///     * Wskaźnik musi być wyrównany nawet w przypadku plasterków o zerowej długości.
    ///     Jednym z powodów jest to, że optymalizacje układu wyliczenia mogą polegać na odniesieniach (w tym wycinkach o dowolnej długości), które są wyrównane i niezerowe, aby odróżnić je od innych danych.
    ///
    ///     Możesz uzyskać wskaźnik, który jest używany jako `data` dla wycinków o zerowej długości przy użyciu [`NonNull::dangling()`].
    ///
    /// * Całkowity rozmiar `ptr.len() * mem::size_of::<T>()` wycinka nie może być większy niż `isize::MAX`.
    ///   Zobacz dokumentację dotyczącą bezpieczeństwa [`pointer::offset`].
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///   W szczególności, przez cały czas trwania tego życia, pamięć, na którą wskazuje wskaźnik, nie może być dostępna (odczytywana ani zapisywana) przez żaden inny wskaźnik.
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    ///
    /// Zobacz także [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Jest to bezpieczne, ponieważ `memory` obsługuje odczyty i zapisy dla wielu bajtów `memory.len()`.
    /// // Zauważ, że wywoływanie `memory.as_mut()` jest tutaj niedozwolone, ponieważ zawartość może być niezainicjowana.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Zwraca nieprzetworzony wskaźnik do elementu lub elementu podrzędnego, bez sprawdzania granic.
    ///
    /// Wywołanie tej metody z indeksem spoza zakresu lub gdy `self` nie daje możliwości wyłuskiwania jest *[niezdefiniowane zachowanie]*, nawet jeśli wynikowy wskaźnik nie jest używany.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // BEZPIECZEŃSTWO: dzwoniący zapewnia, że `self` jest dereferencjonowalny, a `index` w granicach.
        // W konsekwencji wynikowy wskaźnik nie może mieć wartości NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // BEZPIECZEŃSTWO: Unikalny wskaźnik nie może być zerowy, więc warunki dla
        // new_unchecked() są szanowani.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // BEZPIECZEŃSTWO: Zmienne odniesienie nie może mieć wartości NULL.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // BEZPIECZEŃSTWO: odwołanie nie może być zerowe, więc warunki dla
        // new_unchecked() są szanowani.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}