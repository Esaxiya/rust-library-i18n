use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Zwraca `true`, jeśli wskaźnik ma wartość null.
    ///
    /// Zwróć uwagę, że typy bez rozmiaru mają wiele możliwych wskaźników zerowych, ponieważ brany jest pod uwagę tylko wskaźnik surowych danych, a nie ich długość, tabela vtable itp.
    /// Dlatego dwa wskaźniki, które są zerowe, mogą nadal nie być ze sobą równe.
    ///
    /// ## Zachowanie podczas oceny const
    ///
    /// Gdy ta funkcja jest używana podczas szacowania const, może zwracać `false` dla wskaźników, które okazują się być puste w czasie wykonywania.
    /// W szczególności, gdy wskaźnik do jakiejś pamięci jest przesunięty poza swoje granice w taki sposób, że wynikowy wskaźnik jest pusty, funkcja nadal zwraca `false`.
    ///
    /// Nie ma sposobu, aby CTFE poznał bezwzględną pozycję tej pamięci, więc nie możemy stwierdzić, czy wskaźnik jest pusty, czy nie.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Porównaj rzutowanie z cienkim wskaźnikiem, więc grube wskaźniki biorą pod uwagę tylko ich część "data" pod kątem zerowej wartości.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Rzuca na wskaźnik innego typu.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Zdekomponuj (możliwie szeroki) wskaźnik na komponenty adresu i metadanych.
    ///
    /// Wskaźnik można później zrekonstruować za pomocą [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Zwraca `None`, jeśli wskaźnik ma wartość null, lub zwraca wspólne odwołanie do wartości opakowanej w `Some`.Jeśli wartość może być niezainicjowana, należy zamiast tego użyć [`as_uninit_ref`].
    ///
    /// Zmienny odpowiednik, patrz [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że *albo* wskaźnik ma wartość NULL *lub* wszystkie poniższe są prawdziwe:
    ///
    /// * Wskaźnik musi być odpowiednio wyrównany.
    ///
    /// * Musi to być "dereferencable" w sensie określonym w [the module documentation].
    ///
    /// * Wskaźnik musi wskazywać na zainicjowaną instancję `T`.
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///   W szczególności, w czasie trwania tego życia, pamięć wskazywana przez wskaźnik nie może zostać zmutowana (z wyjątkiem wewnątrz `UnsafeCell`).
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    /// (Część dotycząca inicjalizacji nie jest jeszcze w pełni ustalona, ale dopóki tak się nie stanie, jedynym bezpiecznym podejściem jest upewnienie się, że są one rzeczywiście zainicjowane).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Wersja niezaznaczona
    ///
    /// Jeśli jesteś pewien, że wskaźnik nigdy nie może być zerowy i szukasz jakiegoś `as_ref_unchecked`, który zwraca `&T` zamiast `Option<&T>`, wiedz, że możesz bezpośrednio wyłuskać wskaźnik.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` jest ważny dla
        // odniesienie, jeśli nie jest null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Zwraca `None`, jeśli wskaźnik ma wartość null, lub zwraca wspólne odwołanie do wartości opakowanej w `Some`.
    /// W przeciwieństwie do [`as_ref`] nie wymaga to inicjalizacji wartości.
    ///
    /// Zmienny odpowiednik, patrz [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że *albo* wskaźnik ma wartość NULL *lub* wszystkie poniższe są prawdziwe:
    ///
    /// * Wskaźnik musi być odpowiednio wyrównany.
    ///
    /// * Musi to być "dereferencable" w sensie określonym w [the module documentation].
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///
    ///   W szczególności, w czasie trwania tego życia, pamięć wskazywana przez wskaźnik nie może zostać zmutowana (z wyjątkiem wewnątrz `UnsafeCell`).
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` spełnia wszystkie wymagania
        // wymagania dotyczące odniesienia.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Oblicza przesunięcie na podstawie wskaźnika.
    ///
    /// `count` jest w jednostkach T;np. `count` o wartości 3 oznacza przesunięcie wskaźnika o `3 * size_of::<T>()` bajtów.
    ///
    /// # Safety
    ///
    /// Jeśli którykolwiek z poniższych warunków zostanie naruszony, wynikiem jest Niezdefiniowane zachowanie:
    ///
    /// * Zarówno początkowy, jak i wynikowy wskaźnik muszą znajdować się w granicach lub jeden bajt za końcem tego samego przydzielonego obiektu.
    /// Zauważ, że w Rust każda zmienna (stack-allocated) jest uważana za oddzielny przydzielony obiekt.
    ///
    /// * Obliczone przesunięcie,**w bajtach**, nie może przepełnić `isize`.
    ///
    /// * Przesunięcie w granicach nie może polegać na "wrapping around" przestrzeni adresowej.Oznacza to, że suma o nieskończonej precyzji,**w bajtach**, musi zmieścić się w usize.
    ///
    /// Kompilator i biblioteka standardowa zazwyczaj starają się zapewnić, że alokacje nigdy nie osiągną rozmiaru, w którym przesunięcie jest problemem.
    /// Na przykład `Vec` i `Box` zapewniają, że nigdy nie przydzielą więcej niż `isize::MAX` bajtów, więc `vec.as_ptr().add(vec.len())` jest zawsze bezpieczny.
    ///
    /// Większość platform zasadniczo nie może nawet skonstruować takiej alokacji.
    /// Na przykład żadna ze znanych platform 64-bitowych nie może obsłużyć żądania o 2 <sup>63</sup> bajty z powodu ograniczeń tablicy stron lub podziału przestrzeni adresowej.
    /// Jednak niektóre platformy 32-bitowe i 16-bitowe mogą z powodzeniem obsługiwać żądania dotyczące więcej niż `isize::MAX` bajtów za pomocą takich rzeczy, jak rozszerzenie adresu fizycznego.
    ///
    /// W związku z tym pamięć uzyskana bezpośrednio z alokatorów lub plików mapowanych w pamięci *może* być zbyt duża, aby obsłużyć tę funkcję.
    ///
    /// Zamiast tego rozważ użycie [`wrapping_offset`], jeśli te ograniczenia są trudne do spełnienia.
    /// Jedyną zaletą tej metody jest to, że umożliwia ona bardziej agresywne optymalizacje kompilatora.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `offset`.
        // Uzyskany wskaźnik jest ważny dla zapisów, ponieważ wywołujący musi zagwarantować, że wskazuje na ten sam przydzielony obiekt co `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Oblicza przesunięcie ze wskaźnika przy użyciu arytmetyki zawijania.
    /// `count` jest w jednostkach T;np. `count` o wartości 3 oznacza przesunięcie wskaźnika o `3 * size_of::<T>()` bajtów.
    ///
    /// # Safety
    ///
    /// Ta operacja sama w sobie jest zawsze bezpieczna, ale użycie wynikowego wskaźnika już nie.
    ///
    /// Wynikowy wskaźnik pozostaje dołączony do tego samego przydzielonego obiektu, na który wskazuje `self`.
    /// Może *nie* być używany do uzyskania dostępu do innego przydzielonego obiektu.Zauważ, że w Rust każda zmienna (stack-allocated) jest uważana za oddzielny przydzielony obiekt.
    ///
    /// Innymi słowy, `let z = x.wrapping_offset((y as isize) - (x as isize))`*nie* sprawia, że `z` jest taki sam jak `y`, nawet jeśli założymy, że `T` ma rozmiar `1` i nie ma przepełnienia: `z` jest nadal dołączony do obiektu, do którego jest dołączony `x`, a dereferencja jest niezdefiniowanym zachowaniem, chyba że `x` i `y` wskazuje na ten sam przydzielony obiekt.
    ///
    /// W porównaniu do [`offset`], ta metoda zasadniczo opóźnia wymóg przebywania w tym samym przydzielonym obiekcie: [`offset`] jest natychmiastowym niezdefiniowanym zachowaniem podczas przekraczania granic obiektu;`wrapping_offset` generuje wskaźnik, ale nadal prowadzi do niezdefiniowanego zachowania, jeśli wskaźnik jest wyłuskiwany, gdy znajduje się poza granicami obiektu, do którego jest dołączony.
    /// [`offset`] może być lepiej zoptymalizowany i dlatego jest preferowany w kodzie wrażliwym na wydajność.
    ///
    /// Opóźnione sprawdzenie bierze pod uwagę tylko wartość wskaźnika, który został wyłuskany, a nie wartości pośrednie używane podczas obliczania wyniku końcowego.
    /// Na przykład `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` jest zawsze taki sam jak `x`.Innymi słowy, pozostawienie przydzielonego obiektu i ponowne wejście do niego później jest dozwolone.
    ///
    /// Jeśli chcesz przekroczyć granice obiektu, rzuć wskaźnik na liczbę całkowitą i wykonaj tam arytmetykę.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // Iteruj używając surowego wskaźnika w przyrostach co dwa elementy
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: `arith_offset` wewnętrzny nie ma żadnych wymagań wstępnych, aby go wywołać.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Zwraca `None`, jeśli wskaźnik ma wartość null, lub zwraca unikalne odwołanie do wartości opakowanej w `Some`.Jeśli wartość może być niezainicjowana, należy zamiast tego użyć [`as_uninit_mut`].
    ///
    /// Udostępniony odpowiednik, patrz [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że *albo* wskaźnik ma wartość NULL *lub* wszystkie poniższe są prawdziwe:
    ///
    /// * Wskaźnik musi być odpowiednio wyrównany.
    ///
    /// * Musi to być "dereferencable" w sensie określonym w [the module documentation].
    ///
    /// * Wskaźnik musi wskazywać na zainicjowaną instancję `T`.
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///   W szczególności, przez cały czas trwania tego życia, pamięć, na którą wskazuje wskaźnik, nie może być dostępna (odczytywana ani zapisywana) przez żaden inny wskaźnik.
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    /// (Część dotycząca inicjalizacji nie jest jeszcze w pełni ustalona, ale dopóki tak się nie stanie, jedynym bezpiecznym podejściem jest upewnienie się, że są one rzeczywiście zainicjowane).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Wydrukuje: "[4, 2, 3]".
    /// ```
    ///
    /// # Wersja niezaznaczona
    ///
    /// Jeśli jesteś pewien, że wskaźnik nigdy nie może być zerowy i szukasz jakiegoś `as_mut_unchecked`, który zwraca `&mut T` zamiast `Option<&mut T>`, wiedz, że możesz bezpośrednio wyłuskać wskaźnik.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Wydrukuje: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` będzie ważny przez
        // zmienne odniesienie, jeśli nie jest puste.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Zwraca `None`, jeśli wskaźnik ma wartość null, lub zwraca unikalne odwołanie do wartości opakowanej w `Some`.
    /// W przeciwieństwie do [`as_mut`] nie wymaga to inicjalizacji wartości.
    ///
    /// Udostępniony odpowiednik, patrz [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że *albo* wskaźnik ma wartość NULL *lub* wszystkie poniższe są prawdziwe:
    ///
    /// * Wskaźnik musi być odpowiednio wyrównany.
    ///
    /// * Musi to być "dereferencable" w sensie określonym w [the module documentation].
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///
    ///   W szczególności, przez cały czas trwania tego życia, pamięć, na którą wskazuje wskaźnik, nie może być dostępna (odczytywana ani zapisywana) przez żaden inny wskaźnik.
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `self` spełnia wszystkie wymagania
        // wymagania dotyczące odniesienia.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Zwraca czy dwa wskaźniki są równe.
    ///
    /// W czasie wykonywania ta funkcja zachowuje się jak `self == other`.
    /// Jednak w niektórych kontekstach (np. Ocena w czasie kompilacji) nie zawsze jest możliwe określenie równości dwóch wskaźników, więc ta funkcja może fałszywie zwrócić `false` dla wskaźników, które później faktycznie okazują się równe.
    ///
    /// Ale kiedy zwraca `true`, wskaźniki są równe.
    ///
    /// Ta funkcja jest zwierciadłem [`guaranteed_ne`], ale nie jest jej odwrotnością.Istnieją porównania wskaźników, dla których obie funkcje zwracają `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Wartość zwracana może się zmieniać w zależności od wersji kompilatora, a niebezpieczny kod może nie polegać na wyniku tej funkcji pod względem poprawności.
    /// Zaleca się używanie tej funkcji tylko do optymalizacji wydajności, gdzie fałszywe wartości zwracane przez `false` przez tę funkcję nie wpływają na wynik, ale tylko na wydajność.
    /// Konsekwencje użycia tej metody w celu zmiany zachowania kodu w czasie wykonywania i kompilacji nie zostały zbadane.
    /// Tej metody nie należy stosować do wprowadzania takich różnic, nie należy też jej stabilizować, zanim lepiej zrozumiemy tę kwestię.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Zwraca informację, czy dwa wskaźniki są nierówne.
    ///
    /// W czasie wykonywania ta funkcja zachowuje się jak `self != other`.
    /// Jednak w niektórych kontekstach (np. Ocena w czasie kompilacji) nie zawsze jest możliwe określenie nierówności dwóch wskaźników, więc ta funkcja może fałszywie zwrócić `false` dla wskaźników, które później faktycznie okazują się nierówne.
    ///
    /// Ale kiedy zwraca `true`, wskaźniki są nierówne.
    ///
    /// Ta funkcja jest zwierciadłem [`guaranteed_eq`], ale nie jest jej odwrotnością.Istnieją porównania wskaźników, dla których obie funkcje zwracają `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Wartość zwracana może się zmieniać w zależności od wersji kompilatora, a niebezpieczny kod może nie polegać na wyniku tej funkcji pod względem poprawności.
    /// Zaleca się używanie tej funkcji tylko do optymalizacji wydajności, gdzie fałszywe wartości zwracane przez `false` przez tę funkcję nie wpływają na wynik, ale tylko na wydajność.
    /// Konsekwencje użycia tej metody w celu zmiany zachowania kodu w czasie wykonywania i kompilacji nie zostały zbadane.
    /// Tej metody nie należy stosować do wprowadzania takich różnic, nie należy też jej stabilizować, zanim lepiej zrozumiemy tę kwestię.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Oblicza odległość między dwoma wskaźnikami.Zwracana wartość jest w jednostkach T: odległość w bajtach jest dzielona przez `mem::size_of::<T>()`.
    ///
    /// Ta funkcja jest odwrotnością [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Jeśli którykolwiek z poniższych warunków zostanie naruszony, wynikiem jest Niezdefiniowane zachowanie:
    ///
    /// * Zarówno początkowy, jak i drugi wskaźnik muszą znajdować się w granicach lub jeden bajt za końcem tego samego przydzielonego obiektu.
    /// Zauważ, że w Rust każda zmienna (stack-allocated) jest uważana za oddzielny przydzielony obiekt.
    ///
    /// * Oba wskaźniki muszą *pochodzić od* wskaźnika do tego samego obiektu.
    ///   (Zobacz przykład poniżej).
    ///
    /// * Odległość między wskaźnikami w bajtach musi być dokładną wielokrotnością rozmiaru `T`.
    ///
    /// * Odległość między wskaźnikami,**w bajtach**, nie może przekroczyć `isize`.
    ///
    /// * Odległość znajdująca się w granicach nie może polegać na "wrapping around" przestrzeni adresowej.
    ///
    /// Typy Rust nigdy nie są większe niż `isize::MAX`, a alokacje Rust nigdy nie zawijają się wokół przestrzeni adresowej, więc dwa wskaźniki w obrębie jakiejś wartości dowolnego typu Rust `T` zawsze spełniają dwa ostatnie warunki.
    ///
    /// Biblioteka standardowa zapewnia również, że alokacje nigdy nie osiągną rozmiaru, w którym przesunięcie jest problemem.
    /// Na przykład `Vec` i `Box` zapewniają, że nigdy nie przydzielą więcej bajtów niż `isize::MAX`, więc `ptr_into_vec.offset_from(vec.as_ptr())` zawsze spełnia dwa ostatnie warunki.
    ///
    /// Większość platform zasadniczo nie może nawet zbudować tak dużej alokacji.
    /// Na przykład żadna ze znanych platform 64-bitowych nie może obsłużyć żądania o 2 <sup>63</sup> bajty z powodu ograniczeń tablicy stron lub podziału przestrzeni adresowej.
    /// Jednak niektóre platformy 32-bitowe i 16-bitowe mogą z powodzeniem obsługiwać żądania dotyczące więcej niż `isize::MAX` bajtów za pomocą takich rzeczy, jak rozszerzenie adresu fizycznego.
    /// W związku z tym pamięć uzyskana bezpośrednio z alokatorów lub plików mapowanych w pamięci *może* być zbyt duża, aby obsłużyć tę funkcję.
    /// (Należy zauważyć, że [`offset`] i [`add`] również mają podobne ograniczenie i dlatego nie mogą być również używane w tak dużych alokacjach).
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ta funkcja panics, jeśli `T` to typ ("ZST") o zerowym rozmiarze.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Nieprawidłowe* użycie:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Uczyń ptr2_other "alias" z ptr2, ale wyprowadzonym z ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ponieważ ptr2_other i ptr2 są wyprowadzane ze wskaźników do różnych obiektów, obliczanie ich przesunięcia jest niezdefiniowanym zachowaniem, nawet jeśli wskazują na ten sam adres!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Niezdefiniowane zachowanie
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Oblicza przesunięcie na podstawie wskaźnika (wygoda dla `.offset(count as isize)`).
    ///
    /// `count` jest w jednostkach T;np. `count` o wartości 3 oznacza przesunięcie wskaźnika o `3 * size_of::<T>()` bajtów.
    ///
    /// # Safety
    ///
    /// Jeśli którykolwiek z poniższych warunków zostanie naruszony, wynikiem jest Niezdefiniowane zachowanie:
    ///
    /// * Zarówno początkowy, jak i wynikowy wskaźnik muszą znajdować się w granicach lub jeden bajt za końcem tego samego przydzielonego obiektu.
    /// Zauważ, że w Rust każda zmienna (stack-allocated) jest uważana za oddzielny przydzielony obiekt.
    ///
    /// * Obliczone przesunięcie,**w bajtach**, nie może przepełnić `isize`.
    ///
    /// * Przesunięcie w granicach nie może polegać na "wrapping around" przestrzeni adresowej.Oznacza to, że suma o nieskończonej precyzji musi zmieścić się w `usize`.
    ///
    /// Kompilator i biblioteka standardowa zazwyczaj starają się zapewnić, że alokacje nigdy nie osiągną rozmiaru, w którym przesunięcie jest problemem.
    /// Na przykład `Vec` i `Box` zapewniają, że nigdy nie przydzielą więcej niż `isize::MAX` bajtów, więc `vec.as_ptr().add(vec.len())` jest zawsze bezpieczny.
    ///
    /// Większość platform zasadniczo nie może nawet skonstruować takiej alokacji.
    /// Na przykład żadna ze znanych platform 64-bitowych nie może obsłużyć żądania o 2 <sup>63</sup> bajty z powodu ograniczeń tablicy stron lub podziału przestrzeni adresowej.
    /// Jednak niektóre platformy 32-bitowe i 16-bitowe mogą z powodzeniem obsługiwać żądania dotyczące więcej niż `isize::MAX` bajtów za pomocą takich rzeczy, jak rozszerzenie adresu fizycznego.
    ///
    /// W związku z tym pamięć uzyskana bezpośrednio z alokatorów lub plików mapowanych w pamięci *może* być zbyt duża, aby obsłużyć tę funkcję.
    ///
    /// Zamiast tego rozważ użycie [`wrapping_add`], jeśli te ograniczenia są trudne do spełnienia.
    /// Jedyną zaletą tej metody jest to, że umożliwia ona bardziej agresywne optymalizacje kompilatora.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Oblicza przesunięcie ze wskaźnika (wygoda dla `.offset ((licz jako isize).wrapping_neg())`).
    ///
    /// `count` jest w jednostkach T;np. `count` o wartości 3 oznacza przesunięcie wskaźnika o `3 * size_of::<T>()` bajtów.
    ///
    /// # Safety
    ///
    /// Jeśli którykolwiek z poniższych warunków zostanie naruszony, wynikiem jest Niezdefiniowane zachowanie:
    ///
    /// * Zarówno początkowy, jak i wynikowy wskaźnik muszą znajdować się w granicach lub jeden bajt za końcem tego samego przydzielonego obiektu.
    /// Zauważ, że w Rust każda zmienna (stack-allocated) jest uważana za oddzielny przydzielony obiekt.
    ///
    /// * Obliczone przesunięcie nie może przekraczać `isize::MAX`**bajtów**.
    ///
    /// * Przesunięcie w granicach nie może polegać na "wrapping around" przestrzeni adresowej.Oznacza to, że nieskończenie precyzyjna suma musi zmieścić się w usize.
    ///
    /// Kompilator i biblioteka standardowa zazwyczaj starają się zapewnić, że alokacje nigdy nie osiągną rozmiaru, w którym przesunięcie jest problemem.
    /// Na przykład `Vec` i `Box` zapewniają, że nigdy nie przydzielą więcej niż `isize::MAX` bajtów, więc `vec.as_ptr().add(vec.len()).sub(vec.len())` jest zawsze bezpieczny.
    ///
    /// Większość platform zasadniczo nie może nawet skonstruować takiej alokacji.
    /// Na przykład żadna ze znanych platform 64-bitowych nie może obsłużyć żądania o 2 <sup>63</sup> bajty z powodu ograniczeń tablicy stron lub podziału przestrzeni adresowej.
    /// Jednak niektóre platformy 32-bitowe i 16-bitowe mogą z powodzeniem obsługiwać żądania dotyczące więcej niż `isize::MAX` bajtów za pomocą takich rzeczy, jak rozszerzenie adresu fizycznego.
    ///
    /// W związku z tym pamięć uzyskana bezpośrednio z alokatorów lub plików mapowanych w pamięci *może* być zbyt duża, aby obsłużyć tę funkcję.
    ///
    /// Zamiast tego rozważ użycie [`wrapping_sub`], jeśli te ograniczenia są trudne do spełnienia.
    /// Jedyną zaletą tej metody jest to, że umożliwia ona bardziej agresywne optymalizacje kompilatora.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Oblicza przesunięcie ze wskaźnika przy użyciu arytmetyki zawijania.
    /// (wygoda dla `.wrapping_offset(count as isize)`)
    ///
    /// `count` jest w jednostkach T;np. `count` o wartości 3 oznacza przesunięcie wskaźnika o `3 * size_of::<T>()` bajtów.
    ///
    /// # Safety
    ///
    /// Ta operacja sama w sobie jest zawsze bezpieczna, ale użycie wynikowego wskaźnika już nie.
    ///
    /// Wynikowy wskaźnik pozostaje dołączony do tego samego przydzielonego obiektu, na który wskazuje `self`.
    /// Może *nie* być używany do uzyskania dostępu do innego przydzielonego obiektu.Zauważ, że w Rust każda zmienna (stack-allocated) jest uważana za oddzielny przydzielony obiekt.
    ///
    /// Innymi słowy, `let z = x.wrapping_add((y as usize) - (x as usize))`*nie* sprawia, że `z` jest taki sam jak `y`, nawet jeśli założymy, że `T` ma rozmiar `1` i nie ma przepełnienia: `z` jest nadal dołączony do obiektu, do którego jest dołączony `x`, a wyłuskiwanie jest niezdefiniowane, chyba że `x` i `y` wskazuje na ten sam przydzielony obiekt.
    ///
    /// W porównaniu do [`add`], ta metoda zasadniczo opóźnia wymóg przebywania w tym samym przydzielonym obiekcie: [`add`] jest natychmiastowym niezdefiniowanym zachowaniem podczas przekraczania granic obiektu;`wrapping_add` generuje wskaźnik, ale nadal prowadzi do niezdefiniowanego zachowania, jeśli wskaźnik jest wyłuskiwany, gdy znajduje się poza granicami obiektu, do którego jest dołączony.
    /// [`add`] może być lepiej zoptymalizowany i dlatego jest preferowany w kodzie wrażliwym na wydajność.
    ///
    /// Opóźnione sprawdzenie bierze pod uwagę tylko wartość wskaźnika, który został wyłuskany, a nie wartości pośrednie używane podczas obliczania wyniku końcowego.
    /// Na przykład `x.wrapping_add(o).wrapping_sub(o)` jest zawsze taki sam jak `x`.Innymi słowy, pozostawienie przydzielonego obiektu i ponowne wejście do niego później jest dozwolone.
    ///
    /// Jeśli chcesz przekroczyć granice obiektu, rzuć wskaźnik na liczbę całkowitą i wykonaj tam arytmetykę.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // Iteruj używając surowego wskaźnika w przyrostach co dwa elementy
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ta pętla drukuje "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Oblicza przesunięcie ze wskaźnika przy użyciu arytmetyki zawijania.
    /// (wygoda dla `.wrapping_offset ((liczone jako isize).wrapping_neg())`)
    ///
    /// `count` jest w jednostkach T;np. `count` o wartości 3 oznacza przesunięcie wskaźnika o `3 * size_of::<T>()` bajtów.
    ///
    /// # Safety
    ///
    /// Ta operacja sama w sobie jest zawsze bezpieczna, ale użycie wynikowego wskaźnika już nie.
    ///
    /// Wynikowy wskaźnik pozostaje dołączony do tego samego przydzielonego obiektu, na który wskazuje `self`.
    /// Może *nie* być używany do uzyskania dostępu do innego przydzielonego obiektu.Zauważ, że w Rust każda zmienna (stack-allocated) jest uważana za oddzielny przydzielony obiekt.
    ///
    /// Innymi słowy, `let z = x.wrapping_sub((x as usize) - (y as usize))`*nie* sprawia, że `z` jest taki sam jak `y`, nawet jeśli założymy, że `T` ma rozmiar `1` i nie ma przepełnienia: `z` jest nadal dołączony do obiektu, do którego jest dołączony `x`, a dereferencja jest niezdefiniowanym zachowaniem, chyba że `x` i `y` wskazuje na ten sam przydzielony obiekt.
    ///
    /// W porównaniu do [`sub`], ta metoda zasadniczo opóźnia wymóg przebywania w tym samym przydzielonym obiekcie: [`sub`] jest natychmiastowym niezdefiniowanym zachowaniem podczas przekraczania granic obiektu;`wrapping_sub` generuje wskaźnik, ale nadal prowadzi do niezdefiniowanego zachowania, jeśli wskaźnik jest wyłuskiwany, gdy znajduje się poza granicami obiektu, do którego jest dołączony.
    /// [`sub`] może być lepiej zoptymalizowany i dlatego jest preferowany w kodzie wrażliwym na wydajność.
    ///
    /// Opóźnione sprawdzenie bierze pod uwagę tylko wartość wskaźnika, który został wyłuskany, a nie wartości pośrednie używane podczas obliczania wyniku końcowego.
    /// Na przykład `x.wrapping_add(o).wrapping_sub(o)` jest zawsze taki sam jak `x`.Innymi słowy, pozostawienie przydzielonego obiektu i ponowne wejście do niego później jest dozwolone.
    ///
    /// Jeśli chcesz przekroczyć granice obiektu, rzuć wskaźnik na liczbę całkowitą i wykonaj tam arytmetykę.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // Iteruj używając surowego wskaźnika w przyrostach dwóch elementów (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ta pętla drukuje "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Ustawia wartość wskaźnika na `ptr`.
    ///
    /// W przypadku, gdy `self` jest wskaźnikiem (fat) do typu bez rozmiaru, ta operacja wpłynie tylko na część wskaźnika, podczas gdy w przypadku wskaźników (thin) do typów o rozmiarze ma to taki sam efekt, jak proste przypisanie.
    ///
    /// Wynikowy wskaźnik będzie miał pochodzenie `val`, tj. Dla wskaźnika tłuszczu operacja ta jest semantycznie taka sama, jak tworzenie nowego wskaźnika tłuszczu z wartością wskaźnika danych `val`, ale metadanymi `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ta funkcja jest przede wszystkim przydatna do zezwalania na arytmetykę wskaźników bajtowych na potencjalnie grubych wskaźnikach:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // wydrukuje "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // BEZPIECZEŃSTWO: W przypadku cienkiej wskazówki operacje te są identyczne
        // do prostego zadania.
        // W przypadku fat pointer, przy aktualnej implementacji fat pointer layout, pierwszym polem takiego wskaźnika jest zawsze wskaźnik danych, który jest podobnie przypisany.
        //
        unsafe { *thin = val };
        self
    }

    /// Odczytuje wartość z `self` bez jej przenoszenia.
    /// Pozostawia to pamięć w `self` bez zmian.
    ///
    /// Zobacz [`ptr::read`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla ``.
        unsafe { read(self) }
    }

    /// Dokonuje ulotnego odczytu wartości z `self` bez jej przenoszenia.Pozostawia to pamięć w `self` bez zmian.
    ///
    /// Operacje ulotne mają działać na pamięci I/O i gwarantuje, że kompilator nie usunie ich ani nie zmieni ich kolejności w innych operacjach ulotnych.
    ///
    ///
    /// Zobacz [`ptr::read_volatile`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Odczytuje wartość z `self` bez jej przenoszenia.
    /// Pozostawia to pamięć w `self` bez zmian.
    ///
    /// W przeciwieństwie do `read`, wskaźnik może być niewyrównany.
    ///
    /// Zobacz [`ptr::read_unaligned`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopiuje bajty `count * size_of<T>` z `self` do `dest`.
    /// Źródło i miejsce docelowe mogą się pokrywać.
    ///
    /// NOTE: ma *taką samą* kolejność argumentów jak [`ptr::copy`].
    ///
    /// Zobacz [`ptr::copy`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopiuje bajty `count * size_of<T>` z `self` do `dest`.
    /// Źródło i miejsce docelowe mogą *nie* zachodzić na siebie.
    ///
    /// NOTE: ma *taką samą* kolejność argumentów jak [`ptr::copy_nonoverlapping`].
    ///
    /// Zobacz [`ptr::copy_nonoverlapping`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kopiuje bajty `count * size_of<T>` z `src` do `self`.
    /// Źródło i miejsce docelowe mogą się pokrywać.
    ///
    /// NOTE: ma to *przeciwną* kolejność argumentów [`ptr::copy`].
    ///
    /// Zobacz [`ptr::copy`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Kopiuje bajty `count * size_of<T>` z `src` do `self`.
    /// Źródło i miejsce docelowe mogą *nie* zachodzić na siebie.
    ///
    /// NOTE: ma to *przeciwną* kolejność argumentów [`ptr::copy_nonoverlapping`].
    ///
    /// Zobacz [`ptr::copy_nonoverlapping`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Wykonuje destruktor (jeśli istnieje) wskazanej wartości.
    ///
    /// Zobacz [`ptr::drop_in_place`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Zastępuje lokalizację pamięci podaną wartością bez odczytywania lub upuszczania starej wartości.
    ///
    ///
    /// Zobacz [`ptr::write`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `write`.
        unsafe { write(self, val) }
    }

    /// Wywołuje memset na określonym wskaźniku, ustawiając `count * size_of::<T>()` bajtów pamięci, zaczynając od `self` do `val`.
    ///
    ///
    /// Zobacz [`ptr::write_bytes`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Wykonuje ulotny zapis lokalizacji pamięci z podaną wartością bez odczytywania lub porzucania starej wartości.
    ///
    /// Operacje ulotne mają działać na pamięci I/O i gwarantuje, że kompilator nie usunie ich ani nie zmieni ich kolejności w innych operacjach ulotnych.
    ///
    ///
    /// Zobacz [`ptr::write_volatile`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Zastępuje lokalizację pamięci podaną wartością bez odczytywania lub upuszczania starej wartości.
    ///
    ///
    /// W przeciwieństwie do `write`, wskaźnik może być niewyrównany.
    ///
    /// Zobacz [`ptr::write_unaligned`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Zastępuje wartość w `self` przez `src`, zwracając starą wartość, nie pomijając żadnej z nich.
    ///
    ///
    /// Zobacz [`ptr::replace`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `replace`.
        unsafe { replace(self, src) }
    }

    /// Zamienia wartości w dwóch zmiennych lokalizacjach tego samego typu, również bez deinicjalizacji.
    /// W przeciwieństwie do `mem::swap`, który jest równoważny, mogą się na siebie nakładać.
    ///
    /// Zobacz [`ptr::swap`], aby zapoznać się z kwestiami bezpieczeństwa i przykładami.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `swap`.
        unsafe { swap(self, with) }
    }

    /// Oblicza przesunięcie, które należy zastosować do wskaźnika, aby dopasować go do `align`.
    ///
    /// Jeśli wyrównanie wskaźnika nie jest możliwe, implementacja zwraca `usize::MAX`.
    /// Dopuszczalne jest, aby implementacja *zawsze* zwracała `usize::MAX`.
    /// Tylko wydajność algorytmu może zależeć od uzyskania użytecznego przesunięcia, a nie od jego poprawności.
    ///
    /// Przesunięcie jest wyrażane w liczbie elementów `T`, a nie w bajtach.Zwracana wartość może być używana z metodą `wrapping_add`.
    ///
    /// Nie ma żadnej gwarancji, że przesunięcie wskaźnika nie spowoduje przepełnienia ani przekroczenia alokacji, na którą wskazuje wskaźnik.
    ///
    /// Do wywołującego należy upewnienie się, że zwrócone przesunięcie jest poprawne we wszystkich warunkach poza wyrównaniem.
    ///
    /// # Panics
    ///
    /// Funkcja panics, jeśli `align` nie jest potęgą dwóch.
    ///
    /// # Examples
    ///
    /// Dostęp do sąsiedniego `u8` jako `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // podczas gdy wskaźnik można wyrównać za pomocą `offset`, wskazywałby on poza alokacją
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // BEZPIECZEŃSTWO: `align` został sprawdzony jako potęga 2 powyżej
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Zwraca długość surowego wycinka.
    ///
    /// Zwracana wartość to liczba **elementów**, a nie liczba bajtów.
    ///
    /// Ta funkcja jest bezpieczna, nawet jeśli surowego wycinka nie można rzutować na odniesienie do wycinka, ponieważ wskaźnik ma wartość null lub jest niewyrównany.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // BEZPIECZEŃSTWO: jest to bezpieczne, ponieważ `*const [T]` i `FatPtr<T>` mają ten sam układ.
            // Tylko `std` może udzielić takiej gwarancji.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Zwraca surowy wskaźnik do bufora wycinka.
    ///
    /// Jest to równoważne z rzutowaniem `self` na `*mut T`, ale bardziej bezpieczne dla typów.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Zwraca nieprzetworzony wskaźnik do elementu lub elementu podrzędnego, bez sprawdzania granic.
    ///
    /// Wywołanie tej metody z indeksem spoza zakresu lub gdy `self` nie daje możliwości wyłuskiwania jest *[niezdefiniowane zachowanie]*, nawet jeśli wynikowy wskaźnik nie jest używany.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // BEZPIECZEŃSTWO: dzwoniący zapewnia, że `self` jest dereferencjonowalny, a `index` w granicach.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Zwraca `None`, jeśli wskaźnik ma wartość null, lub zwraca udostępniony wycinek do wartości opakowanej w `Some`.
    /// W przeciwieństwie do [`as_ref`] nie wymaga to inicjalizacji wartości.
    ///
    /// Zmienny odpowiednik, patrz [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że *albo* wskaźnik ma wartość NULL *lub* wszystkie poniższe są prawdziwe:
    ///
    /// * Wskaźnik musi mieć wartość [valid] dla odczytów `ptr.len() * mem::size_of::<T>()` wiele bajtów i musi być odpowiednio wyrównany.Oznacza to w szczególności:
    ///
    ///     * Cały zakres pamięci tego wycinka musi być zawarty w jednym przydzielonym obiekcie!
    ///       Plasterki nigdy nie mogą obejmować wielu przydzielonych obiektów.
    ///
    ///     * Wskaźnik musi być wyrównany nawet w przypadku plasterków o zerowej długości.
    ///     Jednym z powodów jest to, że optymalizacje układu wyliczenia mogą polegać na odniesieniach (w tym wycinkach o dowolnej długości), które są wyrównane i niezerowe, aby odróżnić je od innych danych.
    ///
    ///     Możesz uzyskać wskaźnik, który jest używany jako `data` dla wycinków o zerowej długości przy użyciu [`NonNull::dangling()`].
    ///
    /// * Całkowity rozmiar `ptr.len() * mem::size_of::<T>()` wycinka nie może być większy niż `isize::MAX`.
    ///   Zobacz dokumentację dotyczącą bezpieczeństwa [`pointer::offset`].
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///   W szczególności, w czasie trwania tego życia, pamięć wskazywana przez wskaźnik nie może zostać zmutowana (z wyjątkiem wewnątrz `UnsafeCell`).
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    ///
    /// Zobacz także [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Zwraca `None`, jeśli wskaźnik ma wartość null, lub zwraca unikalny wycinek do wartości opakowanej w `Some`.
    /// W przeciwieństwie do [`as_mut`] nie wymaga to inicjalizacji wartości.
    ///
    /// Udostępniony odpowiednik, patrz [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Wywołując tę metodę, musisz upewnić się, że *albo* wskaźnik ma wartość NULL *lub* wszystkie poniższe są prawdziwe:
    ///
    /// * Wskaźnik musi mieć wartość [valid] dla odczytów i zapisów dla wielu bajtów `ptr.len() * mem::size_of::<T>()` i musi być odpowiednio wyrównany.Oznacza to w szczególności:
    ///
    ///     * Cały zakres pamięci tego wycinka musi być zawarty w jednym przydzielonym obiekcie!
    ///       Plasterki nigdy nie mogą obejmować wielu przydzielonych obiektów.
    ///
    ///     * Wskaźnik musi być wyrównany nawet w przypadku plasterków o zerowej długości.
    ///     Jednym z powodów jest to, że optymalizacje układu wyliczenia mogą polegać na odniesieniach (w tym wycinkach o dowolnej długości), które są wyrównane i niezerowe, aby odróżnić je od innych danych.
    ///
    ///     Możesz uzyskać wskaźnik, który jest używany jako `data` dla wycinków o zerowej długości przy użyciu [`NonNull::dangling()`].
    ///
    /// * Całkowity rozmiar `ptr.len() * mem::size_of::<T>()` wycinka nie może być większy niż `isize::MAX`.
    ///   Zobacz dokumentację dotyczącą bezpieczeństwa [`pointer::offset`].
    ///
    /// * Musisz wymusić reguły aliasingu Rust, ponieważ zwrócony okres istnienia `'a` jest wybierany arbitralnie i niekoniecznie odzwierciedla faktyczny czas życia danych.
    ///   W szczególności, przez cały czas trwania tego życia, pamięć, na którą wskazuje wskaźnik, nie może być dostępna (odczytywana ani zapisywana) przez żaden inny wskaźnik.
    ///
    /// Dotyczy to również sytuacji, gdy wynik tej metody jest niewykorzystany!
    ///
    /// Zobacz także [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Równość wskaźników
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}