//! Operacje na ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Sprawdza, czy wszystkie bajty w tym wycinku mieszczą się w zakresie ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Sprawdza, czy dwa wycinki są dopasowaniem bez rozróżniania wielkości liter w kodzie ASCII.
    ///
    /// To samo co `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ale bez przydzielania i kopiowania tymczasowych.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Konwertuje ten wycinek na jego odpowiednik z wielkich liter ASCII w miejscu.
    ///
    /// Litery ASCII 'a' do 'z' są odwzorowywane na 'A' do 'Z', ale litery inne niż ASCII pozostają niezmienione.
    ///
    /// Aby zwrócić nową wartość pisaną wielkimi literami bez modyfikowania istniejącej, użyj [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Konwertuje ten wycinek na jego odpowiednik z małych liter ASCII w miejscu.
    ///
    /// Litery ASCII 'A' do 'Z' są odwzorowywane na 'a' do 'z', ale litery inne niż ASCII pozostają niezmienione.
    ///
    /// Aby zwrócić nową małą wartość bez modyfikowania istniejącej, użyj [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Zwraca `true`, jeśli którykolwiek bajt w słowie `v` jest nonascii (>=128).
/// Snarfed z `../str/mod.rs`, który robi coś podobnego dla walidacji utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Zoptymalizowany test ASCII, który będzie używał operacji typu " usize-at-a-time`zamiast operacji " bajt po czasie` (jeśli to możliwe).
///
/// Algorytm, którego tutaj używamy, jest dość prosty.Jeśli `s` jest za krótki, po prostu sprawdzamy każdy bajt i skończymy z tym.Inaczej:
///
/// - Przeczytaj pierwsze słowo z niewyrównanym ładunkiem.
/// - Wyrównaj wskaźnik, czytaj kolejne słowa do końca z wyrównanymi obciążeniami.
/// - Przeczytaj ostatnie `usize` z `s` z niewyrównanym obciążeniem.
///
/// Jeśli którekolwiek z tych obciążeń daje coś, dla którego `contains_nonascii` (above) zwraca prawdę, to wiemy, że odpowiedź jest fałszywa.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Jeśli nie uzyskalibyśmy niczego z implementacji słowo po czasie, wróć do pętli skalarnej.
    //
    // Robimy to również dla architektur, w których `size_of::<usize>()` nie jest wystarczającym wyrównaniem dla `usize`, ponieważ jest to dziwny przypadek edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Zawsze czytamy pierwsze słowo niewyrównane, co oznacza, że `align_offset` jest
    // 0, ponownie odczytalibyśmy tę samą wartość dla wyrównanego odczytu.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // BEZPIECZEŃSTWO: weryfikujemy `len < USIZE_SIZE` powyżej.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Sprawdziliśmy to powyżej, nieco pośrednio.
    // Zauważ, że `offset_to_aligned` to `align_offset` lub `USIZE_SIZE`, oba są wyraźnie zaznaczone powyżej.
    //
    debug_assert!(offset_to_aligned <= len);

    // BEZPIECZEŃSTWO: word_ptr to (odpowiednio wyrównany) ptr usize, którego używamy do czytania
    // środkowy kawałek plastra.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` jest indeksem bajtów `word_ptr`, używanym do sprawdzania końca pętli.
    let mut byte_pos = offset_to_aligned;

    // Paranoja sprawdza wyrównanie, ponieważ mamy zamiar wykonać kilka niewyrównanych ładunków.
    // W praktyce powinno to być niemożliwe, poza błędem w `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Czytaj kolejne słowa aż do ostatniego wyrównanego słowa, z wyłączeniem ostatniego wyrównanego słowa, które ma być wykonane później w sprawdzaniu ogona, aby upewnić się, że koniec jest zawsze najwyżej jednym `usize` do dodatkowego branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sprawdzenie poczytalności, czy odczyt jest w granicach
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // I to jest zgodne z naszymi przypuszczeniami dotyczącymi `byte_pos`.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // BEZPIECZEŃSTWO: wiemy, że `word_ptr` jest prawidłowo wyrównany (ponieważ
        // `align_offset`) i wiemy, że mamy wystarczająco dużo bajtów między `word_ptr` a końcem
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // BEZPIECZEŃSTWO: wiemy, że `byte_pos <= len - USIZE_SIZE`, co oznacza to
        // po tym `add` `word_ptr` będzie co najwyżej jeden po drugim.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sprawdzenie poczytalności, aby upewnić się, że został tylko jeden `usize`.
    // Powinien to gwarantować nasz warunek pętli.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // BEZPIECZEŃSTWO: To zależy od `len >= USIZE_SIZE`, który sprawdzamy na początku.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}