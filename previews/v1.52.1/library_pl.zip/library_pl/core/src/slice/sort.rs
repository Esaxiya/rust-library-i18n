//! Sortowanie plasterków
//!
//! Ten moduł zawiera algorytm sortowania oparty na szybkim sortowaniu pokonującym wzorce Orsona Petersa, opublikowanym pod adresem: <https://github.com/orlp/pdqsort>
//!
//!
//! Niestabilne sortowanie jest kompatybilne z libcore, ponieważ nie alokuje pamięci, w przeciwieństwie do naszej stabilnej implementacji sortowania.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Po upuszczeniu kopiuje z `src` do `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // BEZPIECZEŃSTWO: To jest klasa pomocnicza.
        //          Sprawdź jego użycie, aby sprawdzić poprawność.
        //          Mianowicie należy mieć pewność, że `src` i `dst` nie zachodzą na siebie, jak wymaga tego `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Przesuwa pierwszy element w prawo, aż napotka większy lub równy element.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // BEZPIECZEŃSTWO: niebezpieczne operacje opisane poniżej obejmują indeksowanie bez powiązanego sprawdzenia (`get_unchecked` i `get_unchecked_mut`)
    // i kopiowanie pamięci (`ptr::copy_nonoverlapping`).
    //
    // za.Indeksowanie:
    //  1. Sprawdziliśmy rozmiar tablicy na>=2.
    //  2. Całe indeksowanie, które zrobimy, będzie zawsze odbywać się najwyżej między {0 <= index < len}.
    //
    // b.Kopiowanie pamięci
    //  1. Uzyskujemy wskazówki do referencji, które są na pewno aktualne.
    //  2. Nie mogą się pokrywać, ponieważ otrzymujemy wskaźniki różnicujące indeksy wycinka.
    //     Mianowicie `i` i `i-1`.
    //  3. Jeśli plasterek jest odpowiednio wyrównany, elementy są odpowiednio wyrównane.
    //     Do osoby dzwoniącej należy upewnienie się, że plaster jest odpowiednio wyrównany.
    //
    // Więcej szczegółów w komentarzach poniżej.
    unsafe {
        // Jeśli pierwsze dwa elementy są niesprawne ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Wczytaj pierwszy element do zmiennej przydzielonej na stosie.
            // Jeśli następująca operacja porównania panics, `hole` zostanie usunięta i automatycznie zapisze element z powrotem do wycinka.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Przesuń `i`-ty element o jedno miejsce w lewo, przesuwając tym samym otwór w prawo.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` zostaje upuszczony, a tym samym kopiuje `tmp` do pozostałej dziury w `v`.
        }
    }
}

/// Przesuwa ostatni element w lewo, aż napotka mniejszy lub równy element.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // BEZPIECZEŃSTWO: niebezpieczne operacje opisane poniżej obejmują indeksowanie bez powiązanego sprawdzenia (`get_unchecked` i `get_unchecked_mut`)
    // i kopiowanie pamięci (`ptr::copy_nonoverlapping`).
    //
    // za.Indeksowanie:
    //  1. Sprawdziliśmy rozmiar tablicy na>=2.
    //  2. Całe indeksowanie, które zrobimy, będzie zawsze odbywać się najwyżej między `0 <= index < len-1`.
    //
    // b.Kopiowanie pamięci
    //  1. Uzyskujemy wskazówki do referencji, które są na pewno aktualne.
    //  2. Nie mogą się pokrywać, ponieważ otrzymujemy wskaźniki różnicujące indeksy wycinka.
    //     Mianowicie `i` i `i+1`.
    //  3. Jeśli plasterek jest odpowiednio wyrównany, elementy są odpowiednio wyrównane.
    //     Do osoby dzwoniącej należy upewnienie się, że plaster jest odpowiednio wyrównany.
    //
    // Więcej szczegółów w komentarzach poniżej.
    unsafe {
        // Jeśli ostatnie dwa elementy są niesprawne ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Wczytaj ostatni element do zmiennej przydzielonej na stosie.
            // Jeśli następująca operacja porównania panics, `hole` zostanie usunięta i automatycznie zapisze element z powrotem do wycinka.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Przesuń `i`-ty element o jedno miejsce w prawo, przesuwając tym samym otwór w lewo.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` zostaje upuszczony, a tym samym kopiuje `tmp` do pozostałej dziury w `v`.
        }
    }
}

/// Częściowo sortuje wycinek, przesuwając dookoła kilka niedziałających w kolejności elementów.
///
/// Zwraca `true`, jeśli wycinek jest posortowany na końcu.Ta funkcja jest *O*(*n*) w najgorszym przypadku.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maksymalna liczba przylegających par niedziałających w kolejności, które zostaną przesunięte.
    const MAX_STEPS: usize = 5;
    // Jeśli wycinek jest krótszy, nie przesuwaj żadnych elementów.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // BEZPIECZEŃSTWO: Już jawnie sprawdziliśmy wiązanie za pomocą `i < len`.
        // Całe nasze późniejsze indeksowanie dotyczy tylko zakresu `0 <= index < len`
        unsafe {
            // Znajdź następną parę sąsiednich niedziałających w kolejności elementów.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Skończyliśmy?
        if i == len {
            return true;
        }

        // Nie przesuwaj elementów w krótkich tablicach, ponieważ ma to wpływ na wydajność.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Zamień znalezioną parę elementów.To ustawia je we właściwej kolejności.
        v.swap(i - 1, i);

        // Przesuń mniejszy element w lewo.
        shift_tail(&mut v[..i], is_less);
        // Przesuń większy element w prawo.
        shift_head(&mut v[i..], is_less);
    }

    // Nie udało się posortować plasterka w ograniczonej liczbie kroków.
    false
}

/// Sortuje plasterek przy użyciu sortowania przez wstawianie, które jest *O*(*n*^ 2) w najgorszym przypadku.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sortuje `v` przy użyciu heapsort, co gwarantuje *O*(*n*\*log(* n*)) w najgorszym przypadku.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ta sterta binarna jest zgodna z niezmiennym `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Dzieci `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Wybierz większe dziecko.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Zatrzymaj się, jeśli niezmiennik utrzymuje się na poziomie `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Zamień `node` z większym dzieckiem, zejdź o jeden stopień w dół i kontynuuj przesiewanie.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Zbuduj stertę w czasie liniowym.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Zdejmuj maksymalne elementy ze sterty.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Dzieli `v` na elementy mniejsze niż `pivot`, po których następują elementy większe lub równe `pivot`.
///
///
/// Zwraca liczbę elementów mniejszą niż `pivot`.
///
/// Partycjonowanie jest wykonywane blok po bloku w celu zminimalizowania kosztów operacji rozgałęziania.
/// Idea ta została przedstawiona w artykule [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Liczba elementów w typowym bloku.
    const BLOCK: usize = 128;

    // Algorytm partycjonowania powtarza następujące kroki aż do zakończenia:
    //
    // 1. Śledź blok z lewej strony, aby zidentyfikować elementy większe lub równe osi.
    // 2. Śledź blok z prawej strony, aby zidentyfikować elementy mniejsze niż oś obrotu.
    // 3. Wymień zidentyfikowane elementy między lewą a prawą stroną.
    //
    // Zachowujemy następujące zmienne dla bloku elementów:
    //
    // 1. `block` - Liczba elementów w bloku.
    // 2. `start` - Uruchom wskaźnik do tablicy `offsets`.
    // 3. `end` - Wskaźnik końca do tablicy `offsets`.
    // 4. `przesunięcia, indeksy niedziałających elementów w bloku.

    // Bieżący blok po lewej stronie (od `l` do `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Bieżący blok po prawej stronie (od `r.sub(block_r)` to `r`).
    // BEZPIECZEŃSTWO: Dokumentacja .add() wyraźnie wspomina, że `vec.as_ptr().add(vec.len())` jest zawsze bezpieczny
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Kiedy otrzymamy VLA, spróbuj raczej utworzyć jedną tablicę o długości `min(v.len(), 2 * BLOCK) `
    // niż dwie tablice o stałym rozmiarze o długości `BLOCK`.Umowy VLA mogą być bardziej wydajne w pamięci podręcznej.

    // Zwraca liczbę elementów między wskaźnikami `l` (inclusive) i `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Skończyliśmy z partycjonowaniem blok po bloku, gdy `l` i `r` są bardzo blisko.
        // Następnie wykonujemy pewne poprawki, aby podzielić pozostałe elementy pomiędzy.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Liczba pozostałych elementów (nadal nie w porównaniu do osi).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Dostosuj rozmiary bloków tak, aby lewy i prawy blok nie zachodziły na siebie, ale zostały idealnie wyrównane, aby pokryć całą pozostałą lukę.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Śledź elementy `block_l` z lewej strony.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // BEZPIECZEŃSTWO: Poniższe niebezpieczne czynności wymagają użycia `offset`.
                //         Zgodnie z warunkami wymaganymi przez funkcję spełniamy je, ponieważ:
                //         1. `offsets_l` jest przydzielony na stosie i dlatego jest uważany za oddzielny przydzielony obiekt.
                //         2. Funkcja `is_less` zwraca `bool`.
                //            Przesyłanie `bool` nigdy nie przepełni `isize`.
                //         3. Gwarantujemy, że `block_l` będzie `<= BLOCK`.
                //            Dodatkowo `end_l` został początkowo ustawiony na wskaźnik początku `offsets_`, który został zadeklarowany na stosie.
                //            W ten sposób wiemy, że nawet w najgorszym przypadku (wszystkie wywołania `is_less` zwracają fałsz), na końcu przekroczymy najwyżej 1 bajt.
                //        Kolejną niebezpieczną operacją tutaj jest wyłuskiwanie `elem`.
                //        Jednak `elem` był początkowo wskaźnikiem początkowym do wycinka, który jest zawsze prawidłowy.
                unsafe {
                    // Bezgałęziowe porównanie.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Śledź elementy `block_r` z prawej strony.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // BEZPIECZEŃSTWO: Poniższe niebezpieczne czynności wymagają użycia `offset`.
                //         Zgodnie z warunkami wymaganymi przez funkcję spełniamy je, ponieważ:
                //         1. `offsets_r` jest przydzielony na stosie i dlatego jest uważany za oddzielny przydzielony obiekt.
                //         2. Funkcja `is_less` zwraca `bool`.
                //            Przesyłanie `bool` nigdy nie przepełni `isize`.
                //         3. Gwarantujemy, że `block_r` będzie `<= BLOCK`.
                //            Dodatkowo `end_r` został początkowo ustawiony na wskaźnik początku `offsets_`, który został zadeklarowany na stosie.
                //            W ten sposób wiemy, że nawet w najgorszym przypadku (wszystkie wywołania `is_less` zwracają prawdę), na końcu będziemy mieć co najwyżej 1 bajt.
                //        Kolejną niebezpieczną operacją tutaj jest wyłuskiwanie `elem`.
                //        Jednak `elem` był początkowo `1 *sizeof(T)` poza końcem i przed uzyskaniem do niego dostępu zmniejszamy go o `1* sizeof(T)`.
                //        Ponadto stwierdzono, że `block_r` jest mniejszy niż `BLOCK`, a zatem `elem` będzie co najwyżej wskazywał początek wycinka.
                unsafe {
                    // Bezgałęziowe porównanie.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Liczba niedziałających elementów do zamiany między lewą a prawą stroną.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Zamiast zamieniać jedną parę naraz, bardziej efektywne jest wykonanie cyklicznej permutacji.
            // Nie jest to ściśle równoważne zamianie, ale daje podobny wynik przy użyciu mniejszej liczby operacji na pamięci.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Wszystkie niedziałające elementy w lewym bloku zostały przeniesione.Przejdź do następnego bloku.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Wszystkie niedziałające elementy w prawym bloku zostały przeniesione.Przejdź do poprzedniego bloku.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Teraz pozostaje tylko co najwyżej jeden blok (lewy lub prawy) z niedziałającymi elementami, które należy przesunąć.
    // Takie pozostałe elementy można po prostu przesunąć do końca w swoim bloku.
    //

    if start_l < end_l {
        // Lewy blok pozostaje.
        // Przenieś pozostałe niedziałające w kolejności elementy maksymalnie w prawo.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Pozostaje prawy blok.
        // Przesuń pozostałe niedziałające elementy w skrajną lewą stronę.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nic więcej do zrobienia, skończyliśmy.
        width(v.as_mut_ptr(), l)
    }
}

/// Dzieli `v` na elementy mniejsze niż `v[pivot]`, po których następują elementy większe lub równe `v[pivot]`.
///
///
/// Zwraca krotkę:
///
/// 1. Liczba elementów mniejsza niż `v[pivot]`.
/// 2. Prawda, jeśli `v` był już podzielony na partycje.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Umieść oś na początku plasterka.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Wczytaj przestawienie do zmiennej przydzielonej na stosie, aby zwiększyć wydajność.
        // Jeśli następna operacja porównania panics, punkt obrotu zostanie automatycznie zapisany z powrotem do wycinka.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Znajdź pierwszą parę niedziałających elementów.
        let mut l = 0;
        let mut r = v.len();

        // BEZPIECZEŃSTWO: Poniższe zagrożenie obejmuje indeksowanie tablicy.
        // Po pierwsze: sprawdzamy już granice w `l < r`.
        // Po drugie: początkowo mamy `l == 0` i `r == v.len()` i sprawdziliśmy, czy `l < r` przy każdej operacji indeksowania.
        //                     Stąd wiemy, że `r` musi być co najmniej `r == l`, co okazało się ważne od pierwszego.
        unsafe {
            // Znajdź pierwszy element większy lub równy osi obrotu.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Znajdź ostatni element mniejszy niż oś.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` wychodzi poza zakres i zapisuje wartość przestawną (która jest zmienną przydzieloną na stosie) z powrotem do wycinka, w którym był pierwotnie.
        // Ten krok ma kluczowe znaczenie dla zapewnienia bezpieczeństwa!
        //
    };

    // Umieść trzpień między dwiema przegrodami.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Dzieli `v` na elementy równe `v[pivot]`, po których następują elementy większe niż `v[pivot]`.
///
/// Zwraca liczbę elementów równą obrotowi.
/// Zakłada się, że `v` nie zawiera elementów mniejszych niż pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Umieść oś na początku plasterka.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Wczytaj przestawienie do zmiennej przydzielonej na stosie, aby zwiększyć wydajność.
    // Jeśli następna operacja porównania panics, punkt obrotu zostanie automatycznie zapisany z powrotem do wycinka.
    // BEZPIECZEŃSTWO: Wskaźnik tutaj jest ważny, ponieważ pochodzi z odniesienia do wycinka.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Teraz podziel plasterek.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // BEZPIECZEŃSTWO: Poniższe zagrożenie obejmuje indeksowanie tablicy.
        // Po pierwsze: sprawdzamy już granice w `l < r`.
        // Po drugie: początkowo mamy `l == 0` i `r == v.len()` i sprawdziliśmy, czy `l < r` przy każdej operacji indeksowania.
        //                     Stąd wiemy, że `r` musi być co najmniej `r == l`, co okazało się ważne od pierwszego.
        unsafe {
            // Znajdź pierwszy element większy niż oś.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Znajdź ostatni element równy obrotowi.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Skończyliśmy?
            if l >= r {
                break;
            }

            // Zamień znalezioną parę niedziałających elementów.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Znaleźliśmy elementy `l` równe obrotowi.Dodaj 1, aby uwzględnić sam przestawienie.
    l + 1

    // `_pivot_guard` wychodzi poza zakres i zapisuje wartość przestawną (która jest zmienną przydzieloną na stosie) z powrotem do wycinka, w którym był pierwotnie.
    // Ten krok ma kluczowe znaczenie dla zapewnienia bezpieczeństwa!
}

/// Rozprasza niektóre elementy, próbując złamać wzorce, które mogą powodować niezrównoważone partycje w quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generator liczb pseudolosowych z artykułu "Xorshift RNGs" autorstwa George'a Marsaglii.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Weź liczby losowe modulo tę liczbę.
        // Liczba pasuje do `usize`, ponieważ `len` nie jest większe niż `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Niektórzy kandydaci na zmienne będą znajdowali się w pobliżu tego indeksu.Wybierzmy je losowo.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Wygeneruj liczbę losową modulo `len`.
            // Aby jednak uniknąć kosztownych operacji, najpierw bierzemy go modulo do potęgi dwóch, a następnie zmniejszamy o `len`, aż mieści się w zakresie `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` gwarantuje, że będzie mniejsza niż `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Wybiera punkt obrotu w `v` i zwraca indeks i `true`, jeśli wycinek jest już prawdopodobnie posortowany.
///
/// W trakcie tego procesu można zmienić kolejność elementów w `v`.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimalna długość do wyboru metody mediany.
    // W przypadku krótszych plasterków zastosowano prostą metodę mediany z trzech.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maksymalna liczba swapów, które można wykonać w tej funkcji.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Trzy indeksy, w pobliżu których będziemy wybierać pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Oblicza całkowitą liczbę swapów, które mamy zamiar wykonać podczas sortowania indeksów.
    let mut swaps = 0;

    if len >= 8 {
        // Zamienia indeksy, aby `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Zamienia indeksy, aby `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Znajduje medianę `v[a - 1], v[a], v[a + 1]` i zapisuje indeks w `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Znajdź mediany w sąsiedztwie `a`, `b` i `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Znajdź medianę wśród `a`, `b` i `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Wykonano maksymalną liczbę swapów.
        // Istnieje prawdopodobieństwo, że wycinek opada lub głównie opada, więc cofanie prawdopodobnie pomoże go szybciej posortować.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sortuje `v` rekurencyjnie.
///
/// Jeśli wycinek miał poprzednika w oryginalnej tablicy, jest określany jako `pred`.
///
/// `limit` to liczba dozwolonych niezrównoważonych partycji przed przełączeniem na `heapsort`.
/// Jeśli zero, ta funkcja natychmiast przełączy się na sortowanie stosu.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Plastry do tej długości są sortowane za pomocą sortowania przez wstawianie.
    const MAX_INSERTION: usize = 20;

    // Prawda, jeśli ostatnie partycjonowanie było rozsądnie zrównoważone.
    let mut was_balanced = true;
    // Prawda, jeśli ostatnie partycjonowanie nie pomieszało elementów (wycinek był już podzielony na partycje).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Bardzo krótkie plasterki są sortowane za pomocą sortowania przez wstawianie.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Jeśli dokonano zbyt wielu złych wyborów obrotu, po prostu wróć do heapsort, aby zagwarantować `O(n * log(n))` najgorszy przypadek.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Jeśli ostatnie partycjonowanie było niezrównoważone, spróbuj przełamać wzorce w kawałku, tasując niektóre elementy dookoła.
        // Miejmy nadzieję, że tym razem wybierzemy lepszy punkt zwrotny.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Wybierz oś i spróbuj zgadnąć, czy wycinek jest już posortowany.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Jeśli ostatnie partycjonowanie było przyzwoicie zrównoważone i nie tasowało elementów, a wybór przestawny przewiduje, że wycinek jest już prawdopodobnie posortowany ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Spróbuj zidentyfikować kilka niedziałających w kolejności elementów i przesunąć je do właściwych pozycji.
            // Jeśli kawałek zostanie całkowicie posortowany, to koniec.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Jeśli wybrany obrót jest równy poprzednikowi, jest to najmniejszy element w wycinku.
        // Podziel plasterek na elementy równe i elementy większe niż oś obrotu.
        // Ten przypadek jest zwykle trafiony, gdy plasterek zawiera wiele zduplikowanych elementów.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Kontynuuj sortowanie elementów większych niż oś.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Podziel plasterek.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Podziel plasterek na `left`, `pivot` i `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Powtarzaj tylko na krótszą stronę, aby zminimalizować całkowitą liczbę wywołań rekurencyjnych i zużywać mniej miejsca na stosie.
        // Następnie po prostu kontynuuj z dłuższym bokiem (jest to podobne do rekurencji ogona).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sortuje `v` za pomocą szybkiego sortowania pokonującego wzorce, co jest *O*(*n*\*log(* n*)) w najgorszym przypadku.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sortowanie nie ma sensownego zachowania w przypadku typów o zerowej wielkości.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Ogranicz liczbę niezrównoważonych partycji do `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // W przypadku plasterków o takiej długości prawdopodobnie szybciej je po prostu posortować.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Wybierz punkt obrotu
        let (pivot, _) = choose_pivot(v, is_less);

        // Jeśli wybrany obrót jest równy poprzednikowi, jest to najmniejszy element w wycinku.
        // Podziel plasterek na elementy równe i elementy większe niż oś obrotu.
        // Ten przypadek jest zwykle trafiony, gdy plasterek zawiera wiele zduplikowanych elementów.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Jeśli przeszliśmy nasz indeks, to jest dobrze.
                if mid > index {
                    return;
                }

                // W przeciwnym razie kontynuuj sortowanie elementów większych niż oś.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Podziel plasterek na `left`, `pivot` i `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Jeśli mid==index, to koniec, ponieważ partition() gwarantuje, że wszystkie elementy po środku są większe lub równe mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sortowanie nie ma sensownego zachowania w przypadku typów o zerowej wielkości.Nic nie robić.
    } else if index == v.len() - 1 {
        // Znajdź element max i umieść go na ostatniej pozycji tablicy.
        // Możemy tutaj używać `unwrap()`, ponieważ wiemy, że v nie może być puste.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Znajdź element min i umieść go na pierwszej pozycji tablicy.
        // Możemy tutaj używać `unwrap()`, ponieważ wiemy, że v nie może być puste.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}