//! Makra używane przez iteratory plasterka.

// Inlinowanie is_empty i len powoduje ogromną różnicę w wydajności
macro_rules! is_empty {
    // Sposób, w jaki kodujemy długość iteratora ZST, działa to zarówno dla ZST, jak i nie-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Aby pozbyć się niektórych sprawdzeń granic (patrz `position`), obliczamy długość w nieco nieoczekiwany sposób.
// (Testowane przez " codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // czasami jesteśmy wykorzystywani w niebezpiecznym bloku

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ten _cannot_ używa `unchecked_sub`, ponieważ polegamy na zawijaniu, aby przedstawić długość długich iteratorów wycinków ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Wiemy, że `start <= end`, więc radzi sobie lepiej niż `offset_from`, który wymaga podpisania umowy.
            // Ustawiając tutaj odpowiednie flagi, możemy to powiedzieć LLVM, co pomaga w usuwaniu kontroli granic.
            // BEZPIECZEŃSTWO: według niezmiennego typu, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Informując również LLVM, że wskaźniki są oddzielone dokładną wielokrotnością rozmiaru typu, może zoptymalizować `len() == 0` do `start == end` zamiast `(end - start) < size`.
            //
            // BEZPIECZEŃSTWO: Zgodnie z niezmiennikiem typu wskaźniki są wyrównane, więc
            //         odległość między nimi musi być wielokrotnością rozmiaru punktu
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Wspólna definicja iteratorów `Iter` i `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Zwraca pierwszy element i przesuwa początek iteratora do przodu o 1.
        // Znacznie poprawia wydajność w porównaniu z wbudowaną funkcją.
        // Iterator nie może być pusty.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Zwraca ostatni element i przesuwa koniec iteratora wstecz o 1.
        // Znacznie poprawia wydajność w porównaniu z wbudowaną funkcją.
        // Iterator nie może być pusty.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Zmniejsza iterator, gdy T jest ZST, przesuwając koniec iteratora wstecz o `n`.
        // `n` nie może przekraczać `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Funkcja pomocnicza do tworzenia wycinka z iteratora.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // BEZPIECZEŃSTWO: iterator został utworzony z plastra ze wskaźnikiem
                // `self.ptr` i długość `len!(self)`.
                // Gwarantuje to, że wszystkie wymagania wstępne dla `from_raw_parts` są spełnione.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Funkcja pomocnicza do przesuwania początku iteratora do przodu o elementy `offset`, zwracająca stary początek.
            //
            // Niebezpieczne, ponieważ przesunięcie nie może przekraczać `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // BEZPIECZEŃSTWO: dzwoniący gwarantuje, że `offset` nie przekracza `self.len()`,
                    // więc ten nowy wskaźnik znajduje się wewnątrz `self`, a zatem gwarantuje, że nie jest zerowy.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Funkcja pomocnicza do przesuwania końca iteratora wstecz o elementy `offset`, zwracająca nowy koniec.
            //
            // Niebezpieczne, ponieważ przesunięcie nie może przekraczać `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // BEZPIECZEŃSTWO: dzwoniący gwarantuje, że `offset` nie przekracza `self.len()`,
                    // który gwarantuje, że nie przepełni `isize`.
                    // Ponadto wynikowy wskaźnik znajduje się w granicach `slice`, co spełnia inne wymagania dotyczące `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // można by zaimplementować z plasterkami, ale pozwala to uniknąć sprawdzania granic

                // BEZPIECZEŃSTWO: wywołania `assume` są bezpieczne od początku wskaźnika wycinka
                // musi mieć wartość różną od null, a wycinki na elementach innych niż ZST muszą mieć również niezerowy wskaźnik końcowy.
                // Wywołanie `next_unchecked!` jest bezpieczne, ponieważ najpierw sprawdzamy, czy iterator jest pusty.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ten iterator jest teraz pusty.
                    if mem::size_of::<T>() == 0 {
                        // Musimy to zrobić w ten sposób, ponieważ `ptr` może nigdy nie wynosić 0, ale `end` może być (ze względu na zawijanie).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // BEZPIECZEŃSTWO: koniec nie może wynosić 0, jeśli T nie jest ZST, ponieważ ptr nie jest równe 0 i end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // BEZPIECZEŃSTWO: Jesteśmy w granicach.`post_inc_start` robi to, co właściwe, nawet w przypadku ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Zastępujemy domyślną implementację, która używa `try_fold`, ponieważ ta prosta implementacja generuje mniej LLVM IR i jest szybsza w kompilacji.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Zastępujemy domyślną implementację, która używa `try_fold`, ponieważ ta prosta implementacja generuje mniej LLVM IR i jest szybsza w kompilacji.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Zastępujemy domyślną implementację, która używa `try_fold`, ponieważ ta prosta implementacja generuje mniej LLVM IR i jest szybsza w kompilacji.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Zastępujemy domyślną implementację, która używa `try_fold`, ponieważ ta prosta implementacja generuje mniej LLVM IR i jest szybsza w kompilacji.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Zastępujemy domyślną implementację, która używa `try_fold`, ponieważ ta prosta implementacja generuje mniej LLVM IR i jest szybsza w kompilacji.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Zastępujemy domyślną implementację, która używa `try_fold`, ponieważ ta prosta implementacja generuje mniej LLVM IR i jest szybsza w kompilacji.
            // Ponadto `assume` unika kontroli granic.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // BEZPIECZEŃSTWO: gwarantujemy, że jesteśmy w granicach niezmiennika pętli:
                        // gdy `i >= n`, `self.next()` zwraca `None` i pętla zostaje przerwana.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Zastępujemy domyślną implementację, która używa `try_fold`, ponieważ ta prosta implementacja generuje mniej LLVM IR i jest szybsza w kompilacji.
            // Ponadto `assume` unika kontroli granic.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // BEZPIECZEŃSTWO: `i` musi być niższy niż `n`, ponieważ zaczyna się od `n`
                        // i tylko maleje.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // BEZPIECZEŃSTWO: dzwoniący musi zagwarantować, że `i` jest w granicach
                // bazowego wycinka, więc `i` nie może przepełnić `isize`, a zwrócone odwołania mają gwarancję, że odwołują się do elementu wycinka, a tym samym gwarantują, że będą prawidłowe.
                //
                // Zwróć również uwagę, że wywołujący gwarantuje również, że nigdy nie zostaniemy wywołani z tym samym indeksem i że nie są wywoływane żadne inne metody, które będą miały dostęp do tej podklasy, więc prawidłowe jest, aby zwrócone odwołanie było modyfikowalne w przypadku
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // można by zaimplementować z plasterkami, ale pozwala to uniknąć sprawdzania granic

                // BEZPIECZEŃSTWO: wywołania `assume` są bezpieczne, ponieważ wskaźnik początkowy wycinka nie może być zerowy,
                // a plasterki na innych niż ZST muszą mieć również niezerowy wskaźnik końca.
                // Wywołanie `next_back_unchecked!` jest bezpieczne, ponieważ najpierw sprawdzamy, czy iterator jest pusty.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ten iterator jest teraz pusty.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // BEZPIECZEŃSTWO: Jesteśmy w granicach.`pre_dec_end` robi to, co właściwe, nawet w przypadku ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}