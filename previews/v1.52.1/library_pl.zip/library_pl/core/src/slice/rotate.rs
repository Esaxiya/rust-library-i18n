// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Obraca zakres `[mid-left, mid+right)` w taki sposób, że element w `mid` staje się pierwszym elementem.Odpowiednio obraca elementy `left` zakresu w lewo lub elementy `right` w prawo.
///
/// # Safety
///
/// Określony zakres musi być ważny do odczytu i zapisu.
///
/// # Algorithm
///
/// Algorytm 1 jest używany dla małych wartości `left + right` lub dla dużych `T`.
/// Elementy są przesuwane pojedynczo do swoich pozycji końcowych, zaczynając od `mid - left` i przesuwając dalej o `right` kroki modulo `left + right`, tak że potrzebny jest tylko jeden tymczasowy.
/// W końcu wracamy do `mid - left`.
/// Jeśli jednak `gcd(left + right, right)` nie jest 1, powyższe kroki pomijają elementy.
/// Na przykład:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Na szczęście liczba pominiętych elementów między sfinalizowanymi elementami jest zawsze równa, więc możemy po prostu przesunąć naszą pozycję startową i zrobić więcej rund (całkowita liczba rund to `gcd(left + right, right)` value).
///
/// W rezultacie wszystkie elementy są finalizowane raz i tylko raz.
///
/// Algorytm 2 jest używany, jeśli `left + right` jest duży, ale `min(left, right)` jest wystarczająco mały, aby zmieścić się w buforze stosu.
/// Elementy `min(left, right)` są kopiowane do bufora, `memmove` jest nakładane na pozostałe, a te z bufora są przenoszone z powrotem do otworu po przeciwnej stronie miejsca, w którym powstały.
///
/// Algorytmy, które można wektoryzować, przewyższają powyższe, gdy `left + right` stanie się wystarczająco duży.
/// Algorytm 1 można wektoryzować, dzieląc na fragmenty i wykonując wiele rund jednocześnie, ale średnio jest zbyt mało rund, dopóki `left + right` nie będzie ogromny, a najgorszy przypadek pojedynczej rundy zawsze istnieje.
/// Zamiast tego algorytm 3 wykorzystuje powtarzające się zamiany elementów `min(left, right)`, aż do pozostawienia mniejszego problemu z obrotem.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// kiedy `left < right` zamiana odbywa się z lewej strony.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. Poniższe algorytmy mogą zawieść, jeśli te przypadki nie zostaną sprawdzone
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorytm 1 Mikroznaczniki wskazują, że średnia wydajność przypadkowych przesunięć jest lepsza aż do około `left + right == 32`, ale w najgorszym przypadku wydajność spada nawet do około 16.
            // 24 został wybrany jako środek pośredni.
            // Jeśli rozmiar `T` jest większy niż 4 " usize`, algorytm ten przewyższa również inne algorytmy.
            //
            //
            let x = unsafe { mid.sub(left) };
            // początek pierwszej rundy
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` można znaleźć wcześniej, obliczając `gcd(left + right, right)`, ale szybciej jest wykonać jedną pętlę, która oblicza gcd jako efekt uboczny, a następnie wykonać resztę kawałka
            //
            //
            let mut gcd = right;
            // testy porównawcze pokazują, że szybsza jest wymiana elementów tymczasowych w całości, zamiast jednorazowego czytania jednego tymczasowego, kopiowania wstecz, a następnie zapisywania tego tymczasowego na samym końcu.
            // Jest to prawdopodobnie spowodowane faktem, że zamiana lub zamiana tymczasowych wykorzystuje tylko jeden adres pamięci w pętli, zamiast konieczności zarządzania dwoma.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // zamiast zwiększać `i`, a następnie sprawdzać, czy znajduje się poza granicami, sprawdzamy, czy `i` wyjdzie poza granice przy następnym zwiększeniu.
                // Zapobiega to zawijaniu wskaźników lub `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // koniec pierwszej rundy
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ten warunek musi być tutaj, jeśli `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // zakończ kawałek większą ilością rund
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` nie jest typem o rozmiarze zerowym, więc można podzielić przez jego rozmiar.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorytm 2 `[T; 0]` ma zapewnić, że jest to odpowiednio wyrównane dla T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorytm 3 Istnieje alternatywny sposób zamiany, który polega na znalezieniu miejsca, w którym byłaby ostatnia zamiana tego algorytmu, i zamianie przy użyciu ostatniego fragmentu zamiast zamiany sąsiednich fragmentów, jak to robi ten algorytm, ale ten sposób jest nadal szybszy.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorytm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}