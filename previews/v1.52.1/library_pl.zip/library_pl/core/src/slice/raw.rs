//! Darmowe funkcje do tworzenia `&[T]` i `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Tworzy wycinek ze wskaźnika i długości.
///
/// Argument `len` to liczba **elementów**, a nie liczba bajtów.
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `data` musi być [valid] dla odczytów dla `len * mem::size_of::<T>()` wiele bajtów i musi być odpowiednio wyrównany.Oznacza to w szczególności:
///
///     * Cały zakres pamięci tego wycinka musi być zawarty w jednym przydzielonym obiekcie!
///       Plasterki nigdy nie mogą obejmować wielu przydzielonych obiektów.Zobacz [below](#incorrect-usage), aby zapoznać się z przykładem niepoprawnie nie biorąc tego pod uwagę.
///     * `data` musi być różna od null i wyrównana nawet dla wycinków o zerowej długości.
///     Jednym z powodów jest to, że optymalizacje układu wyliczenia mogą polegać na odniesieniach (w tym wycinkach o dowolnej długości), które są wyrównane i niezerowe, aby odróżnić je od innych danych.
///     Możesz uzyskać wskaźnik, który jest używany jako `data` dla wycinków o zerowej długości przy użyciu [`NonNull::dangling()`].
///
/// * `data` musi wskazywać na `len` kolejne prawidłowo zainicjowane wartości typu `T`.
///
/// * Pamięć, do której odwołuje się zwrócony wycinek, nie może być modyfikowana przez okres istnienia `'a`, z wyjątkiem wewnątrz `UnsafeCell`.
///
/// * Całkowity rozmiar `len * mem::size_of::<T>()` wycinka nie może być większy niż `isize::MAX`.
///   Zobacz dokumentację dotyczącą bezpieczeństwa [`pointer::offset`].
///
/// # Caveat
///
/// Okres istnienia zwracanego wycinka jest wywnioskowany na podstawie jego użycia.
/// Aby zapobiec przypadkowemu niewłaściwemu użyciu, sugeruje się powiązanie okresu istnienia z dowolnym okresem istnienia źródła jest bezpieczny w kontekście, na przykład przez zapewnienie funkcji pomocniczej, która pobiera okres istnienia wartości hosta dla wycinka lub jawną adnotację.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestuje wycinek dla pojedynczego elementu
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Nieprawidłowe użycie
///
/// Następująca funkcja `join_slices` jest **niesprawna** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Powyższe stwierdzenie zapewnia, że `fst` i `snd` są ciągłe, ale mogą nadal znajdować się w _different allocated objects_, w takim przypadku tworzenie tego wycinka jest niezdefiniowanym zachowaniem.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` i `b` to różne przydzielone obiekty ...
///     let a = 42;
///     let b = 27;
///     // ... które mimo wszystko mogą zostać umieszczone w pamięci w sposób ciągły: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Pełni te same funkcje co [`from_raw_parts`], z tą różnicą, że zwracany jest modyfikowalny wycinek.
///
/// # Safety
///
/// Zachowanie jest niezdefiniowane, jeśli zostanie naruszony którykolwiek z następujących warunków:
///
/// * `data` musi być [valid] zarówno dla odczytu, jak i zapisu dla `len * mem::size_of::<T>()` wiele bajtów i musi być odpowiednio wyrównany.Oznacza to w szczególności:
///
///     * Cały zakres pamięci tego wycinka musi być zawarty w jednym przydzielonym obiekcie!
///       Plasterki nigdy nie mogą obejmować wielu przydzielonych obiektów.
///     * `data` musi być różna od null i wyrównana nawet dla wycinków o zerowej długości.
///     Jednym z powodów jest to, że optymalizacje układu wyliczenia mogą polegać na odniesieniach (w tym wycinkach o dowolnej długości), które są wyrównane i niezerowe, aby odróżnić je od innych danych.
///
///     Możesz uzyskać wskaźnik, który jest używany jako `data` dla wycinków o zerowej długości przy użyciu [`NonNull::dangling()`].
///
/// * `data` musi wskazywać na `len` kolejne prawidłowo zainicjowane wartości typu `T`.
///
/// * Do pamięci, do której odwołuje się zwrócony wycinek, nie można uzyskać dostępu przez żaden inny wskaźnik (nie pochodzący z wartości zwracanej) przez okres istnienia `'a`.
///   Zabrania się dostępu do odczytu i zapisu.
///
/// * Całkowity rozmiar `len * mem::size_of::<T>()` wycinka nie może być większy niż `isize::MAX`.
///   Zobacz dokumentację dotyczącą bezpieczeństwa [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Konwertuje odniesienie do T na odcinek o długości 1 (bez kopiowania).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Konwertuje odniesienie do T na odcinek o długości 1 (bez kopiowania).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}