// ignore-tidy-filelength

//! Zarządzanie i manipulacja plastrami.
//!
//! Aby uzyskać więcej informacji, zobacz [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Czysta implementacja memchr rust, zaczerpnięta z rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ta funkcja jest publiczna tylko dlatego, że nie ma innego sposobu na jednostkowe testowanie heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Zwraca liczbę elementów w wycinku.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // BEZPIECZEŃSTWO: const sound, ponieważ transmutujemy pole długości jako usize (które musi być)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // BEZPIECZEŃSTWO: jest to bezpieczne, ponieważ `&[T]` i `FatPtr<T>` mają ten sam układ.
            // Tylko `std` może udzielić takiej gwarancji.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Zastąp `crate::ptr::metadata(self)`, gdy jest stabilny.
            // W chwili pisania tego tekstu powoduje to błąd "Const-stable functions can only call other const-stable functions".
            //

            // BEZPIECZEŃSTWO: Dostęp do wartości z unii `PtrRepr` jest bezpieczny, ponieważ * const T
            // i PtrComponents<T>mają te same układy pamięci.
            // Tylko std może dać tę gwarancję.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Zwraca `true`, jeśli wycinek ma długość 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Zwraca pierwszy element wycinka lub `None`, jeśli jest pusty.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Zwraca zmienny wskaźnik do pierwszego elementu wycinka lub `None`, jeśli jest pusty.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Zwraca pierwszy i wszystkie pozostałe elementy wycinka lub `None`, jeśli jest pusty.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Zwraca pierwszy i wszystkie pozostałe elementy wycinka lub `None`, jeśli jest pusty.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Zwraca ostatni i wszystkie pozostałe elementy wycinka lub `None`, jeśli jest pusty.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Zwraca ostatni i wszystkie pozostałe elementy wycinka lub `None`, jeśli jest pusty.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Zwraca ostatni element wycinka lub `None`, jeśli jest pusty.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Zwraca zmienny wskaźnik do ostatniego elementu w wycinku.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Zwraca odwołanie do elementu lub podklasy w zależności od typu indeksu.
    ///
    /// - Jeśli podano pozycję, zwraca odwołanie do elementu w tej pozycji lub `None`, jeśli jest poza zakresem.
    ///
    /// - Jeśli podano zakres, zwraca podklaskę odpowiadającą temu zakresowi lub `None`, jeśli jest poza zakresem.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Zwraca zmienne odwołanie do elementu lub fragmentu podrzędnego w zależności od typu indeksu (patrz [`get`]) lub `None`, jeśli indeks jest poza zakresem.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Zwraca odniesienie do elementu lub podklasy, bez sprawdzania granic.
    ///
    /// Aby uzyskać bezpieczną alternatywę, zobacz [`get`].
    ///
    /// # Safety
    ///
    /// Wywołanie tej metody z indeksem spoza zakresu jest *[niezdefiniowane zachowanie]*, nawet jeśli wynikowe odwołanie nie jest używane.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać większości wymagań bezpieczeństwa dotyczących `get_unchecked`;
        // wycinek można usunąć odwołanie, ponieważ `self` jest bezpiecznym odniesieniem.
        // Zwrócony wskaźnik jest bezpieczny, ponieważ impls `SliceIndex` muszą zagwarantować, że tak jest.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Zwraca zmienne odwołanie do elementu lub podklasy, bez sprawdzania granic.
    ///
    /// Aby uzyskać bezpieczną alternatywę, zobacz [`get_mut`].
    ///
    /// # Safety
    ///
    /// Wywołanie tej metody z indeksem spoza zakresu jest *[niezdefiniowane zachowanie]*, nawet jeśli wynikowe odwołanie nie jest używane.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać wymagań bezpieczeństwa dla `get_unchecked_mut`;
        // wycinek można usunąć odwołanie, ponieważ `self` jest bezpiecznym odniesieniem.
        // Zwrócony wskaźnik jest bezpieczny, ponieważ impls `SliceIndex` muszą zagwarantować, że tak jest.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Zwraca surowy wskaźnik do bufora wycinka.
    ///
    /// Obiekt wywołujący musi upewnić się, że wycinek przeżyje wskaźnik zwracany przez tę funkcję, w przeciwnym razie będzie wskazywał na śmieci.
    ///
    /// Obiekt wywołujący musi również upewnić się, że pamięć, na którą wskazuje wskaźnik (non-transitively), nigdy nie zostanie zapisana (z wyjątkiem wewnątrz `UnsafeCell`) przy użyciu tego wskaźnika lub wskaźnika pochodnego od niego.
    /// Jeśli chcesz zmodyfikować zawartość plasterka, użyj [`as_mut_ptr`].
    ///
    /// Modyfikacja kontenera, do którego odwołuje się ten wycinek, może spowodować ponowne przydzielenie jego bufora, co spowoduje również unieważnienie wszelkich wskaźników do niego.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Zwraca niebezpieczny, zmienny wskaźnik do bufora wycinka.
    ///
    /// Obiekt wywołujący musi upewnić się, że wycinek przeżyje wskaźnik zwracany przez tę funkcję, w przeciwnym razie będzie wskazywał na śmieci.
    ///
    /// Modyfikacja kontenera, do którego odwołuje się ten wycinek, może spowodować ponowne przydzielenie jego bufora, co spowoduje również unieważnienie wszelkich wskaźników do niego.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Zwraca dwa surowe wskaźniki obejmujące wycinek.
    ///
    /// Zwrócony zakres jest w połowie otwarty, co oznacza, że wskaźnik końcowy wskazuje *jeden za* ostatni element wycinka.
    /// W ten sposób pusty wycinek jest reprezentowany przez dwa równe wskaźniki, a różnica między tymi dwoma wskaźnikami reprezentuje rozmiar wycinka.
    ///
    /// Zobacz [`as_ptr`], aby uzyskać ostrzeżenia dotyczące używania tych wskaźników.Wskaźnik końcowy wymaga dodatkowej ostrożności, ponieważ nie wskazuje prawidłowego elementu w wycinku.
    ///
    /// Ta funkcja jest przydatna do interakcji z obcymi interfejsami, które używają dwóch wskaźników do odwoływania się do zakresu elementów w pamięci, co jest powszechne w C++ .
    ///
    ///
    /// Przydatne może być również sprawdzenie, czy wskaźnik do elementu odnosi się do elementu tego wycinka:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // BEZPIECZEŃSTWO: `add` jest tutaj bezpieczny, ponieważ:
        //
        //   - Oba wskaźniki są częścią tego samego obiektu, ponieważ liczy się również wskazanie bezpośrednio obok obiektu.
        //
        //   - Rozmiar wycinka nigdy nie jest większy niż isize::MAX bajtów, jak zauważono tutaj:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Nie ma zawijania, ponieważ plasterki nie zawijają się poza koniec przestrzeni adresowej.
        //
        // Zobacz dokumentację pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Zwraca dwa niebezpieczne zmienne wskaźniki obejmujące wycinek.
    ///
    /// Zwrócony zakres jest w połowie otwarty, co oznacza, że wskaźnik końcowy wskazuje *jeden za* ostatni element wycinka.
    /// W ten sposób pusty wycinek jest reprezentowany przez dwa równe wskaźniki, a różnica między tymi dwoma wskaźnikami reprezentuje rozmiar wycinka.
    ///
    /// Zobacz [`as_mut_ptr`], aby uzyskać ostrzeżenia dotyczące używania tych wskaźników.
    /// Wskaźnik końcowy wymaga dodatkowej ostrożności, ponieważ nie wskazuje prawidłowego elementu w wycinku.
    ///
    /// Ta funkcja jest przydatna do interakcji z obcymi interfejsami, które używają dwóch wskaźników do odwoływania się do zakresu elementów w pamięci, co jest powszechne w C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // BEZPIECZEŃSTWO: Zobacz as_ptr_range() powyżej, aby dowiedzieć się, dlaczego `add` jest tutaj bezpieczny.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Zamienia dwa elementy w plasterku.
    ///
    /// # Arguments
    ///
    /// * a, Indeks pierwszego elementu
    /// * b, indeks drugiego elementu
    ///
    /// # Panics
    ///
    /// Panics, jeśli `a` lub `b` są poza zakresem.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Nie można wziąć dwóch pożyczek z możliwością zmiany od jednego vector, więc zamiast tego użyj surowych wskaźników.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // BEZPIECZEŃSTWO: `pa` i `pb` zostały stworzone z bezpiecznych, modyfikowalnych odniesień i odniesień
        // do elementów w plasterku i dlatego gwarantujemy poprawność i wyrównanie.
        // Zwróć uwagę, że dostęp do elementów za `a` i `b` jest zaznaczony i panic będzie poza zakresem.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Odwraca kolejność elementów w plasterku na miejscu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // W przypadku bardzo małych typów wszystkie poszczególne odczyty w normalnej ścieżce działają słabo.
        // Możemy zrobić lepiej, mając wydajne niewyrównane load/store, ładując większy fragment i odwracając rejestr.
        //

        // Idealnie byłoby, gdyby LLVM zrobił to za nas, ponieważ wie lepiej niż my, czy niewyrównane odczyty są wydajne (ponieważ zmienia się to na przykład między różnymi wersjami ARM) i jaki byłby najlepszy rozmiar fragmentu.
        // Niestety od LLVM 4.0 (2017-05) tylko rozwija pętlę, więc musimy to zrobić sami.
        // (Hipoteza: odwrócenie jest kłopotliwe, ponieważ boki można ustawić inaczej-będzie, gdy długość jest nieparzysta-więc nie ma możliwości emitowania pre-i postludiów, aby użyć w pełni wyrównanego SIMD w środku.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Użyj wbudowanego llvm.bswap do odwrócenia U8 w usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // BEZPIECZEŃSTWO: Jest kilka rzeczy do sprawdzenia:
                //
                // - Zauważ, że `chunk` to 4 lub 8 ze względu na powyższą kontrolę cfg.Więc `chunk - 1` jest pozytywny.
                // - Indeksowanie z indeksem `i` jest w porządku, ponieważ kontrola pętli gwarantuje
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indeksowanie z indeksem `ln - i - chunk = ln - (i + chunk)` jest w porządku:
                //   - `i + chunk > 0` jest trywialnie prawdziwe.
                //   - Kontrola pętli gwarantuje:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, dlatego odejmowanie nie powoduje niedomiarów.
                // - Połączenia `read_unaligned` i `write_unaligned` są w porządku:
                //   - `pa` wskazuje na indeks `i`, gdzie `i < ln / 2 - (chunk - 1)` (patrz wyżej) i `pb` wskazuje na indeks `ln - i - chunk`, więc oba są co najmniej `chunk` oddalone o wiele bajtów od końca `self`.
                //
                //   - Każda zainicjowana pamięć jest poprawna `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Użyj obrotu o 16, aby odwrócić U16 w u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // BEZPIECZEŃSTWO: niewyrównany u32 można odczytać z `i`, jeśli `i + 1 < ln`
                // (i oczywiście `i < ln`), ponieważ każdy element ma 2 bajty i czytamy 4.
                //
                // `i + chunk - 1 < ln / 2` # podczas gdy stan
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Ponieważ jest mniejsza niż długość podzielona przez 2, to musi być w granicach.
                //
                // Oznacza to również, że warunek `0 < i + chunk <= ln` jest zawsze przestrzegany, zapewniając bezpieczne użycie wskaźnika `pb`.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // BEZPIECZEŃSTWO: `i` jest gorszy od połowy długości plastra tzw
            // dostęp do `i` i `ln - i - 1` jest bezpieczny (`i` zaczyna się od 0 i nie idzie dalej niż `ln / 2 - 1`).
            // Wynikowe wskaźniki `pa` i `pb` są zatem prawidłowe i wyrównane oraz mogą być odczytywane i zapisywane.
            //
            //
            unsafe {
                // Niebezpieczna zamiana, aby uniknąć granic, zamelduj się w bezpiecznej zamianie.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Zwraca iterator na wycinku.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Zwraca iterator, który umożliwia modyfikowanie każdej wartości.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Zwraca iterator dla wszystkich ciągłych windows o długości `size`.
    /// windows zachodzi na siebie.
    /// Jeśli wycinek jest krótszy niż `size`, iterator nie zwraca żadnych wartości.
    ///
    /// # Panics
    ///
    /// Panics, jeśli `size` to 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Jeśli wycinek jest krótszy niż `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Zwraca na raz iterator po elementach `chunk_size` wycinka, zaczynając od początku wycinka.
    ///
    /// Kawałki są plastrami i nie nakładają się na siebie.Jeśli `chunk_size` nie podzieli długości wycinka, ostatni fragment nie będzie miał długości `chunk_size`.
    ///
    /// Zobacz [`chunks_exact`] dla wariantu tego iteratora, który zwraca fragmenty zawsze dokładnie dokładnie `chunk_size` i [`rchunks`] dla tego samego iteratora, ale zaczynającego się na końcu wycinka.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `chunk_size` to 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Zwraca na raz iterator po elementach `chunk_size` wycinka, zaczynając od początku wycinka.
    ///
    /// Kawałki są plastrami zmiennymi i nie nakładają się na siebie.Jeśli `chunk_size` nie podzieli długości wycinka, ostatni fragment nie będzie miał długości `chunk_size`.
    ///
    /// Zobacz [`chunks_exact_mut`] dla wariantu tego iteratora, który zwraca fragmenty zawsze dokładnie dokładnie `chunk_size` i [`rchunks_mut`] dla tego samego iteratora, ale zaczynającego się na końcu wycinka.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `chunk_size` to 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Zwraca na raz iterator po elementach `chunk_size` wycinka, zaczynając od początku wycinka.
    ///
    /// Kawałki są plastrami i nie nakładają się na siebie.
    /// Jeśli `chunk_size` nie podzieli długości wycinka, ostatnie elementy do `chunk_size-1` zostaną pominięte i można je pobrać z funkcji `remainder` iteratora.
    ///
    ///
    /// Ponieważ każdy fragment ma dokładnie elementy `chunk_size`, kompilator często może lepiej zoptymalizować wynikowy kod niż w przypadku [`chunks`].
    ///
    /// Zobacz [`chunks`] dla wariantu tego iteratora, który również zwraca resztę jako mniejszy fragment, a [`rchunks_exact`] dla tego samego iteratora, ale zaczynającego się na końcu wycinka.
    ///
    /// # Panics
    ///
    /// Panics, jeśli `chunk_size` to 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Zwraca na raz iterator po elementach `chunk_size` wycinka, zaczynając od początku wycinka.
    ///
    /// Kawałki są plastrami zmiennymi i nie nakładają się na siebie.
    /// Jeśli `chunk_size` nie podzieli długości wycinka, ostatnie elementy do `chunk_size-1` zostaną pominięte i można je pobrać z funkcji `into_remainder` iteratora.
    ///
    ///
    /// Ponieważ każdy fragment ma dokładnie elementy `chunk_size`, kompilator często może lepiej zoptymalizować wynikowy kod niż w przypadku [`chunks_mut`].
    ///
    /// Zobacz [`chunks_mut`] dla wariantu tego iteratora, który również zwraca resztę jako mniejszy fragment, a [`rchunks_exact_mut`] dla tego samego iteratora, ale zaczynającego się na końcu wycinka.
    ///
    /// # Panics
    ///
    /// Panics, jeśli `chunk_size` to 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Dzieli plasterek na wycinek tablic " N` elementów, zakładając, że nie ma reszty.
    ///
    ///
    /// # Safety
    ///
    /// Można to wywołać tylko wtedy, gdy
    /// - Wycinek dzieli się dokładnie na porcje " N` (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // BEZPIECZEŃSTWO: 1-elementowe kawałki nigdy nie pozostaną
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // BEZPIECZEŃSTWO: długość wycinka (6) jest wielokrotnością 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // To byłoby niewłaściwe:
    /// // niech kawałki: &[[_;5]]= slice.as_chunks_unchecked()//Długość wycinka nie jest wielokrotnością 5 kawałków let:&[[_;0]]= slice.as_chunks_unchecked()//Fragmenty o zerowej długości nigdy nie są dozwolone
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // BEZPIECZEŃSTWO: Nasz warunek wstępny jest dokładnie tym, co jest potrzebne, aby to nazwać
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // BEZPIECZEŃSTWO: Wrzucamy kawałek elementów `new_len * N` do
        // kawałek `new_len` wiele fragmentów elementów `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Dzieli plasterek na wycinek tablic " N`, zaczynając od początku wycinka, oraz na pozostałą część o długości dokładnie mniejszej niż `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `N` ma wartość 0. To sprawdzenie najprawdopodobniej zostanie zmienione na błąd czasu kompilacji, zanim ta metoda zostanie ustabilizowana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // BEZPIECZEŃSTWO: Już wpadliśmy w panikę do zera i zapewniła nas konstrukcja
        // że długość podskrawki jest wielokrotnością N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Dzieli plasterek na wycinek tablic " N`, zaczynając od końca wycinka, i pozostałą część wycinka o długości dokładnie mniejszej niż `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `N` ma wartość 0. To sprawdzenie najprawdopodobniej zostanie zmienione na błąd czasu kompilacji, zanim ta metoda zostanie ustabilizowana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // BEZPIECZEŃSTWO: Już wpadliśmy w panikę do zera i zapewniła nas konstrukcja
        // że długość podskrawki jest wielokrotnością N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Zwraca na raz iterator po elementach `N` wycinka, zaczynając od początku wycinka.
    ///
    /// Porcje są odniesieniami do tablic i nie nakładają się.
    /// Jeśli `N` nie podzieli długości wycinka, ostatnie elementy do `N-1` zostaną pominięte i można je pobrać z funkcji `remainder` iteratora.
    ///
    ///
    /// Ta metoda jest stałym odpowiednikiem [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics, jeśli `N` ma wartość 0. To sprawdzenie najprawdopodobniej zostanie zmienione na błąd czasu kompilacji, zanim ta metoda zostanie ustabilizowana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Dzieli plasterek na wycinek tablic " N` elementów, zakładając, że nie ma reszty.
    ///
    ///
    /// # Safety
    ///
    /// Można to wywołać tylko wtedy, gdy
    /// - Wycinek dzieli się dokładnie na porcje " N` (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // BEZPIECZEŃSTWO: 1-elementowe kawałki nigdy nie pozostaną
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // BEZPIECZEŃSTWO: długość wycinka (6) jest wielokrotnością 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // To byłoby niewłaściwe:
    /// // niech kawałki: &[[_;5]]= slice.as_chunks_unchecked_mut()//Długość wycinka nie jest wielokrotnością 5 kawałków let:&[[_;0]]= slice.as_chunks_unchecked_mut()//Fragmenty o zerowej długości nigdy nie są dozwolone
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // BEZPIECZEŃSTWO: Nasz warunek wstępny jest dokładnie tym, co jest potrzebne, aby to nazwać
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // BEZPIECZEŃSTWO: Wrzucamy kawałek elementów `new_len * N` do
        // kawałek `new_len` wiele fragmentów elementów `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Dzieli plasterek na wycinek tablic " N`, zaczynając od początku wycinka, oraz na pozostałą część o długości dokładnie mniejszej niż `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `N` ma wartość 0. To sprawdzenie najprawdopodobniej zostanie zmienione na błąd czasu kompilacji, zanim ta metoda zostanie ustabilizowana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // BEZPIECZEŃSTWO: Już wpadliśmy w panikę do zera i zapewniła nas konstrukcja
        // że długość podskrawki jest wielokrotnością N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Dzieli plasterek na wycinek tablic " N`, zaczynając od końca wycinka, i pozostałą część wycinka o długości dokładnie mniejszej niż `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `N` ma wartość 0. To sprawdzenie najprawdopodobniej zostanie zmienione na błąd czasu kompilacji, zanim ta metoda zostanie ustabilizowana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // BEZPIECZEŃSTWO: Już wpadliśmy w panikę do zera i zapewniła nas konstrukcja
        // że długość podskrawki jest wielokrotnością N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Zwraca na raz iterator po elementach `N` wycinka, zaczynając od początku wycinka.
    ///
    /// Porcje są zmiennymi odwołaniami do tablic i nie nakładają się.
    /// Jeśli `N` nie podzieli długości wycinka, ostatnie elementy do `N-1` zostaną pominięte i można je pobrać z funkcji `into_remainder` iteratora.
    ///
    ///
    /// Ta metoda jest stałym odpowiednikiem [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics, jeśli `N` ma wartość 0. To sprawdzenie najprawdopodobniej zostanie zmienione na błąd czasu kompilacji, zanim ta metoda zostanie ustabilizowana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Zwraca iterator nakładający się na elementy windows z `N` wycinka, zaczynając od początku wycinka.
    ///
    ///
    /// To jest stały odpowiednik [`windows`].
    ///
    /// Jeśli `N` jest większy niż rozmiar wycinka, nie zwróci windows.
    ///
    /// # Panics
    ///
    /// Panics, jeśli `N` to 0.
    /// To sprawdzenie najprawdopodobniej zostanie zmienione na błąd czasu kompilacji, zanim ta metoda zostanie ustabilizowana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Zwraca na raz iterator po elementach `chunk_size` wycinka, zaczynając od końca wycinka.
    ///
    /// Kawałki są plastrami i nie nakładają się na siebie.Jeśli `chunk_size` nie podzieli długości wycinka, ostatni fragment nie będzie miał długości `chunk_size`.
    ///
    /// Zobacz [`rchunks_exact`] dla wariantu tego iteratora, który zwraca fragmenty zawsze dokładnie dokładnie `chunk_size` i [`chunks`] dla tego samego iteratora, ale zaczynając od początku wycinka.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `chunk_size` to 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Zwraca na raz iterator po elementach `chunk_size` wycinka, zaczynając od końca wycinka.
    ///
    /// Kawałki są plastrami zmiennymi i nie nakładają się na siebie.Jeśli `chunk_size` nie podzieli długości wycinka, ostatni fragment nie będzie miał długości `chunk_size`.
    ///
    /// Zobacz [`rchunks_exact_mut`] dla wariantu tego iteratora, który zwraca fragmenty zawsze dokładnie dokładnie `chunk_size` i [`chunks_mut`] dla tego samego iteratora, ale zaczynając od początku wycinka.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `chunk_size` to 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Zwraca na raz iterator po elementach `chunk_size` wycinka, zaczynając od końca wycinka.
    ///
    /// Kawałki są plastrami i nie nakładają się na siebie.
    /// Jeśli `chunk_size` nie podzieli długości wycinka, ostatnie elementy do `chunk_size-1` zostaną pominięte i można je pobrać z funkcji `remainder` iteratora.
    ///
    /// Ponieważ każdy fragment ma dokładnie elementy `chunk_size`, kompilator często może lepiej zoptymalizować wynikowy kod niż w przypadku [`chunks`].
    ///
    /// Zobacz [`rchunks`] dla wariantu tego iteratora, który również zwraca resztę jako mniejszy fragment, a [`chunks_exact`] dla tego samego iteratora, ale zaczynając od początku wycinka.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `chunk_size` to 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Zwraca na raz iterator po elementach `chunk_size` wycinka, zaczynając od końca wycinka.
    ///
    /// Kawałki są plastrami zmiennymi i nie nakładają się na siebie.
    /// Jeśli `chunk_size` nie podzieli długości wycinka, ostatnie elementy do `chunk_size-1` zostaną pominięte i można je pobrać z funkcji `into_remainder` iteratora.
    ///
    /// Ponieważ każdy fragment ma dokładnie elementy `chunk_size`, kompilator często może lepiej zoptymalizować wynikowy kod niż w przypadku [`chunks_mut`].
    ///
    /// Zobacz [`rchunks_mut`] dla wariantu tego iteratora, który również zwraca resztę jako mniejszy fragment, a [`chunks_exact_mut`] dla tego samego iteratora, ale zaczynając od początku wycinka.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `chunk_size` to 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Zwraca iterator na wycinku, tworząc niezachodzące na siebie serie elementów, używając predykatu do ich oddzielenia.
    ///
    /// Predykat jest wywoływany na dwóch elementach następujących po sobie, co oznacza, że predykat jest wywoływany na `slice[0]` i `slice[1]`, a następnie na `slice[1]` i `slice[2]` i tak dalej.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ta metoda może być użyta do wyodrębnienia posortowanych podklasków:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Zwraca iterator na wycinku, tworząc niezachodzące na siebie zmienne serie elementów przy użyciu predykatu do ich oddzielenia.
    ///
    /// Predykat jest wywoływany na dwóch elementach następujących po sobie, co oznacza, że predykat jest wywoływany na `slice[0]` i `slice[1]`, a następnie na `slice[1]` i `slice[2]` i tak dalej.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ta metoda może być użyta do wyodrębnienia posortowanych podklasków:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Dzieli jeden plasterek na dwa pod indeksem.
    ///
    /// Pierwszy będzie zawierał wszystkie indeksy z `[0, mid)` (z wyłączeniem samego indeksu `mid`), a drugi będzie zawierał wszystkie indeksy z `[mid, len)` (z wyłączeniem samego indeksu `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // BEZPIECZEŃSTWO: `[ptr; mid]` i `[mid; len]` znajdują się wewnątrz `self`, które
        // spełnia wymagania `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Dzieli jeden zmienny wycinek na dwa pod indeksem.
    ///
    /// Pierwszy będzie zawierał wszystkie indeksy z `[0, mid)` (z wyłączeniem samego indeksu `mid`), a drugi będzie zawierał wszystkie indeksy z `[mid, len)` (z wyłączeniem samego indeksu `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // BEZPIECZEŃSTWO: `[ptr; mid]` i `[mid; len]` znajdują się wewnątrz `self`, które
        // spełnia wymagania `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Dzieli jeden plasterek na dwa w indeksie, bez sprawdzania granic.
    ///
    /// Pierwszy będzie zawierał wszystkie indeksy z `[0, mid)` (z wyłączeniem samego indeksu `mid`), a drugi będzie zawierał wszystkie indeksy z `[mid, len)` (z wyłączeniem samego indeksu `len`).
    ///
    ///
    /// Aby uzyskać bezpieczną alternatywę, zobacz [`split_at`].
    ///
    /// # Safety
    ///
    /// Wywołanie tej metody z indeksem spoza zakresu jest *[niezdefiniowane zachowanie]*, nawet jeśli wynikowe odwołanie nie jest używane.Dzwoniący musi upewnić się, że `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // BEZPIECZEŃSTWO: dzwoniący musi sprawdzić, czy `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Dzieli jeden zmienny wycinek na dwa w indeksie, bez sprawdzania granic.
    ///
    /// Pierwszy będzie zawierał wszystkie indeksy z `[0, mid)` (z wyłączeniem samego indeksu `mid`), a drugi będzie zawierał wszystkie indeksy z `[mid, len)` (z wyłączeniem samego indeksu `len`).
    ///
    ///
    /// Aby uzyskać bezpieczną alternatywę, zobacz [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Wywołanie tej metody z indeksem spoza zakresu jest *[niezdefiniowane zachowanie]*, nawet jeśli wynikowe odwołanie nie jest używane.Dzwoniący musi upewnić się, że `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // BEZPIECZEŃSTWO: dzwoniący musi sprawdzić, czy `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` i `[mid; len]` nie nakładają się, więc zwrócenie zmiennego odniesienia jest w porządku.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Zwraca iterator po fragmentach podrzędnych oddzielonych elementami pasującymi do `pred`.
    /// Dopasowany element nie jest zawarty w elementach podrzędnych.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Jeśli pierwszy element zostanie dopasowany, pusty wycinek będzie pierwszym elementem zwróconym przez iterator.
    /// Podobnie, jeśli dopasowany jest ostatni element w wycinku, pusty wycinek będzie ostatnim elementem zwróconym przez iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Jeśli dwa dopasowane elementy znajdują się bezpośrednio obok siebie, między nimi pojawi się pusty plasterek:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Zwraca iterator po modyfikowalnych podklasach oddzielonych elementami, które pasują do `pred`.
    /// Dopasowany element nie jest zawarty w elementach podrzędnych.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Zwraca iterator po fragmentach podrzędnych oddzielonych elementami pasującymi do `pred`.
    /// Dopasowany element znajduje się na końcu poprzedniej pod-kratki jako terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Jeśli ostatni element wycinka jest dopasowany, ten element będzie traktowany jako terminator poprzedniego wycinka.
    ///
    /// Ten wycinek będzie ostatnim elementem zwróconym przez iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Zwraca iterator po modyfikowalnych podklasach oddzielonych elementami, które pasują do `pred`.
    /// Dopasowany element jest zawarty w poprzedniej części podrzędnej jako terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Zwraca iterator nad fragmentami podrzędnymi oddzielonymi elementami pasującymi do `pred`, zaczynając od końca wycinka i działając wstecz.
    /// Dopasowany element nie jest zawarty w elementach podrzędnych.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Podobnie jak w `split()`, jeśli dopasowany jest pierwszy lub ostatni element, pusty wycinek będzie pierwszym (lub ostatnim) elementem zwróconym przez iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Zwraca iterator nad modyfikowalnymi fragmentami podrzędnymi oddzielonymi elementami pasującymi do `pred`, zaczynając od końca wycinka i działając wstecz.
    /// Dopasowany element nie jest zawarty w elementach podrzędnych.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Zwraca iterator po fragmentach podrzędnych oddzielonych elementami pasującymi do `pred`, z ograniczeniem do zwracania co najwyżej elementów `n`.
    /// Dopasowany element nie jest zawarty w elementach podrzędnych.
    ///
    /// Ostatni zwrócony element, jeśli istnieje, będzie zawierał pozostałą część wycinka.
    ///
    /// # Examples
    ///
    /// Wydrukuj wycinek podzielony raz na liczby podzielne przez 3 (np. `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Zwraca iterator po fragmentach podrzędnych oddzielonych elementami pasującymi do `pred`, z ograniczeniem do zwracania co najwyżej elementów `n`.
    /// Dopasowany element nie jest zawarty w elementach podrzędnych.
    ///
    /// Ostatni zwrócony element, jeśli istnieje, będzie zawierał pozostałą część wycinka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Zwraca iterator nad podklasami oddzielonymi elementami, które pasują do `pred`, ograniczone do zwracania maksymalnie elementów `n`.
    /// Zaczyna się na końcu plasterka i działa wstecz.
    /// Dopasowany element nie jest zawarty w elementach podrzędnych.
    ///
    /// Ostatni zwrócony element, jeśli istnieje, będzie zawierał pozostałą część wycinka.
    ///
    /// # Examples
    ///
    /// Wydrukuj raz podzielony wycinek, zaczynając od końca, według liczb podzielnych przez 3 (tj. `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Zwraca iterator nad podklasami oddzielonymi elementami, które pasują do `pred`, ograniczone do zwracania maksymalnie elementów `n`.
    /// Zaczyna się na końcu plasterka i działa wstecz.
    /// Dopasowany element nie jest zawarty w elementach podrzędnych.
    ///
    /// Ostatni zwrócony element, jeśli istnieje, będzie zawierał pozostałą część wycinka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Zwraca `true`, jeśli wycinek zawiera element o podanej wartości.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Jeśli nie masz `&T`, ale tylko `&U`, taki jak `T: Borrow<U>` (np
    /// `Ciąg: Pożycz<str>`), możesz użyć `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // kawałek `String`
    /// assert!(v.iter().any(|e| e == "hello")); // szukaj za pomocą `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Zwraca `true`, jeśli `needle` jest przedrostkiem wycinka.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Zawsze zwraca `true`, jeśli `needle` jest pustym plasterkiem:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Zwraca `true`, jeśli `needle` jest sufiksem wycinka.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Zawsze zwraca `true`, jeśli `needle` jest pustym plasterkiem:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Zwraca element podrzędny z usuniętym przedrostkiem.
    ///
    /// Jeśli wycinek zaczyna się od `prefix`, zwraca podklaskę po prefiksie, opakowaną w `Some`.
    /// Jeśli `prefix` jest pusty, po prostu zwraca oryginalny wycinek.
    ///
    /// Jeśli wycinek nie zaczyna się od `prefix`, zwraca `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ta funkcja będzie wymagała przepisania, jeśli i kiedy SlicePattern stanie się bardziej wyrafinowana.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Zwraca podklaskę z usuniętym sufiksem.
    ///
    /// Jeśli wycinek kończy się na `suffix`, zwraca podklaskę przed przyrostkiem, opakowaną w `Some`.
    /// Jeśli `suffix` jest pusty, po prostu zwraca oryginalny wycinek.
    ///
    /// Jeśli wycinek nie kończy się na `suffix`, zwraca `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ta funkcja będzie wymagała przepisania, jeśli i kiedy SlicePattern stanie się bardziej wyrafinowana.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binarny przeszukuje posortowany wycinek dla danego elementu.
    ///
    /// Jeśli wartość zostanie znaleziona, zwracany jest [`Result::Ok`], zawierający indeks pasującego elementu.
    /// Jeśli jest wiele dopasowań, można zwrócić dowolne z dopasowań.
    /// Jeśli wartość nie zostanie znaleziona, zwracany jest [`Result::Err`] zawierający indeks, do którego można wstawić pasujący element, zachowując posortowaną kolejność.
    ///
    ///
    /// Zobacz także [`binary_search_by`], [`binary_search_by_key`] i [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Wyszukuje serię czterech elementów.
    /// Pierwszy zostaje znaleziony, z jednoznacznie określoną pozycją;nie znaleziono drugiego i trzeciego;czwarty może pasować do dowolnej pozycji w `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Jeśli chcesz wstawić element do posortowanego vector, zachowując porządek sortowania:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binarny przeszukuje posortowany wycinek z funkcją komparatora.
    ///
    /// Funkcja komparatora powinna implementować kolejność zgodną z porządkiem sortowania podstawowego wycinka, zwracając kod kolejności wskazujący, czy jej argumentem jest `Less`, `Equal` lub `Greater` żądany cel.
    ///
    ///
    /// Jeśli wartość zostanie znaleziona, zwracany jest [`Result::Ok`], zawierający indeks pasującego elementu.Jeśli jest wiele dopasowań, można zwrócić dowolne z dopasowań.
    /// Jeśli wartość nie zostanie znaleziona, zwracany jest [`Result::Err`] zawierający indeks, do którego można wstawić pasujący element, zachowując posortowaną kolejność.
    ///
    /// Zobacz także [`binary_search`], [`binary_search_by_key`] i [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Wyszukuje serię czterech elementów.Pierwszy zostaje znaleziony, z jednoznacznie określoną pozycją;nie znaleziono drugiego i trzeciego;czwarty może pasować do dowolnej pozycji w `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // BEZPIECZEŃSTWO: połączenie jest zabezpieczone przez następujące niezmienniki:
            // - `mid >= 0`
            // - `mid < size`: `mid` jest ograniczone przez `[left; right)`.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Powodem, dla którego używamy przepływu sterowania if/else zamiast dopasowania, jest to, że dopasowywanie zmienia kolejność operacji porównywania, które są perfekcyjne.
            //
            // To jest x86 asm dla u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binarny przeszukuje ten posortowany wycinek za pomocą funkcji wyodrębniania klucza.
    ///
    /// Zakłada, że wycinek jest posortowany według klucza, na przykład [`sort_by_key`] używa tej samej funkcji wyodrębniania klucza.
    ///
    /// Jeśli wartość zostanie znaleziona, zwracany jest [`Result::Ok`], zawierający indeks pasującego elementu.
    /// Jeśli jest wiele dopasowań, można zwrócić dowolne z dopasowań.
    /// Jeśli wartość nie zostanie znaleziona, zwracany jest [`Result::Err`] zawierający indeks, do którego można wstawić pasujący element, zachowując posortowaną kolejność.
    ///
    ///
    /// Zobacz także [`binary_search`], [`binary_search_by`] i [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Wyszukuje serię czterech elementów w kawałku par posortowanych według drugich elementów.
    /// Pierwszy zostaje znaleziony, z jednoznacznie określoną pozycją;nie znaleziono drugiego i trzeciego;czwarty może pasować do dowolnej pozycji w `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links jest dozwolony, ponieważ `slice::sort_by_key` jest w crate `alloc` i jako taki nie istnieje jeszcze podczas budowania `core`.
    //
    // łącza do podrzędnego crate: #74481.Ponieważ prymitywy są dokumentowane tylko w libstd (#73423), w praktyce nigdy nie prowadzi to do zerwania łączy.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Sortuje wycinek, ale może nie zachowywać kolejności równych elementów.
    ///
    /// To sortowanie jest niestabilne (tj. Może zmienić kolejność równych elementów), w miejscu (tj. Nie alokuje) i *O*(*n*\*log(* n*)) w najgorszym przypadku.
    ///
    /// # Bieżąca realizacja
    ///
    /// Obecny algorytm jest oparty na [pattern-defeating quicksort][pdqsort] autorstwa Orsona Petersa, który łączy szybki średni przypadek losowego sortowania szybkiego z najszybszym najgorszym przypadkiem sortowania, przy jednoczesnym osiąganiu czasu liniowego na plasterkach o określonych wzorach.
    /// Używa pewnej randomizacji, aby uniknąć zdegenerowanych przypadków, ale ze stałym seed, aby zawsze zapewniać deterministyczne zachowanie.
    ///
    /// Zwykle jest szybsze niż sortowanie stabilne, z wyjątkiem kilku specjalnych przypadków, np. Gdy wycinek składa się z kilku połączonych posortowanych sekwencji.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Sortuje wycinek za pomocą funkcji komparatora, ale może nie zachowywać kolejności równych elementów.
    ///
    /// To sortowanie jest niestabilne (tj. Może zmienić kolejność równych elementów), w miejscu (tj. Nie alokuje) i *O*(*n*\*log(* n*)) w najgorszym przypadku.
    ///
    /// Funkcja komparatora musi definiować całkowitą kolejność elementów w wycinku.Jeśli kolejność nie jest całkowita, kolejność elementów jest nieokreślona.Zamówienie jest zamówieniem całkowitym, jeśli tak jest (dla wszystkich `a`, `b` i `c`):
    ///
    /// * całkowity i antysymetryczny: dokładnie jeden z `a < b`, `a == b` lub `a > b` jest prawdziwy i
    /// * przechodnia, `a < b` i `b < c` implikuje `a < c`.To samo musi dotyczyć zarówno `==`, jak i `>`.
    ///
    /// Na przykład, chociaż [`f64`] nie implementuje [`Ord`], ponieważ `NaN != NaN`, możemy użyć `partial_cmp` jako naszej funkcji sortowania, gdy wiemy, że wycinek nie zawiera `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Bieżąca realizacja
    ///
    /// Obecny algorytm jest oparty na [pattern-defeating quicksort][pdqsort] autorstwa Orsona Petersa, który łączy szybki średni przypadek losowego sortowania szybkiego z najszybszym najgorszym przypadkiem sortowania, przy jednoczesnym osiąganiu czasu liniowego na plasterkach o określonych wzorach.
    /// Używa pewnej randomizacji, aby uniknąć zdegenerowanych przypadków, ale ze stałym seed, aby zawsze zapewniać deterministyczne zachowanie.
    ///
    /// Zwykle jest szybsze niż sortowanie stabilne, z wyjątkiem kilku specjalnych przypadków, np. Gdy wycinek składa się z kilku połączonych posortowanych sekwencji.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // sortowanie odwrotne
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Sortuje wycinek za pomocą funkcji wyodrębniania klucza, ale może nie zachowywać kolejności równych elementów.
    ///
    /// To sortowanie jest niestabilne (tzn. Może zmienić kolejność równych elementów), w miejscu (tj. Nie alokuje) i *O*(m\* * n *\* log(*n*)) w najgorszym przypadku, gdzie funkcja klucza to *O*(*m*).
    ///
    /// # Bieżąca realizacja
    ///
    /// Obecny algorytm jest oparty na [pattern-defeating quicksort][pdqsort] autorstwa Orsona Petersa, który łączy szybki średni przypadek losowego sortowania szybkiego z najszybszym najgorszym przypadkiem sortowania, przy jednoczesnym osiąganiu czasu liniowego na plasterkach o określonych wzorach.
    /// Używa pewnej randomizacji, aby uniknąć zdegenerowanych przypadków, ale ze stałym seed, aby zawsze zapewniać deterministyczne zachowanie.
    ///
    /// Ze względu na strategię wywoływania kluczy [`sort_unstable_by_key`](#method.sort_unstable_by_key) prawdopodobnie będzie wolniejszy niż [`sort_by_cached_key`](#method.sort_by_cached_key) w przypadkach, gdy funkcja klucza jest droga.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Zmień kolejność wycinka tak, aby element w `index` znalazł się w ostatecznej posortowanej pozycji.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Zmień kolejność wycinka za pomocą funkcji komparatora, tak aby element w `index` znalazł się w ostatecznej posortowanej pozycji.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Zmień kolejność wycinka za pomocą funkcji wyodrębniania klucza tak, aby element w `index` znalazł się w ostatecznej posortowanej pozycji.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Zmień kolejność wycinka tak, aby element w `index` znalazł się w ostatecznej posortowanej pozycji.
    ///
    /// Ta zmiana kolejności ma dodatkową właściwość polegającą na tym, że każda wartość w pozycji `i < index` będzie mniejsza lub równa dowolnej wartości w pozycji `j > index`.
    /// Ponadto ta zmiana kolejności jest niestabilna (tj
    /// dowolna liczba równych elementów może znaleźć się na pozycji `index`), na miejscu (tj
    /// nie alokuje) i *O*(*n*) w najgorszym przypadku.
    /// Ta funkcja jest również/znana jako "kth element" w innych bibliotekach.
    /// Zwraca tryplet następujących wartości: wszystkie elementy mniejsze niż jeden przy danym indeksie, wartość przy danym indeksie i wszystkie elementy większe niż ten przy danym indeksie.
    ///
    ///
    /// # Bieżąca realizacja
    ///
    /// Bieżący algorytm jest oparty na części szybkiego wyboru tego samego algorytmu szybkiego sortowania używanego w [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, gdy `index >= len()`, co oznacza, że zawsze panics na pustych plasterkach.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Znajdź medianę
    /// v.select_nth_unstable(2);
    ///
    /// // Gwarantujemy tylko, że wycinek będzie jednym z poniższych, w zależności od sposobu sortowania według określonego indeksu.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Zmień kolejność wycinka za pomocą funkcji komparatora, tak aby element w `index` znalazł się w ostatecznej posortowanej pozycji.
    ///
    /// Ta zmiana kolejności ma dodatkową właściwość polegającą na tym, że dowolna wartość w pozycji `i < index` będzie mniejsza lub równa dowolnej wartości w pozycji `j > index` przy użyciu funkcji komparatora.
    /// Ponadto zmiana kolejności jest niestabilna (tj. Dowolna liczba równych elementów może znaleźć się na pozycji `index`), lokalna (tj. Nie alokuje) i *O*(*n*) w najgorszym przypadku.
    /// Ta funkcja jest również znana jako "kth element" w innych bibliotekach.
    /// Zwraca tryplet następujących wartości: wszystkie elementy mniejsze niż ten pod danym indeksem, wartość pod danym indeksem i wszystkie elementy większe niż ten pod danym indeksem, przy użyciu podanej funkcji komparatora.
    ///
    ///
    /// # Bieżąca realizacja
    ///
    /// Bieżący algorytm jest oparty na części szybkiego wyboru tego samego algorytmu szybkiego sortowania używanego w [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, gdy `index >= len()`, co oznacza, że zawsze panics na pustych plasterkach.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Znajdź medianę tak, jakby wycinki zostały posortowane w porządku malejącym.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Gwarantujemy tylko, że wycinek będzie jednym z poniższych, w zależności od sposobu sortowania według określonego indeksu.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Zmień kolejność wycinka za pomocą funkcji wyodrębniania klucza tak, aby element w `index` znalazł się w ostatecznej posortowanej pozycji.
    ///
    /// Ta zmiana kolejności ma dodatkową właściwość polegającą na tym, że dowolna wartość w pozycji `i < index` będzie mniejsza lub równa dowolnej wartości w pozycji `j > index` przy użyciu funkcji wyodrębniania klucza.
    /// Ponadto zmiana kolejności jest niestabilna (tj. Dowolna liczba równych elementów może znaleźć się na pozycji `index`), lokalna (tj. Nie alokuje) i *O*(*n*) w najgorszym przypadku.
    /// Ta funkcja jest również znana jako "kth element" w innych bibliotekach.
    /// Zwraca tryplet następujących wartości: wszystkie elementy mniejsze niż jeden pod danym indeksem, wartość pod danym indeksem i wszystkie elementy większe niż jeden pod danym indeksem, przy użyciu dostarczonej funkcji wyodrębniania klucza.
    ///
    ///
    /// # Bieżąca realizacja
    ///
    /// Bieżący algorytm jest oparty na części szybkiego wyboru tego samego algorytmu szybkiego sortowania używanego w [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, gdy `index >= len()`, co oznacza, że zawsze panics na pustych plasterkach.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Zwróć medianę tak, jakby tablica została posortowana według wartości bezwzględnej.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Gwarantujemy tylko, że wycinek będzie jednym z poniższych, w zależności od sposobu sortowania według określonego indeksu.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Przenosi wszystkie kolejne powtarzające się elementy na koniec wycinka zgodnie z implementacją [`PartialEq`] trait.
    ///
    ///
    /// Zwraca dwa wycinki.Pierwsza nie zawiera kolejnych powtarzających się elementów.
    /// Druga zawiera wszystkie duplikaty w nieokreślonej kolejności.
    ///
    /// Jeśli plasterek jest posortowany, pierwszy zwrócony wycinek nie zawiera duplikatów.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Przenosi wszystkie kolejne elementy oprócz pierwszego na koniec wycinka spełniającego daną relację równości.
    ///
    /// Zwraca dwa wycinki.Pierwsza nie zawiera kolejnych powtarzających się elementów.
    /// Druga zawiera wszystkie duplikaty w nieokreślonej kolejności.
    ///
    /// Do funkcji `same_bucket` przekazywane są odwołania do dwóch elementów z wycinka i musi ona określić, czy elementy są równe.
    /// Elementy są przekazywane w odwrotnej kolejności niż ich kolejność w wycinku, więc jeśli `same_bucket(a, b)` zwraca `true`, `a` jest przesuwany na końcu wycinka.
    ///
    ///
    /// Jeśli plasterek jest posortowany, pierwszy zwrócony wycinek nie zawiera duplikatów.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Chociaż mamy zmienne odniesienie do `self`, nie możemy dokonywać *arbitralnych* zmian.Wywołania `same_bucket` mogą panic, więc musimy upewnić się, że wycinek jest cały czas w prawidłowym stanie.
        //
        // Sposób, w jaki sobie z tym radzimy, polega na użyciu zamiany;iterujemy po wszystkich elementach, zamieniając się w trakcie, aby na końcu elementy, które chcemy zachować, znajdowały się z przodu, a te, które chcemy odrzucić, z tyłu.
        // Następnie możemy podzielić plasterek.
        // Ta operacja to nadal `O(n)`.
        //
        // Przykład: Zaczynamy w tym stanie, gdzie `r` oznacza " następny`
        // read ", a `w` reprezentuje" next_write ".
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Porównując self[r] z self [w-1], nie jest to duplikat, więc zamieniamy self[r] i self[w] (bez efektu jako r==w), a następnie zwiększamy oba r i w, pozostawiając nam:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Porównując self[r] z self [w-1], ta wartość jest duplikatem, więc zwiększamy `r`, ale pozostawiamy wszystko inne niezmienione:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Porównując self[r] ze sobą [w-1], nie jest to duplikat, więc zamień self[r] i self[w] i przejdź do przodu r i w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // To nie jest duplikat, powtórz:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplikat, advance r. End wycinka.Podziel na w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // BEZPIECZEŃSTWO: stan `while` gwarantuje `next_read` i `next_write`
        // są mniejsze niż `len`, więc znajdują się wewnątrz `self`.
        // `prev_ptr_write` wskazuje na jeden element przed `ptr_write`, ale `next_write` zaczyna się od 1, więc `prev_ptr_write` nigdy nie jest mniejsze niż 0 i znajduje się wewnątrz wycinka.
        // Spełnia to wymagania dotyczące wyłuskiwania `ptr_read`, `prev_ptr_write` i `ptr_write` oraz korzystania z `ptr.add(next_read)`, `ptr.add(next_write - 1)` i `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` jest również zwiększany co najwyżej raz na pętlę, co oznacza, że żaden element nie jest pomijany, gdy może zajść potrzeba zamiany.
        //
        // `ptr_read` i `prev_ptr_write` nigdy nie wskazują na ten sam element.Jest to wymagane, aby `&mut *ptr_read`, `&mut* prev_ptr_write` były bezpieczne.
        // Wyjaśnienie jest po prostu takie, że `next_read >= next_write` jest zawsze prawdziwe, a więc `next_read > next_write - 1` też.
        //
        //
        //
        //
        //
        unsafe {
            // Unikaj sprawdzania granic, używając surowych wskaźników.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Przenosi wszystkie kolejne elementy oprócz pierwszego z kolejnych elementów na koniec wycinka, który jest rozpoznawany do tego samego klucza.
    ///
    ///
    /// Zwraca dwa wycinki.Pierwsza nie zawiera kolejnych powtarzających się elementów.
    /// Druga zawiera wszystkie duplikaty w nieokreślonej kolejności.
    ///
    /// Jeśli plasterek jest posortowany, pierwszy zwrócony wycinek nie zawiera duplikatów.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Obraca plasterek w miejscu w taki sposób, że pierwsze elementy `mid` plasterka przesuwają się na koniec, a ostatnie elementy `self.len() - mid` na przód.
    /// Po wywołaniu `rotate_left`, element znajdujący się wcześniej pod indeksem `mid` stanie się pierwszym elementem w wycinku.
    ///
    /// # Panics
    ///
    /// Ta funkcja zwróci panic, jeśli `mid` jest większe niż długość wycinka.Zauważ, że `mid == self.len()` robi _not_ panic i jest obrotem bez operacji.
    ///
    /// # Complexity
    ///
    /// Trwa liniowo (w czasie `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Obracanie podklasku:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // BEZPIECZEŃSTWO: seria `[p.add(mid) - mid, p.add(mid) + k)` jest trywialna
        // obowiązuje do czytania i pisania, zgodnie z wymaganiami `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Obraca plasterek w miejscu w taki sposób, że pierwsze elementy `self.len() - k` plasterka przesuwają się na koniec, a ostatnie elementy `k` na przód.
    /// Po wywołaniu `rotate_right`, element znajdujący się wcześniej pod indeksem `self.len() - k` stanie się pierwszym elementem w wycinku.
    ///
    /// # Panics
    ///
    /// Ta funkcja zwróci panic, jeśli `k` jest większe niż długość wycinka.Zauważ, że `k == self.len()` robi _not_ panic i jest obrotem bez operacji.
    ///
    /// # Complexity
    ///
    /// Trwa liniowo (w czasie `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Obróć podklaskę:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // BEZPIECZEŃSTWO: seria `[p.add(mid) - mid, p.add(mid) + k)` jest trywialna
        // obowiązuje do czytania i pisania, zgodnie z wymaganiami `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Wypełnia `self` elementami przez klonowanie `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Wypełnia `self` elementami zwracanymi przez wielokrotne wywoływanie zamknięcia.
    ///
    /// Ta metoda używa zamknięcia do tworzenia nowych wartości.Jeśli wolisz [`Clone`] daną wartość, użyj [`fill`].
    /// Jeśli chcesz użyć [`Default`] trait do generowania wartości, możesz przekazać [`Default::default`] jako argument.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopiuje elementy z `src` do `self`.
    ///
    /// Długość `src` musi być taka sama jak `self`.
    ///
    /// Jeśli `T` implementuje `Copy`, bardziej wydajne może być użycie [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ta funkcja spowoduje panic, jeśli dwa plastry mają różne długości.
    ///
    /// # Examples
    ///
    /// Klonowanie dwóch elementów z plasterka do innego:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ponieważ plasterki muszą mieć tę samą długość, kroimy plasterek źródłowy z czterech na dwa.
    /// // Będzie panic, jeśli tego nie zrobimy.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust wymusza, że może istnieć tylko jedno zmienne odniesienie bez niezmiennych odwołań do określonego fragmentu danych w określonym zakresie.
    /// Z tego powodu próba użycia `clone_from_slice` na pojedynczym wycinku zakończy się niepowodzeniem kompilacji:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Aby obejść ten problem, możemy użyć [`split_at_mut`] do utworzenia dwóch odrębnych pod-plasterków z plasterka:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopiuje wszystkie elementy z `src` do `self` przy użyciu memcpy.
    ///
    /// Długość `src` musi być taka sama jak `self`.
    ///
    /// Jeśli `T` nie implementuje `Copy`, użyj [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Ta funkcja spowoduje panic, jeśli dwa plastry mają różne długości.
    ///
    /// # Examples
    ///
    /// Kopiowanie dwóch elementów z plasterka do innego:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ponieważ plasterki muszą mieć tę samą długość, kroimy plasterek źródłowy z czterech na dwa.
    /// // Będzie panic, jeśli tego nie zrobimy.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust wymusza, że może istnieć tylko jedno zmienne odniesienie bez niezmiennych odwołań do określonego fragmentu danych w określonym zakresie.
    /// Z tego powodu próba użycia `copy_from_slice` na pojedynczym wycinku zakończy się niepowodzeniem kompilacji:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Aby obejść ten problem, możemy użyć [`split_at_mut`] do utworzenia dwóch odrębnych pod-plasterków z plasterka:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Ścieżka kodu panic została umieszczona w zimnej funkcji, aby nie nadużywać witryny wywołania.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // BEZPIECZEŃSTWO: `self` jest z definicji ważne dla elementów `self.len()`, a `src` było
        // zaznaczone, aby mieć tę samą długość.
        // Plasterki nie mogą się nakładać, ponieważ zmienne odwołania są wyłączne.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopiuje elementy z jednej części plasterka do innej części samego siebie, używając memmove.
    ///
    /// `src` to zakres w `self` do skopiowania.
    /// `dest` jest początkowym indeksem zakresu w `self` do skopiowania, który będzie miał taką samą długość jak `src`.
    /// Te dwa zakresy mogą się pokrywać.
    /// Końce dwóch zakresów muszą być mniejsze lub równe `self.len()`.
    ///
    /// # Panics
    ///
    /// Ta funkcja zwróci panic, jeśli którykolwiek zakres przekracza koniec wycinka lub jeśli koniec `src` jest przed początkiem.
    ///
    ///
    /// # Examples
    ///
    /// Kopiowanie czterech bajtów w plasterku:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // BEZPIECZEŃSTWO: wszystkie warunki dla `ptr::copy` zostały sprawdzone powyżej,
        // podobnie jak te dla `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Zamienia wszystkie elementy w `self` z tymi w `other`.
    ///
    /// Długość `other` musi być taka sama jak `self`.
    ///
    /// # Panics
    ///
    /// Ta funkcja spowoduje panic, jeśli dwa plastry mają różne długości.
    ///
    /// # Example
    ///
    /// Zamiana dwóch elementów na plasterkach:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust wymusza, że może istnieć tylko jedno zmienne odniesienie do określonego fragmentu danych w określonym zakresie.
    ///
    /// Z tego powodu próba użycia `swap_with_slice` na pojedynczym wycinku zakończy się niepowodzeniem kompilacji:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Aby obejść ten problem, możemy użyć [`split_at_mut`] do utworzenia dwóch odrębnych modyfikowalnych pod-plasterków z plastra:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // BEZPIECZEŃSTWO: `self` jest z definicji ważne dla elementów `self.len()`, a `src` było
        // zaznaczone, aby mieć tę samą długość.
        // Plasterki nie mogą się nakładać, ponieważ zmienne odwołania są wyłączne.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funkcja do obliczania długości środkowego i końcowego wycinka dla `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // To, co zrobimy z `rest`, to dowiedzieć się, jaką wielokrotność " U`możemy wstawić do najmniejszej liczby " T`.
        //
        // A ile `` T '' potrzebujemy na każdy taki "multiple".
        //
        // Rozważmy na przykład T=u8 U=u16.Wtedy możemy wstawić 1 U w 2 Ts.Prosty.
        // Rozważmy teraz na przykład przypadek, w którym size_of: :<T>=16, rozmiar_z::<U>=24.</u>
        // Możemy wstawić 2 Us na miejsce każdych 3 Ts w wycinku `rest`.
        // Nieco bardziej skomplikowane.
        //
        // Wzór do obliczenia tego jest następujący:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Rozszerzony i uproszczony:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Na szczęście, ponieważ wszystko to podlega ciągłej ocenie ... wydajność tutaj nie ma znaczenia!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iteracyjny algorytm steina Powinniśmy nadal tworzyć ten `const fn` (i powrócić do algorytmu rekurencyjnego, jeśli to zrobimy), ponieważ poleganie na llvm do konstewności tego wszystkiego jest…cóż, czuję się nieswojo.
            //
            //

            // BEZPIECZEŃSTWO: `a` i `b` są sprawdzane jako wartości niezerowe.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // usuń wszystkie czynniki 2 z b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // BEZPIECZEŃSTWO: `b` jest sprawdzane jako niezerowe.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Uzbrojeni w tę wiedzę, możemy dowiedzieć się, ilu `U`s możemy pomieścić!
        let us_len = self.len() / ts * us;
        // A ile " T` będzie w końcowym wycinku!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Przekształć plasterek w plasterek innego typu, upewniając się, że wyrównanie typów zostanie zachowane.
    ///
    /// Ta metoda dzieli plasterek na trzy odrębne plasterki: prefiks, poprawnie wyrównany środkowy plasterek nowego typu i przyrostek.
    /// Metoda może sprawić, że środkowy wycinek będzie miał największą możliwą długość dla danego typu i segmentu wejściowego, ale od tego powinna zależeć tylko wydajność algorytmu, a nie jego poprawność.
    ///
    /// Dozwolone jest, aby wszystkie dane wejściowe były zwracane jako segment prefiksu lub sufiksu.
    ///
    /// Ta metoda jest bezcelowa, gdy element wejściowy `T` lub element wyjściowy `U` mają zerowy rozmiar i zwracają oryginalny wycinek bez dzielenia czegokolwiek.
    ///
    /// # Safety
    ///
    /// Ta metoda jest zasadniczo `transmute` w odniesieniu do elementów w zwróconym środkowym wycinku, więc wszystkie zwykłe zastrzeżenia dotyczące `transmute::<T, U>` mają również zastosowanie tutaj.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Zauważ, że większość tej funkcji będzie obliczana na stałe,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // obsługuj ZST specjalnie, czyli-nie obsługuj ich w ogóle.
            return (self, &[], &[]);
        }

        // Najpierw sprawdź, w którym momencie dzielimy się między pierwszym a drugim wycinkiem.
        // Łatwo z ptr.align_offset.
        let ptr = self.as_ptr();
        // BEZPIECZEŃSTWO: szczegółowe uwagi dotyczące bezpieczeństwa można znaleźć w metodzie `align_to_mut`.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // BEZPIECZEŃSTWO: teraz `rest` jest zdecydowanie wyrównany, więc `from_raw_parts` poniżej jest w porządku,
            // ponieważ dzwoniący gwarantuje, że możemy bezpiecznie transmutować `T` do `U`.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Przekształć plasterek w plasterek innego typu, upewniając się, że wyrównanie typów zostanie zachowane.
    ///
    /// Ta metoda dzieli plasterek na trzy odrębne plasterki: prefiks, poprawnie wyrównany środkowy plasterek nowego typu i przyrostek.
    /// Metoda może sprawić, że środkowy wycinek będzie miał największą możliwą długość dla danego typu i segmentu wejściowego, ale od tego powinna zależeć tylko wydajność algorytmu, a nie jego poprawność.
    ///
    /// Dozwolone jest, aby wszystkie dane wejściowe były zwracane jako segment prefiksu lub sufiksu.
    ///
    /// Ta metoda jest bezcelowa, gdy element wejściowy `T` lub element wyjściowy `U` mają zerowy rozmiar i zwracają oryginalny wycinek bez dzielenia czegokolwiek.
    ///
    /// # Safety
    ///
    /// Ta metoda jest zasadniczo `transmute` w odniesieniu do elementów w zwróconym środkowym wycinku, więc wszystkie zwykłe zastrzeżenia dotyczące `transmute::<T, U>` mają również zastosowanie tutaj.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Zauważ, że większość tej funkcji będzie obliczana na stałe,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // obsługuj ZST specjalnie, czyli-nie obsługuj ich w ogóle.
            return (self, &mut [], &mut []);
        }

        // Najpierw sprawdź, w którym momencie dzielimy się między pierwszym a drugim wycinkiem.
        // Łatwo z ptr.align_offset.
        let ptr = self.as_ptr();
        // BEZPIECZEŃSTWO: tutaj zapewniamy, że użyjemy wyrównanych wskaźników dla U dla
        // reszta metody.Odbywa się to poprzez przekazanie wskaźnika do&[T] z wyrównaniem skierowanym na U.
        // `crate::ptr::align_offset` jest wywoływana z prawidłowo wyrównanym i poprawnym wskaźnikiem `ptr` (pochodzi z odniesienia do `self`) i ma rozmiar będący potęgą dwójki (ponieważ pochodzi z wyrównania dla U), spełniając jego ograniczenia bezpieczeństwa.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Po tym nie możemy ponownie użyć `rest`, co unieważniłoby jego alias `mut_ptr`!BEZPIECZEŃSTWO: patrz komentarze do `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Sprawdza, czy elementy tego wycinka są posortowane.
    ///
    /// Oznacza to, że dla każdego elementu `a` i następującego po nim elementu `b`, `a <= b` musi się utrzymywać.Jeśli wycinek daje dokładnie zero lub jeden element, zwracane jest `true`.
    ///
    /// Zauważ, że jeśli `Self::Item` to tylko `PartialOrd`, ale nie `Ord`, powyższa definicja oznacza, że ta funkcja zwraca `false`, jeśli jakiekolwiek dwa kolejne elementy nie są porównywalne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Sprawdza, czy elementy tego wycinka są posortowane przy użyciu podanej funkcji komparatora.
    ///
    /// Zamiast używać `PartialOrd::partial_cmp`, ta funkcja używa podanej funkcji `compare` do określenia kolejności dwóch elementów.
    /// Poza tym jest odpowiednikiem [`is_sorted`];zobacz dokumentację, aby uzyskać więcej informacji.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Sprawdza, czy elementy tego wycinka są posortowane przy użyciu podanej funkcji wyodrębniania klucza.
    ///
    /// Zamiast bezpośrednio porównywać elementy wycinka, ta funkcja porównuje klucze elementów, określone przez `f`.
    /// Poza tym jest odpowiednikiem [`is_sorted`];zobacz dokumentację, aby uzyskać więcej informacji.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Zwraca indeks rozcięcia zgodnie z podanym predykatem (indeks pierwszego elementu drugiej partycji).
    ///
    /// Zakłada się, że wycinek jest podzielony zgodnie z podanym predykatem.
    /// Oznacza to, że wszystkie elementy, dla których predykat zwraca wartość true, znajdują się na początku wycinka, a wszystkie elementy, dla których predykat zwraca wartość false, znajdują się na końcu.
    ///
    /// Na przykład [7, 15, 3, 5, 4, 12, 6] jest podzielony na partycje pod predykatem x% 2!=0 (wszystkie liczby nieparzyste znajdują się na początku, wszystkie parzyste na końcu).
    ///
    /// Jeśli ten wycinek nie jest podzielony na partycje, zwrócony wynik jest nieokreślony i bez znaczenia, ponieważ ta metoda wykonuje rodzaj wyszukiwania binarnego.
    ///
    /// Zobacz także [`binary_search`], [`binary_search_by`] i [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // BEZPIECZEŃSTWO: Kiedy `left < right`, `left <= mid < right`.
            // Dlatego `left` zawsze rośnie, a `right` zawsze maleje i jeden z nich jest wybrany.W obu przypadkach `left <= right` jest spełnione.Dlatego jeśli `left < right` w jednym kroku, `left <= right` jest zadowolony w następnym kroku.
            //
            // Dlatego tak długo, jak `left != right`, `0 <= left < right <= len` jest spełnione, a jeśli w tym przypadku, `0 <= mid < len` jest również spełnione.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Musimy wyraźnie pokroić je na taką samą długość
        // aby ułatwić optymalizatorowi sprawdzanie granic.
        // Ale ponieważ nie można na nim polegać, mamy również wyraźną specjalizację dla T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Tworzy pusty plasterek.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Tworzy zmienny pusty plasterek.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Wzory w plasterkach, obecnie używane tylko przez `strip_prefix` i `strip_suffix`.
/// W punkcie future mamy nadzieję uogólnić `core::str::Pattern` (który w chwili pisania jest ograniczony do `str`) do plasterków, a następnie ten trait zostanie zastąpiony lub zniesiony.
///
pub trait SlicePattern {
    /// Typ elementu wycinka, do którego ma zostać dopasowany.
    type Item;

    /// Obecnie konsumenci `SlicePattern` potrzebują kawałka.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}