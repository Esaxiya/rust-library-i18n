//! Obsługa Panic dla libcore
//!
//! Podstawowa biblioteka nie może definiować paniki, ale *deklaruje* panikę.
//! Oznacza to, że funkcje wewnątrz libcore są dozwolone dla panic, ale aby były użyteczne, nadrzędny crate musi zdefiniować panikowanie, aby libcore mogło użyć.
//! Bieżący interfejs do panikowania to:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Ta definicja pozwala na panikowanie w przypadku dowolnego ogólnego komunikatu, ale nie pozwala na niepowodzenie z wartością `Box<Any>`.
//! (`PanicInfo` zawiera tylko `&(dyn Any + Send)`, dla którego wpisujemy wartość zastępczą w `PanicInfo: : internal_constructor`.) Powodem tego jest to, że libcore nie może alokować.
//!
//!
//! Ten moduł zawiera kilka innych funkcji panikujących, ale są to tylko niezbędne elementy lang dla kompilatora.Wszystkie panics są kierowane przez tę jedną funkcję.
//! Rzeczywisty symbol jest zadeklarowany za pomocą atrybutu `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Podstawowa implementacja makra `panic!` w bibliotece libcore, gdy nie jest używane żadne formatowanie.
#[cold]
// nigdy w tekście, chyba że panic_immediate_abort, aby w jak największym stopniu uniknąć nadużywania kodu w witrynach wywołań
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // wymagane przez codegen dla panic na przepełnieniu i innych terminatorach `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Użyj Arguments::new_v1 zamiast format_args! ("{}", Wyrażenie), aby potencjalnie zmniejszyć narzut rozmiaru.
    // Plik format_args!makro używa Display trait str do zapisu wyrażenia, które wywołuje Formatter::pad, które musi uwzględniać obcięcie i dopełnienie napisów (nawet jeśli żadne nie jest tutaj użyte).
    //
    // Użycie Arguments::new_v1 może pozwolić kompilatorowi na pominięcie Formatter::pad w wyjściowym pliku binarnym, oszczędzając do kilku kilobajtów.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // potrzebne dla panics z oceną const
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // wymagane przez codegen dla panic na dostępie OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Podstawowa implementacja makra `panic!` w bibliotece libcore podczas formatowania.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // UWAGA Ta funkcja nigdy nie przekracza granicy FFI;jest to wywołanie Rust-to-Rust, które jest tłumaczone na funkcję `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // BEZPIECZEŃSTWO: `panic_impl` jest zdefiniowany w bezpiecznym kodzie Rust i dlatego można go bezpiecznie wywołać.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Funkcja wewnętrzna dla makr `assert_eq!` i `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}