/// trait do dostosowywania zachowania operatora `?`.
///
/// Typ implementujący `Try` to taki, który ma kanoniczny sposób postrzegania go w kategoriach dychotomii success/failure.
/// Ta trait umożliwia zarówno wyodrębnienie tych wartości sukcesu lub niepowodzenia z istniejącej instancji, jak i utworzenie nowej instancji z wartości sukcesu lub niepowodzenia.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Typ tej wartości, który jest uważany za pomyślny.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Typ tej wartości, gdy jest wyświetlana jako nieudana.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Stosuje operator "?".Zwrot `Ok(t)` oznacza, że wykonanie powinno być kontynuowane normalnie, a wynikiem `?` jest wartość `t`.
    /// Zwrot `Err(e)` oznacza, że wykonanie powinno branch do najbardziej wewnętrznego otaczającego `catch` lub powrócić z funkcji.
    ///
    /// Jeśli zostanie zwrócony wynik `Err(e)`, wartością `e` będzie "wrapped" w zwracanym typie obejmującego zakresu (który sam musi implementować `Try`).
    ///
    /// W szczególności zwracana jest wartość `X::from_error(From::from(e))`, gdzie `X` jest typem zwracanym funkcji otaczającej.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Zawiń wartość błędu, aby skonstruować wynik złożony.
    /// Na przykład `Result::Err(x)` i `Result::from_error(x)` są równoważne.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Zawiń wartość OK, aby skonstruować wynik złożony.
    /// Na przykład `Result::Ok(x)` i `Result::from_ok(x)` są równoważne.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}