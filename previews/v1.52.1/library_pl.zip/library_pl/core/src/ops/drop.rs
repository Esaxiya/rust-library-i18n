/// Kod niestandardowy w destruktorze.
///
/// Gdy wartość nie jest już potrzebna, Rust uruchomi "destructor" na tej wartości.
/// Najczęstszym sposobem, w jaki wartość nie jest już potrzebna, jest sytuacja, gdy wykracza ona poza zakres.Destruktory mogą nadal działać w innych okolicznościach, ale skupimy się na zakresie przykładów tutaj.
/// Aby dowiedzieć się więcej o niektórych innych przypadkach, zobacz sekcję [the reference] dotyczącą destruktorów.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Ten destruktor składa się z dwóch komponentów:
/// - Wywołanie `Drop::drop` dla tej wartości, jeśli ten specjalny `Drop` trait jest zaimplementowany dla tego typu.
/// - Automatycznie wygenerowany "drop glue", który rekurencyjnie wywołuje destruktory wszystkich pól tej wartości.
///
/// Ponieważ Rust automatycznie wywołuje destruktory wszystkich zawartych pól, w większości przypadków nie musisz implementować `Drop`.
/// Ale są pewne przypadki, w których jest to przydatne, na przykład w przypadku typów, które bezpośrednio zarządzają zasobami.
/// Tym zasobem może być pamięć, może to być deskryptor pliku, może to być gniazdo sieciowe.
/// Gdy wartość tego typu nie będzie już używana, powinna "clean up" swój zasób, zwalniając pamięć lub zamykając plik lub gniazdo.
/// To zadanie destruktora, a więc zadanie `Drop::drop`.
///
/// ## Examples
///
/// Aby zobaczyć destruktory w akcji, spójrzmy na następujący program:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust najpierw wywoła `Drop::drop` dla `_x`, a następnie dla `_x.one` i `_x.two`, co oznacza, że uruchomienie tego wypisze
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Nawet jeśli usuniemy implementację `Drop` dla `HasTwoDrop`, destruktory jego pól są nadal wywoływane.
/// Spowodowałoby to
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Nie możesz sam zadzwonić do `Drop::drop`
///
/// Ponieważ `Drop::drop` służy do czyszczenia wartości, użycie tej wartości po wywołaniu metody może być niebezpieczne.
/// Ponieważ `Drop::drop` nie przejmuje własności swoich danych wejściowych, Rust zapobiega nadużyciom, uniemożliwiając bezpośrednie wywołanie `Drop::drop`.
///
/// Innymi słowy, jeśli spróbujesz jawnie wywołać `Drop::drop` w powyższym przykładzie, otrzymasz błąd kompilatora.
///
/// Jeśli chcesz jawnie wywołać destruktor wartości, można zamiast tego użyć [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Upuść zamówienie
///
/// Który z naszych dwóch `HasDrop` spada jako pierwszy?W przypadku struktur jest to ta sama kolejność, w jakiej są deklarowane: najpierw `one`, potem `two`.
/// Jeśli chcesz to wypróbować samodzielnie, możesz zmodyfikować `HasDrop` powyżej, aby zawierał jakieś dane, takie jak liczba całkowita, a następnie użyć go w `println!` wewnątrz `Drop`.
/// Takie zachowanie gwarantuje język.
///
/// W przeciwieństwie do struktur, zmienne lokalne są usuwane w odwrotnej kolejności:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// To się wydrukuje
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Zobacz [the reference], aby zapoznać się z pełnymi zasadami.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` i `Drop` są ekskluzywne
///
/// Nie można zaimplementować [`Copy`] i `Drop` na tym samym typie.Typy `Copy` są niejawnie duplikowane przez kompilator, co bardzo utrudnia przewidzenie, kiedy i jak często będą wykonywane destruktory.
///
/// W związku z tym te typy nie mogą mieć destruktorów.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Wykonuje destruktor dla tego typu.
    ///
    /// Ta metoda jest wywoływana niejawnie, gdy wartość wykracza poza zakres i nie można jej wywołać jawnie (jest to błąd kompilatora [E0040]).
    /// Jednak funkcja [`mem::drop`] w prelude może zostać użyta do wywołania implementacji `Drop` argumentu.
    ///
    /// Gdy ta metoda została wywołana, `self` nie został jeszcze cofnięty.
    /// Dzieje się to dopiero po zakończeniu metody.
    /// Gdyby tak nie było, `self` byłby wiszącym odniesieniem.
    ///
    /// # Panics
    ///
    /// Biorąc pod uwagę, że [`panic!`] wywoła `drop` podczas rozwijania, każdy [`panic!`] w implementacji `drop` prawdopodobnie zostanie przerwany.
    ///
    /// Zauważ, że nawet jeśli ten panics, wartość jest uważana za odrzuconą;
    /// nie możesz powodować ponownego wywołania `drop`.
    /// Zwykle jest to obsługiwane automatycznie przez kompilator, ale przy użyciu niebezpiecznego kodu może czasami wystąpić niezamierzenie, szczególnie podczas korzystania z [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}