/// Wersja operatora połączenia, która przyjmuje niezmiennego odbiorcę.
///
/// Instancje `Fn` mogą być wywoływane wielokrotnie bez stanu mutacji.
///
/// *Tego trait (`Fn`) nie należy mylić z [function pointers] (`fn`).*
///
/// `Fn` jest implementowany automatycznie przez domknięcia, które pobierają tylko niezmienne odniesienia do przechwyconych zmiennych lub w ogóle niczego nie przechwytują, podobnie jak (safe) [function pointers] (z pewnymi zastrzeżeniami, zobacz ich dokumentację po więcej szczegółów).
///
/// Dodatkowo, dla każdego typu `F`, który implementuje `Fn`, `&F` również implementuje `Fn`.
///
/// Ponieważ zarówno [`FnMut`], jak i [`FnOnce`] są nadciśnieniami `Fn`, dowolna instancja `Fn` może być użyta jako parametr, w przypadku którego oczekuje się [`FnMut`] lub [`FnOnce`].
///
/// Użyj `Fn` jako ograniczenia, jeśli chcesz zaakceptować parametr typu funkcyjnego i musisz go wywoływać wielokrotnie i bez stanu mutacji (np. Podczas wywoływania go jednocześnie).
/// Jeśli nie potrzebujesz tak surowych wymagań, użyj [`FnMut`] lub [`FnOnce`] jako granic.
///
/// Zobacz [chapter on closures in *The Rust Programming Language*][book], aby uzyskać więcej informacji na ten temat.
///
/// Warto również zwrócić uwagę na specjalną składnię dla `Fn` traits (np
/// `Fn(usize, bool) -> usize`).Zainteresowani szczegółami technicznymi mogą odnieść się do [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Wzywam zamknięcie
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Korzystanie z parametru `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aby regex mógł polegać na `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Wykonuje operację wywołania.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Wersja operatora połączeń, która przyjmuje mutowalny odbiornik.
///
/// Instancje `FnMut` mogą być wywoływane wielokrotnie i mogą powodować mutacje stanu.
///
/// `FnMut` jest implementowany automatycznie przez domknięcia, które pobierają mutowalne odniesienia do przechwyconych zmiennych, a także wszystkie typy, które implementują [`Fn`], np. (safe) [function pointers] (ponieważ `FnMut` jest cechą nadrzędną [`Fn`]).
/// Dodatkowo, dla każdego typu `F`, który implementuje `FnMut`, `&mut F` również implementuje `FnMut`.
///
/// Ponieważ [`FnOnce`] jest cechą nadrzędną `FnMut`, dowolne wystąpienie `FnMut` może być użyte tam, gdzie oczekuje się [`FnOnce`], a ponieważ [`Fn`] jest cechą podrzędną `FnMut`, można użyć dowolnego wystąpienia [`Fn`] tam, gdzie oczekuje się `FnMut`.
///
/// Użyj `FnMut` jako ograniczenia, jeśli chcesz zaakceptować parametr typu funkcyjnego i musisz go wywoływać wielokrotnie, jednocześnie pozwalając mu na mutację stanu.
/// Jeśli nie chcesz, aby parametr zmieniał stan, użyj [`Fn`] jako ograniczenia;jeśli nie musisz wywoływać go wielokrotnie, użyj [`FnOnce`].
///
/// Zobacz [chapter on closures in *The Rust Programming Language*][book], aby uzyskać więcej informacji na ten temat.
///
/// Warto również zwrócić uwagę na specjalną składnię dla `Fn` traits (np
/// `Fn(usize, bool) -> usize`).Zainteresowani szczegółami technicznymi mogą odnieść się do [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Nazywanie zamknięciem przechwytującym na zmianę
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Korzystanie z parametru `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aby regex mógł polegać na `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Wykonuje operację wywołania.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Wersja operatora połączenia, która przyjmuje odbiornik według wartości.
///
/// Instancje `FnOnce` można wywoływać, ale nie można ich wielokrotnie wywoływać.Z tego powodu, jeśli jedyną znaną rzeczą o typie jest to, że implementuje `FnOnce`, można go wywołać tylko raz.
///
/// `FnOnce` jest implementowany automatycznie przez domknięcia, które mogą zużywać przechwycone zmienne, a także wszystkie typy, które implementują [`FnMut`], np. (safe) [function pointers] (ponieważ `FnOnce` jest cechą nadrzędną [`FnMut`]).
///
///
/// Ponieważ zarówno [`Fn`], jak i [`FnMut`] są cechami podrzędnymi `FnOnce`, można użyć dowolnej instancji [`Fn`] lub [`FnMut`] tam, gdzie oczekuje się `FnOnce`.
///
/// Użyj `FnOnce` jako ograniczenia, jeśli chcesz zaakceptować parametr typu funkcyjnego i musisz go wywołać tylko raz.
/// Jeśli musisz wielokrotnie wywoływać parametr, użyj [`FnMut`] jako ograniczenia;jeśli potrzebujesz go również, aby nie mutować stanu, użyj [`Fn`].
///
/// Zobacz [chapter on closures in *The Rust Programming Language*][book], aby uzyskać więcej informacji na ten temat.
///
/// Warto również zwrócić uwagę na specjalną składnię dla `Fn` traits (np
/// `Fn(usize, bool) -> usize`).Zainteresowani szczegółami technicznymi mogą odnieść się do [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Korzystanie z parametru `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` zużywa przechwycone zmienne, więc nie można go uruchomić więcej niż raz.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Próba ponownego wywołania `func()` spowoduje zgłoszenie błędu `use of moved value` dla `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` nie można już przywołać w tym momencie
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aby regex mógł polegać na `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Zwrócony typ po użyciu operatora połączenia.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Wykonuje operację wywołania.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}