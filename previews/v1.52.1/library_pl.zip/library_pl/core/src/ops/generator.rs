use crate::marker::Unpin;
use crate::pin::Pin;

/// Wynik wznowienia generatora.
///
/// To wyliczenie jest zwracane z metody `Generator::resume` i wskazuje możliwe wartości zwracane przez generator.
/// Obecnie odpowiada to punktowi zawieszenia (`Yielded`) lub punktowi zakończenia (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generator zawieszony z wartością.
    ///
    /// Ten stan wskazuje, że generator został zawieszony i zwykle odpowiada instrukcji `yield`.
    /// Wartość podana w tym wariancie odpowiada wyrażeniu przekazanemu do `yield` i umożliwia generatorom dostarczanie wartości za każdym razem, gdy generują.
    ///
    ///
    Yielded(Y),

    /// Generator zakończył zwracaną wartością.
    ///
    /// Ten stan wskazuje, że generator zakończył wykonywanie z podaną wartością.
    /// Gdy generator zwróci `Complete`, ponowne wywołanie `resume` jest uważane za błąd programisty.
    ///
    Complete(R),
}

/// trait zaimplementowane przez wbudowane typy generatorów.
///
/// Generatory, powszechnie nazywane również coroutines, są obecnie eksperymentalną funkcją języka w Rust.
/// Generatory dodane w [RFC 2033] mają obecnie przede wszystkim zapewnić blok konstrukcyjny składni async/await, ale prawdopodobnie rozszerzą się również o zapewnienie ergonomicznej definicji dla iteratorów i innych prymitywów.
///
///
/// Składnia i semantyka generatorów jest niestabilna i będzie wymagać dalszego RFC w celu stabilizacji.W tej chwili jednak składnia jest podobna do domknięcia:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Więcej dokumentacji generatorów można znaleźć w niestabilnej książce.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Typ wartości, jaką daje ten generator.
    ///
    /// Ten skojarzony typ odpowiada wyrażeniu `yield` i wartościom, które mogą być zwracane za każdym razem, gdy generator zwraca wynik.
    ///
    /// Na przykład iterator-as-a-generator prawdopodobnie miałby ten typ jako `T`, typ jest iterowany.
    ///
    type Yield;

    /// Typ wartości zwracanej przez ten generator.
    ///
    /// Odpowiada to typowi zwróconemu z generatora za pomocą instrukcji `return` lub niejawnie jako ostatnie wyrażenie literału generatora.
    /// Na przykład futures użyłby tego jako `Result<T, E>`, ponieważ reprezentuje ukończone future.
    ///
    ///
    type Return;

    /// Wznawia działanie tego generatora.
    ///
    /// Ta funkcja wznowi wykonywanie generatora lub rozpocznie wykonywanie, jeśli jeszcze tego nie zrobił.
    /// To wywołanie powróci do ostatniego punktu zawieszenia generatora, wznawiając wykonywanie od najnowszego `yield`.
    /// Generator będzie kontynuował wykonywanie, dopóki nie zwróci lub nie zwróci, w którym to momencie funkcja zwróci.
    ///
    /// # Wartość zwracana
    ///
    /// Wyliczenie `GeneratorState` zwrócone przez tę funkcję wskazuje, w jakim stanie znajduje się generator po powrocie.
    /// Jeśli wariant `Yielded` zostanie zwrócony, oznacza to, że generator osiągnął punkt zawieszenia i wartość została uzyskana.
    /// Generatory w tym stanie można wznowić w późniejszym czasie.
    ///
    /// Jeśli zwrócone zostanie `Complete`, generator całkowicie zakończył pracę z podaną wartością.Ponowne wznowienie generatora jest nieważne.
    ///
    /// # Panics
    ///
    /// Ta funkcja może panic, jeśli zostanie wywołana po wcześniejszym zwróceniu wariantu `Complete`.
    /// Chociaż literały generatora w języku są gwarantowane do panic przy wznowieniu po `Complete`, nie jest to gwarantowane dla wszystkich implementacji `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}