/// Używany do niezmiennych operacji wyłuskiwania, takich jak `*v`.
///
/// Oprócz tego, że jest używany do jawnych operacji wyłuskiwania z operatorem (unary) `*` w niezmiennych kontekstach, `Deref` jest również używany niejawnie przez kompilator w wielu okolicznościach.
/// Ten mechanizm nazywa się ['`Deref` coercion'][more].
/// W kontekstach zmiennych używany jest [`DerefMut`].
///
/// Wdrożenie `Deref` dla inteligentnych wskaźników sprawia, że dostęp do danych za nimi jest wygodny, dlatego implementują `Deref`.
/// Z drugiej strony, zasady dotyczące `Deref` i [`DerefMut`] zostały zaprojektowane specjalnie w celu uwzględnienia inteligentnych wskaźników.
/// Z tego powodu **`Deref` należy zaimplementować tylko dla inteligentnych wskaźników**, aby uniknąć nieporozumień.
///
/// Z podobnych powodów **ten trait nigdy nie powinien zawieść**.Niepowodzenie podczas wyłuskiwania może być bardzo mylące, gdy `Deref` jest wywoływany niejawnie.
///
/// # Więcej o przymusie `Deref`
///
/// Jeśli `T` implementuje `Deref<Target = U>`, a `x` jest wartością typu `T`, to:
///
/// * W niezmiennych kontekstach `*x` (gdzie `T` nie jest ani odwołaniem, ani surowym wskaźnikiem) jest równoważne `* Deref::deref(&x)`.
/// * Wartości typu `&T` są przekształcane na wartości typu `&U`
/// * `T` niejawnie implementuje wszystkie metody (immutable) typu `U`.
///
/// Aby uzyskać więcej informacji, odwiedź [the chapter in *The Rust Programming Language*][book], a także sekcje referencyjne dotyczące [the dereference operator][ref-deref-op], [method resolution] i [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktura z pojedynczym polem, do którego można uzyskać dostęp poprzez dereferencję struktury.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Wynikowy typ po wyłuskowaniu.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Wybiera wartość.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Używany do operacji wyłuskiwania z możliwością zmiany, jak w `*v = 1;`.
///
/// Oprócz tego, że jest używany do jawnych operacji wyłuskiwania z operatorem (unary) `*` w kontekstach zmiennych, `DerefMut` jest również używany niejawnie przez kompilator w wielu okolicznościach.
/// Ten mechanizm nazywa się ['`Deref` coercion'][more].
/// W niezmiennych kontekstach używany jest [`Deref`].
///
/// Wdrożenie `DerefMut` dla inteligentnych wskaźników sprawia, że mutowanie danych za nimi jest wygodne, dlatego implementują `DerefMut`.
/// Z drugiej strony, zasady dotyczące [`Deref`] i `DerefMut` zostały zaprojektowane specjalnie w celu uwzględnienia inteligentnych wskaźników.
/// Z tego powodu **`DerefMut` należy zaimplementować tylko dla inteligentnych wskaźników**, aby uniknąć nieporozumień.
///
/// Z podobnych powodów **ten trait nigdy nie powinien zawieść**.Niepowodzenie podczas wyłuskiwania może być bardzo mylące, gdy `DerefMut` jest wywoływany niejawnie.
///
/// # Więcej o przymusie `Deref`
///
/// Jeśli `T` implementuje `DerefMut<Target = U>`, a `x` jest wartością typu `T`, to:
///
/// * W kontekstach zmiennych `*x` (gdzie `T` nie jest ani odwołaniem, ani surowym wskaźnikiem) jest równoważne `* DerefMut::deref_mut(&mut x)`.
/// * Wartości typu `&mut T` są przekształcane na wartości typu `&mut U`
/// * `T` niejawnie implementuje wszystkie metody (mutable) typu `U`.
///
/// Aby uzyskać więcej informacji, odwiedź [the chapter in *The Rust Programming Language*][book], a także sekcje referencyjne dotyczące [the dereference operator][ref-deref-op], [method resolution] i [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktura z pojedynczym polem, którą można modyfikować przez dereferencję struktury.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Bez wątpienia wyłuskuje wartość.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Wskazuje, że struktura może być używana jako odbiornik metody bez funkcji `arbitrary_self_types`.
///
/// Jest to implementowane przez typy wskaźników standardowej biblioteki, takie jak `Box<T>`, `Rc<T>`, `&T` i `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}