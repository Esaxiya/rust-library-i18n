//! Przeciążalne operatory.
//!
//! Implementacja tych traits pozwala na przeciążenie niektórych operatorów.
//!
//! Niektóre z tych traits są importowane przez prelude, więc są dostępne w każdym programie Rust.Tylko operatorzy wspierani przez traits mogą być przeciążeni.
//! Na przykład operator dodawania (`+`) może zostać przeciążony przez [`Add`] trait, ale ponieważ operator przypisania (`=`) nie ma zaplecza trait, nie ma możliwości przeciążenia jego semantyki.
//! Dodatkowo moduł ten nie zapewnia żadnego mechanizmu tworzenia nowych operatorów.
//! Jeśli wymagane jest przeciążanie bez cech lub niestandardowe operatory, powinieneś spojrzeć na makra lub wtyczki kompilatora, aby rozszerzyć składnię Rust.
//!
//! Implementacje operatora traits nie powinny być zaskakujące w swoim kontekście, biorąc pod uwagę ich zwykłe znaczenie i [operator precedence].
//! Na przykład podczas implementowania [`Mul`] operacja powinna mieć pewne podobieństwo do mnożenia (i mieć wspólne oczekiwane właściwości, takie jak asocjatywność).
//!
//! Zwróć uwagę, że operatory `&&` i `||` powodują zwarcie, tj. Oceniają swój drugi operand tylko wtedy, gdy ma on wpływ na wynik.Ponieważ to zachowanie nie jest egzekwowane przez traits, `&&` i `||` nie są obsługiwane jako operatory z możliwością przeciążenia.
//!
//! Wiele operatorów przyjmuje argumenty według wartości.W nieogólnych kontekstach obejmujących typy wbudowane zwykle nie stanowi to problemu.
//! Jednak użycie tych operatorów w kodzie ogólnym wymaga pewnej uwagi, jeśli wartości muszą być ponownie użyte, w przeciwieństwie do pozwalania operatorom na ich użycie.Jedną z opcji jest okazjonalne używanie [`clone`].
//! Inną opcją jest poleganie na typach, które zapewniają dodatkowe implementacje operatorów dla odwołań.
//! Na przykład w przypadku typu `T` zdefiniowanego przez użytkownika, który ma obsługiwać dodawanie, prawdopodobnie dobrym pomysłem jest, aby zarówno `T`, jak i `&T` zaimplementowały traits [`Add<T>`][`Add`] i [`Add<&T>`][`Add`], aby można było pisać ogólny kod bez niepotrzebnego klonowania.
//!
//!
//! # Examples
//!
//! Ten przykład tworzy strukturę `Point`, która implementuje [`Add`] i [`Sub`], a następnie demonstruje dodawanie i odejmowanie dwóch " Point`.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Zobacz dokumentację każdego trait, aby zapoznać się z przykładową implementacją.
//!
//! [`Fn`], [`FnMut`] i [`FnOnce`] traits są implementowane przez typy, które mogą być wywoływane jak funkcje.Zauważ, że [`Fn`] bierze `&self`, [`FnMut`] bierze `&mut self`, a [`FnOnce`] zajmuje `self`.
//! Odpowiadają one trzem rodzajom metod, które można wywołać w wystąpieniu: wywołanie przez odwołanie, wywołanie przez odwołanie z możliwością zmiany i wywołanie według wartości.
//! Najczęstszym zastosowaniem tych traits jest działanie jako ograniczenia do funkcji wyższego poziomu, które przyjmują funkcje lub zamknięcia jako argumenty.
//!
//! Biorąc [`Fn`] jako parametr:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Biorąc [`FnMut`] jako parametr:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Biorąc [`FnOnce`] jako parametr:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` zużywa przechwycone zmienne, więc nie można go uruchomić więcej niż raz
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Próba ponownego wywołania `func()` spowoduje zgłoszenie błędu `use of moved value` dla `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` nie można już przywołać w tym momencie
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;