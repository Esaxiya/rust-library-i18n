use crate::marker::Unsize;

/// Trait, który wskazuje, że jest to wskaźnik lub opakowanie na jeden, w którym można dokonać zmiany rozmiaru na pointee.
///
/// Aby uzyskać więcej informacji, zobacz [DST coercion RFC][dst-coerce] i [the nomicon entry on coercion][nomicon-coerce].
///
/// W przypadku wbudowanych typów wskaźników wskaźniki `T` będą przekształcać wskaźniki do `U`, jeśli `T: Unsize<U>`, konwertując cienki wskaźnik na gruby wskaźnik.
///
/// W przypadku typów niestandardowych wymuszenie tutaj działa poprzez przekształcenie `Foo<T>` do `Foo<U>`, pod warunkiem, że istnieje impl z `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Taki implik można zapisać tylko wtedy, gdy `Foo<T>` ma tylko jedno nie-fantomowe pole danych obejmujące `T`.
/// Jeśli typ tego pola to `Bar<T>`, musi istnieć implementacja `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Wymuszenie będzie działać poprzez przekształcenie pola `Bar<T>` w `Bar<U>` i wypełnienie pozostałych pól z `Foo<T>`, aby utworzyć `Foo<U>`.
/// Spowoduje to efektywne przejście do pola wskaźnikowego i wymusi to.
///
/// Ogólnie rzecz biorąc, w przypadku inteligentnych wskaźników zaimplementujesz `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, z opcjonalnym `?Sized` powiązanym z samym `T`.
/// W przypadku typów opakowań, które bezpośrednio osadzają `T`, takich jak `Cell<T>` i `RefCell<T>`, można bezpośrednio zaimplementować `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Pozwoli to na działanie przymusu typu `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] służy do oznaczania typów, które mogą być przekształcane na czas letni, jeśli znajdują się za wskaźnikami.Jest implementowany automatycznie przez kompilator.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Jest to używane ze względu na bezpieczeństwo obiektów, aby sprawdzić, czy typ odbiornika metody może być wysłany.
///
/// Przykładowa implementacja trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}