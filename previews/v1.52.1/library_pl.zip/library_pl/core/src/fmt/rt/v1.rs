//! To jest moduł wewnętrzny używany przez ifmt!runtime.Struktury te są emitowane do tablic statycznych w celu prekompilowania ciągów formatu z wyprzedzeniem.
//!
//! Te definicje są podobne do ich odpowiedników w `ct`, ale różnią się tym, że mogą być przydzielane statycznie i są nieco zoptymalizowane pod kątem środowiska uruchomieniowego
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Możliwe wyrównania, których można zażądać w ramach dyrektywy formatowania.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Wskazanie, że treść powinna być wyrównana do lewej.
    Left,
    /// Wskazanie, że treść powinna być wyrównana do prawej.
    Right,
    /// Wskazanie, że zawartość powinna być wyrównana do środka.
    Center,
    /// Nie zażądano wyrównania.
    Unknown,
}

/// Używany przez specyfikatory [width](https://doc.rust-lang.org/std/fmt/#width) i [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Określony liczbą literału, przechowuje wartość
    Is(usize),
    /// Określony przy użyciu składni `$` i `*`, przechowuje indeks w `args`
    Param(usize),
    /// Nieokreślony
    Implied,
}