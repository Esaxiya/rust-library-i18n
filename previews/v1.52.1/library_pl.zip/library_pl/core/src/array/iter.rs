//! Definiuje iterator dla tablic należący do `IntoIter`.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Iterator [array] według wartości.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// To jest tablica, nad którą iterujemy.
    ///
    /// Elementy o indeksie `i`, gdzie `alive.start <= i < alive.end` nie zostały jeszcze zwrócone i są prawidłowymi wpisami w tablicy.
    /// Elementy z indeksami `i < alive.start` lub `i >= alive.end` zostały już uzyskane i nie można ich już otwierać!Te martwe elementy mogą być nawet całkowicie niezainicjowane!
    ///
    ///
    /// Tak więc niezmienniki to:
    /// - `data[alive]` żyje (czyli zawiera prawidłowe elementy)
    /// - `data[..alive.start]` i `data[alive.end..]` są martwe (tj. elementy zostały już odczytane i nie można ich już dotykać!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Elementy w `data`, które nie zostały jeszcze udostępnione.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Tworzy nowy iterator na podanym `array`.
    ///
    /// *Uwaga*: ta metoda może być przestarzała w future, po [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Typ `value` to tutaj `i32` zamiast `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // BEZPIECZEŃSTWO: transmutacja jest w rzeczywistości bezpieczna.Dokumentacja `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` gwarantuje ten sam rozmiar i wyrównanie
        // > jako `T`.
        //
        // Dokumenty pokazują nawet transmutację z tablicy `MaybeUninit<T>` do tablicy `T`.
        //
        //
        // Dzięki temu inicjalizacja spełnia niezmienniki.

        // FIXME(LukasKalbertodt): faktycznie używaj tutaj `mem::transmute`, gdy działa z typami ogólnymi const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Do tego czasu możemy użyć `mem::transmute_copy` do utworzenia kopii bitowej jako innego typu, a następnie zapomnieć `array`, aby nie został upuszczony.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Zwraca niezmienny wycinek wszystkich elementów, które nie zostały jeszcze podane.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // BEZPIECZEŃSTWO: Wiemy, że wszystkie elementy w `alive` są poprawnie zainicjalizowane.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Zwraca zmienny wycinek wszystkich elementów, które nie zostały jeszcze podane.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // BEZPIECZEŃSTWO: Wiemy, że wszystkie elementy w `alive` są poprawnie zainicjalizowane.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Pobierz następny indeks od przodu.
        //
        // Zwiększenie `alive.start` o 1 zachowuje niezmienność `alive`.
        // Jednak z powodu tej zmiany przez krótki czas żywa strefa to już nie `data[alive]`, ale `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Odczytaj element z tablicy.
            // BEZPIECZEŃSTWO: `idx` to indeks poprzedniego regionu "alive"
            // szyk.Odczytanie tego elementu oznacza, że `data[idx]` jest teraz uważany za martwy (tj. Nie dotykaj).
            // Ponieważ `idx` był początkiem strefy życia, strefą życia jest teraz ponownie `data[alive]`, przywracając wszystkie niezmienniki.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Pobierz następny indeks z tyłu.
        //
        // Zmniejszenie `alive.end` o 1 zachowuje niezmiennik `alive`.
        // Jednak z powodu tej zmiany przez krótki czas żywa strefa to już nie `data[alive]`, ale `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Odczytaj element z tablicy.
            // BEZPIECZEŃSTWO: `idx` to indeks poprzedniego regionu "alive"
            // szyk.Odczytanie tego elementu oznacza, że `data[idx]` jest teraz uważany za martwy (tj. Nie dotykaj).
            // Ponieważ `idx` był końcem strefy życia, strefą życia jest teraz ponownie `data[alive]`, przywracając wszystkie niezmienniki.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // BEZPIECZEŃSTWO: To jest bezpieczne: `as_mut_slice` zwraca dokładnie podsekcję
        // elementów, które nie zostały jeszcze usunięte, a które pozostały do porzucenia.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Nigdy nie będzie niedomiar z powodu niezmiennego `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iterator rzeczywiście zgłasza prawidłową długość.
// Liczba elementów "alive" (które nadal będą uzyskiwane) to długość zakresu `alive`.
// Długość tego zakresu jest zmniejszana w `next` lub `next_back`.
// W tych metodach jest zawsze zmniejszany o 1, ale tylko wtedy, gdy zwracane jest `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Zauważ, że tak naprawdę nie musimy dopasowywać dokładnie tego samego żywego zakresu, więc możemy po prostu sklonować do offsetu 0 niezależnie od tego, gdzie jest `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klonuj wszystkie żywe elementy.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Zapisz klon do nowej tablicy, a następnie zaktualizuj jego aktywny zakres.
            // Jeśli klonujesz panics, poprawnie usuniemy poprzednie elementy.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Wydrukuj tylko te elementy, które nie zostały jeszcze zwrócone: nie możemy już uzyskać dostępu do uzyskanych elementów.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}