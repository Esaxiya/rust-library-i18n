//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Najwyższy prawidłowy punkt kodowy, jaki może mieć `char`.
    ///
    /// `char` to [Unicode Scalar Value], co oznacza, że jest to [Code Point], ale tylko w określonym zakresie.
    /// `MAX` to najwyższy prawidłowy punkt kodowy, który jest prawidłowym [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () jest używany w standardzie Unicode do reprezentowania błędu dekodowania.
    ///
    /// Może się to zdarzyć na przykład podczas przekazywania źle sformatowanych bajtów UTF-8 do [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Wersja [Unicode](http://www.unicode.org/), na której są oparte części Unicode metod `char` i `str`.
    ///
    /// Nowe wersje Unicode są wydawane regularnie, a następnie wszystkie metody w bibliotece standardowej w zależności od Unicode są aktualizowane.
    /// Dlatego zachowanie niektórych metod `char` i `str` oraz wartość tej stałej zmienia się w czasie.
    /// To *nie* jest uważane za przełomową zmianę.
    ///
    /// Schemat numerowania wersji jest wyjaśniony w [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Tworzy iterator na punktach kodowych zakodowanych w UTF-16 w `iter`, zwracając niesparowane surogaty jako " Err`.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Dekoder stratny można uzyskać, zastępując wyniki `Err` znakiem zastępczym:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Konwertuje `u32` na `char`.
    ///
    /// Zauważ, że wszystkie znaki " char`są poprawne [" u32`] i mogą być rzutowane na jeden z
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Jednak sytuacja odwrotna nie jest prawdą: nie wszystkie prawidłowe znaki [" u32`] są poprawnymi znakami " char`.
    /// `from_u32()` zwróci `None`, jeśli dane wejściowe nie są poprawną wartością dla `char`.
    ///
    /// Aby zapoznać się z niebezpieczną wersją tej funkcji, która ignoruje te sprawdzenia, zobacz [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Zwracanie `None`, gdy wejście nie jest poprawnym `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Konwertuje `u32` na `char`, ignorując ważność.
    ///
    /// Zauważ, że wszystkie znaki " char`są poprawne [" u32`] i mogą być rzutowane na jeden z
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Jednak sytuacja odwrotna nie jest prawdą: nie wszystkie prawidłowe znaki [" u32`] są poprawnymi znakami " char`.
    /// `from_u32_unchecked()` zignoruje to i ślepo przesyła na `char`, prawdopodobnie tworząc nieprawidłowy.
    ///
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna, ponieważ może tworzyć nieprawidłowe wartości `char`.
    ///
    /// Aby uzyskać bezpieczną wersję tej funkcji, zobacz funkcję [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać umowy dotyczącej bezpieczeństwa.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Konwertuje cyfrę o podanej podstawie na `char`.
    ///
    /// 'radix' jest tutaj czasami nazywany 'base'.
    /// Podstawa dwa oznacza liczbę binarną, podstawę dziesiętną dziesiętną, a podstawę szesnastkową szesnastkową, dając pewne wspólne wartości.
    ///
    /// Obsługiwane są arbitralne rodniki.
    ///
    /// `from_digit()` zwróci `None`, jeśli wejście nie jest cyfrą o podanej podstawie.
    ///
    /// # Panics
    ///
    /// Panics, jeśli ma podstawę większą niż 36.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Liczba dziesiętna 11 to pojedyncza cyfra o podstawie 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Zwracanie `None`, gdy wartość wejściowa nie jest cyfrą:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Przekazywanie dużej podstawy, powodując panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Sprawdza, czy `char` jest cyfrą o podanej podstawie.
    ///
    /// 'radix' jest tutaj czasami nazywany 'base'.
    /// Podstawa dwa oznacza liczbę binarną, podstawę dziesiętną dziesiętną, a podstawę szesnastkową szesnastkową, dając pewne wspólne wartości.
    ///
    /// Obsługiwane są arbitralne rodniki.
    ///
    /// W porównaniu do [`is_numeric()`] ta funkcja rozpoznaje tylko znaki `0-9`, `a-z` i `A-Z`.
    ///
    /// 'Digit' jest zdefiniowana jako tylko następujące znaki:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Aby uzyskać pełniejsze zrozumienie 'digit', zobacz [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics, jeśli ma podstawę większą niż 36.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Przekazywanie dużej podstawy, powodując panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Konwertuje `char` na cyfrę o podanej podstawie.
    ///
    /// 'radix' jest tutaj czasami nazywany 'base'.
    /// Podstawa dwa oznacza liczbę binarną, podstawę dziesiętną dziesiętną, a podstawę szesnastkową szesnastkową, dając pewne wspólne wartości.
    ///
    /// Obsługiwane są arbitralne rodniki.
    ///
    /// 'Digit' jest zdefiniowana jako tylko następujące znaki:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Zwraca `None`, jeśli `char` nie odnosi się do cyfry o podanej podstawie.
    ///
    /// # Panics
    ///
    /// Panics, jeśli ma podstawę większą niż 36.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Przekazanie wartości niebędącej cyfrą powoduje niepowodzenie:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Przekazywanie dużej podstawy, powodując panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kod jest tutaj podzielony, aby przyspieszyć wykonywanie w przypadkach, gdy `radix` jest stały i 10 lub mniejszy
        //
        let val = if likely(radix <= 10) {
            // Jeśli nie jest cyfrą, zostanie utworzona liczba większa niż podstawa.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Zwraca iterator, który zwraca szesnastkową ucieczkę znaku Unicode jako " char`.
    ///
    /// Spowoduje to zmianę znaczenia znaków ze składnią Rust w postaci `\u{NNNNNN}`, gdzie `NNNNNN` jest reprezentacją szesnastkową.
    ///
    ///
    /// # Examples
    ///
    /// Jako iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Używając `println!` bezpośrednio:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Oba są równoważne z:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Korzystanie z `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 zapewnia, że dla c==0 kod oblicza, że jedna cyfra powinna zostać wydrukowana i (która jest taka sama) pozwala uniknąć (31, 32) niedopełnienia
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // indeks najbardziej znaczącej cyfry szesnastkowej
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Rozszerzona wersja `escape_debug`, która opcjonalnie pozwala na unikanie punktów kodowych Extended Grapheme.
    /// To pozwala nam lepiej formatować znaki, takie jak znaki bez odstępów, gdy znajdują się na początku ciągu.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Zwraca iterator, który zwraca literalny kod ucieczki znaku jako " char`.
    ///
    /// Spowoduje to usunięcie znaków podobnych do implementacji `Debug` `str` lub `char`.
    ///
    ///
    /// # Examples
    ///
    /// Jako iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Używając `println!` bezpośrednio:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Oba są równoważne z:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Korzystanie z `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Zwraca iterator, który zwraca literalny kod ucieczki znaku jako " char`.
    ///
    /// Wartość domyślna jest wybierana z naciskiem na tworzenie literałów, które są legalne w różnych językach, w tym w C++ 11 i podobnych językach z rodziny C.
    /// Dokładne zasady to:
    ///
    /// * Znak tabulacji jest zapisywany jako `\t`.
    /// * Powrót karetki jest zapisywany jako `\r`.
    /// * Znak nowego wiersza jest zapisywany jako `\n`.
    /// * Pojedynczy cudzysłów jest zapisywany jako `\'`.
    /// * Podwójny cudzysłów jest zapisywany jako `\"`.
    /// * Ukośnik odwrotny jest zapisywany jako `\\`.
    /// * Żaden znak z zakresu " printable ASCII` `0x20` .. `0x7e` włącznie nie jest zmieniany.
    /// * Wszystkie inne znaki otrzymują szesnastkowe znaki ucieczki Unicode;zobacz [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Jako iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Używając `println!` bezpośrednio:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Oba są równoważne z:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Korzystanie z `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Zwraca liczbę bajtów, których `char` potrzebowałby, gdyby zostało zakodowane w UTF-8.
    ///
    /// Ta liczba bajtów wynosi zawsze od 1 do 4 włącznie.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Typ `&str` gwarantuje, że jego zawartość to UTF-8, więc możemy porównać długość, jaką zajęłoby to, gdyby każdy punkt kodowy był reprezentowany jako `char` w porównaniu z samym `&str`:
    ///
    ///
    /// ```
    /// // jako znaki
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // oba mogą być reprezentowane jako trzy bajty
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // jako &str, te dwa są zakodowane w UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // widzimy, że zajmują łącznie sześć bajtów ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... tak jak &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Zwraca liczbę 16-bitowych jednostek kodu, których `char` potrzebowałby, gdyby został zakodowany w UTF-16.
    ///
    ///
    /// Więcej informacji na temat tej koncepcji można znaleźć w dokumentacji [`len_utf8()`].
    /// Ta funkcja jest lustrem, ale dla UTF-16 zamiast UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Koduje ten znak jako UTF-8 w podanym buforze bajtów, a następnie zwraca podskrawek buforu, który zawiera zakodowany znak.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli bufor nie jest wystarczająco duży.
    /// Bufor o długości cztery jest wystarczająco duży, aby zakodować dowolny `char`.
    ///
    /// # Examples
    ///
    /// W obu tych przykładach kod 'ß' zajmuje dwa bajty.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Bufor, który jest za mały:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // BEZPIECZEŃSTWO: `char` nie jest substytutem, więc jest to poprawne UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Koduje ten znak jako UTF-16 w podanym buforze `u16`, a następnie zwraca podskrawek buforu, który zawiera zakodowany znak.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli bufor nie jest wystarczająco duży.
    /// Bufor o długości 2 jest wystarczająco duży, aby zakodować dowolny `char`.
    ///
    /// # Examples
    ///
    /// W obu tych przykładach '𝕊' wymaga do zakodowania dwóch znaków " u16`.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Bufor, który jest za mały:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Zwraca `true`, jeśli ten `char` ma właściwość `Alphabetic`.
    ///
    /// `Alphabetic` jest opisany w rozdziale 4 (Właściwości znaków) [Unicode Standard] i określony w [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // miłość to wiele rzeczy, ale nie jest ona alfabetyczna
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Zwraca `true`, jeśli ten `char` ma właściwość `Lowercase`.
    ///
    /// `Lowercase` jest opisany w rozdziale 4 (Właściwości znaków) [Unicode Standard] i określony w [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Różne chińskie pisma i znaki interpunkcyjne nie mają wielkości liter, więc:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Zwraca `true`, jeśli ten `char` ma właściwość `Uppercase`.
    ///
    /// `Uppercase` jest opisany w rozdziale 4 (Właściwości znaków) [Unicode Standard] i określony w [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Różne chińskie pisma i znaki interpunkcyjne nie mają wielkości liter, więc:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Zwraca `true`, jeśli ten `char` ma właściwość `White_Space`.
    ///
    /// `White_Space` jest określony w [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // nierozerwalna przestrzeń
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Zwraca `true`, jeśli ten `char` spełnia wymagania [`is_alphabetic()`] lub [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Zwraca `true`, jeśli ten `char` ma ogólną kategorię dla kodów sterujących.
    ///
    /// Kody sterujące (punkty kodowe z ogólną kategorią `Cc`) są opisane w rozdziale 4 (Właściwości znaku) [Unicode Standard] i określone w [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // U + 009C, KOŃCÓWKA STRINGU
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Zwraca `true`, jeśli ten `char` ma właściwość `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` jest opisany w [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] i określony w [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Zwraca `true`, jeśli ten `char` ma jedną z ogólnych kategorii liczb.
    ///
    /// Ogólne kategorie liczb (`Nd` dla cyfr dziesiętnych, `Nl` dla liter o charakterze cyfrowym i `No` dla innych znaków numerycznych) są określone w [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Zwraca iterator, który zwraca mapowanie małych liter tego `char` jako jeden lub więcej
    /// `char`s.
    ///
    /// Jeśli ten `char` nie ma odwzorowania małych liter, iterator zwraca ten sam `char`.
    ///
    /// Jeśli ten `char` ma odwzorowanie jeden do jednego małych liter podane przez [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator zwraca `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Jeśli ten `char` wymaga specjalnych rozważań (np. Wiele znaków " char`), iterator zwraca " znaki` podane przez [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ta operacja wykonuje bezwarunkowe mapowanie bez dostosowywania.Oznacza to, że konwersja jest niezależna od kontekstu i języka.
    ///
    /// W [Unicode Standard], Rozdział 4 (Właściwości znaku) omawia mapowanie wielkości liter w ogólności, a Rozdział 3 (Conformance) omawia domyślny algorytm konwersji wielkości liter.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Jako iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Używając `println!` bezpośrednio:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Oba są równoważne z:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Korzystanie z `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Czasami wynikiem jest więcej niż jeden znak:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Znaki, które nie mają zarówno wielkich, jak i małych liter, są konwertowane na siebie.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Zwraca iterator, który zwraca mapowanie wielkich liter `char` jako jeden lub więcej
    /// `char`s.
    ///
    /// Jeśli ten `char` nie ma odwzorowania wielkich liter, iterator zwraca ten sam `char`.
    ///
    /// Jeśli ten `char` ma odwzorowanie jeden do jednego wielkich liter podane przez [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator zwraca `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Jeśli ten `char` wymaga specjalnych rozważań (np. Wiele znaków " char`), iterator zwraca " znaki` podane przez [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ta operacja wykonuje bezwarunkowe mapowanie bez dostosowywania.Oznacza to, że konwersja jest niezależna od kontekstu i języka.
    ///
    /// W [Unicode Standard], Rozdział 4 (Właściwości znaku) omawia mapowanie wielkości liter w ogólności, a Rozdział 3 (Conformance) omawia domyślny algorytm konwersji wielkości liter.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Jako iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Używając `println!` bezpośrednio:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Oba są równoważne z:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Korzystanie z `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Czasami wynikiem jest więcej niż jeden znak:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Znaki, które nie mają zarówno wielkich, jak i małych liter, są konwertowane na siebie.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Uwaga dotycząca lokalizacji
    ///
    /// W języku tureckim odpowiednik 'i' w języku łacińskim ma pięć form zamiast dwóch:
    ///
    /// * 'Dotless': Ja/ı, czasami napisane ï
    /// * 'Dotted': İ/i
    ///
    /// Zwróć uwagę, że mała litera 'i' z kropkami jest taka sama jak łacińska.W związku z tym:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Wartość `upper_i` zależy tutaj od języka tekstu: jeśli jesteśmy w `en-US`, powinno to być `"I"`, ale jeśli jesteśmy w `tr_TR`, powinno to być `"İ"`.
    /// `to_uppercase()` nie bierze tego pod uwagę, a więc:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// obowiązuje w różnych językach.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Sprawdza, czy wartość mieści się w zakresie ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Tworzy kopię wartości w jej odpowiedniku z wielkich liter ASCII.
    ///
    /// Litery ASCII 'a' do 'z' są odwzorowywane na 'A' do 'Z', ale litery inne niż ASCII pozostają niezmienione.
    ///
    /// Aby wpisać wartość lokalnie wielką literą, użyj [`make_ascii_uppercase()`].
    ///
    /// Aby oprócz znaków spoza zestawu ASCII pisać wielkimi literami, użyj [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Tworzy kopię wartości zapisaną małymi literami ASCII.
    ///
    /// Litery ASCII 'A' do 'Z' są odwzorowywane na 'a' do 'z', ale litery inne niż ASCII pozostają niezmienione.
    ///
    /// Aby wprowadzić małe litery w miejscu, użyj [`make_ascii_lowercase()`].
    ///
    /// Aby oprócz znaków spoza zestawu ASCII małymi literami, użyj [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Sprawdza, czy dwie wartości nie uwzględniają wielkości liter w kodzie ASCII.
    ///
    /// Odpowiednik `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Konwertuje ten typ na jego odpowiednik z wielkich liter ASCII w miejscu.
    ///
    /// Litery ASCII 'a' do 'z' są odwzorowywane na 'A' do 'Z', ale litery inne niż ASCII pozostają niezmienione.
    ///
    /// Aby zwrócić nową wartość pisaną wielkimi literami bez modyfikowania istniejącej, użyj [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Konwertuje ten typ na jego odpowiednik w miejscu z małymi literami ASCII.
    ///
    /// Litery ASCII 'A' do 'Z' są odwzorowywane na 'a' do 'z', ale litery inne niż ASCII pozostają niezmienione.
    ///
    /// Aby zwrócić nową małą wartość bez modyfikowania istniejącej, użyj [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Sprawdza, czy wartość jest znakiem alfabetu ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' lub
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Sprawdza, czy wartość jest wielką literą ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Sprawdza, czy wartość jest małą literą ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Sprawdza, czy wartość jest znakiem alfanumerycznym ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' lub
    /// - U + 0061 'a' ..=U + 007A 'z' lub
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Sprawdza, czy wartość jest cyfrą dziesiętną ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Sprawdza, czy wartość jest cyfrą szesnastkową ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' lub
    /// - U + 0041 'A' ..=U + 0046 'F' lub
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Sprawdza, czy wartość jest znakiem interpunkcyjnym ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` lub
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` lub
    /// - U + 005B ..=U + 0060 ``[\] ^ _`` lub
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Sprawdza, czy wartość jest znakiem graficznym ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Sprawdza, czy wartość jest białym znakiem ASCII:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED lub U + 000D CARRIAGE RETURN.
    ///
    /// Rust wykorzystuje model [definition of ASCII whitespace][infra-aw] firmy WhatWG Infra Standard.Istnieje kilka innych definicji w szerokim użyciu.
    /// Na przykład [the POSIX locale][pct] zawiera U + 000B VERTICAL TAB oraz wszystkie powyższe znaki, ale-z tej samej specyfikacji-[domyślna reguła dla "field splitting" w Bourne shell][bfs] uwzględnia *tylko* SPACJĘ, POZIOMĄ TABELĘ i LINE FEED jako białe znaki.
    ///
    ///
    /// Jeśli piszesz program, który będzie przetwarzał istniejący format pliku, przed użyciem tej funkcji sprawdź, jaka jest definicja białych znaków w tym formacie.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Sprawdza, czy wartość jest znakiem sterującym ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR lub U + 007F DELETE.
    /// Zauważ, że większość białych znaków ASCII to znaki sterujące, ale SPACJA nie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Koduje nieprzetworzoną wartość u32 jako UTF-8 w podanym buforze bajtów, a następnie zwraca podskrawek buforu, który zawiera zakodowany znak.
///
///
/// W przeciwieństwie do `char::encode_utf8` ta metoda obsługuje również punkty kodowe w zakresie zastępczym.
/// (Tworzenie `char` w zakresie zastępczym to UB). Wynik jest prawidłowy [generalized UTF-8], ale nieprawidłowy UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics, jeśli bufor nie jest wystarczająco duży.
/// Bufor o długości cztery jest wystarczająco duży, aby zakodować dowolny `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Koduje nieprzetworzoną wartość u32 jako UTF-16 w dostarczonym buforze `u16`, a następnie zwraca podskrawek buforu, który zawiera zakodowany znak.
///
///
/// W przeciwieństwie do `char::encode_utf16` ta metoda obsługuje również punkty kodowe w zakresie zastępczym.
/// (Tworzenie `char` w zakresie zastępczym to UB).
///
/// # Panics
///
/// Panics, jeśli bufor nie jest wystarczająco duży.
/// Bufor o długości 2 jest wystarczająco duży, aby zakodować dowolny `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // BEZPIECZEŃSTWO: każde ramię sprawdza, czy jest wystarczająco dużo bitów do zapisania
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP przepada
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Dodatkowe płaszczyzny rozbijają się na surogaty.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}