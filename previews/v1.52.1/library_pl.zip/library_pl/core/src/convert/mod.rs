//! Traits do konwersji między typami.
//!
//! traits w tym module umożliwia konwersję z jednego typu na inny.
//! Każdy trait służy innemu celowi:
//!
//! - Zaimplementuj [`AsRef`] trait, aby uzyskać tanie konwersje odniesienia do odniesienia
//! - Zaimplementuj [`AsMut`] trait, aby uzyskać tanie konwersje mutable-mutable
//! - Zaimplementuj [`From`] trait do konwersji wartości do wartości
//! - Zaimplementuj [`Into`] trait do konsumowania konwersji wartości do wartości do typów spoza bieżącego crate
//! - [`TryFrom`] i [`TryInto`] traits zachowują się jak [`From`] i [`Into`], ale należy je zaimplementować, gdy konwersja może się nie powieść.
//!
//! traits w tym module są często używane jako trait bounds dla funkcji ogólnych, takich jak argumenty wielu typów.Przykłady można znaleźć w dokumentacji każdego trait.
//!
//! Jako autor biblioteki zawsze powinieneś preferować implementację [`From<T>`][`From`] lub [`TryFrom<T>`][`TryFrom`] niż [`Into<U>`][`Into`] lub [`TryInto<U>`][`TryInto`], ponieważ [`From`] i [`TryFrom`] zapewniają większą elastyczność i oferują równoważne implementacje [`Into`] lub [`TryInto`] za darmo, dzięki ogólnej implementacji w standardowej bibliotece.
//! W przypadku kierowania na wersję starszą niż Rust 1.41 może być konieczne bezpośrednie zaimplementowanie [`Into`] lub [`TryInto`] podczas konwersji na typ spoza bieżącego crate.
//!
//! # Implementacje ogólne
//!
//! - [`AsRef`] i [`AsMut`] auto-dereference, jeśli typ wewnętrzny jest odwołaniem
//! - [`From`]`<U>for T` implikuje [`Into`]`</u><T><U>dla U`</u>
//! - [`TryFrom`]`<U>for T` implikuje [`TryInto`]`</u><T><U>dla U`</u>
//! - [`From`] i [`Into`] są refleksyjne, co oznacza, że wszystkie typy mogą same `into` i same `from`
//!
//! Przykłady użycia można znaleźć w każdym trait.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Funkcja tożsamości.
///
/// Na temat tej funkcji należy zwrócić uwagę na dwie rzeczy:
///
/// - Nie zawsze jest równoważne zamknięciu, jak `|x| x`, ponieważ zamknięcie może wymusić `x` na inny typ.
///
/// - Przenosi wejście `x` przekazane do funkcji.
///
/// Chociaż może wydawać się dziwne, że funkcja po prostu zwraca dane wejściowe, jest kilka interesujących zastosowań.
///
///
/// # Examples
///
/// Używanie `identity` do robienia niczego w sekwencji innych, interesujących funkcji:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Udawajmy, że dodanie jednej jest ciekawą funkcją.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Używanie `identity` jako przypadku podstawowego "do nothing" w warunkowym:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Rób więcej interesujących rzeczy ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Używanie `identity` do zachowania wariantów `Some` iteratora `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Służy do taniej konwersji odniesienia na odniesienie.
///
/// Ten trait jest podobny do [`AsMut`], który jest używany do konwersji między zmiennymi odniesieniami.
/// Jeśli potrzebujesz wykonać kosztowną konwersję, lepiej zaimplementować [`From`] z typem `&T` lub napisać niestandardową funkcję.
///
/// `AsRef` ma taką samą sygnaturę jak [`Borrow`], ale [`Borrow`] różni się w kilku aspektach:
///
/// - W przeciwieństwie do `AsRef`, [`Borrow`] ma ogólny impl dla każdego `T` i może być używany do akceptowania odwołania lub wartości.
/// - [`Borrow`] wymaga również, aby [`Hash`], [`Eq`] i [`Ord`] dla wartości pożyczonej były równoważne wartości posiadanej.
/// Z tego powodu, jeśli chcesz pożyczyć tylko jedno pole struktury, możesz zaimplementować `AsRef`, ale nie [`Borrow`].
///
/// **Note: Ten trait nie może zawieść **.Jeśli konwersja może się nie powieść, użyj dedykowanej metody, która zwraca [`Option<T>`] lub [`Result<T, E>`].
///
/// # Implementacje ogólne
///
/// - `AsRef` autodereferencje, jeśli typ wewnętrzny jest odwołaniem lub odwołaniem zmiennym (np .: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Używając trait bounds możemy akceptować argumenty różnych typów, o ile można je przekonwertować na określony typ `T`.
///
/// Na przykład: Tworząc funkcję ogólną, która przyjmuje `AsRef<str>`, wyrażamy, że chcemy akceptować wszystkie odwołania, które można przekonwertować na [`&str`] jako argument.
/// Ponieważ zarówno [`String`], jak i [`&str`] implementują `AsRef<str>`, możemy przyjąć oba jako argument wejściowy.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Wykonuje konwersję.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Służy do taniej konwersji odniesienia mutable-to-mutable.
///
/// Ten trait jest podobny do [`AsRef`], ale używany do konwersji między zmiennymi odniesieniami.
/// Jeśli potrzebujesz wykonać kosztowną konwersję, lepiej zaimplementować [`From`] z typem `&mut T` lub napisać niestandardową funkcję.
///
/// **Note: Ten trait nie może zawieść **.Jeśli konwersja może się nie powieść, użyj dedykowanej metody, która zwraca [`Option<T>`] lub [`Result<T, E>`].
///
/// # Implementacje ogólne
///
/// - `AsMut` autodereferencje, jeśli typ wewnętrzny jest zmiennym odwołaniem (np .: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Używając `AsMut` jako trait bound dla funkcji ogólnej, możemy zaakceptować wszystkie zmienne odwołania, które można przekonwertować na typ `&mut T`.
/// Ponieważ [`Box<T>`] implementuje `AsMut<T>`, możemy napisać funkcję `add_one`, która przyjmuje wszystkie argumenty, które można przekonwertować na `&mut u64`.
/// Ponieważ [`Box<T>`] implementuje `AsMut<T>`, `add_one` akceptuje również argumenty typu `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Wykonuje konwersję.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Konwersja wartości do wartości, która zużywa wartość wejściową.Przeciwieństwo [`From`].
///
/// Należy unikać implementowania [`Into`] i zamiast tego wdrażać [`From`].
/// Implementacja [`From`] automatycznie zapewnia implementację [`Into`] dzięki ogólnej implementacji w standardowej bibliotece.
///
/// Preferuj używanie [`Into`] zamiast [`From`] podczas określania trait bounds w funkcji ogólnej, aby upewnić się, że typy, które implementują tylko [`Into`], mogą być również używane.
///
/// **Note: Ten trait nie może zawieść **.Jeśli konwersja może się nie powieść, użyj [`TryInto`].
///
/// # Implementacje ogólne
///
/// - [" Od`] " <T>dla U` implikuje `Into<U> for T`
/// - [`Into`] jest zwrotny, co oznacza, że zaimplementowano `Into<T> for T`
///
/// # Implementacja [`Into`] do konwersji na typy zewnętrzne w starych wersjach Rust
///
/// Przed Rust 1.41, jeśli typ docelowy nie był częścią bieżącego crate, nie można było bezpośrednio zaimplementować [`From`].
/// Na przykład weź ten kod:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Nie uda się to skompilować w starszych wersjach języka, ponieważ reguły osierocenia Rust były nieco bardziej rygorystyczne.
/// Aby to obejść, możesz bezpośrednio zaimplementować [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Ważne jest, aby zrozumieć, że [`Into`] nie zapewnia implementacji [`From`] (tak jak [`From`] robi z [`Into`]).
/// Dlatego należy zawsze próbować zaimplementować [`From`], a następnie wrócić do [`Into`], jeśli nie można zaimplementować [`From`].
///
/// # Examples
///
/// [`String`] implementuje [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Aby wyrazić, że chcemy, aby funkcja ogólna pobierała wszystkie argumenty, które można przekonwertować na określony typ `T`, możemy użyć trait bound [`Into`]`<T>`.
///
/// Na przykład: Funkcja `is_hello` przyjmuje wszystkie argumenty, które można przekształcić w [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Wykonuje konwersję.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Służy do wykonywania konwersji wartości do wartości z wykorzystaniem wartości wejściowej.Jest odwrotnością [`Into`].
///
/// Zawsze należy preferować implementację `From` zamiast [`Into`], ponieważ implementacja `From` automatycznie zapewnia implementację [`Into`] dzięki ogólnej implementacji w standardowej bibliotece.
///
///
/// Implementuj [`Into`] tylko w przypadku kierowania na wersję wcześniejszą niż Rust 1.41 i konwertowania na typ spoza bieżącego crate.
/// `From` nie był w stanie wykonać tego typu konwersji we wcześniejszych wersjach ze względu na zasady osierocenia Rust.
/// Aby uzyskać więcej informacji, zobacz [`Into`].
///
/// Preferuj [`Into`] zamiast `From` podczas określania trait bounds w funkcji ogólnej.
/// W ten sposób typy, które bezpośrednio implementują [`Into`], mogą być również używane jako argumenty.
///
/// `From` jest również bardzo przydatny podczas obsługi błędów.Podczas konstruowania funkcji, która może zakończyć się niepowodzeniem, zwracany typ będzie miał zwykle postać `Result<T, E>`.
/// `From` trait upraszcza obsługę błędów, umożliwiając funkcji zwracanie pojedynczego typu błędu, który obejmuje wiele typów błędów.Więcej informacji można znaleźć w sekcji "Examples" i [the book][book].
///
/// **Note: Ten trait nie może zawieść **.Jeśli konwersja może się nie powieść, użyj [`TryFrom`].
///
/// # Implementacje ogólne
///
/// - `From<T> for U` implikuje [`Into`]`<U>dla T`</u>
/// - `From` jest zwrotny, co oznacza, że zaimplementowano `From<T> for T`
///
/// # Examples
///
/// [`String`] wdraża `From<&str>`:
///
/// Jawna konwersja z `&str` na String jest wykonywana w następujący sposób:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Podczas obsługi błędów często warto zaimplementować `From` dla własnego typu błędu.
/// Konwertując podstawowe typy błędów na nasz własny niestandardowy typ błędu, który hermetyzuje podstawowy typ błędu, możemy zwrócić pojedynczy typ błędu bez utraty informacji o podstawowej przyczynie.
/// Operator '?' automatycznie konwertuje podstawowy typ błędu na nasz niestandardowy typ błędu, wywołując `Into<CliError>::into`, który jest automatycznie dostarczany podczas implementowania `From`.
/// Kompilator następnie wnioskuje, której implementacji `Into` należy użyć.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Wykonuje konwersję.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Próba konwersji, która zużywa `self`, co może być kosztowne lub nie.
///
/// Autorzy bibliotek zwykle nie powinni bezpośrednio implementować tego trait, ale powinni preferować implementację [`TryFrom`] trait, która oferuje większą elastyczność i zapewnia równoważną implementację `TryInto` za darmo, dzięki ogólnej implementacji w standardowej bibliotece.
/// Więcej informacji na ten temat można znaleźć w dokumentacji [`Into`].
///
/// # Wdrażanie `TryInto`
///
/// Obejmuje to te same ograniczenia i rozumowanie, co implementacja [`Into`], patrz tam, aby uzyskać szczegółowe informacje.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Typ zwracany w przypadku błędu konwersji.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Wykonuje konwersję.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Proste i bezpieczne konwersje typów, które w pewnych okolicznościach mogą się nie powieść w kontrolowany sposób.Jest odwrotnością [`TryInto`].
///
/// Jest to przydatne, gdy wykonujesz konwersję typu, która może odnieść trywialny sukces, ale może również wymagać specjalnej obsługi.
/// Na przykład nie ma możliwości przekonwertowania [`i64`] na [`i32`] przy użyciu [`From`] trait, ponieważ [`i64`] może zawierać wartość, której [`i32`] nie może reprezentować, a zatem konwersja spowoduje utratę danych.
///
/// Można to zrobić, skracając [`i64`] do [`i32`] (zasadniczo dając wartość [`i64`] modulo [`i32::MAX`]) lub po prostu zwracając [`i32::MAX`], lub inną metodą.
/// [`From`] trait jest przeznaczony do doskonałych konwersji, więc `TryFrom` trait informuje programistę, kiedy konwersja typu może pójść źle i pozwala mu zdecydować, jak sobie z tym poradzić.
///
/// # Implementacje ogólne
///
/// - `TryFrom<T> for U` implikuje [`TryInto`]`<U>dla T`</u>
/// - [`try_from`] jest zwrotny, co oznacza, że `TryFrom<T> for T` jest zaimplementowany i nie może zawieść-skojarzony typ `Error` do wywołania `T::try_from()` na wartości typu `T` to [`Infallible`].
/// Gdy typ [`!`] jest ustabilizowany, [`Infallible`] i [`!`] będą równoważne.
///
/// `TryFrom<T>` można zaimplementować w następujący sposób:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Jak opisano, [`i32`] implementuje `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Cicho obcina `big_number`, wymaga wykrycia i obsługi obcięcia po fakcie.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Zwraca błąd, ponieważ `big_number` jest zbyt duży, aby zmieścić się w `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Zwraca `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Typ zwracany w przypadku błędu konwersji.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Wykonuje konwersję.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// OGÓLNE IMPLS
////////////////////////////////////////////////////////////////////////////////

// Jak unosi się nad&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Ponieważ podnosi ponad &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): zamień powyższe implikacje dla&/&mut na następujący, bardziej ogólny:
// // Jak podnosi nad Derefem
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut podnosi ponad &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): zastąp powyższy impl dla &mut następującym, bardziej ogólnym:
// // AsMut przechodzi przez DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Od implikuje do
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Od (a więc do) jest zwrotne
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Uwaga o stabilności:** Ten plik impl jeszcze nie istnieje, ale jesteśmy "reserving space", aby dodać go do future.
/// Aby uzyskać szczegółowe informacje, patrz [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): zamiast tego zrób pryncypialną poprawkę.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implikuje TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Nieomylne konwersje są semantycznie równoważne omylnym konwersjom z niezamieszkanym typem błędu.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLY BETONOWE
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// TYP BŁĘDU BEZ BŁĘDU
////////////////////////////////////////////////////////////////////////////////

/// Typ błędu dla błędów, które nigdy nie mogą się zdarzyć.
///
/// Ponieważ to wyliczenie nie ma wariantu, wartość tego typu nie może nigdy istnieć.
/// Może to być przydatne w przypadku ogólnych interfejsów API, które używają [`Result`] i parametryzują typ błędu, aby wskazać, że wynikiem jest zawsze [`Ok`].
///
/// Na przykład [`TryFrom`] trait (konwersja, która zwraca [`Result`]) ma ogólną implementację dla wszystkich typów, w których istnieje odwrotna implementacja [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Zgodność z Future
///
/// To wyliczenie ma taką samą rolę jak [the `!`“never”type][never], co jest niestabilne w tej wersji Rust.
/// Po ustabilizowaniu `!` planujemy uczynić `Infallible` aliasem typu:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …I ostatecznie wycofaj `Infallible`.
///
/// Jest jednak jeden przypadek, w którym składnia `!` może zostać użyta, zanim `!` zostanie ustabilizowany jako typ pełnoprawny: w pozycji zwracanego typu funkcji.
/// W szczególności możliwe są implementacje dla dwóch różnych typów wskaźników funkcji:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Ponieważ `Infallible` jest wyliczeniem, ten kod jest prawidłowy.
/// Jednak gdy `Infallible` stanie się aliasem dla never type, dwa `impl`s zaczną się nakładać i dlatego będą zabronione przez reguły koherencji języka trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}