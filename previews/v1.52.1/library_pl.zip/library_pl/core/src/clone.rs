//! `Clone` trait dla typów, których nie można " niejawnie skopiować`.
//!
//! W Rust niektóre proste typy to "implicitly copyable" i kiedy przypiszesz je lub przekażesz jako argumenty, odbiorca otrzyma kopię, pozostawiając oryginalną wartość na miejscu.
//! Te typy nie wymagają alokacji do kopiowania i nie mają finalizatorów (tj. Nie zawierają posiadanych pudełek ani nie implementują [`Drop`]), więc kompilator uważa je za tanie i bezpieczne do skopiowania.
//!
//! W przypadku innych typów kopie należy wykonać jawnie, stosując konwencję implementującą [`Clone`] trait i wywołując metodę [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Podstawowy przykład użycia:
//!
//! ```
//! let s = String::new(); // Typ łańcuchowy implementuje Clone
//! let copy = s.clone(); // więc możemy go sklonować
//! ```
//!
//! Aby łatwo zaimplementować Clone trait, możesz również użyć `#[derive(Clone)]`.Przykład:
//!
//! ```
//! #[derive(Clone)] // dodajemy Clone trait do struktury Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // a teraz możemy go sklonować!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Typowy trait dla możliwości jawnego duplikowania obiektu.
///
/// Różni się od [`Copy`] tym, że [`Copy`] jest niejawny i wyjątkowo niedrogi, podczas gdy `Clone` jest zawsze jawny i może być drogi lub nie.
/// Aby wymusić te cechy, Rust nie pozwala na ponowną implementację [`Copy`], ale możesz ponownie zaimplementować `Clone` i uruchomić dowolny kod.
///
/// Ponieważ `Clone` jest bardziej ogólny niż [`Copy`], możesz automatycznie zmienić dowolne [`Copy`] na `Clone`.
///
/// ## Derivable
///
/// Ten trait może być używany z `#[derive]`, jeśli wszystkie pola mają wartość `Clone`.Implementacja metody pochodnej [`Clone`] wywołuje [`clone`] w każdym polu.
///
/// [`clone`]: Clone::clone
///
/// W przypadku struktury ogólnej `#[derive]` implementuje `Clone` warunkowo, dodając powiązany `Clone` na parametrach ogólnych.
///
/// ```
/// // `derive` implementuje Clone for Reading<T>kiedy T jest klonem.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Jak mogę wdrożyć `Clone`?
///
/// Typy [`Copy`] powinny mieć trywialną implementację `Clone`.Bardziej formalnie:
/// jeśli `T: Copy`, `x: T` i `y: &T`, to `let x = y.clone();` jest równoważne `let x = *y;`.
/// Implementacje ręczne powinny być ostrożne, aby zachować tę niezmienność;jednak niebezpieczny kod nie może polegać na nim, aby zapewnić bezpieczeństwo pamięci.
///
/// Przykładem jest struktura ogólna przechowująca wskaźnik funkcji.W tym przypadku implementacja `Clone` nie może być " pochodną`, ale może zostać zaimplementowana jako:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Dodatkowi realizatorzy
///
/// Oprócz [implementors listed below][impls] w `Clone` są również stosowane następujące typy:
///
/// * Typy elementów funkcji (tj. Różne typy zdefiniowane dla każdej funkcji)
/// * Typy wskaźników funkcji (np. `fn() -> i32`)
/// * Typy tablic dla wszystkich rozmiarów, jeśli typ elementu również implementuje `Clone` (np. `[i32; 123456]`)
/// * Typy krotek, jeśli każdy komponent implementuje również `Clone` (np. `()`, `(i32, bool)`)
/// * Typy zamknięć, jeśli nie wychwytują żadnej wartości ze środowiska lub jeśli wszystkie takie przechwycone wartości same implementują `Clone`.
///   Zwróć uwagę, że zmienne przechwycone przez wspólne odwołanie zawsze implementują `Clone` (nawet jeśli odwołanie tego nie robi), podczas gdy zmienne przechwycone przez mutowalne odwołanie nigdy nie implementują `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Zwraca kopię wartości.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementuje Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Wykonuje przydział kopii z `source`.
    ///
    /// `a.clone_from(&b)` jest odpowiednikiem `a = b.clone()` pod względem funkcjonalności, ale można go zastąpić, aby ponownie wykorzystać zasoby `a`, aby uniknąć niepotrzebnych alokacji.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Wyprowadź makro generując implik z trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): te struktury są używane wyłącznie przez#[pochodne] do zapewnienia, że każdy składnik typu implementuje Clone lub Copy.
//
//
// Te struktury nigdy nie powinny pojawiać się w kodzie użytkownika.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementacje `Clone` dla typów pierwotnych.
///
/// Implementacje, których nie można opisać w Rust, są zaimplementowane w `traits::SelectionContext::copy_clone_conditions()` w `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Współużytkowane odniesienia można klonować, ale zmienne odniesienia *nie*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Współużytkowane odniesienia można klonować, ale zmienne odniesienia *nie*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}