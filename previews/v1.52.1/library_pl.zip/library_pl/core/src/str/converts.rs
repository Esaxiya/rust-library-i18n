//! Sposoby tworzenia `str` z wycinka bajtów.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Konwertuje kawałek bajtów na kawałek ciągu.
///
/// Fragment łańcucha ([`&str`]) składa się z bajtów ([`u8`]), a segment bajtu ([`&[u8]`][byteslice]) z bajtów, więc ta funkcja konwertuje między nimi.
/// Jednak nie wszystkie segmenty bajtów są prawidłowymi segmentami łańcuchów: [`&str`] wymaga, aby był prawidłowy UTF-8.
/// `from_utf8()` sprawdza, czy bajty są prawidłowe UTF-8, a następnie przeprowadza konwersję.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Jeśli masz pewność, że segment bajtów jest prawidłowy UTF-8 i nie chcesz ponosić narzutu związanego z kontrolą poprawności, istnieje niebezpieczna wersja tej funkcji, [`from_utf8_unchecked`], która zachowuje się tak samo, ale pomija sprawdzanie.
///
///
/// Jeśli potrzebujesz `String` zamiast `&str`, rozważ [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Ponieważ możesz przydzielić `[u8; N]` w stosie i możesz wziąć [`&[u8]`][byteslice] z tego, ta funkcja jest jednym ze sposobów na uzyskanie ciągu przydzielonego stosu.Przykład tego znajduje się w sekcji przykładów poniżej.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Zwraca `Err`, jeśli wycinek nie jest UTF-8 z opisem, dlaczego podany wycinek nie jest UTF-8.
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::str;
///
/// // kilka bajtów w vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Wiemy, że te bajty są prawidłowe, więc po prostu użyj `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Niepoprawne bajty:
///
/// ```
/// use std::str;
///
/// // niektóre nieprawidłowe bajty w vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Zobacz dokumentację [`Utf8Error`], aby uzyskać więcej informacji na temat rodzajów błędów, które mogą zostać zwrócone.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // kilka bajtów w tablicy przydzielonej na stosie
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Wiemy, że te bajty są prawidłowe, więc po prostu użyj `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // BEZPIECZEŃSTWO: Właśnie przeprowadziłem weryfikację.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Konwertuje zmienny wycinek bajtów na zmienny wycinek ciągu.
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" jako zmienny vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Ponieważ wiemy, że te bajty są prawidłowe, możemy użyć `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Niepoprawne bajty:
///
/// ```
/// use std::str;
///
/// // Niektóre nieprawidłowe bajty w zmiennym vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Zobacz dokumentację [`Utf8Error`], aby uzyskać więcej informacji na temat rodzajów błędów, które mogą zostać zwrócone.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // BEZPIECZEŃSTWO: Właśnie przeprowadziłem weryfikację.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Konwertuje wycinek bajtów na wycinek ciągu bez sprawdzania, czy ciąg zawiera prawidłowy UTF-8.
///
/// Więcej informacji można znaleźć w bezpiecznej wersji [`from_utf8`].
///
/// # Safety
///
/// Ta funkcja jest niebezpieczna, ponieważ nie sprawdza, czy przekazane do niej bajty są prawidłowe UTF-8.
/// Jeśli to ograniczenie zostanie naruszone, powstanie niezdefiniowane zachowanie, ponieważ reszta Rust zakłada, że [`&str`] s są prawidłowe UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::str;
///
/// // kilka bajtów w vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // BEZPIECZEŃSTWO: wywołujący musi zagwarantować, że bajty `v` są prawidłowe UTF-8.
    // Opiera się również na `&str` i `&[u8]` o tym samym układzie.
    unsafe { mem::transmute(v) }
}

/// Konwertuje kawałek bajtów na kawałek łańcucha bez sprawdzania, czy ciąg zawiera prawidłowe UTF-8;wersja zmienna.
///
///
/// Więcej informacji można znaleźć w niezmiennej wersji [`from_utf8_unchecked()`].
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // BEZPIECZEŃSTWO: wywołujący musi zagwarantować, że bajty `v`
    // są poprawne w UTF-8, więc rzutowanie na `*mut str` jest bezpieczne.
    // Ponadto wyłuskiwanie wskaźnika jest bezpieczne, ponieważ ten wskaźnik pochodzi z odniesienia, które jest gwarantowane dla zapisów.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}