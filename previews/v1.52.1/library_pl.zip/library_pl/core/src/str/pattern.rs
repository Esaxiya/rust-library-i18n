//! String Pattern API.
//!
//! Interfejs API Pattern zapewnia ogólny mechanizm używania różnych typów wzorców podczas przeszukiwania ciągu.
//!
//! Aby uzyskać więcej informacji, zobacz traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] i [`DoubleEndedSearcher`].
//!
//! Chociaż ten interfejs API jest niestabilny, jest udostępniany za pośrednictwem stabilnych interfejsów API typu [`str`].
//!
//! # Examples
//!
//! [`Pattern`] jest [implemented][pattern-impls] w stabilnym API dla [`&str`][`str`], [`char`], fragmentach [`char`] oraz funkcjach i domknięciach implementujących `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // wzór znaków
//! assert_eq!(s.find('n'), Some(2));
//! // kawałek wzoru znaków
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // wzór zamknięcia
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Wzór sznurka.
///
/// `Pattern<'a>` wyraża, że typ implementujący może być używany jako wzorzec łańcucha do wyszukiwania w [`&'a str`][str].
///
/// Na przykład `'a'` i `"aa"` są wzorcami, które pasują do indeksu `1` w ciągu `"baaaab"`.
///
/// Sam trait działa jako konstruktor dla skojarzonego typu [`Searcher`], który wykonuje rzeczywistą pracę polegającą na znajdowaniu wystąpień wzorca w ciągu.
///
///
/// W zależności od typu wzorca zachowanie metod takich jak [`str::find`] i [`str::contains`] może ulec zmianie.
/// Poniższa tabela opisuje niektóre z tych zachowań.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Powiązana wyszukiwarka dla tego wzorca
    type Searcher: Searcher<'a>;

    /// Konstruuje powiązaną wyszukiwarkę z `self` i `haystack` do wyszukiwania.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Sprawdza, czy wzór pasuje do dowolnego miejsca w stogu siana
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Sprawdza, czy wzór pasuje do przodu stogu siana
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Sprawdza, czy wzór pasuje do tyłu stogu siana
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Usuwa wzór z przodu stogu siana, jeśli pasuje.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // BEZPIECZEŃSTWO: `Searcher` jest znany z zwracania prawidłowych indeksów.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Usuwa wzór z tyłu stogu siana, jeśli pasuje.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // BEZPIECZEŃSTWO: `Searcher` jest znany z zwracania prawidłowych indeksów.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Wynik wywołania [`Searcher::next()`] lub [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Wyraża, że dopasowanie wzorca zostało znalezione w `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Wyraża, że `haystack[a..b]` został odrzucony jako możliwe dopasowanie do wzorca.
    ///
    /// Zwróć uwagę, że między dwoma " Dopasowaniami` może znajdować się więcej niż jeden `Reject`, nie ma potrzeby łączenia ich w jedno.
    ///
    ///
    Reject(usize, usize),
    /// Wyraża, że odwiedzono każdy bajt stogu siana, co kończy iterację.
    ///
    Done,
}

/// Wyszukiwarka ciągu znaków.
///
/// Ten trait zapewnia metody wyszukiwania nienakładających się dopasowań wzorca, zaczynając od (left) z przodu łańcucha.
///
/// Zostanie zaimplementowany przez powiązane typy `Searcher` [`Pattern`] trait.
///
/// trait jest oznaczony jako niebezpieczny, ponieważ indeksy zwracane przez metody [`next()`][Searcher::next] muszą leżeć na prawidłowych granicach utf8 w stogu siana.
/// Umożliwia to konsumentom tego trait cięcie stogu siana bez dodatkowych kontroli w czasie wykonywania.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter dla szukanego ciągu bazowego
    ///
    /// Zawsze zwróci ten sam [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Wykonuje następny krok wyszukiwania, zaczynając od przodu.
    ///
    /// - Zwraca [`Match(a, b)`][SearchStep::Match], jeśli `haystack[a..b]` pasuje do wzorca.
    /// - Zwraca [`Reject(a, b)`][SearchStep::Reject], jeśli `haystack[a..b]` nie może dopasować wzorca, nawet częściowo.
    /// - Zwraca [`Done`][SearchStep::Done], jeśli odwiedzono każdy bajt stogu siana.
    ///
    /// Strumień wartości [`Match`][SearchStep::Match] i [`Reject`][SearchStep::Reject] aż do [`Done`][SearchStep::Done] będzie zawierał zakresy indeksów, które sąsiadują ze sobą, nie pokrywają się, pokrywają cały stóg siana i leżą na granicach utf8.
    ///
    ///
    /// Wynik [`Match`][SearchStep::Match] musi zawierać cały dopasowany wzorzec, jednak wyniki [`Reject`][SearchStep::Reject] mogą zostać podzielone na dowolne, wiele sąsiednich fragmentów.Oba zakresy mogą mieć zerową długość.
    ///
    /// Na przykład wzór `"aaa"` i stóg siana `"cbaaaaab"` mogą generować strumień
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Znajduje następny wynik [`Match`][SearchStep::Match].Zobacz [`next()`][Searcher::next].
    ///
    /// W przeciwieństwie do [`next()`][Searcher::next], nie ma gwarancji, że zwrócone zakresy this i [`next_reject`][Searcher::next_reject] będą się nakładać.
    /// Zwróci to `(start_match, end_match)`, gdzie dopasowanie_początkowe to indeks miejsca rozpoczęcia dopasowania, a dopasowanie końcówka to indeks występujący po zakończeniu dopasowania.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Znajduje następny wynik [`Reject`][SearchStep::Reject].Zobacz [`next()`][Searcher::next] i [`next_match()`][Searcher::next_match].
    ///
    /// W przeciwieństwie do [`next()`][Searcher::next], nie ma gwarancji, że zwrócone zakresy this i [`next_match`][Searcher::next_match] będą się nakładać.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Wyszukiwarka wsteczna dla wzorca łańcuchowego.
///
/// Ten trait zapewnia metody wyszukiwania nienakładających się dopasowań wzorca, zaczynając od tylnego (right) ciągu.
///
/// Zostanie zaimplementowany przez powiązane typy [`Searcher`] [`Pattern`] trait, jeśli wzorzec obsługuje wyszukiwanie go od tyłu.
///
///
/// Zakresy indeksów zwracane przez to trait nie muszą dokładnie odpowiadać zakresom wyszukiwania w przód w tył.
///
/// Z powodu, dla którego ten trait jest oznaczony jako niebezpieczny, zobacz je nadrzędny trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Wykonuje następny krok wyszukiwania, zaczynając od tyłu.
    ///
    /// - Zwraca [`Match(a, b)`][SearchStep::Match], jeśli `haystack[a..b]` pasuje do wzorca.
    /// - Zwraca [`Reject(a, b)`][SearchStep::Reject], jeśli `haystack[a..b]` nie może dopasować wzorca, nawet częściowo.
    /// - Zwraca [`Done`][SearchStep::Done], jeśli odwiedzono każdy bajt stogu siana
    ///
    /// Strumień wartości [`Match`][SearchStep::Match] i [`Reject`][SearchStep::Reject] aż do [`Done`][SearchStep::Done] będzie zawierał zakresy indeksów, które sąsiadują ze sobą, nie pokrywają się, pokrywają cały stóg siana i leżą na granicach utf8.
    ///
    ///
    /// Wynik [`Match`][SearchStep::Match] musi zawierać cały dopasowany wzorzec, jednak wyniki [`Reject`][SearchStep::Reject] mogą zostać podzielone na dowolne, wiele sąsiednich fragmentów.Oba zakresy mogą mieć zerową długość.
    ///
    /// Na przykład wzór `"aaa"` i stóg siana `"cbaaaaab"` mogą generować strumień `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Znajduje następny wynik [`Match`][SearchStep::Match].
    /// Zobacz [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Znajduje następny wynik [`Reject`][SearchStep::Reject].
    /// Zobacz [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Znacznik trait do wyrażenia, że [`ReverseSearcher`] może być użyty do implementacji [`DoubleEndedIterator`].
///
/// W tym celu impl z [`Searcher`] i [`ReverseSearcher`] muszą spełniać następujące warunki:
///
/// - Wszystkie wyniki `next()` muszą być identyczne z wynikami `next_back()` w odwrotnej kolejności.
/// - `next()` a `next_back()` muszą zachowywać się jak dwa końce zakresu wartości, to znaczy nie mogą "walk past each other".
///
/// # Examples
///
/// `char::Searcher` jest `DoubleEndedSearcher`, ponieważ wyszukiwanie [`char`] wymaga patrzenia tylko na jeden na raz, który zachowuje się tak samo z obu stron.
///
/// `(&str)::Searcher` nie jest `DoubleEndedSearcher`, ponieważ wzorzec `"aa"` w stogu siana `"aaa"` pasuje jako `"[aa]a"` lub `"a[aa]"`, w zależności od tego, z której strony jest przeszukiwany.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl dla char
/////////////////////////////////////////////////////////////////////////////

/// Powiązany typ dla `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // niezmiennik bezpieczeństwa: `finger`/`finger_back` musi być prawidłowym indeksem bajtów utf8 `haystack` Ten niezmiennik może zostać złamany *w ramach* next_match i next_match_back, jednak muszą one kończyć się palcami na prawidłowych granicach punktu kodowego.
    //
    //
    /// `finger` jest bieżącym indeksem bajtów wyszukiwania do przodu.
    /// Wyobraź sobie, że istnieje przed bajtem w jego indeksie, tj
    /// `haystack[finger]` jest pierwszym bajtem wycinka, który musimy sprawdzić podczas wyszukiwania w przód
    ///
    finger: usize,
    /// `finger_back` jest bieżącym indeksem bajtów wyszukiwania wstecznego.
    /// Wyobraź sobie, że istnieje po bajcie w jego indeksie, tj
    /// haystack [finger_back, 1] to ostatni bajt wycinka, który musimy sprawdzić podczas wyszukiwania w przód (a tym samym pierwszy bajt do sprawdzenia podczas wywoływania next_back()).
    ///
    finger_back: usize,
    /// Poszukiwana postać
    needle: char,

    // niezmiennik bezpieczeństwa: `utf8_size` musi być mniejszy niż 5
    /// Liczba bajtów zajmowanych przez `needle` podczas kodowania w utf8.
    utf8_size: usize,
    /// Kopia `needle` zakodowana w utf8
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // BEZPIECZEŃSTWO: 1-4 gwarantuje bezpieczeństwo `get_unchecked`
        // 1. `self.finger` i `self.finger_back` są trzymane na granicach Unicode (jest to niezmienne)
        // 2. `self.finger >= 0` ponieważ zaczyna się od 0 i tylko rośnie
        // 3. `self.finger < self.finger_back` ponieważ w przeciwnym razie znak `iter` zwróciłby `SearchStep::Done`
        // 4.
        // `self.finger` pojawia się przed końcem stogu siana, ponieważ `self.finger_back` zaczyna się na końcu i tylko maleje
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // dodaj przesunięcie bajtów bieżącego znaku bez ponownego kodowania jako utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // zdobądź stóg siana po znalezieniu ostatniej postaci
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // ostatni bajt igły zakodowanej w utf8 BEZPIECZEŃSTWO: mamy niezmiennik, że `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Nowy palec to indeks bajtu, który znaleźliśmy, plus jeden, ponieważ zapamiętaliśmy ostatni bajt znaku.
                //
                // Zauważ, że nie zawsze daje nam to wgląd w granicę UTF8.
                // Jeśli *nie* znaleźliśmy naszego znaku, być może zindeksowaliśmy do nie ostatniego bajtu 3-bajtowego lub 4-bajtowego znaku.
                // Nie możemy po prostu przejść do następnego prawidłowego bajtu początkowego, ponieważ znak taki jak ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` sprawi, że zawsze znajdziemy drugi bajt podczas wyszukiwania trzeciego.
                //
                //
                // Jednak jest to całkowicie w porządku.
                // Chociaż mamy niezmiennik, że self.finger znajduje się na granicy UTF8, ten niezmiennik nie jest oparty na tej metodzie (jest oparty na CharSearcher::next()).
                //
                // Opuszczamy tę metodę tylko wtedy, gdy dotrzemy do końca łańcucha lub jeśli coś znajdziemy.Kiedy coś znajdziemy, `finger` zostanie ustawiony na granicę UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // nic nie znalazłem, wyjdź
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // niech next_reject użyje domyślnej implementacji z Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // BEZPIECZEŃSTWO: zobacz komentarz dotyczący next() powyżej
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // odejmij przesunięcie bajtów bieżącego znaku bez ponownego kodowania jako utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // podnieść stóg siana do, ale nie wliczając ostatnio przeszukiwanej postaci
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // ostatni bajt igły zakodowanej w utf8 BEZPIECZEŃSTWO: mamy niezmiennik, że `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // przeszukaliśmy wycinek przesunięty o self.finger, dodaliśmy self.finger, aby odzyskać oryginalny indeks
                //
                let index = self.finger + index;
                // memrchr zwróci indeks bajtu, który chcemy znaleźć.
                // W przypadku znaku ASCII rzeczywiście tak jest, gdybyśmy chcieli, aby nasz nowy palec był ("after" to znak znaleziony w paradygmacie odwrotnej iteracji).
                //
                // W przypadku znaków wielobajtowych musimy przeskoczyć o liczbę więcej bajtów, które mają niż ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // przesuń palec na przed znalezionym znakiem (tj. na jego indeksie początkowym)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Nie możemy tutaj użyć finger_back=index, size + 1.
                // Jeśli znaleźliśmy ostatni znak o innym rozmiarze (lub środkowy bajt innego znaku), musimy zrzucić finger_back do `index`.
                // To podobnie sprawia, że `finger_back` może już nie znajdować się na granicy, ale jest to w porządku, ponieważ wychodzimy z tej funkcji tylko na granicy lub gdy stóg siana został całkowicie przeszukany.
                //
                //
                // W przeciwieństwie do next_match nie ma problemu z powtarzającymi się bajtami w utf-8, ponieważ szukamy ostatniego bajtu, a ostatni bajt możemy znaleźć tylko podczas wyszukiwania w odwrotnej kolejności.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // nic nie znalazłem, wyjdź
                return None;
            }
        }
    }

    // niech next_reject_back użyje domyślnej implementacji z Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Wyszukuje znaki, które są równe podanemu [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl dla opakowania MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Porównaj długości wewnętrznego iteratora segmentu bajtów, aby znaleźć długość bieżącego znaku
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Porównaj długości wewnętrznego iteratora segmentu bajtów, aby znaleźć długość bieżącego znaku
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl dla&[znak]
/////////////////////////////////////////////////////////////////////////////

// Todo: Zmień/Usuń z powodu niejasności znaczenia.

/// Powiązany typ dla `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Wyszukuje znaki, które są równe dowolnemu [`char`] w wycinku.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl dla F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Powiązany typ dla `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Wyszukuje [`char`], które pasują do podanego predykatu.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl dla&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegaci do `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl dla &str
/////////////////////////////////////////////////////////////////////////////

/// Wyszukiwanie podciągów bez alokacji.
///
/// Obsłuży wzorzec `""` jako zwracanie pustych dopasowań na każdej granicy znaku.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Sprawdza, czy wzór pasuje do przodu stogu siana.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Usuwa wzór z przodu stogu siana, jeśli pasuje.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // BEZPIECZEŃSTWO: właśnie zweryfikowano istnienie przedrostka.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Sprawdza, czy wzór pasuje do tyłu stogu siana.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Usuwa wzór z tyłu stogu siana, jeśli pasuje.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // BEZPIECZEŃSTWO: właśnie zweryfikowano istnienie sufiksu.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Dwukierunkowa wyszukiwarka podciągów
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Powiązany typ dla `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // pusta igła odrzuca każdy znak i dopasowuje każdy pusty ciąg między nimi
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher generuje prawidłowe *Match* indeksy, które dzielą się na granicach znaków, o ile poprawnie dopasowuje i że stóg siana i igła są prawidłowe UTF-8 *Odrzuty* z algorytmu mogą spaść na dowolne indeksy, ale przejdziemy je ręcznie do następnej granicy znaku, aby były bezpieczne dla utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // przejdź do następnej granicy znaku
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // napisz przypadki `true` i `false`, aby zachęcić kompilator do specjalizacji tych dwóch przypadków osobno.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // przejdź do następnej granicy znaku
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // napisz `true` i `false`, jak `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Stan wewnętrzny dwukierunkowego algorytmu wyszukiwania podciągów.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// krytyczny wskaźnik faktoryzacji
    crit_pos: usize,
    /// krytyczny wskaźnik faktoryzacji dla odwróconej igły
    crit_pos_back: usize,
    period: usize,
    /// `byteset` jest rozszerzeniem (nie jest częścią dwukierunkowego algorytmu);
    /// jest to 64-bitowy "fingerprint", gdzie każdy ustawiony bit `j` odpowiada (bajtowi&63)==j obecnemu w igle.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// indeks do igły, przed którą już dopasowaliśmy
    memory: usize,
    /// indeks w igłę, po której już dopasowaliśmy
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Szczególnie czytelne wyjaśnienie tego, co się tutaj dzieje, można znaleźć w książce Crochemore i Rytter "Text Algorithms", rozdział 13.
        // W szczególności patrz kod "Algorithm CP" na str.
        // 323.
        //
        // Chodzi o to, że mamy pewne krytyczne rozłożenie na czynniki (u, v) igły i chcemy określić, czy u jest przyrostkiem&v [.. kropka].
        // Jeśli tak, używamy "Algorithm CP1".
        // W przeciwnym razie używamy "Algorithm CP2", który jest zoptymalizowany pod kątem dużych okresów igły.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // przypadek krótkiego okresu-okres jest dokładny obliczyć oddzielną faktoryzację krytyczną dla odwróconej igły x=u 'v' gdzie | v '|<period(x).
            //
            // Przyspiesza to już znany okres.
            // Zauważ, że przypadek taki jak x= "acba" może być rozłożony na czynniki dokładnie w przód (kryt_pos=1, okres=3), podczas gdy jest uwzględniany z przybliżonym okresem w odwrotnej kolejności (kryt_pos=2, okres=2).
            // Używamy podanej odwrotnej faktoryzacji, ale zachowujemy dokładny okres.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // przypadek długi okres-mamy przybliżenie do rzeczywistego okresu i nie używamy zapamiętywania.
            //
            //
            // W przybliżeniu okres dolną granicą max(|u|, |v|) + 1.
            // Krytyczna faktoryzacja jest skuteczna w przypadku wyszukiwania w przód i w tył.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Wartość zastępcza oznaczająca, że okres jest długi
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Jedną z głównych idei Two-Way jest to, że rozłożymy igłę na dwie połowy (u, v) i zaczniemy próbować znaleźć v w stogu siana, skanując od lewej do prawej.
    // Jeśli v pasuje, próbujemy dopasować u, skanując od prawej do lewej.
    // To, jak daleko możemy przeskoczyć, gdy napotkamy niedopasowanie, opiera się na fakcie, że (u, v) jest kluczowym czynnikiem dla igły.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` używa `self.position` jako kursora
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Sprawdź, czy mamy miejsce do wyszukiwania w pozycji + needle_last nie mogą się przepełniać, jeśli założymy, że plasterki są ograniczone zakresem isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Szybko pomijaj duże fragmenty niezwiązane z naszym podciągiem
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Sprawdź, czy prawa część igły pasuje
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Sprawdź, czy lewa część igły pasuje
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Znaleźliśmy dopasowanie!
            let match_pos = self.position;

            // Note: dodaj self.period zamiast needle.len(), aby uzyskać nakładające się dopasowania
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // ustawione na needle.len(), self.period dla pokrywających się dopasowań
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Podąża za pomysłami `next()`.
    //
    // Definicje są symetryczne, gdzie period(x) = period(reverse(x)) i local_period(u, v) = local_period(reverse(v), reverse(u)), więc jeśli (u, v) jest krytycznym faktoryzacją, to jest (reverse(v), reverse(u)).
    //
    //
    // Dla przypadku odwrotnego obliczyliśmy krytyczną faktoryzację x=u 'v' (pole `crit_pos_back`).Potrzebujemy | u |<period(x) dla przypadku przodu, a zatem | v '|<period(x) do tyłu.
    //
    // Aby przeszukać stóg siana do tyłu, przeszukujemy do przodu odwrócony stóg siana z odwróconą igłą, dopasowując najpierw u ', a następnie v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` używa `self.end` jako swojego kursora-tak, że `next()` i `next_back()` są niezależne.
        //
        let old_end = self.end;
        'search: loop {
            // Sprawdź, czy na końcu mamy miejsce do przeszukania, needle.len() zawinie się, gdy nie będzie już miejsca, ale ze względu na ograniczenia długości kawałków nigdy nie zawinie się do końca stogu siana.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Szybko pomijaj duże fragmenty niezwiązane z naszym podciągiem
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Sprawdź, czy lewa część igły pasuje
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Sprawdź, czy prawa część igły pasuje
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Znaleźliśmy dopasowanie!
            let match_pos = self.end - needle.len();
            // Note: sub self.period zamiast needle.len(), aby mieć nakładające się dopasowania
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Oblicz maksymalny sufiks `arr`.
    //
    // Maksymalnym sufiksem jest możliwa krytyczna faktoryzacja (u, v) `arr`.
    //
    // Zwraca (`i`, `p`), gdzie `i` to początkowy indeks v, a `p` to okres v.
    //
    // `order_greater` określa, czy porządek leksykalny to `<` czy `>`.
    // Należy obliczyć oba rzędy-kolejność z największym `i` daje krytyczną faktoryzację.
    //
    //
    // W przypadku długich okresów wynikowy okres nie jest dokładny (jest zbyt krótki).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Odpowiada i w artykule
        let mut right = 1; // Odpowiada j w artykule
        let mut offset = 0; // Odpowiada k w artykule, ale zaczynając od 0
        // aby dopasować indeksowanie oparte na 0.
        let mut period = 1; // Odpowiada p w artykule

        while let Some(&a) = arr.get(right + offset) {
            // `left` będzie wbounds, gdy `right` jest.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Sufiks jest mniejszy, kropka to dotychczas cały prefiks.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Przejdź przez powtórzenie bieżącego okresu.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Przyrostek jest większy, zacznij od nowa od bieżącej lokalizacji.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Oblicz maksymalny sufiks odwrotności `arr`.
    //
    // Maksymalnym sufiksem jest możliwa krytyczna faktoryzacja (u ', v') `arr`.
    //
    // Zwraca `i`, gdzie `i` jest początkowym indeksem v ', od tyłu;
    // zwraca natychmiast po osiągnięciu okresu `known_period`.
    //
    // `order_greater` określa, czy porządek leksykalny to `<` czy `>`.
    // Należy obliczyć oba rzędy-kolejność z największym `i` daje krytyczną faktoryzację.
    //
    //
    // W przypadku długich okresów wynikowy okres nie jest dokładny (jest zbyt krótki).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Odpowiada i w artykule
        let mut right = 1; // Odpowiada j w artykule
        let mut offset = 0; // Odpowiada k w artykule, ale zaczynając od 0
        // aby dopasować indeksowanie oparte na 0.
        let mut period = 1; // Odpowiada p w artykule
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Sufiks jest mniejszy, kropka to dotychczas cały prefiks.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Przejdź przez powtórzenie bieżącego okresu.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Przyrostek jest większy, zacznij od nowa od bieżącej lokalizacji.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy pozwala algorytmowi na pomijanie niedopasowań tak szybko, jak to możliwe, lub na pracę w trybie, w którym stosunkowo szybko emituje odrzucenia.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Jak najszybciej przechodź do interwałów meczy
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emituj odrzuca regularnie
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}