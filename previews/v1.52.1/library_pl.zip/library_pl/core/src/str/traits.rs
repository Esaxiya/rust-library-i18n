//! Implementacje Trait dla `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementuje porządkowanie ciągów.
///
/// Łańcuchy są uporządkowane [lexicographically](Ord#lexicographical-comparison) według wartości bajtów.
/// To porządkuje punkty kodowe Unicode na podstawie ich pozycji na wykresach kodów.
/// Niekoniecznie jest to to samo, co kolejność "alphabetical", która różni się w zależności od języka i lokalizacji.
/// Sortowanie ciągów zgodnie ze standardami akceptowanymi kulturowo wymaga danych specyficznych dla ustawień regionalnych, które są poza zakresem typu `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementuje operacje porównania na ciągach.
///
/// Łańcuchy są porównywane [lexicographically](Ord#lexicographical-comparison) według wartości bajtów.
/// To porównuje punkty kodowe Unicode na podstawie ich pozycji na wykresach kodów.
/// Niekoniecznie jest to to samo, co kolejność "alphabetical", która różni się w zależności od języka i lokalizacji.
/// Porównywanie ciągów znaków zgodnie ze standardami akceptowanymi kulturowo wymaga danych specyficznych dla ustawień regionalnych, które wykraczają poza zakres typu `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementuje wycinanie podciągów ze składnią `&self[..]` lub `&mut self[..]`.
///
/// Zwraca wycinek całego ciągu, tj. Zwraca `&self` lub `&mut self`.Odpowiednik " &self [0 ..
/// len] `lub`&mut self [0 ..
/// len]`.
/// W przeciwieństwie do innych operacji indeksowania, to nigdy nie może panic.
///
/// Ta operacja to *O*(1).
///
/// Przed 1.20.0 te operacje indeksowania były nadal obsługiwane przez bezpośrednią implementację `Index` i `IndexMut`.
///
/// Odpowiednik `&self[0 .. len]` lub `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementuje wycinanie podciągów ze składnią `&self[begin .. end]` lub `&mut self[begin .. end]`.
///
/// Zwraca wycinek podanego ciągu z zakresu bajtów [" początek`, `end`).
///
/// Ta operacja to *O*(1).
///
/// Przed 1.20.0 te operacje indeksowania były nadal obsługiwane przez bezpośrednią implementację `Index` i `IndexMut`.
///
/// # Panics
///
/// Panics, jeśli `begin` lub `end` nie wskazuje na początkowe przesunięcie bajtu znaku (zgodnie z definicją `is_char_boundary`), jeśli `begin > end` lub `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // te będą panic:
/// // bajt 2 znajduje się w `ö`:
/// // &s [2 ..3];
///
/// // bajt 8 znajduje się w `老`&s [1 ..
/// // 8];
///
/// // bajt 100 znajduje się poza ciągiem&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BEZPIECZEŃSTWO: właśnie sprawdziłem, czy `start` i `end` są na granicy znaku,
            // i przekazujemy bezpieczne odniesienie, więc zwracana wartość również będzie równa jeden.
            // Sprawdziliśmy również granice znaków, więc jest to poprawny UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BEZPIECZEŃSTWO: właśnie sprawdziłem, czy `start` i `end` są na granicy znaku.
            // Wiemy, że wskaźnik jest wyjątkowy, ponieważ otrzymaliśmy go z `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // BEZPIECZEŃSTWO: dzwoniący gwarantuje, że `self` jest w granicach `slice`
        // który spełnia wszystkie warunki dla `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // BEZPIECZEŃSTWO: patrz komentarze do `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary sprawdza, czy indeks jest w [0, .len()] nie może ponownie użyć `get` jak powyżej, z powodu problemów z NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BEZPIECZEŃSTWO: właśnie sprawdziłem, czy `start` i `end` są na granicy znaku,
            // i przekazujemy bezpieczne odniesienie, więc zwracana wartość również będzie równa jeden.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementuje wycinanie podciągów ze składnią `&self[.. end]` lub `&mut self[.. end]`.
///
/// Zwraca wycinek podanego ciągu z zakresu bajtów [" 0`, `end`).
/// Odpowiednik `&self[0 .. end]` lub `&mut self[0 .. end]`.
///
/// Ta operacja to *O*(1).
///
/// Przed 1.20.0 te operacje indeksowania były nadal obsługiwane przez bezpośrednią implementację `Index` i `IndexMut`.
///
/// # Panics
///
/// Panics, jeśli `end` nie wskazuje na początkowe przesunięcie bajtu znaku (zgodnie z definicją w `is_char_boundary`) lub jeśli `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // BEZPIECZEŃSTWO: właśnie sprawdziłem, czy `end` znajduje się na granicy znaku,
            // i przekazujemy bezpieczne odniesienie, więc zwracana wartość również będzie równa jeden.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // BEZPIECZEŃSTWO: właśnie sprawdziłem, czy `end` znajduje się na granicy znaku,
            // i przekazujemy bezpieczne odniesienie, więc zwracana wartość również będzie równa jeden.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // BEZPIECZEŃSTWO: właśnie sprawdziłem, czy `end` znajduje się na granicy znaku,
            // i przekazujemy bezpieczne odniesienie, więc zwracana wartość również będzie równa jeden.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementuje wycinanie podciągów ze składnią `&self[begin ..]` lub `&mut self[begin ..]`.
///
/// Zwraca wycinek podanego ciągu z zakresu bajtów [" początek`, `len`).Odpowiednik " &self [początek ...
/// len] `lub`&mut self [początek ...
/// len]`.
///
/// Ta operacja to *O*(1).
///
/// Przed 1.20.0 te operacje indeksowania były nadal obsługiwane przez bezpośrednią implementację `Index` i `IndexMut`.
///
/// # Panics
///
/// Panics, jeśli `begin` nie wskazuje na początkowe przesunięcie bajtu znaku (zgodnie z definicją w `is_char_boundary`) lub jeśli `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // BEZPIECZEŃSTWO: właśnie sprawdziłem, czy `start` znajduje się na granicy znaku,
            // i przekazujemy bezpieczne odniesienie, więc zwracana wartość również będzie równa jeden.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // BEZPIECZEŃSTWO: właśnie sprawdziłem, czy `start` znajduje się na granicy znaku,
            // i przekazujemy bezpieczne odniesienie, więc zwracana wartość również będzie równa jeden.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // BEZPIECZEŃSTWO: dzwoniący gwarantuje, że `self` jest w granicach `slice`
        // który spełnia wszystkie warunki dla `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // BEZPIECZEŃSTWO: identyczne z `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // BEZPIECZEŃSTWO: właśnie sprawdziłem, czy `start` znajduje się na granicy znaku,
            // i przekazujemy bezpieczne odniesienie, więc zwracana wartość również będzie równa jeden.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementuje wycinanie podciągów ze składnią `&self[begin ..= end]` lub `&mut self[begin ..= end]`.
///
/// Zwraca wycinek podanego ciągu z zakresu bajtów [`begin`, `end`].Odpowiednik `&self [begin .. end + 1]` lub `&mut self[begin .. end + 1]`, z wyjątkiem przypadku, gdy `end` ma maksymalną wartość dla `usize`.
///
/// Ta operacja to *O*(1).
///
/// # Panics
///
/// Panics, jeśli `begin` nie wskazuje początkowego przesunięcia bajtu znaku (zgodnie z definicją `is_char_boundary`), jeśli `end` nie wskazuje końcowego przesunięcia bajtu znaku (`end + 1` jest albo początkowym przesunięciem bajtu, albo równym `len`), jeśli `begin > end` lub jeśli `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementuje wycinanie podciągów ze składnią `&self[..= end]` lub `&mut self[..= end]`.
///
/// Zwraca wycinek podanego ciągu z zakresu bajtów [0, `end`].
/// Odpowiednik `&self [0 .. end + 1]`, z wyjątkiem przypadku, gdy `end` ma maksymalną wartość dla `usize`.
///
/// Ta operacja to *O*(1).
///
/// # Panics
///
/// Panics, jeśli `end` nie wskazuje na końcowe przesunięcie bajtu znaku (`end + 1` jest albo początkowym przesunięciem bajtu zgodnie z definicją `is_char_boundary` lub równe `len`) lub jeśli `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // BEZPIECZEŃSTWO: dzwoniący musi dotrzymać umowy bezpieczeństwa dla `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Przeanalizuj wartość z ciągu
///
/// Metoda `FromStr` [`from_str`] jest często używana niejawnie, za pośrednictwem metody [`parse`] [`str`].
/// Przykłady można znaleźć w dokumentacji [`parse`].
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` nie ma parametru okresu istnienia, więc można analizować tylko typy, które same nie zawierają parametru okresu istnienia.
///
/// Innymi słowy, możesz przeanalizować `i32` z `FromStr`, ale nie `&i32`.
/// Możesz przeanalizować strukturę zawierającą `i32`, ale nie taką, która zawiera `&i32`.
///
/// # Examples
///
/// Podstawowa implementacja `FromStr` na przykładzie typu `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Powiązany błąd, który może zostać zwrócony podczas analizy.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analizuje ciąg `s`, aby zwrócić wartość tego typu.
    ///
    /// Jeśli parsowanie powiedzie się, zwróć wartość wewnątrz [`Ok`], w przeciwnym razie, gdy łańcuch jest źle sformatowany, zwróć błąd specyficzny dla wewnętrznego [`Err`].
    /// Typ błędu jest specyficzny dla implementacji trait.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie z [`i32`], typem, który implementuje `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Przeanalizuj `bool` z ciągu.
    ///
    /// Daje `Result<bool, ParseBoolError>`, ponieważ `s` może, ale nie musi, być analizowalny.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Uwaga, w wielu przypadkach metoda `.parse()` na `str` jest bardziej odpowiednia.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}