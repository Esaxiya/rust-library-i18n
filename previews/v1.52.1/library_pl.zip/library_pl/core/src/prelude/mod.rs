//! Biblioteka libcore prelude
//!
//! Ten moduł jest przeznaczony dla użytkowników libcore, które również nie zawierają linków do libstd.
//! Ten moduł jest domyślnie importowany, gdy `#![no_std]` jest używany w taki sam sposób, jak prelude biblioteki standardowej.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Wersja rdzenia prelude z 2015 roku.
///
/// Zobacz [module-level documentation](self) po więcej.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Wersja jądra prelude z 2018 roku.
///
/// Zobacz [module-level documentation](self) po więcej.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Wersja rdzenia prelude z 2021 roku.
///
/// Zobacz [module-level documentation](self) po więcej.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Dodaj więcej rzeczy.
}