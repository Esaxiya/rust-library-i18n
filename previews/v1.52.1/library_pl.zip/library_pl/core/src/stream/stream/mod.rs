use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Interfejs do obsługi asynchronicznych iteratorów.
///
/// To jest główny strumień trait.
/// Aby uzyskać więcej informacji na temat ogólnie koncepcji strumieni, zobacz [module-level documentation].
/// W szczególności możesz chcieć wiedzieć, jak [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Typ elementów generowanych przez strumień.
    type Item;

    /// Spróbuj pobrać następną wartość tego strumienia, rejestrując bieżące zadanie do wznowienia, jeśli wartość nie jest jeszcze dostępna, i zwracając `None`, jeśli strumień jest wyczerpany.
    ///
    /// # Wartość zwracana
    ///
    /// Istnieje kilka możliwych wartości zwracanych, z których każda wskazuje odrębny stan strumienia:
    ///
    /// - `Poll::Pending` oznacza, że następna wartość tego strumienia nie jest jeszcze gotowa.Implementacje zapewnią, że bieżące zadanie zostanie powiadomione, gdy następna wartość będzie gotowa.
    ///
    /// - `Poll::Ready(Some(val))` oznacza, że strumień pomyślnie wygenerował wartość `val` i może generować dalsze wartości przy kolejnych wywołaniach `poll_next`.
    ///
    /// - `Poll::Ready(None)` oznacza, że strumień został zakończony i `poll_next` nie powinien być ponownie wywoływany.
    ///
    /// # Panics
    ///
    /// Po zakończeniu strumienia (zwrócony `Ready(None)` from `poll_next`), ponowne wywołanie jego metody `poll_next` może panic, zablokować się na zawsze lub spowodować inne rodzaje problemów; `Stream` trait nie stawia żadnych wymagań co do efektów takiego wywołania.
    ///
    /// Jednakże, ponieważ metoda `poll_next` nie jest oznaczona jako `unsafe`, obowiązują zwykłe reguły Rust: wywołania nigdy nie mogą powodować nieokreślonego zachowania (uszkodzenie pamięci, nieprawidłowe użycie funkcji `unsafe` itp.), Niezależnie od stanu strumienia.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Zwraca granice pozostałej długości strumienia.
    ///
    /// W szczególności `size_hint()` zwraca krotkę, w której pierwszy element jest dolną granicą, a drugi element jest górną granicą.
    ///
    /// Druga połowa zwracanej krotki to [`Option`]`<`[`usize`] `>`.
    /// [`None`] oznacza tutaj, że albo nie ma znanej górnej granicy, albo górna granica jest większa niż [`usize`].
    ///
    /// # Uwagi dotyczące wdrożenia
    ///
    /// Nie jest wymuszone, że implementacja strumienia daje zadeklarowaną liczbę elementów.Błędny strumień może dawać mniej niż dolna granica lub więcej niż górna granica elementów.
    ///
    /// `size_hint()` jest przeznaczony przede wszystkim do optymalizacji, takich jak rezerwowanie miejsca dla elementów strumienia, ale nie można mu ufać, że np. pominie sprawdzanie granic w niebezpiecznym kodzie.
    /// Nieprawidłowa implementacja `size_hint()` nie powinna prowadzić do naruszenia bezpieczeństwa pamięci.
    ///
    /// To powiedziawszy, implementacja powinna zapewnić poprawne oszacowanie, ponieważ w przeciwnym razie byłoby to naruszenie protokołu trait.
    ///
    /// Domyślna implementacja zwraca " (0," [" Brak`] " )" , co jest poprawne dla dowolnego strumienia.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}