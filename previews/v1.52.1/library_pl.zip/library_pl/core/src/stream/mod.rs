//! Komponowalna asynchroniczna iteracja.
//!
//! Jeśli futures są wartościami asynchronicznymi, strumienie są asynchronicznymi iteratorami.
//! Jeśli masz jakąś asynchroniczną kolekcję i potrzebujesz wykonać operację na elementach tej kolekcji, szybko natrafisz na 'streams'.
//! Strumienie są mocno wykorzystywane w idiomatycznym kodzie asynchronicznym Rust, dlatego warto się z nimi zapoznać.
//!
//! Zanim wyjaśnimy więcej, porozmawiajmy o strukturze tego modułu:
//!
//! # Organization
//!
//! Ten moduł jest w dużej mierze zorganizowany według typu:
//!
//! * [Traits] są główną częścią: te traits określają, jakie rodzaje strumieni istnieją i co można z nimi zrobić.Warto poświęcić trochę czasu na naukę metod tych traits.
//! * Funkcje zapewniają przydatne sposoby tworzenia podstawowych strumieni.
//! * Struktury są często typami zwracanymi przez różne metody w traits tego modułu.Zwykle będziesz chciał przyjrzeć się metodzie, która tworzy `struct`, a nie samemu `struct`.
//! Aby uzyskać więcej informacji o tym, dlaczego, zobacz " [Implementing Stream](#Implementing-stream)`.
//!
//! [Traits]: #traits
//!
//! Otóż to!Zagłębmy się w strumienie.
//!
//! # Stream
//!
//! Sercem i duszą tego modułu jest [`Stream`] trait.Rdzeń [`Stream`] wygląda następująco:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! W przeciwieństwie do `Iterator`, `Stream` rozróżnia metodę [`poll_next`], która jest używana podczas implementacji `Stream`, i metodę (to-be-implemented) `next`, która jest używana podczas konsumowania strumienia.
//!
//! Konsumenci `Stream` muszą wziąć pod uwagę tylko `next`, który po wywołaniu zwraca future, który daje `Option<Stream::Item>`.
//!
//! future zwrócone przez `next` przyniesie `Some(Item)`, o ile istnieją elementy, a gdy wszystkie zostaną wyczerpane, da `None` wskazujący, że iteracja została zakończona.
//! Jeśli czekamy na rozwiązanie asynchroniczne, future zaczeka, aż strumień będzie gotowy do ponownego ustąpienia.
//!
//! Poszczególne strumienie mogą zdecydować się na wznowienie iteracji, więc ponowne wywołanie `next` może w pewnym momencie ponownie przynieść `Some(Item)` lub nie.
//!
//! Pełna definicja [`Stream`] zawiera również wiele innych metod, ale są to metody domyślne, zbudowane na [`poll_next`], więc dostajesz je za darmo.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Wdrażanie Stream
//!
//! Tworzenie własnego strumienia obejmuje dwa kroki: utworzenie `struct` do przechowywania stanu strumienia, a następnie zaimplementowanie [`Stream`] dla tego `struct`.
//!
//! Stwórzmy strumień o nazwie `Counter`, który liczy od `1` do `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Najpierw struktura:
//!
//! /// Strumień liczący od jednego do pięciu
//! struct Counter {
//!     count: usize,
//! }
//!
//! // chcemy, aby nasza liczba zaczynała się od jednego, więc dodajmy metodę new(), aby pomóc.
//! // Nie jest to bezwzględnie konieczne, ale jest wygodne.
//! // Zauważ, że zaczynamy `count` od zera, zobaczymy dlaczego w implementacji `poll_next()`'s poniżej.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Następnie wdrażamy `Stream` dla naszego `Counter`:
//!
//! impl Stream for Counter {
//!     // będziemy liczyć z usize
//!     type Item = usize;
//!
//!     // poll_next() jest jedyną wymaganą metodą
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Zwiększ naszą liczbę.Dlatego zaczęliśmy od zera.
//!         self.count += 1;
//!
//!         // Sprawdź, czy zakończyliśmy liczenie, czy nie.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Strumienie są *leniwe*.Oznacza to, że samo utworzenie strumienia nie wymaga _do_.Tak naprawdę nic się nie dzieje, dopóki nie zadzwonisz do `next`.
//! Czasami jest to źródłem nieporozumień podczas tworzenia strumienia wyłącznie ze względu na jego skutki uboczne.
//! Kompilator ostrzeże nas przed tego typu zachowaniem:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;