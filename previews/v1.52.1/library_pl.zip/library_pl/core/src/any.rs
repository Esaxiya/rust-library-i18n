//! Ten moduł implementuje `Any` trait, który umożliwia dynamiczne wpisywanie dowolnego typu `'static` poprzez odbicie w czasie wykonywania.
//!
//! `Any` sam może być użyty do uzyskania `TypeId` i ma więcej funkcji, gdy jest używany jako obiekt trait.
//! Jako `&dyn Any` (pożyczony obiekt trait) ma metody `is` i `downcast_ref`, aby sprawdzić, czy zawarta wartość jest danego typu i uzyskać odwołanie do wartości wewnętrznej jako typ.
//! Podobnie jak `&mut dyn Any`, istnieje również metoda `downcast_mut`, służąca do uzyskiwania zmiennego odniesienia do wartości wewnętrznej.
//! `Box<dyn Any>` dodaje metodę `downcast`, która próbuje przekonwertować na `Box<T>`.
//! Zobacz dokumentację [`Box`], aby uzyskać szczegółowe informacje.
//!
//! Należy zauważyć, że `&dyn Any` ogranicza się do testowania, czy wartość jest określonego konkretnego typu i nie może być używana do testowania, czy typ implementuje trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Inteligentne wskaźniki i `dyn Any`
//!
//! Jednym z zachowań, o których należy pamiętać podczas używania `Any` jako obiektu trait, szczególnie w przypadku typów takich jak `Box<dyn Any>` lub `Arc<dyn Any>`, jest to, że zwykłe wywołanie `.type_id()` na wartości spowoduje utworzenie `TypeId`*kontenera*, a nie bazowego obiektu trait.
//!
//! Można tego uniknąć, konwertując inteligentny wskaźnik na `&dyn Any`, który zwróci `TypeId` obiektu.
//! Na przykład:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Bardziej prawdopodobne jest, że będziesz tego chciał:
//! let actual_id = (&*boxed).type_id();
//! // ... od tego:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Rozważmy sytuację, w której chcemy wylogować wartość przekazaną do funkcji.
//! Znamy wartość, nad którą pracujemy, implementuje debugowanie, ale nie znamy jej konkretnego typu.Chcemy potraktować określone typy w specjalny sposób: w tym przypadku wypisuje długość wartości String przed ich wartością.
//! Nie znamy konkretnego typu naszej wartości w czasie kompilacji, więc zamiast tego musimy użyć odbicia w czasie wykonywania.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Funkcja rejestratora dla dowolnego typu, który implementuje debugowanie.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Spróbuj przeliczyć naszą wartość na `String`.
//!     // Jeśli się powiedzie, chcemy wypisać długość łańcucha oraz jego wartość.
//!     // Jeśli nie, to inny typ: po prostu wydrukuj go bez ozdób.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ta funkcja chce wylogować swój parametr przed rozpoczęciem pracy z nią.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... wykonać inną pracę
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Dowolny trait
///////////////////////////////////////////////////////////////////////////////

/// trait do emulacji dynamicznego pisania.
///
/// Większość typów implementuje `Any`.Jednak żaden typ, który zawiera odniesienie nie-" statyczne`, nie zawiera.
/// Zobacz [module-level documentation][mod], aby uzyskać więcej informacji.
///
/// [mod]: crate::any
// Ten trait nie jest niebezpieczny, chociaż polegamy na specyfice jego jedynej funkcji `type_id` impl w niebezpiecznym kodzie (np. `downcast`).Zwykle byłby to problem, ale ponieważ jedyną implementacją `Any` jest ogólna implementacja, żaden inny kod nie może zaimplementować `Any`.
//
// Moglibyśmy prawdopodobnie uczynić ten trait niebezpiecznym-nie spowodowałoby to zepsucia, ponieważ kontrolujemy wszystkie implementacje-ale decydujemy się tego nie robić, ponieważ nie jest to naprawdę konieczne i może zmylić użytkowników co do rozróżnienia niebezpiecznych traits i niebezpiecznych metod (tj. `type_id` nadal byłoby bezpieczne, ale prawdopodobnie chcielibyśmy wskazać jako takie w dokumentacji).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Pobiera `TypeId` z `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metody rozszerzające dla dowolnych obiektów trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Upewnij się, że wynik np. Łączenia wątku może zostać wydrukowany i tym samym użyty z `unwrap`.
// Może ostatecznie nie być już potrzebne, jeśli wysyłka działa z upcastingiem.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Zwraca `true`, jeśli typ w pudełku jest taki sam jak `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Pobierz `TypeId` typu, z którym tworzona jest instancja tej funkcji.
        let t = TypeId::of::<T>();

        // Uzyskaj `TypeId` typu w obiekcie trait (`self`).
        let concrete = self.type_id();

        // Porównaj oba " TypeId` na równości.
        t == concrete
    }

    /// Zwraca odniesienie do wartości w ramce, jeśli jest typu `T` lub `None`, jeśli nie jest.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // BEZPIECZEŃSTWO: właśnie sprawdziliśmy, czy wskazujemy właściwy typ i możemy na nim polegać
            // które sprawdzają bezpieczeństwo pamięci, ponieważ wdrożyliśmy Any dla wszystkich typów;żadne inne implikacje nie mogą istnieć, ponieważ byłyby w konflikcie z naszym plikiem impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Zwraca zmienne odniesienie do wartości w ramce, jeśli jest typu `T` lub `None`, jeśli nie jest.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // BEZPIECZEŃSTWO: właśnie sprawdziliśmy, czy wskazujemy właściwy typ i możemy na nim polegać
            // które sprawdzają bezpieczeństwo pamięci, ponieważ wdrożyliśmy Any dla wszystkich typów;żadne inne implikacje nie mogą istnieć, ponieważ byłyby w konflikcie z naszym plikiem impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Przechodzi do metody zdefiniowanej w typie `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Przechodzi do metody zdefiniowanej w typie `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Przechodzi do metody zdefiniowanej w typie `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Przechodzi do metody zdefiniowanej w typie `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Przechodzi do metody zdefiniowanej w typie `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Przechodzi do metody zdefiniowanej w typie `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID i jego metody
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` reprezentuje globalnie unikatowy identyfikator typu.
///
/// Każdy `TypeId` to nieprzezroczysty obiekt, który nie pozwala na kontrolę tego, co jest w środku, ale pozwala na podstawowe operacje, takie jak klonowanie, porównywanie, drukowanie i pokazywanie.
///
///
/// `TypeId` jest obecnie dostępny tylko dla typów, które przypisują `'static`, ale to ograniczenie można usunąć w future.
///
/// Chociaż `TypeId` implementuje `Hash`, `PartialOrd` i `Ord`, warto zauważyć, że skróty i kolejność będą się różnić w zależności od wersji Rust.
/// Uważaj, aby nie polegać na nich w swoim kodzie!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Zwraca `TypeId` typu, z którym została utworzona instancja tej funkcji ogólnej.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Zwraca nazwę typu jako fragment ciągu.
///
/// # Note
///
/// Jest to przeznaczone do użytku diagnostycznego.
/// Dokładna zawartość i format zwracanego ciągu nie są określone, poza tym, że jest to opis typu z najlepszymi wysiłkami.
/// Na przykład wśród ciągów, które może zwrócić `type_name::<Option<String>>()`, są `"Option<String>"` i `"std::option::Option<std::string::String>"`.
///
///
/// Zwracanego ciągu nie można traktować jako unikalnego identyfikatora typu, ponieważ wiele typów może być mapowanych na tę samą nazwę typu.
/// Podobnie nie ma gwarancji, że wszystkie części typu pojawią się w zwracanym ciągu: na przykład specyfikatory czasu życia nie są obecnie uwzględniane.
/// Ponadto dane wyjściowe mogą się zmieniać między wersjami kompilatora.
///
/// Bieżąca implementacja używa tej samej infrastruktury, co diagnostyka kompilatora i informacje o debugowaniu, ale nie jest to gwarantowane.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Zwraca nazwę typu wskazanej wartości jako wycinek ciągu.
/// Jest to to samo, co `type_name::<T>()`, ale może być używane, gdy typ zmiennej nie jest łatwo dostępny.
///
/// # Note
///
/// Jest to przeznaczone do użytku diagnostycznego.Dokładna zawartość i format ciągu nie są określone, poza tym, że jest to dokładny opis typu.
/// Na przykład `type_name_of_val::<Option<String>>(None)` może zwrócić `"Option<String>"` lub `"std::option::Option<std::string::String>"`, ale nie `"foobar"`.
///
/// Ponadto dane wyjściowe mogą się zmieniać między wersjami kompilatora.
///
/// Ta funkcja nie rozwiązuje obiektów trait, co oznacza, że `type_name_of_val(&7u32 as &dyn Debug)` może zwrócić `"dyn Debug"`, ale nie `"u32"`.
///
/// Nazwa typu nie powinna być traktowana jako niepowtarzalny identyfikator typu;
/// wiele typów może mieć tę samą nazwę typu.
///
/// Bieżąca implementacja używa tej samej infrastruktury, co diagnostyka kompilatora i informacje o debugowaniu, ale nie jest to gwarantowane.
///
/// # Examples
///
/// Wyświetla domyślne typy całkowite i zmiennoprzecinkowe.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}