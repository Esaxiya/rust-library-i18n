# `rustc-std-workspace-core` crate

Ten crate to podkładka i pusty crate, który po prostu zależy od `libcore` i ponownie eksportuje całą swoją zawartość.
crate jest sednem umocnienia standardowej biblioteki do polegania na crates z crates.io

Crates na crates.io, od którego zależy biblioteka standardowa, musi zależeć od `rustc-std-workspace-core` crate z crates.io, który jest pusty.

Używamy `[patch]`, aby zastąpić go tym crate w tym repozytorium.
W rezultacie crates na crates.io narysuje zależność edge do `libcore`, wersję zdefiniowaną w tym repozytorium.
To powinno narysować wszystkie krawędzie zależności, aby zapewnić, że Cargo pomyślnie zbuduje crates!

Zauważ, że crates na crates.io musi zależeć od tego crate o nazwie `core`, aby wszystko działało poprawnie.Aby to zrobić, mogą użyć:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Poprzez użycie klucza `package` nazwa crate zostaje zmieniona na `core`, co oznacza, że będzie wyglądać jak

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

gdy Cargo wywołuje kompilator, spełniając niejawną dyrektywę `extern crate core` wprowadzoną przez kompilator.




