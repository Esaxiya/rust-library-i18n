use backtrace::Backtrace;

// Ten test działa tylko na platformach, które mają działającą funkcję `symbol_address` dla ramek, które zgłaszają początkowy adres symbolu.
// W rezultacie jest włączony tylko na kilku platformach.
//
const ENABLED: bool = cfg!(all(
    // Windows nie został tak naprawdę przetestowany, a OSX nie obsługuje faktycznego znajdowania otaczającej ramki, więc wyłącz to
    //
    target_os = "linux",
    // W ARM znalezienie funkcji otaczającej to po prostu zwrócenie samego adresu IP.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}