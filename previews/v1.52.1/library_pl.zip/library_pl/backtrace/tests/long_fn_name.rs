use backtrace::Backtrace;

// 50-znakowa nazwa modułu
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-znakowa nazwa struktury
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Długie nazwy funkcji należy skrócić do (MAX_SYM_NAME, 1) znaków.
// Uruchom ten test tylko dla msvc, ponieważ gnu drukuje "<no info>" dla wszystkich ramek.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 powtórzeń nazwy struktury, więc w pełni kwalifikowana nazwa funkcji ma co najmniej 10 *(50 + 50)* 2=2000 znaków.
    //
    // W rzeczywistości jest dłuższy, ponieważ zawiera również `::`, `<>` i nazwę bieżącego modułu
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}