//! Moduł wspomagający zarządzanie dowiązaniami dbghelp na Windows
//!
//! Ślady wsteczne na Windows (przynajmniej dla MSVC) są w dużej mierze zasilane przez `dbghelp.dll` i różne funkcje, które zawiera.
//! Te funkcje są obecnie ładowane *dynamicznie*, a nie statycznie łączone z `dbghelp.dll`.
//! Jest to obecnie wykonywane przez bibliotekę standardową (i teoretycznie jest tam wymagane), ale jest próbą zmniejszenia statycznych zależności bibliotek dll, ponieważ ślady wsteczne są zazwyczaj dość opcjonalne.
//!
//! Biorąc to pod uwagę, `dbghelp.dll` prawie zawsze pomyślnie ładuje się na Windows.
//!
//! Zwróć jednak uwagę, że ponieważ ładujemy całą tę obsługę dynamicznie, nie możemy w rzeczywistości używać surowych definicji w `winapi`, ale raczej musimy sami zdefiniować typy wskaźników funkcji i ich użyć.
//! Naprawdę nie chcemy zajmować się powielaniem winapi, więc mamy funkcję `verify-winapi` w Cargo, która zapewnia, że wszystkie wiązania pasują do tych w winapi i ta funkcja jest włączona w CI.
//!
//! Na koniec zauważysz, że dll dla `dbghelp.dll` nigdy nie jest rozładowywany i jest to obecnie zamierzone.
//! Myślenie jest takie, że możemy globalnie buforować go i używać między wywołaniami API, unikając kosztownego loads/unloads.
//! Jeśli jest to problem z wykrywaczami wycieków lub czymś w tym rodzaju, możemy przejść przez most, gdy tam dotrzemy.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Obejście `SymGetOptions` i `SymSetOptions`, które nie są obecne w samym winapi.
// W przeciwnym razie jest to używane tylko wtedy, gdy podwójnie sprawdzamy typy przeciwko winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Nie zdefiniowano jeszcze w winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Jest to zdefiniowane w winapi, ale jest niepoprawne (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Nie zdefiniowano jeszcze w winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// To makro służy do definiowania struktury `Dbghelp`, która zawiera wewnętrznie wszystkie wskaźniki funkcji, które możemy załadować.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Załadowana biblioteka DLL dla `dbghelp.dll`
            dll: HMODULE,

            // Każdy wskaźnik funkcji dla każdej funkcji, której możemy użyć
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Początkowo nie załadowaliśmy biblioteki DLL
            dll: 0 as *mut _,
            // Początkowo wszystkie funkcje są ustawione na zero, aby powiedzieć, że muszą być ładowane dynamicznie.
            //
            $($name: 0,)*
        };

        // Wygodny typ definicji dla każdego typu funkcji.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Próby otwarcia `dbghelp.dll`.
            /// Zwraca sukces, jeśli działa, lub błąd, jeśli `LoadLibraryW` zawiedzie.
            ///
            /// Panics, jeśli biblioteka jest już załadowana.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funkcja dla każdej metody, której chcielibyśmy użyć.
            // Po wywołaniu odczyta buforowany wskaźnik funkcji lub załaduje go i zwróci załadowaną wartość.
            // Zakłada się, że obciążenia się powiodły.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Wygodne proxy do używania blokad porządkujących do odwoływania się do funkcji dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Zainicjuj całą obsługę niezbędną do uzyskania dostępu do funkcji API `dbghelp` z tego crate.
///
///
/// Zauważ, że ta funkcja jest **bezpieczna**, posiada wewnętrzną synchronizację.
/// Należy również pamiętać, że wielokrotne rekurencyjne wywoływanie tej funkcji jest bezpieczne.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Pierwszą rzeczą, którą musimy zrobić, jest zsynchronizowanie tej funkcji.Można to wywołać współbieżnie z innych wątków lub rekurencyjnie w ramach jednego wątku.
        // Zauważ, że jest to jednak trudniejsze, ponieważ to, czego tutaj używamy, `dbghelp`,*również* musi być zsynchronizowane ze wszystkimi innymi wywołującymi `dbghelp` w tym procesie.
        //
        // Zazwyczaj nie ma tak wielu wywołań `dbghelp` w ramach tego samego procesu i prawdopodobnie możemy bezpiecznie założyć, że tylko my mamy do niego dostęp.
        // Jest jednak jeden główny inny użytkownik, o który musimy się martwić, o który jak na ironię my sami, ale w standardowej bibliotece.
        // Standardowa biblioteka Rust zależy od tego crate do obsługi śledzenia wstecznego, a ta crate istnieje również w crates.io.
        // Oznacza to, że jeśli standardowa biblioteka drukuje ślad panic, może ścigać się z tym crate pochodzącym z crates.io, powodując segfaulty.
        //
        // Aby pomóc rozwiązać ten problem z synchronizacją, zastosowaliśmy tutaj sztuczkę specyficzną dla systemu Windows (jest to w końcu ograniczenie dotyczące synchronizacji specyficzne dla systemu Windows).
        // Tworzymy *sesję lokalną* o nazwie mutex, aby chronić to wywołanie.
        // Intencją jest to, że standardowa biblioteka i ten crate nie muszą współużytkować interfejsów API poziomu Rust w celu synchronizacji tutaj, ale zamiast tego mogą pracować za kulisami, aby upewnić się, że synchronizują się ze sobą.
        //
        // W ten sposób, gdy ta funkcja jest wywoływana przez bibliotekę standardową lub przez crates.io, możemy być pewni, że ten sam mutex jest uzyskiwany.
        //
        // Wszystko to oznacza, że pierwszą rzeczą, którą tutaj robimy, jest atomowe utworzenie `HANDLE`, który jest nazwanym muteksem na Windows.
        // Trochę synchronizujemy się z innymi wątkami, które współużytkują tę funkcję, i zapewniamy, że tylko jeden uchwyt jest tworzony na instancję tej funkcji.
        // Zwróć uwagę, że uchwyt nigdy nie jest zamknięty, gdy jest przechowywany w pliku global.
        //
        // Po tym, jak już przejdziemy do blokady, po prostu ją zdobędziemy, a nasza rączka `Init`, którą wręczamy, będzie odpowiedzialna za jej upuszczenie.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, uff!Teraz, gdy wszyscy jesteśmy bezpiecznie zsynchronizowani, zacznijmy właściwie wszystko przetwarzać.
        // Najpierw musimy upewnić się, że `dbghelp.dll` jest faktycznie ładowany w tym procesie.
        // Robimy to dynamicznie, aby uniknąć statycznej zależności.
        // W przeszłości było to robione w celu obejścia dziwnych problemów z linkowaniem i ma na celu uczynienie plików binarnych bardziej przenośnymi, ponieważ jest to w dużej mierze narzędzie do debugowania.
        //
        //
        // Po otwarciu `dbghelp.dll` musimy wywołać w nim kilka funkcji inicjalizacyjnych, o których szczegółowo poniżej.
        // Robimy to jednak tylko raz, więc mamy globalną wartość logiczną wskazującą, czy już skończyliśmy, czy nie.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Upewnij się, że flaga `SYMOPT_DEFERRED_LOADS` jest ustawiona, ponieważ zgodnie z własną dokumentacją MSVC na ten temat: "This is the fastest, most efficient way to use the symbol handler.", zróbmy to!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Właściwie zainicjuj symbole za pomocą MSVC.Pamiętaj, że może się to nie udać, ale ignorujemy to.
        // Nie ma tu wielu wcześniejszych rozwiązań jako takich, ale LLVM wewnętrznie wydaje się ignorować zwracaną tutaj wartość, a jedna z bibliotek odkażających w LLVM drukuje przerażające ostrzeżenie, jeśli to się nie powiedzie, ale w zasadzie ignoruje je na dłuższą metę.
        //
        //
        // Jednym z przypadków, w których pojawia się to często w przypadku Rust, jest to, że standardowa biblioteka i ten crate na crates.io chcą konkurować o `SymInitializeW`.
        // Biblioteka standardowa historycznie chciała inicjować, a następnie porządkować przez większość czasu, ale teraz, gdy używa tego crate, oznacza to, że ktoś pierwszy przejdzie do inicjalizacji, a drugi odbierze tę inicjalizację.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}