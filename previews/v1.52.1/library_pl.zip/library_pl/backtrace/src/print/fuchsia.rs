use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr przyjmuje wywołanie zwrotne, które otrzyma wskaźnik dl_phdr_info dla każdego DSO, który został dołączony do procesu.
    // dl_iterate_phdr zapewnia również, że linker dynamiczny jest zablokowany od początku do końca iteracji.
    // Jeśli wywołanie zwrotne zwraca wartość niezerową, iteracja jest przerywana wcześniej.
    // 'data' zostanie przekazany jako trzeci argument wywołania zwrotnego przy każdym wywołaniu.
    // 'size' podaje rozmiar pliku dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Musimy przeanalizować identyfikator kompilacji i kilka podstawowych danych nagłówka programu, co oznacza, że potrzebujemy również trochę informacji ze specyfikacji ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Teraz musimy replikować, bit po bicie, strukturę typu dl_phdr_info używaną przez aktualny linker dynamiczny fuchsia.
// Chromium ma również tę granicę ABI, a także crashpad.
// W końcu chcielibyśmy przenieść te przypadki do korzystania z wyszukiwania elfów, ale musielibyśmy zapewnić to w SDK, a to nie zostało jeszcze zrobione.
//
// Tak więc my (i oni) jesteśmy skazani na konieczność korzystania z tej metody, która wiąże się ze ścisłym sprzężeniem z libc fuchsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Nie mamy możliwości sprawdzenia, czy e_phoff i e_phnum są prawidłowe.
    // Biblioteka libc powinna nam to jednak zapewnić, więc utworzenie kawałka w tym miejscu jest bezpieczne.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr reprezentuje 64-bitowy nagłówek programu ELF w endianness docelowej architekturze.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr reprezentuje prawidłowy nagłówek programu ELF i jego zawartość.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Nie mamy możliwości sprawdzenia, czy p_addr lub p_memsz są prawidłowe.
    // Biblioteka Fuchsia najpierw analizuje notatki, ale z racji bycia tutaj te nagłówki muszą być ważne.
    //
    // NoteIter nie wymaga, aby dane bazowe były prawidłowe, ale wymaga, aby ograniczenia były prawidłowe.
    // Ufamy, że libc zapewniło, że tak właśnie jest w naszym przypadku.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Typ notatki dla identyfikatorów kompilacji.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr reprezentuje nagłówek notatki ELF w endianness celu.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Notatka reprezentuje notatkę ELF (nagłówek + zawartość).
// Nazwa jest pozostawiana jako wycinek u8, ponieważ nie zawsze jest zakończona wartością null, a rust ułatwia sprawdzenie, czy bajty są zgodne.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter pozwala bezpiecznie iterować po segmencie notatki.
// Kończy się, gdy tylko wystąpi błąd lub nie ma więcej notatek.
// Jeśli iterujesz po nieprawidłowych danych, będzie działać tak, jakby nie znaleziono żadnych notatek.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Niezmiennikiem funkcji jest to, że podany wskaźnik i rozmiar oznaczają prawidłowy zakres bajtów, które można odczytać.
    // Zawartość tych bajtów może być dowolna, ale zakres musi być ważny, aby był bezpieczny.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to wyrównuje 'x' do wyrównania do bajtów przy założeniu, że 'to' jest potęgą 2.
// Jest to zgodne ze standardowym wzorcem w kodzie analizy C/C ++ ELF, w którym używane jest (x + to, 1)&-to.
// Rust nie pozwala negować usize, więc używam
// 2, aby to odtworzyć.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 zużywa num bajtów z wycinka (jeśli jest obecny) i dodatkowo zapewnia, że końcowy wycinek jest odpowiednio wyrównany.
// Jeśli żądana liczba bajtów jest zbyt duża lub wycinka nie może zostać później ponownie wyrównana z powodu niewystarczającej liczby pozostałych bajtów, zwracana jest wartość Brak i wycinek nie jest modyfikowany.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ta funkcja nie ma rzeczywistych niezmienników, które wywołujący musi utrzymywać, poza tym, że być może 'bytes' powinien być wyrównany pod kątem wydajności (i poprawności niektórych architektur).
// Wartości w polach Elf_Nhdr mogą być nonsensowne, ale ta funkcja niczego takiego nie zapewnia.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Jest to bezpieczne, o ile jest wystarczająco dużo miejsca i właśnie to potwierdziliśmy w powyższym oświadczeniu if, więc nie powinno to być niebezpieczne.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Zauważ, że sice_of: :<Elf_Nhdr>() jest zawsze wyrównane do 4 bajtów.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Sprawdź, czy dotarliśmy do końca.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Przekształcamy nhdr, ale uważnie rozważamy wynikową strukturę.
        // Nie ufamy namesz ani descsz i nie podejmujemy niebezpiecznych decyzji w oparciu o typ.
        //
        // Więc nawet jeśli wydostaniemy kompletne śmieci, nadal powinniśmy być bezpieczni.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Wskazuje, że segment jest wykonywalny.
const PERM_X: u32 = 0b00000001;
/// Wskazuje, że segment jest zapisywalny.
const PERM_W: u32 = 0b00000010;
/// Wskazuje, że segment jest czytelny.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Reprezentuje segment ELF w czasie wykonywania.
struct Segment {
    /// Podaje wirtualny adres środowiska wykonawczego zawartości tego segmentu.
    addr: usize,
    /// Podaje rozmiar pamięci zawartości tego segmentu.
    size: usize,
    /// Podaje modułowi adres wirtualny tego segmentu z plikiem ELF.
    mod_rel_addr: usize,
    /// Nadaje uprawnienia znalezione w pliku ELF.
    /// Te uprawnienia niekoniecznie są jednak uprawnieniami obecnymi w czasie wykonywania.
    flags: Perm,
}

/// Pozwala na iterację segmentów z DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Reprezentuje ELF DSO (Dynamic Shared Object).
/// Ten typ odwołuje się do danych przechowywanych w rzeczywistym DSO, zamiast tworzyć własną kopię.
struct Dso<'a> {
    /// Dynamiczny linker zawsze podaje nam nazwę, nawet jeśli jest ona pusta.
    /// W przypadku głównego pliku wykonywalnego nazwa ta będzie pusta.
    /// W przypadku współdzielonego obiektu będzie to nazwa sondy (patrz DT_SONAME).
    name: &'a str,
    /// Na Fuchsii praktycznie wszystkie pliki binarne mają identyfikatory kompilacji, ale nie jest to ścisłe wymaganie.
    /// Nie ma możliwości dopasowania informacji DSO do prawdziwego pliku ELF później, jeśli nie ma build_id, więc wymagamy, aby każdy DSO miał tutaj jeden.
    ///
    /// DSO bez build_id są ignorowane.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Zwraca iterator segmentów w tym DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Te błędy kodują problemy, które pojawiają się podczas analizowania informacji o każdym DSO.
///
enum Error {
    /// NameError oznacza, że wystąpił błąd podczas konwersji napisu w stylu C na łańcuch rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError oznacza, że nie znaleźliśmy identyfikatora kompilacji.
    /// Może to być spowodowane tym, że DSO nie miał identyfikatora kompilacji lub segment zawierający identyfikator kompilacji był nieprawidłowy.
    ///
    BuildIDError,
}

/// Wywołuje 'dso' lub 'error' dla każdego DSO podłączonego do procesu przez dynamiczny linker.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, który będzie miał jedną z metod zjadania zwanych foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr zapewnia, że info.name wskaże prawidłową lokalizację.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ta funkcja drukuje znaczniki symbolizatora Fuchsia dla wszystkich informacji zawartych w DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}