use core::ffi::c_void;
use core::fmt;

/// Sprawdza bieżący stos wywołań, przekazując wszystkie aktywne ramki do podanego zamknięcia w celu obliczenia śladu stosu.
///
/// Ta funkcja jest koniem roboczym tej biblioteki w obliczaniu śladów stosu dla programu.Podane zamknięcie `cb` jest zwracane jako wystąpienie `Frame`, które reprezentuje informacje o tej ramce wywołania na stosie.
/// Zamknięcie składa się z ramek w sposób odgórny (ostatnio nazywany najpierw funkcjami).
///
/// Wartość zwracana przez zamknięcie wskazuje, czy śledzenie wsteczne powinno być kontynuowane.Zwrócona wartość `false` zakończy śledzenie wstecz i natychmiast wróci.
///
/// Po uzyskaniu `Frame` prawdopodobnie będziesz chciał zadzwonić do `backtrace::resolve`, aby przekonwertować `ip` (wskaźnik instrukcji) lub adres symbolu na `Symbol`, za pomocą którego można się nauczyć nazwy i/lub nazwy pliku/numeru linii.
///
///
/// Zwróć uwagę, że jest to funkcja stosunkowo niskiego poziomu i jeśli chcesz, na przykład, przechwycić ślad śledzenia do późniejszego sprawdzenia, typ `Backtrace` może być bardziej odpowiedni.
///
/// # Wymagane funkcje
///
/// Ta funkcja wymaga włączenia funkcji `std` w `backtrace` crate, a funkcja `std` jest domyślnie włączona.
///
/// # Panics
///
/// Ta funkcja stara się nigdy nie panic, ale jeśli `cb` dostarczył panics, to niektóre platformy zmuszą podwójny panic do przerwania procesu.
/// Niektóre platformy używają biblioteki C, która wewnętrznie używa wywołań zwrotnych, których nie można przywrócić, więc panikowanie z `cb` może spowodować przerwanie procesu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // kontynuuj ślad
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Tak samo jak `trace`, tylko niebezpieczne, ponieważ nie jest zsynchronizowane.
///
/// Ta funkcja nie ma gwarancji synchronizacji, ale jest dostępna, gdy funkcja `std` tego crate nie jest wkompilowana.
/// Więcej dokumentacji i przykładów znajdziesz w opisie funkcji `trace`.
///
/// # Panics
///
/// Zobacz informacje na temat `trace`, aby zapoznać się z ostrzeżeniami dotyczącymi paniki `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait reprezentujące jedną klatkę śledzenia wstecznego, przekazane funkcji `trace` tego crate.
///
/// Zamknięcie funkcji śledzenia będzie dawało ramki, a ramka jest wirtualnie wysyłana, ponieważ podstawowa implementacja nie zawsze jest znana do czasu wykonania.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Zwraca bieżący wskaźnik instrukcji tej ramki.
    ///
    /// Zwykle jest to następna instrukcja do wykonania w ramce, ale nie wszystkie implementacje podają ją ze 100% dokładnością (ale generalnie jest dość blisko).
    ///
    ///
    /// Zaleca się przekazanie tej wartości do `backtrace::resolve`, aby przekształcić ją w nazwę symbolu.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Zwraca bieżący wskaźnik stosu tej ramki.
    ///
    /// W przypadku, gdy zaplecze nie może odzyskać wskaźnika stosu dla tej ramki, zwracany jest wskaźnik pusty.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Zwraca początkowy adres symbolu ramki tej funkcji.
    ///
    /// Spowoduje to próbę przewinięcia wskaźnika instrukcji zwróconego przez `ip` na początek funkcji i zwrócenie tej wartości.
    ///
    /// Jednak w niektórych przypadkach backendy po prostu zwracają `ip` z tej funkcji.
    ///
    /// Zwracana wartość może być czasami używana, jeśli `backtrace::resolve` nie powiodło się na `ip` podanym powyżej.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Zwraca adres bazowy modułu, do którego należy ramka.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // To musi być pierwsze, aby zapewnić, że Miri ma pierwszeństwo przed platformą hosta
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // używane tylko w dbghelp symbolize
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}