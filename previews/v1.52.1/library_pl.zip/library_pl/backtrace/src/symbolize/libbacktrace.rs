//! Strategia symbolizacji wykorzystująca kod parsujący DWARF w libbacktrace.
//!
//! Biblioteka libbacktrace C, zwykle dystrybuowana z gcc, obsługuje nie tylko generowanie śladu wstecznego (którego w rzeczywistości nie używamy), ale także symbolizowanie śledzenia wstecznego i obsługę informacji debugowania karła, takich jak ramki wstawiane i tak dalej.
//!
//!
//! Jest to stosunkowo skomplikowane z powodu wielu różnych problemów, ale podstawowa idea jest taka:
//!
//! * Najpierw nazywamy `backtrace_syminfo`.To pobiera informacje o symbolach z dynamicznej tablicy symboli, jeśli możemy.
//! * Następnie dzwonimy do `backtrace_pcinfo`.Spowoduje to przeanalizowanie tabel debuginfo, jeśli są dostępne, i pozwoli nam odzyskać informacje o ramkach wbudowanych, nazwach plików, numerach wierszy itp.
//!
//! Istnieje wiele sztuczek związanych z wprowadzeniem tabel krasnoludów do libbacktrace, ale mam nadzieję, że to nie koniec świata i jest wystarczająco jasny, gdy czytasz poniżej.
//!
//! Jest to domyślna strategia symbolizacji dla platform innych niż MSVC i OSX.Jednak w libstd jest to domyślna strategia dla OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Jeśli to możliwe, preferuj nazwę `function`, która pochodzi z informacji o debugowaniu i zazwyczaj może być dokładniejsza, na przykład w przypadku ramek wbudowanych.
                // Jeśli tego nie ma, wróć do nazwy tabeli symboli określonej w `symname`.
                //
                // Zauważ, że czasami `function` może wydawać się nieco mniej dokładny, na przykład jako `try<i32,closure>` jest częścią `std::panicking::try::do_call`.
                //
                // Nie jest do końca jasne, dlaczego, ale ogólnie nazwa `function` wydaje się dokładniejsza.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // na razie nic nie rób
}

/// Typ wskaźnika `data` przekazany do `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Po wywołaniu tego wywołania zwrotnego z `backtrace_syminfo`, gdy zaczynamy rozwiązywać, przechodzimy dalej, aby wywołać `backtrace_pcinfo`.
    // Funkcja `backtrace_pcinfo` zapozna się z informacjami debugowania i podejmie próbę wykonania takich czynności, jak odzyskanie informacji file/line, a także wstawionych ramek.
    // Zauważ jednak, że `backtrace_pcinfo` może zawieść lub nie zrobić wiele, jeśli nie ma informacji o debugowaniu, więc jeśli tak się stanie, z pewnością wywołasz wywołanie zwrotne z co najmniej jednym symbolem z `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Typ wskaźnika `data` przekazany do `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Interfejs API libbacktrace obsługuje tworzenie stanu, ale nie obsługuje niszczenia stanu.
// Osobiście uważam, że oznacza to, że stan ma zostać stworzony, a następnie żyć wiecznie.
//
// Chciałbym zarejestrować program obsługi at_exit(), który czyści ten stan, ale libbacktrace nie daje takiej możliwości.
//
// Z tymi ograniczeniami ta funkcja ma statycznie buforowany stan, który jest obliczany przy pierwszym żądaniu.
//
// Pamiętaj, że wszystkie operacje śledzenia wstecznego odbywają się po kolei (jedna blokada globalna).
//
// Zauważ, że brak synchronizacji w tym przypadku wynika z wymogu zewnętrznej synchronizacji `resolve`.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Nie korzystaj z możliwości ochrony wątków w libbacktrace, ponieważ zawsze wywołujemy ją w sposób zsynchronizowany.
        //
        0,
        error_cb,
        ptr::null_mut(), // brak dodatkowych danych
    );

    return STATE;

    // Zauważ, że aby libbacktrace w ogóle działało, musi znaleźć informacje debugowania DWARF dla bieżącego pliku wykonywalnego.Zwykle robi to za pomocą wielu mechanizmów, w tym między innymi:
    //
    // * /proc/self/exe na obsługiwanych platformach
    // * Nazwa pliku przekazana jawnie podczas tworzenia stanu
    //
    // Biblioteka libbacktrace to duży plik kodu w C.To oczywiście oznacza, że ma luki w zabezpieczeniach pamięci, szczególnie podczas obsługi źle sformułowanych informacji o debugowaniu.
    // Libstd napotkał wiele z nich w przeszłości.
    //
    // Jeśli używany jest /proc/self/exe, zwykle możemy je zignorować, ponieważ zakładamy, że libbacktrace to "mostly correct", a poza tym nie robi dziwnych rzeczy z informacjami o debugowaniu karła "attempted to be correct".
    //
    //
    // Jeśli jednak przekażemy nazwę pliku, jest to możliwe na niektórych platformach (takich jak BSD), na których złośliwy aktor może spowodować umieszczenie dowolnego pliku w tej lokalizacji.
    // Oznacza to, że jeśli powiemy libbacktrace o nazwie pliku, może on używać dowolnego pliku, prawdopodobnie powodując błędy segfault.
    // Jeśli jednak nic nie powiemy libbacktrace, to nic nie zrobi na platformach, które nie obsługują ścieżek, takich jak /proc/self/exe!
    //
    // Biorąc pod uwagę wszystko, co staramy się jak najbardziej *nie* przekazywać nazwy pliku, ale musimy na platformach, które w ogóle nie obsługują /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Zwróć uwagę, że idealnie byłoby użyć `std::env::current_exe`, ale nie możemy tutaj wymagać `std`.
            //
            // Użyj `_NSGetExecutablePath`, aby załadować bieżącą ścieżkę wykonywalną do obszaru statycznego (który, jeśli jest zbyt mały, po prostu zrezygnuj).
            //
            //
            // Zauważ, że poważnie ufamy, że libbacktrace nie umrze na uszkodzonych plikach wykonywalnych, ale z pewnością ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ma tryb otwierania plików, w którym po otwarciu nie można go usunąć.
            // Generalnie tego chcemy tutaj, ponieważ chcemy mieć pewność, że nasz plik wykonywalny nie zmieni się spod nas po przekazaniu go libbacktrace, miejmy nadzieję, że złagodzi możliwość przekazywania dowolnych danych do libbacktrace (co może być niewłaściwie obsługiwane).
            //
            //
            // Biorąc pod uwagę, że wykonujemy tu trochę tańca, aby spróbować zablokować swój własny wizerunek:
            //
            // * Uzyskaj uchwyt do bieżącego procesu, załaduj jego nazwę pliku.
            // * Otwórz plik o tej nazwie z odpowiednimi flagami.
            // * Załaduj ponownie nazwę pliku bieżącego procesu, upewniając się, że jest taka sama
            //
            // Jeśli to wszystko się powiedzie, w teorii faktycznie otworzyliśmy plik naszego procesu i mamy gwarancję, że się nie zmieni.FWIW, część tego jest historycznie skopiowana z libstd, więc jest to moja najlepsza interpretacja tego, co się dzieje.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // To żyje w pamięci statycznej, więc możemy je zwrócić.
                static mut BUF: [i8; N] = [0; N];
                // ... i to żyje na stosie, ponieważ jest tymczasowe
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // celowo przecieka `handle` tutaj, ponieważ otwarcie tego powinno zachować naszą blokadę na tej nazwie pliku.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Chcemy zwrócić wycinek zakończony wartością nul, więc jeśli wszystko zostało wypełnione i równa się całkowitej długości, zrównaj to z niepowodzeniem.
                //
                //
                // W przeciwnym razie podczas zwracania sukcesu upewnij się, że bajt nul jest uwzględniony w wycinku.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // błędy śledzenia wstecznego są obecnie zamiatane pod dywan
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Wywołaj interfejs API `backtrace_syminfo`, który (czytając kod) powinien wywołać `syminfo_cb` dokładnie raz (lub prawdopodobnie zakończy się błędem).
    // W `syminfo_cb` zajmujemy się więcej.
    //
    // Zauważ, że robimy to, ponieważ `syminfo` skonsultuje się z tablicą symboli, znajdując nazwy symboli, nawet jeśli nie ma informacji debugowania w pliku binarnym.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}