use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Przekształć adres na symbol, przekazując symbol do określonego zamknięcia.
///
/// Ta funkcja wyszuka podany adres w obszarach, takich jak lokalna tablica symboli, dynamiczna tablica symboli lub informacje debugowania DWARF (w zależności od aktywowanej implementacji), aby znaleźć symbole do uzyskania.
///
///
/// Zamknięcia nie można wywołać, jeśli nie można wykonać rozdzielczości, a także można go wywołać więcej niż jeden raz w przypadku funkcji wbudowanych.
///
/// Uzyskane symbole reprezentują wykonanie w określonym `addr`, zwracając pary file/line dla tego adresu (jeśli są dostępne).
///
/// Zauważ, że jeśli masz `Frame`, zaleca się użycie funkcji `resolve_frame` zamiast tej.
///
/// # Wymagane funkcje
///
/// Ta funkcja wymaga włączenia funkcji `std` w `backtrace` crate, a funkcja `std` jest domyślnie włączona.
///
/// # Panics
///
/// Ta funkcja stara się nigdy nie panic, ale jeśli `cb` dostarczył panics, to niektóre platformy zmuszą podwójny panic do przerwania procesu.
/// Niektóre platformy używają biblioteki C, która wewnętrznie używa wywołań zwrotnych, których nie można przywrócić, więc panikowanie z `cb` może spowodować przerwanie procesu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // spójrz tylko na górną ramę
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Przekształć poprzednio przechwyconą klatkę na symbol, przekazując symbol do określonego zamknięcia.
///
/// Ta funkcja pełni tę samą funkcję co `resolve`, z tym wyjątkiem, że przyjmuje `Frame` jako argument zamiast adresu.
/// Może to umożliwić niektórym implementacjom śledzenia wstecznego na platformie dostarczanie dokładniejszych informacji o symbolach lub na przykład informacji o ramkach wbudowanych.
///
/// Zaleca się korzystanie z tego, jeśli możesz.
///
/// # Wymagane funkcje
///
/// Ta funkcja wymaga włączenia funkcji `std` w `backtrace` crate, a funkcja `std` jest domyślnie włączona.
///
/// # Panics
///
/// Ta funkcja stara się nigdy nie panic, ale jeśli `cb` dostarczył panics, to niektóre platformy zmuszą podwójny panic do przerwania procesu.
/// Niektóre platformy używają biblioteki C, która wewnętrznie używa wywołań zwrotnych, których nie można przywrócić, więc panikowanie z `cb` może spowodować przerwanie procesu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // spójrz tylko na górną ramę
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Wartości IP z ramek stosu są zwykle (always?) instrukcją *po* wywołaniu, która jest rzeczywistym śladem stosu.
// Symbolizowanie tego na powoduje, że liczba filename/line jest o jeden do przodu i być może w pustkę, jeśli jest blisko końca funkcji.
//
// Wydaje się, że w zasadzie zawsze ma to miejsce na wszystkich platformach, więc zawsze odejmujemy jeden od rozwiązanego adresu IP, aby rozwiązać go z poprzednią instrukcją wywołania, zamiast instrukcji zwracanej.
//
//
// Idealnie byśmy tego nie robili.
// W idealnym przypadku wymagalibyśmy od wywołujących interfejsów API `resolve`, aby ręcznie wykonali -1 i stwierdzili, że chcą informacji o lokalizacji dla *poprzedniej* instrukcji, a nie bieżącej.
// Idealnie byłoby również ujawnić na `Frame`, jeśli rzeczywiście jesteśmy adresem następnej instrukcji lub bieżącej.
//
// Na razie jest to dość niszowy problem, więc wewnętrznie zawsze odejmujemy jeden.
// Konsumenci powinni nadal pracować i uzyskiwać całkiem dobre wyniki, więc powinniśmy być wystarczająco dobrzy.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Tak samo jak `resolve`, tylko niebezpieczne, ponieważ nie jest zsynchronizowane.
///
/// Ta funkcja nie ma gwarancji synchronizacji, ale jest dostępna, gdy funkcja `std` tego crate nie jest wkompilowana.
/// Więcej dokumentacji i przykładów znajdziesz w opisie funkcji `resolve`.
///
/// # Panics
///
/// Zobacz informacje na temat `resolve`, aby zapoznać się z ostrzeżeniami dotyczącymi paniki `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Tak samo jak `resolve_frame`, tylko niebezpieczne, ponieważ nie jest zsynchronizowane.
///
/// Ta funkcja nie ma gwarancji synchronizacji, ale jest dostępna, gdy funkcja `std` tego crate nie jest wkompilowana.
/// Więcej dokumentacji i przykładów znajdziesz w opisie funkcji `resolve_frame`.
///
/// # Panics
///
/// Zobacz informacje na temat `resolve_frame`, aby poznać zastrzeżenia dotyczące paniki `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait reprezentujące rozdzielczość symbolu w pliku.
///
/// Ten trait jest dostarczany jako obiekt trait do zamknięcia przekazanego funkcji `backtrace::resolve` i jest wirtualnie wysyłany, ponieważ nie wiadomo, która implementacja za tym stoi.
///
///
/// Symbol może podawać kontekstowe informacje o funkcji, na przykład nazwę, nazwę pliku, numer wiersza, dokładny adres itp.
/// Jednak nie wszystkie informacje są zawsze dostępne w symbolu, więc wszystkie metody zwracają `Option`.
///
///
pub struct Symbol {
    // TODO: ten czas życia musi zostać ostatecznie utrzymany w `Symbol`,
    // ale to obecnie przełomowa zmiana.
    // Na razie jest to bezpieczne, ponieważ `Symbol` jest zawsze wydawany tylko przez odniesienie i nie można go sklonować.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Zwraca nazwę tej funkcji.
    ///
    /// Zwrócona struktura może służyć do wykonywania zapytań o różne właściwości dotyczące nazwy symbolu:
    ///
    ///
    /// * Implementacja `Display` wydrukuje zdemanglowany symbol.
    /// * Można uzyskać dostęp do surowej wartości `str` symbolu (jeśli jest to poprawna utf-8).
    /// * Można uzyskać dostęp do surowych bajtów nazwy symbolu.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Zwraca adres początkowy tej funkcji.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Zwraca nieprzetworzoną nazwę pliku jako plasterek.
    /// Jest to przydatne głównie w środowiskach `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Zwraca numer kolumny dla miejsca, w którym ten symbol jest obecnie wykonywany.
    ///
    /// Tylko gimli podaje obecnie wartość tutaj, a nawet wtedy tylko wtedy, gdy `filename` zwraca `Some`, a więc podlega podobnym zastrzeżeniom.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Zwraca numer wiersza, w którym ten symbol jest obecnie wykonywany.
    ///
    /// Ta zwracana wartość to zwykle `Some`, jeśli `filename` zwraca `Some`, i w konsekwencji podlega podobnym zastrzeżeniom.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Zwraca nazwę pliku, w którym zdefiniowano tę funkcję.
    ///
    /// Obecnie jest to dostępne tylko wtedy, gdy używana jest biblioteka libbacktrace lub gimli (np
    /// unix platformy inne) i gdy plik binarny jest kompilowany za pomocą funkcji debuginfo.
    /// Jeśli żaden z tych warunków nie jest spełniony, prawdopodobnie zwróci `None`.
    ///
    /// # Wymagane funkcje
    ///
    /// Ta funkcja wymaga włączenia funkcji `std` w `backtrace` crate, a funkcja `std` jest domyślnie włączona.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Może przeanalizowany symbol C++ , jeśli analiza zniekształconego symbolu jako Rust nie powiodła się.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Pamiętaj, aby zachować zerowy rozmiar, aby funkcja `cpp_demangle` była bezpłatna po wyłączeniu.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Opakowanie wokół nazwy symbolu w celu zapewnienia ergonomicznych metod dostępu do odkodowanej nazwy, surowych bajtów, nieprzetworzonego ciągu itp.
///
// Zezwalaj na martwy kod, gdy funkcja `cpp_demangle` nie jest włączona.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Tworzy nową nazwę symbolu z surowych bazowych bajtów.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Zwraca nieprzetworzoną nazwę symbolu (mangled) jako `str`, jeśli symbol jest prawidłowy utf-8.
    ///
    /// Użyj implementacji `Display`, jeśli chcesz uzyskać wersję demangled.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Zwraca surową nazwę symbolu jako listę bajtów
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Może to zostać wydrukowane, jeśli zdemontowany symbol nie jest w rzeczywistości poprawny, więc obsłuż błąd tutaj z wdziękiem, nie propagując go na zewnątrz.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Spróbuj odzyskać pamięć podręczną używaną do symbolizowania adresów.
///
/// Ta metoda podejmie próbę zwolnienia wszelkich globalnych struktur danych, które w innym przypadku byłyby buforowane globalnie lub w wątku, które zazwyczaj reprezentują przeanalizowane informacje DWARF lub podobne.
///
///
/// # Caveats
///
/// Chociaż ta funkcja jest zawsze dostępna, w rzeczywistości nie robi nic w większości implementacji.
/// Biblioteki, takie jak dbghelp lub libbacktrace, nie zapewniają narzędzi do zwalniania stanu i zarządzania przydzieloną pamięcią.
/// Na razie funkcja `gimli-symbolize` tego crate jest jedyną funkcją, w której ta funkcja ma jakikolwiek efekt.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}