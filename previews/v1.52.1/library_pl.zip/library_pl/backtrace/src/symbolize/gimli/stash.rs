// obecnie używany tylko na Linux, więc zezwalaj na martwy kod w innym miejscu
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Prosty alokator areny dla buforów bajtów.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Przydziela bufor o określonym rozmiarze i zwraca do niego zmienne odwołanie.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // BEZPIECZEŃSTWO: jest to jedyna funkcja, która kiedykolwiek konstruuje zmienną
        // odniesienie do `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // BEZPIECZEŃSTWO: nigdy nie usuwamy elementów z `self.buffers`, więc odniesienie
        // do danych w dowolnym buforze będzie żył tak długo, jak `self`.
        &mut buffers[i]
    }
}