//! Obsługa symbolizacji przy użyciu `gimli` crate na crates.io
//!
//! To jest domyślna implementacja symbolizacji dla Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // " statyczny czas życia to kłamstwo, które należy omijać brak wsparcia dla struktur odwołujących się do samych siebie.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Konwertuj na " statyczne okresy istnienia, ponieważ symbole powinny pożyczać tylko `map` i `stash`, a zachowujemy je poniżej.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Aby załadować natywne biblioteki na Windows, zobacz dyskusję na temat rust-lang/rust#71060 dla różnych strategii tutaj.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Biblioteki MinGW obecnie nie obsługują ASLR (rust-lang/rust#16514), ale biblioteki DLL mogą być nadal przenoszone w przestrzeni adresowej.
            // Wygląda na to, że adresy w informacjach debugowania są takie, jakby ta biblioteka została załadowana w jej "image base", co jest polem w jej nagłówkach plików COFF.
            // Ponieważ wydaje się, że jest to lista debuginfo, analizujemy tablicę symboli i przechowujemy adresy tak, jakby biblioteka była również ładowana w "image base".
            //
            // Biblioteki nie można jednak załadować w "image base".
            // (przypuszczalnie można tam załadować coś innego?) W tym miejscu do gry wkracza pole `bias` i musimy tutaj obliczyć wartość `bias`.Niestety nie jest jasne, jak to uzyskać z załadowanego modułu.
            // Mamy jednak rzeczywisty adres ładowania (`modBaseAddr`).
            //
            // Jako trochę wykrętki na razie mmapujemy plik, czytamy informacje z nagłówka pliku, a następnie upuszczamy mmap.Jest to marnotrawstwo, ponieważ prawdopodobnie później ponownie otworzymy mmapa, ale na razie powinno to działać wystarczająco dobrze.
            //
            // Gdy już mamy `image_base` (pożądaną lokalizację ładowania) i `base_addr` (rzeczywistą lokalizację ładowania), możemy wypełnić `bias` (różnicę między rzeczywistym a pożądanym), a następnie podany adres każdego segmentu to `image_base`, ponieważ tak mówi plik.
            //
            //
            // Na razie wygląda na to, że w przeciwieństwie do ELF/MachO możemy zadowolić się jednym segmentem na bibliotekę, używając `modBaseSize` jako całego rozmiaru.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS używa formatu pliku Mach-O i używa interfejsów API specyficznych dla DYLD do załadowania listy natywnych bibliotek, które są częścią aplikacji.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Pobierz nazwę tej biblioteki, która odpowiada ścieżce, gdzie ją załadować.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Załaduj nagłówek obrazu tej biblioteki i deleguj do `object`, aby przeanalizować wszystkie polecenia ładowania, abyśmy mogli znaleźć wszystkie segmenty, których to dotyczy.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Powtarzaj segmenty i rejestruj znane regiony dla znalezionych segmentów.
            // Dodatkowo zapisz informacje o segmentach tekstu do późniejszego przetworzenia, patrz komentarze poniżej.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Określ "slide" dla tej biblioteki, która kończy się błędem, którego używamy, aby dowiedzieć się, gdzie w pamięci są ładowane obiekty.
            // Jest to jednak trochę dziwne obliczenie i jest wynikiem wypróbowania kilku rzeczy na wolności i sprawdzenia, co się trzyma.
            //
            // Ogólna idea jest taka, że `bias` plus `stated_virtual_memory_address` segmentu będzie tam, gdzie w rzeczywistej przestrzeni adresowej znajduje się segment.
            // Inną rzeczą, na której polegamy, jest to, że prawdziwy adres minus `bias` jest indeksem do wyszukiwania w tablicy symboli i informacji o debugowaniu.
            //
            // Okazuje się jednak, że dla bibliotek ładowanych przez system obliczenia te są niepoprawne.Jednak w przypadku natywnych plików wykonywalnych wydaje się to poprawne.
            // Podnosząc trochę logiki ze źródła LLDB, ma on specjalną wielkość liter dla pierwszej sekcji `__TEXT` ładowanej z pliku offset 0 o niezerowym rozmiarze.
            // Z jakiegoś powodu, kiedy to jest obecne, wydaje się, że oznacza to, że tablica symboli jest względna tylko do slajdu vmaddr dla biblioteki.
            // Jeśli *nie* jest obecny, to tablica symboli jest zależna od slajdu vmaddr plus podany adres segmentu.
            //
            // Aby poradzić sobie z tą sytuacją, jeśli *nie* znajdziemy sekcji tekstowej w pliku offset zero, zwiększamy odchylenie o podany adres pierwszej sekcji tekstu i zmniejszamy również wszystkie podane adresy o tę wartość.
            //
            // W ten sposób tablica symboli jest zawsze wyświetlana w odniesieniu do wartości odchylenia biblioteki.
            // Wydaje się, że daje to właściwe wyniki dla symbolizacji za pomocą tabeli symboli.
            //
            // Szczerze mówiąc, nie jestem do końca pewien, czy to prawda, czy też jest coś innego, co powinno wskazywać, jak to zrobić.
            // Na razie wydaje się, że działa to wystarczająco dobrze (?) i zawsze powinniśmy być w stanie poprawić to z czasem, jeśli to konieczne.
            //
            // Aby uzyskać więcej informacji, zobacz #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Inne Unix (np
        // Linux) używają ELF jako formatu pliku obiektowego i zazwyczaj implementują interfejs API o nazwie `dl_iterate_phdr` do ładowania natywnych bibliotek.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` powinny być prawidłowymi wskazówkami.
        // `vec` powinien być prawidłowym wskaźnikiem do `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 nie obsługuje natywnie informacji debugowania, ale system kompilacji umieści informacje debugowania w ścieżce `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Wszystko inne powinno używać ELF, ale nie wie, jak załadować biblioteki natywne.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Wszystkie znane biblioteki współdzielone, które zostały załadowane.
    libraries: Vec<Library>,

    /// Pamięć podręczna mapowań, w której przechowujemy przeanalizowane informacje o karłach.
    ///
    /// Ta lista ma stałą pojemność dla całego okresu użytkowania, która nigdy się nie zwiększa.
    /// Element `usize` każdej pary jest indeksem do `libraries` powyżej, gdzie `usize::max_value()` reprezentuje bieżący plik wykonywalny.
    ///
    /// `Mapping` to odpowiednia przeanalizowana informacja o karłach.
    ///
    /// Zauważ, że jest to w zasadzie pamięć podręczna LRU i będziemy tu przenosić rzeczy, gdy będziemy symbolizować adresy.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmenty tej biblioteki są ładowane do pamięci i gdzie są ładowane.
    segments: Vec<LibrarySegment>,
    /// "bias" tej biblioteki, zwykle tam, gdzie jest ładowany do pamięci.
    /// Ta wartość jest dodawana do podanego adresu każdego segmentu, aby uzyskać rzeczywisty adres pamięci wirtualnej, do której segment jest ładowany.
    /// Dodatkowo to odchylenie jest odejmowane od rzeczywistych adresów pamięci wirtualnej w celu zaindeksowania informacji o debugowaniu i tablicy symboli.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Podany adres tego segmentu w pliku obiektowym.
    /// W rzeczywistości nie jest to miejsce, w którym ładowany jest segment, ale raczej ten adres plus `bias` biblioteki zawierającej to miejsce, w którym można go znaleźć.
    ///
    stated_virtual_memory_address: usize,
    /// Rozmiar tego segmentu w pamięci.
    len: usize,
}

// niebezpieczne, ponieważ wymaga zewnętrznej synchronizacji
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // niebezpieczne, ponieważ wymaga zewnętrznej synchronizacji
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Bardzo mała, bardzo prosta pamięć podręczna LRU do mapowania informacji debugowania.
        //
        // Współczynnik trafień powinien być bardzo wysoki, ponieważ typowy stos nie krzyżuje się między wieloma bibliotekami współdzielonymi.
        //
        // Struktury `addr2line::Context` są dość drogie w tworzeniu.
        // Oczekuje się, że jego koszt zostanie zamortyzowany przez kolejne zapytania `locate`, które wykorzystują struktury zbudowane podczas konstruowania `addr2line: : Context`, aby uzyskać dobre przyspieszenia.
        //
        // Gdybyśmy nie mieli tej pamięci podręcznej, ta amortyzacja nigdy by się nie wydarzyła, a symboliczne ślady wsteczne byłyby ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Najpierw sprawdź, czy ten `lib` ma segment zawierający `addr` (obsługa relokacji).Jeśli to sprawdzenie przejdzie pomyślnie, możemy kontynuować poniżej i faktycznie przetłumaczyć adres.
                //
                // Zwróć uwagę, że używamy tutaj `wrapping_add`, aby uniknąć sprawdzania przepełnienia.Na wolności zaobserwowano, że obliczenia odchylenia SVMA + przepełniają się.
                // Wydaje się to trochę dziwne, że tak się stanie, ale niewiele możemy z tym zrobić, poza tym, że prawdopodobnie po prostu zignorujemy te segmenty, ponieważ prawdopodobnie wskazują one w kosmos.
                //
                // To pierwotnie pojawiło się w rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Teraz, gdy wiemy, że `lib` zawiera `addr`, możemy przesunąć odchylenie, aby znaleźć podany adres pamięci wirusowej.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Niezmienny: po zakończeniu tego warunku bez wcześniejszego powrotu
        // z powodu błędu wpis pamięci podręcznej dla tej ścieżki znajduje się pod indeksem 0.

        if let Some(idx) = idx {
            // Gdy mapowanie jest już w pamięci podręcznej, przenieś je na przód.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Jeśli mapowania nie ma w pamięci podręcznej, utwórz nowe mapowanie, włóż je z przodu pamięci podręcznej i usuń najstarszy wpis pamięci podręcznej, jeśli to konieczne.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // nie przeciekaj żywotności `'static`, upewnij się, że jest on przeznaczony tylko dla nas
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Wydłuż żywotność `sym` do `'static`, ponieważ niestety jesteśmy tutaj zobowiązani, ale zawsze pojawia się jako odniesienie, więc i tak żadne odniesienie do niego nie powinno być utrzymywane poza tą ramką.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Na koniec pobierz mapowanie z pamięci podręcznej lub utwórz nowe mapowanie dla tego pliku i oceń informacje DWARF, aby znaleźć file/line/name dla tego adresu.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Udało nam się znaleźć informacje o ramce dla tego symbolu, a ramka `addr2line` ma wewnętrznie wszystkie podstawowe szczegóły.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Nie można znaleźć informacji debugowania, ale znaleźliśmy je w tabeli symboli pliku wykonywalnego elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}