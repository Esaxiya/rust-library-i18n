//! Typy zależne od platformy.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Niezależna od platformy reprezentacja ciągu.
/// Podczas pracy z włączonym `std` zaleca się wygodne metody zapewniania konwersji na typy `std`.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Kawałek, zwykle dostarczany na platformach Unix.
    Bytes(&'a [u8]),
    /// Szerokie struny typowo od Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Stratna konwersja do `Cow<str>`, przydzieli, jeśli `Bytes` nie jest poprawne UTF-8 lub jeśli `BytesOrWideString` to `Wide`.
    ///
    /// # Wymagane funkcje
    ///
    /// Ta funkcja wymaga włączenia funkcji `std` w `backtrace` crate, a funkcja `std` jest domyślnie włączona.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Zapewnia reprezentację `Path` `BytesOrWideString`.
    ///
    /// # Wymagane funkcje
    ///
    /// Ta funkcja wymaga włączenia funkcji `std` w `backtrace` crate, a funkcja `std` jest domyślnie włączona.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}