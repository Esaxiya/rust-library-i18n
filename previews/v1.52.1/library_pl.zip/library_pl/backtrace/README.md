# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Biblioteka do uzyskiwania śladów śledzenia w czasie wykonywania dla Rust.
Ta biblioteka ma na celu ulepszenie obsługi standardowej biblioteki poprzez zapewnienie programistycznego interfejsu do pracy, ale obsługuje również proste łatwe drukowanie bieżącego śledzenia wstecznego, takiego jak panics libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Aby po prostu uchwycić ślad śladu i odłożyć zajmowanie się nim na później, możesz użyć typu `Backtrace` najwyższego poziomu.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Jeśli jednak chcesz mieć bardziej surowy dostęp do rzeczywistych funkcji śledzenia, możesz bezpośrednio użyć funkcji `trace` i `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Rozwiąż ten wskaźnik instrukcji na nazwę symbolu
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // przejdź do następnej klatki
    });
}
```

# License

Ten projekt jest objęty licencją w ramach jednego z

 * Licencja Apache, wersja 2.0, ([LICENSE-APACHE](LICENSE-APACHE) lub http://www.apache.org/licenses/LICENSE-2.0)
 * Licencja MIT ([LICENSE-MIT](LICENSE-MIT) lub http://opensource.org/licenses/MIT)

według własnego uznania.

### Contribution

O ile wyraźnie nie postanowisz inaczej, każdy wkład celowo przesłany przez Ciebie do włączenia do backtrace-rs, zgodnie z definicją w licencji Apache-2.0, będzie objęty podwójną licencją, jak powyżej, bez żadnych dodatkowych warunków.







