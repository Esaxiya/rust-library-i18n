//! Unwinding panics dla Miri.
use alloc::boxed::Box;
use core::any::Any;

// Typ ładunku, który silnik Miri propaguje, rozwijając dla nas.
// Musi mieć rozmiar wskaźnika.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Funkcja zewnętrzna zapewniana przez Miri, aby rozpocząć rozwijanie.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Ładunek, który przekazujemy do `miri_start_panic`, będzie dokładnie tym argumentem, który otrzymujemy w `cleanup` poniżej.
    // Więc po prostu zapakowujemy to raz, aby uzyskać coś o rozmiarze wskaźnika.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Odzyskaj podstawowy `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}