//! Implementacja panics poprzez rozwijanie stosu
//!
//! Ten crate jest implementacją panics w Rust przy użyciu mechanizmu rozwijania stosu "most native" platformy, dla której jest kompilowany.
//! Zasadniczo dzieli się to obecnie na trzy segmenty:
//!
//! 1. Cele MSVC używają SEH w pliku `seh.rs`.
//! 2. Emscripten używa wyjątków C++ w pliku `emcc.rs`.
//! 3. Wszystkie inne cele używają libunwind/libgcc w pliku `gcc.rs`.
//!
//! Więcej dokumentacji na temat każdego wdrożenia można znaleźć w odpowiednim module.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` nie jest używany z Miri, więc ostrzeżenia o ciszy.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Obiekty startowe środowiska uruchomieniowego Rust zależą od tych symboli, więc upublicznij je.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Cele, które nie obsługują rozwijania.
        // - arch=wasm32
        // - os=none (cele "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Użyj środowiska wykonawczego Miri.
        // Nadal musimy również załadować normalne środowisko uruchomieniowe powyżej, ponieważ rustc oczekuje, że określone zostaną stamtąd pewne elementy języka.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Użyj rzeczywistego środowiska uruchomieniowego.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler w libstd jest wywoływany, gdy obiekt panic zostanie upuszczony poza `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler w libstd wywoływany, gdy zostanie przechwycony wyjątek obcy.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Punkt wejścia do zgłaszania wyjątku, po prostu delegaci do implementacji specyficznej dla platformy.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}