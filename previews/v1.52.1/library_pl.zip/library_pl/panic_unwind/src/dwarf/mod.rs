//! Narzędzia do analizowania strumieni danych zakodowanych w formacie DWARF.
//! Patrz standard <http://www.dwarfstd.org>, DWARF-4, rozdział 7, "Data Representation"
//!

// Ten moduł jest obecnie używany tylko przez x86_64-pc-windows-gnu, ale kompilujemy go wszędzie, aby uniknąć regresji.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Strumienie DWARF są pakowane, więc np. u32 niekoniecznie musi być wyrównany do 4-bajtowej granicy.
    // Może to powodować problemy na platformach ze ścisłymi wymaganiami dotyczącymi wyrównania.
    // Pakując dane w strukturę "packed", mówimy backendowi, aby wygenerował kod "misalignment-safe".
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // Kodowania ULEB128 i SLEB128 są zdefiniowane w sekcji 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}