//! Windows SEH
//!
//! Na Windows (obecnie tylko na MSVC) domyślnym mechanizmem obsługi wyjątków jest Structured Exception Handling (SEH).
//! Jest to zupełnie inne niż obsługa wyjątków oparta na Dwarfach (np. Używana na innych platformach unix) pod względem wewnętrznych elementów kompilatora, więc LLVM musi mieć dużo dodatkowego wsparcia dla SEH.
//!
//! Krótko mówiąc, to, co się tutaj dzieje, to:
//!
//! 1. Funkcja `panic` wywołuje standardową funkcję Windows `_CxxThrowException`, aby zgłosić wyjątek podobny do C++ , wyzwalając proces odwijania.
//! 2.
//! Wszystkie lądowiska wygenerowane przez kompilator używają funkcji osobowości `__CxxFrameHandler3`, funkcji w CRT, a rozwijany kod w Windows będzie używał tej funkcji osobowości do wykonania całego kodu porządkującego na stosie.
//!
//! 3. Wszystkie wywołania `invoke` generowane przez kompilator mają lądowisko ustawione jako instrukcja `cleanuppad` LLVM, która wskazuje początek procedury czyszczenia.
//! Osobowość (w kroku 2, zdefiniowana w CRT) jest odpowiedzialna za wykonywanie procedur czyszczenia.
//! 4. Ostatecznie kod "catch" w module wewnętrznym `try` (wygenerowanym przez kompilator) jest wykonywany i wskazuje, że sterowanie powinno wrócić do Rust.
//! Odbywa się to za pomocą instrukcji `catchswitch` plus `catchpad` w terminach LLVM IR, ostatecznie przywracając normalne sterowanie do programu za pomocą instrukcji `catchret`.
//!
//! Niektóre specyficzne różnice w stosunku do obsługi wyjątków opartej na gcc to:
//!
//! * Rust nie ma niestandardowej funkcji osobowości, zamiast tego jest *zawsze*`__CxxFrameHandler3`.Ponadto nie jest wykonywane żadne dodatkowe filtrowanie, więc w końcu wychwytujemy wszelkie wyjątki C++ , które wyglądają tak, jak te, które rzucamy.
//! Zauważ, że wyrzucenie wyjątku do Rust i tak jest niezdefiniowanym zachowaniem, więc powinno wystarczyć.
//! * Mamy trochę danych do przesłania przez rozwijającą się granicę, w szczególności `Box<dyn Any + Send>`.Podobnie jak w przypadku wyjątków krasnoludów, te dwa wskaźniki są przechowywane jako ładunek w samym wyjątku.
//! Jednak w MSVC nie ma potrzeby przydzielania dodatkowej sterty, ponieważ stos wywołań jest zachowywany podczas wykonywania funkcji filtrujących.
//! Oznacza to, że wskaźniki są przekazywane bezpośrednio do `_CxxThrowException`, które są następnie odzyskiwane w funkcji filtru w celu zapisania w ramce stosu elementu wewnętrznego `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Musi to być opcja, ponieważ wychwytujemy wyjątek przez odniesienie, a jego destruktor jest wykonywany przez środowisko wykonawcze C++ .
    // Kiedy wyjmujemy Box z wyjątku, musimy pozostawić wyjątek w prawidłowym stanie, aby jego destruktor działał bez podwójnego upuszczania Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Najpierw cała masa definicji typów.Jest tu kilka dziwactw specyficznych dla platformy, a wiele z nich jest po prostu rażąco skopiowanych z LLVM.Celem tego wszystkiego jest zaimplementowanie poniższej funkcji `panic` poprzez wywołanie `_CxxThrowException`.
//
// Ta funkcja przyjmuje dwa argumenty.Pierwszym jest wskaźnik do przekazywanych danych, którym w tym przypadku jest nasz obiekt trait.Bardzo łatwe do znalezienia!Następny jest jednak bardziej skomplikowany.
// To jest wskaźnik do struktury `_ThrowInfo` i zwykle ma na celu po prostu opisanie zgłaszanego wyjątku.
//
// Obecnie definicja tego typu [1] jest trochę owłosiona, a główną osobliwością (i różnicą w stosunku do artykułu online) jest to, że w wersji 32-bitowej wskaźniki są wskaźnikami, ale w wersji 64-bitowej wskaźniki są wyrażane jako 32-bitowe przesunięcia Symbol `__ImageBase`.
//
// Do wyrażenia tego służą makra `ptr_t` i `ptr!` w poniższych modułach.
//
// Labirynt definicji typów również ściśle podąża za tym, co LLVM emituje dla tego rodzaju operacji.Na przykład, jeśli kompilujesz ten kod C++ na MSVC i emitujesz LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      nieważne foo() { rust_panic a = {0, 1};
//          Rzuć;}
//
// Zasadniczo to właśnie próbujemy naśladować.Większość poniższych stałych wartości została właśnie skopiowana z LLVM,
//
// W każdym razie wszystkie te struktury są zbudowane w podobny sposób i jest to dla nas trochę rozwlekłe.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Zauważ, że celowo ignorujemy tutaj reguły dotyczące zniekształcania nazw: nie chcemy, aby C++ był w stanie złapać Rust panics po prostu deklarując `struct rust_panic`.
//
//
// Podczas modyfikowania upewnij się, że ciąg nazwy typu jest dokładnie zgodny z tym używanym w `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Wiodący bajt `\x01` jest w rzeczywistości magicznym sygnałem dla LLVM, aby *nie* stosować żadnych innych zniekształceń, takich jak prefiksowanie znaku `_`.
    //
    //
    // Ten symbol jest tabelą vtable używaną przez `std::type_info` w języku C++ .
    // Obiekty typu `std::type_info`, deskryptory typów, mają wskaźnik do tej tabeli.
    // Deskryptory typów są przywoływane przez struktury C++ EH zdefiniowane powyżej i które konstruujemy poniżej.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Ten deskryptor typu jest używany tylko podczas zgłaszania wyjątku.
// Część catch jest obsługiwana przez wewnętrzną try, która generuje swój własny TypeDescriptor.
//
// Jest to w porządku, ponieważ środowisko uruchomieniowe MSVC używa porównania ciągów w nazwie typu w celu dopasowania TypeDescriptors zamiast równości wskaźnika.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destruktor używany, jeśli kod C++ zdecyduje się przechwycić wyjątek i porzucić go bez propagowania go.
// Część catch procedury try intrinsic ustawi pierwsze słowo obiektu wyjątku na 0, tak aby zostało ono pominięte przez destruktor.
//
// Zauważ, że x86 Windows używa konwencji wywoływania "thiscall" dla funkcji składowych C++ zamiast domyślnej konwencji wywoływania "C".
//
// Funkcja wyjątku_copy jest tutaj nieco wyjątkowa: jest wywoływana przez środowisko wykonawcze MSVC w ramach bloku try/catch, a wygenerowany tutaj panic zostanie użyty jako wynik kopii wyjątku.
//
// Jest to używane przez środowisko uruchomieniowe C++ do obsługi przechwytywania wyjątków za pomocą std::exception_ptr, których nie możemy obsługiwać, ponieważ Box<dyn Any>nie jest klonowalny.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException jest wykonywany w całości na tej ramce stosu, więc nie ma potrzeby przenoszenia `data` na stertę w inny sposób.
    // Po prostu przekazujemy wskaźnik stosu do tej funkcji.
    //
    // ManuallyDrop jest tutaj potrzebny, ponieważ nie chcemy, aby wyjątek był usuwany podczas rozwijania.
    // Zamiast tego zostanie usunięty przez wyjątek_cleanup, który jest wywoływany przez środowisko wykonawcze C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // To ... może wydawać się zaskakujące i uzasadnione.W 32-bitowym MSVC wskaźniki między tymi strukturami są po prostu wskaźnikami.
    // Jednak w 64-bitowym MSVC wskaźniki między strukturami są raczej wyrażane jako 32-bitowe przesunięcia w stosunku do `__ImageBase`.
    //
    // W konsekwencji na 32-bitowym MSVC możemy zadeklarować wszystkie te wskaźniki w powyższym parametrze " static`.
    // Na 64-bitowym MSVC musielibyśmy wyrazić odejmowanie wskaźników w statyce, na co Rust obecnie nie pozwala, więc nie możemy tego zrobić.
    //
    // Następną najlepszą rzeczą jest wypełnienie tych struktur w czasie wykonywania (i tak panika to już "slow path").
    // Więc tutaj reinterpretujemy wszystkie te pola wskaźników jako 32-bitowe liczby całkowite, a następnie przechowujemy w nich odpowiednią wartość (niepodzielnie, ponieważ może mieć miejsce współbieżne panics).
    //
    // Technicznie rzecz biorąc, środowisko uruchomieniowe prawdopodobnie odczyta te pola w sposób nieatomowy, ale teoretycznie nigdy nie odczyta *złej* wartości, więc nie powinno być tak źle ...
    //
    // W każdym razie zasadniczo musimy zrobić coś takiego, dopóki nie będziemy w stanie wyrazić większej liczby operacji w statyce (a być może nigdy nie będziemy w stanie).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL ładunek tutaj oznacza, że otrzymaliśmy tutaj z połowu (...) z __rust_try.
    // Dzieje się tak, gdy zostanie przechwycony wyjątek zagraniczny inny niż Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Jest to wymagane przez kompilator, aby istniało (np. Jest to pozycja lang), ale w rzeczywistości nie jest wywoływane przez kompilator, ponieważ __C_specific_handler lub_except_handler3 to funkcja osobowości, która jest zawsze używana.
//
// Dlatego jest to tylko przerwany kod.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}