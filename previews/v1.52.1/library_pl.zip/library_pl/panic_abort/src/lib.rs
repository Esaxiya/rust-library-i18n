//! Implementacja Rust panics poprzez przerwanie procesu
//!
//! W porównaniu do implementacji poprzez rozwijanie, ten crate jest *znacznie* prostszy!Biorąc to pod uwagę, nie jest tak wszechstronny, ale proszę bardzo!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" ładunek i podkładkę do odpowiedniego przerwania na danej platformie.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // zadzwoń pod numer std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Na Windows użyj specyficznego dla procesora mechanizmu __fastfail.W Windows 8 i nowszych spowoduje to natychmiastowe zakończenie procesu bez uruchamiania jakichkolwiek procedur obsługi wyjątków w procesie.
            // We wcześniejszych wersjach Windows ta sekwencja instrukcji będzie traktowana jako naruszenie zasad dostępu, kończąc proces, ale niekoniecznie pomijając wszystkie procedury obsługi wyjątków.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: jest to ta sama implementacja, co w `abort_internal` libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// To ... jest trochę dziwne.Tl; dr;jest to, że jest to wymagane do prawidłowego połączenia, dłuższe wyjaśnienie znajduje się poniżej.
//
// Obecnie wszystkie dostarczane przez nas pliki binarne libcore/libstd są skompilowane z `-C panic=unwind`.Ma to na celu zapewnienie, że pliki binarne są maksymalnie kompatybilne z jak największą liczbą sytuacji.
// Kompilator wymaga jednak "personality function" dla wszystkich funkcji skompilowanych za pomocą `-C panic=unwind`.Ta funkcja osobowości jest zakodowana na stałe w symbolu `rust_eh_personality` i jest zdefiniowana przez element `eh_personality` lang.
//
// So...
// dlaczego nie zdefiniować tutaj tego lang elementu?Dobre pytanie!Sposób, w jaki są połączone środowiska wykonawcze panic, jest w rzeczywistości nieco subtelny, ponieważ są one "sort of" w sklepie crate kompilatora, ale w rzeczywistości są połączone tylko wtedy, gdy inny nie jest faktycznie połączony.
//
// Oznacza to, że zarówno ten crate, jak i panic_unwind crate mogą pojawić się w magazynie crate kompilatora, a jeśli oba zdefiniują element `eh_personality` lang, to wystąpi błąd.
//
// Aby sobie z tym poradzić, kompilator wymaga zdefiniowania `eh_personality` tylko wtedy, gdy dowiązane środowisko uruchomieniowe panic jest rozwijającym się środowiskiem uruchomieniowym, w przeciwnym razie nie jest wymagane jego zdefiniowanie (słusznie).
// W tym przypadku jednak ta biblioteka po prostu definiuje ten symbol, więc gdzieś jest przynajmniej jakaś osobowość.
//
// Zasadniczo ten symbol jest po prostu zdefiniowany, aby połączyć się z plikami binarnymi libcore/libstd, ale nigdy nie powinien być wywoływany, ponieważ w ogóle nie łączymy się w rozwijającym się środowisku wykonawczym.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Na x86_64-pc-windows-gnu używamy naszej własnej funkcji osobowości, która musi zwrócić `ExceptionContinueSearch`, gdy przekazujemy wszystkie nasze ramki.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Podobnie jak powyżej, odpowiada to elementowi `eh_catch_typeinfo` lang, który jest obecnie używany tylko w Emscripten.
    //
    // Ponieważ panics nie generuje wyjątków, a obce wyjątki są obecnie UB z -C panic=abort (chociaż może to ulec zmianie), żadne wywołania catch_unwind nigdy nie użyją tego typu informacji.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Te dwa są wywoływane przez nasze obiekty startowe na i686-pc-windows-gnu, ale nie muszą nic robić, więc ciała są nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}