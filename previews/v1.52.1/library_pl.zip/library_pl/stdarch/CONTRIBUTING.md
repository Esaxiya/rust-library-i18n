# Przyczynianie się do stdarch

`stdarch` crate jest więcej niż chętny do przyjmowania datków!Najpierw prawdopodobnie będziesz chciał sprawdzić repozytorium i upewnić się, że testy przeszły za Ciebie:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Gdzie `<your-target-arch>` jest potrójną wartością docelową używaną przez `rustup`, np. `x86_x64-unknown-linux-gnu` (bez żadnego poprzedzającego `nightly-` lub podobnego).
Pamiętaj również, że to repozytorium wymaga nocnego kanału Rust!
Powyższe testy w rzeczywistości wymagają, aby nocne rust było domyślne w twoim systemie, aby ustawić, że używa `rustup default nightly` (i `rustup default stable` do przywrócenia).

Jeśli którykolwiek z powyższych kroków nie zadziała, [please let us know][new]!

Następnie możesz [find an issue][issues], aby pomóc, wybraliśmy kilka z tagami [`help wanted`][help] i [`impl-period`][impl], które szczególnie przydałyby się pewna pomoc. 
Możesz być najbardziej zainteresowany [#40][vendor], implementującym wszystkie wewnętrzne funkcje dostawcy na x86.Ten numer zawiera dobre wskazówki, od czego zacząć!

Jeśli masz ogólne pytania, napisz do [join us on gitter][gitter] i zapytaj!Możesz pingować@BurntSushi lub@alexcrichton z pytaniami.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Jak pisać przykłady elementów wewnętrznych stdarch

Istnieje kilka funkcji, które muszą być włączone, aby dany element wewnętrzny działał poprawnie, a przykład musi być uruchomiony przez `cargo test --doc` tylko wtedy, gdy funkcja jest obsługiwana przez procesor.

W rezultacie domyślny `fn main` generowany przez `rustdoc` nie będzie działał (w większości przypadków).
Rozważ skorzystanie z poniższych wskazówek, aby upewnić się, że Twój przykład działa zgodnie z oczekiwaniami.

```rust
/// # // Potrzebujemy cfg_target_feature, aby zapewnić tylko przykład
/// # // uruchamiany przez `cargo test --doc`, gdy procesor obsługuje tę funkcję
/// # #![feature(cfg_target_feature)]
/// # // Potrzebujemy elementu target_feature, aby element wewnętrzny działał
/// # #![feature(target_feature)]
/// #
/// # // rustdoc domyślnie używa `extern crate stdarch`, ale potrzebujemy
/// # // `#[macro_use]`
/// # # [makro_używanie] extern crate stdarch;
/// #
/// # // Prawdziwa główna funkcja
/// # fn main() {
/// #     // Uruchamiaj to tylko wtedy, gdy obsługiwany jest `<target feature>`
/// #     if cfg_feature_enabled! ("<target feature>"){
/// #         // Utwórz funkcję `worker`, która będzie uruchamiana tylko w przypadku funkcji docelowej
/// #         // jest obsługiwany i upewnij się, że `target_feature` jest włączony dla Twojego pracownika
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         niebezpieczny fn worker() {
/// // Wpisz tutaj swój przykład.Tutaj będą działać funkcje specyficzne dla funkcji!Zaszaleć!
///
/// #         }
///
/// #         niebezpieczne { worker(); }
/// #     }
/// # }
```

Jeśli część powyższej składni nie wygląda znajomo, sekcja [Documentation as tests] [Rust Book] opisuje składnię `rustdoc` całkiem dobrze.
Jak zawsze, zapraszam do [join us on gitter][gitter] i zapytaj nas, czy natrafiłeś na jakieś przeszkody i dziękuję za pomoc w ulepszaniu dokumentacji `stdarch`!

# Alternatywne instrukcje testowania

Generalnie zaleca się używanie `ci/run.sh` do uruchamiania testów.
Jednak to może nie działać dla Ciebie, np. Jeśli korzystasz z Windows.

W takim przypadku możesz wrócić do uruchamiania `cargo +nightly test` i `cargo +nightly test --release -p core_arch` w celu przetestowania generowania kodu.
Zauważ, że wymagają one zainstalowania nightly toolchain i aby `rustc` wiedział o twojej docelowej trójce i jej procesorze.
W szczególności musisz ustawić zmienną środowiskową `TARGET`, tak jak w przypadku `ci/run.sh`.
Ponadto musisz ustawić `RUSTCFLAGS` (potrzebujesz `C`), aby wskazać funkcje docelowe, np `RUSTCFLAGS="-C -target-features=+avx2"`.
Możesz także ustawić `-C -target-cpu=native`, jeśli rozwijasz "just" w porównaniu z obecnym procesorem.

Ostrzegamy, że podczas korzystania z tych alternatywnych instrukcji [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], np
testy generowania instrukcji mogą się nie powieść, ponieważ deasembler nazwał je inaczej, np
może generować instrukcje `vaesenc` zamiast `aesenc`, mimo że zachowują się tak samo.
Również te instrukcje wykonują mniej testów niż normalnie, więc nie zdziw się, gdy w końcu zażądasz ściągnięcia, niektóre błędy mogą pojawić się w testach, których tutaj nie omówiono.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






