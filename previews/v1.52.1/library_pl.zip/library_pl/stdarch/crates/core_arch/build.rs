use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Służy do mówienia naszym adnotacjom `#[assert_instr]`, że wszystkie wewnętrzne elementy simd są dostępne do testowania ich kodegenu, ponieważ niektóre są zamknięte za dodatkowym `-Ctarget-feature=+unimplemented-simd128`, który nie ma teraz żadnego odpowiednika w `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}