`core::arch` - Wewnętrzne elementy specyficzne dla architektury rdzennej biblioteki Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Moduł `core::arch` implementuje wewnętrzne funkcje zależne od architektury (np. SIMD).

# Usage 

`core::arch` jest dostępny jako część `libcore` i jest ponownie eksportowany przez `libstd`.Wolisz używać go przez `core::arch` lub `std::arch` niż przez ten crate.
Niestabilne funkcje są często dostępne w nocnym Rust za pośrednictwem `feature(stdsimd)`.

Używanie `core::arch` za pośrednictwem tego crate wymaga nocnego Rust i może (i robi) często się zepsuć.Jedyne przypadki, w których powinieneś rozważyć użycie go za pośrednictwem tego crate to:

* jeśli musisz samodzielnie przekompilować `core::arch`, np. z włączonymi określonymi funkcjami docelowymi, które nie są włączone dla `libcore`/`libstd`.
Note: jeśli potrzebujesz ponownie skompilować go dla niestandardowego celu, preferuj użycie `xargo` i ponowną kompilację `libcore`/`libstd`, jeśli jest to właściwe, zamiast używania tego crate.
  
* używanie niektórych funkcji, które mogą nie być dostępne nawet w przypadku niestabilnych funkcji Rust.Staramy się ograniczyć to do minimum.
Jeśli chcesz skorzystać z niektórych z tych funkcji, otwórz problem, abyśmy mogli je ujawnić w nocnym Rust i stamtąd możesz z nich korzystać.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` jest rozpowszechniany głównie na warunkach zarówno licencji MIT, jak i licencji Apache (wersja 2.0), z częściami objętymi różnymi licencjami typu BSD.

Szczegółowe informacje można znaleźć w LICENSE-APACHE i LICENSE-MIT.

# Contribution

O ile wyraźnie nie postanowisz inaczej, każdy wkład celowo przesłany przez Ciebie do włączenia do `core_arch`, zgodnie z definicją w licencji Apache-2.0, będzie objęty podwójną licencją, jak powyżej, bez żadnych dodatkowych warunków.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












