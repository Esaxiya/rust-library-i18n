//! Biblioteka wsparcia dla autorów makr podczas definiowania nowych makr.
//!
//! Ta biblioteka, dostarczana przez standardową dystrybucję, zapewnia typy używane w interfejsach proceduralnie definiowanych makr, takich jak makra funkcyjne `#[proc_macro]`, atrybuty makr `#[proc_macro_attribute]` i niestandardowe atrybuty wyprowadzania`#[proc_macro_derive]`.
//!
//!
//! Zobacz [the book] po więcej.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Określa, czy proc_macro został udostępniony aktualnie uruchomionemu programowi.
///
/// Proc_macro crate jest przeznaczony tylko do użytku wewnątrz implementacji makr proceduralnych.Wszystkie funkcje w tym crate panic, jeśli są wywoływane spoza makra proceduralnego, na przykład ze skryptu budowania lub testu jednostkowego lub zwykłego pliku binarnego Rust.
///
/// Biorąc pod uwagę biblioteki Rust, które są zaprojektowane do obsługi zarówno przypadków użycia makr, jak i innych niż makra, `proc_macro::is_available()` zapewnia nie panikujący sposób wykrywania, czy infrastruktura wymagana do korzystania z interfejsu API proc_macro jest obecnie dostępna.
/// Zwraca wartość true, jeśli zostanie wywołana z wnętrza makra proceduralnego, false, jeśli zostanie wywołana z dowolnego innego pliku binarnego.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Główny typ dostarczany przez ten crate, reprezentujący abstrakcyjny strumień tokens lub, dokładniej, sekwencję drzew token.
/// Typ zapewnia interfejsy do iteracji po tych drzewach token i odwrotnie, zbierania wielu drzew token w jeden strumień.
///
///
/// Jest to zarówno wejście, jak i wyjście definicji `#[proc_macro]`, `#[proc_macro_attribute]` i `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Błąd zwrócony z `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Zwraca puste `TokenStream` bez drzew token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Sprawdza, czy ten `TokenStream` jest pusty.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Próbuje podzielić ciąg na tokens i przeanalizować te tokens w strumień token.
/// Może się nie powieść z wielu powodów, na przykład jeśli ciąg zawiera niezrównoważone ograniczniki lub znaki nieistniejące w języku.
///
/// Wszystkie tokens w przeanalizowanym strumieniu otrzymują rozpiętości `Span::call_site()`.
///
/// NOTE: niektóre błędy mogą powodować panics zamiast zwracać `LexError`.Zastrzegamy sobie prawo do późniejszej zmiany tych błędów na `LexError`.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// Uwaga, most zapewnia tylko `to_string`, zaimplementuj `fmt::Display` na jego podstawie (odwrotność zwykłej relacji między nimi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Wyświetla strumień token jako ciąg, który powinien być bezstratnie konwertowany z powrotem do tego samego strumienia token (rozpiętości modulo), z wyjątkiem być może `TokenTree: : Group` z ogranicznikami `Delimiter::None` i ujemnymi literałami liczbowymi.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Wyświetla token w postaci wygodnej do debugowania.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Tworzy strumień token zawierający pojedyncze drzewo token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Zbiera kilka drzew token w jeden strumień.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Operacja "flattening" na strumieniach token zbiera drzewa token z wielu strumieni token w jeden strumień.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Użyj zoptymalizowanej implementacji if/when.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Publiczne szczegóły implementacji dla typu `TokenStream`, takie jak iteratory.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Iterator po `TokenTree`s`TokenStream`.
    /// Iteracja to "shallow", np. Iterator nie powtarza się w rozdzielane grupy i zwraca całe grupy jako drzewa token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` akceptuje dowolne tokens i rozwija się do `TokenStream` opisującego dane wejściowe.
/// Na przykład `quote!(a + b)` wygeneruje wyrażenie, które po ocenie tworzy `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Cofanie cudzysłowów odbywa się za pomocą `$` i działa, przyjmując pojedynczy następny ident jako niecytowany termin.
/// Aby zacytować samo `$`, użyj `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Region kodu źródłowego wraz z informacjami o rozszerzaniu makr.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Tworzy nowy `Diagnostic` z podanym `message` na rozpiętości `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Rozpiętość, która jest rozwiązywana w witrynie makr definicji.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Zakres wywołania bieżącego makra proceduralnego.
    /// Identyfikatory utworzone za pomocą tego zakresu zostaną rozwiązane tak, jakby zostały zapisane bezpośrednio w lokalizacji wywołania makra (higiena miejsca wywołania), a inny kod w witrynie wywołania makra również będzie mógł się do nich odwoływać.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Rozpiętość, która reprezentuje higienę `macro_rules`, a czasami jest rozwiązywana w miejscu makra definicji (zmienne lokalne, etykiety, `$crate`), a czasami w miejscu wywołania makra (wszystko inne).
    ///
    /// Lokalizacja zakresu jest pobierana z witryny wywołania.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Oryginalny plik źródłowy, na który wskazuje ten zakres.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` dla tokens w poprzednim rozwinięciu makra, z którego został wygenerowany `self`, jeśli taki istnieje.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Zakres dla kodu źródłowego pochodzenia, z którego został wygenerowany `self`.
    /// Jeśli ten `Span` nie został wygenerowany z innych rozszerzeń makr, wartość zwracana jest taka sama jak `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Pobiera początkowy line/column w pliku źródłowym dla tego zakresu.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Pobiera końcowy line/column w pliku źródłowym dla tego zakresu.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Tworzy nowy zakres obejmujący `self` i `other`.
    ///
    /// Zwraca `None`, jeśli `self` i `other` pochodzą z różnych plików.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Tworzy nowy zakres z tymi samymi informacjami line/column, co `self`, ale rozwiązuje symbole tak, jakby znajdował się w `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Tworzy nowy zakres z tym samym zachowaniem przy rozpoznawaniu nazw, co `self`, ale z informacjami line/column `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Porównuje rozpiętości, aby sprawdzić, czy są równe.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Zwraca tekst źródłowy za zakresem.
    /// Pozwala to zachować oryginalny kod źródłowy, w tym spacje i komentarze.
    /// Zwraca wynik tylko wtedy, gdy rozpiętość odpowiada rzeczywistemu kodowi źródłowemu.
    ///
    /// Note: Obserwowalny wynik makra powinien polegać tylko na tokens, a nie na tym tekście źródłowym.
    ///
    /// Rezultatem tej funkcji jest najlepszy wysiłek, który należy wykorzystać tylko do diagnostyki.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Drukuje zakres w postaci wygodnej do debugowania.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Para wiersz-kolumna reprezentująca początek lub koniec `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Indeksowany 1 wiersz w pliku źródłowym, w którym rozpiętość zaczyna się lub kończy (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Kolumna indeksowana 0 (w znakach UTF-8) w pliku źródłowym, w której zakres zaczyna lub kończy (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Plik źródłowy danego `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Pobiera ścieżkę do tego pliku źródłowego.
    ///
    /// ### Note
    /// Jeśli zakres kodu powiązany z tym `SourceFile` został wygenerowany przez zewnętrzne makro, to makro może nie być rzeczywistą ścieżką w systemie plików.
    /// Użyj [`is_real`], aby sprawdzić.
    ///
    /// Należy również zauważyć, że nawet jeśli `is_real` zwraca `true`, jeśli `--remap-path-prefix` zostało przekazane w wierszu poleceń, podana ścieżka może w rzeczywistości nie być poprawna.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Zwraca `true`, jeśli ten plik źródłowy jest rzeczywistym plikiem źródłowym i nie jest generowany przez rozszerzenie zewnętrznego makra.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Jest to sztuczka do czasu zaimplementowania rozpiętości międzyskrzyniowych i możemy mieć prawdziwe pliki źródłowe dla rozpiętości generowane w zewnętrznych makrach.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Pojedynczy token lub rozdzielona sekwencja drzew token (np. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Strumień token otoczony ogranicznikami nawiasów.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Identyfikator.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Pojedynczy znak interpunkcyjny (" +`, `,`, `$` itd.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Znak literału (`'a'`), ciąg (`"hello"`), numer (`2.3`) itd.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Zwraca zakres tego drzewa, delegując do metody `span` zawartego token lub rozdzielanego strumienia.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfiguruje zakres dla *tylko tego token*.
    ///
    /// Zauważ, że jeśli ten token jest `Group`, to ta metoda nie skonfiguruje zakresu każdego z wewnętrznych tokens, po prostu deleguje do metody `set_span` każdego wariantu.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Wyświetla drzewo token w postaci wygodnej do debugowania.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Każdy z nich ma nazwę w typie struktury w wyprowadzonym debugowaniu, więc nie przejmuj się dodatkową warstwą pośrednią
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// Uwaga, most zapewnia tylko `to_string`, zaimplementuj `fmt::Display` na jego podstawie (odwrotność zwykłej relacji między nimi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Wyświetla drzewo token jako łańcuch, który powinien być bezstratnie konwertowany z powrotem do tego samego drzewa token (rozpiętości modulo), z wyjątkiem być może `TokenTree: : Group` z ogranicznikami `Delimiter::None` i ujemnymi literałami liczbowymi.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Rozdzielany strumień token.
///
/// `Group` zawiera wewnętrznie `TokenStream`, który jest otoczony znakami `Delimiter`.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Opisuje, w jaki sposób rozdzielana jest sekwencja drzew token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Niejawny separator, który może na przykład pojawić się wokół tokens pochodzącego z "macro variable" `$var`.
    /// Ważne jest, aby zachować priorytety operatora w przypadkach takich jak `$var * 3`, gdzie `$var` to `1 + 2`.
    /// Niejawne ograniczniki mogą nie przetrwać obiegu w obie strony strumienia token za pośrednictwem ciągu.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Tworzy nowy `Group` z podanym ogranicznikiem i strumieniem token.
    ///
    /// Ten konstruktor ustawi rozpiętość dla tej grupy na `Span::call_site()`.
    /// Aby zmienić rozpiętość, możesz użyć poniższej metody `set_span`.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Zwraca ogranicznik tego `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Zwraca `TokenStream` z tokens, które są rozdzielane w tym `Group`.
    ///
    /// Zwróć uwagę, że zwrócony strumień token nie zawiera ogranicznika zwróconego powyżej.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Zwraca zakres dla ograniczników tego strumienia token obejmujący cały `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Zwraca zakres wskazujący na ogranicznik otwierający tej grupy.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Zwraca zakres wskazujący na ogranicznik zamykający tej grupy.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfiguruje zakres dla ograniczników tej grupy, ale nie dla jej wewnętrznych tokens.
    ///
    /// Ta metoda **nie** ustawi rozpiętość wszystkich wewnętrznych tokens obejmowanych przez tę grupę, ale raczej ustawi rozpiętość ogranicznika tokens na poziomie `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// Uwaga, most zapewnia tylko `to_string`, zaimplementuj `fmt::Display` na jego podstawie (odwrotność zwykłej relacji między nimi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Wyświetla grupę jako ciąg, który powinien być bezstratnie konwertowany z powrotem do tej samej grupy (rozpiętości modulo), z wyjątkiem być może `TokenTree: : Group` z ogranicznikami `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` to pojedynczy znak interpunkcyjny, taki jak `+`, `-` lub `#`.
///
/// Operatory wieloznakowe, takie jak `+=`, są reprezentowane jako dwa wystąpienia `Punct` z zwróconymi różnymi formami `Spacing`.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Czy po `Punct` następuje bezpośrednio inny `Punct`, czy po nim następuje inny token lub biały znak.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// np. `+` to `Alone` w `+ =`, `+ident` lub `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// np. `+` to `Joint` w `+=` lub `'#`.
    /// Dodatkowo pojedynczy cudzysłów `'` może łączyć się z identyfikatorami w celu utworzenia okresów istnienia `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Tworzy nowy `Punct` na podstawie podanego znaku i odstępu.
    /// Argument `ch` musi być prawidłowym znakiem interpunkcyjnym dozwolonym przez język, w przeciwnym razie funkcja będzie panic.
    ///
    /// Zwrócony `Punct` będzie miał domyślną rozpiętość `Span::call_site()`, którą można dalej skonfigurować za pomocą poniższej metody `set_span`.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Zwraca wartość tego znaku interpunkcyjnego jako `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Zwraca odstępy tego znaku interpunkcyjnego, wskazując, czy bezpośrednio po nim następuje kolejny `Punct` w strumieniu token, więc można je potencjalnie połączyć w operator wieloznakowy (`Joint`), czy też następuje po nim jakiś inny znak token lub biały znak (`Alone`), więc operator z pewnością ma zakończone.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Zwraca zakres dla tego znaku interpunkcyjnego.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Skonfiguruj zakres dla tego znaku interpunkcyjnego.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Uwaga, most zapewnia tylko `to_string`, zaimplementuj `fmt::Display` na jego podstawie (odwrotność zwykłej relacji między nimi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Wyświetla znak interpunkcyjny jako ciąg, który powinien być bezstratnie konwertowany z powrotem na ten sam znak.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Identyfikator (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Tworzy nowe `Ident` z podanym `string` oraz z określonym `span`.
    /// Argument `string` musi być prawidłowym identyfikatorem dozwolonym przez język (łącznie ze słowami kluczowymi, np. `self` lub `fn`).W przeciwnym razie funkcja będzie panic.
    ///
    /// Należy zauważyć, że `span`, obecnie w rustc, konfiguruje informacje higieniczne dla tego identyfikatora.
    ///
    /// Od tego czasu `Span::call_site()` wyraźnie zgadza się na higienę "call-site", co oznacza, że identyfikatory utworzone za pomocą tego zakresu zostaną rozwiązane tak, jakby zostały zapisane bezpośrednio w miejscu wywołania makra, a inny kod w witrynie wywołania makra będzie mógł odnosić się do je również.
    ///
    ///
    /// Późniejsze zakresy, takie jak `Span::def_site()`, umożliwią włączenie higieny "definition-site", co oznacza, że identyfikatory utworzone za pomocą tego zakresu zostaną rozwiązane w miejscu definicji makra, a inny kod w witrynie wywołania makra nie będzie mógł się do nich odwoływać.
    ///
    /// Ze względu na aktualne znaczenie higieny ten konstruktor, w przeciwieństwie do innych tokens, wymaga określenia `Span` na budowie.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// To samo co `Ident::new`, ale tworzy nieprzetworzony identyfikator (`r#ident`).
    /// Argument `string` to poprawny identyfikator dozwolony przez język (w tym słowa kluczowe, np. `fn`).
    /// Słowa kluczowe, których można używać w segmentach ścieżek (np
    /// `self`, `super`) nie są obsługiwane i spowoduje panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Zwraca zakres tego `Ident`, obejmujący cały ciąg zwrócony przez [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfiguruje zakres tego `Ident`, prawdopodobnie zmieniając jego kontekst higieny.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Uwaga, most zapewnia tylko `to_string`, zaimplementuj `fmt::Display` na jego podstawie (odwrotność zwykłej relacji między nimi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Wyświetla identyfikator jako ciąg, który powinien być bezstratny z powrotem do tego samego identyfikatora.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Literał łańcuch (`"hello"`), łańcuch bajtowy (`b"hello"`), znak (`'a'`), znak bajtowy (`b'a'`), liczba całkowita lub zmiennoprzecinkowa z sufiksem lub bez (" 1`, `1u8`, `2.3`, `2.3f32`).
///
/// Literały logiczne, takie jak `true` i `false`, nie należą tutaj, są to " Ident`.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Tworzy nowy literał liczby całkowitej z sufiksem o określonej wartości.
        ///
        /// Ta funkcja utworzy liczbę całkowitą, taką jak `1u32`, w której określona wartość całkowita jest pierwszą częścią token, a całka jest również dodana na końcu.
        /// Literały utworzone z liczb ujemnych mogą nie przetrwać podróży w obie strony przez `TokenStream` lub łańcuchy i mogą zostać podzielone na dwa tokens (`-` i literał dodatni).
        ///
        ///
        /// Literały utworzone za pomocą tej metody mają domyślnie rozpiętość `Span::call_site()`, którą można skonfigurować za pomocą poniższej metody `set_span`.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Tworzy nowy literał liczby całkowitej bez przyrostka o określonej wartości.
        ///
        /// Ta funkcja utworzy liczbę całkowitą, taką jak `1`, w której określona wartość całkowita jest pierwszą częścią token.
        /// Żaden sufiks nie jest określony w tym token, co oznacza, że wywołania takie jak `Literal::i8_unsuffixed(1)` są równoważne z `Literal::u32_unsuffixed(1)`.
        /// Literały utworzone z liczb ujemnych mogą nie przetrwać rountrips do `TokenStream` lub łańcuchów i mogą zostać podzielone na dwa tokens (`-` i literał dodatni).
        ///
        ///
        /// Literały utworzone za pomocą tej metody mają domyślnie rozpiętość `Span::call_site()`, którą można skonfigurować za pomocą poniższej metody `set_span`.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Tworzy nowy niefiksowany literał zmiennoprzecinkowy.
    ///
    /// Ten konstruktor jest podobny do takich jak `Literal::i8_unsuffixed`, w których wartość float jest emitowana bezpośrednio do token, ale nie jest używany żaden sufiks, więc można wywnioskować, że jest to `f64` później w kompilatorze.
    ///
    /// Literały utworzone z liczb ujemnych mogą nie przetrwać rountrips do `TokenStream` lub łańcuchów i mogą zostać podzielone na dwa tokens (`-` i literał dodatni).
    ///
    /// # Panics
    ///
    /// Ta funkcja wymaga, aby określona zmiennoprzecinkowa była skończona, na przykład jeśli jest nieskończoność lub NaN, ta funkcja będzie panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Tworzy nowy literał zmiennoprzecinkowy z sufiksem.
    ///
    /// Ten konstruktor utworzy literał, taki jak `1.0f32`, w którym określona wartość jest poprzednią częścią token, a `f32` jest sufiksem token.
    /// Ten token będzie zawsze wywnioskowany jako `f32` w kompilatorze.
    /// Literały utworzone z liczb ujemnych mogą nie przetrwać rountrips do `TokenStream` lub łańcuchów i mogą zostać podzielone na dwa tokens (`-` i literał dodatni).
    ///
    ///
    /// # Panics
    ///
    /// Ta funkcja wymaga, aby określona zmiennoprzecinkowa była skończona, na przykład jeśli jest nieskończoność lub NaN, ta funkcja będzie panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Tworzy nowy niefiksowany literał zmiennoprzecinkowy.
    ///
    /// Ten konstruktor jest podobny do takich jak `Literal::i8_unsuffixed`, w których wartość float jest emitowana bezpośrednio do token, ale nie jest używany żaden sufiks, więc można wywnioskować, że jest to `f64` później w kompilatorze.
    ///
    /// Literały utworzone z liczb ujemnych mogą nie przetrwać rountrips do `TokenStream` lub łańcuchów i mogą zostać podzielone na dwa tokens (`-` i literał dodatni).
    ///
    /// # Panics
    ///
    /// Ta funkcja wymaga, aby określona zmiennoprzecinkowa była skończona, na przykład jeśli jest nieskończoność lub NaN, ta funkcja będzie panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Tworzy nowy literał zmiennoprzecinkowy z sufiksem.
    ///
    /// Ten konstruktor utworzy literał, taki jak `1.0f64`, w którym określona wartość jest poprzednią częścią token, a `f64` jest sufiksem token.
    /// Ten token będzie zawsze wywnioskowany jako `f64` w kompilatorze.
    /// Literały utworzone z liczb ujemnych mogą nie przetrwać rountrips do `TokenStream` lub łańcuchów i mogą zostać podzielone na dwa tokens (`-` i literał dodatni).
    ///
    ///
    /// # Panics
    ///
    /// Ta funkcja wymaga, aby określona zmiennoprzecinkowa była skończona, na przykład jeśli jest nieskończoność lub NaN, ta funkcja będzie panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Literał ciągu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Dosłowny znak.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Literał ciągu bajtowego.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Zwraca zakres obejmujący ten literał.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfiguruje zakres skojarzony z tym literałem.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Zwraca `Span`, który jest podzbiorem `self.span()` zawierającym tylko bajty źródłowe w zakresie `range`.
    /// Zwraca `None`, jeśli przyszły obcięty zakres znajduje się poza granicami `self`.
    ///
    // FIXME(SergioBenitez): sprawdź, czy zakres bajtów zaczyna się i kończy na granicy UTF-8 źródła.
    // w przeciwnym razie jest prawdopodobne, że panic pojawi się gdzie indziej, gdy drukowany jest tekst źródłowy.
    // FIXME(SergioBenitez): nie ma sposobu, aby użytkownik wiedział, do czego właściwie odwzorowuje `self.span()`, więc ta metoda może być obecnie wywoływana tylko na ślepo.
    // Na przykład `to_string()` dla znaku 'c' zwraca "'\u{63}'";użytkownik nie ma możliwości dowiedzenia się, czy tekstem źródłowym był 'c', czy też '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) coś podobnego do `Option::cloned`, ale dla `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// Uwaga, most zapewnia tylko `to_string`, zaimplementuj `fmt::Display` na jego podstawie (odwrotność zwykłej relacji między nimi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Wyświetla literał jako łańcuch, który powinien być bezstratnie konwertowany z powrotem na ten sam literał (z wyjątkiem możliwego zaokrąglenia dla literałów zmiennoprzecinkowych).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Śledzony dostęp do zmiennych środowiskowych.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Pobierz zmienną środowiskową i dodaj ją do informacji o zależnościach kompilacji.
    /// System kompilacji wykonujący kompilator będzie wiedział, że zmienna została uzyskana podczas kompilacji i będzie w stanie ponownie uruchomić kompilację, gdy wartość tej zmiennej ulegnie zmianie.
    ///
    /// Oprócz śledzenia zależności ta funkcja powinna być równoważna `env::var` z biblioteki standardowej, z tym wyjątkiem, że argumentem musi być UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}