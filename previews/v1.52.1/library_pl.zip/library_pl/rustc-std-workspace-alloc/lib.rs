#![feature(no_core)]
#![no_core]

// Zobacz rustc-std-workspace-core, aby dowiedzieć się, dlaczego ten crate jest potrzebny.

// Zmień nazwę crate, aby uniknąć konfliktu z modułem alokacji w liballoc.
extern crate alloc as foo;

pub use foo::*;