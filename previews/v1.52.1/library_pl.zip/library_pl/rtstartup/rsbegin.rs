// rsbegin.o a rsend.o to tak zwane "compiler runtime startup objects".
// Zawierają kod potrzebny do poprawnego zainicjowania środowiska wykonawczego kompilatora.
//
// Kiedy plik wykonywalny lub obraz dylib jest połączony, cały kod użytkownika i biblioteki są "sandwiched" między tymi dwoma plikami obiektowymi, więc kod lub dane z rsbegin.o stają się pierwsze w odpowiednich sekcjach obrazu, podczas gdy kod i dane z rsend.o stają się ostatnimi.
// Ten efekt może być używany do umieszczania symboli na początku lub na końcu sekcji, a także do wstawiania dowolnych wymaganych nagłówków lub stopek.
//
// Zwróć uwagę, że rzeczywisty punkt wejścia modułu znajduje się w obiekcie startowym środowiska wykonawczego C (zwykle nazywanym `crtX.o`), który następnie wywołuje wywołania zwrotne inicjalizacji innych komponentów środowiska wykonawczego (zarejestrowane za pośrednictwem jeszcze innej specjalnej sekcji obrazu).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Zaznacza początek sekcji informacji o rozwijaniu ramki stosu
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Miejsce na zarysowania dla wewnętrznej księgowości odwijaka.
    // Jest to zdefiniowane jako `struct object` w $ GCC/relax-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Rozwiń informacje o procedurach registration/deregistration.
    // Zobacz dokumentację libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // zarejestruj się rozwiń informacje o uruchomieniu modułu
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // wyrejestruj się przy wyłączaniu
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Rutynowa rejestracja init/uninit specyficzna dla MinGW
    pub mod mingw_init {
        // Obiekty startowe MinGW (crt0.o/dllcrt0.o) będą wywoływać globalne konstruktory w sekcjach .ctors i .dtors podczas uruchamiania i zamykania.
        // W przypadku bibliotek DLL jest to wykonywane, gdy biblioteka DLL jest ładowana i zwalniana.
        //
        // Linker posortuje sekcje, co zapewni, że nasze wywołania zwrotne znajdują się na końcu listy.
        // Ponieważ konstruktory są uruchamiane w odwrotnej kolejności, zapewnia to, że nasze wywołania zwrotne są wykonywane jako pierwsze i ostatnie.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C wywołania zwrotne inicjalizacji
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: wywołania zwrotne dotyczące zakończenia C.
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}