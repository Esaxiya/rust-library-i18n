#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Zawartość nowej pamięci nie jest zainicjowana.
    Uninitialized,
    /// Nowa pamięć jest zerowana.
    Zeroed,
}

/// Narzędzie niskiego poziomu do bardziej ergonomicznego przydzielania, realokacji i zwalniania bufora pamięci na stercie bez martwienia się o wszystkie zaangażowane przypadki narożne.
///
/// Ten typ jest doskonały do tworzenia własnych struktur danych, takich jak Vec i VecDeque.
/// W szczególności:
///
/// * Produkuje `Unique::dangling()` na typach o zerowym rozmiarze.
/// * Tworzy `Unique::dangling()` przy alokacjach o zerowej długości.
/// * Pozwala uniknąć uwolnienia `Unique::dangling()`.
/// * Wyłapuje wszystkie przepełnienia w obliczeniach wydajności (promuje je do "capacity overflow" panics).
/// * Chroni przed 32-bitowymi systemami przydzielającymi więcej niż isize::MAX bajtów.
/// * Chroni przed przepełnieniem.
/// * Wzywa `handle_alloc_error` do omylnych alokacji.
/// * Zawiera `ptr::Unique`, a tym samym zapewnia użytkownikowi wszystkie powiązane korzyści.
/// * Wykorzystuje nadwyżkę zwróconą z alokatora do wykorzystania największej dostępnej przepustowości.
///
/// Ten typ w żaden sposób nie sprawdza pamięci, którą zarządza.Po upuszczeniu *zwolni* swoją pamięć, ale *nie* spróbuje upuścić jej zawartości.
/// Obsługiwanie rzeczywistych rzeczy *przechowywanych* w `RawVec` należy do użytkownika `RawVec`.
///
/// Zauważ, że nadmiar typów o rozmiarze zerowym jest zawsze nieskończony, więc `capacity()` zawsze zwraca `usize::MAX`.
/// Oznacza to, że musisz zachować ostrożność podczas wyzwalania tego typu w obie strony za pomocą `Box<[T]>`, ponieważ `capacity()` nie ustąpi długości.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Dzieje się tak, ponieważ `#[unstable]` `const fn`s nie muszą być zgodne z `min_const_fn`, więc nie można ich również wywołać w`min_const_fn`s.
    ///
    /// Jeśli zmienisz `RawVec<T>::new` lub zależności, uważaj, aby nie wprowadzać niczego, co naprawdę naruszałoby `min_const_fn`.
    ///
    /// NOTE: Moglibyśmy uniknąć tego włamania i sprawdzić zgodność z pewnym atrybutem `#[rustc_force_min_const_fn]`, który wymaga zgodności z `min_const_fn`, ale niekoniecznie pozwala na wywołanie go w `stable(...) const fn`/kod użytkownika nie włączający `foo`, gdy obecny jest `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Tworzy największy możliwy `RawVec` (na stercie systemowej) bez alokacji.
    /// Jeśli `T` ma rozmiar dodatni, wówczas `RawVec` ma pojemność `0`.
    /// Jeśli `T` ma rozmiar zerowy, tworzy `RawVec` o pojemności `usize::MAX`.
    /// Przydatne do wdrażania opóźnionej alokacji.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Tworzy `RawVec` (na stercie systemu) z dokładnie takimi wymaganiami dotyczącymi pojemności i wyrównania jak `[T; capacity]`.
    /// Jest to równoważne wywołaniu `RawVec::new`, gdy `capacity` to `0` lub `T` ma rozmiar zerowy.
    /// Zauważ, że jeśli `T` ma rozmiar zerowy, oznacza to, że *nie* otrzymasz `RawVec` o wymaganej pojemności.
    ///
    /// # Panics
    ///
    /// Panics, jeśli żądana pojemność przekracza `isize::MAX` bajtów.
    ///
    /// # Aborts
    ///
    /// Przerwy na OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Podobnie jak `with_capacity`, ale gwarantuje wyzerowanie bufora.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Odtwarza `RawVec` ze wskaźnika i pojemności.
    ///
    /// # Safety
    ///
    /// `ptr` musi być przydzielony (na stercie systemowej) iz podanym `capacity`.
    /// `capacity` nie może przekraczać `isize::MAX` dla typów o rozmiarze.(dotyczy tylko systemów 32-bitowych).
    /// ZST Wektory Z0Z mogą mieć pojemność do `usize::MAX`.
    /// Jeśli `ptr` i `capacity` pochodzą z `RawVec`, to jest to gwarantowane.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Małe Vecy są głupie.Przejdź do:
    // - 8, jeśli rozmiar elementu wynosi 1, ponieważ każdy alokator sterty prawdopodobnie zaokrągli żądanie mniejsze niż 8 bajtów do co najmniej 8 bajtów.
    //
    // - 4, jeśli elementy są średniej wielkości (<=1 KiB).
    // - 1 w przeciwnym razie, aby uniknąć marnowania zbyt dużej ilości miejsca na bardzo krótkie Vec.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Podobnie jak `new`, ale sparametryzowane przez wybór alokatora dla zwróconego `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` oznacza "unallocated".typy o zerowej wielkości są ignorowane.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Podobnie jak `with_capacity`, ale sparametryzowane przez wybór alokatora dla zwróconego `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Podobnie jak `with_capacity_zeroed`, ale sparametryzowane przez wybór alokatora dla zwróconego `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Konwertuje `Box<[T]>` na `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Konwertuje cały bufor na `Box<[MaybeUninit<T>]>` z określonym `len`.
    ///
    /// Należy pamiętać, że spowoduje to prawidłowe odtworzenie wszelkich zmian `cap`, które mogły zostać wprowadzone.(Zobacz opis typu, aby uzyskać szczegółowe informacje).
    ///
    /// # Safety
    ///
    /// * `len` musi być większa lub równa ostatnio żądanej pojemności, oraz
    /// * `len` musi być mniejsza lub równa `self.capacity()`.
    ///
    /// Należy zauważyć, że żądana pojemność i `self.capacity()` mogą się różnić, ponieważ alokator może nadać alokację i zwrócić większy blok pamięci niż żądany.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sprawdź poczytalność połowy wymogu bezpieczeństwa (nie możemy sprawdzić drugiej połowy).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Unikamy tutaj `unwrap_or_else`, ponieważ zwiększa ilość generowanego IR LLVM.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Odtwarza `RawVec` ze wskaźnika, pojemności i alokatora.
    ///
    /// # Safety
    ///
    /// `ptr` należy zaalokować (przez podany podzielnik `alloc`) iz podanym `capacity`.
    /// `capacity` nie może przekraczać `isize::MAX` dla typów o rozmiarze.
    /// (dotyczy tylko systemów 32-bitowych).
    /// ZST Wektory Z0Z mogą mieć pojemność do `usize::MAX`.
    /// Jeśli `ptr` i `capacity` pochodzą z `RawVec` utworzonego za pomocą `alloc`, to jest to gwarantowane.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Pobiera nieprzetworzony wskaźnik do początku alokacji.
    /// Zauważ, że jest to `Unique::dangling()`, jeśli `capacity == 0` lub `T` ma rozmiar zerowy.
    /// W pierwszym przypadku musisz być ostrożny.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Pobiera pojemność alokacji.
    ///
    /// Będzie to zawsze `usize::MAX`, jeśli `T` ma rozmiar zerowy.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Zwraca współdzielone odniesienie do alokatora wspierającego ten `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Mamy przydzielony fragment pamięci, więc możemy ominąć testy uruchomieniowe, aby uzyskać nasz aktualny układ.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Zapewnia, że bufor zawiera co najmniej wystarczającą ilość miejsca do przechowywania elementów `len + additional`.
    /// Jeśli nie ma jeszcze wystarczającej pojemności, przydzieli wystarczająco dużo miejsca oraz wygodną przestrzeń, aby uzyskać zamortyzowane zachowanie *O*(1).
    ///
    /// Ograniczy to zachowanie, jeśli niepotrzebnie spowodowałoby to panic.
    ///
    /// Jeśli `len` przekracza `self.capacity()`, może to nie przydzielić żądanej przestrzeni.
    /// Nie jest to naprawdę niebezpieczne, ale niebezpieczny kod *który* piszesz, który opiera się na działaniu tej funkcji, może się zepsuć.
    ///
    /// Jest to idealne rozwiązanie do implementacji operacji przesyłania zbiorczego, takiej jak `extend`.
    ///
    /// # Panics
    ///
    /// Panics, jeśli nowa pojemność przekracza `isize::MAX` bajtów.
    ///
    /// # Aborts
    ///
    /// Przerwy na OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezerwa przerwałaby działanie lub wpadła w panikę, gdyby len przekroczyła `isize::MAX`, więc teraz można to bezpiecznie zrobić bez zaznaczenia.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// To samo co `reserve`, ale zwraca po błędach zamiast panikować lub przerywać.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Zapewnia, że bufor zawiera co najmniej wystarczającą ilość miejsca do przechowywania elementów `len + additional`.
    /// Jeśli jeszcze tego nie zrobiono, ponownie przydzieli minimalną możliwą ilość potrzebnej pamięci.
    /// Generalnie będzie to dokładnie taka ilość pamięci, jaka jest potrzebna, ale w zasadzie alokator może oddać więcej, niż prosiliśmy.
    ///
    ///
    /// Jeśli `len` przekracza `self.capacity()`, może to nie przydzielić żądanej przestrzeni.
    /// Nie jest to naprawdę niebezpieczne, ale niebezpieczny kod *który* piszesz, który opiera się na działaniu tej funkcji, może się zepsuć.
    ///
    /// # Panics
    ///
    /// Panics, jeśli nowa pojemność przekracza `isize::MAX` bajtów.
    ///
    /// # Aborts
    ///
    /// Przerwy na OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// To samo co `reserve_exact`, ale zwraca po błędach zamiast panikować lub przerywać.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Zmniejsza alokację do określonej kwoty.
    /// Jeśli podana kwota wynosi 0, w rzeczywistości całkowicie zwalnia.
    ///
    /// # Panics
    ///
    /// Panics, jeśli podana ilość jest *większa* niż aktualna pojemność.
    ///
    /// # Aborts
    ///
    /// Przerwy na OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Zwraca, jeśli bufor musi wzrosnąć, aby spełnić wymaganą dodatkową pojemność.
    /// Używany głównie do tworzenia inliningowych wywołań rezerwowych bez inlining `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ta metoda jest zwykle tworzona wiele razy.Dlatego chcemy, aby był jak najmniejszy, aby skrócić czas kompilacji.
    // Ale chcemy również, aby jak najwięcej jego zawartości było obliczalne statycznie, aby wygenerowany kod działał szybciej.
    // Dlatego ta metoda jest starannie napisana, tak aby cały kod, który zależy od `T`, znajdował się w niej, podczas gdy jak najwięcej kodu, który nie zależy od `T`, znajduje się w funkcjach, które są nieogólne w stosunku do `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Zapewniają to konteksty wywołań.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Ponieważ zwracamy pojemność `usize::MAX`, gdy `elem_size` jest
            // 0, dotarcie tutaj musi koniecznie oznaczać, że `RawVec` jest przepełniony.
            return Err(CapacityOverflow);
        }

        // Niestety, nic nie możemy zrobić z tymi kontrolami.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Gwarantuje to wykładniczy wzrost.
        // Podwojenie nie może się przepełnić, ponieważ `cap <= isize::MAX`, a typ `cap` to `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` nie jest generyczny w porównaniu z `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ograniczenia tej metody są takie same jak w `grow_amortized`, ale ta metoda jest zwykle tworzona rzadziej, więc jest mniej krytyczna.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Ponieważ zwracamy pojemność `usize::MAX`, gdy rozmiar typu to
            // 0, dotarcie tutaj musi koniecznie oznaczać, że `RawVec` jest przepełniony.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` nie jest generyczny w porównaniu z `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ta funkcja jest poza `RawVec`, aby zminimalizować czas kompilacji.Zobacz komentarz powyżej `RawVec::grow_amortized`, aby uzyskać szczegółowe informacje.
// (Parametr `A` nie ma znaczenia, ponieważ liczba różnych typów `A` widziana w praktyce jest znacznie mniejsza niż liczba typów `T`).
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Sprawdź tutaj błąd, aby zminimalizować rozmiar `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Alokator sprawdza równość dopasowania
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Zwalnia pamięć posiadaną przez `RawVec`*bez* próby usunięcia jej zawartości.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Centralna funkcja do obsługi błędów rezerw.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Musimy zagwarantować, co następuje:
// * Nigdy nie przydzielamy obiektów o rozmiarze bajtów `> isize::MAX`.
// * Nie przepełniamy `usize::MAX` i tak naprawdę alokujemy za mało.
//
// W wersji 64-bitowej musimy tylko sprawdzić, czy nie ma przepełnienia, ponieważ próba przydzielenia bajtów `> isize::MAX` z pewnością się nie powiedzie.
// W przypadku wersji 32-bitowej i 16-bitowej musimy dodać do tego dodatkową ochronę na wypadek, gdybyśmy pracowali na platformie, która może wykorzystywać wszystkie 4 GB przestrzeni użytkownika, np. PAE lub x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Jedna centralna funkcja odpowiedzialna za zgłaszanie przepełnień mocy.
// Zapewni to, że generowanie kodu związanego z tymi panics jest minimalne, ponieważ istnieje tylko jedna lokalizacja, w której panics, a nie kilka w całym module.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}