use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Napisanie testu integracji między alokatorami innych firm a `RawVec` jest trochę trudne, ponieważ API `RawVec` nie ujawnia omylnych metod alokacji, więc nie możemy sprawdzić, co się dzieje, gdy alokator jest wyczerpany (poza wykryciem panic).
    //
    //
    // Zamiast tego sprawdza się tylko, czy metody `RawVec` przynajmniej przechodzą przez interfejs API Alokatora, gdy rezerwuje miejsce na dane.
    //
    //
    //
    //
    //

    // Głupi podzielnik, który zużywa określoną ilość paliwa, zanim próby alokacji zaczną kończyć się niepowodzeniem.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (powoduje realokację, a zatem użycie 50 + 150=200 jednostek paliwa)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Po pierwsze, `reserve` alokuje podobnie jak `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 to więcej niż podwojona liczba 7, więc `reserve` powinien działać jak `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 to mniej niż połowa z 12, więc `reserve` musi rosnąć wykładniczo.
        // W chwili pisania tego testu współczynnik wzrostu wynosi 2, więc nowa pojemność to 24, jednak współczynnik wzrostu 1.5 też jest OK.
        //
        // Stąd `>= 18` w asercie.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}