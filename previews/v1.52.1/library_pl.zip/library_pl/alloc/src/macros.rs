/// Tworzy [`Vec`] zawierający argumenty.
///
/// `vec!` pozwala na zdefiniowanie `Vec`s przy użyciu tej samej składni, co wyrażenia tablicowe.
/// Istnieją dwie formy tego makra:
///
/// - Utwórz [`Vec`] zawierający podaną listę elementów:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Utwórz [`Vec`] z danego elementu i rozmiaru:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Zauważ, że w przeciwieństwie do wyrażeń tablicowych ta składnia obsługuje wszystkie elementy, które implementują [`Clone`], a liczba elementów nie musi być stała.
///
/// Spowoduje to użycie `clone` do zduplikowania wyrażenia, więc należy uważać, używając tego z typami o niestandardowej implementacji `Clone`.
/// Na przykład `vec![Rc::new(1);5] `utworzy vector z pięciu odniesień do tej samej wartości całkowitej w ramce, a nie pięciu odniesień wskazujących na liczby całkowite w niezależnych ramkach.
///
///
/// Zwróć również uwagę, że `vec![expr; 0]` jest dozwolone i tworzy pusty vector.
/// To jednak nadal oceni `expr` i natychmiast obniży wynikową wartość, więc pamiętaj o efektach ubocznych.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): W przypadku cfg(test) nieodłączna metoda `[T]::into_vec`, która jest wymagana dla tej definicji makra, nie jest dostępna.
// Zamiast tego użyj funkcji `slice::into_vec`, która jest dostępna tylko z cfg(test) NB, patrz moduł slice::hack w slice.rs, aby uzyskać więcej informacji
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Tworzy `String` przy użyciu interpolacji wyrażeń środowiska uruchomieniowego.
///
/// Pierwszym argumentem, który otrzymuje `format!`, jest łańcuch formatu.Musi to być literał ciągu.Siła ciągu formatującego jest zawarta w `{} 'zawartych.
///
/// Dodatkowe parametry przekazane do `format!` zastępują " {}` w ciągu formatującym w podanej kolejności, chyba że używane są parametry nazwane lub pozycyjne;zobacz [`std::fmt`], aby uzyskać więcej informacji.
///
///
/// Typowym zastosowaniem `format!` jest konkatenacja i interpolacja ciągów.
/// Ta sama konwencja jest używana z makrami [`print!`] i [`write!`], w zależności od zamierzonego przeznaczenia ciągu.
///
/// Aby przekonwertować pojedynczą wartość na ciąg, użyj metody [`to_string`].Spowoduje to użycie formatowania [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics, jeśli implementacja formatująca trait zwróci błąd.
/// Wskazuje to na niepoprawną implementację, ponieważ `fmt::Write for String` sam nigdy nie zwraca błędu.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Zmusić węzeł AST do wyrażenia, aby poprawić diagnostykę w pozycji wzorca.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}