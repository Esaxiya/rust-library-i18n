//! Wskaźniki zliczania odniesień jednowątkowych.'Rc' to skrót od " Reference
//! Counted'.
//!
//! Typ [`Rc<T>`][`Rc`] zapewnia współdzieloną własność wartości typu `T`, przydzielonej na stercie.
//! Wywołanie [`clone`][clone] na [`Rc`] tworzy nowy wskaźnik do tej samej alokacji w stercie.
//! Gdy ostatni wskaźnik [`Rc`] do danej alokacji zostanie zniszczony, wartość przechowywana w tej alokacji (często nazywana "inner value") jest również usuwana.
//!
//! Współdzielone odwołania w Rust domyślnie zabraniają mutacji, a [`Rc`] nie jest wyjątkiem: generalnie nie można uzyskać zmiennego odniesienia do czegoś wewnątrz [`Rc`].
//! Jeśli potrzebujesz zmienności, umieść [`Cell`] lub [`RefCell`] wewnątrz [`Rc`];zobacz [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] wykorzystuje nieatomowe liczenie referencyjne.
//! Oznacza to, że narzut jest bardzo niski, ale [`Rc`] nie może być przesyłany między wątkami, w związku z czym [`Rc`] nie implementuje [`Send`][send].
//! W rezultacie kompilator Rust sprawdzi *w czasie kompilacji*, że nie wysyłasz [`Rc`] s między wątkami.
//! Jeśli potrzebujesz wielowątkowego, atomowego liczenia odwołań, użyj [`sync::Arc`][arc].
//!
//! Metoda [`downgrade`][downgrade] może służyć do tworzenia wskaźnika [`Weak`], który nie jest właścicielem.
//! Wskaźnik [`Weak`] może być [`upgrade`][upgrade] d do [`Rc`], ale zwróci [`None`], jeśli wartość przechowywana w alokacji została już usunięta.
//! Innymi słowy, wskaźniki `Weak` nie utrzymują wartości wewnątrz alokacji przy życiu;jednak *robią* alokację (magazyn zapasowy dla wartości wewnętrznej) przy życiu.
//!
//! Cykl między wskaźnikami [`Rc`] nigdy nie zostanie cofnięty.
//! Z tego powodu [`Weak`] jest używany do przerywania cykli.
//! Na przykład drzewo może mieć silne wskaźniki [`Rc`] od węzłów nadrzędnych do podrzędnych, a wskaźniki [`Weak`] od dzieci do rodziców.
//!
//! `Rc<T>` automatycznie odwołuje się do `T` (przez [`Deref`] trait), więc możesz wywołać metody `T` na wartości typu [`Rc<T>`][`Rc`].
//! Aby uniknąć kolizji nazw z metodami `T`, metody samego [`Rc<T>`][`Rc`] są skojarzonymi funkcjami, wywoływanymi przy użyciu [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>`` implementacje traits, takie jak `Clone`, można również wywołać przy użyciu w pełni kwalifikowanej składni.
//! Niektórzy wolą używać w pełni kwalifikowanej składni, podczas gdy inni wolą używać składni wywołania metody.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Składnia wywołania metody
//! let rc2 = rc.clone();
//! // W pełni kwalifikowana składnia
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] nie dokonuje automatycznego wyłuskiwania `T`, ponieważ wewnętrzna wartość mogła już zostać usunięta.
//!
//! # Klonowanie odniesień
//!
//! Tworzenie nowego odniesienia do tej samej alokacji, co istniejący wskaźnik zliczany odniesienia, odbywa się za pomocą `Clone` trait zaimplementowanego dla [`Rc<T>`][`Rc`] i [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Dwie poniższe składnie są równoważne.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a i b wskazują na to samo miejsce w pamięci co foo.
//! ```
//!
//! Składnia `Rc::clone(&from)` jest najbardziej idiomatyczna, ponieważ wyraźniej przekazuje znaczenie kodu.
//! W powyższym przykładzie składnia ta ułatwia dostrzeżenie, że ten kod tworzy nowe odniesienie, zamiast kopiować całą zawartość foo.
//!
//! # Examples
//!
//! Rozważmy scenariusz, w którym zestaw " gadżetów` jest własnością danego `Owner`.
//! Chcemy, aby nasz " gadżet` odnosił się do ich `Owner`.Nie możemy tego zrobić z unikalną własnością, ponieważ więcej niż jeden gadżet może należeć do tego samego `Owner`.
//! [`Rc`] pozwala nam dzielić `Owner` między wieloma `gadżetami 'i pozostawić `Owner` przydzielony tak długo, jak dowolny punkt `Gadget` na niego.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... inne dziedziny
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... inne dziedziny
//! }
//!
//! fn main() {
//!     // Utwórz `Owner` liczony jako odwołanie.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Utwórz `gadżet należący do `gadget_owner`.
//!     // Klonowanie `Rc<Owner>` daje nam nowy wskaźnik do tej samej alokacji `Owner`, zwiększając liczbę odwołań w procesie.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Usuń naszą lokalną zmienną `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Pomimo upuszczenia `gadget_owner`, nadal jesteśmy w stanie wydrukować nazwę `Owner` z `Gadget`s.
//!     // Dzieje się tak, ponieważ upuściliśmy tylko jeden `Rc<Owner>`, a nie `Owner`, na który wskazuje.
//!     // Dopóki istnieją inne `Rc<Owner>` wskazujące na tę samą alokację `Owner`, pozostanie on aktywny.
//!     // Projekcja pola `gadget1.owner.name` działa, ponieważ `Rc<Owner>` automatycznie odwołuje się do `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Pod koniec funkcji `gadget1` i `gadget2` są niszczone, a wraz z nimi ostatnie zliczone odniesienia do naszego `Owner`.
//!     // Gadget Man również zostaje zniszczony.
//!     //
//! }
//! ```
//!
//! Jeśli zmienią się nasze wymagania i będziemy musieli być w stanie przejść od `Owner` do `Gadget`, napotkamy problemy.
//! Wskaźnik [`Rc`] od `Owner` do `Gadget` wprowadza cykl.
//! Oznacza to, że ich liczba referencyjna nigdy nie osiągnie 0, a alokacja nigdy nie zostanie zniszczona:
//! wyciek pamięci.Aby to obejść, możemy użyć wskaźników [`Weak`].
//!
//! Rust w rzeczywistości utrudnia utworzenie tej pętli w pierwszej kolejności.Aby otrzymać dwie wartości, które wskazują na siebie, jedna z nich musi być zmienna.
//! Jest to trudne, ponieważ [`Rc`] wymusza bezpieczeństwo pamięci, udostępniając tylko wspólne odniesienia do opakowanej wartości, a te nie pozwalają na bezpośrednią mutację.
//! Musimy zawinąć część wartości, którą chcemy zmutować, w [`RefCell`], co zapewnia *wewnętrzną zmienność*: metodę osiągnięcia zmienności poprzez wspólne odniesienie.
//! [`RefCell`] wymusza zasady wypożyczania Rust w czasie wykonywania.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... inne dziedziny
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... inne dziedziny
//! }
//!
//! fn main() {
//!     // Utwórz `Owner` liczony jako odwołanie.
//!     // Zwróć uwagę, że umieściliśmy vector `Owner`s of`Gadget`s wewnątrz `RefCell`, abyśmy mogli go zmodyfikować za pomocą współdzielonego odniesienia.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Utwórz `gadżet należący do `gadget_owner`, jak poprzednio.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Dodaj " gadżety` do ich `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dynamiczne pożyczanie kończy się tutaj.
//!     }
//!
//!     // Iteruj po naszych `Gadżetach`, drukując ich szczegóły.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` to `Weak<Gadget>`.
//!         // Ponieważ wskaźniki `Weak` nie mogą zagwarantować, że alokacja nadal istnieje, musimy wywołać `upgrade`, który zwraca `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // W tym przypadku wiemy, że alokacja nadal istnieje, więc po prostu `unwrap` `Option`.
//!         // W bardziej skomplikowanym programie możesz potrzebować wdzięcznej obsługi błędów dla wyniku `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Pod koniec funkcji `gadget_owner`, `gadget1` i `gadget2` są niszczone.
//!     // Nie ma teraz silnych wskaźników (`Rc`) do gadżetów, więc są one niszczone.
//!     // To zeruje liczbę odniesień na Gadget Man, więc on również zostaje zniszczony.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Jest to od repr(C) do future odporne na ewentualne zmiany kolejności w terenie, które mogłyby kolidować z bezpiecznym [into|from]_raw() transmutowalnych typów wewnętrznych.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Wskaźnik zliczania odwołań jednowątkowych.'Rc' to skrót od " Reference
/// Counted'.
///
/// Zobacz [module-level documentation](./index.html), aby uzyskać więcej informacji.
///
/// Nieodłącznymi metodami `Rc` są wszystkie powiązane funkcje, co oznacza, że musisz nazywać je np. [`Rc::get_mut(&mut value)`][get_mut] zamiast `value.get_mut()`.
/// Pozwala to uniknąć konfliktów z metodami typu wewnętrznego `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // To zagrożenie jest w porządku, ponieważ podczas gdy ten RC jest aktywny, mamy gwarancję, że wewnętrzny wskaźnik jest prawidłowy.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Konstruuje nowy `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Istnieje niejawny słaby wskaźnik należący do wszystkich silnych wskaźników, który zapewnia, że słaby destruktor nigdy nie zwalnia alokacji podczas działania silnego destruktora, nawet jeśli słaby wskaźnik jest przechowywany w silnym.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Konstruuje nowy `Rc<T>`, używając słabego odniesienia do samego siebie.
    /// Próba zaktualizowania słabego odwołania przed zwróceniem tej funkcji spowoduje wyświetlenie wartości `None`.
    ///
    /// Jednak słabe odniesienie można swobodnie klonować i przechowywać do wykorzystania w późniejszym czasie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... więcej pól
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Skonstruuj wewnętrzną w stanie "uninitialized" z pojedynczym słabym odniesieniem.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Ważne jest, abyśmy nie rezygnowali z własności słabego wskaźnika, w przeciwnym razie pamięć może zostać zwolniona do czasu powrotu `data_fn`.
        // Gdybyśmy naprawdę chcieli przekazać własność, moglibyśmy stworzyć dla siebie dodatkowy słaby wskaźnik, ale spowodowałoby to dodatkowe aktualizacje słabej liczby odwołań, które w przeciwnym razie mogłyby nie być konieczne.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Silne odwołania powinny wspólnie posiadać wspólne słabe odniesienie, więc nie uruchamiaj destruktora dla naszego starego słabego odniesienia.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruuje nowy `Rc` z niezainicjowaną zawartością.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odroczona inicjalizacja:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruuje nowy `Rc` z niezainicjowaną zawartością, z pamięcią wypełnioną `0` bajtami.
    ///
    ///
    /// Zobacz [`MaybeUninit::zeroed`][zeroed], aby zapoznać się z przykładami prawidłowego i nieprawidłowego użycia tej metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruuje nowy `Rc<T>`, zwracając błąd, jeśli alokacja się nie powiedzie
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Istnieje niejawny słaby wskaźnik należący do wszystkich silnych wskaźników, który zapewnia, że słaby destruktor nigdy nie zwalnia alokacji podczas działania silnego destruktora, nawet jeśli słaby wskaźnik jest przechowywany w silnym.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Konstruuje nowy `Rc` z niezainicjowaną zawartością, zwracając błąd, jeśli alokacja się nie powiedzie
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Odroczona inicjalizacja:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruuje nowy `Rc` z niezainicjowaną zawartością, z pamięcią wypełnioną bajtami `0`, zwracając błąd, jeśli alokacja się nie powiedzie
    ///
    ///
    /// Zobacz [`MaybeUninit::zeroed`][zeroed], aby zapoznać się z przykładami prawidłowego i nieprawidłowego użycia tej metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Konstruuje nowy `Pin<Rc<T>>`.
    /// Jeśli `T` nie implementuje `Unpin`, `value` zostanie przypięty do pamięci i nie będzie można go przenieść.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Zwraca wartość wewnętrzną, jeśli `Rc` ma dokładnie jedną silną referencję.
    ///
    /// W przeciwnym razie zwracany jest [`Err`] z tym samym `Rc`, który został przekazany.
    ///
    ///
    /// To się powiedzie, nawet jeśli istnieją wybitne słabe odniesienia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // skopiuj zawarty obiekt

                // Wskaż słabym, że nie można ich promować, zmniejszając silną liczbę, a następnie usuń niejawny wskaźnik "strong weak", jednocześnie obsługując logikę upuszczania, po prostu tworząc fałszywą słabość.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Konstruuje nowy wycinek zliczoną jako odwołanie z niezainicjowaną zawartością.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odroczona inicjalizacja:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Konstruuje nowy wycinek zliczany jako odniesienie z niezainicjowaną zawartością, z pamięcią wypełnioną `0` bajtów.
    ///
    ///
    /// Zobacz [`MaybeUninit::zeroed`][zeroed], aby zapoznać się z przykładami prawidłowego i nieprawidłowego użycia tej metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Konwertuje na `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Podobnie jak w przypadku [`MaybeUninit::assume_init`], wywołujący musi zagwarantować, że wartość wewnętrzna rzeczywiście jest w stanie zainicjowanym.
    ///
    /// Wywołanie tego, gdy zawartość nie jest jeszcze w pełni zainicjowana, powoduje natychmiastowe niezdefiniowane zachowanie.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odroczona inicjalizacja:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Konwertuje na `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Podobnie jak w przypadku [`MaybeUninit::assume_init`], wywołujący musi zagwarantować, że wartość wewnętrzna rzeczywiście jest w stanie zainicjowanym.
    ///
    /// Wywołanie tego, gdy zawartość nie jest jeszcze w pełni zainicjowana, powoduje natychmiastowe niezdefiniowane zachowanie.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odroczona inicjalizacja:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Zużywa `Rc`, zwracając opakowany wskaźnik.
    ///
    /// Aby uniknąć wycieku pamięci, wskaźnik musi zostać przekonwertowany z powrotem na `Rc` przy użyciu [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Zapewnia nieprzetworzony wskaźnik do danych.
    ///
    /// Liczby nie ulegają zmianie w żaden sposób, a `Rc` nie jest zużywany.
    /// Wskaźnik jest ważny tak długo, jak długo istnieją silne liczniki w `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // BEZPIECZEŃSTWO: To nie może przejść przez Deref::deref lub Rc::inner, ponieważ
        // jest to wymagane, aby zachować pochodzenie raw/mut w taki sposób, że np
        // `get_mut` może pisać przez wskaźnik po odzyskaniu Rc przez `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Konstruuje `Rc<T>` z surowego wskaźnika.
    ///
    /// Nieprzetworzony wskaźnik musiał zostać wcześniej zwrócony przez wywołanie [`Rc<U>::into_raw`][into_raw], gdzie `U` musi mieć taki sam rozmiar i wyrównanie jak `T`.
    /// Jest to trywialnie prawdziwe, jeśli `U` to `T`.
    /// Zauważ, że jeśli `U` nie jest `T`, ale ma ten sam rozmiar i wyrównanie, jest to w zasadzie jak transmutowanie odniesień różnych typów.
    /// Zobacz [`mem::transmute`][transmute], aby uzyskać więcej informacji na temat ograniczeń obowiązujących w tym przypadku.
    ///
    /// Użytkownik `from_raw` musi upewnić się, że określona wartość `T` zostanie usunięta tylko raz.
    ///
    /// Ta funkcja jest niebezpieczna, ponieważ niewłaściwe użycie może prowadzić do zagrożenia pamięci, nawet jeśli nigdy nie uzyskano dostępu do zwróconego `Rc<T>`.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konwertuj z powrotem na `Rc`, aby zapobiec wyciekom.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Dalsze wywołania `Rc::from_raw(x_ptr)` byłyby niebezpieczne dla pamięci.
    /// }
    ///
    /// // Pamięć została zwolniona, gdy `x` wyszedł poza zakres powyżej, więc `x_ptr` teraz zwisa!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Odwróć przesunięcie, aby znaleźć oryginalny RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Tworzy nowy wskaźnik [`Weak`] do tej alokacji.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Upewnij się, że nie utworzymy wiszącego słabego
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Pobiera liczbę wskaźników [`Weak`] do tej alokacji.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Pobiera liczbę silnych wskaźników (`Rc`) do tej alokacji.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Zwraca `true`, jeśli nie ma innych wskaźników `Rc` lub [`Weak`] do tej alokacji.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Zwraca zmienne odniesienie do podanego `Rc`, jeśli nie ma innych wskaźników `Rc` lub [`Weak`] do tej samej alokacji.
    ///
    ///
    /// W przeciwnym razie zwraca [`None`], ponieważ nie jest bezpieczna zmiana wartości współdzielonej.
    ///
    /// Zobacz także [`make_mut`][make_mut], co spowoduje [`clone`][clone] wartość wewnętrzną, gdy istnieją inne wskaźniki.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Zwraca zmienną referencję do podanego `Rc`, bez żadnego sprawdzenia.
    ///
    /// Zobacz także [`get_mut`], który jest bezpieczny i przeprowadza odpowiednie kontrole.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Żadnych innych wskaźników `Rc` lub [`Weak`] do tej samej alokacji nie można wyłuskiwać na czas trwania zwróconej pożyczki.
    ///
    /// Jest to trywialne w przypadku, gdy nie ma takich wskaźników, na przykład bezpośrednio po `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Uważamy, aby *nie* tworzyć odniesienia obejmującego pola "count", ponieważ spowodowałoby to konflikt z dostępem do liczników odwołań (np.
        // przez `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Zwraca `true`, jeśli dwa " Rc` wskazują na tę samą alokację (w stylu podobnym do [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Tworzy zmienne odniesienie do danego `Rc`.
    ///
    /// Jeśli istnieją inne wskaźniki `Rc` do tej samej alokacji, `make_mut` [`clone`] dokona [`clone`] wewnętrznej wartości do nowej alokacji, aby zapewnić unikalną własność.
    /// Nazywa się to również klonowaniem przy zapisie.
    ///
    /// Jeśli nie ma innych wskaźników `Rc` do tej alokacji, wówczas wskaźniki [`Weak`] do tej alokacji zostaną odłączone.
    ///
    /// Zobacz także [`get_mut`], który zakończy się niepowodzeniem zamiast klonowania.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Niczego nie sklonuje
    /// let mut other_data = Rc::clone(&data);    // Nie klonuje danych wewnętrznych
    /// *Rc::make_mut(&mut data) += 1;        // Klonuje dane wewnętrzne
    /// *Rc::make_mut(&mut data) += 1;        // Niczego nie sklonuje
    /// *Rc::make_mut(&mut other_data) *= 2;  // Niczego nie sklonuje
    ///
    /// // Teraz `data` i `other_data` wskazują na różne alokacje.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] wskaźniki zostaną odłączone:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Muszę sklonować dane, są inne Rcs.
            // Wstępnie przydziel pamięć, aby umożliwić bezpośrednie zapisywanie sklonowanej wartości.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Może po prostu ukraść dane, wszystko, co zostało, to słabe
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Usuń ukryty silny-słaby ref (nie ma potrzeby tworzenia fałszywego Słabego tutaj-wiemy, że inne Słabe mogą nam posprzątać)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // To zagrożenie jest w porządku, ponieważ mamy gwarancję, że zwrócony wskaźnik jest *jedynym* wskaźnikiem, który kiedykolwiek zostanie zwrócony do T.
        // Nasza liczba referencji na tym etapie jest gwarantowana na 1, a sam `Rc<T>` wymagał, aby był `mut`, więc zwracamy jedyne możliwe odniesienie do alokacji.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Spróbuj obniżyć `Rc<dyn Any>` do konkretnego typu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Przydziela `RcBox<T>` z wystarczającą ilością miejsca na potencjalnie niewymiarową wartość wewnętrzną, jeśli wartość ma podany układ.
    ///
    /// Funkcja `mem_to_rcbox` jest wywoływana ze wskaźnikiem danych i musi zwrócić (potencjalnie gruby) wskaźnik dla `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Oblicz układ przy użyciu podanego układu wartości.
        // Wcześniej układ był obliczany na podstawie wyrażenia `&*(ptr as* const RcBox<T>)`, ale powodowało to nieprawidłowe odniesienie (patrz #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Przydziela `RcBox<T>` z wystarczającą ilością miejsca na prawdopodobnie nietypową wartość wewnętrzną, w której wartość ma podany układ, zwracając błąd, jeśli alokacja nie powiedzie się.
    ///
    ///
    /// Funkcja `mem_to_rcbox` jest wywoływana ze wskaźnikiem danych i musi zwrócić (potencjalnie gruby) wskaźnik dla `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Oblicz układ przy użyciu podanego układu wartości.
        // Wcześniej układ był obliczany na podstawie wyrażenia `&*(ptr as* const RcBox<T>)`, ale powodowało to nieprawidłowe odniesienie (patrz #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Przydziel dla układu.
        let ptr = allocate(layout)?;

        // Zainicjuj plik RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Przydziela `RcBox<T>` z wystarczającą ilością miejsca na wewnętrzną wartość bez rozmiaru
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Przydziel dla `RcBox<T>` przy użyciu podanej wartości.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Skopiuj wartość jako bajty
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Zwolnij przydział bez upuszczania jego zawartości
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Przydziela `RcBox<[T]>` o podanej długości.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Skopiuj elementy z plasterka do nowo przydzielonego Rc <\[T\]>
    ///
    /// Niebezpieczne, ponieważ dzwoniący musi albo przejąć własność, albo powiązać `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Konstruuje `Rc<[T]>` z iteratora, o którym wiadomo, że ma określony rozmiar.
    ///
    /// Zachowanie jest nieokreślone, jeśli rozmiar jest nieprawidłowy.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic chroni podczas klonowania elementów T.
        // W przypadku panic elementy, które zostały zapisane w nowym RcBox zostaną usunięte, a następnie pamięć zwolniona.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Wskaźnik do pierwszego elementu
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Wszystko jasne.Zapomnij o strażniku, aby nie zwolnił nowego RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specjalizacja trait używana dla `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Upuszcza `Rc`.
    ///
    /// Spowoduje to zmniejszenie liczby silnych odniesień.
    /// Jeśli liczba silnych odniesień osiągnie zero, wówczas jedynymi innymi odniesieniami (jeśli istnieją) są [`Weak`], więc `drop` jest wartością wewnętrzną.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Nic nie drukuje
    /// drop(foo2);   // Drukuje "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // zniszczyć zawarty obiekt
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // usuń ukryty wskaźnik "strong weak" teraz, gdy zniszczyliśmy zawartość.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Tworzy klon wskaźnika `Rc`.
    ///
    /// Tworzy to kolejny wskaźnik do tej samej alokacji, zwiększając liczbę silnych odwołań.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Tworzy nowy `Rc<T>` z wartością `Default` dla `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack, aby umożliwić specjalizację na `Eq`, mimo że `Eq` ma metodę.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Robimy tę specjalizację tutaj, a nie jako bardziej ogólną optymalizację na `&T`, ponieważ w przeciwnym razie dodałoby to koszt do wszystkich sprawdzeń równości w referencjach.
/// Zakładamy, że `Rc` są używane do przechowywania dużych wartości, które są powolne do klonowania, ale także trudne do sprawdzenia pod kątem równości, co powoduje, że ten koszt łatwiej się opłaca.
///
/// Bardziej prawdopodobne jest również istnienie dwóch klonów `Rc`, które wskazują na tę samą wartość, niż dwa znaki " &T`.
///
/// Możemy to zrobić tylko wtedy, gdy `T: Eq` jako `PartialEq` może celowo nie działać odruchowo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Równość dla dwóch " Rc`.
    ///
    /// Dwa `Rc` są równe, jeśli ich wewnętrzne wartości są równe, nawet jeśli są przechowywane w różnych alokacjach.
    ///
    /// Jeśli `T` również implementuje `Eq` (implikując refleksyjność równości), dwa " Rc`, które wskazują na tę samą alokację, są zawsze równe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Nierówność dla dwóch " Rc`.
    ///
    /// Dwa `Rc` są nierówne, jeśli ich wewnętrzne wartości są nierówne.
    ///
    /// Jeśli `T` również implementuje `Eq` (implikując refleksyjność równości), dwa " Rc`, które wskazują na tę samą alokację, nigdy nie są nierówne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Częściowe porównanie dla dwóch " Rc`.
    ///
    /// Porównuje się je, wywołując `partial_cmp()` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mniejsze niż porównanie dla dwóch `Rc`.
    ///
    /// Porównuje się je, wywołując `<` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Porównanie " Mniejsze lub równe`dla dwóch " Rc`.
    ///
    /// Porównuje się je, wywołując `<=` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Porównanie większe niż dla dwóch " Rc`.
    ///
    /// Porównuje się je, wywołując `>` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Porównanie " Większe lub równe`dla dwóch " Rc`.
    ///
    /// Porównuje się je, wywołując `>=` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Porównanie dla dwóch " Rc`.
    ///
    /// Porównuje się je, wywołując `cmp()` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Przydziel wycinek zliczany jako odniesienie i wypełnij go, klonując elementy " v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Przydziel kawałek łańcucha liczony jako odniesienie i skopiuj do niego `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Przydziel kawałek łańcucha liczony jako odniesienie i skopiuj do niego `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Przenieś obiekt w ramce do nowej alokacji zliczonej referencji.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Przydziel wycinek zliczany w odniesieniu do referencji i przenieś do niego elementy " v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Pozwól Vek uwolnić pamięć, ale nie niszcz jej zawartości
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Pobiera każdy element z `Iterator` i gromadzi go w `Rc<[T]>`.
    ///
    /// # Charakterystyka wydajności
    ///
    /// ## Ogólny przypadek
    ///
    /// W ogólnym przypadku zbieranie danych do `Rc<[T]>` odbywa się najpierw poprzez gromadzenie danych do `Vec<T>`.Oznacza to, że pisząc:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// zachowuje się tak, jakbyśmy napisali:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Tutaj odbywa się pierwszy zestaw przydziałów.
    ///     .into(); // Tutaj następuje drugi przydział dla `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Spowoduje to alokację tyle razy, ile potrzeba do skonstruowania `Vec<T>`, a następnie przydzieli raz na przekształcenie `Vec<T>` w `Rc<[T]>`.
    ///
    ///
    /// ## Iteratory o znanej długości
    ///
    /// Kiedy `Iterator` implementuje `TrustedLen` i ma dokładny rozmiar, zostanie dokonana pojedyncza alokacja dla `Rc<[T]>`.Na przykład:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Tutaj odbywa się tylko jeden przydział.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specjalizacja trait używana do zbierania do `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Tak jest w przypadku iteratora `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BEZPIECZEŃSTWO: Musimy upewnić się, że iterator ma dokładną długość i tak jest.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Wróć do normalnej implementacji.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` jest wersją [`Rc`], która zawiera odniesienie do zarządzanej alokacji, które nie jest właścicielem.Dostęp do alokacji uzyskuje się przez wywołanie [`upgrade`] na wskaźniku `Weak`, który zwraca [`Option`]`<`[`Rc`] `<T>>`.
///
/// Ponieważ odwołanie `Weak` nie jest wliczane do własności, nie zapobiega to porzuceniu wartości przechowywanej w alokacji, a sam `Weak` nie gwarantuje, że wartość nadal będzie obecna.
/// Dlatego może zwrócić [`None`], gdy [`upgrade`] d.
/// Należy jednak zauważyć, że odwołanie `Weak`*nie* zapobiega cofnięciu alokacji (magazynu zapasowego).
///
/// Wskaźnik `Weak` jest przydatny do przechowywania tymczasowego odniesienia do alokacji zarządzanej przez [`Rc`] bez zapobiegania porzuceniu jego wewnętrznej wartości.
/// Służy również do zapobiegania cyklicznym odwołaniom między wskaźnikami [`Rc`], ponieważ odniesienia do wzajemnego posiadania nigdy nie pozwolą na usunięcie [`Rc`].
/// Na przykład drzewo może mieć silne wskaźniki [`Rc`] od węzłów nadrzędnych do podrzędnych, a wskaźniki `Weak` od dzieci do rodziców.
///
/// Typowym sposobem uzyskania wskaźnika `Weak` jest wywołanie [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // To jest `NonNull`, aby umożliwić optymalizację tego typu w wyliczeniach, ale niekoniecznie jest to prawidłowy wskaźnik.
    //
    // `Weak::new` ustawia to na `usize::MAX`, aby nie musiał przydzielać miejsca na stercie.
    // To nie jest wartość, jaką kiedykolwiek będzie miał prawdziwy wskaźnik, ponieważ RcBox ma wyrównanie co najmniej 2.
    // Jest to możliwe tylko wtedy, gdy `T: Sized`;nietypowy `T` nigdy nie zwisa.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Konstruuje nowy `Weak<T>` bez przydzielania pamięci.
    /// Wywołanie [`upgrade`] na zwracanej wartości zawsze daje [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Typ pomocnika, aby umożliwić dostęp do liczników odwołań bez dokonywania jakichkolwiek potwierdzeń dotyczących pola danych.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Zwraca nieprzetworzony wskaźnik do obiektu `T` wskazywanego przez ten `Weak<T>`.
    ///
    /// Wskaźnik jest poprawny tylko wtedy, gdy istnieją silne odniesienia.
    /// Wskaźnik może być wiszący, niewyrównany lub w przeciwnym razie nawet [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Obie wskazują ten sam obiekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Silny tutaj utrzymuje go przy życiu, więc nadal możemy uzyskać dostęp do obiektu.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ale już nie.
    /// // Możemy zrobić weak.as_ptr(), ale dostęp do wskaźnika prowadziłby do nieokreślonego zachowania.
    /// // assert_eq! ("witaj", niebezpieczne {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Jeśli wskaźnik się wisi, zwracamy bezpośrednio wartownika.
            // Nie może to być prawidłowy adres ładunku, ponieważ ładunek jest co najmniej tak wyrównany, jak RcBox (usize).
            ptr as *const T
        } else {
            // BEZPIECZEŃSTWO: jeśli is_dangling zwraca false, to wskaźnik można wyłuskać.
            // W tym momencie ładunek może zostać upuszczony i musimy zachować pochodzenie, więc użyj surowej manipulacji wskaźnikiem.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Zużywa `Weak<T>` i zamienia go w surowy wskaźnik.
    ///
    /// To konwertuje słaby wskaźnik do surowego wskaźnika, zachowując jednocześnie własność jednego słabego odniesienia (słaba liczba nie jest modyfikowana przez tę operację).
    /// Można go przekształcić z powrotem w `Weak<T>` za pomocą [`from_raw`].
    ///
    /// Obowiązują te same ograniczenia dostępu do celu wskaźnika, jak w przypadku [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konwertuje nieprzetworzony wskaźnik utworzony wcześniej przez [`into_raw`] z powrotem na `Weak<T>`.
    ///
    /// Można to wykorzystać do bezpiecznego uzyskania silnego odniesienia (wywołując później [`upgrade`]) lub do zwolnienia słabej liczby, upuszczając `Weak<T>`.
    ///
    /// Przejmuje na własność jedno słabe odniesienie (z wyjątkiem wskaźników utworzonych przez [`new`], ponieważ one niczego nie posiadają; metoda nadal na nich działa).
    ///
    /// # Safety
    ///
    /// Wskaźnik musi pochodzić z [`into_raw`] i nadal musi posiadać swoje potencjalne słabe odniesienie.
    ///
    /// Dopuszczalne jest, aby silna liczba wynosiła 0 w momencie wywołania tego.
    /// Niemniej jednak przejmuje to na własność jedno słabe odniesienie, które jest obecnie reprezentowane jako nieprzetworzony wskaźnik (słaba liczba nie jest modyfikowana przez tę operację) i dlatego musi być sparowana z poprzednim wywołaniem [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Zmniejsz ostatnią słabą liczbę.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Zobacz Weak::as_ptr, aby zapoznać się z kontekstem, w jaki sposób wyprowadzany jest wskaźnik wejściowy.

        let ptr = if is_dangling(ptr as *mut T) {
            // To jest wiszący Słaby.
            ptr as *mut RcBox<T>
        } else {
            // W przeciwnym razie mamy gwarancję, że wskaźnik pochodzi od nieplączącego się słabego.
            // BEZPIECZEŃSTWO: data_offset jest bezpieczna do wywołania, ponieważ ptr odwołuje się do rzeczywistego (potencjalnie upuszczonego) T.
            let offset = unsafe { data_offset(ptr) };
            // W ten sposób odwracamy przesunięcie, aby uzyskać cały RcBox.
            // BEZPIECZEŃSTWO: wskaźnik pochodzi ze słabego, więc to przesunięcie jest bezpieczne.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // BEZPIECZEŃSTWO: odzyskaliśmy oryginalny wskaźnik słabych, więc możemy stworzyć słabe.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Próbuje uaktualnić wskaźnik `Weak` do [`Rc`], opóźniając upuszczenie wartości wewnętrznej, jeśli się powiedzie.
    ///
    ///
    /// Zwraca [`None`], jeśli wartość wewnętrzna została od tego czasu usunięta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Zniszcz wszystkie silne wskazówki.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Pobiera liczbę silnych wskaźników (`Rc`) wskazujących na tę alokację.
    ///
    /// Jeśli `self` został utworzony przy użyciu [`Weak::new`], zwróci to 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Pobiera liczbę wskaźników `Weak` wskazujących na tę alokację.
    ///
    /// Jeśli nie pozostaną żadne silne wskazówki, zwróci to zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // odejmij niejawny słaby ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Zwraca `None`, gdy wskaźnik zwisa i nie ma przydzielonego `RcBox` (tj. Kiedy ten `Weak` został utworzony przez `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Uważamy, aby *nie* utworzyć odniesienia obejmującego pole "data", ponieważ pole może być jednocześnie mutowane (na przykład, jeśli ostatnie `Rc` zostanie usunięte, pole danych zostanie usunięte w miejscu).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Zwraca `true`, jeśli dwa " Słabe` wskazują na tę samą alokację (podobnie jak w [`ptr::eq`]) lub jeśli oba nie wskazują na żadną alokację (ponieważ zostały utworzone za pomocą `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Ponieważ porównuje to wskaźniki, oznacza to, że `Weak::new()` będą sobie równe, nawet jeśli nie wskazują na żadną alokację.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Porównanie `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Upuszcza wskaźnik `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nic nie drukuje
    /// drop(foo);        // Drukuje "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // słaby licznik zaczyna się od 1 i spadnie do zera tylko wtedy, gdy wszystkie silne wskazówki znikną.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Tworzy klon wskaźnika `Weak`, który wskazuje na tę samą alokację.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruuje nowy `Weak<T>`, alokując pamięć dla `T` bez inicjowania go.
    /// Wywołanie [`upgrade`] na zwracanej wartości zawsze daje [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Sprawdziliśmy_dodaj tutaj, aby bezpiecznie radzić sobie z mem::forget.W szczególności
// jeśli masz mem::forget Rcs (lub Weaks), licznik ref może się przepełnić, a następnie możesz zwolnić alokację, gdy istnieją zaległe Rcs (lub Weaks).
//
// Przerywamy, ponieważ jest to tak zdegenerowany scenariusz, że nie obchodzi nas, co się stanie-żaden prawdziwy program nie powinien nigdy tego doświadczyć.
//
// Powinno to mieć znikomy narzut, ponieważ w rzeczywistości nie musisz ich klonować w Rust dzięki własności i semantyce przenoszenia.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Chcemy przerwać działanie przy przepełnieniu zamiast porzucać wartość.
        // Liczba odwołań nigdy nie będzie wynosić zero, gdy zostanie wywołana;
        // niemniej jednak wstawiamy tutaj przerwanie, aby wskazać LLVM na brakującą optymalizację.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Chcemy przerwać działanie przy przepełnieniu zamiast porzucać wartość.
        // Liczba odwołań nigdy nie będzie wynosić zero, gdy zostanie wywołana;
        // niemniej jednak wstawiamy tutaj przerwanie, aby wskazać LLVM na brakującą optymalizację.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Uzyskaj przesunięcie w `RcBox` dla ładunku znajdującego się za wskaźnikiem.
///
/// # Safety
///
/// Wskaźnik musi wskazywać (i mieć prawidłowe metadane) na poprzednio prawidłowe wystąpienie T, ale T może zostać usunięta.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Wyrównaj wartość bez rozmiaru do końca RcBox.
    // Ponieważ RcBox to repr(C), zawsze będzie to ostatnie pole w pamięci.
    // BEZPIECZEŃSTWO: ponieważ jedynymi możliwymi typami bez rozmiaru są plasterki, obiekty trait,
    // i extern, wymaganie bezpieczeństwa wejścia jest obecnie wystarczające, aby spełnić wymagania align_of_val_raw;jest to szczegół implementacji języka, na którym nie można polegać poza std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}