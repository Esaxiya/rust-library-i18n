use core::intrinsics;
use core::mem;
use core::ptr;

/// Zastępuje to wartość znajdującą się za unikalnym odwołaniem `v` przez wywołanie odpowiedniej funkcji.
///
///
/// Jeśli w zamknięciu `change` wystąpi panic, cały proces zostanie przerwany.
#[allow(dead_code)] // zachować jako ilustrację i do użycia w future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Zastępuje wartość znajdującą się za unikalnym odwołaniem `v` przez wywołanie odpowiedniej funkcji i zwraca wynik uzyskany po drodze.
///
///
/// Jeśli w zamknięciu `change` wystąpi panic, cały proces zostanie przerwany.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}