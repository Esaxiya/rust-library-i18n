use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Dołącza wszystkie pary klucz-wartość z unii dwóch rosnących iteratorów, zwiększając po drodze zmienną `length`.Ta ostatnia ułatwia dzwoniącemu uniknięcie wycieku, gdy osoba obsługująca upuszczenie wpada w panikę.
    ///
    /// Jeśli oba iteratory wytwarzają ten sam klucz, ta metoda usuwa parę z lewego iteratora i dołącza parę z prawego iteratora.
    ///
    /// Jeśli chcesz, aby drzewo kończyło się w ściśle rosnącej kolejności, jak w przypadku `BTreeMap`, obie iteratory powinny generować klucze w ściśle rosnącej kolejności, każdy większy niż wszystkie klucze w drzewie, w tym wszystkie klucze już w drzewie w momencie wejścia.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Przygotowujemy się do scalenia `left` i `right` w posortowaną sekwencję w czasie liniowym.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // W międzyczasie budujemy drzewo z posortowanej sekwencji w czasie liniowym.
        self.bulk_push(iter, length)
    }

    /// Umieszcza wszystkie pary klucz-wartość na końcu drzewa, zwiększając po drodze zmienną `length`.
    /// To ostatnie ułatwia dzwoniącemu uniknięcie wycieku, gdy iterator wpada w panikę.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iteruj przez wszystkie pary klucz-wartość, wpychając je do węzłów na odpowiednim poziomie.
        for (key, value) in iter {
            // Spróbuj wypchnąć parę klucz-wartość do bieżącego węzła-liścia.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Nie ma już miejsca, idź w górę i pchnij tam.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Znaleziono węzeł z pozostawioną spacją, wciśnij tutaj.
                                open_node = parent;
                                break;
                            } else {
                                // Idź ponownie.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Jesteśmy na górze, tworzymy nowy węzeł główny i wciskamy go.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Wypchnij parę klucz-wartość i nowe prawe poddrzewo.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Zejdź ponownie do skrajnego prawego liścia.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Zwiększaj długość każdej iteracji, aby upewnić się, że mapa porzuca dołączone elementy, nawet w przypadku panikowania iteratora.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iterator do łączenia dwóch posortowanych sekwencji w jedną
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Jeśli dwa klucze są równe, zwraca parę klucz-wartość z odpowiedniego źródła.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}