use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modeluje ponowne pobranie jakiegoś unikalnego odniesienia, gdy wiesz, że to ponowne zapisanie i wszystkie jego potomki (tj. Wszystkie wskaźniki i odniesienia z niego pochodzące) nie będą już używane w pewnym momencie, po czym chcesz ponownie użyć oryginalnego unikalnego odniesienia .
///
///
/// Program sprawdzający pożyczki zwykle obsługuje takie zestawianie pożyczek za Ciebie, ale niektóre przepływy sterowania, które wykonują to zestawianie, są zbyt skomplikowane, aby kompilator mógł je śledzić.
/// `DormantMutRef` umożliwia samodzielne sprawdzenie pożyczki, jednocześnie wyrażając jej skumulowaną naturę i hermetyzując surowy kod wskaźnika potrzebny do zrobienia tego bez niezdefiniowanego zachowania.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Zdobądź unikalną pożyczkę i natychmiast ją pożycz ponownie.
    /// W przypadku kompilatora okres istnienia nowego odniesienia jest taki sam, jak okres istnienia oryginalnego odniesienia, ale promise używa go przez krótszy okres.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // BEZPIECZEŃSTWO: trzymamy pożyczkę przez cały czas przez `_marker` i ujawniamy
        // tylko ta referencja, więc jest wyjątkowa.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Przywróć pierwotnie przechwyconą unikalną pożyczkę.
    ///
    /// # Safety
    ///
    /// Ponowne wypożyczanie musiało się zakończyć, tj. Odwołanie zwrócone przez `new` oraz wszystkie wskaźniki i referencje z niego wyprowadzone nie mogą być już używane.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // BEZPIECZEŃSTWO: nasze własne warunki bezpieczeństwa sugerują, że to odniesienie jest znowu wyjątkowe.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;