// To próba realizacji ideału
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Ponieważ Rust w rzeczywistości nie ma typów zależnych i rekurencji polimorficznej, radzimy sobie z wieloma niebezpieczeństwami.
//

// Głównym celem tego modułu jest uniknięcie złożoności poprzez traktowanie drzewa jako ogólny (jeśli ma dziwny kształt) kontener i unikanie zajmowania się większością niezmienników B-Tree.
//
// W związku z tym ten moduł nie dba o to, czy wpisy są posortowane, które węzły mogą być niepełne, a nawet co oznacza niepełne.Jednak opieramy się na kilku niezmiennikach:
//
// - Drzewa muszą mieć jednolite depth/height.Oznacza to, że każda ścieżka prowadząca do liścia z danego węzła ma dokładnie taką samą długość.
// - Węzeł o długości `n` ma klucze `n`, wartości `n` i krawędzie `n + 1`.
//   Oznacza to, że nawet pusty węzeł ma co najmniej jeden edge.
//   W przypadku węzła liścia "having an edge" oznacza tylko, że możemy zidentyfikować pozycję w węźle, ponieważ krawędzie liścia są puste i nie wymagają reprezentacji danych.
// W węźle wewnętrznym edge zarówno identyfikuje pozycję, jak i zawiera wskaźnik do węzła potomnego.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Podstawowa reprezentacja węzłów liści i część reprezentacji węzłów wewnętrznych.
struct LeafNode<K, V> {
    /// Chcemy być kowariantni w `K` i `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Indeks tego węzła do tablicy `edges` węzła nadrzędnego.
    /// `*node.parent.edges[node.parent_idx]` powinno być tym samym, co `node`.
    /// Jest to gwarantowane tylko wtedy, gdy `parent` ma wartość różną od null.
    parent_idx: MaybeUninit<u16>,

    /// Liczba kluczy i wartości przechowywanych w tym węźle.
    len: u16,

    /// Tablice przechowujące rzeczywiste dane węzła.
    /// Tylko pierwsze elementy `len` każdej tablicy są zainicjowane i prawidłowe.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicjuje nową lokalną `LeafNode`.
    unsafe fn init(this: *mut Self) {
        // Zgodnie z ogólną zasadą pozostawiamy pola niezainicjalizowane, jeśli to możliwe, ponieważ powinno to być zarówno nieco szybsze, jak i łatwiejsze do śledzenia w Valgrind.
        //
        unsafe {
            // parent_idx, klucze i wartości to wszystko możeMożeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Tworzy nowy pudełkowy `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Podstawowa reprezentacja węzłów wewnętrznych.Podobnie jak w przypadku `LeafNode`, powinny one być ukryte za`BoxedNode`, aby zapobiec porzucaniu niezainicjowanych kluczy i wartości.
/// Dowolny wskaźnik do `InternalNode` może być bezpośrednio rzutowany na wskaźnik do podstawowej części `LeafNode` węzła, umożliwiając kodowi działanie na liście i węzłach wewnętrznych generalnie bez konieczności sprawdzania, na który z dwóch wskazuje wskaźnik.
///
/// Ta właściwość jest włączana przy użyciu `repr(C)`.
///
#[repr(C)]
// gdb_providers.py używa tej nazwy typu do introspekcji.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Wskaźniki do elementów podrzędnych tego węzła.
    /// `len + 1` z nich są uważane za zainicjowane i prawidłowe, z wyjątkiem tego, że pod koniec, podczas gdy drzewo jest utrzymywane przez pożyczkę typu `Dying`, niektóre z tych wskaźników wiszą.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Tworzy nowy pudełkowy `InternalNode`.
    ///
    /// # Safety
    /// Niezmiennikiem węzłów wewnętrznych jest to, że mają co najmniej jeden zainicjowany i prawidłowy edge.
    /// Ta funkcja nie tworzy takiego edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Musimy tylko zainicjować dane;krawędzie są MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Zarządzany, niezerowy wskaźnik do węzła.Jest to albo wskaźnik będący własnością `LeafNode<K, V>`, albo wskaźnik będący własnością `InternalNode<K, V>`.
///
/// Jednak `BoxedNode` nie zawiera informacji o tym, który z dwóch typów węzłów faktycznie zawiera, a częściowo z powodu tego braku informacji nie jest oddzielnym typem i nie ma destruktora.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Węzeł główny posiadanego drzewa.
///
/// Zauważ, że nie ma to destruktora i musi zostać wyczyszczone ręcznie.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Zwraca nowe posiadane drzewo z własnym węzłem głównym, który jest początkowo pusty.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` nie może wynosić zero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Wymiennie pożycza posiadany węzeł główny.
    /// W przeciwieństwie do `reborrow_mut` jest to bezpieczne, ponieważ zwracanej wartości nie można użyć do zniszczenia korzenia i nie mogą istnieć inne odniesienia do drzewa.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nieznacznie zmiennie pożycza posiadany węzeł główny.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nieodwracalnie przechodzi do odniesienia, które pozwala na przemierzanie i oferuje destrukcyjne metody i niewiele więcej.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Dodaje nowy węzeł wewnętrzny z pojedynczym węzłem edge wskazującym na poprzedni węzeł główny, ustawia ten nowy węzeł jako węzeł główny i zwraca go.
    /// Zwiększa to wysokość o 1 i jest przeciwieństwem `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, poza tym, że zapomnieliśmy, że teraz jesteśmy wewnętrzni:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Usuwa wewnętrzny węzeł główny, używając pierwszego węzła podrzędnego jako nowego węzła głównego.
    /// Ponieważ jest przeznaczone do wywołania tylko wtedy, gdy węzeł główny ma tylko jedno dziecko, żadne czyszczenie kluczy, wartości i innych elementów podrzędnych nie jest wykonywane.
    ///
    /// Zmniejsza to wysokość o 1 i jest przeciwieństwem `push_internal_level`.
    ///
    /// Wymaga wyłącznego dostępu do obiektu `Root`, ale nie do węzła głównego;
    /// nie unieważni innych uchwytów ani odniesień do węzła głównego.
    ///
    /// Panics, jeśli nie ma poziomu wewnętrznego, tj. Jeśli węzeł główny jest liściem.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // BEZPIECZEŃSTWO: zapewnialiśmy, że jesteśmy wewnętrzni.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // BEZPIECZEŃSTWO: pożyczyliśmy wyłącznie `self`, a jego typ pożyczki jest wyłączny.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // BEZPIECZEŃSTWO: pierwszy edge jest zawsze inicjalizowany.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` jest zawsze kowariantny w `K` i `V`, nawet jeśli `BorrowType` to `Mut`.
// Jest to technicznie błędne, ale nie może powodować żadnego zagrożenia ze względu na wewnętrzne użycie `NodeRef`, ponieważ pozostajemy całkowicie uniwersalni w stosunku do `K` i `V`.
//
// Jednak za każdym razem, gdy typ publiczny zawija `NodeRef`, upewnij się, że ma poprawną wariancję.
//
/// Odniesienie do węzła.
///
/// Ten typ ma szereg parametrów, które sterują jego działaniem:
/// - `BorrowType`: Typ manekina, który opisuje rodzaj pożyczki i trwa przez całe życie.
///    - Kiedy to jest `Immut<'a>`, `NodeRef` działa z grubsza jak `&'a Node`.
///    - Gdy jest to `ValMut<'a>`, `NodeRef` działa z grubsza jak `&'a Node` w odniesieniu do kluczy i struktury drzewa, ale pozwala również na współistnienie wielu modyfikowalnych odwołań do wartości w całym drzewie.
///    - Kiedy jest to `Mut<'a>`, `NodeRef` działa mniej więcej tak jak `&'a mut Node`, chociaż metody wstawiania pozwalają na współistnienie mutowalnego wskaźnika do wartości.
///    - Gdy jest to `Owned`, `NodeRef` działa mniej więcej tak, jak `Box<Node>`, ale nie ma destruktora i należy go wyczyścić ręcznie.
///    - Kiedy jest to `Dying`, `NodeRef` nadal działa mniej więcej tak jak `Box<Node>`, ale ma metody niszczenia drzewa bit po bicie, a zwykłe metody, chociaż nie są oznaczone jako niebezpieczne do wywołania, mogą wywoływać UB, jeśli zostaną wywołane nieprawidłowo.
///
///   Ponieważ każdy `NodeRef` umożliwia nawigację po drzewie, `BorrowType` skutecznie stosuje się do całego drzewa, a nie tylko do samego węzła.
/// - `K` i `V`: są to typy kluczy i wartości przechowywanych w węzłach.
/// - `Type`: Może to być `Leaf`, `Internal` lub `LeafOrInternal`.
/// Gdy jest to `Leaf`, `NodeRef` wskazuje na węzeł liścia, gdy jest to `Internal`, `NodeRef` wskazuje na węzeł wewnętrzny, a gdy jest to `LeafOrInternal`, `NodeRef` może wskazywać na dowolny typ węzła.
///   `Type` nosi nazwę `NodeType`, gdy jest używany poza `NodeRef`.
///
/// Zarówno `BorrowType`, jak i `NodeType` ograniczają stosowane przez nas metody, aby wykorzystać bezpieczeństwo typu statycznego.Istnieją ograniczenia w sposobie stosowania takich ograniczeń:
/// - Dla każdego parametru typu możemy zdefiniować metodę tylko generalnie lub dla jednego określonego typu.
/// Na przykład nie możemy zdefiniować metody takiej jak `into_kv` ogólnie dla wszystkich `BorrowType` lub raz dla wszystkich typów, które mają okres istnienia, ponieważ chcemy, aby zwracała odwołania `&'a`.
///   Dlatego definiujemy go tylko dla najmniej wydajnego typu `Immut<'a>`.
/// - Nie możemy uzyskać niejawnego przymusu z powiedzmy `Mut<'a>` do `Immut<'a>`.
///   Dlatego musimy jawnie wywołać `reborrow` na bardziej wydajnym `NodeRef`, aby osiągnąć metodę taką jak `into_kv`.
///
/// Wszystkie metody na `NodeRef`, które zwracają jakieś odniesienie, albo:
/// - Weź `self` według wartości i zwróć czas życia przenoszony przez `BorrowType`.
///   Czasami, aby wywołać taką metodę, musimy wywołać `reborrow_mut`.
/// - Weź `self` jako odniesienie, a (implicitly) zwróci okres istnienia tego odniesienia, zamiast okresu istnienia przenoszonego przez `BorrowType`.
/// W ten sposób osoba sprawdzająca pożyczkę gwarantuje, że `NodeRef` pozostanie wypożyczony tak długo, jak długo używany jest zwracany numer referencyjny.
///   Metody obsługujące wstawianie wyginają tę regułę, zwracając nieprzetworzony wskaźnik, tj. Referencję bez czasu życia.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Liczba poziomów, które są oddzielone węzłem i poziom liści, stała węzła, której nie można całkowicie opisać przez `Type` i której sam węzeł nie przechowuje.
    /// Musimy tylko zapisać wysokość węzła głównego i wyprowadzić z niego wysokość każdego innego węzła.
    /// Musi wynosić zero, jeśli `Type` to `Leaf` i niezerowe, jeśli `Type` to `Internal`.
    ///
    ///
    height: usize,
    /// Wskaźnik do liścia lub węzła wewnętrznego.
    /// Definicja `InternalNode` zapewnia, że wskaźnik jest poprawny w obu przypadkach.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Rozpakuj odwołanie do węzła spakowane jako `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ujawnia dane wewnętrznego węzła.
    ///
    /// Zwraca nieprzetworzony ptr, aby uniknąć unieważnienia innych odwołań do tego węzła.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // BEZPIECZEŃSTWO: typ węzła statycznego to `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Pożycza wyłączny dostęp do danych węzła wewnętrznego.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Znajduje długość węzła.To jest liczba kluczy lub wartości.
    /// Liczba krawędzi wynosi `len() + 1`.
    /// Należy zauważyć, że pomimo bezpieczeństwa wywołanie tej funkcji może mieć efekt uboczny w postaci unieważnienia odwołań modyfikowalnych, które utworzył niebezpieczny kod.
    ///
    pub fn len(&self) -> usize {
        // Co najważniejsze, mamy tutaj dostęp tylko do pola `len`.
        // Jeśli BorrowType to marker::ValMut, mogą istnieć zaległe zmienne odwołania do wartości, których nie możemy unieważniać.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Zwraca liczbę poziomów, które są oddzielone węzłem i liśćmi.
    /// Zerowa wysokość oznacza, że sam węzeł jest liściem.
    /// Jeśli wyobrazisz sobie drzewa z korzeniem na górze, liczba mówi, na jakiej wysokości znajduje się węzeł.
    /// Jeśli wyobrazisz sobie drzewa z liśćmi na górze, liczba mówi, jak wysoko drzewo rozciąga się nad węzłem.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Tymczasowo usuwa inne, niezmienne odwołanie do tego samego węzła.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Odsłania część liścia dowolnego liścia lub węzła wewnętrznego.
    ///
    /// Zwraca nieprzetworzony ptr, aby uniknąć unieważnienia innych odwołań do tego węzła.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Węzeł musi być ważny co najmniej przez część LeafNode.
        // To nie jest odwołanie w typie NodeRef, ponieważ nie wiemy, czy powinno być unikalne, czy współdzielone.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Znajduje rodzica bieżącego węzła.
    /// Zwraca `Ok(handle)`, jeśli bieżący węzeł faktycznie ma rodzica, gdzie `handle` wskazuje na edge rodzica, który wskazuje na bieżący węzeł.
    ///
    /// Zwraca `Err(self)`, jeśli bieżący węzeł nie ma rodzica, zwracając oryginalny `NodeRef`.
    ///
    /// Nazwa metody zakłada, że obrazujesz drzewa z węzłem głównym na górze.
    ///
    /// `edge.descend().ascend().unwrap()` a `node.ascend().unwrap().descend()` po sukcesie nie powinien nic robić.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Musimy używać surowych wskaźników do węzłów, ponieważ jeśli BorrowType to marker::ValMut, mogą istnieć wyjątkowe zmienne odniesienia do wartości, których nie możemy unieważniać.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Zauważ, że `self` musi być niepusty.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Zauważ, że `self` musi być niepusty.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Odsłania część liścia dowolnego liścia lub węzła wewnętrznego w niezmiennym drzewie.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // BEZPIECZEŃSTWO: nie może być żadnych zmiennych odniesień do tego drzewa pożyczonego jako `Immut`.
        unsafe { &*ptr }
    }

    /// Pożycza widok do kluczy przechowywanych w węźle.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Podobnie jak `ascend`, pobiera odwołanie do węzła nadrzędnego węzła, ale także zwalnia bieżący węzeł w procesie.
    /// Jest to niebezpieczne, ponieważ bieżący węzeł będzie nadal dostępny pomimo zwolnienia.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Niezabezpieczenie zapewnia kompilatorowi statyczną informację, że ten węzeł to `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Niezabezpiecznie potwierdza kompilatorowi statyczne informacje, że ten węzeł to `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Tymczasowo usuwa inne, zmienne odwołanie do tego samego węzła.Uważaj, ponieważ ta metoda jest bardzo niebezpieczna, podwójnie, ponieważ może nie wydawać się niebezpieczna od razu.
    ///
    /// Ponieważ zmienne wskaźniki mogą wędrować w dowolnym miejscu po drzewie, zwracany wskaźnik może być łatwo użyty do tego, aby oryginalny wskaźnik zwisał, znalazł się poza granicami lub był nieważny zgodnie z regułami pożyczania w stosie.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) rozważ dodanie jeszcze jednego parametru typu do `NodeRef`, który ogranicza użycie metod nawigacji do ponownie zapisanych wskaźników, zapobiegając temu niebezpiecznemu.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Pożycza wyłączny dostęp do części liścia dowolnego liścia lub węzła wewnętrznego.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // BEZPIECZEŃSTWO: mamy wyłączny dostęp do całego węzła.
        unsafe { &mut *ptr }
    }

    /// Oferuje wyłączny dostęp do części liścia dowolnego liścia lub węzła wewnętrznego.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // BEZPIECZEŃSTWO: mamy wyłączny dostęp do całego węzła.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Wypożycza wyłączny dostęp do elementu magazynu kluczy.
    ///
    /// # Safety
    /// `index` jest w granicach 0..POJEMNOŚĆ
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // BEZPIECZEŃSTWO: dzwoniący nie będzie mógł wywołać innych metod samodzielnie
        // do momentu porzucenia odniesienia do wycinka klucza, ponieważ mamy unikalny dostęp przez cały czas trwania pożyczki.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Wypożycza wyłączny dostęp do elementu lub wycinka obszaru przechowywania wartości węzła.
    ///
    /// # Safety
    /// `index` jest w granicach 0..POJEMNOŚĆ
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // BEZPIECZEŃSTWO: dzwoniący nie będzie mógł wywołać innych metod samodzielnie
        // do momentu porzucenia odniesienia do wycinka wartości, ponieważ mamy unikalny dostęp przez cały okres trwania pożyczki.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Wypożycza wyłączny dostęp do elementu lub wycinka obszaru pamięci węzła na zawartość edge.
    ///
    /// # Safety
    /// `index` mieści się w granicach 0..POJEMNOŚĆ + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // BEZPIECZEŃSTWO: dzwoniący nie będzie mógł wywołać innych metod samodzielnie
        // dopóki odniesienie do wycinka edge nie zostanie porzucone, ponieważ mamy unikalny dostęp przez cały czas trwania pożyczki.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Węzeł ma więcej niż zainicjowanych elementów `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Tworzymy tylko odniesienie do jednego elementu, który nas interesuje, aby uniknąć aliasingu z wybitnymi odwołaniami do innych elementów, w szczególności tych zwróconych do obiektu wywołującego we wcześniejszych iteracjach.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Musimy przekonać się do wskaźników tablicy bez rozmiaru z powodu problemu Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Wypożycza wyłączny dostęp do długości węzła.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ustawia łącze węzła na jego nadrzędny edge, bez unieważniania innych odniesień do węzła.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Czyści łącze roota do jego rodzica edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Dodaje parę klucz-wartość na końcu węzła.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Każdy element zwracany przez `range` jest prawidłowym indeksem edge dla węzła.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Dodaje parę klucz-wartość i edge, aby przejść na prawo od tej pary, na koniec węzła.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Sprawdza, czy węzeł jest węzłem `Internal` czy `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Odwołanie do określonej pary klucz-wartość lub edge w węźle.
/// Parametr `Node` musi być `NodeRef`, podczas gdy `Type` może być `KV` (oznaczający uchwyt w parze klucz-wartość) lub `Edge` (oznaczający uchwyt w edge).
///
/// Zauważ, że nawet węzły `Leaf` mogą mieć uchwyty `Edge`.
/// Zamiast reprezentować wskaźnik do węzła podrzędnego, reprezentują one spacje, w których wskaźniki podrzędne znajdowałyby się między parami klucz-wartość.
/// Na przykład w węźle o długości 2 byłyby 3 możliwe lokalizacje edge, jedna po lewej stronie węzła, jedna między dwiema parami i jedna po prawej stronie węzła.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Nie potrzebujemy pełnej ogólności `#[derive(Clone)]`, ponieważ `Node` będzie można klonować tylko wtedy, gdy jest niezmiennym odniesieniem, a zatem `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Pobiera węzeł zawierający edge lub parę klucz-wartość, na którą wskazuje ten uchwyt.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Zwraca pozycję tego uchwytu w węźle.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Tworzy nowe dojście do pary klucz-wartość w `node`.
    /// Niebezpieczne, ponieważ dzwoniący musi zapewnić, że `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Może to być publiczna implementacja PartialEq, ale używana tylko w tym module.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Tymczasowo wyjmuje inny, niezmienny uchwyt w tym samym miejscu.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Nie możemy użyć Handle::new_kv ani Handle::new_edge, ponieważ nie znamy naszego typu
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Niezabezpiecznie zapewnia kompilatorowi statyczną informację, że węzłem uchwytu jest `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Tymczasowo wyjmuje inny, zmienny uchwyt w tym samym miejscu.
    /// Uważaj, ponieważ ta metoda jest bardzo niebezpieczna, podwójnie, ponieważ może nie wydawać się niebezpieczna od razu.
    ///
    ///
    /// Aby uzyskać szczegółowe informacje, zobacz `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Nie możemy użyć Handle::new_kv ani Handle::new_edge, ponieważ nie znamy naszego typu
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Tworzy nowy uchwyt do edge w `node`.
    /// Niebezpieczne, ponieważ dzwoniący musi zapewnić, że `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Biorąc pod uwagę indeks edge, w którym chcemy wstawić do węzła wypełnionego do pełna, oblicza rozsądny indeks KV punktu podziału i gdzie wykonać wstawienie.
///
/// Celem punktu podziału jest to, aby jego klucz i wartość znalazły się w węźle nadrzędnym;
/// klawisze, wartości i krawędzie po lewej stronie punktu podziału stają się lewym dzieckiem;
/// klucze, wartości i krawędzie po prawej stronie punktu podziału stają się właściwym dzieckiem.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Problem Rust #74834 próbuje wyjaśnić te zasady symetrii.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Wstawia nową parę klucz-wartość między parami klucz-wartość po prawej i lewej stronie tego edge.
    /// Ta metoda zakłada, że w węźle jest wystarczająco dużo miejsca, aby zmieścić nową parę.
    ///
    /// Zwrócony wskaźnik wskazuje na wstawioną wartość.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Wstawia nową parę klucz-wartość między parami klucz-wartość po prawej i lewej stronie tego edge.
    /// Ta metoda dzieli węzeł, jeśli nie ma wystarczającej ilości miejsca.
    ///
    /// Zwrócony wskaźnik wskazuje na wstawioną wartość.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Naprawia wskaźnik nadrzędny i indeks w węźle podrzędnym, do którego łączy się ten edge.
    /// Jest to przydatne, gdy kolejność krawędzi została zmieniona,
    fn correct_parent_link(self) {
        // Utwórz backpointer bez unieważniania innych odniesień do węzła.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Wstawia nową parę klucz-wartość i edge, które zostaną umieszczone po prawej stronie tej nowej pary między tym edge a parą klucz-wartość po prawej stronie tego edge.
    /// Ta metoda zakłada, że w węźle jest wystarczająco dużo miejsca, aby zmieścić nową parę.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Wstawia nową parę klucz-wartość i edge, które zostaną umieszczone po prawej stronie tej nowej pary między tym edge a parą klucz-wartość po prawej stronie tego edge.
    /// Ta metoda dzieli węzeł, jeśli nie ma wystarczającej ilości miejsca.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Wstawia nową parę klucz-wartość między parami klucz-wartość po prawej i lewej stronie tego edge.
    /// Ta metoda dzieli węzeł, jeśli nie ma wystarczającej ilości miejsca, i próbuje wstawić podzieloną część rekurencyjnie do węzła nadrzędnego, aż do osiągnięcia katalogu głównego.
    ///
    ///
    /// Jeśli zwrócony wynik to `Fit`, węzeł jego uchwytu może być węzłem tego edge lub przodkiem.
    /// Jeśli zwrócony wynik to `Split`, pole `left` będzie węzłem głównym.
    /// Zwrócony wskaźnik wskazuje na wstawioną wartość.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Znajduje węzeł wskazywany przez ten edge.
    ///
    /// Nazwa metody zakłada, że obrazujesz drzewa z węzłem głównym na górze.
    ///
    /// `edge.descend().ascend().unwrap()` a `node.ascend().unwrap().descend()` po sukcesie nie powinien nic robić.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Musimy używać surowych wskaźników do węzłów, ponieważ jeśli BorrowType to marker::ValMut, mogą istnieć wyjątkowe zmienne odniesienia do wartości, których nie możemy unieważniać.
        // Nie ma problemu z dostępem do pola wysokości, ponieważ ta wartość jest kopiowana.
        // Pamiętaj, że po wyłuskaniu wskaźnika węzła uzyskujemy dostęp do tablicy brzegów z odniesieniem (Rust wydanie #73987) i unieważniamy wszelkie inne odniesienia do lub wewnątrz tablicy, jeśli jakieś są w pobliżu.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Nie możemy wywołać oddzielnych metod klucza i wartości, ponieważ wywołanie drugiej unieważnia odwołanie zwrócone przez pierwszą.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Zastąp klucz i wartość, do której odwołuje się uchwyt KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Pomaga we wdrożeniach `split` dla konkretnego `NodeType`, dbając o dane liści.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Dzieli podstawowy węzeł na trzy części:
    ///
    /// - Węzeł jest obcinany, aby zawierał tylko pary klucz-wartość po lewej stronie tego uchwytu.
    /// - Klucz i wartość wskazywana przez ten uchwyt są wyodrębniane.
    /// - Wszystkie pary klucz-wartość po prawej stronie tego uchwytu są umieszczane w nowo przydzielonym węźle.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Usuwa parę klucz-wartość wskazywaną przez ten uchwyt i zwraca ją wraz z edge, do którego została zwinięta para klucz-wartość.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Dzieli podstawowy węzeł na trzy części:
    ///
    /// - Węzeł jest obcinany, aby zawierał tylko krawędzie i pary klucz-wartość po lewej stronie tego uchwytu.
    /// - Klucz i wartość wskazywana przez ten uchwyt są wyodrębniane.
    /// - Wszystkie krawędzie i pary klucz-wartość po prawej stronie tego uchwytu są umieszczane w nowo przydzielonym węźle.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Reprezentuje sesję służącą do oceny i wykonywania operacji równoważenia wokół wewnętrznej pary klucz-wartość.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Wybiera kontekst równoważenia, w którym węzeł jest dzieckiem, a więc między KV bezpośrednio po lewej lub po prawej stronie węzła nadrzędnego.
    /// Zwraca `Err`, jeśli nie ma rodzica.
    /// Panics, jeśli rodzic jest pusty.
    ///
    /// Preferuje lewą stronę, aby być optymalnym, jeśli dany węzeł jest w jakiś sposób niepełny, co oznacza tylko, że ma mniej elementów niż jego lewy brat i jego prawy brat, jeśli istnieją.
    /// W takim przypadku scalanie z lewym rodzeństwem jest szybsze, ponieważ wystarczy przesunąć elementy N węzła, zamiast przesuwać je w prawo i przesuwać więcej niż N elementów do przodu.
    /// Kradzież od lewego rodzeństwa jest również zazwyczaj szybsza, ponieważ musimy tylko przesunąć elementy N węzła w prawo, zamiast przesuwać co najmniej N elementów rodzeństwa w lewo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Zwraca, czy scalanie jest możliwe, tj. Czy w węźle jest wystarczająco dużo miejsca, aby połączyć centralny KV z oboma sąsiednimi węzłami podrzędnymi.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Wykonuje scalanie i pozwala zamknięciu zdecydować, co zwrócić.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // BEZPIECZEŃSTWO: wysokość łączonych węzłów jest o jeden poniżej wysokości
                // węzła tego edge, a więc powyżej zera, więc są wewnętrzne.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Łączy parę klucz-wartość nadrzędnego i oba sąsiednie węzły podrzędne do lewego węzła podrzędnego i zwraca skurczony węzeł nadrzędny.
    ///
    ///
    /// Panics, chyba że `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Łączy parę klucz-wartość nadrzędnego i oba sąsiednie węzły podrzędne do lewego węzła podrzędnego i zwraca ten węzeł podrzędny.
    ///
    ///
    /// Panics, chyba że `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Łączy parę klucz-wartość rodzica i oba sąsiednie węzły podrzędne do lewego węzła podrzędnego i zwraca uchwyt edge w tym węźle podrzędnym, do którego trafiło śledzone dziecko edge
    ///
    ///
    /// Panics, chyba że `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Usuwa parę klucz-wartość z lewego elementu podrzędnego i umieszcza ją w magazynie klucz-wartość elementu nadrzędnego, jednocześnie wypychając starą parę klucz-wartość elementu nadrzędnego do prawego elementu podrzędnego.
    ///
    /// Zwraca uchwyt do edge w prawym potomku odpowiadającym miejscu, w którym zakończył się oryginalny edge określony przez `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Usuwa parę klucz-wartość z prawego elementu podrzędnego i umieszcza ją w magazynie klucz-wartość elementu nadrzędnego, jednocześnie wypychając starą parę klucz-wartość elementu nadrzędnego na lewe dziecko.
    ///
    /// Zwraca uchwyt do edge w lewym dziecku określonym przez `track_left_edge_idx`, który się nie poruszył.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// To robi kradzież podobną do `steal_left`, ale kradnie wiele elementów jednocześnie.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Upewnij się, że możemy bezpiecznie kraść.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Przenieś dane liści.
            {
                // Zrób miejsce na skradzione elementy u właściwego dziecka.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Przenieś elementy z lewego dziecka na prawe.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Przenieś skradzioną parę z lewej strony do rodzica.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Przenieś parę klucz-wartość rodzica do właściwego dziecka.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Zrób miejsce na skradzione krawędzie.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Kradnij krawędzie.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Symetryczny klon `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Upewnij się, że możemy bezpiecznie kraść.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Przenieś dane liści.
            {
                // Przenieś skradzioną parę po prawej stronie do rodzica.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Przenieś parę klucz-wartość rodzica na lewe dziecko.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Przenieś elementy z prawego dziecka na lewe.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Wypełnij lukę w miejscu skradzionych elementów.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Kradnij krawędzie.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Wypełnij lukę w miejscu, gdzie kiedyś znajdowały się skradzione krawędzie.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Usuwa wszelkie informacje statyczne, które twierdzą, że ten węzeł jest węzłem `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Usuwa wszelkie informacje statyczne, które twierdzą, że ten węzeł jest węzłem `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Sprawdza, czy węzeł bazowy jest węzłem `Internal` czy `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Przenieś sufiks po `self` z jednego węzła do drugiego.`right` musi być pusty.
    /// Pierwszy edge `right` pozostaje niezmieniony.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Wynik wstawienia, gdy węzeł wymagał rozszerzenia poza jego pojemność.
pub struct SplitResult<'a, K, V, NodeType> {
    // Zmieniony węzeł w istniejącym drzewie z elementami i krawędziami, które należą do lewej strony `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Oddzielono klucz i wartość, aby wstawić gdzie indziej.
    pub kv: (K, V),
    // Własny, niedołączony, nowy węzeł z elementami i krawędziami, które należą do prawej strony `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Czy odwołania do węzłów tego typu pożyczenia umożliwiają przechodzenie do innych węzłów w drzewie.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal nie jest potrzebny, dzieje się to na podstawie wyniku `borrow_mut`.
        // Wyłączając przemierzanie i tworząc tylko nowe odniesienia do korzeni, wiemy, że każde odwołanie typu `Owned` prowadzi do węzła głównego.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Wstawia wartość do wycinka zainicjowanych elementów, po których następuje jeden niezainicjowany element.
///
/// # Safety
/// Kawałek zawiera więcej elementów niż `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Usuwa i zwraca wartość z wycinka wszystkich zainicjowanych elementów, pozostawiając jeden końcowy niezainicjowany element.
///
///
/// # Safety
/// Kawałek zawiera więcej elementów niż `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Przesuwa elementy w plasterku o `distance` w lewo.
///
/// # Safety
/// Kawałek zawiera co najmniej `distance` elementów.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Przesuwa elementy w plasterku o `distance` w prawo.
///
/// # Safety
/// Kawałek zawiera co najmniej `distance` elementów.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Przenosi wszystkie wartości z wycinka zainicjowanych elementów do wycinka niezainicjowanych elementów, pozostawiając `src` jako wszystkie niezainicjowane.
///
/// Działa jak `dst.copy_from_slice(src)`, ale nie wymaga, aby `T` było `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;