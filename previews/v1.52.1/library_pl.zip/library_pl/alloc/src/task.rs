#![stable(feature = "wake_trait", since = "1.51.0")]
//! Typy i Traits do pracy z zadaniami asynchronicznymi.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Realizacja wybudzania zadania na executorze.
///
/// Ten trait może być użyty do stworzenia [`Waker`].
/// Wykonawca może zdefiniować implementację tego trait i użyć tego do skonstruowania Wakera, który będzie przekazywał zadania, które są wykonywane na tym module wykonawczym.
///
/// Ten trait to bezpieczna w pamięci i ergonomiczna alternatywa dla konstrukcji [`RawWaker`].
/// Obsługuje typowy projekt wykonawczy, w którym dane używane do wybudzania zadania są przechowywane w [`Arc`].
/// Niektóre programy wykonawcze (szczególnie te dla systemów wbudowanych) nie mogą używać tego API, dlatego [`RawWaker`] istnieje jako alternatywa dla tych systemów.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Podstawowa funkcja `block_on`, która pobiera future i uruchamia ją do zakończenia w bieżącym wątku.
///
/// **Note:** Ten przykład zamienia poprawność na prostotę.
/// Aby zapobiec zakleszczeniom, implementacje klasy produkcyjnej będą również musiały obsługiwać wywołania pośrednie do `thread::unpark`, a także wywołania zagnieżdżone.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Waker, który budzi bieżący wątek po wywołaniu.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Uruchom future do zakończenia w bieżącym wątku.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Przypnij future, aby umożliwić odpytywanie.
///     let mut fut = Box::pin(fut);
///
///     // Utwórz nowy kontekst do przekazania do future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Uruchom future do zakończenia.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Obudź to zadanie.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Obudź to zadanie bez zużywania czuwacza.
    ///
    /// Jeśli executor obsługuje tańszy sposób budzenia bez zużywania wakera, powinien zastąpić tę metodę.
    /// Domyślnie klonuje [`Arc`] i wywołuje [`wake`] na klonie.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // BEZPIECZEŃSTWO: To jest bezpieczne, ponieważ raw_waker bezpiecznie konstruuje
        // RawWaker z Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ta prywatna funkcja do konstruowania RawWakera jest używana raczej niż
// wbudowanie tego w `From<Arc<W>> for RawWaker` impl, aby upewnić się, że bezpieczeństwo `From<Arc<W>> for Waker` nie zależy od prawidłowego wysłania trait, zamiast tego oba impls wywołują tę funkcję bezpośrednio i jawnie.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Zwiększ liczbę referencyjną łuku, aby go sklonować.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Obudź się według wartości, przenosząc Łuk do funkcji Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Obudź się przez odniesienie, zawiń czuwacza w ManuallyDrop, aby go nie upuścić
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Zmniejsz licznik odniesienia łuku przy upuszczaniu
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}