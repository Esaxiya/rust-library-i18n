//! Ciąg znaków zakodowany w UTF-8.
//!
//! Ten moduł zawiera typ [`String`], [`ToString`] trait do konwersji na łańcuchy oraz kilka typów błędów, które mogą wynikać z pracy z [`String`] s.
//!
//!
//! # Examples
//!
//! Istnieje wiele sposobów tworzenia nowego [`String`] na podstawie literału ciągu:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Możesz utworzyć nowy [`String`] z istniejącego, łącząc go z
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Jeśli masz vector z prawidłowych bajtów UTF-8, możesz zrobić z niego [`String`].Możesz też zrobić odwrotnie.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Wiemy, że te bajty są prawidłowe, więc użyjemy `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Ciąg znaków zakodowany w UTF-8.
///
/// Typ `String` jest najpopularniejszym typem łańcucha, który ma prawo własności do zawartości ciągu.Ma ścisły związek ze swoim pożyczonym odpowiednikiem, prymitywnym [`str`].
///
/// # Examples
///
/// Możesz utworzyć `String` z [a literal string][`str`] za pomocą [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Możesz dołączyć [`char`] do `String` za pomocą metody [`push`], a [`&str`] za pomocą metody [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Jeśli masz vector o rozmiarze UTF-8 bajtów, możesz utworzyć z niego `String` metodą [`from_utf8`]:
///
/// ```
/// // kilka bajtów w vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Wiemy, że te bajty są prawidłowe, więc użyjemy `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `Ciągi są zawsze prawidłowe UTF-8.Ma to kilka konsekwencji, z których pierwszą jest to, że jeśli potrzebujesz łańcucha innego niż UTF-8, rozważ [`OsString`].Jest podobnie, ale bez ograniczenia UTF-8.Drugą konsekwencją jest to, że nie można indeksować w `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indeksowanie ma być operacją działającą w czasie stałym, ale kodowanie UTF-8 nam na to nie pozwala.Co więcej, nie jest jasne, jaki rodzaj rzeczy powinien zwrócić indeks: bajt, punkt kodowy lub klaster grafemowy.
/// Metody [`bytes`] i [`chars`] zwracają iteratory odpowiednio dla pierwszych dwóch.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s implement [`Deref`] `<Target=str>`, a więc dziedziczą wszystkie metody [`str`].Ponadto oznacza to, że możesz przekazać `String` do funkcji, która przyjmuje [`&str`], używając znaku ampers i (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Spowoduje to utworzenie [`&str`] z `String` i przekazanie go. Ta konwersja jest bardzo tania, więc generalnie funkcje akceptują [`&str`] jako argumenty, chyba że z jakiegoś konkretnego powodu potrzebują `String`.
///
/// W niektórych przypadkach Rust nie ma wystarczających informacji, aby wykonać tę konwersję, znaną jako wymuszenie [`Deref`].W poniższym przykładzie fragment ciągu [`&'a str`][`&str`] implementuje trait `TraitExample`, a funkcja `example_func` przyjmuje wszystko, co implementuje trait.
/// W tym przypadku Rust musiałby wykonać dwie niejawne konwersje, na które Rust nie ma środków.
/// Z tego powodu poniższy przykład nie zostanie skompilowany.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Zamiast tego działają dwie opcje.Pierwszym z nich byłaby zmiana linii `example_func(&example_string);` na `example_func(example_string.as_str());` przy użyciu metody [`as_str()`], aby jawnie wyodrębnić fragment ciągu zawierający ciąg.
/// Drugi sposób zmienia `example_func(&example_string);` na `example_func(&*example_string);`.
/// W tym przypadku odwołujemy `String` do [`str`][`&str`], a następnie odwołujemy [`str`][`&str`] z powrotem do [`&str`].
/// Drugi sposób jest bardziej idiomatyczny, jednak oba działają, aby wykonać konwersję jawnie, zamiast polegać na konwersji niejawnej.
///
/// # Representation
///
/// `String` składa się z trzech elementów: wskaźnika do niektórych bajtów, długości i pojemności.Wskaźnik wskazuje na wewnętrzny bufor używany przez `String` do przechowywania danych.Długość to liczba bajtów aktualnie przechowywanych w buforze, a pojemność to rozmiar bufora w bajtach.
///
/// W związku z tym długość zawsze będzie mniejsza lub równa pojemności.
///
/// Ten bufor jest zawsze przechowywany na stercie.
///
/// Możesz przyjrzeć się tym metodom [`as_ptr`], [`len`] i [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Zaktualizuj to po ustabilizowaniu vec_into_raw_parts.
/// // Zapobiegaj automatycznemu upuszczaniu danych ciągu
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // historia ma dziewiętnaście bajtów
/// assert_eq!(19, len);
///
/// // Możemy ponownie zbudować String z ptr, len i capacity.
/// // To wszystko jest niebezpieczne, ponieważ jesteśmy odpowiedzialni za upewnienie się, że komponenty są prawidłowe:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Jeśli `String` ma wystarczającą pojemność, dodanie do niego elementów nie spowoduje ponownego przydzielenia.Weźmy na przykład pod uwagę ten program:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Spowoduje to wyświetlenie następujących informacji:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Początkowo w ogóle nie mamy przydzielonej pamięci, ale w miarę dołączania do ciągu odpowiednio zwiększa on swoją pojemność.Jeśli zamiast tego użyjemy metody [`with_capacity`], aby początkowo przydzielić odpowiednią pojemność:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Otrzymujemy inny wynik:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Tutaj nie ma potrzeby przydzielania większej ilości pamięci wewnątrz pętli.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Możliwa wartość błędu podczas konwersji `String` z bajtu UTF-8 vector.
///
/// Ten typ jest typem błędu metody [`from_utf8`] w [`String`].
/// Został zaprojektowany w taki sposób, aby ostrożnie unikać realokacji: metoda [`into_bytes`] zwróci bajt vector, który został użyty podczas próby konwersji.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Typ [`Utf8Error`] dostarczony przez [`std::str`] reprezentuje błąd, który może wystąpić podczas konwersji wycinka [`u8`] s na [`&str`].
/// W tym sensie jest to odpowiednik `FromUtf8Error` i można go uzyskać z `FromUtf8Error` za pomocą metody [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// // niektóre nieprawidłowe bajty w vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Możliwa wartość błędu podczas konwersji `String` z segmentu bajtów UTF-16.
///
/// Ten typ jest typem błędu metody [`from_utf16`] w [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Tworzy nowy pusty `String`.
    ///
    /// Biorąc pod uwagę, że `String` jest pusty, nie spowoduje to przydzielenia żadnego początkowego bufora.Chociaż oznacza to, że ta początkowa operacja jest bardzo niedroga, może spowodować nadmierną alokację później, gdy dodasz dane.
    ///
    /// Jeśli masz pojęcie, ile danych będzie przechowywanych w `String`, rozważ metodę [`with_capacity`], aby zapobiec nadmiernej ponownej alokacji.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Tworzy nowy pusty `String` o określonej pojemności.
    ///
    /// `Ciągi mają wewnętrzny bufor do przechowywania danych.
    /// Pojemność to długość tego bufora, o którą można zapytać metodą [`capacity`].
    /// Ta metoda tworzy pusty `String`, ale taki z początkowym buforem, który może przechowywać bajty `capacity`.
    /// Jest to przydatne, gdy możesz dołączać kilka danych do `String`, zmniejszając liczbę ponownych alokacji, które musi wykonać.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Jeśli dana pojemność wynosi `0`, nie nastąpi alokacja, a ta metoda jest identyczna jak metoda [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Ciąg nie zawiera żadnych znaków, mimo że może pomieścić więcej
    /// assert_eq!(s.len(), 0);
    ///
    /// // Wszystko to odbywa się bez ponownego przydziału ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ale może to spowodować zmianę alokacji ciągu
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): w przypadku cfg(test) nieodłączna metoda `[T]::to_vec`, która jest wymagana dla tej definicji metody, nie jest dostępna.
    // Ponieważ nie potrzebujemy tej metody do celów testowych, po prostu ją skasuję. Uwaga: zobacz moduł slice::hack w slice.rs, aby uzyskać więcej informacji
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Konwertuje vector bajtów na `String`.
    ///
    /// Ciąg ([`String`]) składa się z bajtów ([`u8`]), a vector z bajtów ([`Vec<u8>`]) jest utworzony z bajtów, więc ta funkcja konwertuje między nimi.
    /// Nie wszystkie segmenty bajtów są poprawnymi ciągami znaków, jednakże: `String` wymaga, aby był prawidłowy UTF-8.
    /// `from_utf8()` sprawdza, czy bajty są prawidłowe UTF-8, a następnie przeprowadza konwersję.
    ///
    /// Jeśli masz pewność, że segment bajtów jest prawidłowy UTF-8 i nie chcesz ponosić narzutu związanego z kontrolą poprawności, istnieje niebezpieczna wersja tej funkcji, [`from_utf8_unchecked`], która zachowuje się tak samo, ale pomija sprawdzanie.
    ///
    ///
    /// Ta metoda pozwoli nie kopiować vector ze względu na wydajność.
    ///
    /// Jeśli potrzebujesz [`&str`] zamiast `String`, rozważ [`str::from_utf8`].
    ///
    /// Odwrotnością tej metody jest [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Zwraca [`Err`], jeśli wycinek nie jest UTF-8 z opisem, dlaczego podane bajty nie są UTF-8.Uwzględniony jest również vector, do którego się wprowadziłeś.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // kilka bajtów w vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Wiemy, że te bajty są prawidłowe, więc użyjemy `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Niepoprawne bajty:
    ///
    /// ```
    /// // niektóre nieprawidłowe bajty w vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Zobacz dokumentację [`FromUtf8Error`], aby uzyskać więcej informacji na temat tego, co możesz zrobić z tym błędem.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Konwertuje fragment bajtów na ciąg, w tym nieprawidłowe znaki.
    ///
    /// Łańcuchy składają się z bajtów ([`u8`]), a wycinek bajtów ([`&[u8]`][byteslice]) z bajtów, więc ta funkcja konwertuje między nimi.Jednak nie wszystkie segmenty bajtów są prawidłowymi ciągami: ciągi muszą być poprawnymi UTF-8.
    /// Podczas tej konwersji `from_utf8_lossy()` zamieni wszelkie nieprawidłowe sekwencje UTF-8 na [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], które wygląda następująco:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Jeśli jesteś pewien, że segment bajtów jest prawidłowy UTF-8 i nie chcesz ponosić narzutu konwersji, istnieje niebezpieczna wersja tej funkcji, [`from_utf8_unchecked`], która zachowuje się tak samo, ale pomija sprawdzanie.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ta funkcja zwraca [`Cow<'a, str>`].Jeśli nasz fragment bajtu jest nieprawidłowy UTF-8, musimy wstawić znaki zastępcze, które zmienią rozmiar ciągu, a co za tym idzie, będą wymagały `String`.
    /// Ale jeśli jest już ważny UTF-8, nie potrzebujemy nowego przydziału.
    /// Ten typ zwrotu pozwala nam obsłużyć oba przypadki.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // kilka bajtów w vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Niepoprawne bajty:
    ///
    /// ```
    /// // niektóre nieprawidłowe bajty
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Dekoduj kodowany w UTF-16 vector `v` do `String`, zwracając [`Err`], jeśli `v` zawiera jakiekolwiek nieprawidłowe dane.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Nie można tego zrobić za pomocą funkcji collect: <Result<_, _>> () ze względu na wydajność.
        // FIXME: funkcję można uprościć ponownie po zamknięciu #48994.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Dekoduj zakodowany w UTF-16 wycinek `v` do `String`, zastępując nieprawidłowe dane [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// W przeciwieństwie do [`from_utf8_lossy`], który zwraca [`Cow<'a, str>`], `from_utf16_lossy` zwraca `String`, ponieważ konwersja UTF-16 na UTF-8 wymaga alokacji pamięci.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Rozkłada `String` na jego surowe komponenty.
    ///
    /// Zwraca nieprzetworzony wskaźnik do danych źródłowych, długość ciągu (w bajtach) i przydzieloną pojemność danych (w bajtach).
    /// Są to te same argumenty w tej samej kolejności, co argumenty [`from_raw_parts`].
    ///
    /// Po wywołaniu tej funkcji dzwoniący jest odpowiedzialny za pamięć wcześniej zarządzaną przez `String`.
    /// Jedynym sposobem, aby to zrobić, jest przekonwertowanie surowego wskaźnika, długości i pojemności z powrotem na `String` z funkcją [`from_raw_parts`], umożliwiając destruktorowi wykonanie czyszczenia.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Tworzy nowy `String` na podstawie długości, pojemności i wskaźnika.
    ///
    /// # Safety
    ///
    /// Jest to wysoce niebezpieczne ze względu na liczbę niezmienników, które nie są sprawdzane:
    ///
    /// * Pamięć w `buf` musi być wcześniej przydzielona przez ten sam alokator, z którego korzysta biblioteka standardowa, z wymaganym wyrównaniem dokładnie 1.
    /// * `length` musi być mniejsze lub równe `capacity`.
    /// * `capacity` musi mieć prawidłową wartość.
    /// * Pierwsze bajty `length` w `buf` muszą być poprawnymi UTF-8.
    ///
    /// Naruszenie tych zasad może spowodować problemy, takie jak uszkodzenie wewnętrznych struktur danych alokatora.
    ///
    /// Własność `buf` jest skutecznie przenoszona na `String`, który może następnie zwolnić, ponownie przydzielić lub zmienić zawartość pamięci wskazywaną przez wskaźnik.
    /// Upewnij się, że nic innego nie używa wskaźnika po wywołaniu tej funkcji.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Zaktualizuj to po ustabilizowaniu vec_into_raw_parts.
    ///     // Zapobiegaj automatycznemu upuszczaniu danych ciągu
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Konwertuje vector bajtów na `String` bez sprawdzania, czy ciąg zawiera prawidłowe UTF-8.
    ///
    /// Więcej informacji można znaleźć w bezpiecznej wersji [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna, ponieważ nie sprawdza, czy przekazane do niej bajty są prawidłowe UTF-8.
    /// Jeśli to ograniczenie zostanie naruszone, może to spowodować problemy z bezpieczeństwem pamięci u użytkowników future `String`, ponieważ reszta biblioteki standardowej zakłada, że `String`s są poprawnymi UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // kilka bajtów w vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Konwertuje `String` na bajt vector.
    ///
    /// To pochłania `String`, więc nie musimy kopiować jego zawartości.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Wyodrębnia kawałek łańcucha zawierający cały `String`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Konwertuje `String` na zmienny kawałek łańcucha.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Dołącza dany kawałek łańcucha na koniec tego `String`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Zwraca pojemność tego ciągu " String` w bajtach.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Zapewnia, że pojemność tego " Ciągu` jest co najmniej `additional` bajtów większa niż jego długość.
    ///
    /// Jeśli tak zdecyduje, pojemność może zostać zwiększona o więcej niż `additional` bajtów, aby zapobiec częstym ponownym przydziałom.
    ///
    ///
    /// Jeśli nie chcesz tego zachowania "at least", zapoznaj się z metodą [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics, jeśli nowa pojemność przekroczy [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// W rzeczywistości może to nie zwiększyć pojemności:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ma teraz długość 2 i pojemność 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Ponieważ mamy już dodatkowe 8 miejsc, nazywając to ...
    /// s.reserve(8);
    ///
    /// // ... w rzeczywistości nie rośnie.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Zapewnia, że pojemność tego ciągu jest o `additional` bajtów większa niż jego długość.
    ///
    /// Rozważ użycie metody [`reserve`], chyba że absolutnie wiesz lepiej niż alokator.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics, jeśli nowa pojemność przekroczy `usize`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// W rzeczywistości może to nie zwiększyć pojemności:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ma teraz długość 2 i pojemność 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Ponieważ mamy już dodatkowe 8 miejsc, nazywając to ...
    /// s.reserve_exact(8);
    ///
    /// // ... w rzeczywistości nie rośnie.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Próbuje zarezerwować pojemność dla co najmniej `additional` więcej elementów do wstawienia w podanym `String`.
    /// Kolekcja może zarezerwować więcej miejsca, aby uniknąć częstych ponownych przydziałów.
    /// Po wywołaniu `reserve` pojemność będzie większa lub równa `self.len() + additional`.
    /// Nic nie robi, jeśli pojemność jest już wystarczająca.
    ///
    /// # Errors
    ///
    /// W przypadku przepełnienia zdolności produkcyjnej lub alokatora zgłasza awarię, zwracany jest błąd.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Wstępnie zarezerwuj pamięć, wychodząc, jeśli nie możemy
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Teraz wiemy, że to nie może OOM w środku naszej złożonej pracy
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Próbuje zarezerwować minimalną pojemność dla dokładnie `additional` większej liczby elementów do wstawienia w podanym `String`.
    ///
    /// Po wywołaniu `reserve_exact` pojemność będzie większa lub równa `self.len() + additional`.
    /// Nic nie robi, jeśli pojemność jest już wystarczająca.
    ///
    /// Należy zauważyć, że osoba dokonująca alokacji może zapewnić kolekcji więcej miejsca, niż żąda.
    /// Dlatego nie można zakładać, że pojemność jest dokładnie minimalna.
    /// Preferuj `reserve`, jeśli spodziewane są wstawienia future.
    ///
    /// # Errors
    ///
    /// W przypadku przepełnienia zdolności produkcyjnej lub alokatora zgłasza awarię, zwracany jest błąd.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Wstępnie zarezerwuj pamięć, wychodząc, jeśli nie możemy
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Teraz wiemy, że to nie może OOM w środku naszej złożonej pracy
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Zmniejsza pojemność tego `String`, aby dopasować go do jego długości.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Zmniejsza pojemność `String` z dolną granicą.
    ///
    /// Pojemność pozostanie co najmniej tak duża, jak zarówno długość, jak i dostarczona wartość.
    ///
    ///
    /// Jeśli aktualna pojemność jest mniejsza niż dolna granica, nie można tego zrobić.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Dołącza dane [`char`] na koniec tego `String`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Zwraca fragment bajtów zawartości tego ciągu " String`.
    ///
    /// Odwrotnością tej metody jest [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Skraca `String` do określonej długości.
    ///
    /// Jeśli `new_len` jest większe niż bieżąca długość łańcucha, nie ma to żadnego wpływu.
    ///
    ///
    /// Zauważ, że ta metoda nie ma wpływu na przydzieloną pojemność ciągu
    ///
    /// # Panics
    ///
    /// Panics, jeśli `new_len` nie leży na granicy [`char`].
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Usuwa ostatni znak z bufora ciągów i zwraca go.
    ///
    /// Zwraca [`None`], jeśli ten `String` jest pusty.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Usuwa [`char`] z tego `String` na pozycji bajtu i zwraca go.
    ///
    /// Jest to operacja *O*(*n*), ponieważ wymaga skopiowania każdego elementu w buforze.
    ///
    /// # Panics
    ///
    /// Panics, jeśli `idx` jest większe lub równe długości " ciągu` lub jeśli nie leży na granicy [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Usuń wszystkie dopasowania wzorca `pat` w `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Dopasowania będą wykrywane i usuwane iteracyjnie, więc w przypadku nakładania się wzorców usuwany jest tylko pierwszy wzorzec:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // BEZPIECZEŃSTWO: początek i koniec będą miały granicę utf8 bajtów na
        // the Searcher docs
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Zachowuje tylko znaki określone w predykacie.
    ///
    /// Innymi słowy, usuń wszystkie znaki `c` tak, aby `f(c)` zwracało `false`.
    /// Ta metoda działa w miejscu, odwiedzając każdy znak dokładnie raz w pierwotnej kolejności i zachowując kolejność zachowanych znaków.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Dokładna kolejność może być przydatna do śledzenia stanu zewnętrznego, na przykład indeksu.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Wskaż idx na następny znak
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Wstawia znak do tego `String` na pozycji bajtu.
    ///
    /// Jest to operacja *O*(*n*), ponieważ wymaga skopiowania każdego elementu w buforze.
    ///
    /// # Panics
    ///
    /// Panics, jeśli `idx` jest większe niż długość " String` lub jeśli nie leży na granicy [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Wstawia kawałek łańcucha do tego `String` na pozycji bajtu.
    ///
    /// Jest to operacja *O*(*n*), ponieważ wymaga skopiowania każdego elementu w buforze.
    ///
    /// # Panics
    ///
    /// Panics, jeśli `idx` jest większe niż długość " String` lub jeśli nie leży na granicy [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Zwraca zmienne odniesienie do zawartości tego `String`.
    ///
    /// # Safety
    ///
    /// Ta funkcja jest niebezpieczna, ponieważ nie sprawdza, czy przekazane do niej bajty są prawidłowe UTF-8.
    /// Jeśli to ograniczenie zostanie naruszone, może to spowodować problemy z bezpieczeństwem pamięci u użytkowników future `String`, ponieważ reszta biblioteki standardowej zakłada, że `String`s są poprawnymi UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Zwraca długość tego `String` w bajtach, a nie w [`char`] s lub grafemach.
    /// Innymi słowy, może nie być tym, co człowiek uważa za długość struny.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Zwraca `true`, jeśli ten `String` ma długość równą zero, lub `false` w przeciwnym razie.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Dzieli ciąg na dwie części pod podanym indeksem bajtów.
    ///
    /// Zwraca nowo przydzielony `String`.
    /// `self` zawiera bajty `[0, at)`, a zwrócony `String` zawiera bajty `[at, len)`.
    /// `at` musi znajdować się na granicy punktu kodowego UTF-8.
    ///
    /// Zwróć uwagę, że pojemność `self` się nie zmienia.
    ///
    /// # Panics
    ///
    /// Panics, jeśli `at` nie znajduje się na granicy punktu kodowego `UTF-8` lub jeśli znajduje się poza ostatnim punktem kodowym ciągu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Obcina ten `String`, usuwając całą zawartość.
    ///
    /// Chociaż oznacza to, że `String` będzie miał długość równą zero, nie wpływa to na jego pojemność.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Tworzy opróżniający iterator, który usuwa określony zakres w `String` i zwraca usunięty `chars`.
    ///
    ///
    /// Note: Zakres elementów jest usuwany, nawet jeśli iterator nie jest używany do końca.
    ///
    /// # Panics
    ///
    /// Panics, jeśli punkt początkowy lub punkt końcowy nie leży na granicy [`char`] lub jeśli są poza granicami.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Usuń zakres aż do β z łańcucha
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Pełny zakres czyści ciąg
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Bezpieczeństwo pamięci
        //
        // Wersja String Drain nie ma problemów związanych z bezpieczeństwem pamięci w wersji vector.
        // Dane to zwykłe bajty.
        // Ponieważ usuwanie zakresu odbywa się w Drop, jeśli iterator Drain zostanie wyciekły, usunięcie nie nastąpi.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Weź dwa jednoczesne pożyczki.
        // Ciąg &mut nie będzie dostępny, dopóki iteracja nie zostanie zakończona, w Drop.
        let self_ptr = self as *mut _;
        // BEZPIECZEŃSTWO: `slice::range` i `is_char_boundary` wykonują odpowiednie kontrole granic.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Usuwa określony zakres w ciągu i zastępuje go podanym ciągiem.
    /// Podany ciąg nie musi mieć takiej samej długości jak zakres.
    ///
    /// # Panics
    ///
    /// Panics, jeśli punkt początkowy lub punkt końcowy nie leży na granicy [`char`] lub jeśli są poza granicami.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Zastąp zakres aż do β z ciągu
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Bezpieczeństwo pamięci
        //
        // Funkcja Replace_range nie ma problemów związanych z bezpieczeństwem pamięci w złączu vector.
        // wersji vector.Dane to zwykłe bajty.

        // OSTRZEŻENIE: wstawienie tej zmiennej byłoby niezdrowe (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // OSTRZEŻENIE: wstawienie tej zmiennej byłoby niezdrowe (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Ponowne użycie `range` byłoby niewłaściwe (#81138) Zakładamy, że granice zgłaszane przez `range` pozostają takie same, ale kontradyktoryjne implementacje mogą się zmieniać między wywołaniami
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Konwertuje ten `String` na [`Box`]`<`[`str`] `>`.
    ///
    /// Spowoduje to zmniejszenie nadmiaru pojemności.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Zwraca wycinek [`u8`] s bajtów, które próbowano przekonwertować na `String`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // niektóre nieprawidłowe bajty w vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Zwraca bajty, które próbowano przekonwertować na `String`.
    ///
    /// Ta metoda jest starannie opracowana, aby uniknąć alokacji.
    /// Zużywa błąd, przenosząc bajty, dzięki czemu nie trzeba tworzyć kopii bajtów.
    ///
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // niektóre nieprawidłowe bajty w vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Pobierz `Utf8Error`, aby uzyskać więcej informacji o niepowodzeniu konwersji.
    ///
    /// Typ [`Utf8Error`] dostarczony przez [`std::str`] reprezentuje błąd, który może wystąpić podczas konwersji wycinka [`u8`] s na [`&str`].
    /// W tym sensie jest to odpowiednik `FromUtf8Error`.
    /// Zobacz jego dokumentację, aby uzyskać więcej informacji na temat korzystania z niego.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// // niektóre nieprawidłowe bajty w vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // pierwszy bajt jest tutaj nieprawidłowy
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Ponieważ iterujemy po `String`s, możemy uniknąć co najmniej jednej alokacji, pobierając pierwszy ciąg z iteratora i dołączając do niego wszystkie kolejne ciągi.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Ponieważ iterujemy nad CoW, możemy (potentially) uniknąć przynajmniej jednej alokacji, zdobywając pierwszy przedmiot i dodając do niego wszystkie kolejne.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Wygoda oznacza, że deleguje do impl for `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Tworzy pusty `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementuje operator `+` do łączenia dwóch ciągów.
///
/// To zużywa `String` po lewej stronie i ponownie wykorzystuje jego bufor (zwiększając go, jeśli to konieczne).
/// Ma to na celu uniknięcie przydzielania nowego `String` i kopiowania całej zawartości podczas każdej operacji, co prowadziłoby do czasu działania *O*(*n*^ 2) podczas budowania ciągu *n*-bajtowego przez wielokrotne łączenie.
///
///
/// Ciąg po prawej stronie jest tylko pożyczony;jego zawartość jest kopiowana do zwracanego `String`.
///
/// # Examples
///
/// Łączenie dwóch argumentów " String` pobiera pierwszy ze względu na wartość i pożycza drugi:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` jest przeniesiony i nie można go już tutaj używać.
/// ```
///
/// Jeśli chcesz nadal używać pierwszego `String`, możesz go sklonować i zamiast tego dołączyć do klona:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` nadal obowiązuje tutaj.
/// ```
///
/// Łączenie plasterków `&str` można wykonać, konwertując pierwszy na `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementuje operator `+=` do dołączania do `String`.
///
/// Zachowuje się tak samo jak metoda [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Alias typu dla [`Infallible`].
///
/// Ten alias istnieje w celu zapewnienia zgodności z poprzednimi wersjami i może ostatecznie zostać wycofany.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait do konwersji wartości na `String`.
///
/// Ten trait jest automatycznie implementowany dla każdego typu, który implementuje [`Display`] trait.
/// W związku z tym `ToString` nie powinien być implementowany bezpośrednio:
/// [`Display`] należy zaimplementować zamiast tego, a implementację `ToString` otrzymasz za darmo.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Konwertuje podaną wartość na `String`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// W tej implementacji metoda `to_string` panics, jeśli implementacja `Display` zwróci błąd.
/// Wskazuje to na niepoprawną implementację `Display`, ponieważ `fmt::Write for String` sam nigdy nie zwraca błędu.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Powszechną wskazówką jest, aby nie wbudowywać funkcji ogólnych.
    // Jednak usunięcie `#[inline]` z tej metody powoduje regresje, których nie można pominąć.
    // Zobacz <https://github.com/rust-lang/rust/pull/74852>, ostatnia próba usunięcia go.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Konwertuje `&mut str` na `String`.
    ///
    /// Wynik jest przydzielany na stercie.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test ściąga libstd, co powoduje tutaj błędy
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Konwertuje podany wycinek `str` w pudełku na `String`.
    /// Warto zauważyć, że plaster `str` jest własnością.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Konwertuje dane `String` na zapakowany wycinek `str`, którego właścicielem jest.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Konwertuje kawałek ciągu na wariant pożyczony.
    /// Nie jest wykonywana żadna alokacja sterty, a ciąg nie jest kopiowany.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Konwertuje String na wariant posiadany.
    /// Nie jest wykonywana żadna alokacja sterty, a ciąg nie jest kopiowany.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Konwertuje odwołanie typu String na wariant pożyczony.
    /// Nie jest wykonywana żadna alokacja sterty, a ciąg nie jest kopiowany.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Konwertuje podane `String` na vector `Vec`, który przechowuje wartości typu `u8`.
    ///
    /// # Examples
    ///
    /// Podstawowe użycie:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Drenujący iterator dla `String`.
///
/// Ta struktura jest tworzona metodą [`drain`] na [`String`].
/// Więcej informacji można znaleźć w dokumentacji.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Będzie używany jako&'a mut String w destruktorze
    string: *mut String,
    /// Początek części do usunięcia
    start: usize,
    /// Koniec części do usunięcia
    end: usize,
    /// Aktualny pozostały zakres do usunięcia
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Użyj Vec::drain.
            // "Reaffirm" granica sprawdza, aby uniknąć ponownego wstawienia kodu panic.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Zwraca pozostały (pod) ciąg tego iteratora jako wycinek.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: odkomentuj AsRef implikuje poniżej podczas stabilizacji.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Odkomentuj podczas stabilizacji `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>dla Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> dla Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}