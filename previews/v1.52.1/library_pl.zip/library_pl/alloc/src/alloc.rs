//! Interfejsy API alokacji pamięci

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Są to magiczne symbole, które można nazwać globalnym alokatorem.rustc generuje je w celu wywołania `__rg_alloc` itp.
    // jeśli istnieje atrybut `#[global_allocator]` (kod rozszerzający to makro atrybutu generuje te funkcje) lub aby wywołać domyślne implementacje w libstd (`__rdl_alloc` itp.
    //
    // w `library/std/src/alloc.rs`) w przeciwnym razie.
    // rustc fork z LLVM również w specjalnych przypadkach te nazwy funkcji, aby móc je zoptymalizować, jak odpowiednio `malloc`, `realloc` i `free`.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Globalny alokator pamięci.
///
/// Ten typ implementuje [`Allocator`] trait przez przekazywanie wywołań do alokatora zarejestrowanego z atrybutem `#[global_allocator]`, jeśli taki istnieje, lub domyślnym `std` crate.
///
///
/// Note: chociaż ten typ jest niestabilny, do zapewnianych przez niego funkcji można uzyskać dostęp za pośrednictwem [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Przydziel pamięć za pomocą globalnego alokatora.
///
/// Ta funkcja przekazuje wywołania do metody [`GlobalAlloc::alloc`] alokatora zarejestrowanego za pomocą atrybutu `#[global_allocator]`, jeśli taki istnieje, lub wartości domyślnej `std` crate.
///
///
/// Oczekuje się, że ta funkcja zostanie wycofana na korzyść metody `alloc` typu [`Global`], gdy ona i [`Allocator`] trait staną się stabilne.
///
/// # Safety
///
/// Zobacz [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Zwolnij pamięć za pomocą globalnego alokatora.
///
/// Ta funkcja przekazuje wywołania do metody [`GlobalAlloc::dealloc`] alokatora zarejestrowanego za pomocą atrybutu `#[global_allocator]`, jeśli taki istnieje, lub wartości domyślnej `std` crate.
///
///
/// Oczekuje się, że ta funkcja zostanie wycofana na korzyść metody `dealloc` typu [`Global`], gdy ona i [`Allocator`] trait staną się stabilne.
///
/// # Safety
///
/// Zobacz [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Przydziel ponownie pamięć za pomocą globalnego alokatora.
///
/// Ta funkcja przekazuje wywołania do metody [`GlobalAlloc::realloc`] alokatora zarejestrowanego za pomocą atrybutu `#[global_allocator]`, jeśli taki istnieje, lub wartości domyślnej `std` crate.
///
///
/// Oczekuje się, że ta funkcja zostanie wycofana na korzyść metody `realloc` typu [`Global`], gdy ona i [`Allocator`] trait staną się stabilne.
///
/// # Safety
///
/// Zobacz [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Przydziel pamięć zainicjowaną przez zero za pomocą globalnego alokatora.
///
/// Ta funkcja przekazuje wywołania do metody [`GlobalAlloc::alloc_zeroed`] alokatora zarejestrowanego za pomocą atrybutu `#[global_allocator]`, jeśli taki istnieje, lub wartości domyślnej `std` crate.
///
///
/// Oczekuje się, że ta funkcja zostanie wycofana na korzyść metody `alloc_zeroed` typu [`Global`], gdy ona i [`Allocator`] trait staną się stabilne.
///
/// # Safety
///
/// Zobacz [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // BEZPIECZEŃSTWO: `layout` ma rozmiar niezerowy,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // BEZPIECZEŃSTWO: tak samo jak `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // BEZPIECZEŃSTWO: `new_size` jest niezerowe, ponieważ `old_size` jest większe lub równe `new_size`
            // zgodnie z wymogami bezpieczeństwa.Dzwoniący musi przestrzegać innych warunków
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` prawdopodobnie sprawdza `new_size >= old_layout.size()` lub coś podobnego.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // BEZPIECZEŃSTWO: ponieważ `new_layout.size()` musi być większe lub równe `old_size`,
            // zarówno stary, jak i nowy przydział pamięci są ważne dla odczytów i zapisów dla `old_size` bajtów.
            // Ponadto, ponieważ stara alokacja nie została jeszcze cofnięta, nie może pokrywać się z `new_ptr`.
            // Dzięki temu połączenie z `copy_nonoverlapping` jest bezpieczne.
            // Osoba dzwoniąca musi przestrzegać umowy dotyczącej bezpieczeństwa dla `dealloc`.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // BEZPIECZEŃSTWO: `layout` ma rozmiar niezerowy,
            // dzwoniący musi przestrzegać innych warunków
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać wszystkich warunków
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać wszystkich warunków
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // BEZPIECZEŃSTWO: dzwoniący musi przestrzegać warunków
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // BEZPIECZEŃSTWO: `new_size` jest niezerowe.Dzwoniący musi przestrzegać innych warunków
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` prawdopodobnie sprawdza `new_size <= old_layout.size()` lub coś podobnego.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // BEZPIECZEŃSTWO: ponieważ `new_size` musi być mniejszy lub równy `old_layout.size()`,
            // zarówno stary, jak i nowy przydział pamięci są ważne dla odczytów i zapisów dla `new_size` bajtów.
            // Ponadto, ponieważ stara alokacja nie została jeszcze cofnięta, nie może pokrywać się z `new_ptr`.
            // Dzięki temu połączenie z `copy_nonoverlapping` jest bezpieczne.
            // Osoba dzwoniąca musi przestrzegać umowy dotyczącej bezpieczeństwa dla `dealloc`.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Alokator dla unikalnych wskaźników.
// Ta funkcja nie może się rozwijać.Jeśli tak się stanie, kodowanie MIR nie powiedzie się.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Ten podpis musi być taki sam jak `Box`, w przeciwnym razie dojdzie do ICE.
// Gdy dodawany jest dodatkowy parametr do `Box` (taki jak `A: Allocator`), należy go również dodać tutaj.
// Na przykład, jeśli `Box` zostanie zmieniony na `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, ta funkcja również musi zostać zmieniona na `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Procedura obsługi błędów alokacji

extern "Rust" {
    // To jest magiczny symbol wywołujący globalną procedurę obsługi błędów alokacji.
    // rustc generuje go, aby wywołać `__rg_oom`, jeśli istnieje `#[alloc_error_handler]`, lub w przeciwnym razie wywołać domyślne implementacje poniżej (`__rdl_oom`).
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Przerwanie w przypadku błędu lub niepowodzenia alokacji pamięci.
///
/// Osoby wywołujące interfejsy API alokacji pamięci, które chcą przerwać obliczenia w odpowiedzi na błąd alokacji, są zachęcane do wywoływania tej funkcji zamiast bezpośredniego wywoływania `panic!` lub podobnego.
///
///
/// Domyślnym zachowaniem tej funkcji jest wydrukowanie komunikatu o błędzie standardowym i przerwanie procesu.
/// Można go zastąpić [`set_alloc_error_hook`] i [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Do testu alokacji `std::alloc::handle_alloc_error` może być używany bezpośrednio.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // wywołane przez wygenerowany `__rust_alloc_error_handler`

    // jeśli nie ma `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // jeśli jest `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Specjalizuj klony we wstępnie przydzielonej, niezainicjowanej pamięci.
/// Używany przez `Box::clone` i `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Przydzielenie *first* może pozwolić optymalizatorowi na utworzenie sklonowanej wartości w miejscu, z pominięciem lokalnego i przeniesieniem.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Zawsze możemy kopiować na miejscu, nigdy nie angażując wartości lokalnej.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}