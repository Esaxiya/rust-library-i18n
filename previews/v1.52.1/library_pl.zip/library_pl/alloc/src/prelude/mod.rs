//! Alokacja Prelude
//!
//! Celem tego modułu jest złagodzenie importu często używanych elementów `alloc` crate poprzez dodanie importu globalnego do górnej części modułów:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;