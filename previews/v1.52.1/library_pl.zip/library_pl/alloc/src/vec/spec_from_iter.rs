use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specjalizacja trait używana dla Vec::from_iter
///
/// ## Wykres delegacji:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Typowym przypadkiem jest przekazanie vector do funkcji, która natychmiast zbiera się ponownie do vector.
        // Możemy to zewrzeć, jeśli IntoIter nie został w ogóle zaawansowany.
        // Kiedy jest zaawansowana, możemy również ponownie wykorzystać pamięć i przenieść dane na przód.
        // Ale robimy to tylko wtedy, gdy wynikowy Vec nie miałby więcej niewykorzystanej pojemności niż utworzenie go za pomocą generycznej implementacji FromIterator.
        //
        // To ograniczenie nie jest bezwzględnie konieczne, ponieważ zachowanie Vec w zakresie alokacji jest celowo nieokreślone.
        // Ale to konserwatywny wybór.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // musi delegować do spec_extend(), ponieważ sam extend() deleguje do spec_from dla pustych Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Wykorzystuje `iterator.as_slice().to_vec()`, ponieważ spec_extend musi podjąć więcej kroków, aby uzasadnić ostateczną pojemność i długość, a tym samym wykonać więcej pracy.
// `to_vec()` bezpośrednio przydziela prawidłową kwotę i dokładnie ją wypełnia.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): w przypadku cfg(test) nieodłączna metoda `[T]::to_vec`, która jest wymagana dla tej definicji metody, nie jest dostępna.
    // Zamiast tego użyj funkcji `slice::to_vec`, która jest dostępna tylko z cfg(test) NB, patrz moduł slice::hack w slice.rs, aby uzyskać więcej informacji
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}