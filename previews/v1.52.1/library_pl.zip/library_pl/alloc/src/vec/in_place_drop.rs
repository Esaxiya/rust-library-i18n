use core::ptr::{self};
use core::slice::{self};

// Struktura pomocnicza dla iteracji w miejscu, która porzuca docelowy wycinek iteracji, tj. Nagłówek.
// Fragment źródłowy (ogon) jest upuszczany przez IntoIter.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}