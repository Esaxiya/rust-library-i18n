use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Znacznik specjalizacji do zbierania potoku iteratora do Vec podczas ponownego wykorzystania alokacji źródła, tj
/// wykonanie rurociągu na miejscu.
///
/// Element nadrzędny SourceIter trait jest niezbędny, aby funkcja specjalizująca się mogła uzyskać dostęp do alokacji, która ma być ponownie wykorzystana.
/// Ale to nie wystarczy, aby specjalizacja była ważna.
/// Zobacz dodatkowe ograniczenia na impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Wewnętrzne std SourceIter/InPlaceIterable traits są realizowane tylko przez łańcuchy adaptera <Adapter<Adapter<IntoIter>>> (wszystkie należące do core/std).
// Dodatkowe ograniczenia implementacji adaptera (poza `impl<I: Trait> Trait for Adapter<I>`) zależą tylko od innych traits już oznaczonych jako specjalizacja traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. znacznik nie zależy od czasów życia typów podanych przez użytkownika.Modulo the Copy hole, od którego zależy już kilka innych specjalizacji.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Dodatkowe wymagania, których nie można wyrazić za pomocą trait bounds.Zamiast tego opieramy się na const eval:
        // a) brak ZST, ponieważ nie byłoby alokacji do ponownego wykorzystania, a arytmetyka wskaźników byłaby panic b) dopasowanie rozmiaru zgodnie z wymaganiami kontraktu Alloc c) dopasowanie dopasowania zgodnie z wymaganiami kontraktu Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // powrót do bardziej ogólnych implementacji
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // używaj try-fold od
        // - wektoryzuje się lepiej dla niektórych adapterów iteratorów
        // - w przeciwieństwie do większości wewnętrznych metod iteracji, wymaga tylko samodzielnego &mut
        // - pozwala nam przeciągnąć wskaźnik zapisu przez jego wnętrze i odzyskać go na końcu
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteracja się powiodła, nie upuszczaj głowy
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // sprawdź, czy kontrakt SourceIter został dotrzymany zastrzeżenie: jeśli nie, możemy nawet nie dotrzeć do tego punktu
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // check InPlaceIterable kontrakt.Jest to możliwe tylko wtedy, gdy iterator w ogóle przesuwał wskaźnik do źródła.
        // Jeśli korzysta z niesprawdzonego dostępu za pośrednictwem TrustedRandomAccess, wskaźnik źródła pozostanie w swoim początkowym położeniu i nie możemy go użyć jako odniesienia
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // upuść wszystkie pozostałe wartości na końcu źródła, ale zapobiegnij spadkowi alokacji, gdy IntoIter wyjdzie poza zakres, jeśli drop panics, wtedy również wyciekamy wszystkie elementy zebrane do dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // kontraktu InPlaceIterable nie można tutaj dokładnie zweryfikować, ponieważ try_fold ma wyłączne odniesienie do wskaźnika źródła, wszystko, co możemy zrobić, to sprawdzić, czy nadal znajduje się w zakresie
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}