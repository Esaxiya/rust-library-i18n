//! Ciągła tablica z możliwością powiększania z zawartością przydzieloną na sterty, zapisana w `Vec<T>`.
//!
//! Wektory V mają indeksowanie `O(1)`, amortyzowane wypychanie `O(1)` (do końca) i popychanie `O(1)` (od końca).
//!
//!
//! Vectors zapewniają, że nigdy nie przydzielą więcej niż `isize::MAX` bajtów.
//!
//! # Examples
//!
//! Możesz jawnie utworzyć [`Vec`] za pomocą [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... lub przy pomocy makra [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // dziesięć zer
//! ```
//!
//! Możesz [`push`] wartości na końcu vector (co spowoduje powiększenie vector w razie potrzeby):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping wartości działa w podobny sposób:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors obsługują również indeksowanie (przez [`Index`] i [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Ciągła tablica z możliwością powiększania, zapisywana jako `Vec<T>` i wymawiana jako 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Makro [`vec!`] ułatwia inicjalizację:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Może również zainicjować każdy element `Vec<T>` podaną wartością.
/// Może to być bardziej wydajne niż wykonywanie alokacji i inicjalizacji w oddzielnych krokach, szczególnie podczas inicjowania vector zer:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Poniższe jest równoważne, ale potencjalnie wolniejsze:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Aby uzyskać więcej informacji, zobacz [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Użyj `Vec<T>` jako wydajnego stosu:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Wydruki 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Typ `Vec` umożliwia dostęp do wartości według indeksu, ponieważ implementuje [`Index`] trait.Przykład będzie bardziej wyraźny:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // wyświetli '2'
/// ```
///
/// Jednak bądź ostrożny: jeśli spróbujesz uzyskać dostęp do indeksu, którego nie ma w `Vec`, twoje oprogramowanie panic!Nie możesz tego zrobić:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Użyj [`get`] i [`get_mut`], jeśli chcesz sprawdzić, czy indeks znajduje się w `Vec`.
///
/// # Slicing
///
/// `Vec` można modyfikować.Z drugiej strony plasterki są obiektami tylko do odczytu.
/// Aby uzyskać [slice][prim@slice], użyj [`&`].Przykład:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... i to wszystko!
/// // możesz to również zrobić w ten sposób:
/// let u: &[usize] = &v;
/// // lub tak:
/// let u: &[_] = &v;
/// ```
///
/// W Rust częściej przekazuje się plasterki jako argumenty niż vectors, gdy chcesz tylko zapewnić dostęp do odczytu.To samo dotyczy [`String`] i [`&str`].
///
/// # Pojemność i realokacja
///
/// Pojemność vector to ilość miejsca przydzielonego na dowolne elementy future, które zostaną dodane do vector.Nie należy tego mylić z *długością* vector, która określa liczbę rzeczywistych elementów w vector.
/// Jeśli długość vector przekroczy jego pojemność, jego pojemność zostanie automatycznie zwiększona, ale jego elementy będą musiały zostać ponownie przydzielone.
///
/// Na przykład vector o pojemności 10 i długości 0 byłby pustym vector z miejscem na 10 dodatkowych elementów.Wepchnięcie 10 lub mniej elementów do vector nie zmieni jego pojemności ani nie spowoduje realokacji.
/// Jeśli jednak długość vector zostanie zwiększona do 11, konieczne będzie ponowne przydzielenie, co może być powolne.Z tego powodu zaleca się używanie [`Vec::with_capacity`], gdy tylko jest to możliwe, aby określić, jak duży ma być vector.
///
/// # Guarantees
///
/// Ze względu na swój niezwykle fundamentalny charakter `Vec` daje wiele gwarancji na temat swojego projektu.Zapewnia to, że w ogólnym przypadku jest to tak niskie, jak to tylko możliwe, i może być poprawnie manipulowane w prymitywny sposób przez niebezpieczny kod.Należy pamiętać, że te gwarancje dotyczą niekwalifikowanego `Vec<T>`.
/// Jeśli zostaną dodane dodatkowe parametry typu (np. W celu obsługi niestandardowych alokatorów), zastąpienie ich wartości domyślnych może zmienić zachowanie.
///
/// Zasadniczo `Vec` jest i zawsze będzie triolą (wskaźnik, pojemność, długość).Nie więcej nie mniej.Kolejność tych pól jest całkowicie nieokreślona i należy użyć odpowiednich metod, aby je zmodyfikować.
/// Wskaźnik nigdy nie będzie pusty, więc ten typ jest zoptymalizowany pod kątem wskaźnika zerowego.
///
/// Jednak wskaźnik może w rzeczywistości nie wskazywać na przydzieloną pamięć.
/// W szczególności, jeśli skonstruujesz `Vec` o pojemności 0 za pośrednictwem [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] lub wywołując [`shrink_to_fit`] na pustym Vec, nie przydzieli pamięci.Podobnie, jeśli przechowujesz typy o zerowej wielkości wewnątrz `Vec`, nie przydzieli dla nich miejsca.
/// *Należy pamiętać, że w tym przypadku `Vec` może nie zgłosić [`capacity`] równego 0*.
/// `Vec` przydzieli wtedy i tylko wtedy, gdy [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Ogólnie szczegóły alokacji `Vec` są bardzo subtelne-jeśli zamierzasz przydzielić pamięć za pomocą `Vec` i użyć jej do czegoś innego (albo do przekazania do niebezpiecznego kodu, albo do zbudowania własnej kolekcji opartej na pamięci), upewnij się, że aby zwolnić tę pamięć, używając `from_raw_parts` do odzyskania `Vec`, a następnie upuszczając ją.
///
/// Jeśli `Vec`*ma* przydzieloną pamięć, to pamięć, na którą wskazuje, znajduje się na stercie (zgodnie z definicją alokatora Rust jest skonfigurowany do użycia domyślnie), a jego wskaźnik wskazuje na zainicjowane [`len`], ciągłe elementy w kolejności (co byś zrobił zobacz, czy wymusiłeś to na wycinek), po którym następuje [`capacity`]`,`[`len`] logicznie niezainicjowane, ciągłe elementy.
///
///
/// vector zawierający elementy `'a'` i `'b'` o pojemności 4 można wizualizować jak poniżej.Górna część to struktura `Vec`, zawiera wskaźnik do nagłówka alokacji w stercie, długości i pojemności.
/// Dolna część to alokacja na stercie, ciągłym bloku pamięci.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** reprezentuje pamięć, która nie została zainicjowana, patrz [`MaybeUninit`].
/// - Note: ABI nie jest stabilny, a `Vec` nie daje żadnych gwarancji co do układu pamięci (w tym kolejności pól).
///
/// `Vec` nigdy nie wykona "small optimization", w którym elementy są faktycznie przechowywane na stosie z dwóch powodów:
///
/// * Utrudniłoby to niebezpiecznemu kodowi poprawne manipulowanie `Vec`.Zawartość `Vec` nie miałaby stabilnego adresu, gdyby była tylko przenoszona, i byłoby trudniej określić, czy `Vec` faktycznie przydzielił pamięć.
///
/// * Ukarałoby to ogólny przypadek, powodując dodatkowe odgałęzienie przy każdym dostępie.
///
/// `Vec` nigdy nie zmniejszy się automatycznie, nawet jeśli jest całkowicie pusty.Dzięki temu nie wystąpią niepotrzebne alokacje lub cofnięcia przydziałów.Opróżnienie `Vec`, a następnie zapełnienie go z powrotem do tego samego [`len`] nie powinno powodować żadnych wywołań alokatora.Jeśli chcesz zwolnić nieużywaną pamięć, użyj [`shrink_to_fit`] lub [`shrink_to`].
///
/// [`push`] a [`insert`] nigdy nie przydzieli (ponownie), jeśli zgłoszona pojemność jest wystarczająca.[`push`] i [`insert`]* * przydzielą (ponownie), jeśli [`len`]`==`[`capacity`].Oznacza to, że zgłaszana pojemność jest całkowicie dokładna i można na niej polegać.W razie potrzeby można go nawet użyć do ręcznego zwolnienia pamięci przydzielonej przez `Vec`.
/// Metody masowego wstawiania *mogą* zmienić przydział, nawet jeśli nie jest to konieczne.
///
/// `Vec` nie gwarantuje żadnej określonej strategii wzrostu w przypadku ponownego przydziału, gdy jest pełny, ani w przypadku wywołania [`reserve`].Obecna strategia jest podstawowa i może okazać się pożądane użycie niestałego czynnika wzrostu.Niezależnie od zastosowanej strategii, będzie oczywiście gwarantować *O*(1) amortyzowane [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` i [`Vec::with_capacity(n)`][`Vec::with_capacity`] wyprodukują `Vec` o dokładnie wymaganej pojemności.
/// Jeśli [`len`]`==`[`capacity`], (jak ma to miejsce w przypadku makra [`vec!`]), wówczas `Vec<T>` można przekonwertować na iz [`Box<[T]>`][owned slice] bez ponownego przydzielania lub przenoszenia elementów.
///
/// `Vec` nie nadpisze żadnych danych, które są z niego usunięte, ale także nie będzie ich specjalnie zachowywać.Jego niezainicjowana pamięć to przestrzeń magazynująca, z której może korzystać w dowolny sposób.Generalnie zrobi wszystko, co jest najbardziej wydajne lub w inny sposób łatwe do wdrożenia.Nie oczekuj, że usunięte dane zostaną usunięte ze względów bezpieczeństwa.
/// Nawet jeśli upuścisz `Vec`, jego bufor może być po prostu ponownie użyty przez inny `Vec`.
/// Nawet jeśli najpierw wyzerujesz pamięć `Vec`, może się to nie zdarzyć, ponieważ optymalizator nie uważa tego za efekt uboczny, który należy zachować.
/// Jest jednak jeden przypadek, którego nie rozwiążemy: użycie kodu `unsafe` do zapisania nadwyżki pojemności, a następnie zwiększenie dopasowanej długości jest zawsze poprawne.
///
/// Obecnie `Vec` nie gwarantuje kolejności, w jakiej elementy są upuszczane.
/// Kolejność zmieniła się w przeszłości i może się ponownie zmienić.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Metody nieodłączne
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Konstruuje nowy, pusty `Vec<T>`.
    ///
    /// vector nie będzie alokować, dopóki elementy nie zostaną do niego przesunięte.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Konstruuje nowy, pusty `Vec<T>` o określonej pojemności.
    ///
    /// vector będzie w stanie pomieścić dokładnie `capacity` elementów bez ponownego przydziału.
    /// Jeśli `capacity` ma wartość 0, vector nie przydzieli.
    ///
    /// Należy zauważyć, że chociaż zwracany vector ma określoną *pojemność*, vector będzie miał zerową *długość*.
    ///
    /// Aby uzyskać wyjaśnienie różnicy między długością a pojemnością, zobacz *[Pojemność i realokacja]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector nie zawiera żadnych elementów, chociaż może pomieścić więcej
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Wszystko to odbywa się bez ponownego przydziału ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ale może to spowodować ponowne przydzielenie vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Tworzy `Vec<T>` bezpośrednio z surowych komponentów innego vector.
    ///
    /// # Safety
    ///
    /// Jest to wysoce niebezpieczne ze względu na liczbę niezmienników, które nie są sprawdzane:
    ///
    /// * `ptr` musi być wcześniej przydzielone przez [`String`]/`Vec<T>`(przynajmniej jest wysoce prawdopodobne, że tak nie jest).
    /// * `T` musi mieć ten sam rozmiar i wyrównanie, z którym przydzielono `ptr`.
    ///   (`T` mający mniej ścisłe wyrównanie nie jest wystarczające, wyrównanie naprawdę musi być równe, aby spełnić wymóg [`dealloc`], że pamięć musi być alokowana i zwalniana w tym samym układzie).
    ///
    /// * `length` musi być mniejsze lub równe `capacity`.
    /// * `capacity` musi być pojemnością, z którą został przydzielony wskaźnik.
    ///
    /// Naruszenie tych zasad może spowodować problemy, takie jak uszkodzenie wewnętrznych struktur danych alokatora.Na przykład **nie** jest bezpieczne tworzenie `Vec<u8>` ze wskaźnika do tablicy C `char` o długości `size_t`.
    /// Nie jest również bezpieczne zbudowanie jednego z `Vec<u16>` i jego długości, ponieważ alokator dba o wyrównanie, a te dwa typy mają różne wyrównania.
    /// Bufor został przydzielony z wyrównaniem 2 (dla `u16`), ale po przekształceniu go w `Vec<u8>` zostanie cofnięty z wyrównaniem 1.
    ///
    /// Własność `ptr` jest skutecznie przenoszona na `Vec<T>`, który może następnie zwolnić, ponownie przydzielić lub zmienić zawartość pamięci wskazywaną przez wskaźnik.
    /// Upewnij się, że nic innego nie używa wskaźnika po wywołaniu tej funkcji.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Zaktualizuj to po ustabilizowaniu vec_into_raw_parts.
    ///     // Zapobiegaj uruchamianiu destruktora `v`, aby mieć pełną kontrolę nad alokacją.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Wyciągnij różne ważne informacje o `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Nadpisz pamięć na 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Złóż wszystko z powrotem w Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Konstruuje nowy, pusty `Vec<T, A>`.
    ///
    /// vector nie będzie alokować, dopóki elementy nie zostaną do niego przesunięte.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Konstruuje nowy, pusty `Vec<T, A>` o określonej pojemności z podanym alokatorem.
    ///
    /// vector będzie w stanie pomieścić dokładnie `capacity` elementów bez ponownego przydziału.
    /// Jeśli `capacity` ma wartość 0, vector nie przydzieli.
    ///
    /// Należy zauważyć, że chociaż zwracany vector ma określoną *pojemność*, vector będzie miał zerową *długość*.
    ///
    /// Aby uzyskać wyjaśnienie różnicy między długością a pojemnością, zobacz *[Pojemność i realokacja]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector nie zawiera żadnych elementów, chociaż może pomieścić więcej
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Wszystko to odbywa się bez ponownego przydziału ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ale może to spowodować ponowne przydzielenie vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Tworzy `Vec<T, A>` bezpośrednio z surowych komponentów innego vector.
    ///
    /// # Safety
    ///
    /// Jest to wysoce niebezpieczne ze względu na liczbę niezmienników, które nie są sprawdzane:
    ///
    /// * `ptr` musi być wcześniej przydzielone przez [`String`]/`Vec<T>`(przynajmniej jest wysoce prawdopodobne, że tak nie jest).
    /// * `T` musi mieć ten sam rozmiar i wyrównanie, z którym przydzielono `ptr`.
    ///   (`T` mający mniej ścisłe wyrównanie nie jest wystarczające, wyrównanie naprawdę musi być równe, aby spełnić wymóg [`dealloc`], że pamięć musi być alokowana i zwalniana w tym samym układzie).
    ///
    /// * `length` musi być mniejsze lub równe `capacity`.
    /// * `capacity` musi być pojemnością, z którą został przydzielony wskaźnik.
    ///
    /// Naruszenie tych zasad może spowodować problemy, takie jak uszkodzenie wewnętrznych struktur danych alokatora.Na przykład **nie** jest bezpieczne tworzenie `Vec<u8>` ze wskaźnika do tablicy C `char` o długości `size_t`.
    /// Nie jest również bezpieczne zbudowanie jednego z `Vec<u16>` i jego długości, ponieważ alokator dba o wyrównanie, a te dwa typy mają różne wyrównania.
    /// Bufor został przydzielony z wyrównaniem 2 (dla `u16`), ale po przekształceniu go w `Vec<u8>` zostanie cofnięty z wyrównaniem 1.
    ///
    /// Własność `ptr` jest skutecznie przenoszona na `Vec<T>`, który może następnie zwolnić, ponownie przydzielić lub zmienić zawartość pamięci wskazywaną przez wskaźnik.
    /// Upewnij się, że nic innego nie używa wskaźnika po wywołaniu tej funkcji.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Zaktualizuj to po ustabilizowaniu vec_into_raw_parts.
    ///     // Zapobiegaj uruchamianiu destruktora `v`, aby mieć pełną kontrolę nad alokacją.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Wyciągnij różne ważne informacje o `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Nadpisz pamięć na 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Złóż wszystko z powrotem w Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Rozkłada `Vec<T>` na jego surowe komponenty.
    ///
    /// Zwraca nieprzetworzony wskaźnik do danych bazowych, długość vector (w elementach) i przydzieloną pojemność danych (w elementach).
    /// Są to te same argumenty w tej samej kolejności, co argumenty [`from_raw_parts`].
    ///
    /// Po wywołaniu tej funkcji dzwoniący jest odpowiedzialny za pamięć wcześniej zarządzaną przez `Vec`.
    /// Jedynym sposobem, aby to zrobić, jest przekonwertowanie surowego wskaźnika, długości i pojemności z powrotem na `Vec` z funkcją [`from_raw_parts`], umożliwiając destruktorowi wykonanie czyszczenia.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Możemy teraz wprowadzać zmiany w komponentach, takie jak transmutowanie surowego wskaźnika do zgodnego typu.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Rozkłada `Vec<T>` na jego surowe komponenty.
    ///
    /// Zwraca nieprzetworzony wskaźnik do danych bazowych, długość vector (w elementach), przydzieloną pojemność danych (w elementach) i alokator.
    /// Są to te same argumenty w tej samej kolejności, co argumenty [`from_raw_parts_in`].
    ///
    /// Po wywołaniu tej funkcji dzwoniący jest odpowiedzialny za pamięć wcześniej zarządzaną przez `Vec`.
    /// Jedynym sposobem, aby to zrobić, jest przekonwertowanie surowego wskaźnika, długości i pojemności z powrotem na `Vec` z funkcją [`from_raw_parts_in`], umożliwiając destruktorowi wykonanie czyszczenia.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Możemy teraz wprowadzać zmiany w komponentach, takie jak transmutowanie surowego wskaźnika do zgodnego typu.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Zwraca liczbę elementów, które vector może przechowywać bez ponownego przydziału.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Rezerwuje pojemność na co najmniej `additional` więcej elementów do wstawienia w danym `Vec<T>`.
    /// Kolekcja może zarezerwować więcej miejsca, aby uniknąć częstych ponownych przydziałów.
    /// Po wywołaniu `reserve` pojemność będzie większa lub równa `self.len() + additional`.
    /// Nic nie robi, jeśli pojemność jest już wystarczająca.
    ///
    /// # Panics
    ///
    /// Panics, jeśli nowa pojemność przekracza `isize::MAX` bajtów.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Rezerwuje minimalną pojemność dla dokładnie `additional` więcej elementów do wstawienia w podanym `Vec<T>`.
    ///
    /// Po wywołaniu `reserve_exact` pojemność będzie większa lub równa `self.len() + additional`.
    /// Nic nie robi, jeśli pojemność jest już wystarczająca.
    ///
    /// Należy zauważyć, że osoba dokonująca alokacji może zapewnić kolekcji więcej miejsca, niż żąda.
    /// Dlatego nie można zakładać, że pojemność jest dokładnie minimalna.
    /// Preferuj `reserve`, jeśli spodziewane są wstawienia future.
    ///
    /// # Panics
    ///
    /// Panics, jeśli nowa pojemność przekroczy `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Próbuje zarezerwować pojemność dla co najmniej `additional` więcej elementów do wstawienia w podanym `Vec<T>`.
    /// Kolekcja może zarezerwować więcej miejsca, aby uniknąć częstych ponownych przydziałów.
    /// Po wywołaniu `try_reserve` pojemność będzie większa lub równa `self.len() + additional`.
    /// Nic nie robi, jeśli pojemność jest już wystarczająca.
    ///
    /// # Errors
    ///
    /// W przypadku przepełnienia zdolności produkcyjnej lub alokatora zgłasza awarię, zwracany jest błąd.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Wstępnie zarezerwuj pamięć, wychodząc, jeśli nie możemy
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Teraz wiemy, że to nie może OOM w środku naszej złożonej pracy
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // bardzo skomplikowane
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Próbuje zarezerwować minimalną pojemność dla dokładnie elementów `additional`, które mają być wstawione do danego `Vec<T>`.
    /// Po wywołaniu `try_reserve_exact` pojemność będzie większa lub równa `self.len() + additional`, jeśli zwraca `Ok(())`.
    ///
    /// Nic nie robi, jeśli pojemność jest już wystarczająca.
    ///
    /// Należy zauważyć, że osoba dokonująca alokacji może zapewnić kolekcji więcej miejsca, niż żąda.
    /// Dlatego nie można zakładać, że pojemność jest dokładnie minimalna.
    /// Preferuj `reserve`, jeśli spodziewane są wstawienia future.
    ///
    /// # Errors
    ///
    /// W przypadku przepełnienia zdolności produkcyjnej lub alokatora zgłasza awarię, zwracany jest błąd.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Wstępnie zarezerwuj pamięć, wychodząc, jeśli nie możemy
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Teraz wiemy, że to nie może OOM w środku naszej złożonej pracy
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // bardzo skomplikowane
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Zmniejsza pojemność vector tak bardzo, jak to możliwe.
    ///
    /// Spadnie jak najbliżej długości, ale alokator może nadal informować vector, że jest miejsce na kilka dodatkowych elementów.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Pojemność nigdy nie jest mniejsza niż długość i nie ma nic do zrobienia, gdy są równe, więc możemy uniknąć przypadku panic w `RawVec::shrink_to_fit`, wywołując go tylko z większą pojemnością.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Zmniejsza pojemność vector z dolną granicą.
    ///
    /// Pojemność pozostanie co najmniej tak duża, jak zarówno długość, jak i dostarczona wartość.
    ///
    ///
    /// Jeśli aktualna pojemność jest mniejsza niż dolna granica, nie można tego zrobić.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Konwertuje vector na [`Box<[T]>`][owned slice].
    ///
    /// Należy pamiętać, że spowoduje to zmniejszenie nadmiaru pojemności.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Nadmiar pojemności jest usuwany:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Skraca vector, zachowując pierwsze elementy `len` i odrzucając resztę.
    ///
    /// Jeśli `len` jest większe niż bieżąca długość vector, nie ma to wpływu.
    ///
    /// Metoda [`drain`] może emulować `truncate`, ale powoduje, że nadmiarowe elementy są zwracane, a nie porzucane.
    ///
    ///
    /// Zauważ, że ta metoda nie ma wpływu na alokowaną przepustowość vector.
    ///
    /// # Examples
    ///
    /// Obcinanie pięcioelementowego vector do dwóch elementów:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Obcięcie nie występuje, gdy `len` jest większe niż bieżąca długość vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Obcinanie, gdy `len == 0` jest równoważne wywołaniu metody [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Jest to bezpieczne, ponieważ:
        //
        // * wycinek przekazany do `drop_in_place` jest prawidłowy;przypadek `len > self.len` pozwala uniknąć tworzenia nieprawidłowego wycinka, a
        // * `len` z vector jest zmniejszany przed wywołaniem `drop_in_place`, tak że żadna wartość nie zostanie usunięta dwa razy w przypadku, gdy `drop_in_place` był jeden raz na panic (jeśli panics dwa razy, program przerywa pracę).
        //
        //
        //
        unsafe {
            // Note: To celowe, że jest to `>`, a nie `>=`.
            //       Zmiana na `>=` ma w niektórych przypadkach negatywny wpływ na wydajność.
            //       Zobacz #78884 po więcej.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Wyodrębnia wycinek zawierający cały vector.
    ///
    /// Odpowiednik `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Wydobywa zmienny wycinek z całego vector.
    ///
    /// Odpowiednik `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Zwraca surowy wskaźnik do bufora vector.
    ///
    /// Wzywający musi upewnić się, że vector przeżyje wskaźnik zwracany przez tę funkcję, w przeciwnym razie będzie wskazywał na śmieci.
    /// Modyfikacja vector może spowodować realokację jego bufora, co również spowoduje unieważnienie wszelkich wskaźników do niego.
    ///
    /// Obiekt wywołujący musi również upewnić się, że pamięć, na którą wskazuje wskaźnik (non-transitively), nigdy nie zostanie zapisana (z wyjątkiem wewnątrz `UnsafeCell`) przy użyciu tego wskaźnika lub wskaźnika pochodnego od niego.
    /// Jeśli chcesz zmodyfikować zawartość plasterka, użyj [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Cieniujemy metodę wycinków o tej samej nazwie, aby uniknąć przechodzenia przez `deref`, który tworzy odwołanie pośrednie.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Zwraca niebezpieczny, zmienny wskaźnik do bufora vector.
    ///
    /// Wzywający musi upewnić się, że vector przeżyje wskaźnik zwracany przez tę funkcję, w przeciwnym razie będzie wskazywał na śmieci.
    ///
    /// Modyfikacja vector może spowodować realokację jego bufora, co również spowoduje unieważnienie wszelkich wskaźników do niego.
    ///
    /// # Examples
    ///
    /// ```
    /// // Przydziel vector wystarczająco duży na 4 elementy.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Zainicjuj elementy za pomocą surowych zapisów wskaźników, a następnie ustaw długość.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Cieniujemy metodę wycinków o tej samej nazwie, aby uniknąć przechodzenia przez `deref_mut`, który tworzy odwołanie pośrednie.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Zwraca odwołanie do bazowego alokatora.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Wymusza długość od vector do `new_len`.
    ///
    /// Jest to operacja niskiego poziomu, która nie zachowuje żadnych normalnych niezmienników tego typu.
    /// Zwykle zmiana długości vector odbywa się za pomocą jednej z bezpiecznych operacji, takich jak [`truncate`], [`resize`], [`extend`] lub [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` musi być mniejsza lub równa [`capacity()`].
    /// - Elementy w `old_len..new_len` muszą zostać zainicjowane.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Ta metoda może być przydatna w sytuacjach, w których vector służy jako bufor dla innego kodu, szczególnie przez FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // To jest tylko minimalny szkielet przykładu z dokumentacją;
    /// # // nie używaj tego jako punktu wyjścia dla prawdziwej biblioteki.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Zgodnie z dokumentacją metody FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // BEZPIECZEŃSTWO: Kiedy `deflateGetDictionary` zwraca `Z_OK`, utrzymuje, że:
    ///     // 1. `dict_length` elementy zostały zainicjowane.
    ///     // 2.
    ///     // `dict_length` <=pojemność (32_768), dzięki której połączenie `set_len` jest bezpieczne.
    ///     unsafe {
    ///         // Wykonaj połączenie FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... i zaktualizuj długość do zainicjowanej.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Chociaż poniższy przykład jest dźwiękowy, występuje wyciek pamięci, ponieważ wewnętrzne wektory Z0 nie zostały zwolnione przed wywołaniem `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` jest pusty, więc żadne elementy nie muszą być inicjowane.
    /// // 2. `0 <= capacity` zawsze zawiera to, czym jest `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalnie tutaj zamiast tego można by użyć [`clear`], aby poprawnie upuścić zawartość, a tym samym nie przeciekać pamięci.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Usuwa element z vector i zwraca go.
    ///
    /// Usunięty element jest zastępowany ostatnim elementem vector.
    ///
    /// To nie zachowuje kolejności, ale jest O(1).
    ///
    /// # Panics
    ///
    /// Panics, jeśli `index` jest poza zakresem.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Zastępujemy self [index] ostatnim elementem.
            // Zwróć uwagę, że jeśli powyższe sprawdzenie granic powiedzie się, musi istnieć ostatni element (który może być samym self [index]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Wstawia element na pozycji `index` w vector, przesuwając wszystkie elementy za nim w prawo.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // miejsce na nowy element
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // nieomylny Miejsce, w którym można umieścić nową wartość
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Przesuń wszystko, aby zrobić miejsce.
                // (Powielanie elementu " index` w dwóch kolejnych miejscach).
                ptr::copy(p, p.offset(1), len - index);
                // Wpisz go, nadpisując pierwszą kopię elementu " index`.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Usuwa i zwraca element na pozycji `index` w vector, przesuwając wszystkie elementy za nim w lewo.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `index` jest poza zakresem.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // miejsce, z którego bierzemy.
                let ptr = self.as_mut_ptr().add(index);
                // skopiuj go, niebezpiecznie mając kopię wartości na stosie iw vector w tym samym czasie.
                //
                ret = ptr::read(ptr);

                // Przesuń wszystko w dół, aby wypełnić to miejsce.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Zachowuje tylko elementy określone w predykacie.
    ///
    /// Innymi słowy, usuń wszystkie elementy `e` tak, że `f(&e)` zwraca `false`.
    /// Ta metoda działa w miejscu, odwiedzając każdy element dokładnie raz w oryginalnej kolejności i zachowując kolejność zachowanych elementów.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Ponieważ elementy są odwiedzane dokładnie raz w pierwotnej kolejności, stan zewnętrzny może służyć do decydowania, które elementy zachować.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Unikaj podwójnego upuszczenia, jeśli osłona nie zostanie uruchomiona, ponieważ podczas procesu możemy zrobić kilka dziur.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-przetworzony len-> |^-obok sprawdzić
        //                  | <-usunięte cnt-> |
        //      | <-oryginalny_len-> |Utrzymane: elementy, których predykat zwraca prawdę.
        //
        // Otwór: Przeniesiony lub upuszczony slot elementu.
        // Niezaznaczone: niezaznaczone prawidłowe elementy.
        //
        // Ta ochrona przed upadkiem zostanie wywołana, gdy predykat lub `drop` elementu wpadną w panikę.
        // Przesuwa niezaznaczone elementy, aby zakryć otwory i `set_len` na odpowiednią długość.
        // W przypadkach, gdy predykat i `drop` nigdy nie panikują, zostaną zoptymalizowane.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // BEZPIECZEŃSTWO: Końcowe niezaznaczone pozycje muszą być ważne, ponieważ nigdy ich nie dotykamy.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // BEZPIECZEŃSTWO: Po wypełnieniu otworów wszystkie pozycje są w ciągłej pamięci.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // BEZPIECZEŃSTWO: Niezaznaczony element musi być ważny.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Awansuj wcześnie, aby uniknąć podwójnego upuszczenia, jeśli `drop_in_place` spanikuje.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // BEZPIECZEŃSTWO: Nigdy więcej nie dotykamy tego elementu po upuszczeniu.
                unsafe { ptr::drop_in_place(cur) };
                // Już przesunęliśmy licznik.
                continue;
            }
            if g.deleted_cnt > 0 {
                // BEZPIECZEŃSTWO: `deleted_cnt`> 0, więc szczelina otworu nie może pokrywać się z bieżącym elementem.
                // Używamy kopiowania do przenoszenia i nigdy więcej nie dotykamy tego elementu.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Wszystkie pozycje są przetwarzane.Można to zoptymalizować do `set_len` przez LLVM.
        drop(g);
    }

    /// Usuwa wszystkie oprócz pierwszego z kolejnych elementów w vector, które są rozwiązywane do tego samego klucza.
    ///
    ///
    /// Jeśli vector jest posortowany, usuwa to wszystkie duplikaty.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Usuwa wszystkie oprócz pierwszego z kolejnych elementów w vector spełniających daną relację równości.
    ///
    /// Do funkcji `same_bucket` przekazywane są odwołania do dwóch elementów z vector i musi ona określić, czy elementy są równe.
    /// Elementy są przekazywane w odwrotnej kolejności niż ich kolejność w wycinku, więc jeśli `same_bucket(a, b)` zwraca `true`, `a` jest usuwany.
    ///
    ///
    /// Jeśli vector jest posortowany, usuwa to wszystkie duplikaty.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Dołącza element z tyłu kolekcji.
    ///
    /// # Panics
    ///
    /// Panics, jeśli nowa pojemność przekracza `isize::MAX` bajtów.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Spowoduje to panic lub przerwanie, jeśli przydzielimy> isize::MAX bajtów lub jeśli przyrost długości przepełni się dla typów o zerowej wielkości.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Usuwa ostatni element z vector i zwraca go lub [`None`], jeśli jest pusty.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Przenosi wszystkie elementy `other` do `Self`, pozostawiając `other` puste.
    ///
    /// # Panics
    ///
    /// Panics, jeśli liczba elementów w vector przekracza `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Dołącza elementy do `Self` z innego bufora.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Tworzy opróżniający iterator, który usuwa określony zakres w vector i zwraca usunięte elementy.
    ///
    /// Kiedy iterator **jest** upuszczony, wszystkie elementy w zakresie są usuwane z vector, nawet jeśli iterator nie został w pełni wykorzystany.
    /// Jeśli iterator **nie zostanie** usunięty (na przykład z [`mem::forget`]), nie jest określone, ile elementów zostanie usuniętych.
    ///
    /// # Panics
    ///
    /// Panics, jeśli punkt początkowy jest większy niż punkt końcowy lub jeśli punkt końcowy jest większy niż długość wektora Z0Z.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Pełen zakres czyści vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Bezpieczeństwo pamięci
        //
        // Kiedy Drain jest tworzony po raz pierwszy, skraca długość źródłowego vector, aby upewnić się, że żadne niezainicjowane lub przeniesione elementy nie są w ogóle dostępne, jeśli destruktor Drain nigdy nie zostanie uruchomiony.
        //
        //
        // Drain wykona ptr::read wartości do usunięcia.
        // Po zakończeniu pozostały koniec vec jest kopiowany z powrotem, aby zakryć otwór, a długość vector jest przywracana do nowej długości.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // ustaw długość self.vec na początku, aby być bezpiecznym w przypadku wycieku Drain
            self.set_len(start);
            // Użyj pożyczki w IterMut, aby wskazać zachowanie pożyczania całego iteratora Drain (jak &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Czyści vector, usuwając wszystkie wartości.
    ///
    /// Zauważ, że ta metoda nie ma wpływu na alokowaną przepustowość vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Zwraca liczbę elementów w vector, nazywaną również 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Zwraca `true`, jeśli vector nie zawiera żadnych elementów.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Dzieli kolekcję na dwie pod podanym indeksem.
    ///
    /// Zwraca nowo przydzielony vector zawierający elementy z zakresu `[at, len)`.
    /// Po wywołaniu oryginalny vector pozostanie zawierający elementy `[0, at)` z niezmienioną poprzednią pojemnością.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jeśli `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // nowy vector może przejąć oryginalny bufor i uniknąć kopiowania
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Unsafely `set_len` i skopiuj elementy do `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Zmienia rozmiar `Vec` w miejscu, tak aby `len` było równe `new_len`.
    ///
    /// Jeśli `new_len` jest większe niż `len`, `Vec` jest wydłużane o różnicę, przy czym każda dodatkowa szczelina jest wypełniana wynikiem wywołania zamknięcia `f`.
    ///
    /// Zwracane wartości z `f` trafią do `Vec` w kolejności, w jakiej zostały wygenerowane.
    ///
    /// Jeśli `new_len` jest mniejsze niż `len`, `Vec` jest po prostu obcięte.
    ///
    /// Ta metoda używa zamknięcia do tworzenia nowych wartości przy każdym wypychaniu.Jeśli wolisz [`Clone`] daną wartość, użyj [`Vec::resize`].
    /// Jeśli chcesz użyć [`Default`] trait do generowania wartości, możesz przekazać [`Default::default`] jako drugi argument.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Zużywa i wycieka `Vec`, zwracając zmienne odniesienie do zawartości, `&'a mut [T]`.
    /// Należy pamiętać, że typ `T` musi przetrwać wybrany okres eksploatacji `'a`.
    /// Jeśli typ ma tylko statyczne odniesienia lub nie ma ich wcale, można wybrać `'static`.
    ///
    /// Ta funkcja jest podobna do funkcji [`leak`][Box::leak] w [`Box`] z wyjątkiem tego, że nie ma sposobu na odzyskanie wyciekającej pamięci.
    ///
    ///
    /// Ta funkcja jest przydatna głównie w przypadku danych, które pozostają do końca życia programu.
    /// Porzucenie zwróconego odwołania spowoduje przeciek pamięci.
    ///
    /// # Examples
    ///
    /// Proste użycie:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Zwraca pozostałe wolne moce produkcyjne vector jako wycinek `MaybeUninit<T>`.
    ///
    /// Zwrócony wycinek może zostać użyty do wypełnienia vector danymi (np
    /// poprzez odczyt z pliku) przed oznaczeniem danych jako zainicjowanych metodą [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Przydziel vector wystarczająco duży na 10 elementów.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Wypełnij pierwsze 3 elementy.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Oznacz pierwsze 3 elementy vector jako inicjowane.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Ta metoda nie jest zaimplementowana w zakresie `split_at_spare_mut`, aby zapobiec unieważnieniu wskaźników do bufora.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Zwraca zawartość vector jako wycinek `T`, wraz z pozostałą wolną wydajnością vector jako wycinek `MaybeUninit<T>`.
    ///
    /// Zwrócony wycinek wolnej mocy obliczeniowej może zostać użyty do wypełnienia vector danymi (np. Poprzez odczyt z pliku) przed oznaczeniem danych jako zainicjowanych metodą [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Zwróć uwagę, że jest to interfejs API niskiego poziomu, którego należy używać ostrożnie w celu optymalizacji.
    /// Jeśli chcesz dołączyć dane do `Vec`, możesz użyć [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] lub [`resize_with`], w zależności od Twoich potrzeb.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Zarezerwuj dodatkowe miejsce na 10 elementów.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Wypełnij kolejne 4 elementy.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Oznacz 4 elementy vector jako inicjowane.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len jest ignorowane i nigdy się nie zmienia
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Bezpieczeństwo: zmiana zwróconego .2 (użycie &mut) jest traktowana tak samo, jak wywołanie `.set_len(_)`.
    ///
    /// Ta metoda służy do uzyskania unikalnego dostępu do wszystkich części vec jednocześnie w `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` gwarantuje, że będzie obowiązywał dla elementów `len`
        // - `spare_ptr` wskazuje jeden element poza bufor, więc nie nakłada się na `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Zmienia rozmiar `Vec` w miejscu, tak aby `len` było równe `new_len`.
    ///
    /// Jeśli `new_len` jest większe niż `len`, `Vec` jest wydłużane o różnicę, a każdy dodatkowy slot jest wypełniony `value`.
    ///
    /// Jeśli `new_len` jest mniejsze niż `len`, `Vec` jest po prostu obcięte.
    ///
    /// Ta metoda wymaga, aby `T` zaimplementował [`Clone`], aby móc sklonować przekazaną wartość.
    /// Jeśli potrzebujesz większej elastyczności (lub chcesz polegać na [`Default`] zamiast [`Clone`]), użyj [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klonuje i dołącza wszystkie elementy w plasterku do `Vec`.
    ///
    /// Iteruje po wycinku `other`, klonuje każdy element, a następnie dołącza go do tego `Vec`.
    /// `other` vector jest przesuwany w kolejności.
    ///
    /// Zauważ, że ta funkcja jest taka sama jak [`extend`], z wyjątkiem tego, że jest wyspecjalizowana do pracy z plasterkami.
    ///
    /// Jeśli i kiedy Rust uzyska specjalizację, ta funkcja będzie prawdopodobnie przestarzała (ale nadal będzie dostępna).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopiuje elementy z zakresu `src` do końca vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` gwarantuje, że podany zakres jest prawidłowy do indeksowania siebie
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Ten kod uogólnia `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Rozszerz vector o wartości `n`, używając podanego generatora.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Użyj SetLenOnDrop, aby obejść błąd, w którym kompilator może nie zdawać sobie sprawy, że sklep za pośrednictwem `ptr` do self.set_len() nie ma aliasu.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Napisz wszystkie elementy oprócz ostatniego
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Zwiększaj długość w każdym kroku w przypadku next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Ostatni element możemy napisać bezpośrednio, bez niepotrzebnego klonowania
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len ustawiony przez osłonę lunety
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Usuwa kolejne powtarzające się elementy w vector zgodnie z implementacją [`PartialEq`] trait.
    ///
    ///
    /// Jeśli vector jest posortowany, usuwa to wszystkie duplikaty.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Metody i funkcje wewnętrzne
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` musi być prawidłowym indeksem
    /// - `self.capacity() - self.len()` musi być `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len jest zwiększane dopiero po zainicjowaniu elementów
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - dzwoniący gwarantuje, że src jest prawidłowym indeksem
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element został właśnie zainicjowany w `MaybeUninit::write`, więc można zwiększyć len
            // - len zwiększa się po każdym elemencie, aby zapobiec wyciekom (patrz wydanie #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - dzwoniący gwarantuje, że `src` jest prawidłowym indeksem
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Oba wskaźniki są tworzone z unikalnych odniesień do wycinków (`&mut [_]`), więc są prawidłowe i nie nakładają się.
            //
            // - Elementy to: Kopiuj, więc można je skopiować bez robienia czegokolwiek z oryginalnymi wartościami
            // - `count` jest równe len z `source`, więc źródło jest ważne dla odczytów `count`
            // - `.reserve(count)` gwarantuje, że tak zapasowy `spare.len() >= count` jest ważny dla zapisów `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Elementy zostały właśnie zainicjowane przez `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Typowe implementacje trait dla Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): w przypadku cfg(test) nieodłączna metoda `[T]::to_vec`, która jest wymagana dla tej definicji metody, nie jest dostępna.
    // Zamiast tego użyj funkcji `slice::to_vec`, która jest dostępna tylko z cfg(test) NB, patrz moduł slice::hack w slice.rs, aby uzyskać więcej informacji
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // upuść wszystko, co nie zostanie nadpisane
        self.truncate(other.len());

        // self.len <= other.len z powodu powyższego obcięcia, więc tutaj wycinki są zawsze w granicach.
        //
        let (init, tail) = other.split_at(self.len());

        // ponownie użyj zawartych wartości allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Tworzy iterator konsumujący, to znaczy taki, który przesuwa każdą wartość z vector (od początku do końca).
    /// Po wywołaniu tej funkcji nie można użyć vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s ma typ String, a nie &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // leaf, do której delegują różne implementacje SpecFrom/SpecExtend, gdy nie mają dalszych optymalizacji do zastosowania
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Tak jest w przypadku ogólnego iteratora.
        //
        // Ta funkcja powinna być moralnym odpowiednikiem:
        //
        //      dla elementu w iteratorze {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // Uwaga: nie można przepełnić, ponieważ musielibyśmy przydzielić przestrzeń adresową
                self.set_len(len + 1);
            }
        }
    }

    /// Tworzy iterator splicingu, który zastępuje określony zakres w vector podanym iteratorem `replace_with` i zwraca usunięte elementy.
    ///
    /// `replace_with` nie musi mieć takiej samej długości jak `range`.
    ///
    /// `range` jest usuwany, nawet jeśli iterator nie jest używany do końca.
    ///
    /// Nie określono, ile elementów zostanie usuniętych z vector w przypadku wycieku wartości `Splice`.
    ///
    /// Iterator wejściowy `replace_with` jest używany tylko wtedy, gdy wartość `Splice` zostanie usunięta.
    ///
    /// Jest to optymalne, jeśli:
    ///
    /// * Ogon (elementy w vector po `range`) jest pusty,
    /// * lub `replace_with` daje mniej lub równą liczbę elementów niż długość " zakresu`
    /// * lub dolna granica `size_hint()` jest dokładna.
    ///
    /// W przeciwnym razie przydzielany jest tymczasowy vector, a ogon jest przesuwany dwukrotnie.
    ///
    /// # Panics
    ///
    /// Panics, jeśli punkt początkowy jest większy niż punkt końcowy lub jeśli punkt końcowy jest większy niż długość wektora Z0Z.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Tworzy iterator, który używa zamknięcia, aby określić, czy element powinien zostać usunięty.
    ///
    /// Jeśli zamknięcie zwraca prawdę, element jest usuwany i zwracany.
    /// Jeśli zamknięcie zwróci fałsz, element pozostanie w vector i nie zostanie uzyskany przez iterator.
    ///
    /// Użycie tej metody jest równoważne z następującym kodem:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // Twój kod tutaj
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ale `drain_filter` jest łatwiejszy w użyciu.
    /// `drain_filter` jest również bardziej wydajny, ponieważ może masowo cofać elementy tablicy.
    ///
    /// Zwróć uwagę, że `drain_filter` umożliwia również mutację każdego elementu w zamknięciu filtra, niezależnie od tego, czy zdecydujesz się go zachować, czy usunąć.
    ///
    ///
    /// # Examples
    ///
    /// Dzielenie tablicy na liczby parzyste i szanse, ponowne wykorzystanie pierwotnej alokacji:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Chroń nas przed wyciekiem (wzmocnienie wycieku)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Implementacja rozszerzająca, która kopiuje elementy z odniesień przed umieszczeniem ich w Vec.
///
/// Ta implementacja jest wyspecjalizowana w iteratorach wycinków, gdzie używa [`copy_from_slice`] do dołączania całego wycinka naraz.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Implementuje porównanie wektorów Z0Z, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Realizuje porządkowanie wektorów Z0Z, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // użyj drop dla [T] użyj surowego plasterka, aby odnieść się do elementów vector jako najsłabszego koniecznego typu;
            //
            // może w niektórych przypadkach uniknąć pytań o ważność
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec obsługuje zwalnianie przydziałów
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Tworzy pusty `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test ściąga libstd, co powoduje tutaj błędy
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test ściąga libstd, co powoduje tutaj błędy
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Pobiera całą zawartość `Vec<T>` jako tablicę, jeśli jej rozmiar dokładnie odpowiada rozmiarowi żądanej tablicy.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Jeśli długość się nie zgadza, dane wejściowe powracają w `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Jeśli nie masz nic przeciwko uzyskaniu prefiksu `Vec<T>`, możesz najpierw zadzwonić do [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // BEZPIECZEŃSTWO: `.set_len(0)` to zawsze dźwięk.
        unsafe { vec.set_len(0) };

        // BEZPIECZEŃSTWO: Wskaźnik `Vec` jest zawsze ustawiony prawidłowo, a
        // wyrównanie, którego potrzebuje tablica, jest takie samo jak elementów.
        // Sprawdziliśmy wcześniej, czy mamy wystarczającą ilość pozycji.
        // Elementy nie spadną dwukrotnie, ponieważ `set_len` mówi `Vec`, aby ich również nie upuszczał.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}