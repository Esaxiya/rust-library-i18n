#![stable(feature = "rust1", since = "1.0.0")]

//! Bezpieczne wątkowo wskaźniki liczenia odwołań.
//!
//! Więcej informacji można znaleźć w dokumentacji [`Arc<T>`][Arc].

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Miękki limit ilości odniesień, które można wprowadzić do `Arc`.
///
/// Przekroczenie tego limitu spowoduje przerwanie programu (choć niekoniecznie) w odniesieniach _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer nie obsługuje barier pamięci.
// Aby uniknąć fałszywie pozytywnych raportów w implementacji Arc/Weak, użyj zamiast tego do synchronizacji obciążeń atomowych.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Wskaźnik liczenia odwołań bezpieczny dla wątków.'Arc' oznacza " Atomically Reference Counted`.
///
/// Typ `Arc<T>` zapewnia współdzieloną własność wartości typu `T`, przydzielonej na stercie.Wywołanie [`clone`][clone] na `Arc` tworzy nową instancję `Arc`, która wskazuje na taką samą alokację na stercie co źródłowy `Arc`, jednocześnie zwiększając liczbę odwołań.
/// Gdy ostatni wskaźnik `Arc` do danej alokacji zostanie zniszczony, wartość przechowywana w tej alokacji (często nazywana "inner value") jest również usuwana.
///
/// Współdzielone odwołania w Rust domyślnie zabraniają mutacji, a `Arc` nie jest wyjątkiem: generalnie nie można uzyskać zmiennego odniesienia do czegoś wewnątrz `Arc`.Jeśli chcesz dokonać mutacji przez `Arc`, użyj [`Mutex`][mutex], [`RwLock`][rwlock] lub jednego z typów [`Atomic`][atomic].
///
/// ## Bezpieczeństwo wątku
///
/// W przeciwieństwie do [`Rc<T>`], `Arc<T>` używa operacji atomowych do liczenia referencyjnego.Oznacza to, że jest bezpieczny dla wątków.Wadą jest to, że operacje atomowe są droższe niż zwykłe dostępy do pamięci.Jeśli nie udostępniasz alokacji zliczanych odwołań między wątkami, rozważ użycie [`Rc<T>`] w celu zmniejszenia narzutu.
/// [`Rc<T>`] jest bezpieczną wartością domyślną, ponieważ kompilator przechwyci każdą próbę wysłania [`Rc<T>`] między wątkami.
/// Jednak biblioteka może wybrać `Arc<T>`, aby zapewnić konsumentom większą elastyczność.
///
/// `Arc<T>` wdroży [`Send`] i [`Sync`], o ile `T` implementuje [`Send`] i [`Sync`].
/// Dlaczego nie możesz umieścić niegwintowanego typu `T` w `Arc<T>`, aby był bezpieczny dla wątków?Na początku może to wydawać się nieco sprzeczne z intuicją: w końcu czy nie chodzi o bezpieczeństwo wątków `Arc<T>`?Klucz jest następujący: `Arc<T>` zapewnia bezpieczeństwo wątków, aby mieć wielokrotne prawa własności do tych samych danych, ale nie dodaje bezpieczeństwa wątków do swoich danych.
///
/// Rozważmy `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] nie jest [`Sync`], a jeśli `Arc<T>` było zawsze [`Send`], to `Arc <` [`RefCell<T>`]`>`byłoby również.
/// Ale wtedy mielibyśmy problem:
/// [`RefCell<T>`] nie jest bezpieczny dla wątków;śledzi liczbę pożyczek za pomocą operacji nieatomowych.
///
/// Ostatecznie oznacza to, że może być konieczne sparowanie `Arc<T>` z jakimś rodzajem typu [`std::sync`], zwykle [`Mutex<T>`][mutex].
///
/// ## Cykle hamowania z `Weak`
///
/// Metoda [`downgrade`][downgrade] może służyć do tworzenia wskaźnika [`Weak`] niebędącego właścicielem.Wskaźnik [`Weak`] może być [`upgrade`][upgrade] d do `Arc`, ale zwróci [`None`], jeśli wartość przechowywana w alokacji została już usunięta.
/// Innymi słowy, wskaźniki `Weak` nie utrzymują wartości wewnątrz alokacji przy życiu;jednakże *utrzymują* alokację (magazyn zapasowy dla wartości) przy życiu.
///
/// Cykl między wskaźnikami `Arc` nigdy nie zostanie cofnięty.
/// Z tego powodu [`Weak`] jest używany do przerywania cykli.Na przykład drzewo może mieć silne wskaźniki `Arc` od węzłów nadrzędnych do podrzędnych, a wskaźniki [`Weak`] od dzieci do rodziców.
///
/// # Klonowanie odniesień
///
/// Tworzenie nowego odniesienia z istniejącego wskaźnika zliczanego odniesienia odbywa się za pomocą `Clone` trait zaimplementowanego dla [`Arc<T>`][Arc] i [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Dwie poniższe składnie są równoważne.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b i foo to wszystkie łuki wskazujące na to samo miejsce w pamięci
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatycznie odwołuje się do `T` (przez [`Deref`][deref] trait), więc możesz wywołać metody `T` na wartości typu `Arc<T>`.Aby uniknąć kolizji nazw z metodami `T`, metody samego `Arc<T>` są skojarzonymi funkcjami, wywoływanymi przy użyciu [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>`` implementacje traits, takie jak `Clone`, można również wywołać przy użyciu w pełni kwalifikowanej składni.
/// Niektórzy wolą używać w pełni kwalifikowanej składni, podczas gdy inni wolą używać składni wywołania metody.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Składnia wywołania metody
/// let arc2 = arc.clone();
/// // W pełni kwalifikowana składnia
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] nie dokonuje automatycznego wyłuskiwania `T`, ponieważ wewnętrzna wartość mogła już zostać usunięta.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Udostępnianie niezmiennych danych między wątkami:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Zwróć uwagę, że **nie** przeprowadzamy tutaj tych testów.
// Konstruktorzy windows są bardzo niezadowoleni, jeśli wątek przeżyje główny wątek, a następnie zostanie zamknięty w tym samym czasie (coś zakleszczy się), więc po prostu unikamy tego całkowicie, nie uruchamiając tych testów.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Udostępnianie mutowalnego [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Więcej ogólnych przykładów zliczania referencji można znaleźć w [`rc` documentation][rc_examples].
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` jest wersją [`Arc`], która zawiera odniesienie do zarządzanej alokacji, które nie jest właścicielem.
/// Dostęp do alokacji uzyskuje się przez wywołanie [`upgrade`] na wskaźniku `Weak`, który zwraca [`Option`]`<`[`Arc`] `<T>>`.
///
/// Ponieważ odwołanie `Weak` nie jest wliczane do własności, nie zapobiega to porzuceniu wartości przechowywanej w alokacji, a sam `Weak` nie gwarantuje, że wartość nadal będzie obecna.
///
/// Dlatego może zwrócić [`None`], gdy [`upgrade`] d.
/// Należy jednak zauważyć, że odwołanie `Weak`*nie* zapobiega cofnięciu alokacji (magazynu zapasowego).
///
/// Wskaźnik `Weak` jest przydatny do przechowywania tymczasowego odniesienia do alokacji zarządzanej przez [`Arc`] bez zapobiegania porzuceniu jego wewnętrznej wartości.
/// Służy również do zapobiegania cyklicznym odwołaniom między wskaźnikami [`Arc`], ponieważ odniesienia do wzajemnego posiadania nigdy nie pozwolą na usunięcie [`Arc`].
/// Na przykład drzewo może mieć silne wskaźniki [`Arc`] od węzłów nadrzędnych do podrzędnych, a wskaźniki `Weak` od dzieci do rodziców.
///
/// Typowym sposobem uzyskania wskaźnika `Weak` jest wywołanie [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // To jest `NonNull`, aby umożliwić optymalizację tego typu w wyliczeniach, ale niekoniecznie jest to prawidłowy wskaźnik.
    //
    // `Weak::new` ustawia to na `usize::MAX`, aby nie musiał przydzielać miejsca na stercie.
    // To nie jest wartość, jaką kiedykolwiek będzie miał prawdziwy wskaźnik, ponieważ RcBox ma wyrównanie co najmniej 2.
    // Jest to możliwe tylko wtedy, gdy `T: Sized`;nietypowy `T` nigdy nie zwisa.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Jest to od repr(C) do future odporne na ewentualne zmiany kolejności w terenie, które mogłyby kolidować z bezpiecznym [into|from]_raw() transmutowalnych typów wewnętrznych.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // wartość usize::MAX działa jako wartownik dla tymczasowej zdolności "locking" do ulepszania słabych wskaźników lub obniżania wartości silnych;służy do unikania wyścigów w `make_mut` i `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konstruuje nowy `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Zacznij liczyć słaby wskaźnik jako 1, który jest słabym wskaźnikiem utrzymywanym przez wszystkie silne wskaźniki (kinda), zobacz std/rc.rs, aby uzyskać więcej informacji
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konstruuje nowy `Arc<T>`, używając słabego odniesienia do samego siebie.
    /// Próba zaktualizowania słabego odwołania przed zwróceniem tej funkcji spowoduje wyświetlenie wartości `None`.
    /// Jednak słabe odniesienie można swobodnie klonować i przechowywać do wykorzystania w późniejszym czasie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Skonstruuj wewnętrzną w stanie "uninitialized" z pojedynczym słabym odniesieniem.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Ważne jest, abyśmy nie rezygnowali z własności słabego wskaźnika, w przeciwnym razie pamięć może zostać zwolniona do czasu powrotu `data_fn`.
        // Gdybyśmy naprawdę chcieli przekazać własność, moglibyśmy stworzyć dla siebie dodatkowy słaby wskaźnik, ale spowodowałoby to dodatkowe aktualizacje słabej liczby odwołań, które w przeciwnym razie mogłyby nie być konieczne.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Teraz możemy poprawnie zainicjować wartość wewnętrzną i zmienić nasze słabe odniesienie w silne odniesienie.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Powyższy zapis w polu danych musi być widoczny dla wszystkich wątków, które obserwują niezerową silną liczbę.
            // Dlatego potrzebujemy przynajmniej zamówienia "Release", aby zsynchronizować się z `compare_exchange_weak` w `Weak::upgrade`.
            //
            // "Acquire" zamówienie nie jest wymagane.
            // Rozważając możliwe zachowania `data_fn`, musimy tylko przyjrzeć się, co może zrobić z odniesieniem do `Weak`, którego nie można uaktualnić:
            //
            // - Może *sklonować*`Weak`, zwiększając liczbę słabych odniesień.
            // - Może upuścić te klony, zmniejszając liczbę słabych referencji (ale nigdy do zera).
            //
            // Te skutki uboczne nie mają na nas żadnego wpływu i żadne inne skutki uboczne nie są możliwe przy użyciu samego bezpiecznego kodu.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Silne odwołania powinny wspólnie posiadać wspólne słabe odniesienie, więc nie uruchamiaj destruktora dla naszego starego słabego odniesienia.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruuje nowy `Arc` z niezainicjowaną zawartością.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odroczona inicjalizacja:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruuje nowy `Arc` z niezainicjowaną zawartością, z pamięcią wypełnioną `0` bajtami.
    ///
    ///
    /// Zobacz [`MaybeUninit::zeroed`][zeroed], aby zapoznać się z przykładami prawidłowego i nieprawidłowego użycia tej metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruuje nowy `Pin<Arc<T>>`.
    /// Jeśli `T` nie implementuje `Unpin`, `data` zostanie przypięty do pamięci i nie będzie można go przenieść.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Konstruuje nowy `Arc<T>`, zwracając błąd, jeśli alokacja nie powiedzie się.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Zacznij liczyć słaby wskaźnik jako 1, który jest słabym wskaźnikiem utrzymywanym przez wszystkie silne wskaźniki (kinda), zobacz std/rc.rs, aby uzyskać więcej informacji
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Konstruuje nowy `Arc` z niezainicjowaną zawartością, zwracając błąd, jeśli alokacja nie powiedzie się.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Odroczona inicjalizacja:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruuje nowy `Arc` z niezainicjowaną zawartością, z pamięcią wypełnioną bajtami `0`, zwracając błąd, jeśli alokacja nie powiedzie się.
    ///
    ///
    /// Zobacz [`MaybeUninit::zeroed`][zeroed], aby zapoznać się z przykładami prawidłowego i nieprawidłowego użycia tej metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Zwraca wartość wewnętrzną, jeśli `Arc` ma dokładnie jedną silną referencję.
    ///
    /// W przeciwnym razie zwracany jest [`Err`] z tym samym `Arc`, który został przekazany.
    ///
    ///
    /// To się powiedzie, nawet jeśli istnieją wybitne słabe odniesienia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Utwórz słaby wskaźnik, aby wyczyścić niejawne silne-słabe odniesienie
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Konstruuje nowy wycinek z liczbową liczbą odwołań z niezainicjowaną zawartością.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odroczona inicjalizacja:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Konstruuje nowy wycinek z liczbami niepodzielnych odniesień z niezainicjowaną zawartością, z pamięcią wypełnioną `0` bajtów.
    ///
    ///
    /// Zobacz [`MaybeUninit::zeroed`][zeroed], aby zapoznać się z przykładami prawidłowego i nieprawidłowego użycia tej metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Konwertuje na `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Podobnie jak w przypadku [`MaybeUninit::assume_init`], wywołujący musi zagwarantować, że wartość wewnętrzna rzeczywiście jest w stanie zainicjowanym.
    ///
    /// Wywołanie tego, gdy zawartość nie jest jeszcze w pełni zainicjowana, powoduje natychmiastowe niezdefiniowane zachowanie.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odroczona inicjalizacja:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Konwertuje na `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Podobnie jak w przypadku [`MaybeUninit::assume_init`], wywołujący musi zagwarantować, że wartość wewnętrzna rzeczywiście jest w stanie zainicjowanym.
    ///
    /// Wywołanie tego, gdy zawartość nie jest jeszcze w pełni zainicjowana, powoduje natychmiastowe niezdefiniowane zachowanie.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odroczona inicjalizacja:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Zużywa `Arc`, zwracając opakowany wskaźnik.
    ///
    /// Aby uniknąć wycieku pamięci, wskaźnik musi zostać przekonwertowany z powrotem na `Arc` przy użyciu [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Zapewnia nieprzetworzony wskaźnik do danych.
    ///
    /// Liczby nie ulegają zmianie w żaden sposób, a `Arc` nie jest zużywany.
    /// Wskaźnik jest ważny tak długo, jak długo istnieją silne liczniki w `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // BEZPIECZEŃSTWO: To nie może przejść przez Deref::deref lub RcBoxPtr::inner, ponieważ
        // jest to wymagane, aby zachować pochodzenie raw/mut w taki sposób, że np
        // `get_mut` może pisać przez wskaźnik po odzyskaniu Rc przez `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Konstruuje `Arc<T>` z surowego wskaźnika.
    ///
    /// Nieprzetworzony wskaźnik musiał zostać wcześniej zwrócony przez wywołanie [`Arc<U>::into_raw`][into_raw], gdzie `U` musi mieć taki sam rozmiar i wyrównanie jak `T`.
    /// Jest to trywialnie prawdziwe, jeśli `U` to `T`.
    /// Zauważ, że jeśli `U` nie jest `T`, ale ma ten sam rozmiar i wyrównanie, jest to w zasadzie jak transmutowanie odniesień różnych typów.
    /// Zobacz [`mem::transmute`][transmute], aby uzyskać więcej informacji na temat ograniczeń obowiązujących w tym przypadku.
    ///
    /// Użytkownik `from_raw` musi upewnić się, że określona wartość `T` zostanie usunięta tylko raz.
    ///
    /// Ta funkcja jest niebezpieczna, ponieważ niewłaściwe użycie może prowadzić do zagrożenia pamięci, nawet jeśli nigdy nie uzyskano dostępu do zwróconego `Arc<T>`.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konwertuj z powrotem na `Arc`, aby zapobiec wyciekom.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Dalsze wywołania `Arc::from_raw(x_ptr)` byłyby niebezpieczne dla pamięci.
    /// }
    ///
    /// // Pamięć została zwolniona, gdy `x` wyszedł poza zakres powyżej, więc `x_ptr` teraz zwisa!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Odwróć odsunięcie, aby znaleźć oryginalny ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Tworzy nowy wskaźnik [`Weak`] do tej alokacji.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // To Relaxed jest OK, ponieważ sprawdzamy wartość w CAS poniżej.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // sprawdź, czy słaby licznik to obecnie "locked";jeśli tak, zakręć.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ten kod obecnie ignoruje możliwość przepełnienia
            // do usize::MAX;ogólnie zarówno Rc, jak i Arc muszą być dostosowane, aby poradzić sobie z przepełnieniem.
            //

            // W przeciwieństwie do Clone(), potrzebujemy tego odczytu Acquire, aby zsynchronizować się z zapisem pochodzącym z `is_unique`, tak aby zdarzenia poprzedzające ten zapis miały miejsce przed tym odczytem.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Upewnij się, że nie utworzymy wiszącego słabego
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Pobiera liczbę wskaźników [`Weak`] do tej alokacji.
    ///
    /// # Safety
    ///
    /// Ta metoda sama w sobie jest bezpieczna, ale jej prawidłowe stosowanie wymaga dodatkowej ostrożności.
    /// Inny wątek może zmienić słabą liczbę w dowolnym momencie, w tym potencjalnie między wywołaniem tej metody a działaniem na wyniku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // To stwierdzenie jest deterministyczne, ponieważ nie udostępnialiśmy `Arc` ani `Weak` między wątkami.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Jeśli słaba liczba jest aktualnie zablokowana, wartość zliczenia wynosiła 0 tuż przed zablokowaniem.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Pobiera liczbę silnych wskaźników (`Arc`) do tej alokacji.
    ///
    /// # Safety
    ///
    /// Ta metoda sama w sobie jest bezpieczna, ale jej prawidłowe stosowanie wymaga dodatkowej ostrożności.
    /// Inny wątek może zmienić silną liczbę w dowolnym momencie, w tym potencjalnie między wywołaniem tej metody a działaniem na wyniku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // To stwierdzenie jest deterministyczne, ponieważ nie dzieliliśmy `Arc` między wątkami.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Zwiększa o jeden liczbę silnych odwołań na `Arc<T>` skojarzonym z podanym wskaźnikiem.
    ///
    /// # Safety
    ///
    /// Wskaźnik musi zostać uzyskany za pośrednictwem `Arc::into_raw`, a powiązana instancja `Arc` musi być poprawna (tj
    /// silna liczba musi wynosić co najmniej 1) na czas trwania tej metody.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // To stwierdzenie jest deterministyczne, ponieważ nie dzieliliśmy `Arc` między wątkami.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Zachowaj Arc, ale nie dotykaj refcount przez zawijanie w ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Teraz zwiększ refcount, ale też nie upuszczaj nowego refcount
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Zmniejsza o jeden liczbę silnych odwołań na `Arc<T>` skojarzonym z podanym wskaźnikiem.
    ///
    /// # Safety
    ///
    /// Wskaźnik musi zostać uzyskany za pośrednictwem `Arc::into_raw`, a powiązana instancja `Arc` musi być poprawna (tj
    /// silna liczba musi wynosić co najmniej 1) podczas wywoływania tej metody.
    /// Tej metody można użyć do zwolnienia ostatecznego `Arc` i magazynu zapasowego, ale **nie należy** wywoływać po wydaniu ostatecznego `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Te stwierdzenia są deterministyczne, ponieważ nie dzieliliśmy `Arc` między wątkami.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // To zagrożenie jest w porządku, ponieważ dopóki ten łuk jest żywy, mamy gwarancję, że wewnętrzny wskaźnik jest prawidłowy.
        // Ponadto wiemy, że sama struktura `ArcInner` to `Sync`, ponieważ dane wewnętrzne również to `Sync`, więc możemy pożyczyć niezmienny wskaźnik do tych treści.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Niewielka część `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Zniszcz dane w tym momencie, nawet jeśli nie możemy zwolnić samego przydziału skrzynki (nadal mogą znajdować się słabe punkty).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Porzuć słaby ref wspólnie trzymany przez wszystkie silne odniesienia
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Zwraca `true`, jeśli dwa `Arc` wskazują na tę samą alokację (w stylu podobnym do [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Przydziela `ArcInner<T>` z wystarczającą ilością miejsca na potencjalnie niewymiarową wartość wewnętrzną, jeśli wartość ma podany układ.
    ///
    /// Funkcja `mem_to_arcinner` jest wywoływana ze wskaźnikiem danych i musi zwrócić (potencjalnie gruby) wskaźnik dla `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Oblicz układ przy użyciu podanego układu wartości.
        // Wcześniej układ był obliczany na podstawie wyrażenia `&*(ptr as* const ArcInner<T>)`, ale powodowało to nieprawidłowe odniesienie (patrz #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Przydziela `ArcInner<T>` z wystarczającą ilością miejsca na prawdopodobnie nietypową wartość wewnętrzną, w której wartość ma podany układ, zwracając błąd, jeśli alokacja nie powiedzie się.
    ///
    ///
    /// Funkcja `mem_to_arcinner` jest wywoływana ze wskaźnikiem danych i musi zwrócić (potencjalnie gruby) wskaźnik dla `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Oblicz układ przy użyciu podanego układu wartości.
        // Wcześniej układ był obliczany na podstawie wyrażenia `&*(ptr as* const ArcInner<T>)`, ale powodowało to nieprawidłowe odniesienie (patrz #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Zainicjuj ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Przydziela `ArcInner<T>` z wystarczającą ilością miejsca na wewnętrzną wartość bez rozmiaru.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Przydziel dla `ArcInner<T>` przy użyciu podanej wartości.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Skopiuj wartość jako bajty
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Zwolnij przydział bez upuszczania jego zawartości
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Przydziela `ArcInner<[T]>` o podanej długości.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Skopiuj elementy z plasterka do nowo przydzielonego łuku <\[T\]>
    ///
    /// Niebezpieczne, ponieważ dzwoniący musi przejąć własność lub powiązać `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Konstruuje `Arc<[T]>` z iteratora, o którym wiadomo, że ma określony rozmiar.
    ///
    /// Zachowanie jest nieokreślone, jeśli rozmiar jest nieprawidłowy.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic chroni podczas klonowania elementów T.
        // W przypadku panic elementy, które zostały zapisane w nowym ArcInner, zostaną usunięte, a następnie pamięć zostanie zwolniona.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Wskaźnik do pierwszego elementu
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Wszystko jasne.Zapomnij o strażniku, aby nie uwolnił nowego ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specjalizacja trait używana dla `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Tworzy klon wskaźnika `Arc`.
    ///
    /// Tworzy to kolejny wskaźnik do tej samej alokacji, zwiększając liczbę silnych odwołań.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Używanie swobodnej kolejności jest tutaj w porządku, ponieważ znajomość oryginalnego odniesienia zapobiega błędnemu usunięciu obiektu przez inne wątki.
        //
        // Jak wyjaśniono w [Boost documentation][1], zwiększenie licznika odwołań zawsze można wykonać za pomocą memory_order_relaxed: nowe odniesienia do obiektu można utworzyć tylko z istniejącego odniesienia, a przekazywanie istniejącego odniesienia z jednego wątku do drugiego musi już zapewniać wymaganą synchronizację.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Musimy jednak wystrzegać się ogromnych zwrotów na wypadek, gdyby ktoś `mem: : zapomniał` o Arcs.
        // Jeśli tego nie zrobimy, liczba może się przepełnić, a użytkownicy będą korzystać za darmo.
        // Rasowo przesycamy do `isize::MAX`, zakładając, że nie ma ~2 miliarda wątków zwiększających liczbę odwołań naraz.
        //
        // Ten branch nigdy nie zostanie wykorzystany w żadnym realistycznym programie.
        //
        // Przerywamy, ponieważ taki program jest niesamowicie zdegenerowany i nie zależy nam na jego wspieraniu.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Tworzy zmienne odniesienie do danego `Arc`.
    ///
    /// Jeśli istnieją inne wskaźniki `Arc` lub [`Weak`] do tej samej alokacji, `make_mut` utworzy nową alokację i wywoła [`clone`][clone] na wartości wewnętrznej, aby zapewnić unikalną własność.
    /// Nazywa się to również klonowaniem przy zapisie.
    ///
    /// Zwróć uwagę, że różni się to od zachowania [`Rc::make_mut`], które usuwa skojarzenia wszystkich pozostałych wskaźników `Weak`.
    ///
    /// Zobacz także [`get_mut`][get_mut], który zakończy się niepowodzeniem zamiast klonowania.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Niczego nie sklonuje
    /// let mut other_data = Arc::clone(&data); // Nie klonuje danych wewnętrznych
    /// *Arc::make_mut(&mut data) += 1;         // Klonuje dane wewnętrzne
    /// *Arc::make_mut(&mut data) += 1;         // Niczego nie sklonuje
    /// *Arc::make_mut(&mut other_data) *= 2;   // Niczego nie sklonuje
    ///
    /// // Teraz `data` i `other_data` wskazują na różne alokacje.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Zwróć uwagę, że posiadamy zarówno silne, jak i słabe odniesienie.
        // Zatem zwolnienie tylko naszego silnego odniesienia nie spowoduje samo w sobie zwolnienia pamięci.
        //
        // Użyj Acquire, aby upewnić się, że widzimy wszelkie zapisy do `weak`, które mają miejsce przed wydaniem, zapisuje (tj. Zmniejsza) do `strong`.
        // Ponieważ mamy słabą liczbę, nie ma szans, aby sam ArcInner mógł zostać zwolniony.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Istnieje inny silny wskaźnik, więc musimy sklonować.
            // Wstępnie przydziel pamięć, aby umożliwić bezpośrednie zapisywanie sklonowanej wartości.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Rozluźnienie wystarczy w powyższym, ponieważ jest to zasadniczo optymalizacja: zawsze ścigamy się ze słabymi punktami, które są odrzucane.
            // W najgorszym przypadku niepotrzebnie przydzieliliśmy nowy łuk.
            //

            // Usunęliśmy ostatniego mocnego ref, ale pozostały dodatkowe słabe.
            // Przeniesiemy zawartość do nowej Łuki i unieważnimy inne słabe referencje.
            //

            // Zauważ, że nie jest możliwe, aby odczyt `weak` dał usize::MAX (tj. Zablokowany), ponieważ słaba liczba może być zablokowana tylko przez wątek z silnym odniesieniem.
            //
            //

            // Zmaterializuj nasz własny niejawny słaby wskaźnik, aby w razie potrzeby mógł wyczyścić ArcInner.
            //
            let _weak = Weak { ptr: this.ptr };

            // Może po prostu ukraść dane, wszystko, co zostało, to słabe
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Byliśmy jedynym punktem odniesienia w obu przypadkach;podnieś silną liczbę ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Podobnie jak w przypadku `get_mut()`, brak bezpieczeństwa jest w porządku, ponieważ nasze odniesienie było na początku unikalne lub stało się jednym po sklonowaniu zawartości.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Zwraca zmienne odniesienie do podanego `Arc`, jeśli nie ma innych wskaźników `Arc` lub [`Weak`] do tej samej alokacji.
    ///
    ///
    /// W przeciwnym razie zwraca [`None`], ponieważ nie jest bezpieczna zmiana wartości współdzielonej.
    ///
    /// Zobacz także [`make_mut`][make_mut], co spowoduje [`clone`][clone] wartość wewnętrzną, gdy istnieją inne wskaźniki.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // To zagrożenie jest w porządku, ponieważ mamy gwarancję, że zwrócony wskaźnik jest *jedynym* wskaźnikiem, który kiedykolwiek zostanie zwrócony do T.
            // Nasza liczba odniesień na tym etapie jest gwarantowana na 1, a sam Łuk wymagał, aby był `mut`, więc zwracamy jedyne możliwe odniesienie do danych wewnętrznych.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Zwraca zmienną referencję do podanego `Arc`, bez żadnego sprawdzenia.
    ///
    /// Zobacz także [`get_mut`], który jest bezpieczny i przeprowadza odpowiednie kontrole.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Żadnych innych wskaźników `Arc` lub [`Weak`] do tej samej alokacji nie można wyłuskiwać na czas trwania zwróconej pożyczki.
    ///
    /// Jest to trywialne w przypadku, gdy nie ma takich wskaźników, na przykład bezpośrednio po `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Uważamy, aby *nie* tworzyć odniesienia obejmującego pola "count", ponieważ oznaczałoby to alias z równoczesnym dostępem do zliczeń odwołań (np.
        // przez `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Określ, czy jest to unikalne odniesienie (w tym słabe referencje) do danych bazowych.
    ///
    ///
    /// Zauważ, że wymaga to zablokowania słabej liczby ref.
    fn is_unique(&mut self) -> bool {
        // zablokuj słaby wskaźnik, jeśli wydaje się, że jesteśmy jedynym słabym posiadaczem wskaźnika.
        //
        // Etykieta akwizycji zapewnia tutaj relację zdarzają się przed każdym zapisem do `strong` (w szczególności w `Weak::upgrade`) przed zmniejszeniem liczby `weak` (przez `Weak::drop`, który używa wydania).
        // Jeśli zaktualizowany słaby ref nigdy nie został upuszczony, CAS tutaj zawiedzie, więc nie dbamy o synchronizację.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Musi to być `Acquire`, aby zsynchronizować się z dekrementacją licznika `strong` w `drop`-jedyny dostęp, który ma miejsce, gdy odrzucane jest jakiekolwiek odniesienie oprócz ostatniego.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Zapis wydania tutaj synchronizuje się z odczytem w `downgrade`, skutecznie zapobiegając powyższemu odczytowi `strong` po zapisaniu.
            //
            //
            self.inner().weak.store(1, Release); // zwolnić blokadę
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Upuszcza `Arc`.
    ///
    /// Spowoduje to zmniejszenie liczby silnych odniesień.
    /// Jeśli liczba silnych odniesień osiągnie zero, wówczas jedynymi innymi odniesieniami (jeśli istnieją) są [`Weak`], więc `drop` jest wartością wewnętrzną.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Nic nie drukuje
    /// drop(foo2);   // Drukuje "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Ponieważ `fetch_sub` jest już atomowy, nie musimy synchronizować się z innymi wątkami, chyba że zamierzamy usunąć obiekt.
        // Ta sama logika dotyczy poniższej liczby `fetch_sub` do liczby `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // To ogrodzenie jest potrzebne, aby zapobiec zmianie kolejności wykorzystania danych i ich usunięciu.
        // Ponieważ jest oznaczony jako `Release`, zmniejszanie liczby referencyjnej synchronizuje się z tym ogranicznikiem `Acquire`.
        // Oznacza to, że użycie danych ma miejsce przed zmniejszeniem liczby referencji, co ma miejsce przed tym ogrodzeniem, co ma miejsce przed usunięciem danych.
        //
        // Jak wyjaśniono w [Boost documentation][1],
        //
        // > Ważne jest, aby wymusić jakikolwiek dostęp do obiektu w jednym
        // > wątek (poprzez istniejące odniesienie), aby *nastąpić przed* usunięciem
        // > obiekt w innym wątku.Osiąga się to dzięki "release"
        // > operacja po usunięciu referencji (dowolny dostęp do obiektu
        // > przez to odniesienie musiało się oczywiście wydarzyć wcześniej) i plik
        // > "acquire" operacja przed usunięciem obiektu.
        //
        // W szczególności, chociaż zawartość Arc jest zwykle niezmienna, możliwe jest zapisanie wnętrza do czegoś takiego jak mutex<T>.
        // Ponieważ Mutex nie jest pozyskiwany po usunięciu, nie możemy polegać na jego logice synchronizacji, aby zapisy w wątku A były widoczne dla destruktora działającego w wątku B.
        //
        //
        // Zwróć również uwagę, że ogrodzenie Acquire można prawdopodobnie zastąpić obciążeniem Acquire, co mogłoby poprawić wydajność w sytuacjach, w których często walczy się z rywalizacją.Zobacz [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Spróbuj obniżyć `Arc<dyn Any + Send + Sync>` do konkretnego typu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Konstruuje nowy `Weak<T>` bez przydzielania pamięci.
    /// Wywołanie [`upgrade`] na zwracanej wartości zawsze daje [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Typ pomocnika, aby umożliwić dostęp do liczników odwołań bez dokonywania jakichkolwiek potwierdzeń dotyczących pola danych.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Zwraca nieprzetworzony wskaźnik do obiektu `T` wskazywanego przez ten `Weak<T>`.
    ///
    /// Wskaźnik jest poprawny tylko wtedy, gdy istnieją silne odniesienia.
    /// Wskaźnik może być wiszący, niewyrównany lub w przeciwnym razie nawet [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Obie wskazują ten sam obiekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Silny tutaj utrzymuje go przy życiu, więc nadal możemy uzyskać dostęp do obiektu.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ale już nie.
    /// // Możemy zrobić weak.as_ptr(), ale dostęp do wskaźnika prowadziłby do nieokreślonego zachowania.
    /// // assert_eq! ("witaj", niebezpieczne {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Jeśli wskaźnik się wisi, zwracamy bezpośrednio wartownika.
            // Nie może to być prawidłowy adres ładunku, ponieważ ładunek jest co najmniej tak wyrównany, jak ArcInner (usize).
            ptr as *const T
        } else {
            // BEZPIECZEŃSTWO: jeśli is_dangling zwraca false, to wskaźnik można wyłuskać.
            // W tym momencie ładunek może zostać upuszczony i musimy zachować pochodzenie, więc użyj surowej manipulacji wskaźnikiem.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Zużywa `Weak<T>` i zamienia go w surowy wskaźnik.
    ///
    /// To konwertuje słaby wskaźnik do surowego wskaźnika, zachowując jednocześnie własność jednego słabego odniesienia (słaba liczba nie jest modyfikowana przez tę operację).
    /// Można go przekształcić z powrotem w `Weak<T>` za pomocą [`from_raw`].
    ///
    /// Obowiązują te same ograniczenia dostępu do celu wskaźnika, jak w przypadku [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konwertuje nieprzetworzony wskaźnik utworzony wcześniej przez [`into_raw`] z powrotem na `Weak<T>`.
    ///
    /// Można to wykorzystać do bezpiecznego uzyskania silnego odniesienia (wywołując później [`upgrade`]) lub do zwolnienia słabej liczby, upuszczając `Weak<T>`.
    ///
    /// Przejmuje na własność jedno słabe odniesienie (z wyjątkiem wskaźników utworzonych przez [`new`], ponieważ one niczego nie posiadają; metoda nadal na nich działa).
    ///
    /// # Safety
    ///
    /// Wskaźnik musi pochodzić z [`into_raw`] i nadal musi posiadać swoje potencjalne słabe odniesienie.
    ///
    /// Dopuszczalne jest, aby silna liczba wynosiła 0 w momencie wywołania tego.
    /// Niemniej jednak przejmuje to na własność jedno słabe odniesienie, które jest obecnie reprezentowane jako nieprzetworzony wskaźnik (słaba liczba nie jest modyfikowana przez tę operację) i dlatego musi być sparowana z poprzednim wywołaniem [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Zmniejsz ostatnią słabą liczbę.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Zobacz Weak::as_ptr, aby zapoznać się z kontekstem, w jaki sposób wyprowadzany jest wskaźnik wejściowy.

        let ptr = if is_dangling(ptr as *mut T) {
            // To jest wiszący Słaby.
            ptr as *mut ArcInner<T>
        } else {
            // W przeciwnym razie mamy gwarancję, że wskaźnik pochodzi od nieplączącego się słabego.
            // BEZPIECZEŃSTWO: data_offset jest bezpieczna do wywołania, ponieważ ptr odwołuje się do rzeczywistego (potencjalnie upuszczonego) T.
            let offset = unsafe { data_offset(ptr) };
            // W ten sposób odwracamy przesunięcie, aby uzyskać cały RcBox.
            // BEZPIECZEŃSTWO: wskaźnik pochodzi ze słabego, więc to przesunięcie jest bezpieczne.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // BEZPIECZEŃSTWO: odzyskaliśmy oryginalny wskaźnik słabych, więc możemy stworzyć słabe.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Próbuje uaktualnić wskaźnik `Weak` do [`Arc`], opóźniając upuszczenie wartości wewnętrznej, jeśli się powiedzie.
    ///
    ///
    /// Zwraca [`None`], jeśli wartość wewnętrzna została od tego czasu usunięta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Zniszcz wszystkie silne wskazówki.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Używamy pętli CAS do zwiększania silnej liczby zamiast funkcji fetch_add, ponieważ ta funkcja nigdy nie powinna przyjmować liczby odwołań od zera do jednego.
        //
        //
        let inner = self.inner()?;

        // Rozluźnione obciążenie, ponieważ każdy zapis 0, który możemy obserwować, pozostawia pole w stanie trwale zerowym (więc odczyt "stale" równy 0 jest w porządku), a każda inna wartość jest potwierdzana przez poniższy CAS.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Zobacz komentarze w `Arc::clone`, aby dowiedzieć się, dlaczego to robimy (dla `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Rozluźnienie jest dobre w przypadku niepowodzenia, ponieważ nie mamy żadnych oczekiwań co do nowego stanu.
            // Acquire jest konieczne, aby przypadek powodzenia został zsynchronizowany z `Arc::new_cyclic`, gdy wartość wewnętrzna może zostać zainicjowana po utworzeniu odwołań `Weak`.
            // W takim przypadku spodziewamy się zaobserwować w pełni zainicjowaną wartość.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null zaznaczone powyżej
                Err(old) => n = old,
            }
        }
    }

    /// Pobiera liczbę silnych wskaźników (`Arc`) wskazujących na tę alokację.
    ///
    /// Jeśli `self` został utworzony przy użyciu [`Weak::new`], zwróci to 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Pobiera przybliżoną liczbę wskaźników `Weak` wskazujących na tę alokację.
    ///
    /// Jeśli `self` został utworzony przy użyciu [`Weak::new`] lub jeśli nie ma pozostałych silnych wskaźników, zwróci to 0.
    ///
    /// # Accuracy
    ///
    /// Ze względu na szczegóły implementacji zwracana wartość może być wyłączona o 1 w dowolnym kierunku, gdy inne wątki manipulują dowolnymi wartościami " Arc`lub " Weak` wskazującymi na tę samą alokację.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Ponieważ zaobserwowaliśmy, że po odczytaniu słabej liczby wystąpił co najmniej jeden silny wskaźnik, wiemy, że niejawne słabe odniesienie (obecne zawsze, gdy żyją jakiekolwiek silne odniesienia) było nadal w pobliżu, gdy zaobserwowaliśmy słaby licznik, i dlatego możemy je bezpiecznie odjąć.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Zwraca `None`, gdy wskaźnik zwisa i nie ma przydzielonego `ArcInner` (tj. Kiedy ten `Weak` został utworzony przez `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Uważamy, aby *nie* utworzyć odniesienia obejmującego pole "data", ponieważ pole może być jednocześnie mutowane (na przykład, jeśli ostatnie `Arc` zostanie usunięte, pole danych zostanie usunięte w miejscu).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Zwraca `true`, jeśli dwa " Słabe` wskazują na tę samą alokację (podobnie jak w [`ptr::eq`]) lub jeśli oba nie wskazują na żadną alokację (ponieważ zostały utworzone za pomocą `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Ponieważ porównuje to wskaźniki, oznacza to, że `Weak::new()` będą sobie równe, nawet jeśli nie wskazują na żadną alokację.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Porównanie `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Tworzy klon wskaźnika `Weak`, który wskazuje na tę samą alokację.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Zobacz komentarze w Arc::clone(), aby dowiedzieć się, dlaczego jest to rozluźnione.
        // Może to użyć fetch_add (ignorowanie blokady), ponieważ słaba liczba jest zablokowana tylko wtedy, gdy *nie ma innych* słabych wskaźników.
        //
        // (Więc w takim przypadku nie możemy uruchomić tego kodu).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Zobacz komentarze w Arc::clone(), aby dowiedzieć się, dlaczego to robimy (dla mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruuje nowy `Weak<T>` bez przydzielania pamięci.
    /// Wywołanie [`upgrade`] na zwracanej wartości zawsze daje [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Upuszcza wskaźnik `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nic nie drukuje
    /// drop(foo);        // Drukuje "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Jeśli dowiemy się, że byliśmy ostatnim słabym wskaźnikiem, czas całkowicie zwolnić dane.Zobacz dyskusję w Arc::drop() na temat kolejności pamięci
        //
        // Nie jest tu konieczne sprawdzanie stanu zablokowanego, ponieważ słaby licznik może zostać zablokowany tylko wtedy, gdy był dokładnie jeden słaby ref, co oznacza, że drop może następnie przejść tylko na pozostałym słabym ref, co może się zdarzyć dopiero po zwolnieniu blokady.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Robimy tę specjalizację tutaj, a nie jako bardziej ogólną optymalizację na `&T`, ponieważ w przeciwnym razie dodałoby to koszt do wszystkich sprawdzeń równości w referencjach.
/// Zakładamy, że `Arc`s są używane do przechowywania dużych wartości, które są powolne do klonowania, ale także ciężkie do sprawdzenia równości, co powoduje, że ten koszt łatwiej się zwraca.
///
/// Bardziej prawdopodobne jest również istnienie dwóch klonów `Arc`, które wskazują na tę samą wartość, niż dwa znaki " &T`.
///
/// Możemy to zrobić tylko wtedy, gdy `T: Eq` jako `PartialEq` może celowo nie działać odruchowo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Równość dla dwóch " łuków`.
    ///
    /// Dwa `Arc` są równe, jeśli ich wewnętrzne wartości są równe, nawet jeśli są przechowywane w różnych alokacjach.
    ///
    /// Jeśli `T` również implementuje `Eq` (implikując refleksyjność równości), dwa " Arc`, które wskazują na tę samą alokację, są zawsze równe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Nierówność dla dwóch `Arc`s.
    ///
    /// Dwa `Arc` są nierówne, jeśli ich wewnętrzne wartości są nierówne.
    ///
    /// Jeśli `T` implementuje również `Eq` (implikując refleksyjność równości), dwa " Arc`, które wskazują na tę samą wartość, nigdy nie są nierówne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Częściowe porównanie dla dwóch `Arc`s.
    ///
    /// Porównuje się je, wywołując `partial_cmp()` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mniej niż porównanie dla dwóch `Arc`s.
    ///
    /// Porównuje się je, wywołując `<` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Porównanie " mniejsze lub równe`dla dwóch " łuków`.
    ///
    /// Porównuje się je, wywołując `<=` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Porównanie większe niż dla dwóch `Arc`s.
    ///
    /// Porównuje się je, wywołując `>` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Porównanie " Większe lub równe`dla dwóch " Łuków`.
    ///
    /// Porównuje się je, wywołując `>=` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Porównanie dla dwóch " Arc`.
    ///
    /// Porównuje się je, wywołując `cmp()` na ich wartościach wewnętrznych.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Tworzy nowy `Arc<T>` z wartością `Default` dla `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Przydziel wycinek zliczany jako odniesienie i wypełnij go, klonując elementy " v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Przydziel `str` liczony jako referencje i skopiuj do niego `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Przydziel `str` liczony jako referencje i skopiuj do niego `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Przenieś obiekt w ramce do nowej alokacji zliczanej jako odwołania.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Przydziel wycinek zliczany w odniesieniu do referencji i przenieś do niego elementy " v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Pozwól Vek uwolnić pamięć, ale nie niszcz jej zawartości
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Pobiera każdy element z `Iterator` i gromadzi go w `Arc<[T]>`.
    ///
    /// # Charakterystyka wydajności
    ///
    /// ## Ogólny przypadek
    ///
    /// W ogólnym przypadku zbieranie danych do `Arc<[T]>` odbywa się najpierw poprzez gromadzenie danych do `Vec<T>`.Oznacza to, że pisząc:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// zachowuje się tak, jakbyśmy napisali:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Tutaj odbywa się pierwszy zestaw przydziałów.
    ///     .into(); // Tutaj następuje drugi przydział dla `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Spowoduje to alokację tyle razy, ile potrzeba do skonstruowania `Vec<T>`, a następnie przydzieli raz na przekształcenie `Vec<T>` w `Arc<[T]>`.
    ///
    ///
    /// ## Iteratory o znanej długości
    ///
    /// Kiedy `Iterator` implementuje `TrustedLen` i ma dokładny rozmiar, zostanie dokonana pojedyncza alokacja dla `Arc<[T]>`.Na przykład:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Tutaj odbywa się tylko jeden przydział.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specjalizacja trait używana do zbierania do `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Tak jest w przypadku iteratora `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BEZPIECZEŃSTWO: Musimy upewnić się, że iterator ma dokładną długość i tak jest.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Wróć do normalnej implementacji.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Uzyskaj przesunięcie w `ArcInner` dla ładunku znajdującego się za wskaźnikiem.
///
/// # Safety
///
/// Wskaźnik musi wskazywać (i mieć prawidłowe metadane) na poprzednio prawidłowe wystąpienie T, ale T może zostać usunięta.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Wyrównaj niewymiarową wartość do końca ArcInner.
    // Ponieważ RcBox to repr(C), zawsze będzie to ostatnie pole w pamięci.
    // BEZPIECZEŃSTWO: ponieważ jedynymi możliwymi typami bez rozmiaru są plasterki, obiekty trait,
    // i extern, wymaganie bezpieczeństwa wejścia jest obecnie wystarczające, aby spełnić wymagania align_of_val_raw;jest to szczegół implementacji języka, na którym nie można polegać poza std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}