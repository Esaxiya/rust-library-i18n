//! Narzędzia do formatowania i drukowania `String`ów.
//!
//! Ten moduł zawiera obsługę środowiska wykonawczego dla rozszerzenia składni [`format!`].
//! To makro jest zaimplementowane w kompilatorze w celu emitowania wywołań do tego modułu w celu formatowania argumentów w czasie wykonywania w ciągi.
//!
//! # Usage
//!
//! Makro [`format!`] ma być znane tym, które pochodzą z funkcji `printf`/`fprintf` języka C lub funkcji `str.format` w Python.
//!
//! Oto kilka przykładów rozszerzenia [`format!`]:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" z zerami na początku
//! ```
//!
//! Z tego widać, że pierwszy argument jest ciągiem formatu.Kompilator wymaga, aby był to literał ciągu;nie może być zmienną przekazaną (w celu sprawdzenia poprawności).
//! Kompilator następnie przeanalizuje ciąg formatu i określi, czy lista podanych argumentów jest odpowiednia do przekazania do tego ciągu formatu.
//!
//! Aby przekonwertować pojedynczą wartość na ciąg, użyj metody [`to_string`].Spowoduje to użycie formatowania [`Display`] trait.
//!
//! ## Parametry pozycyjne
//!
//! Każdy argument formatujący może określać, do którego argumentu wartości się odwołuje, a jeśli zostanie pominięty, zakłada się, że jest to "the next argument".
//! Na przykład ciąg formatu `{} {} {}` wymagałby trzech parametrów i byłyby one sformatowane w tej samej kolejności, w jakiej zostały podane.
//! Jednak ciąg formatu `{2} {1} {0}` sformatowałby argumenty w odwrotnej kolejności.
//!
//! Sprawy mogą się trochę skomplikować, gdy zaczniesz mieszać te dwa typy specyfikatorów pozycyjnych.Specyfikator "next argument" można traktować jako iterator po argumencie.
//! Za każdym razem, gdy specyfikator "next argument" jest widoczny, iterator przechodzi do przodu.Prowadzi to do takich zachowań:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Wewnętrzny iterator argumentu nie był zaawansowany do czasu zobaczenia pierwszego `{}`, więc wypisuje pierwszy argument.Następnie, po osiągnięciu drugiego `{}`, iterator przeszedł do drugiego argumentu.
//! Zasadniczo parametry, które jawnie nazywają swój argument, nie wpływają na parametry, które nie nazywają argumentów w kategoriach specyfikatorów pozycyjnych.
//!
//! Aby użyć wszystkich swoich argumentów, wymagany jest ciąg formatu, w przeciwnym razie jest to błąd kompilacji.Możesz odwoływać się do tego samego argumentu więcej niż raz w ciągu formatu.
//!
//! ## Nazwane parametry
//!
//! Sam Rust nie ma podobnego do Python odpowiednika nazwanych parametrów funkcji, ale makro [`format!`] jest rozszerzeniem składni, które pozwala na wykorzystanie nazwanych parametrów.
//! Nazwane parametry są wymienione na końcu listy argumentów i mają składnię:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Na przykład wszystkie poniższe wyrażenia [`format!`] używają nazwanego argumentu:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Nie jest poprawne umieszczanie parametrów pozycyjnych (tych bez nazw) po argumentach, które mają nazwy.Podobnie jak w przypadku parametrów pozycyjnych, podawanie nazwanych parametrów, które nie są używane w ciągu formatu, nie jest poprawne.
//!
//! # Parametry formatowania
//!
//! Każdy formatowany argument można przekształcić za pomocą szeregu parametrów formatowania (odpowiadających `format_spec` w [the syntax](#syntax)). Parametry te wpływają na ciąg reprezentujący formatowany element.
//!
//! ## Width
//!
//! ```
//! // Wszystkie z nich drukują "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Jest to parametr dla "minimum width", który powinien przyjąć format.
//! Jeśli łańcuch wartości nie wypełnia tylu znaków, wypełnienie określone przez fill/alignment zostanie użyte do zajęcia wymaganej przestrzeni (patrz poniżej).
//!
//! Wartość szerokości można również podać jako [`usize`] na liście parametrów, dodając przyrostek `$`, wskazujący, że drugi argument to [`usize`] określający szerokość.
//!
//! Odwołanie się do argumentu ze składnią dolara nie wpływa na licznik "next argument", więc zwykle dobrym pomysłem jest odwoływanie się do argumentów według pozycji lub używanie nazwanych argumentów.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Opcjonalny znak wypełnienia i wyrównanie są zwykle dostarczane w połączeniu z parametrem [`width`](#width).Musi być zdefiniowany przed `width`, zaraz po `:`.
//! Oznacza to, że jeśli formatowana wartość jest mniejsza niż `width`, wokół niej zostaną wydrukowane dodatkowe znaki.
//! Wypełnienie jest dostępne w następujących wariantach dla różnych ustawień:
//!
//! * `[fill]<` - argument jest wyrównany do lewej w kolumnach `width`
//! * `[fill]^` - argument jest wyśrodkowany w kolumnach `width`
//! * `[fill]>` - argument jest wyrównany do prawej w kolumnach `width`
//!
//! Domyślnym [fill/alignment](#fillalignment) dla wartości nienumerycznych jest spacja i wyrównanie do lewej.Wartością domyślną dla elementów formatujących liczb jest również znak spacji, ale z wyrównaniem do prawej.
//! Jeśli flaga `0` (patrz poniżej) jest określona dla liczb, to niejawnym znakiem wypełnienia jest `0`.
//!
//! Należy pamiętać, że wyrównanie może nie być realizowane przez niektóre typy.W szczególności nie jest generalnie zaimplementowany w `Debug` trait.
//! Dobrym sposobem na upewnienie się, że zastosowano dopełnienie, jest sformatowanie danych wejściowych, a następnie wypełnienie tego ciągu wynikowego w celu uzyskania wyniku:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => " Hello Some("hi")!`
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! To są wszystkie flagi zmieniające zachowanie programu formatującego.
//!
//! * `+` - Jest to przeznaczone dla typów numerycznych i wskazuje, że znak powinien być zawsze drukowany.Znaki dodatnie nigdy nie są drukowane domyślnie, a znak ujemny jest drukowany domyślnie tylko dla `Signed` trait.
//! Ta flaga wskazuje, że zawsze powinien być drukowany prawidłowy znak (`+` lub `-`).
//! * `-` - Obecnie nie używany
//! * `#` - Ta flaga wskazuje, że należy użyć formy drukowania "alternate".Alternatywne formy to:
//!     * `#?` - ładnie wydrukuj formatowanie [`Debug`]
//!     * `#x` - poprzedza argument `0x`
//!     * `#X` - poprzedza argument `0x`
//!     * `#b` - poprzedza argument `0b`
//!     * `#o` - poprzedza argument `0o`
//! * `0` - Służy do wskazania dla formatów liczb całkowitych, że dopełnienie `width` powinno być wykonane zarówno znakiem `0`, jak i uwzględniać znaki.
//! Format taki jak `{:08}` dałby `00000001` dla liczby całkowitej `1`, podczas gdy ten sam format dałby `-0000001` dla liczby całkowitej `-1`.
//! Zwróć uwagę, że wersja negatywna ma o jedno zero mniej niż wersja pozytywna.
//!         Zwróć uwagę, że zera wypełniające są zawsze umieszczane po znaku (jeśli występują) i przed cyframi.W przypadku użycia razem z flagą `#` obowiązuje podobna zasada: zera wypełniające są wstawiane po przedrostku, ale przed cyframi.
//!         Prefiks jest zawarty w całkowitej szerokości.
//!
//! ## Precision
//!
//! W przypadku typów nienumerycznych można to uznać za "maximum width".
//! Jeśli wynikowy ciąg jest dłuższy niż ta szerokość, to jest obcinany do tylu znaków, a ta obcięta wartość jest emitowana z odpowiednimi `fill`, `alignment` i `width`, jeśli te parametry są ustawione.
//!
//! W przypadku typów całkowitych jest to ignorowane.
//!
//! W przypadku typów zmiennoprzecinkowych wskazuje, ile cyfr po przecinku ma zostać wydrukowanych.
//!
//! Istnieją trzy możliwe sposoby określenia żądanego `precision`:
//!
//! 1. Liczba całkowita `.N`:
//!
//!    sama liczba całkowita `N` to precyzja.
//!
//! 2. Liczba całkowita lub nazwa, po której następuje znak dolara `.N$`:
//!
//!    użyj argumentu format * *`N` (który musi być `usize`) jako precyzji.
//!
//! 3. Gwiazdka `.*`:
//!
//!    `.*` oznacza, że ten `{...}` jest powiązany z *dwoma* wejściami formatu, a nie z jednym: pierwsze wejście posiada precyzję `usize`, a drugie zawiera wartość do wydrukowania.
//!    Zauważ, że w tym przypadku, jeśli używa się ciągu formatu `{<arg>:<spec>.*}`, to część `<arg>` odwołuje się do* wartości * do wydrukowania, a `precision` musi znajdować się na wejściu poprzedzającym `<arg>`.
//!
//! Na przykład następujące wywołania wyświetlają to samo `Hello x is 0.01000`:
//!
//! ```
//! // Witam {arg 0 ("x")} to {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Witam {arg 1 ("x")} to {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Witam {arg 0 ("x")} to {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Witam {next arg ("x")} to {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Witam {next arg ("x")} to {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Witam {next arg ("x")} to {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Podczas gdy te:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! wydrukuj trzy znacząco różne rzeczy:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! W niektórych językach programowania zachowanie funkcji formatowania ciągów zależy od ustawień regionalnych systemu operacyjnego.
//! Funkcje formatu dostarczane przez standardową bibliotekę Rust nie mają żadnej koncepcji lokalizacji i będą dawać takie same wyniki we wszystkich systemach, niezależnie od konfiguracji użytkownika.
//!
//! Na przykład poniższy kod zawsze wypisze `1.5`, nawet jeśli ustawienia regionalne systemu używają separatora dziesiętnego innego niż kropka.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Znaki literału `{` i `}` mogą być zawarte w ciągu, poprzedzając je tym samym znakiem.Na przykład znak `{` jest chroniony za pomocą `{{`, a znak `}` jest chroniony za pomocą `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Podsumowując, tutaj możesz znaleźć pełną gramatykę ciągów formatujących.
//! Składnia używanego języka formatowania pochodzi z innych języków, więc nie powinna być zbyt obca.Argumenty są formatowane za pomocą składni podobnej do Python, co oznacza, że argumenty są otoczone `{}` zamiast `%` podobnym do C.
//! Rzeczywista gramatyka składni formatowania to:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! W powyższej gramatyce `text` nie może zawierać żadnych znaków `'{'` ani `'}'`.
//!
//! # Formatowanie traits
//!
//! Żądając, aby argument był sformatowany przy użyciu określonego typu, w rzeczywistości żądasz, aby argument przypisał określony trait.
//! Pozwala to na formatowanie wielu rzeczywistych typów za pomocą `{:x}` (np. [`i8`] i [`isize`]).Aktualne mapowanie typów do traits to:
//!
//! * *nic* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] z małymi literami szesnastkowymi liczbami całkowitymi
//! * `X?` ⇒ [`Debug`] z dużymi szesnastkowymi liczbami całkowitymi
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Oznacza to, że każdy typ argumentu, który implementuje [`fmt::Binary`][`Binary`] trait, może być następnie sformatowany za pomocą `{:b}`.Implementacje są dostarczane dla tych traits dla wielu typów pierwotnych również przez bibliotekę standardową.
//!
//! Jeśli nie określono formatu (jak w `{}` lub `{:6}`), wówczas używanym formatem trait jest [`Display`] trait.
//!
//! Implementując format trait dla własnego typu, będziesz musiał zaimplementować metodę podpisu:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // nasz typ niestandardowy
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Twój typ zostanie przekazany jako odniesienie `self`, a następnie funkcja powinna wyemitować dane wyjściowe do strumienia `f.buf`.Prawidłowe przestrzeganie żądanych parametrów formatowania zależy od każdej implementacji formatu trait.
//! Wartości tych parametrów zostaną wymienione w polach struktury [`Formatter`].Aby w tym pomóc, struktura [`Formatter`] zapewnia również kilka metod pomocniczych.
//!
//! Ponadto wartością zwracaną przez tę funkcję jest [`fmt::Result`], który jest aliasem typu [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Implementacje formatowania powinny zapewniać, że propagują błędy z [`Formatter`] (np. Podczas wywoływania [`write!`]).
//! Jednak nigdy nie powinny fałszywie zwracać błędów.
//! Oznacza to, że implementacja formatowania musi i może zwracać błąd tylko wtedy, gdy przekazany [`Formatter`] zwraca błąd.
//! Dzieje się tak, ponieważ w przeciwieństwie do tego, co może sugerować sygnatura funkcji, formatowanie ciągu znaków jest operacją niezawodną.
//! Ta funkcja zwraca tylko wynik, ponieważ zapis do źródłowego strumienia może się nie powieść i musi zapewniać sposób propagowania faktu, że wystąpił błąd w kopii zapasowej stosu.
//!
//! Przykład implementacji formatowania traits wyglądałby następująco:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Wartość `f` implementuje `Write` trait, co jest tym, co pisze!oczekuje makro.
//!         // Zauważ, że to formatowanie ignoruje różne flagi dostarczone do formatowania ciągów.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Różne traits pozwalają na różne formy wyjścia danego typu.
//! // Znaczenie tego formatu polega na wydrukowaniu wielkości vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Przestrzegaj flag formatowania, używając metody pomocnika `pad_integral` w obiekcie Formatter.
//!         // Zobacz dokumentację metody, aby uzyskać szczegółowe informacje, a funkcja `pad` może być używana do dopełniania ciągów.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` w porównaniu z `fmt::Debug`
//!
//! Te dwa formatujące traits mają różne cele:
//!
//! - [`fmt::Display`][`Display`] implementacje zapewniają, że typ może być zawsze wiernie reprezentowany jako łańcuch UTF-8.**Nie** oczekuje się, że wszystkie typy implementują [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] implementacje powinny być zaimplementowane dla **wszystkich** publicznych typów.
//!   Dane wyjściowe będą zazwyczaj jak najwierniej odzwierciedlać stan wewnętrzny.
//!   Celem [`Debug`] trait jest ułatwienie debugowania kodu Rust.W większości przypadków użycie `#[derive(Debug)]` jest wystarczające i zalecane.
//!
//! Kilka przykładów danych wyjściowych z obu traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Powiązane makra
//!
//! Rodzina [`format!`] zawiera wiele powiązanych makr.Obecnie wdrażane są:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! To i [`writeln!`] to dwa makra, które są używane do emitowania ciągu formatu do określonego strumienia.Służy to do zapobiegania pośrednim alokacjom ciągów formatu i zamiast tego bezpośrednio zapisuje dane wyjściowe.
//! Pod maską ta funkcja w rzeczywistości wywołuje funkcję [`write_fmt`] zdefiniowaną w [`std::io::Write`] trait.
//! Przykładowe użycie to:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! To i [`println!`] emitują swoje dane wyjściowe do stdout.Podobnie jak w przypadku makra [`write!`], celem tych makr jest uniknięcie pośrednich alokacji podczas drukowania danych wyjściowych.Przykładowe użycie to:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makra [`eprint!`] i [`eprintln!`] są identyczne jak odpowiednio [`print!`] i [`println!`], z wyjątkiem tego, że emitują swoje dane wyjściowe do stderr.
//!
//! ### `format_args!`
//!
//! Jest to ciekawe makro używane do bezpiecznego przekazywania nieprzezroczystego obiektu opisującego ciąg formatu.Ten obiekt nie wymaga żadnych alokacji sterty do utworzenia i odwołuje się tylko do informacji na stosie.
//! Pod maską wszystkie powiązane makra są zaimplementowane pod tym kątem.
//! Po pierwsze, przykładowe użycie to:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Wynikiem działania makra [`format_args!`] jest wartość typu [`fmt::Arguments`].
//! Ta struktura może być następnie przekazana do funkcji [`write`] i [`format`] wewnątrz tego modułu w celu przetworzenia ciągu formatu.
//! Celem tego makra jest jeszcze większe zapobieganie alokacjom pośrednim podczas formatowania ciągów.
//!
//! Na przykład biblioteka rejestrowania mogłaby używać standardowej składni formatowania, ale wewnętrznie przekazywałaby tę strukturę, dopóki nie zostanie ustalone, gdzie powinny trafiać dane wyjściowe.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Funkcja `format` przyjmuje strukturę [`Arguments`] i zwraca wynikowy sformatowany ciąg.
///
///
/// Instancję [`Arguments`] można utworzyć za pomocą makra [`format_args!`].
///
/// # Examples
///
/// Podstawowe użycie:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Należy pamiętać, że użycie [`format!`] może być lepsze.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}