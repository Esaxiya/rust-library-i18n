//! İşlem iptalleri yoluyla Rust panics'nin uygulanması
//!
//! Çözme yoluyla uygulama ile karşılaştırıldığında, bu crate *çok* daha basittir!Olduğu söyleniyor, o kadar çok yönlü değil, ama işte başlıyor!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" söz konusu platformdaki ilgili iptal için yük ve şim.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal i ara
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows te işlemciye özgü __fastfail mekanizmasını kullanın.Windows 8 ve sonraki sürümlerde bu, herhangi bir işlem içi istisna işleyicisi çalıştırmadan işlemi hemen sonlandıracaktır.
            // Windows in önceki sürümlerinde, bu talimat dizisi bir erişim ihlali olarak değerlendirilecek ve işlemi sonlandıracak, ancak tüm istisna işleyicileri baypas edilmeyecek.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: bu, libstd'nin `abort_internal` indeki ile aynı uygulama
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Bu ... biraz tuhaf.Tl; dr;bunun doğru bir şekilde bağlanması için gerekli olduğudur, daha uzun açıklama aşağıdadır.
//
// Şu anda gönderdiğimiz libcore/libstd ikili dosyalarının tümü `-C panic=unwind` ile derlenmiştir.Bu, ikili dosyaların olabildiğince çok durumla maksimum uyumlu olmasını sağlamak için yapılır.
// Ancak derleyici, `-C panic=unwind` ile derlenen tüm işlevler için bir "personality function" gerektirir.Bu kişilik işlevi, `rust_eh_personality` sembolüne kodlanmıştır ve `eh_personality` dil öğesi ile tanımlanmıştır.
//
// So...
// neden bu dil öğesini burada tanımlamıyorsunuz?İyi soru!panic çalışma zamanlarının bağlanma şekli aslında derleyicinin crate deposunda "sort of" olmaları açısından biraz inceliklidir, ancak yalnızca bir başkası gerçekten bağlantılı değilse gerçekten bağlantılı.
//
// Bu, hem bu crate hem de panic_unwind crate'nin derleyicinin crate deposunda görünebileceği anlamına gelir ve eğer her ikisi de `eh_personality` lang öğesini tanımlarsa bu bir hataya neden olur.
//
// Bunun üstesinden gelmek için derleyici, yalnızca bağlanılan panic çalışma zamanı çözülme çalışma zamanıysa `eh_personality` in tanımlanmasını gerektirir ve aksi takdirde tanımlanması gerekmez (haklı olarak öyle).
// Ancak bu durumda, bu kütüphane sadece bu sembolü tanımlar, böylece bir yerlerde en azından bir miktar kişilik vardır.
//
// Esasen bu sembol sadece libcore/libstd ikili dosyalarına bağlanmak için tanımlanmıştır, ancak çözülmeyen bir çalışma süresine hiç bağlanmadığımız için asla çağrılmamalıdır.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-windows-gnu'de, tüm çerçevelerimizi aktarırken `ExceptionContinueSearch` i döndürmesi gereken kendi kişilik işlevimizi kullanıyoruz.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Yukarıdakine benzer şekilde, bu, şu anda yalnızca Emscripten'da kullanılan `eh_catch_typeinfo` dil öğesine karşılık gelir.
    //
    // panics istisnalar oluşturmadığından ve yabancı istisnalar şu anda -C panic=abort ile UB olduğundan (bu değişebilir olsa da), herhangi bir catch_unwind çağrısı bu tür bilgisini asla kullanmayacaktır.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Bu ikisi i686-pc-windows-gnu üzerindeki başlangıç nesnelerimiz tarafından çağrılır, ancak vücutların nops olması için herhangi bir şey yapmalarına gerek yoktur.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}