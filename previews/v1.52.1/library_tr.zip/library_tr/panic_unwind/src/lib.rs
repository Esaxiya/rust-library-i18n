//! Yığın çözme yoluyla panics'nin uygulanması
//!
//! Bu crate, bunun için derlendiği platformun "most native" yığın çözme mekanizmasını kullanan Rust'deki panics'nin bir uygulamasıdır.
//! Bu, esasen şu anda üç gruba ayrılmıştır:
//!
//! 1. MSVC hedefleri, `seh.rs` dosyasında SEH kullanır.
//! 2. Emscripten, `emcc.rs` dosyasında C++ istisnalarını kullanır.
//! 3. Diğer tüm hedefler `gcc.rs` dosyasında libunwind/libgcc i kullanır.
//!
//! Her bir uygulama hakkında daha fazla belge, ilgili modülde bulunabilir.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` Miri ile kullanılmadığından uyarıları susturun.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust çalışma zamanının başlangıç nesneleri bu sembollere bağlıdır, bu yüzden onları genel yapın.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Çözülmeyi desteklemeyen hedefler.
        // - arch=wasm32
        // - os=yok ("bare metal" hedefleri)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Miri çalışma zamanını kullanın.
        // rustc buradan belirli dil öğelerinin tanımlanmasını beklediğinden, yukarıdaki normal çalışma zamanını da yüklememiz gerekiyor.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Gerçek çalışma zamanını kullanın.
        use real_imp as imp;
    }
}

extern "C" {
    /// Libstd'deki işleyici, bir panic nesnesi `catch_unwind` in dışına bırakıldığında çağrılır.
    ///
    fn __rust_drop_panic() -> !;

    /// Libstd'deki işleyici, yabancı bir istisna yakalandığında çağrılır.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Bir istisna oluşturmak için giriş noktası, yalnızca platforma özgü uygulamaya delege olur.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}