//! Windows SEH
//!
//! Windows te (şu anda yalnızca MSVC'de), varsayılan istisna işleme mekanizması Yapılandırılmış İstisna İşleme (SEH) tir.
//! Bu, derleyici iç bileşenleri açısından Cüce tabanlı istisna işlemeden (örneğin, diğer unix platformlarının kullandığı) oldukça farklıdır, bu nedenle LLVM'nin SEH için oldukça fazla ekstra desteğe sahip olması gerekir.
//!
//! Özetle, burada olan şudur:
//!
//! 1. `panic` işlevi, çözme sürecini tetikleyerek C++ benzeri bir istisna atmak için standart Windows işlevi `_CxxThrowException` i çağırır.
//! 2.
//! Derleyici tarafından üretilen tüm iniş pedleri, CRT'deki bir işlev olan `__CxxFrameHandler3` kişilik işlevini kullanır ve Windows teki çözme kodu, yığın üzerindeki tüm temizleme kodunu yürütmek için bu kişilik işlevini kullanır.
//!
//! 3. `invoke` e derleyici tarafından üretilen tüm çağrılarda, temizleme rutininin başlangıcını belirten bir `cleanuppad` LLVM talimatı olarak ayarlanmış bir iniş pedi vardır.
//! Kişilik (CRT'de tanımlanan 2. adımda) temizlik rutinlerini yürütmekten sorumludur.
//! 4. Sonunda `try` içselindeki (derleyici tarafından üretilen) "catch" kodu yürütülür ve kontrolün Rust'ye geri gelmesi gerektiğini belirtir.
//! Bu, bir `catchswitch` artı LLVM IR terimlerinde bir `catchpad` talimatı ile yapılır ve sonunda `catchret` komutu ile normal kontrolü programa döndürür.
//!
//! gcc tabanlı istisna işlemeden bazı özel farklılıklar şunlardır:
//!
//! * Rust'nin özel bir kişilik işlevi yoktur, bunun yerine *her zaman*`__CxxFrameHandler3` tir.Ek olarak, fazladan filtreleme yapılmaz, bu nedenle attığımız tür gibi görünen herhangi bir C++ istisnasını yakalarız.
//! Rust'ye bir istisna atmanın tanımsız bir davranış olduğunu unutmayın, bu yüzden bu iyi olmalıdır.
//! * Çözme sınırının ötesine aktaracak bazı verilerimiz var, özellikle bir `Box<dyn Any + Send>`.Cüce istisnalarında olduğu gibi, bu iki işaretçi istisnanın kendisinde bir yük olarak saklanır.
//! Ancak MSVC'de, filtre işlevleri yürütülürken çağrı yığını korunduğundan fazladan bir yığın ayırmaya gerek yoktur.
//! Bu, işaretçilerin doğrudan `_CxxThrowException` e aktarıldığı ve daha sonra `try` içselinin yığın çerçevesine yazılmak üzere filtre işlevinde kurtarıldığı anlamına gelir.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Bunun bir Seçenek olması gerekir çünkü istisnayı başvuruya göre yakalarız ve yıkıcısı C++ çalışma zamanı tarafından yürütülür.
    // Kutuyu istisnadan çıkardığımızda, yıkıcının Kutuyu çift düşürmeden çalışması için istisnayı geçerli bir durumda bırakmamız gerekir.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// İlk olarak, bir sürü tip tanımı.Burada platforma özgü birkaç tuhaflık var ve bunlar sadece açıkça LLVM'den kopyalanmış.Tüm bunların amacı, `_CxxThrowException` e yapılan bir çağrı aracılığıyla aşağıdaki `panic` işlevini uygulamaktır.
//
// Bu işlev iki argüman alır.İlki, aktardığımız verilere bir göstericidir, bu durumda bu bizim trait nesnemizdir.Bulması oldukça kolay!Ancak bir sonraki adım daha karmaşıktır.
// Bu, bir `_ThrowInfo` yapısına bir göstericidir ve genellikle sadece fırlatılan istisnayı açıklamayı amaçlamaktadır.
//
// Şu anda bu tür [1] in tanımı biraz karmaşıktır ve ana tuhaflık (ve çevrimiçi makaleden farkı), 32-bit üzerinde işaretçilerin işaretçiler olması, ancak 64-bit üzerinde işaretçilerin, `__ImageBase` sembolü.
//
// Aşağıdaki modüllerdeki `ptr_t` ve `ptr!` makrosu bunu ifade etmek için kullanılır.
//
// Tür tanımlarının labirenti, LLVM'nin bu tür bir işlem için yayınladıklarını da yakından takip eder.Örneğin, bu C++ kodunu MSVC üzerinde derler ve LLVM IR'yi yayarsanız:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      geçersiz foo() { rust_panic a = {0, 1};
//          atmak;}
//
// Aslında öykünmeye çalıştığımız şey bu.Aşağıdaki sabit değerlerin çoğu LLVM'den kopyalandı,
//
// Her durumda, bu yapıların hepsi benzer bir şekilde inşa edildi ve bu bizim için biraz ayrıntılı.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Burada isim değiştirme kurallarını kasıtlı olarak göz ardı ettiğimize dikkat edin: C++ 'nın sadece bir `struct rust_panic` bildirerek Rust panics'yi yakalayabilmesini istemiyoruz.
//
//
// Değiştirirken, tür adı dizesinin `compiler/rustc_codegen_llvm/src/intrinsic.rs` te kullanılanla tam olarak eşleştiğinden emin olun.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Buradaki önde gelen `\x01` baytı, aslında LLVM'ye, `_` karakteriyle önek gibi başka herhangi bir karıştırmayı uygulamamak * için sihirli bir sinyaldir.
    //
    //
    // Bu sembol, C++ 'ın `std::type_info` i tarafından kullanılan vtable'dır.
    // `std::type_info` türü nesneler, tür tanımlayıcıları, bu tabloya bir göstericiye sahiptir.
    // Tip tanımlayıcıları, yukarıda tanımlanan ve aşağıda oluşturduğumuz C++ EH yapıları tarafından referans alınır.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Bu tür tanımlayıcı yalnızca bir istisna atılırken kullanılır.
// Yakalama kısmı, kendi TypeDescriptor'unu oluşturan try intrinsic tarafından ele alınır.
//
// MSVC çalışma zamanı, işaretçi eşitliği yerine TypeDescriptors ile eşleşmek için tür adı üzerinde dize karşılaştırması kullandığından, bu iyidir.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Yıkıcı, C++ kodu istisnayı yakalamaya ve yaymadan bırakmaya karar verirse kullanılır.
// Try intrinsic'in catch kısmı, istisna nesnesinin ilk kelimesini 0'a ayarlayacaktır, böylece yıkıcı tarafından atlanacaktır.
//
// x86 Windows in, varsayılan "C" arama kuralı yerine C++ üye işlevleri için "thiscall" arama kuralını kullandığını unutmayın.
//
// Exception_copy işlevi burada biraz özeldir: MSVC çalışma zamanı tarafından bir try/catch bloğu altında çağrılır ve burada ürettiğimiz panic istisna kopyasının sonucu olarak kullanılacaktır.
//
// Bu, C++ çalışma zamanı tarafından std::exception_ptr ile istisnaların yakalanmasını desteklemek için kullanılır, bunu destekleyemiyoruz çünkü Box<dyn Any>klonlanamaz.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException tamamen bu yığın çerçevesinde yürütülür, bu nedenle `data` i öbeğe aktarmaya gerek yoktur.
    // Bu işleve bir yığın işaretçisi aktarıyoruz.
    //
    // Çözme sırasında İstisnanın kaldırılmasını istemediğimiz için burada ManualDrop gereklidir.
    // Bunun yerine, C++ çalışma zamanı tarafından çağrılan exception_cleanup tarafından bırakılacaktır.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Bu ... şaşırtıcı görünebilir ve haklı olarak öyle.32-bit MSVC'de bu yapılar arasındaki işaretçiler sadece işaretçilerdir.
    // 64-bit MSVC'de, bununla birlikte, yapılar arasındaki işaretçiler daha çok `__ImageBase` ten 32-bit ofsetler olarak ifade edilir.
    //
    // Sonuç olarak, 32-bit MSVC'de tüm bu işaretçileri yukarıdaki "statik" lerde bildirebiliriz.
    // 64-bit MSVC'de, Rust'nin şu anda izin vermediği statikteki işaretçilerin çıkarılmasını ifade etmemiz gerekir, bu yüzden aslında bunu yapamayız.
    //
    // Bundan sonraki en iyi şey, bu yapıları çalışma zamanında doldurmaktır (panik yapmak zaten "slow path" tir).
    // Bu yüzden burada tüm bu işaretçi alanlarını 32 bitlik tamsayılar olarak yeniden yorumluyoruz ve sonra ilgili değeri içine depoluyoruz (atomik olarak, eşzamanlı panics olabileceği gibi).
    //
    // Teknik olarak, çalışma zamanı muhtemelen bu alanların atomik olmayan bir okumasını yapacaktır, ancak teoride asla *yanlış* değeri okumazlar, bu yüzden çok kötü olmamalı ...
    //
    // Her durumda, statikte daha fazla işlem ifade edene kadar (ve asla yapamayabiliriz) kadar temelde böyle bir şey yapmamız gerekir.
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Buradaki bir BOŞ yük, burada __rust_try'nin (...) yakalamasından geldiğimiz anlamına gelir.
    // Bu, Rust dışı bir yabancı istisna yakalandığında gerçekleşir.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Bu, derleyicinin var olması için gereklidir (örneğin, bir dil öğesidir), ancak aslında derleyici tarafından çağrılmaz çünkü __C_specific_handler veya_except_handler3 her zaman kullanılan kişilik işlevidir.
//
// Bu nedenle, bu sadece iptal edilen bir koçan.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}