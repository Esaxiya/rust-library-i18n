// rsbegin.o ve rsend.o sözde "compiler runtime startup objects" tir.
// Derleyici çalışma zamanını doğru şekilde başlatmak için gereken kodu içerirler.
//
// Bir yürütülebilir veya dylib görüntüsü bağlandığında, tüm kullanıcı kodu ve kitaplıklar bu iki nesne dosyası arasında "sandwiched" tir, bu nedenle rsbegin.o ten gelen kod veya veriler görüntünün ilgili bölümlerinde ilk sırada olurken, rsend.o ten gelen kod ve veriler son olanlar olur.
// Bu efekt, sembolleri bir bölümün başına veya sonuna yerleştirmenin yanı sıra gerekli herhangi bir üstbilgi veya altbilgi eklemek için kullanılabilir.
//
// Gerçek modül giriş noktasının, daha sonra diğer çalışma zamanı bileşenlerinin (yine başka bir özel görüntü bölümü aracılığıyla kaydedilen) başlatma geri aramalarını çağıran C çalışma zamanı başlangıç nesnesinde (genellikle `crtX.o` olarak adlandırılır) bulunduğunu unutmayın.
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Yığın çerçevesi çözme bilgisi bölümünün başlangıcını işaretler
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Çözücünün dahili defter tutması için kazıma alanı.
    // Bu, $ GCC/libgcc/çözme-dw2-fde.h dosyasında `struct object` olarak tanımlanır.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Bilgi registration/deregistration rutinlerini gevşetin.
    // Libpanic_unwind belgelerine bakın.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // modül başlangıcında çözme bilgilerini kaydet
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // kapatıldığında kaydı iptal et
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW'ye özgü init/uninit rutin kaydı
    pub mod mingw_init {
        // MinGW'nin başlangıç nesneleri (crt0.o/dllcrt0.o), başlangıçta ve çıkışta .ctors ve .dtors bölümlerindeki global kurucuları çağıracaktır.
        // DLL'ler söz konusu olduğunda bu, DLL yüklendiğinde ve kaldırıldığında yapılır.
        //
        // Bağlayıcı, geri aramalarımızın listenin sonunda yer almasını sağlayan bölümleri sıralayacaktır.
        // Yapıcılar ters sırada çalıştırıldığından, bu bizim geri aramalarımızın ilk ve son çalıştırılanlar olmasını sağlar.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C başlatma geri aramaları
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C sonlandırma geri aramaları
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}