//! `compiler-rt` kitaplığının profil oluşturucu bölümünü derler.
//!
//! Ayrıntılar için libcompiler_builtins crate için build.rs e bakın.

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` yönergeleri şu anda yayınlanmamaktadır ve derleme betiği
    // bu kaynak dosyalardaki veya bunlara eklenen başlıklardaki değişiklikler üzerinde yeniden çalışmayacaktır.
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // Bu dosya LLVM 10'da yeniden adlandırıldı.
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // Bu dosyalar LLVM 11'e eklenmiştir.
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // MSVC'de fazladan kitaplık çekmeyin
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc'nin çeşitli özelliklerini kapatın ve çoğunlukla derleyici-rt'nin derleme sistemini kopyalıyor
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // Bunu için oluşturduğumuz Unix'lerin fnctl() e sahip olduğunu varsayalım.
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // Bu, COMPILER_RT_HAS_ATOMICS'in ne zaman ayarlanacağı konusunda oldukça iyi bir buluşsal yöntem olmalıdır.
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // Çalışacaksak bunun var olması gerektiğini unutmayın (aksi takdirde profil oluşturucu yerleşikleri oluşturmayız).
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}