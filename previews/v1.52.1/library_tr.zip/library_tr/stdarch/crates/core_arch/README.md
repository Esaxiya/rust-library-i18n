`core::arch` - Rust'nin temel kütüphane mimarisine özgü içsel özellikleri
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` modülü, mimariye bağlı içsel bileşenleri (örn. SIMD) uygular.

# Usage 

`core::arch` `libcore` in bir parçası olarak mevcuttur ve `libstd` tarafından yeniden dışa aktarılır.Bu crate yerine `core::arch` veya `std::arch` ile kullanmayı tercih edin.
Kararsız özellikler genellikle `feature(stdsimd)` aracılığıyla her gece Rust'de mevcuttur.

`core::arch` i bu crate aracılığıyla kullanmak, her gece Rust gerektirir ve sık sık bozulabilir (ve yapar).Bu crate ile kullanmayı düşünmeniz gereken durumlar şunlardır:

* `core::arch` i kendiniz yeniden derlemeniz gerekiyorsa, örneğin, `libcore`/`libstd` için etkinleştirilmemiş belirli hedef özellikleri etkinleştirildiğinde.
Note: Standart olmayan bir hedef için yeniden derlemeniz gerekiyorsa, lütfen bu crate'yi kullanmak yerine `xargo` kullanmayı ve `libcore`/`libstd` i uygun şekilde yeniden derlemeyi tercih edin.
  
* kararsız Rust özelliklerinin arkasında bile kullanılamayabilecek bazı özelliklerin kullanılması.Bunları minimumda tutmaya çalışıyoruz.
Bu özelliklerden bazılarını kullanmanız gerekiyorsa, lütfen bir sorun açın, böylece onları her gece Rust'de açığa çıkarabiliriz ve oradan kullanabilirsiniz.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` esas olarak hem MIT lisansı hem de Apache Lisansı (Versiyon 2.0) hükümleri altında dağıtılır ve çeşitli BSD benzeri lisansların kapsamına giren bölümler.

Ayrıntılar için LICENSE-APACHE ve LICENSE-MIT bölümüne bakın.

# Contribution

Açıkça aksi belirtilmedikçe, Apache-2.0 lisansında tanımlandığı üzere tarafınızdan `core_arch` e dahil edilmek üzere kasıtlı olarak gönderilen herhangi bir katkı, herhangi bir ek hüküm veya koşul olmaksızın, yukarıdaki gibi çift lisanslı olacaktır.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












