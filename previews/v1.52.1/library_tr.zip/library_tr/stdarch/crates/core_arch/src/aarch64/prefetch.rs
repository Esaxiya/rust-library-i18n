#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) e bakın.
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) e bakın.
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) e bakın.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) e bakın.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) e bakın.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) e bakın.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Verilen `rw` ve `locality` i kullanarak `p` adresini içeren önbellek satırını getirin.
///
/// `rw` şunlardan biri olmalıdır:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): ön yükleme bir okuma için hazırlanıyor.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): ön yükleme bir yazmaya hazırlanıyor.
///
/// `locality` şunlardan biri olmalıdır:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Yalnızca bir kez kullanılan veriler için akış veya geçici olmayan önceden getirme.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): 3. seviye önbelleğe alın.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): 2. seviye önbelleğe alın.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): 1. seviye önbelleğe alın.
///
/// Önceden getirilmiş bellek talimatları, bellek sistemine belleğin belirli bir adresten eriştiğini bildirir, muhtemelen future yakınında meydana gelir.
/// Bellek sistemi, belirtilen adresin bir veya daha fazla önbelleğe önceden yüklenmesi gibi, oluştuğunda bellek erişimini hızlandırması beklenen eylemleri gerçekleştirerek yanıt verebilir.
///
/// Bu sinyaller yalnızca ipuçları olduğundan, belirli bir CPU'nun önceden getirme talimatlarından herhangi birini veya tümünü bir NOP olarak ele alması geçerlidir.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // `llvm.prefetch` enstrümanını `cache type` =1 (veri önbelleği) ile kullanıyoruz.
    // `rw` ve `strategy`, fonksiyon parametrelerine dayalıdır.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}