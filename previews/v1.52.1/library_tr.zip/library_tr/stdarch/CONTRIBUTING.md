# Stdarch'a katkıda bulunmak

`stdarch` crate, katkıları kabul etmek için fazlasıyla isteklidir!Öncelikle muhtemelen depoyu kontrol etmek ve testlerin sizin için başarılı olduğundan emin olmak isteyeceksiniz:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

`<your-target-arch>`, `rustup` tarafından kullanılan hedef üçlü olduğunda, örneğin `x86_x64-unknown-linux-gnu` (herhangi bir `nightly-` veya benzeri olmadan).
Ayrıca bu deponun Rust'nin gecelik kanalını gerektirdiğini de unutmayın!
Yukarıdaki testler, `rustup default nightly` (ve geri dönmek için `rustup default stable`) kullanmanın ayarlanması için aslında her gece rust'nin sisteminizde varsayılan değer olmasını gerektirir.

Yukarıdaki adımlardan herhangi biri işe yaramazsa, [please let us know][new]!

Daha sonra [find an issue][issues] e yardım edebilirsiniz, özellikle biraz yardıma ihtiyaç duyabilecek [`help wanted`][help] ve [`impl-period`][impl] etiketleriyle birkaç tane seçtik. 
En çok [#40][vendor] ile ilgileniyor olabilirsiniz, tüm satıcı içsellerini x86 üzerinde uygulayabilirsiniz.Bu sorunun nereden başlayacağına dair bazı iyi ipuçları var!

Genel sorularınız varsa, [join us on gitter][gitter] ten çekinmeyin ve etrafa sorun!Sorularınız için@BurntSushi veya@alexcrichton'a ping atmaktan çekinmeyin.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Stdarch intrinsics için örnekler nasıl yazılır

Verilen içsel öğenin düzgün çalışması için etkinleştirilmesi gereken birkaç özellik vardır ve örnek yalnızca özellik CPU tarafından desteklendiğinde `cargo test --doc` tarafından çalıştırılmalıdır.

Sonuç olarak, `rustdoc` tarafından oluşturulan varsayılan `fn main` çalışmayacaktır (çoğu durumda).
Örneğinizin beklendiği gibi çalıştığından emin olmak için aşağıdakileri bir kılavuz olarak kullanmayı düşünün.

```rust
/// # // Örneğin, yalnızca örnek olduğundan emin olmak için cfg_target_feature'a ihtiyacımız var.
/// # // CPU özelliği desteklediğinde `cargo test --doc` tarafından çalıştırılır
/// # #![feature(cfg_target_feature)]
/// # // İçsel olanın çalışması için target_feature'a ihtiyacımız var
/// # #![feature(target_feature)]
/// #
/// # // rustdoc varsayılan olarak `extern crate stdarch` kullanır, ancak
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Gerçek ana işlev
/// # fn main() {
/// #     // Bunu yalnızca `<target feature>` destekleniyorsa çalıştırın
/// #     eğer cfg_feature_enabled! ("<target feature>"){
/// #         // Yalnızca hedef özellik olduğunda çalıştırılacak bir `worker` işlevi oluşturun
/// #         // desteklenir ve çalışanınız için `target_feature` in etkinleştirildiğinden emin olun
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         güvenli olmayan fn worker() {
/// // Örneğinizi buraya yazın.Özelliğe özgü iç bilgiler burada çalışacaktır!Vahşileş!
///
/// #         }
///
/// #         güvenli olmayan { worker(); }
/// #     }
/// # }
```

Yukarıdaki sözdizimlerinin bazıları tanıdık gelmiyorsa, [Rust Book] in [Documentation as tests] bölümü `rustdoc` sözdizimini oldukça iyi açıklıyor.
Her zaman olduğu gibi, [join us on gitter][gitter] ten çekinmeyin ve herhangi bir engelle karşılaşırsanız bize sorun ve `stdarch` in belgelerini iyileştirmeye yardımcı olduğunuz için teşekkür ederiz!

# Alternatif Test Talimatları

Genel olarak testleri çalıştırmak için `ci/run.sh` kullanmanız önerilir.
Ancak bu sizin için işe yaramayabilir, örneğin Windows kullanıyorsanız.

Bu durumda, kod üretimini test etmek için `cargo +nightly test` ve `cargo +nightly test --release -p core_arch` i çalıştırmaya geri dönebilirsiniz.
Bunların gece araç zincirinin kurulmasını ve `rustc` in hedef üçlü ve CPU'yu bilmesini gerektirdiğini unutmayın.
Özellikle, `ci/run.sh` için yaptığınız gibi `TARGET` ortam değişkenini ayarlamanız gerekir.
Ek olarak, hedef özellikleri belirtmek için `RUSTCFLAGS` i (`C` gerekir) ayarlamanız gerekir, örn. `RUSTCFLAGS="-C -target-features=+avx2"`.
Mevcut CPU'nuza karşı "just" geliştiriyorsanız, `-C -target-cpu=native` i de ayarlayabilirsiniz.

Bu alternatif talimatları kullandığınızda, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], örn.
talimat üretme testleri, demonte eden kişi bunları farklı şekilde adlandırdığı için başarısız olabilir, örn.
aynı şekilde davranmalarına rağmen `aesenc` komutları yerine `vaesenc` oluşturabilir.
Ayrıca bu talimatlar normalde yapılandan daha az test yürütür, bu nedenle sonunda çek-talep ettiğinizde burada ele alınmayan testler için bazı hataların görünmesine şaşırmayın.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






