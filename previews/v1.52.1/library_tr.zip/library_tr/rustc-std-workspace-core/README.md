# `rustc-std-workspace-core` crate

Bu crate, basitçe `libcore` e bağlı olan ve tüm içeriğini yeniden aktaran boş bir crate'dir.
crate, standart kitaplığı crates.io ten crates'ye bağlı olacak şekilde güçlendirmenin temel noktasıdır

Standart kitaplığın bağlı olduğu, crates.io in boş olan `rustc-std-workspace-core` crate'ye bağlı olduğu crates.io üzerinde Crates.

Bu depodaki bu crate için onu geçersiz kılmak için `[patch]` kullanıyoruz.
Sonuç olarak, crates.io üzerindeki crates, bu depoda tanımlanan sürüm olan edge ile `libcore` arasında bir bağımlılık çizecektir.
Bu, Cargo'nin crates'yi başarıyla oluşturmasını sağlamak için tüm bağımlılık kenarlarını çizmelidir!

Her şeyin düzgün çalışması için crates.io üzerindeki crates'nin `core` adlı bu crate'ye bağlı olması gerektiğini unutmayın.Bunu yapmak için kullanabilirler:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` anahtarının kullanılmasıyla crate, `core` olarak yeniden adlandırılır, yani

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

Cargo derleyiciyi çağırdığında, derleyici tarafından yerleştirilen örtük `extern crate core` yönergesini yerine getirir.




