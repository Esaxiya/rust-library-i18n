#![feature(no_core)]
#![no_core]

// Bu crate'nin neden gerekli olduğunu öğrenmek için rustc-std-çalışma alanı-çekirdeğine bakın.

// Liballoc'taki ayırma modülüyle çakışmayı önlemek için crate'yi yeniden adlandırın.
extern crate alloc as foo;

pub use foo::*;