//! Bitişik bir diziye dinamik olarak boyutlandırılmış bir görünüm, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Dilimler, bir işaretçi ve uzunluk olarak temsil edilen bir bellek bloğunun görünümüdür.
//!
//! ```
//! // Vec dilimleme
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // bir diziyi bir dilime zorlamak
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Dilimler değiştirilebilir veya paylaşılır.
//! Paylaşılan dilim türü `&[T]` iken değiştirilebilir dilim türü `&mut [T]` tir, burada `T` öğe türünü temsil eder.
//! Örneğin, değiştirilebilir bir dilimin işaret ettiği bellek bloğunu değiştirebilirsin:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! İşte bu modülün içerdiği bazı şeyler:
//!
//! ## Structs
//!
//! Bir dilim üzerinde yinelemeyi temsil eden [`Iter`] gibi, dilimler için yararlı olan birkaç yapı vardır.
//!
//! ## Trait Uygulamaları
//!
//! Dilimler için birçok ortak traits uygulaması vardır.Bazı örnekler şunları içerir:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], eleman tipi [`Eq`] veya [`Ord`] olan dilimler için.
//! * [`Hash`] - eleman türü [`Hash`] olan dilimler için.
//!
//! ## Iteration
//!
//! Dilimler `IntoIterator` i uygular.Yineleyici, dilim öğelerine referanslar verir.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Değiştirilebilir dilim, öğelere değişebilir referanslar verir:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Bu yineleyici, dilimin öğelerine değiştirilebilir referanslar verir, bu nedenle dilimin öğe türü `i32` iken yineleyicinin öğe türü `&mut i32` tir.
//!
//!
//! * [`.iter`] ve [`.iter_mut`], varsayılan yineleyicileri döndürmek için açık yöntemlerdir.
//! * Yineleyicileri döndüren diğer yöntemler, [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ve daha fazlasıdır.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Bu modüldeki kullanımların çoğu yalnızca test yapılandırmasında kullanılır.
// Unused_imports uyarısını kapatmak onları düzeltmekten daha temizdir.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Temel dilim genişletme yöntemleri
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB testi sırasında `vec!` makrosunun uygulanması için gerekli, daha fazla ayrıntı için bu dosyadaki `hack` modülüne bakın.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB testi sırasında `Vec::clone` in uygulanması için gerekli, daha fazla ayrıntı için bu dosyadaki `hack` modülüne bakın.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` mevcut olmadığında, bu üç işlev aslında `impl [T]` te bulunan ancak `core::slice::SliceExt` te olmayan yöntemlerdir, `test_permutations` testi için bu işlevleri sağlamamız gerekir.
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Buna satır içi öznitelik eklememeliyiz, çünkü bu çoğunlukla `vec!` makrosunda kullanılır ve mükemmel regresyona neden olur.
    // Tartışma ve mükemmel sonuçlar için #71204 e bakın.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // öğeler aşağıdaki döngüde başlatıldı olarak işaretlendi
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) LLVM'nin sınır denetimlerini kaldırması ve zip'ten daha iyi bir kod oluşturucuya sahip olması için gereklidir.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec tahsis edildi ve en azından bu uzunluğa yukarıda başlatıldı.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // yukarıda `s` kapasitesiyle tahsis edilir ve aşağıdaki ptr::copy_to_non_overlapping te `s.len()` e başlar.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Dilimi sıralar.
    ///
    /// Bu sıralama kararlıdır (yani, eşit öğeleri yeniden sıralamaz) ve *O*(*n*\*log(* n*)) en kötü durumdur.
    ///
    /// Uygulanabilir olduğunda, kararsız sıralama tercih edilir çünkü genellikle kararlı sıralamadan daha hızlıdır ve yardımcı bellek ayırmaz.
    /// [`sort_unstable`](slice::sort_unstable) e bakın.
    ///
    /// # Mevcut uygulama
    ///
    /// Mevcut algoritma, [timsort](https://en.wikipedia.org/wiki/Timsort) ten esinlenen uyarlamalı, yinelemeli bir birleştirme sıralamasıdır.
    /// Dilimin neredeyse sıralı olduğu veya birbiri ardına sıralanan iki veya daha fazla sıralı diziden oluştuğu durumlarda çok hızlı olacak şekilde tasarlanmıştır.
    ///
    ///
    /// Ayrıca, `self` boyutunun yarısı kadar geçici depolama alanı tahsis eder, ancak kısa dilimler için bunun yerine ayırmayan bir ekleme sıralaması kullanılır.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Dilimi bir karşılaştırıcı işleviyle sıralar.
    ///
    /// Bu sıralama kararlıdır (yani, eşit öğeleri yeniden sıralamaz) ve *O*(*n*\*log(* n*)) en kötü durumdur.
    ///
    /// Karşılaştırıcı işlevi, dilimdeki öğeler için toplam bir sıralama tanımlamalıdır.Sıralama toplam değilse, elemanların sırası belirtilmez.
    /// Bir sipariş, şu ise toplam bir sipariştir (tüm `a`, `b` ve `c` için):
    ///
    /// * toplam ve antisimetrik: `a < b`, `a == b` veya `a > b` ten tam olarak biri doğrudur ve
    /// * geçişli, `a < b` ve `b < c`, `a < c` anlamına gelir.Aynısı hem `==` hem de `>` için geçerli olmalıdır.
    ///
    /// Örneğin, [`f64`], [`Ord`] i `NaN != NaN` nedeniyle gerçekleştirmezken, dilimde `NaN` bulunmadığını bildiğimizde `partial_cmp` i sıralama işlevimiz olarak kullanabiliriz.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Uygulanabilir olduğunda, kararsız sıralama tercih edilir çünkü genellikle kararlı sıralamadan daha hızlıdır ve yardımcı bellek ayırmaz.
    /// [`sort_unstable_by`](slice::sort_unstable_by) e bakın.
    ///
    /// # Mevcut uygulama
    ///
    /// Mevcut algoritma, [timsort](https://en.wikipedia.org/wiki/Timsort) ten esinlenen uyarlamalı, yinelemeli bir birleştirme sıralamasıdır.
    /// Dilimin neredeyse sıralı olduğu veya birbiri ardına sıralanan iki veya daha fazla sıralı diziden oluştuğu durumlarda çok hızlı olacak şekilde tasarlanmıştır.
    ///
    /// Ayrıca, `self` boyutunun yarısı kadar geçici depolama alanı tahsis eder, ancak kısa dilimler için bunun yerine ayırmayan bir ekleme sıralaması kullanılır.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ters sıralama
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Dilimi bir anahtar çıkarma işleviyle sıralar.
    ///
    /// Bu sıralama kararlıdır (yani, eşit öğeleri yeniden sıralamaz) ve *O*(*m*\* * n *\* log(*n*)) en kötü durum, burada anahtar işlevi *O*(*m*) olur.
    ///
    /// Pahalı tuş işlevleri için (örn.
    /// basit özellik erişimleri veya temel işlemler olmayan işlevler), [`sort_by_cached_key`](slice::sort_by_cached_key), öğe anahtarlarını yeniden hesaplamadığı için büyük olasılıkla önemli ölçüde daha hızlı olacaktır.
    ///
    ///
    /// Uygulanabilir olduğunda, kararsız sıralama tercih edilir çünkü genellikle kararlı sıralamadan daha hızlıdır ve yardımcı bellek ayırmaz.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) e bakın.
    ///
    /// # Mevcut uygulama
    ///
    /// Mevcut algoritma, [timsort](https://en.wikipedia.org/wiki/Timsort) ten esinlenen uyarlamalı, yinelemeli bir birleştirme sıralamasıdır.
    /// Dilimin neredeyse sıralı olduğu veya birbiri ardına sıralanan iki veya daha fazla sıralı diziden oluştuğu durumlarda çok hızlı olacak şekilde tasarlanmıştır.
    ///
    /// Ayrıca, `self` boyutunun yarısı kadar geçici depolama alanı tahsis eder, ancak kısa dilimler için bunun yerine ayırmayan bir ekleme sıralaması kullanılır.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Dilimi bir anahtar çıkarma işleviyle sıralar.
    ///
    /// Sıralama sırasında, anahtar işlevi öğe başına yalnızca bir kez çağrılır.
    ///
    /// Bu sıralama kararlıdır (yani, eşit öğeleri yeniden sıralamaz) ve *O*(*m*\* * n *+* n *\* log(*n*)) en kötü durum, burada anahtar işlevi *O*(*m*) .
    ///
    /// Basit tuş işlevleri için (örneğin, özellik erişimi veya temel işlemler olan işlevler), [`sort_by_key`](slice::sort_by_key) muhtemelen daha hızlı olacaktır.
    ///
    /// # Mevcut uygulama
    ///
    /// Mevcut algoritma, belirli desenlere sahip dilimlerde doğrusal zaman elde ederken, rasgele sıralamanın hızlı ortalama durumunu en hızlı yığın sıralaması ile birleştiren Orson Peters tarafından geliştirilen [pattern-defeating quicksort][pdqsort] e dayanmaktadır.
    /// Dejenere durumlardan kaçınmak için bir miktar randomizasyon kullanır, ancak her zaman deterministik davranış sağlamak için sabit bir seed ile.
    ///
    /// En kötü durumda, algoritma bir `Vec<(K, usize)>` te dilim uzunluğuna göre geçici depolama tahsis eder.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Tahsisatı azaltmak için vector ürünümüzü mümkün olan en küçük türe göre indekslemek için yardımcı makro.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` in elemanları endekslendiklerinden benzersizdir, bu nedenle her tür orijinal dilime göre kararlı olacaktır.
                // Burada `sort_unstable` kullanıyoruz çünkü daha az bellek ayırma gerektiriyor.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` i yeni bir `Vec` e kopyalar.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Burada `s` ve `x` bağımsız olarak değiştirilebilir.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self` i ayırıcı ile yeni bir `Vec` e kopyalar.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Burada `s` ve `x` bağımsız olarak değiştirilebilir.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // Not, daha fazla ayrıntı için bu dosyadaki `hack` modülüne bakın.
        hack::to_vec(self, alloc)
    }

    /// `self` i klonlar veya ayırma olmadan bir vector'ye dönüştürür.
    ///
    /// Ortaya çıkan vector, `Vec aracılığıyla bir kutuya dönüştürülebilir.<T>`into_boxed_slice` yöntemi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` `x` e dönüştürüldüğü için artık kullanılamaz.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // Not, daha fazla ayrıntı için bu dosyadaki `hack` modülüne bakın.
        hack::into_vec(self)
    }

    /// Bir dilimi `n` kez tekrarlayarak bir vector oluşturur.
    ///
    /// # Panics
    ///
    /// Kapasite aşılırsa bu işlev panic olacaktır.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic taşma üzerine:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // `n` sıfırdan büyükse, `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` olarak bölünebilir.
        // `2^expn` `n` in en soldaki '1' biti ile temsil edilen sayıdır ve `rem`, `n` in kalan kısmıdır.
        //
        //

        // `set_len()` e erişmek için `Vec` i kullanma.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` tekrarlama, `buf` "expn" sürelerini ikiye katlayarak yapılır.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` ise, en soldaki '1' e kadar kalan bitler vardır.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` kapasitesine sahiptir.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) tekrarı, ilk `rem` tekrarlarını `buf` in kendisinden kopyalayarak yapılır.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Bu, `2^expn > rem` ten beri örtüşmeyen bir durumdur.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` eşittir `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Bir `T` dilimini tek bir `Self::Output` değerinde düzleştirir.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Bir `T` dilimini, her birinin arasına belirli bir ayırıcı yerleştirerek tek bir `Self::Output` değerinde düzleştirir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Bir `T` dilimini, her birinin arasına belirli bir ayırıcı yerleştirerek tek bir `Self::Output` değerinde düzleştirir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Bu dilimin bir kopyasını içeren bir vector döndürür ve burada her baytın kendi ASCII büyük harf eşdeğeriyle eşleştirilir.
    ///
    ///
    /// 'a' ila 'z' arasındaki ASCII harfleri, 'A' ila 'Z' e eşlenir, ancak ASCII olmayan harfler değiştirilmez.
    ///
    /// Yerinde değeri büyük harfle yazmak için [`make_ascii_uppercase`] kullanın.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Bu dilimin bir kopyasını içeren bir vector döndürür ve burada her baytın kendi ASCII küçük harf eşdeğeriyle eşleştirilir.
    ///
    ///
    /// 'A' ila 'Z' arasındaki ASCII harfleri, 'a' ila 'z' e eşlenir, ancak ASCII olmayan harfler değiştirilmez.
    ///
    /// Yerinde değeri küçük harfle yazmak için [`make_ascii_lowercase`] kullanın.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Belirli veri türleri üzerinden dilimler için traits uzantısı
////////////////////////////////////////////////////////////////////////////////

/// ["[T]: : concat`](dilim::concat) için Yardımcı trait.
///
/// Note: `Item` tipi parametre bu trait'de kullanılmaz, ancak impl'lerin daha genel olmasına izin verir.
/// Onsuz, şu hatayı alıyoruz:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Bunun nedeni, birden çok `T` türünün geçerli olacağı şekilde, birden çok `Borrow<[_]>` gösterimi olan `V` türlerinin mevcut olabilmesidir:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Birleştirmeden sonra ortaya çıkan tür
    type Output;

    /// [`[T]: : concat`](dilim::concat) uygulaması
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`] için Yardımcı trait (dilim::birleştirme)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Birleştirmeden sonra ortaya çıkan tür
    type Output;

    /// [`[T]: : join`](dilim::join) uygulaması
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Dilimler için standart trait uygulamaları
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // üzerine yazılmayacak herhangi bir şeyi hedefe bırakın
        target.truncate(self.len());

        // target.len Yukarıdaki kesme nedeniyle <= self.len, bu nedenle buradaki dilimler her zaman sınırlar içindedir.
        //
        let (init, tail) = self.split_at(target.len());

        // içerilen değerleri yeniden kullanın allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` i önceden sıralanmış `v[1..]` dizisine ekler, böylece tüm `v[..]` sıralanır.
///
/// Bu, ekleme sıralamanın ayrılmaz alt yordamıdır.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Burada ekleme yapmanın üç yolu vardır:
            //
            // 1. İlki nihai hedefine ulaşıncaya kadar bitişik öğeleri değiştirin.
            //    Ancak, bu şekilde verileri gereğinden fazla kopyalıyoruz.
            //    Öğeler büyük yapılarsa (kopyalanması maliyetli), bu yöntem yavaş olacaktır.
            //
            // 2. İlk öğe için doğru yer bulunana kadar yineleyin.
            // Ardından, yer açmak için onu takip eden öğeleri kaydırın ve son olarak kalan deliğe yerleştirin.
            // Bu iyi bir yöntemdir.
            //
            // 3. İlk öğeyi geçici bir değişkene kopyalayın.Doğru yer bulunana kadar yineleyin.
            // İlerledikçe, geçilen her öğeyi ondan önceki yuvaya kopyalayın.
            // Son olarak, verileri geçici değişkenden kalan deliğe kopyalayın.
            // Bu yöntem çok iyidir.
            // Kıyaslamalar, 2. yönteme göre biraz daha iyi performans gösterdi.
            //
            // Tüm yöntemler kıyaslandı ve 3'üncü en iyi sonuçları gösterdi.Biz de onu seçtik.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Ekleme işleminin ara durumu her zaman iki amaca hizmet eden `hole` tarafından izlenir:
            // 1. `v` in bütünlüğünü `is_less` te panics'den korur.
            // 2. Sonunda `v` te kalan deliği doldurur.
            //
            // Panic güvenliği:
            //
            // İşlem sırasında herhangi bir noktada `is_less` panics ise, `hole` düşecek ve `v` teki deliği `tmp` ile dolduracak ve böylece `v` in başlangıçta tuttuğu her nesneyi tam olarak bir kez tutmasını sağlayacaktır.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` düşürülür ve böylece `tmp` i `v` teki kalan deliğe kopyalar.
        }
    }

    // Düşürüldüğünde, `src` ten `dest` e kopyalar.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Azalmayan `v[..mid]` ve `v[mid..]` çalıştırmalarını geçici depolama olarak `buf` kullanarak birleştirir ve sonucu `v[..]` te depolar.
///
/// # Safety
///
/// İki dilim boş olmamalı ve `mid` sınırlar içinde olmalıdır.
/// Tampon `buf`, daha kısa dilimin bir kopyasını tutacak kadar uzun olmalıdır.
/// Ayrıca, `T` sıfır boyutlu bir tür olmamalıdır.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Birleştirme işlemi önce daha kısa olan çalışmayı `buf` e kopyalar.
    // Ardından, yeni kopyalanan çalıştırmayı ve daha uzun ilerlemeyi (veya geriye doğru) izler, bir sonraki tüketilmemiş öğelerini karşılaştırır ve daha küçük olanı (veya daha büyük olanı) `v` e kopyalar.
    //
    // Daha kısa çalışma tamamen tüketilir tüketilmez, işlem yapılır.Daha uzun çalıştırma önce tüketilirse, daha kısa sürenin kalanını `v` teki kalan deliğe kopyalamalıyız.
    //
    // İşlemin ara durumu her zaman iki amaca hizmet eden `hole` tarafından izlenir:
    // 1. `v` in bütünlüğünü `is_less` te panics'den korur.
    // 2. Daha uzun çalışma önce tüketilirse `v` te kalan deliği doldurur.
    //
    // Panic güvenliği:
    //
    // İşlem sırasında herhangi bir noktada `is_less` panics ise, `hole` düşecek ve `v` teki boşluğu `buf` teki tüketilmemiş aralıkla dolduracak ve böylece `v` in başlangıçta tam olarak bir kez tuttuğu her nesneyi tutmasını sağlayacaktır.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Sol koşu daha kısa.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Başlangıçta, bu işaretçiler dizilerinin başlangıcına işaret eder.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Küçük tarafı tüketin.
            // Eşitse, stabiliteyi korumak için sol koşuyu tercih edin.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Doğru koşu daha kısadır.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Başlangıçta, bu işaretçiler dizilerinin sonlarını gösterir.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Büyük tarafı tüketin.
            // Eşitse, stabiliteyi korumak için doğru koşuyu tercih edin.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Sonunda, `hole` düşer.
    // Daha kısa çalışma tam olarak tüketilmediyse, bundan geriye ne kaldıysa şimdi `v` teki deliğe kopyalanacaktır.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Düşürüldüğünde, `start..end` aralığını `dest..` e kopyalar.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` sıfır boyutlu bir tür olmadığından, boyutuna göre bölmekte sorun yoktur.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Bu birleştirme sıralaması, [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) ayrıntılı olarak açıklanan TimSort'tan bazı (ancak hepsini değil) fikirleri ödünç alır.
///
///
/// Algoritma, doğal koşular olarak adlandırılan kesinlikle azalan ve azalan olmayan alt dizileri tanımlar.Henüz birleştirilmesi gereken bir yığın bekleyen çalıştırma var.
/// Bulunan her yeni çalışma yığına itilir ve ardından bu iki değişmez elde edilene kadar bazı bitişik çalışma çiftleri birleştirilir:
///
/// 1. `1..runs.len()` teki her `i` için: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` teki her `i` için: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Değişmezler, toplam çalışma süresinin *O*(*n*\*log(* n*)) en kötü durumda olmasını sağlar.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Bu uzunluğa kadar olan dilimler, ekleme sıralaması kullanılarak sıralanır.
    const MAX_INSERTION: usize = 20;
    // Çok kısa süreler, en azından bu kadar çok öğeyi kapsayacak şekilde yerleştirme sıralaması kullanılarak uzatılır.
    const MIN_RUN: usize = 10;

    // Sıralama, sıfır boyutlu türlerde anlamlı bir davranışa sahip değildir.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Kısa diziler, ayırmalardan kaçınmak için araya yerleştirme yoluyla yerinde sıralanır.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Çalışma belleği olarak kullanmak için bir arabellek ayırın.Uzunluğu 0 tutuyoruz, böylece `v` içeriğinin sığ kopyalarını, `is_less` panics ise kopyalar üzerinde çalışan doktorları riske atmadan saklayabiliyoruz.
    //
    // Sıralanmış iki çalışmayı birleştirirken, bu arabellek her zaman en fazla `len / 2` uzunluğa sahip olan daha kısa çalışmanın bir kopyasını tutar.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` teki doğal koşuları belirlemek için, onu geriye doğru hareket ettiriyoruz.
    // Bu garip bir karar gibi görünebilir, ancak birleşmelerin daha çok (forwards) in tersi yönde gittiğini düşünün.
    // Kriterlere göre, ileriye doğru birleştirme, geriye doğru birleştirmekten biraz daha hızlı.
    // Sonuç olarak, geriye doğru gidip gelerek çalıştırmaları tanımlamak performansı artırır.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Bir sonraki doğal koşuyu bulun ve kesinlikle alçalıyorsa tersine çevirin.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Çok kısaysa, çalışmaya biraz daha öğe ekleyin.
        // Ekleme sıralaması, kısa dizilerde birleştirmeli sıralamadan daha hızlıdır, bu nedenle bu, performansı önemli ölçüde artırır.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Bu çalışmayı yığının üzerine itin.
        runs.push(Run { start, len: end - start });
        end = start;

        // Değişmezleri tatmin etmek için bazı bitişik koşu çiftlerini birleştirin.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Son olarak, yığında tam olarak bir çalıştırma kalmalıdır.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Çalıştırma yığınını inceler ve birleştirilecek sonraki çalıştırma çiftini belirler.
    // Daha spesifik olarak, `Some(r)` döndürülürse, bu `runs[r]` ve `runs[r + 1]` in daha sonra birleştirilmesi gerektiği anlamına gelir.
    // Algoritma bunun yerine yeni bir çalıştırma oluşturmaya devam ederse, `None` döndürülür.
    //
    // TimSort, burada açıklandığı gibi hatalı uygulamalarıyla ünlüdür:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Hikayenin özü şudur: değişmezleri yığındaki ilk dört koşuda zorlamalıyız.
    // Bunları yalnızca ilk üçe zorlamak, değişmezlerin yığındaki *tüm* çalışmalar için hala geçerli olmasını sağlamak için yeterli değildir.
    //
    // Bu işlev, ilk dört çalıştırma için değişmezleri doğru bir şekilde kontrol eder.
    // Ek olarak, üst çalıştırma dizin 0'da başlarsa, sıralamayı tamamlamak için yığın tamamen daraltılıncaya kadar her zaman bir birleştirme işlemi talep edecektir.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}