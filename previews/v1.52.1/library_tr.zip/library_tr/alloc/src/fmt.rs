//! "String" leri biçimlendirmek ve yazdırmak için yardımcı programlar.
//!
//! Bu modül, [`format!`] sözdizimi uzantısı için çalışma zamanı desteğini içerir.
//! Bu makro, çalışma zamanında argümanları dizelere biçimlendirmek için bu modüle çağrı göndermek için derleyicide uygulanır.
//!
//! # Usage
//!
//! [`format!`] makrosunun, C'nin `printf`/`fprintf` işlevlerinden veya Python'nin `str.format` işlevinden gelenlere aşina olması amaçlanmıştır.
//!
//! [`format!`] uzantısının bazı örnekleri şunlardır:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" önde gelen sıfırlarla
//! ```
//!
//! Bunlardan, ilk argümanın bir biçim dizesi olduğunu görebilirsiniz.Bunun bir dizge olması için derleyici tarafından gereklidir;geçilen bir değişken olamaz (geçerlilik denetimi yapmak için).
//! Derleyici daha sonra biçim dizesini ayrıştırır ve sağlanan argümanlar listesinin bu biçim dizesine geçirilmeye uygun olup olmadığını belirler.
//!
//! Tek bir değeri dizeye dönüştürmek için [`to_string`] yöntemini kullanın.Bu, [`Display`] biçimlendirmesi trait'yi kullanacaktır.
//!
//! ## Konumsal parametreler
//!
//! Her biçimlendirme bağımsız değişkeninin hangi değer bağımsız değişkenine başvurduğunu belirtmesine izin verilir ve atlanırsa "the next argument" olduğu varsayılır.
//! Örneğin, `{} {} {}` biçim dizesi üç parametre alır ve verildikleri sırayla biçimlendirilirler.
//! Bununla birlikte, `{2} {1} {0}` biçim dizesi, bağımsız değişkenleri ters sırada biçimlendirir.
//!
//! İki tür konum belirleyiciyi birbirine karıştırmaya başladığınızda işler biraz zorlaşabilir."next argument" tanımlayıcısı, bağımsız değişken üzerinde bir yineleyici olarak düşünülebilir.
//! Bir "next argument" tanımlayıcısı her görüldüğünde, yineleyici ilerler.Bu, aşağıdaki gibi davranışlara yol açar:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Argüman üzerindeki dahili yineleyici, ilk `{}` görülene kadar geliştirilmemiştir, bu nedenle ilk argümanı yazdırır.Sonra ikinci `{}` e ulaştıktan sonra, yineleyici ikinci argümana doğru ilerledi.
//! Esasen, bağımsız değişkenlerini açıkça adlandıran parametreler, konumsal belirticiler açısından bir bağımsız değişkeni adlandırmayan parametreleri etkilemez.
//!
//! Tüm bağımsız değişkenlerini kullanmak için bir biçim dizesi gereklidir, aksi takdirde bu bir derleme zamanı hatasıdır.Biçim dizesinde aynı argümana birden çok kez başvurabilirsiniz.
//!
//! ## Adlandırılmış parametreler
//!
//! Rust, bir işlev için adlandırılmış parametrelerin Python benzeri bir eşdeğerine sahip değildir, ancak [`format!`] makrosu, adlandırılmış parametrelerden yararlanmasına izin veren bir sözdizimi uzantısıdır.
//! Adlandırılmış parametreler, bağımsız değişken listesinin sonunda listelenir ve sözdizimine sahiptir:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Örneğin, aşağıdaki [`format!`] ifadelerinin tümü adlandırılmış bağımsız değişken kullanır:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! İsimleri olan bağımsız değişkenlerin arkasına konumsal parametreler (isimsiz olanlar) koymak geçerli değildir.Konumsal parametrelerde olduğu gibi, biçim dizesi tarafından kullanılmayan adlandırılmış parametreleri sağlamak geçerli değildir.
//!
//! # Parametreleri Biçimlendirme
//!
//! Biçimlendirilen her bağımsız değişken, bir dizi biçimlendirme parametresi tarafından dönüştürülebilir ([the syntax](#syntax)) teki `format_spec` e karşılık gelir. Bu parametreler, biçimlendirilenin dize temsilini etkiler.
//!
//! ## Width
//!
//! ```
//! // Tüm bu baskı "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Bu, formatın alması gereken "minimum width" için bir parametredir.
//! Değerin dizesi bu kadar karakteri doldurmuyorsa, gerekli alanı kaplamak için fill/alignment tarafından belirtilen dolgu kullanılacaktır (aşağıya bakın).
//!
//! Genişlik değeri, ikinci bağımsız değişkenin genişliği belirten bir [`usize`] olduğunu belirten bir `$` son eki eklenerek parametreler listesine bir [`usize`] olarak da sağlanabilir.
//!
//! Dolar sözdizimi ile bir argümana başvurmak "next argument" sayacını etkilemez, bu nedenle argümanlara konuma göre atıfta bulunmak veya adlandırılmış argümanlar kullanmak genellikle iyi bir fikirdir.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! İsteğe bağlı dolgu karakteri ve hizalama, normalde [`width`](#width) parametresiyle birlikte sağlanır.`width` ten önce, `:` ten hemen sonra tanımlanmalıdır.
//! Bu, biçimlendirilen değerin `width` ten küçük olması durumunda etrafına bazı ekstra karakterlerin yazdırılacağını gösterir.
//! Doldurma, farklı hizalamalar için aşağıdaki varyantlarda gelir:
//!
//! * `[fill]<` - bağımsız değişken `width` sütunlarında sola hizalanır
//! * `[fill]^` - bağımsız değişken, `width` sütunlarında ortaya hizalanır
//! * `[fill]>` - bağımsız değişken `width` sütunlarında sağa hizalanır
//!
//! Sayısal olmayanlar için varsayılan [fill/alignment](#fillalignment) boşluktur ve sola hizalıdır.Sayısal biçimlendiriciler için varsayılan da bir boşluk karakteridir, ancak sağa hizalı.
//! Sayısallar için `0` bayrağı (aşağıya bakın) belirtilmişse, örtük dolgu karakteri `0` tir.
//!
//! Hizalamanın bazı türler tarafından uygulanmayabileceğini unutmayın.Özellikle, genellikle `Debug` trait için uygulanmaz.
//! Dolgunun uygulandığından emin olmanın iyi bir yolu, girdinizi biçimlendirmek ve ardından çıktınızı elde etmek için bu sonuç dizesini doldurmaktır:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Merhaba Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Bunların tümü, biçimlendiricinin davranışını değiştiren bayraklardır.
//!
//! * `+` - Bu, sayısal türler içindir ve işaretin her zaman yazdırılması gerektiğini belirtir.Pozitif işaretler hiçbir zaman varsayılan olarak yazdırılmaz ve negatif işaret yalnızca varsayılan olarak `Signed` trait için yazdırılır.
//! Bu bayrak, doğru işaretin (`+` veya `-`) her zaman yazdırılması gerektiğini belirtir.
//! * `-` - Şu anda kullanılmıyor
//! * `#` - Bu bayrak, "alternate" yazdırma biçiminin kullanılması gerektiğini belirtir.Alternatif formlar şunlardır:
//!     * `#?` - [`Debug`] biçimlendirmesini kolayca yazdırın
//!     * `#x` - bir `0x` ile argümandan önce gelir
//!     * `#X` - bir `0x` ile argümandan önce gelir
//!     * `#b` - bir `0b` ile argümandan önce gelir
//!     * `#o` - bir `0o` ile argümandan önce gelir
//! * `0` - Bu, tamsayı formatları için `width` e doldurmanın hem `0` karakteriyle yapılması hem de işarete duyarlı olması gerektiğini belirtmek için kullanılır.
//! `{:08}` gibi bir format, `1` tamsayısı için `00000001` verirken, aynı format `-1` tamsayısı için `-0000001` verir.
//! Negatif versiyonda pozitif versiyondan bir eksik sıfır olduğuna dikkat edin.
//!         Dolgu sıfırlarının her zaman işaretten sonra (varsa) ve rakamlardan önce yerleştirildiğini unutmayın.`#` bayrağıyla birlikte kullanıldığında, benzer bir kural geçerlidir: doldurma sıfırları, önekten sonra ancak rakamlardan önce eklenir.
//!         Ön ek, toplam genişliğe dahildir.
//!
//! ## Precision
//!
//! Sayısal olmayan türler için bu, "maximum width" olarak kabul edilebilir.
//! Elde edilen dizge bu genişlikten daha uzunsa, bu kadar karaktere kadar kısaltılır ve bu kesilmiş değer, bu parametreler ayarlandıysa uygun `fill`, `alignment` ve `width` ile yayınlanır.
//!
//! İntegral türleri için bu dikkate alınmaz.
//!
//! Kayan nokta türleri için bu, ondalık noktadan sonra kaç basamağın yazdırılması gerektiğini belirtir.
//!
//! İstenen `precision` i belirlemenin üç olası yolu vardır:
//!
//! 1. Tam sayı `.N`:
//!
//!    `N` tamsayısının kendisi hassasiyettir.
//!
//! 2. Bir tam sayı veya ad ve ardından dolar işareti `.N$`:
//!
//!    Kesinlik olarak *bağımsız değişken*`N` biçimini (bir `usize` olmalıdır) kullanın.
//!
//! 3. Yıldız işareti `.*`:
//!
//!    `.*` bu `{...}` in bir yerine *iki* formatlı girişle ilişkili olduğu anlamına gelir: ilk giriş `usize` hassasiyetini ve ikincisi yazdırılacak değeri tutar.
//!    Bu durumda, biri `{<arg>:<spec>.*}` biçim dizesi kullanılıyorsa, `<arg>` bölümünün yazdırmak için* değerine * atıfta bulunduğunu ve `precision` in `<arg>` ten önceki girişte gelmesi gerektiğini unutmayın.
//!
//! Örneğin, aşağıdaki çağrıların tümü aynı şeyi `Hello x is 0.01000` yazdırır:
//!
//! ```
//! // Merhaba {arg 0 ("x")}, {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Merhaba {arg 1 ("x")}, {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Merhaba {arg 0 ("x")}, {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Merhaba {next arg ("x")}, {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Merhaba {next arg ("x")}, {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Merhaba {next arg ("x")}, {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Bunlar:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! önemli ölçüde farklı üç şey yazdırın:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Bazı programlama dillerinde, dize biçimlendirme işlevlerinin davranışı, işletim sisteminin yerel ayarına bağlıdır.
//! Rust'nin standart kitaplığı tarafından sağlanan biçim işlevlerinin herhangi bir yerel ayar kavramı yoktur ve kullanıcı yapılandırmasına bakılmaksızın tüm sistemlerde aynı sonuçları üretir.
//!
//! Örneğin, sistem yerel ayarı nokta dışında bir ondalık ayırıcı kullansa bile, aşağıdaki kod her zaman `1.5` i yazdıracaktır.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! `{` ve `}` değişmez karakterleri, bir dizeye aynı karakterle başlanarak dahil edilebilir.Örneğin, `{` karakterinden `{{` ile çıkış yapılır ve `}` karakterine `}}` ile çıkış yapılır.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Özetlemek gerekirse, burada biçim dizelerinin tam gramerini bulabilirsiniz.
//! Kullanılan biçimlendirme dilinin sözdizimi diğer dillerden alınmıştır, bu nedenle çok yabancı olmamalıdır.Bağımsız değişkenler Python benzeri sözdizimi ile biçimlendirilir, yani bağımsız değişkenler C benzeri `%` yerine `{}` ile çevrelenmiştir.
//! Biçimlendirme sözdizimi için gerçek dilbilgisi şöyledir:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Yukarıdaki gramerde, `text` herhangi bir `'{'` veya `'}'` karakteri içeremez.
//!
//! # traits biçimlendiriliyor
//!
//! Bir bağımsız değişkenin belirli bir türle biçimlendirilmesini talep ederken, aslında bir bağımsız değişkenin belirli bir trait'ye atfedilmesini talep ediyorsunuz.
//! Bu, birden çok gerçek türün `{:x}` aracılığıyla ([`i8`] ve [`isize`] gibi) biçimlendirilmesine izin verir.Türlerin traits'ye mevcut eşlemesi:
//!
//! * *hiçbir şey* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ Küçük harfli onaltılık tam sayılarla [`Debug`]
//! * `X?` ⇒ Büyük harf onaltılık tam sayılarla [`Debug`]
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Bunun anlamı, [`fmt::Binary`][`Binary`] trait'yi uygulayan herhangi bir argüman türünün daha sonra `{:b}` ile biçimlendirilebileceğidir.Bu traits için uygulamalar standart kitaplık tarafından bir dizi ilkel tür için sağlanır.
//!
//! Herhangi bir format belirtilmezse (`{}` veya `{:6}` te olduğu gibi), kullanılan trait formatı [`Display`] trait'dir.
//!
//! Kendi türünüz için bir trait biçimini uygularken, bir imza yöntemi uygulamanız gerekecektir:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // bizim özel tipimiz
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Türünüz referansla `self` olarak geçirilecek ve ardından işlev `f.buf` akışına çıktı göndermelidir.İstenen biçimlendirme parametrelerine doğru şekilde uymak her biçim trait uygulamasına bağlıdır.
//! Bu parametrelerin değerleri [`Formatter`] yapısının alanlarında listelenecektir.Buna yardımcı olmak için, [`Formatter`] yapısı ayrıca bazı yardımcı yöntemler de sağlar.
//!
//! Ek olarak, bu işlevin dönüş değeri, [`Result`]"<(),"["std: : fmt::Error`] `>` türlerinin diğer adı olan [`fmt::Result`] tir.
//! Biçimlendirme uygulamaları, hataları [`Formatter`] ten yaymalarını sağlamalıdır (örneğin, [`write!`] çağrılırken).
//! Ancak, hataları asla sahte bir şekilde döndürmemelidirler.
//! Diğer bir deyişle, bir biçimlendirme uygulaması, yalnızca geçirilen [`Formatter`] bir hata döndürürse bir hata döndürmelidir ve döndürmelidir.
//! Bunun nedeni, işlev imzasının önerebileceğinin aksine, dize biçimlendirmesinin yanılmaz bir işlem olmasıdır.
//! Bu işlev yalnızca bir sonuç döndürür çünkü temeldeki akışa yazma başarısız olabilir ve yığında bir hatanın oluştuğu gerçeğini yaymak için bir yol sağlamalıdır.
//!
//! traits biçimlendirmesinin uygulanmasına bir örnek şöyle görünecektir:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` değeri, `Write` trait'yi uygular, bu da yazının aynısıdır!makro bekliyor.
//!         // Bu biçimlendirmenin, biçim dizeleri için sağlanan çeşitli bayrakları yok saydığını unutmayın.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Farklı traits, bir türün farklı çıktı biçimlerine izin verir.
//! // Bu biçimin anlamı, bir vector'nin büyüklüğünü yazdırmaktır.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Formatter nesnesinde `pad_integral` yardımcı yöntemini kullanarak biçimlendirme bayraklarına uyun.
//!         // Ayrıntılar için yöntem belgelerine bakın ve dizeleri doldurmak için `pad` işlevi kullanılabilir.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` `fmt::Debug` e kıyasla
//!
//! Bu iki traits biçimlendirmesinin farklı amaçları vardır:
//!
//! - [`fmt::Display`][`Display`] uygulamalar, türün her zaman bir UTF-8 dizgisi olarak aslına uygun şekilde temsil edilebileceğini iddia eder.Tüm türlerin [`Display`] trait'yi uygulaması beklenmemektedir **.
//! - [`fmt::Debug`][`Debug`] uygulamalar **tüm** genel türler için uygulanmalıdır.
//!   Çıktı, tipik olarak iç durumu olabildiğince sadık bir şekilde temsil edecektir.
//!   [`Debug`] trait'nin amacı, Rust kodunda hata ayıklamayı kolaylaştırmaktır.Çoğu durumda, `#[derive(Debug)]` in kullanılması yeterlidir ve önerilir.
//!
//! Her iki traits'den çıktının bazı örnekleri:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # İlgili makrolar
//!
//! [`format!`] ailesinde bir dizi ilgili makro vardır.Şu anda uygulananlar şunlardır:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Bu ve [`writeln!`], biçim dizesini belirli bir akışa yaymak için kullanılan iki makrodur.Bu, biçim dizelerinin ara tahsisatlarını önlemek ve bunun yerine doğrudan çıktıyı yazmak için kullanılır.
//! Başlık altında, bu işlev aslında [`std::io::Write`] trait üzerinde tanımlanan [`write_fmt`] işlevini çağırıyor.
//! Örnek kullanım:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Bu ve [`println!`], çıktılarını stdout'ye gönderir.[`write!`] makrosuna benzer şekilde, bu makroların amacı çıktı yazdırılırken ara ayırmalardan kaçınmaktır.Örnek kullanım:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] ve [`eprintln!`] makroları, çıkışlarını stderr'ye yaymaları dışında, sırasıyla [`print!`] ve [`println!`] ile aynıdır.
//!
//! ### `format_args!`
//!
//! Bu, biçim dizesini açıklayan opak bir nesnenin güvenli bir şekilde etrafından dolaşmak için kullanılan ilginç bir makrodur.Bu nesne, oluşturmak için herhangi bir yığın ayırma gerektirmez ve yalnızca yığındaki bilgilere başvurur.
//! Başlık altında, ilgili tüm makrolar buna göre uygulanmaktadır.
//! Öncelikle, bazı örnek kullanımlar şöyledir:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! [`format_args!`] makrosunun sonucu, [`fmt::Arguments`] tipi bir değerdir.
//! Bu yapı daha sonra biçim dizesini işlemek için bu modül içindeki [`write`] ve [`format`] işlevlerine geçirilebilir.
//! Bu makronun amacı, biçimlendirme dizeleri ile uğraşırken ara ayırmaları daha da önlemektir.
//!
//! Örneğin, bir günlük kitaplığı standart biçimlendirme sözdizimini kullanabilir, ancak çıktının nereye gitmesi gerektiği belirlenene kadar bu yapının içinden dahili olarak geçecektir.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// `format` işlevi bir [`Arguments`] yapısını alır ve sonuçta ortaya çıkan biçimlendirilmiş dizeyi döndürür.
///
///
/// [`Arguments`] örneği, [`format_args!`] makrosu ile oluşturulabilir.
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Lütfen [`format!`] kullanmanın tercih edilebileceğini unutmayın.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}