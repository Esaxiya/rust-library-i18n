#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Yeni belleğin içeriği başlatılmamış.
    Uninitialized,
    /// Yeni hafızanın sıfırlanması garanti edilir.
    Zeroed,
}

/// İlgili tüm köşe durumları hakkında endişelenmenize gerek kalmadan yığın üzerinde bir bellek tamponunu daha ergonomik olarak tahsis etmek, yeniden tahsis etmek ve serbest bırakmak için düşük seviyeli bir yardımcı program.
///
/// Bu tür, Vec ve VecDeque gibi kendi veri yapılarınızı oluşturmak için mükemmeldir.
/// Özellikle:
///
/// * Sıfır boyutlu tiplerde `Unique::dangling()` üretir.
/// * Sıfır uzunluklu tahsislerde `Unique::dangling()` üretir.
/// * `Unique::dangling()` i serbest bırakmaktan kaçınır.
/// * Kapasite hesaplamalarındaki tüm taşmaları yakalar (bunları "capacity overflow" panics'ye yükseltir).
/// * isize::MAX bayttan fazlasını ayıran 32 bit sistemlere karşı koruma sağlar.
/// * Boyunuzun aşılmasına karşı koruma sağlar.
/// * Hatalı tahsisler için `handle_alloc_error` i çağırır.
/// * Bir `ptr::Unique` içerir ve böylece kullanıcıya tüm ilgili faydaları sağlar.
/// * Mevcut en büyük kapasiteyi kullanmak için ayırıcıdan iade edilen fazlalığı kullanır.
///
/// Bu tip zaten yönettiği hafızayı incelemiyor.Düşürüldüğünde *hafızasını* boşaltacaktır, ancak içeriğini *bırakmaya* çalışmayacaktır *.
/// Bir `RawVec` in içinde *depolanan* gerçek şeylerin üstesinden gelmek `RawVec` kullanıcısına bağlıdır.
///
/// Sıfır boyutlu türlerin fazlası her zaman sonsuzdur, bu nedenle `capacity()` her zaman `usize::MAX` döndürür.
/// Bu, bu tür bir `Box<[T]>` ile gidip gelirken dikkatli olmanız gerektiği anlamına gelir, çünkü `capacity()` uzunluğu vermeyecektir.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Bu, `#[unstable]` "const fn" nin `min_const_fn` e uyması gerekmediği ve bu nedenle "min_const_fn" de çağrılamayacağı için mevcuttur.
    ///
    /// `RawVec<T>::new` i veya bağımlılıkları değiştirirseniz, lütfen `min_const_fn` i gerçekten ihlal edecek hiçbir şey sunmamaya dikkat edin.
    ///
    /// NOTE: Bu saldırıdan kaçınabilir ve `min_const_fn` ile uyumluluk gerektiren ancak `#[rustc_const_unstable(feature = "foo", issue = "01234")]` mevcutken `foo` i etkinleştirmeyen `stable(...) const fn`/kullanıcı kodunda çağrılmasına izin vermeyen bazı `#[rustc_force_min_const_fn]` öznitelikleriyle uyumluluğu kontrol edebiliriz.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Ayırma yapmadan mümkün olan en büyük `RawVec` i (sistem yığınında) oluşturur.
    /// `T` pozitif boyuta sahipse, bu `0` kapasiteli bir `RawVec` yapar.
    /// `T` sıfır boyutluysa, `usize::MAX` kapasiteli bir `RawVec` yapar.
    /// Gecikmeli tahsis uygulamak için kullanışlıdır.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Tam olarak bir `[T; capacity]` için kapasite ve hizalama gereksinimlerine sahip bir `RawVec` (sistem yığınında) oluşturur.
    /// Bu, `capacity` `0` veya `T` sıfır boyutlu olduğunda `RawVec::new` i aramaya eşdeğerdir.
    /// `T` sıfır boyutluysa, bunun istenen kapasiteye sahip bir `RawVec`*almayacağınız* anlamına geldiğini unutmayın.
    ///
    /// # Panics
    ///
    /// Panics, istenen kapasite `isize::MAX` baytı aşarsa.
    ///
    /// # Aborts
    ///
    /// OOM üzerinden iptaller.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` gibi, ancak tamponun sıfırlanacağını garanti eder.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Bir işaretçi ve kapasiteden bir `RawVec` i yeniden oluşturur.
    ///
    /// # Safety
    ///
    /// `ptr` (sistem yığınında) ve verilen `capacity` ile tahsis edilmelidir.
    /// `capacity`, boyut türleri için `isize::MAX` i aşamaz.(yalnızca 32 bit sistemlerle ilgili bir sorun).
    /// ZST vectors, `usize::MAX` e kadar kapasiteye sahip olabilir.
    /// `ptr` ve `capacity`, bir `RawVec` ten geliyorsa, bu garantilidir.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vec'ler aptaldır.Geç:
    // - 8 eğer eleman boyutu 1 ise, çünkü herhangi bir yığın ayırıcı muhtemelen 8 bayttan küçük bir isteği en az 8 bayta yuvarlayacaktır.
    //
    // - 4 Öğeler orta büyüklükte ise (<=1 KiB).
    // - 1 aksi takdirde, çok kısa Vec'ler için çok fazla alan israfını önlemek için.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` gibi, ancak döndürülen `RawVec` için ayırıcı seçimi üzerinden parametrelendirildi.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" anlamına gelir.sıfır boyutlu türler göz ardı edilir.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` gibi, ancak döndürülen `RawVec` için ayırıcı seçimi üzerinden parametrelendirildi.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` gibi, ancak döndürülen `RawVec` için ayırıcı seçimi üzerinden parametrelendirildi.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` i `RawVec<T>` e dönüştürür.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Tüm arabelleği belirtilen `len` ile `Box<[MaybeUninit<T>]>` e dönüştürür.
    ///
    /// Bunun gerçekleştirilmiş olabilecek `cap` değişikliklerini doğru şekilde yeniden oluşturacağını unutmayın.(Ayrıntılar için tür açıklamasına bakın.)
    ///
    /// # Safety
    ///
    /// * `len` en son talep edilen kapasiteden büyük veya ona eşit olmalıdır ve
    /// * `len` `self.capacity()` ten küçük veya ona eşit olmalıdır.
    ///
    /// Bir ayırıcı, talep edilenden daha büyük bir bellek bloğunu fazla bulup geri döndürebileceğinden, istenen kapasite ve `self.capacity()` in farklı olabileceğini unutmayın.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Güvenlik gerekliliğinin yarısını sağlıklı kontrol edin (diğer yarısını kontrol edemiyoruz).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Burada `unwrap_or_else` ten kaçınıyoruz çünkü üretilen LLVM IR miktarını şişiriyor.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Bir işaretçi, kapasite ve ayırıcıdan bir `RawVec` i yeniden oluşturur.
    ///
    /// # Safety
    ///
    /// `ptr` (verilen ayırıcı `alloc` aracılığıyla) ve verilen `capacity` ile tahsis edilmelidir.
    /// `capacity`, boyut türleri için `isize::MAX` i aşamaz.
    /// (yalnızca 32 bit sistemlerle ilgili bir sorun).
    /// ZST vectors, `usize::MAX` e kadar kapasiteye sahip olabilir.
    /// `ptr` ve `capacity`, `alloc` aracılığıyla oluşturulan bir `RawVec` ten geliyorsa, bu garanti edilir.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Tahsisatın başlangıcına ham bir işaretçi alır.
    /// `capacity == 0` veya `T` sıfır boyutluysa bunun `Unique::dangling()` olduğunu unutmayın.
    /// İlk durumda dikkatli olmalısın.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Tahsisat kapasitesini alır.
    ///
    /// `T` sıfır boyutlu ise bu her zaman `usize::MAX` olacaktır.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Bu `RawVec` i destekleyen ayırıcıya paylaşılan bir referans döndürür.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Tahsis edilmiş bir bellek yığınına sahibiz, böylece mevcut düzenimizi elde etmek için çalışma zamanı kontrollerini atlayabiliriz.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Arabelleğin en azından `len + additional` öğelerini tutmak için yeterli alan içermesini sağlar.
    /// Zaten yeterli kapasiteye sahip değilse, amortize edilmiş *O*(1) davranışı elde etmek için yeterli alan artı rahat boş alanı yeniden tahsis edecektir.
    ///
    /// Gereksiz yere kendisini panic'ye neden olacaksa, bu davranışı sınırlayacaktır.
    ///
    /// `len`, `self.capacity()` i aşarsa, bu istenen alanı gerçekten tahsis edemeyebilir.
    /// Bu gerçekten güvensiz değildir, ancak bu işlevin davranışına dayanan *sizin* yazdığınız güvenli olmayan kod bozulabilir.
    ///
    /// Bu, `extend` gibi bir toplu itme işlemi uygulamak için idealdir.
    ///
    /// # Panics
    ///
    /// Yeni kapasite `isize::MAX` baytı aşarsa Panics.
    ///
    /// # Aborts
    ///
    /// OOM üzerinden iptaller.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // len `isize::MAX` i aşarsa rezerv iptal edilir veya paniğe kapılırdı, bu nedenle bunu şimdi kontrol edilmeden yapmak güvenlidir.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` ile aynıdır, ancak paniklemek veya iptal etmek yerine hata verir.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Arabelleğin en azından `len + additional` öğelerini tutmak için yeterli alan içermesini sağlar.
    /// Henüz yapmadıysa, gerekli olan minimum bellek miktarını yeniden tahsis edecektir.
    /// Genellikle bu, tam olarak gerekli hafıza miktarı olacaktır, ancak prensipte ayırıcı istediğimizden fazlasını geri vermekte özgürdür.
    ///
    ///
    /// `len`, `self.capacity()` i aşarsa, bu istenen alanı gerçekten tahsis edemeyebilir.
    /// Bu gerçekten güvensiz değildir, ancak bu işlevin davranışına dayanan *sizin* yazdığınız güvenli olmayan kod bozulabilir.
    ///
    /// # Panics
    ///
    /// Yeni kapasite `isize::MAX` baytı aşarsa Panics.
    ///
    /// # Aborts
    ///
    /// OOM üzerinden iptaller.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` ile aynıdır, ancak paniklemek veya iptal etmek yerine hata verir.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Tahsisi belirtilen miktara kadar küçültür.
    /// Verilen miktar 0 ise, gerçekte tamamen serbest bırakılır.
    ///
    /// # Panics
    ///
    /// Panics, verilen miktar mevcut kapasiteden *daha büyükse*.
    ///
    /// # Aborts
    ///
    /// OOM üzerinden iptaller.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Tamponun gerekli ekstra kapasiteyi karşılaması için büyümesi gerekiyorsa geri döner.
    /// Esas olarak, `grow` i satır içi yapmadan yedek aramaları mümkün kılmak için kullanılır.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Bu yöntem genellikle birçok kez somutlaştırılır.Bu nedenle, derleme sürelerini iyileştirmek için olabildiğince küçük olmasını istiyoruz.
    // Ancak, oluşturulan kodun daha hızlı çalışmasını sağlamak için içeriğinin olabildiğince statik olarak hesaplanabilir olmasını da istiyoruz.
    // Bu nedenle, bu yöntem dikkatlice yazılır, böylece `T` e bağlı olan kodun tamamı onun içinde olurken, `T` e bağlı olmayan kodun çoğu `T` e göre jenerik olmayan işlevlerdedir.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Bu, arama bağlamları tarafından sağlanır.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` olduğunda `usize::MAX` kapasitesi döndürdüğümüz için
            // 0, buraya gelmek, `RawVec` in aşırı dolu olduğu anlamına gelir.
            return Err(CapacityOverflow);
        }

        // Ne yazık ki, bu kontroller hakkında gerçekten yapabileceğimiz bir şey yok.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Bu üstel büyümeyi garanti eder.
        // İkiye katlama aşılamaz çünkü `cap <= isize::MAX` ve `cap` tipi `usize` dir.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` e göre jenerik değildir.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Bu yöntemdeki kısıtlamalar `grow_amortized` dekilerle hemen hemen aynıdır, ancak bu yöntem genellikle daha seyrek somutlaştırıldığından daha az kritiktir.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Yazı boyutu olduğunda `usize::MAX` kapasitesi döndürdüğümüz için
            // 0, buraya gelmek, `RawVec` in aşırı dolu olduğu anlamına gelir.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` e göre jenerik değildir.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Bu işlev, derleme sürelerini en aza indirmek için `RawVec` in dışındadır.Ayrıntılar için `RawVec::grow_amortized` üzerindeki yoruma bakın.
// (Pratikte görülen farklı `A` türlerinin sayısı, `T` türlerinin sayısından çok daha az olduğundan, `A` parametresi önemli değildir.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` in boyutunu küçültmek için buradaki hatayı kontrol edin.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Ayırıcı, hizalama eşitliğini kontrol eder
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*'in sahip olduğu belleği, içeriğini bırakmaya* çalışmadan boşaltır.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Yedek hata işleme için merkezi işlev.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Aşağıdakileri garanti etmemiz gerekiyor:
// * `> isize::MAX` bayt boyutlu nesneleri asla ayırmıyoruz.
// * `usize::MAX` i aşmıyoruz ve aslında çok az ayırıyoruz.
//
// 64 bit'te, `> isize::MAX` baytlarını ayırmaya çalışmak kesinlikle başarısız olacağından, taşmayı kontrol etmemiz gerekiyor.
// 32 bit ve 16 bit'te, 4 GB'ın tamamını kullanıcı alanında kullanabilen bir platformda çalıştığımızda, örneğin PAE veya x32 te bunun için ekstra bir koruma eklememiz gerekir.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Kapasite aşımlarının raporlanmasından sorumlu merkezi bir işlev.
// Bu, bu panics ile ilgili kod üretiminin minimum olmasını sağlayacaktır çünkü modül boyunca bir grup yerine panics'nin bulunduğu tek bir konum vardır.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}