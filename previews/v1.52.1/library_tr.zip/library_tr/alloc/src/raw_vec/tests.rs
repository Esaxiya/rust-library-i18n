use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Üçüncü taraf ayırıcılar ile `RawVec` arasında bir entegrasyon testi yazmak biraz yanıltıcıdır çünkü `RawVec` API hatalı tahsis yöntemlerini açığa çıkarmaz, bu nedenle ayırıcı bittiğinde ne olacağını kontrol edemeyiz (bir panic tespit etmenin ötesinde).
    //
    //
    // Bunun yerine, bu yalnızca `RawVec` yöntemlerinin depolama alanı ayırdığında en azından Allocator API'sinden geçip geçmediğini kontrol eder.
    //
    //
    //
    //
    //

    // Tahsis girişimleri başarısız olmaya başlamadan önce sabit miktarda yakıt tüketen aptal bir ayırıcı.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (yeniden tahsise neden olur, böylece 50 + 150=200 birim yakıt kullanır)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // İlk olarak, `reserve`, `reserve_exact` gibi ayırır.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97, 7'nin iki katından fazladır, bu nedenle `reserve`, `reserve_exact` gibi çalışmalıdır.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3, 12'nin yarısından azdır, bu nedenle `reserve` katlanarak büyümelidir.
        // Bu testin yazıldığı sırada büyüme faktörü 2'dir, bu nedenle yeni kapasite 24'tür, ancak 1.5 in büyüme faktörü de uygundur.
        //
        // Dolayısıyla `>= 18` iddialı.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}