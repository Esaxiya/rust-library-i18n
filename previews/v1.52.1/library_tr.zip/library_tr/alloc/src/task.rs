#![stable(feature = "wake_trait", since = "1.51.0")]
//! Eşzamansız görevlerle çalışmak için Türler ve Traits.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Bir uygulayıcıya bir görevi uyandırmanın uygulanması.
///
/// Bu trait, bir [`Waker`] oluşturmak için kullanılabilir.
/// Bir uygulayıcı, bu trait'nin bir uygulamasını tanımlayabilir ve bunu, o yürütücüde yürütülen görevlere geçmek için bir Waker oluşturmak için kullanabilir.
///
/// Bu trait, bir [`RawWaker`] oluşturmaya güvenli ve ergonomik bir alternatiftir.
/// Bir görevi uyandırmak için kullanılan verilerin bir [`Arc`] te depolandığı ortak yürütme tasarımını destekler.
/// Bazı uygulayıcılar (özellikle gömülü sistemler için olanlar) bu API'yi kullanamazlar, bu nedenle [`RawWaker`] bu sistemler için bir alternatif olarak mevcuttur.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Bir future alan ve onu mevcut iş parçacığı üzerinde sonuna kadar çalıştıran temel bir `block_on` işlevi.
///
/// **Note:** Bu örnek, basitlik için doğruluğu takas eder.
/// Kilitlenmeleri önlemek için, üretim düzeyindeki uygulamaların `thread::unpark` e yapılan ara çağrıların yanı sıra iç içe çağrıları da ele alması gerekecektir.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Çağrıldığında mevcut iş parçacığını uyandıran bir uyandırıcı.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Mevcut iş parçacığı üzerinde tamamlamak için bir future çalıştırın.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future'yi yoklayabilmek için sabitleyin.
///     let mut fut = Box::pin(fut);
///
///     // future'ye aktarılacak yeni bir bağlam oluşturun.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Tamamlamak için future'yi çalıştırın.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Bu görevi uyandır.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Uyandırıcıyı tüketmeden bu görevi uyandırın.
    ///
    /// Bir uygulayıcı, uyanıklığı tüketmeden uyanmanın daha ucuz bir yolunu destekliyorsa, bu yöntemi geçersiz kılmalıdır.
    /// Varsayılan olarak, [`Arc`] i klonlar ve klonda [`wake`] i çağırır.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // GÜVENLİK: Bu güvenlidir çünkü raw_waker,
        // Arc'tan bir RawWaker<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Bir RawWaker oluşturmak için bu özel işlev,
// `From<Arc<W>> for Waker` in güvenliğinin doğru trait gönderimine bağlı olmadığından emin olmak için bunu `From<Arc<W>> for RawWaker` impl'ye aktararak, bunun yerine her iki impls bu işlevi doğrudan ve açık bir şekilde çağırır.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Klonlamak için yayın referans sayısını artırın.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Arkı Wake::wake işlevine taşıyarak değere göre uyanma
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Referansla uyandırın, düşürmekten kaçınmak için waker'ı ManualDrop'a sarın
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Düşerken Ark referans sayısını azaltın
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}