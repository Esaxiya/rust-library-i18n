//! Tek iş parçacıklı referans sayma işaretçileri.'Rc' 'Referans' anlamına gelir
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] tipi, yığın içinde tahsis edilen `T` tipi bir değerin ortak sahipliğini sağlar.
//! [`Rc`] üzerinde [`clone`][clone] i çağırmak, yığın içindeki aynı tahsis için yeni bir işaretçi üretir.
//! Belirli bir tahsisat için son [`Rc`] göstericisi yok edildiğinde, o tahsisatta saklanan değer (genellikle "inner value" olarak anılır) da bırakılır.
//!
//! Rust'deki paylaşılan referanslar, varsayılan olarak mutasyona izin vermez ve [`Rc`] bir istisna değildir: genellikle bir [`Rc`] içindeki bir şeye değiştirilebilir bir referans elde edemezsiniz.
//! Değişebilirliğe ihtiyacınız varsa, [`Rc`] in içine bir [`Cell`] veya [`RefCell`] koyun;bkz. [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] atomik olmayan referans sayımı kullanır.
//! Bu, ek yükün çok düşük olduğu, ancak bir [`Rc`] in iş parçacıkları arasında gönderilemeyeceği ve dolayısıyla [`Rc`] in [`Send`][send] i gerçekleştirmediği anlamına gelir.
//! Sonuç olarak, Rust derleyicisi derleme zamanında * iş parçacıkları arasında [`Rc`] göndermediğinizi kontrol edecektir.
//! Çok iş parçacıklı, atomik referans saymaya ihtiyacınız varsa, [`sync::Arc`][arc] i kullanın.
//!
//! [`downgrade`][downgrade] yöntemi, sahip olmayan bir [`Weak`] işaretçisini oluşturmak için kullanılabilir.
//! Bir [`Weak`] işaretçisi bir [`Rc`] e [`yükseltme`][yükseltme] olabilir, ancak bu, tahsiste saklanan değer zaten düşürüldüyse [`None`] i döndürecektir.
//! Başka bir deyişle, `Weak` işaretçileri tahsis içindeki değeri canlı tutmaz;ancak, tahsisi (iç değer için destek deposu) canlı tutuyorlar.
//!
//! [`Rc`] işaretçileri arasındaki bir döngü asla ayrılmayacaktır.
//! Bu nedenle [`Weak`] döngüleri kırmak için kullanılır.
//! Örneğin, bir ağaç ana düğümlerden çocuklara güçlü [`Rc`] işaretçilerine ve çocuklardan ana babalarına [`Weak`] işaretçilerine sahip olabilir.
//!
//! `Rc<T>` `T` e ([`Deref`] trait aracılığıyla) otomatik olarak başvurur, böylece [`Rc<T>`][`Rc`] tipi bir değerde "T" nin yöntemlerini çağırabilirsiniz.
//! "T" yöntemleriyle ad çatışmalarını önlemek için, [`Rc<T>`][`Rc`] in kendi yöntemleri [fully qualified syntax] kullanılarak çağrılan ilişkili işlevlerdir:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>`Clone` gibi traits uygulamaları da tam nitelikli sözdizimi kullanılarak çağrılabilir.
//! Bazı insanlar tam nitelikli sözdizimi kullanmayı tercih ederken, diğerleri yöntem çağrısı sözdizimini kullanmayı tercih eder.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Yöntem çağrısı sözdizimi
//! let rc2 = rc.clone();
//! // Tam nitelikli sözdizimi
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] iç değer zaten düşmüş olabileceğinden, `T` e otomatik başvurmaz.
//!
//! # Referansları klonlama
//!
//! Mevcut bir referans sayılan gösterici ile aynı tahsis için yeni bir referans oluşturmak, [`Rc<T>`][`Rc`] ve [`Weak<T>`][`Weak`] için uygulanan `Clone` trait kullanılarak yapılır.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Aşağıdaki iki sözdizimi eşdeğerdir.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a ve b'nin her ikisi de foo ile aynı bellek konumunu gösterir.
//! ```
//!
//! `Rc::clone(&from)` sözdizimi en deyimsel olanıdır çünkü kodun anlamını daha açık bir şekilde aktarır.
//! Yukarıdaki örnekte, bu sözdizimi, bu kodun foo'nun tüm içeriğini kopyalamak yerine yeni bir referans oluşturduğunu görmeyi kolaylaştırır.
//!
//! # Examples
//!
//! Bir dizi "Aygıt" ın belirli bir `Owner` e ait olduğu bir senaryo düşünün.
//! `Gadget'ımızın `Owner` lerini göstermesini istiyoruz.Bunu benzersiz sahiplikle yapamayız çünkü birden fazla gadget aynı `Owner` e ait olabilir.
//! [`Rc`] bir `Owner` i birden fazla "Gadget" arasında paylaşmamıza ve `Owner` in üzerinde herhangi bir `Gadget` gösterdiği sürece tahsis edilmiş kalmasına izin verir.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... diğer alanlar
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... diğer alanlar
//! }
//!
//! fn main() {
//!     // Referans sayılan bir `Owner` oluşturun.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` e ait `Gadget'lar oluşturun.
//!     // `Rc<Owner>` i klonlamak bize aynı `Owner` tahsisine yeni bir işaretçi verir ve işlemdeki referans sayısını artırır.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Yerel değişkenimiz `gadget_owner` i atın.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` i bırakmamıza rağmen, "Gadget" ların `Owner` adının çıktısını alabiliyoruz.
//!     // Bunun nedeni, işaret ettiği `Owner` i değil, yalnızca tek bir `Rc<Owner>` i düşürmüş olmamızdır.
//!     // Aynı `Owner` tahsisine işaret eden başka `Rc<Owner>` olduğu sürece, canlı kalacaktır.
//!     // Saha projeksiyonu `gadget1.owner.name` çalışır çünkü `Rc<Owner>`, `Owner` e otomatik olarak referansı kaldırır.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // İşlevin sonunda, `gadget1` ve `gadget2` imha edilir ve onlarla birlikte `Owner` imize son sayılan referanslar.
//!     // Gadget Man şimdi de yok ediliyor.
//!     //
//! }
//! ```
//!
//! Gereksinimlerimiz değişirse ve ayrıca `Owner` ten `Gadget` e geçebilmemiz gerekirse, sorunlarla karşılaşacağız.
//! `Owner` ten `Gadget` e bir [`Rc`] işaretçisi bir döngü sunar.
//! Bu, referans sayılarının asla 0'a ulaşamayacağı ve tahsisin asla yok edilmeyeceği anlamına gelir:
//! bir bellek sızıntısı.Bunu aşmak için [`Weak`] işaretçileri kullanabiliriz.
//!
//! Rust aslında ilk etapta bu döngüyü oluşturmayı biraz zorlaştırıyor.Birbirini gösteren iki değer elde etmek için, birinin değiştirilebilir olması gerekir.
//! Bu zordur çünkü [`Rc`], yalnızca kapladığı değere paylaşılan referanslar vererek bellek güvenliğini zorlar ve bunlar doğrudan mutasyona izin vermez.
//! Değiştirmek istediğimiz değerin bir kısmını [`RefCell`] e sarmamız gerekiyor, bu da *dahili değişkenlik* sağlıyor: paylaşılan bir referans aracılığıyla değişkenliğe ulaşma yöntemi.
//! [`RefCell`] çalışma zamanında Rust'nin ödünç alma kurallarını uygular.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... diğer alanlar
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... diğer alanlar
//! }
//!
//! fn main() {
//!     // Referans sayılan bir `Owner` oluşturun.
//!     // Bir `RefCell` içine "Owner" vector "Gadget" ı koyduğumuza dikkat edin, böylece onu paylaşılan bir referans yoluyla değiştirebiliriz.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Daha önce olduğu gibi `gadget_owner` e ait `Gadget'lar oluşturun.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // `Gadget'ları `Owner` lerine ekleyin.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dinamik ödünç alma burada bitiyor.
//!     }
//!
//!     // Ayrıntılarını yazdırarak `Gadget'larımızı tekrarlayın.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` bir `Weak<Gadget>`.
//!         // `Weak` işaretçileri, tahsisin hala var olduğunu garanti edemediğinden, bir `Option<Rc<Gadget>>` döndüren `upgrade` i çağırmamız gerekir.
//!         //
//!         //
//!         // Bu durumda, tahsisin hala var olduğunu biliyoruz, bu yüzden biz sadece `Option` i `unwrap` iz.
//!         // Daha karmaşık bir programda, bir `None` sonucu için kusursuz bir hata işlemeye ihtiyacınız olabilir.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // İşlevin sonunda `gadget_owner`, `gadget1` ve `gadget2` yok edilir.
//!     // Artık gadget'lara yönelik güçlü (`Rc`) işaretçileri yok, bu yüzden yok ediliyorlar.
//!     // Bu, Gadget Man'deki referans sayısını sıfırlar, böylece o da yok edilir.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Bu, dönüştürülebilir iç tiplerin aksi takdirde güvenli olan [into|from]_raw() i engelleyebilecek olası alan yeniden düzenlemelerine karşı repr(C)-future arası dayanıklıdır.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Tek iş parçacıklı bir referans sayma işaretçisi.'Rc' 'Referans' anlamına gelir
/// Counted'.
///
/// Daha fazla ayrıntı için [module-level documentation](./index.html) e bakın.
///
/// `Rc` in doğasında olan yöntemlerin tümü ilişkili işlevlerdir, bu da onları örneğin `value.get_mut()` yerine [`Rc::get_mut(&mut value)`][get_mut] olarak adlandırmanız gerektiği anlamına gelir.
/// Bu, `T` iç tipi yöntemlerle çakışmaları önler.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Bu güvensizlik sorun değil çünkü bu Rc canlıyken, iç göstergenin geçerli olduğu garanti ediliyor.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Yeni bir `Rc<T>` oluşturur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Tüm güçlü işaretçilerin sahip olduğu örtük bir zayıf işaretçi vardır; bu, zayıf işaretçi güçlü olanın içinde saklansa bile, güçlü yıkıcı çalışırken zayıf yok edicinin dağıtımı asla serbest bırakmamasını sağlar.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Kendisine zayıf bir referans kullanarak yeni bir `Rc<T>` oluşturur.
    /// Bu işlev dönmeden önce zayıf referansı yükseltmeye çalışmak, bir `None` değeri ile sonuçlanacaktır.
    ///
    /// Bununla birlikte, zayıf referans serbestçe klonlanabilir ve daha sonra kullanılmak üzere saklanabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... daha fazla alan
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Tek bir zayıf referansla "uninitialized" durumunda iç kısmı oluşturun.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Zayıf göstericinin sahipliğinden vazgeçmememiz önemlidir, aksi takdirde bellek `data_fn` döndüğünde serbest kalabilir.
        // Sahipliği gerçekten devretmek isteseydik, kendimiz için ek bir zayıf işaretçi oluşturabilirdik, ancak bu, aksi takdirde gerekli olmayabilecek zayıf referans sayısında ek güncellemelere neden olur.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Güçlü referanslar toplu olarak paylaşılan bir zayıf referansa sahip olmalıdır, bu nedenle yıkıcıyı eski zayıf referansımız için çalıştırmayın.
        //
        mem::forget(weak);
        strong
    }

    /// Başlatılmamış içeriğe sahip yeni bir `Rc` oluşturur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ertelenmiş başlatma:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Hafızanın `0` baytlarla doldurulduğu, başlatılmamış içeriğe sahip yeni bir `Rc` oluşturur.
    ///
    ///
    /// Bu yöntemin doğru ve yanlış kullanım örnekleri için [`MaybeUninit::zeroed`][zeroed] e bakın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Tahsisat başarısız olursa bir hata döndürerek yeni bir `Rc<T>` oluşturur
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Tüm güçlü işaretçilerin sahip olduğu örtük bir zayıf işaretçi vardır; bu, zayıf işaretçi güçlü olanın içinde saklansa bile, güçlü yıkıcı çalışırken zayıf yok edicinin dağıtımı asla serbest bırakmamasını sağlar.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Başlangıç durumuna getirilmemiş içeriğe sahip yeni bir `Rc` oluşturur ve ayırma başarısız olursa bir hata döndürür
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ertelenmiş başlatma:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Başlangıç durumuna getirilmemiş içeriğe sahip yeni bir `Rc` oluşturur, bellek `0` baytlarla doldurulur ve ayırma başarısız olursa bir hata döndürür
    ///
    ///
    /// Bu yöntemin doğru ve yanlış kullanım örnekleri için [`MaybeUninit::zeroed`][zeroed] e bakın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Yeni bir `Pin<Rc<T>>` oluşturur.
    /// `T`, `Unpin` i uygulamazsa, `value` belleğe sabitlenir ve hareket ettirilemez.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// `Rc` in tam olarak bir güçlü referansı varsa iç değeri döndürür.
    ///
    /// Aksi takdirde, bir [`Err`], geçirilen aynı `Rc` ile döndürülür.
    ///
    ///
    /// Bu, olağanüstü zayıf referanslar olsa bile başarılı olacaktır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // içerilen nesneyi kopyala

                // Zayıflayanlara, güçlü sayımı azaltarak yükseltilemeyeceklerini belirtin ve ardından yalnızca sahte bir Zayıf işleyerek düşürme mantığını işlerken örtük "strong weak" işaretçisini kaldırın.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Başlatılmamış içeriğe sahip referans sayılan yeni bir dilim oluşturur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ertelenmiş başlatma:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Hafızanın `0` bayt ile doldurulduğu, başlatılmamış içeriğe sahip referans sayılan yeni bir dilim oluşturur.
    ///
    ///
    /// Bu yöntemin doğru ve yanlış kullanım örnekleri için [`MaybeUninit::zeroed`][zeroed] e bakın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` e dönüştürür.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] te olduğu gibi, iç değerin gerçekten başlatılmış durumda olduğundan emin olmak arayan kişiye bağlıdır.
    ///
    /// İçerik henüz tam olarak başlatılmadığında bunu çağırmak, anında tanımlanmamış davranışa neden olur.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ertelenmiş başlatma:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` e dönüştürür.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] te olduğu gibi, iç değerin gerçekten başlatılmış durumda olduğundan emin olmak arayan kişiye bağlıdır.
    ///
    /// İçerik henüz tam olarak başlatılmadığında bunu çağırmak, anında tanımlanmamış davranışa neden olur.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ertelenmiş başlatma:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Sarılmış işaretçiyi döndürerek `Rc` i tüketir.
    ///
    /// Bellek sızıntısını önlemek için işaretçi [`Rc::from_raw`][from_raw] kullanılarak `Rc` e geri dönüştürülmelidir.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Verilere ham bir işaretçi sağlar.
    ///
    /// Sayımlar hiçbir şekilde etkilenmez ve `Rc` tüketilmez.
    /// İşaretçi, `Rc` te güçlü sayımlar olduğu sürece geçerlidir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // GÜVENLİK: Bu, Deref::deref veya Rc::inner ten geçemez çünkü
        // bu, örneğin raw/mut provenansını korumak için gereklidir.
        // `get_mut` Rc `from_raw` aracılığıyla kurtarıldıktan sonra işaretçi aracılığıyla yazabilir.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Ham bir işaretçiden bir `Rc<T>` oluşturur.
    ///
    /// Ham işaretçinin daha önce [`Rc<U>::into_raw`][into_raw] e yapılan bir çağrı ile döndürülmüş olması gerekir; burada `U`, `T` ile aynı boyuta ve hizaya sahip olmalıdır.
    /// `U`, `T` ise bu önemsiz bir şekilde doğrudur.
    /// `U`, `T` değilse, ancak aynı boyuta ve hizalamaya sahipse, bunun temelde farklı türlerdeki referansları dönüştürmek gibi olduğunu unutmayın.
    /// Bu durumda hangi kısıtlamaların geçerli olduğu hakkında daha fazla bilgi için [`mem::transmute`][transmute] e bakın.
    ///
    /// `from_raw` kullanıcısı, belirli bir `T` değerinin yalnızca bir kez bırakıldığından emin olmalıdır.
    ///
    /// Bu işlev güvensizdir çünkü yanlış kullanım, geri gönderilen `Rc<T>` e hiçbir zaman erişilmese bile, bellek güvenliğine yol açabilir.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Sızıntıyı önlemek için `Rc` e geri dönüştürün.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` e yapılacak diğer çağrılar bellek açısından güvenli olmayacaktır.
    /// }
    ///
    /// // Bellek, `x` yukarıdaki kapsamın dışına çıktığında serbest bırakıldı, bu nedenle `x_ptr` şimdi sallanıyor!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Orijinal RcBox'ı bulmak için ofseti ters çevirin.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Bu tahsis için yeni bir [`Weak`] işaretçisi oluşturur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Sarkan bir Zayıf yaratmadığımızdan emin olun
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Bu tahsisat için [`Weak`] işaretçisi sayısını alır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Bu ayırmaya yönelik güçlü (`Rc`) işaretçilerinin sayısını alır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Bu tahsis için başka `Rc` veya [`Weak`] işaretçisi yoksa `true` i döndürür.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Aynı tahsis için başka `Rc` veya [`Weak`] işaretçisi yoksa, verilen `Rc` e değiştirilebilir bir referans döndürür.
    ///
    ///
    /// Aksi takdirde [`None`] i döndürür, çünkü paylaşılan bir değeri değiştirmek güvenli değildir.
    ///
    /// Ayrıca, başka işaretçiler varken iç değeri [`clone`][clone] yapacak olan [`make_mut`][make_mut] e de bakın.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Herhangi bir kontrol olmaksızın verilen `Rc` e değiştirilebilir bir referans döndürür.
    ///
    /// Ayrıca güvenli ve uygun kontrolleri yapan [`get_mut`] e bakın.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Aynı tahsisin diğer `Rc` veya [`Weak`] işaretçileri, iade edilen ödünç alma süresi boyunca başvurulmamalıdır.
    ///
    /// Bu, örneğin `Rc::new` ten hemen sonra, böyle işaretçiler yoksa, önemsiz bir durumdur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" alanlarını kapsayan bir referans *oluşturmamaya* dikkat ediyoruz, çünkü bu, referans sayılarına erişimle çelişir (örn.
        // `Weak` tarafından).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// İki "Rc" aynı tahsisi gösteriyorsa ([`ptr::eq`] e benzer bir damarda) `true` i döndürür.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Verilen `Rc` e değiştirilebilir bir referans yapar.
    ///
    /// Aynı tahsis için başka `Rc` işaretçileri varsa, `make_mut`, benzersiz sahiplik sağlamak için yeni bir tahsis için iç değeri [`clone`] yapacaktır.
    /// Bu aynı zamanda yazma sırasında klonlama olarak da adlandırılır.
    ///
    /// Bu tahsis için başka `Rc` işaretçileri yoksa, bu tahsisat için [`Weak`] işaretçilerinin ilişkisi kesilecektir.
    ///
    /// Klonlamak yerine başarısız olan [`get_mut`] e de bakın.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Hiçbir şeyi klonlamayacak
    /// let mut other_data = Rc::clone(&data);    // İç verileri klonlamaz
    /// *Rc::make_mut(&mut data) += 1;        // İç verileri klonlar
    /// *Rc::make_mut(&mut data) += 1;        // Hiçbir şeyi klonlamayacak
    /// *Rc::make_mut(&mut other_data) *= 2;  // Hiçbir şeyi klonlamayacak
    ///
    /// // Şimdi `data` ve `other_data` farklı tahsislere işaret ediyor.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] işaretçilerin ilişkisi kesilecek:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Verileri kopyalamalıyım, başka Rcs var.
            // Klonlanan değerin doğrudan yazılmasına izin vermek için belleği önceden ayırın.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Verileri çalabilir, geriye kalan tek şey Zayıflar
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Örtülü güçlü-zayıf referansı kaldırın (burada sahte bir Zayıf işaretlemeye gerek yok-diğer Zayıfların bizim için temizleyebileceğini biliyoruz)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Bu güvensizlik sorun değil çünkü döndürülen işaretçinin T'ye geri döndürülecek *tek* işaretçi olduğu garanti ediliyor.
        // Referans sayımızın bu noktada 1 olması garantilidir ve `Rc<T>` in kendisinin `mut` olmasını şart koştuk, bu nedenle tahsise olası tek referansı iade ediyoruz.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` i somut bir türe indirgemeye çalışın.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Değerin sağlanan düzene sahip olduğu olasılıkla boyutlandırılmamış bir iç değer için yeterli alana sahip bir `RcBox<T>` ayırır.
    ///
    /// `mem_to_rcbox` işlevi, veri işaretçisi ile çağrılır ve `RcBox<T>` için bir (potansiyel olarak yağ) işaretçisi geri döndürmelidir.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Verilen değer düzenini kullanarak düzeni hesaplayın.
        // Daha önce, düzen `&*(ptr as* const RcBox<T>)` ifadesinde hesaplanıyordu, ancak bu yanlış hizalanmış bir referans oluşturuyordu (bkz. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Değerin sağlanan düzene sahip olduğu olasılıkla boyutlandırılmamış bir iç değer için yeterli alana sahip bir `RcBox<T>` ayırır ve ayırma başarısız olursa bir hata döndürür.
    ///
    ///
    /// `mem_to_rcbox` işlevi, veri işaretçisi ile çağrılır ve `RcBox<T>` için bir (potansiyel olarak yağ) işaretçisi geri döndürmelidir.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Verilen değer düzenini kullanarak düzeni hesaplayın.
        // Daha önce, düzen `&*(ptr as* const RcBox<T>)` ifadesinde hesaplanıyordu, ancak bu yanlış hizalanmış bir referans oluşturuyordu (bkz. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Düzen için ayırın.
        let ptr = allocate(layout)?;

        // RcBox'ı başlatın
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Boyutlandırılmamış bir iç değer için yeterli alana sahip bir `RcBox<T>` tahsis eder
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Verilen değeri kullanarak `RcBox<T>` için ayırın.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Değeri bayt olarak kopyala
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // İçeriğini düşürmeden tahsisi serbest bırakın
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Verilen uzunlukta bir `RcBox<[T]>` tahsis eder.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Öğeleri dilimden yeni ayrılmış Rc <\[T\]> içine kopyala
    ///
    /// Güvensiz çünkü arayan kişinin ya sahipliğini alması ya da `T: Copy` i bağlaması gerekir
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Belirli bir boyutta olduğu bilinen bir yineleyiciden bir `Rc<[T]>` oluşturur.
    ///
    /// Boyut yanlışsa davranış tanımsızdır.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T elemanlarını klonlarken Panic koruma.
        // Bir panic durumunda, yeni RcBox'a yazılan elemanlar bırakılacak, ardından bellek serbest bırakılacaktır.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // İlk öğeye işaretçi
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Temiz.Korumayı unutun, böylece yeni RcBox'ı serbest bırakmasın.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` için kullanılan Uzmanlık trait.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` i düşürür.
    ///
    /// Bu, güçlü referans sayısını azaltacaktır.
    /// Güçlü referans sayısı sıfıra ulaşırsa, diğer referanslar (varsa) [`Weak`] dir, bu nedenle iç değeri `drop` yaparız.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Hiçbir şey yazdırmaz
    /// drop(foo2);   // "dropped!" yazdırır
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // içerdiği nesneyi yok et
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // Şimdi içeriği yok ettiğimize göre örtük "strong weak" işaretçisini kaldırın.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` işaretçisinin bir klonunu oluşturur.
    ///
    /// Bu, güçlü referans sayısını artırarak aynı tahsis için başka bir işaretçi yaratır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` için `Default` değeriyle yeni bir `Rc<T>` oluşturur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` in bir yöntemi olmasına rağmen `Eq` te uzmanlaşmaya izin vermek için hackleyin.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Bu uzmanlığı burada yapıyoruz ve `&T` te daha genel bir optimizasyon olarak değil, çünkü aksi takdirde referanslardaki tüm eşitlik kontrollerine bir maliyet ekleyecektir.
/// "Rc" lerin büyük değerleri depolamak için kullanıldığını, klonlanması yavaş olduğunu, ancak aynı zamanda eşitliği kontrol etmek için ağır olduğunu ve bu maliyetin daha kolay ödenmesine neden olduğunu varsayıyoruz.
///
/// Aynı değere işaret eden iki `Rc` klonuna sahip olma olasılığı, iki "&T" ye göre daha olasıdır.
///
/// Bunu ancak `T: Eq` bir `PartialEq` olarak kasıtlı olarak yansıtma yapmadığında yapabiliriz.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// İki "Rc" için eşitlik.
    ///
    /// İç değerleri eşitse, farklı tahsislerde saklansalar bile iki "Rc" eşittir.
    ///
    /// `T` aynı zamanda `Eq` i de uygularsa (eşitliğin yansıtıcılığını ima eder), aynı tahsisi işaret eden iki "Rc" her zaman eşittir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// İki "Rc" için eşitsizlik.
    ///
    /// İç değerleri eşit değilse iki "Rc" eşit değildir.
    ///
    /// `T` aynı zamanda `Eq` i de uygularsa (eşitliğin yansıtıcılığını ima eder), aynı tahsise işaret eden iki "Rc" asla eşit değildir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// İki "Rc" için kısmi karşılaştırma.
    ///
    /// İkisi, iç değerlerinde `partial_cmp()` aranarak karşılaştırılır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// İki "Rc" için karşılaştırmadan daha az.
    ///
    /// İkisi, iç değerlerinde `<` aranarak karşılaştırılır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// İki "Rc" için "Küçüktür veya eşittir" karşılaştırması.
    ///
    /// İkisi, iç değerlerinde `<=` aranarak karşılaştırılır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// İki "Rc" için karşılaştırmadan daha büyük.
    ///
    /// İkisi, iç değerlerinde `>` aranarak karşılaştırılır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// İki "Rc" için "Büyüktür veya eşittir" karşılaştırması.
    ///
    /// İkisi, iç değerlerinde `>=` aranarak karşılaştırılır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// İki "Rc" için karşılaştırma.
    ///
    /// İkisi, iç değerlerinde `cmp()` aranarak karşılaştırılır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Referans sayılan bir dilimi ayırın ve "v" nin öğelerini klonlayarak doldurun.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Referans sayılan bir dize dilimi ayırın ve `v` i buna kopyalayın.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Referans sayılan bir dize dilimi ayırın ve `v` i buna kopyalayın.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Kutulu bir nesneyi yeni, referans sayılan ayırmaya taşıyın.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Referans sayılan bir dilimi ayırın ve "v" nin öğelerini bu dilime taşıyın.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec'in belleğini boşaltmasına izin verin, ancak içeriğini yok etmesine izin vermeyin
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` teki her bir öğeyi alır ve bir `Rc<[T]>` te toplar.
    ///
    /// # Performans özellikleri
    ///
    /// ## Genel durum
    ///
    /// Genel durumda, `Rc<[T]>` te toplama, önce bir `Vec<T>` te toplanarak yapılır.Yani, aşağıdakileri yazarken:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// bu yazmışız gibi davranır:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // İlk tahsis seti burada gerçekleşir.
    ///     .into(); // `Rc<[T]>` için ikinci bir tahsis burada gerçekleşir.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Bu, `Vec<T>` i inşa etmek için gerektiği kadar ayırır ve ardından `Vec<T>` i `Rc<[T]>` e dönüştürmek için bir kez ayırır.
    ///
    ///
    /// ## Bilinen uzunluktaki yineleyiciler
    ///
    /// `Iterator` iniz `TrustedLen` i uyguladığında ve tam boyutta olduğunda, `Rc<[T]>` için tek bir ayırma yapılacaktır.Örneğin:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Burada sadece tek bir tahsis gerçekleşir.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Uzmanlık trait, `Rc<[T]>` te toplamak için kullanılır.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // `TrustedLen` yineleyici için durum budur.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // GÜVENLİK: Yineleyicinin kesin bir uzunluğa sahip olduğundan ve elimizde olduğundan emin olmalıyız.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Normal uygulamaya geri dönün.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` yönetilen tahsisat için sahip olunmayan bir referans tutan bir [`Rc`] sürümüdür.Tahsise, `Weak` işaretçisinde [`upgrade`] çağrılarak erişilir, bu da bir ["Option"] "<" ["Rc"] "döndürür.<T>>`.
///
/// Bir `Weak` referansı sahiplik olarak sayılmadığından, tahsiste depolanan değerin düşmesini engellemeyecektir ve `Weak` in kendisi hala mevcut olan değer hakkında hiçbir garanti vermez.
/// Böylece [`yükseltme`] d olduğunda [`None`] döndürebilir.
/// Bununla birlikte, bir `Weak` referansının *tahsisin kendisinin (destek deposunun) serbest bırakılmasını engellediğini* unutmayın.
///
/// Bir `Weak` işaretçisi, iç değerinin düşmesini engellemeden [`Rc`] tarafından yönetilen atamaya geçici bir referans tutmak için kullanışlıdır.
/// Aynı zamanda [`Rc`] işaretçileri arasındaki döngüsel referansları önlemek için de kullanılır, çünkü karşılıklı sahiplik referansları hiçbir zaman [`Rc`] in düşürülmesine izin vermez.
/// Örneğin, bir ağaç ana düğümlerden çocuklara güçlü [`Rc`] işaretçilerine ve çocuklardan ana babalarına `Weak` işaretçilerine sahip olabilir.
///
/// Bir `Weak` işaretçisi elde etmenin tipik yolu [`Rc::downgrade`] i aramaktır.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Bu, numaralandırmalarda bu türün boyutunun optimize edilmesine izin veren bir `NonNull` tir, ancak geçerli bir işaretçi olması gerekmez.
    //
    // `Weak::new` bunu `usize::MAX` olarak ayarlar, böylece yığın üzerinde alan ayırmasına gerek kalmaz.
    // Bu, gerçek bir işaretçinin sahip olabileceği bir değer değildir çünkü RcBox en az 2 hizalamaya sahiptir.
    // Bu yalnızca `T: Sized` olduğunda mümkündür;boyutlandırılmamış `T` asla sarkmaz.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Herhangi bir bellek ayırmadan yeni bir `Weak<T>` oluşturur.
    /// Dönüş değerinde [`upgrade`] in çağrılması her zaman [`None`] verir.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Veri alanı hakkında herhangi bir iddiada bulunmadan referans sayılarına erişime izin veren yardımcı türü.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Bu `Weak<T>` tarafından işaret edilen `T` nesnesine ham bir işaretçi döndürür.
    ///
    /// İşaretçi yalnızca bazı güçlü referanslar varsa geçerlidir.
    /// İşaretçi sallanıyor, hizalanmamış ve hatta aksi takdirde [`null`] olabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Her ikisi de aynı nesneyi işaret ediyor
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Burada güçlü olan onu canlı tutar, böylece nesneye hala erişebiliriz.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ama artık değil.
    /// // weak.as_ptr() yapabiliriz, ancak işaretçiye erişmek tanımsız davranışlara yol açar.
    /// // assert_eq! ("merhaba", güvenli olmayan {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // İşaretçi sarkıyorsa, gözcüyü doğrudan iade ederiz.
            // Yük en az RcBox (usize) kadar hizalı olduğundan, bu geçerli bir yük adresi olamaz.
            ptr as *const T
        } else {
            // GÜVENLİK: is_dangling false değerini döndürürse, işaretçi referans alınabilir.
            // Yük bu noktada düşebilir ve kaynağını korumalıyız, bu nedenle ham işaretçi manipülasyonunu kullanın.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` i tüketir ve onu ham bir işaretçiye dönüştürür.
    ///
    /// Bu, zayıf işaretçiyi ham bir işaretçiye dönüştürürken, bir zayıf referansın sahipliğini korurken (zayıf sayı bu işlemle değiştirilmez).
    /// [`from_raw`] ile `Weak<T>` e geri döndürülebilir.
    ///
    /// İşaretçinin hedefine erişim konusunda [`as_ptr`] ile aynı kısıtlamalar geçerlidir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Daha önce [`into_raw`] tarafından oluşturulmuş bir ham işaretçiyi `Weak<T>` e dönüştürür.
    ///
    /// Bu, güvenli bir şekilde güçlü bir referans elde etmek (daha sonra [`upgrade`] i arayarak) veya `Weak<T>` i bırakarak zayıf sayımı iptal etmek için kullanılabilir.
    ///
    /// Bir zayıf referansın sahipliğini alır ([`new`] tarafından oluşturulan işaretçiler hariç, çünkü bunlar hiçbir şeye sahip değildir; yöntem hala üzerlerinde çalışır).
    ///
    /// # Safety
    ///
    /// İşaretçinin [`into_raw`] kaynaklı olması ve potansiyel zayıf referansına sahip olması gerekir.
    ///
    /// Bunu çağırırken güçlü sayımın 0 olmasına izin verilir.
    /// Bununla birlikte, bu, halihazırda bir ham işaretçi olarak gösterilen zayıf bir referansın sahipliğini alır (zayıf sayı, bu işlemle değiştirilmez) ve bu nedenle, [`into_raw`] e yapılan önceki bir çağrı ile eşleştirilmesi gerekir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Son zayıf sayıyı azaltın.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Giriş işaretçisinin nasıl türetildiği ile ilgili bağlam için bkz. Weak::as_ptr.

        let ptr = if is_dangling(ptr as *mut T) {
            // Bu sarkan bir Zayıf.
            ptr as *mut RcBox<T>
        } else {
            // Aksi takdirde, işaretçinin Karışmayan bir Zayıftan geldiğinden emin oluruz.
            // GÜVENLİK: data_offset, ptr bir gerçek (potansiyel olarak düşmüş) T'ye başvurduğundan, çağrılması güvenlidir.
            let offset = unsafe { data_offset(ptr) };
            // Böylece, tüm RcBox'ı elde etmek için ofseti tersine çeviririz.
            // GÜVENLİK: işaretçi Zayıftan kaynaklanmıştır, bu nedenle bu ofset güvenlidir.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // GÜVENLİK: Şimdi orijinal Zayıf işaretçiyi kurtardık, böylece Zayıf olanı yaratabiliriz.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Başarılı olursa iç değerin düşmesini geciktirerek, `Weak` işaretçisini [`Rc`] e yükseltme girişimleri.
    ///
    ///
    /// İç değer o zamandan beri düşürüldüyse [`None`] i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Tüm güçlü işaretçileri yok edin.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Bu ayırmaya işaret eden güçlü (`Rc`) işaretçilerinin sayısını alır.
    ///
    /// `self`, [`Weak::new`] kullanılarak oluşturulmuşsa, bu 0 döndürür.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Bu ayırmaya işaret eden `Weak` işaretçilerinin sayısını alır.
    ///
    /// Güçlü işaretçiler kalmazsa, bu sıfıra döner.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // örtük zayıf ptr'yi çıkar
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// İşaretçi sarkarken ve tahsis edilmiş `RcBox` olmadığında (yani, bu `Weak` `Weak::new` tarafından oluşturulduğunda) `None` i döndürür.
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Alan eşzamanlı olarak değiştirilebileceğinden, "data" alanını kapsayan bir referans *oluşturmamaya* dikkat ediyoruz (örneğin, son `Rc` düşürülürse, veri alanı yerinde bırakılacaktır).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// İki "Zayıf" aynı tahsisi gösteriyorsa ([`ptr::eq`] e benzer) veya her ikisi de herhangi bir tahsisi işaret etmiyorsa (çünkü bunlar `Weak::new()`) ile oluşturulmuşsa) `true` i döndürür.
    ///
    ///
    /// # Notes
    ///
    /// Bu, işaretçileri karşılaştırdığından, `Weak::new()` in herhangi bir tahsisi göstermeseler bile birbirine eşit olacağı anlamına gelir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` karşılaştırılıyor.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` işaretçisini düşürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Hiçbir şey yazdırmaz
    /// drop(foo);        // "dropped!" yazdırır
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // zayıf sayım 1'den başlar ve yalnızca tüm güçlü işaretçiler ortadan kalktığında sıfıra gider.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Aynı tahsisi gösteren `Weak` işaretçisinin bir klonunu oluşturur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Başlatmadan `T` için bellek ayırarak yeni bir `Weak<T>` oluşturur.
    /// Dönüş değerinde [`upgrade`] in çağrılması her zaman [`None`] verir.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget ile güvenli bir şekilde başa çıkmak için burayı kontrol ettik.Özellikle
// Eğer mem::forget Rcs (veya Zayıf) iseniz, ref-sayımı aşabilir ve sonra ödenmemiş Rcs (veya Zayıf) varken tahsisi serbest bırakabilirsiniz.
//
// İptal ediyoruz çünkü bu o kadar yozlaşmış bir senaryo ki ne olacağını umursamıyoruz-hiçbir gerçek program bunu yaşamamalı.
//
// Sahiplik ve hareket semantiği sayesinde Rust'de bu kadar çok klonlamanız gerekmediğinden, bunun ihmal edilebilir bir ek yükü olmalıdır.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Değeri düşürmek yerine taşmayı iptal etmek istiyoruz.
        // Bu çağrıldığında referans sayısı asla sıfır olmayacaktır;
        // yine de, aksi takdirde gözden kaçan bir optimizasyona LLVM'ye ipucu vermek için buraya bir iptal ekliyoruz.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Değeri düşürmek yerine taşmayı iptal etmek istiyoruz.
        // Bu çağrıldığında referans sayısı asla sıfır olmayacaktır;
        // yine de, aksi takdirde gözden kaçan bir optimizasyona LLVM'ye ipucu vermek için buraya bir iptal ekliyoruz.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Bir işaretçinin arkasındaki yük için bir `RcBox` içinde ofseti alın.
///
/// # Safety
///
/// İşaretçi, daha önce geçerli bir T örneğini göstermeli (ve bunun için geçerli meta verilere sahip olmalıdır), ancak T'nin bırakılmasına izin verilir.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Boyutlandırılmamış değeri RcBox'ın sonuna hizalayın.
    // RcBox repr(C) olduğundan, her zaman bellekteki son alan olacaktır.
    // GÜVENLİK: olası tek boyutlandırılmamış türler dilimler, trait nesneler olduğundan,
    // ve harici türlerde, girdi güvenlik gereksinimi şu anda align_of_val_raw gereksinimlerini karşılamak için yeterlidir;bu, dilin std dışında güvenilemeyen bir uygulama ayrıntısıdır.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}