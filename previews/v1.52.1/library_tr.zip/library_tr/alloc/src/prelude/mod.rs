//! Tahsis Prelude
//!
//! Bu modülün amacı, `alloc` crate'nin yaygın olarak kullanılan öğelerinin içe aktarımını, modüllerin üstüne bir glob içe aktarımı ekleyerek azaltmaktır:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;