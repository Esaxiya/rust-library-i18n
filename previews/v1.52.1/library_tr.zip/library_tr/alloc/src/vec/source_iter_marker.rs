use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Kaynak tahsisini yeniden kullanırken yineleyici ardışık düzenini bir Vec'e toplamak için uzmanlık işaretçisi, ör.
/// boru hattını yerinde yürütmek.
///
/// SourceIter ebeveyni trait, özelleştirme işlevinin yeniden kullanılacak ayırmaya erişmesi için gereklidir.
/// Ancak uzmanlığın geçerli olması yeterli değildir.
/// Uygulamadaki ek sınırlara bakın.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-dahili SourceIter/InPlaceIterable traits yalnızca Adaptör zincirleri tarafından uygulanır <Adapter<Adapter<IntoIter>>> (tümü core/std e aittir).
// Adaptör uygulamalarındaki ek sınırlar (`impl<I: Trait> Trait for Adapter<I>` in ötesinde) yalnızca traits (Copy, TrustedRandomAccess, FusedIterator) olarak işaretlenmiş diğer traits'ye bağlıdır.
//
// I.e. işaretçi, kullanıcı tarafından sağlanan türlerin yaşam sürelerine bağlı değildir.Diğer birçok uzmanlığın zaten bağlı olduğu Kopyalama deliğini modulo.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds ile ifade edilemeyen ek gereksinimler.Bunun yerine const eval'a güveniyoruz:
        // a) yeniden kullanım için tahsis olmayacağı ve işaretçi aritmetiği panic olacağı için ZST yok b) Alloc sözleşmesinin gerektirdiği boyut eşleşmesi c) Alloc sözleşmesinin gerektirdiği şekilde hizalamalar eşleşiyor
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // daha genel uygulamalara geri dönüş
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // beri deneyin katlama kullan
        // - bazı yineleyici adaptörleri için daha iyi vektörleştirir
        // - çoğu dahili yineleme yönteminin aksine, yalnızca &mut kendini alır
        // - yazma işaretçisini iç kısımlarından geçirmemizi ve sonunda geri almamızı sağlar
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // yineleme başarılı, aklınızı başınızdan almayın
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // SourceIter sözleşmesinin onaylanıp onaylanmadığını kontrol edin: uyarı: onlar olmasaydı, bu noktaya bile gelemeyebilirdik
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable sözleşmesini kontrol edin.Bu, yalnızca yineleyici kaynak işaretçisini tamamen geliştirdiğinde mümkündür.
        // TrustedRandomAccess aracılığıyla denetlenmemiş erişim kullanıyorsa, kaynak işaretçisi başlangıç konumunda kalacak ve onu referans olarak kullanamayız.
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // Kalan değerleri kaynağın kuyruğuna bırakın, ancak IntoIter kapsam dışına çıktığında tahsisin düşmesini önleyin, eğer düşüş panics ise, toplanan öğeleri de dst_buf'a sızdırıyoruz
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable sözleşmesi burada tam olarak doğrulanamaz çünkü try_fold, kaynak göstericiye özel bir referansa sahiptir çünkü yapabileceğimiz tek şey, hala aralıkta olup olmadığını kontrol etmektir.
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}