use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Örtüşen uzmanlıkları manuel olarak önceliklendirmek için Vec::from_iter için gerekli olan başka bir uzmanlık trait, ayrıntılar için [`SpecFromIter`](super::SpecFromIter) e bakın.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // vector bu yinelemede yinelenebilir boş olmadığında her durumda genişletileceği için ilk yinelemeyi açın, ancak extend_desugared() teki döngü vector'nin birkaç sonraki döngü yinelemesinde dolu olduğunu görmeyecektir.
        //
        // Böylece daha iyi branch tahmini elde ederiz.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // extend() in kendisi boş Vec'ler için spec_from'a delege ettiğinden, spec_extend() e delege vermelidir
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // extend() in kendisi boş Vec'ler için spec_from'a delege ettiğinden, spec_extend() e delege vermelidir
        //
        vector.spec_extend(iterator);
        vector
    }
}