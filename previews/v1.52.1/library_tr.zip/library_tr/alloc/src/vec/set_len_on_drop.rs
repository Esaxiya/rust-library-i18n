// `SetLenOnDrop` değeri kapsam dışına çıktığında vec uzunluğunu ayarlayın.
//
// Fikir şudur: SetLenOnDrop'taki uzunluk alanı, optimize edicinin göreceği yerel bir değişkendir, Vec'in veri işaretçisi aracılığıyla herhangi bir mağazayla aynı adı vermez.
// Bu, #32155 takma ad analizi sorunu için geçici bir çözümdür
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}