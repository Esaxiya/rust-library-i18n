use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter için kullanılan Uzmanlık trait
///
/// ## Yetki grafiği:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Yaygın bir durum, bir vector'yi hemen bir vector'de yeniden toplayan bir işleve geçirmektir.
        // IntoIter hiç geliştirilmediyse bunu kısa devre yapabiliriz.
        // Gelişmiş olduğunda, hafızayı yeniden kullanabilir ve verileri öne taşıyabiliriz.
        // Ancak bunu yalnızca ortaya çıkan Vec, onu genel FromIterator uygulamasıyla oluşturmaktan daha fazla kullanılmayan kapasiteye sahip olmadığında yaparız.
        //
        // Vec'in tahsis davranışı kasıtlı olarak belirtilmediğinden, bu sınırlama kesinlikle gerekli değildir.
        // Ancak muhafazakar bir seçimdir.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // extend() in kendisi boş Vec'ler için spec_from'a delege ettiğinden, spec_extend() e delege vermelidir
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Bu, `iterator.as_slice().to_vec()` i kullanır çünkü spec_extend, nihai kapasite + uzunluk hakkında akıl yürütmek için daha fazla adım atmalı ve böylece daha fazla iş yapmalıdır.
// `to_vec()` doğrudan doğru miktarı tahsis eder ve tam olarak doldurur.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) ile, bu yöntem tanımı için gerekli olan doğal `[T]::to_vec` yöntemi mevcut değildir.
    // Bunun yerine, yalnızca cfg(test) NB ile kullanılabilen `slice::to_vec` işlevini kullanın, daha fazla bilgi için slice.rs teki slice::hack modülüne bakın
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}