use core::intrinsics;
use core::mem;
use core::ptr;

/// Bu, ilgili işlevi çağırarak `v` benzersiz referansının arkasındaki değeri değiştirir.
///
///
/// `change` kapanmasında bir panic meydana gelirse, tüm süreç iptal edilecektir.
#[allow(dead_code)] // örnek olarak ve future kullanımı için saklayın
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Bu, ilgili işlevi çağırarak `v` benzersiz referansının arkasındaki değeri değiştirir ve yol boyunca elde edilen bir sonucu döndürür.
///
///
/// `change` kapanmasında bir panic meydana gelirse, tüm süreç iptal edilecektir.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}