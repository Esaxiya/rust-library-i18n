// Bu, ideali takip eden bir uygulama girişimidir.
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust aslında bağımlı türlere ve polimorfik özyinelemeye sahip olmadığından, pek çok güvensizlikle idare ediyoruz.
//

// Bu modülün ana amacı, ağacı genel (eğer tuhaf bir şekilde şekillendirilmişse) bir kap olarak ele alarak ve B-Ağacı değişmezlerinin çoğuyla uğraşmaktan kaçınarak karmaşıklıktan kaçınmaktır.
//
// Bu nedenle, bu modül, girdilerin sıralanıp sıralanmayacağı, hangi düğümlerin eksik dolu olabileceği ve hatta tam olarak ne anlama geldiğiyle ilgilenmez.Bununla birlikte, birkaç değişmeze güveniyoruz:
//
// - Ağaçlar tek tip depth/height e sahip olmalıdır.Bu, belirli bir düğümden bir yaprağa giden her yolun tam olarak aynı uzunluğa sahip olduğu anlamına gelir.
// - `n` uzunluğundaki bir düğümün `n` anahtarları, `n` değerleri ve `n + 1` kenarları vardır.
//   Bu, boş bir düğümün bile en az bir edge'ye sahip olduğu anlamına gelir.
//   Bir yaprak düğüm için, "having an edge" yalnızca düğümdeki bir konumu tanımlayabileceğimiz anlamına gelir, çünkü yaprak kenarları boştur ve veri temsiline ihtiyaç duymaz.
// Dahili bir düğümde, bir edge hem bir konumu tanımlar hem de bir alt düğüme bir işaretçi içerir.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Yaprak düğümlerin temel temsili ve iç düğümlerin temsilinin bir kısmı.
struct LeafNode<K, V> {
    /// `K` ve `V` te ortak değişken olmak istiyoruz.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Bu düğümün ana düğümün `edges` dizisine dizini.
    /// `*node.parent.edges[node.parent_idx]` `node` ile aynı şey olmalıdır.
    /// Bunun yalnızca `parent` boş olmadığında başlatılması garanti edilir.
    parent_idx: MaybeUninit<u16>,

    /// Bu düğümün sakladığı anahtarların ve değerlerin sayısı.
    len: u16,

    /// Düğümün gerçek verilerini depolayan diziler.
    /// Her dizinin yalnızca ilk `len` öğeleri başlatılır ve geçerlidir.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Yerinde yeni bir `LeafNode` i başlatır.
    unsafe fn init(this: *mut Self) {
        // Genel bir ilke olarak, Valgrind'de hem biraz daha hızlı hem de izlemesi daha kolay olması gerektiğinden, eğer mümkünse alanları ilklendirilmemiş bırakıyoruz.
        //
        unsafe {
            // parent_idx, anahtarlar ve vals hepsi BelkiUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Yeni bir kutulu `LeafNode` oluşturur.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Dahili düğümlerin temel temsili."LeafNode" da olduğu gibi, başlatılmamış anahtarların ve değerlerin düşmesini önlemek için bunlar "BoxedNode" un arkasına gizlenmelidir.
/// Bir `InternalNode` e yönelik herhangi bir işaretçi, düğümün alttaki `LeafNode` kısmına doğrudan bir işaretçiye dönüştürülebilir, böylece kodun, bir işaretçinin ikisinden hangisine işaret ettiğini bile kontrol etmek zorunda kalmadan genel olarak yaprak ve dahili düğümler üzerinde hareket etmesini sağlar.
///
/// Bu özellik, `repr(C)` kullanımıyla etkinleştirilir.
///
#[repr(C)]
// gdb_providers.py bu tür adı iç gözlem için kullanır.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Bu düğümün çocuklarına işaretçiler.
    /// `len + 1` ağaç sonlara doğru `Dying` ödünç alma türü ile tutulurken, bu işaretçilerden bazıları sarkıyor olması dışında bunlardan biri başlatılmış ve geçerli kabul edilir.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Yeni bir kutulu `InternalNode` oluşturur.
    ///
    /// # Safety
    /// Dahili düğümlerin değişmezi, en az bir başlatılmış ve geçerli edge'ye sahip olmalarıdır.
    /// Bu işlev böyle bir edge ayarlamaz.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Sadece veriyi başlatmamız gerekiyor;kenarlar BelkiUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Bir düğüme yönelik yönetilen, boş olmayan bir işaretçi.Bu ya `LeafNode<K, V>` için sahip olunan bir göstericidir ya da `InternalNode<K, V>` için sahip olunan bir göstericidir.
///
/// Ancak, `BoxedNode` gerçekte içerdiği iki tür düğümden hangisini içerdiğine dair hiçbir bilgi içermez ve kısmen bu bilgi eksikliğinden dolayı ayrı bir tür değildir ve yıkıcı yoktur.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Sahip olunan bir ağacın kök düğümü.
///
/// Bunun bir yıkıcısı olmadığını ve manuel olarak temizlenmesi gerektiğini unutmayın.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Başlangıçta boş olan kendi kök düğümü ile sahip olunan yeni bir ağaç döndürür.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` sıfır olmamalıdır.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Sahip olunan kök düğümü mutabık bir şekilde ödünç alır.
    /// `reborrow_mut` ten farklı olarak, bu güvenlidir çünkü dönüş değeri kökü yok etmek için kullanılamaz ve ağaca başka referanslar olamaz.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Sahip olunan kök düğümü biraz mutabık kalarak ödünç alır.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Geri döndürülemez bir şekilde, geçişe izin veren ve yıkıcı yöntemler ve çok az şey sunan bir referansa geçiş yapar.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Önceki kök düğüme işaret eden tek bir edge ile yeni bir dahili düğüm ekler, bu yeni düğümü kök düğüm yapar ve onu döndürür.
    /// Bu, yüksekliği 1 artırır ve `pop_internal_level` in tersidir.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, sadece şimdi içsel olduğumuzu unutmamız dışında:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// İlk alt düğümünü yeni kök düğüm olarak kullanarak dahili kök düğümü kaldırır.
    /// Yalnızca kök düğümün yalnızca bir çocuğu olduğunda çağrılması amaçlandığından, anahtarların, değerlerin ve diğer alt öğelerin hiçbirinde temizleme yapılmaz.
    ///
    /// Bu, yüksekliği 1 azaltır ve `push_internal_level` in tersidir.
    ///
    /// Kök düğüme değil, `Root` nesnesine özel erişim gerektirir;
    /// kök düğüme yapılan diğer tutamaçları veya başvuruları geçersiz kılmayacaktır.
    ///
    /// Panics dahili seviye yoksa, yani kök düğüm bir yapraksa.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // GÜVENLİK: İçsel olduğumuzu iddia ettik.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // GÜVENLİK: `self` i özel olarak ödünç aldık ve ödünç alma türü özeldir.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // GÜVENLİK: ilk edge her zaman başlatılır.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef`, `BorrowType` `Mut` olsa bile, `K` ve `V` te her zaman eş değişkendir.
// Bu teknik olarak yanlıştır, ancak `NodeRef` in dahili kullanımı nedeniyle herhangi bir güvensizlikle sonuçlanamaz çünkü `K` ve `V` e göre tamamen genel kalıyoruz.
//
// Bununla birlikte, genel bir tür `NodeRef` i her sarmaladığında, doğru varyansa sahip olduğundan emin olun.
//
/// Bir düğüme başvuru.
///
/// Bu tür, nasıl davrandığını kontrol eden bir dizi parametreye sahiptir:
/// - `BorrowType`: Bir tür ödünç alma şeklini tanımlayan ve bir ömür boyu süren sahte bir tip.
///    - Bu `Immut<'a>` olduğunda, `NodeRef` kabaca `&'a Node` gibi davranır.
///    - Bu `ValMut<'a>` olduğunda, `NodeRef`, anahtarlar ve ağaç yapısı açısından kabaca `&'a Node` gibi davranır, ancak aynı zamanda ağaç boyunca değerlere birçok değişken referansın bir arada bulunmasına izin verir.
///    - Bu `Mut<'a>` olduğunda, `NodeRef` kabaca `&'a mut Node` gibi davranır, ancak ekleme yöntemleri bir değere değişken bir göstericinin bir arada var olmasına izin verir.
///    - Bu `Owned` olduğunda, `NodeRef` kabaca `Box<Node>` gibi davranır, ancak bir yıkıcıya sahip değildir ve manuel olarak temizlenmesi gerekir.
///    - Bu `Dying` olduğunda, `NodeRef` kabaca `Box<Node>` gibi davranır, ancak ağacı azar azar yok etme yöntemlerine sahiptir ve sıradan yöntemler, arama için güvensiz olarak işaretlenmemiş olsa da, yanlış çağrılırsa UB'yi çağırabilir.
///
///   Herhangi bir `NodeRef` ağaçta gezinmeye izin verdiğinden, `BorrowType` yalnızca düğümün kendisine değil, ağacın tamamına etkin bir şekilde uygulanır.
/// - `K` ve `V`: Bunlar, düğümlerde depolanan anahtar ve değer türleridir.
/// - `Type`: Bu, `Leaf`, `Internal` veya `LeafOrInternal` olabilir.
/// Bu `Leaf` olduğunda, `NodeRef` bir yaprak düğüme işaret eder, bu `Internal` olduğunda `NodeRef` bir dahili düğüme işaret eder ve bu `LeafOrInternal` olduğunda `NodeRef` her iki düğüme de işaret edebilir.
///   `Type` `NodeRef` dışında kullanıldığında `NodeType` olarak adlandırılır.
///
/// Hem `BorrowType` hem de `NodeType`, statik tip güvenliğinden yararlanmak için uyguladığımız yöntemleri kısıtlar.Bu tür kısıtlamaları uygulama şeklimizde sınırlamalar vardır:
/// - Her tür parametresi için, yalnızca genel olarak veya belirli bir tür için bir yöntem tanımlayabiliriz.
/// Örneğin, `into_kv` gibi bir yöntemi genel olarak tüm `BorrowType` için veya bir ömür taşıyan tüm türler için bir kez tanımlayamayız, çünkü `&'a` referanslarını döndürmesini istiyoruz.
///   Bu nedenle, onu yalnızca en az güçlü olan `Immut<'a>` tipi için tanımlıyoruz.
/// - `Mut<'a>` ten `Immut<'a>` e örtük baskı alamayız.
///   Bu nedenle, `into_kv` gibi bir yönteme ulaşmak için daha güçlü bir `NodeRef` üzerinde `reborrow` i açıkça çağırmamız gerekiyor.
///
/// `NodeRef` te bir tür referans döndüren tüm yöntemler:
/// - `self` i değere göre alın ve `BorrowType` tarafından taşınan ömrü iade edin.
///   Bazen böyle bir yöntemi çağırmak için `reborrow_mut` i çağırmamız gerekir.
/// - `self` i referans olarak alın ve (implicitly), `BorrowType` tarafından taşınan ömür yerine bu referansın ömrünü döndürür.
/// Bu şekilde, ödünç alma denetleyicisi, iade edilen referans kullanıldığı sürece `NodeRef` in ödünç alınmış kalacağını garanti eder.
///   Eklemeyi destekleyen yöntemler, ham bir gösterici, yani ömrü olmayan bir referans döndürerek bu kuralı büker.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Düğümün ve yaprak düzeyinin ayrı olduğu düzeylerin sayısı, düğümün `Type` tarafından tamamen tanımlanamayan ve düğümün kendisinin saklamadığı bir sabittir.
    /// Sadece kök düğümün yüksekliğini saklamamız ve diğer tüm düğümlerin yüksekliğini ondan türetmemiz gerekir.
    /// `Type`, `Leaf` ise sıfır ve `Type`, `Internal` ise sıfır olmayan olmalıdır.
    ///
    ///
    height: usize,
    /// Yaprağa veya dahili düğüme işaretçi.
    /// `InternalNode` in tanımı, işaretçinin her iki şekilde de geçerli olmasını sağlar.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` olarak paketlenmiş bir düğüm referansını paketinden çıkarın.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Dahili bir düğümün verilerini gösterir.
    ///
    /// Bu düğüme yapılan diğer başvuruların geçersiz kılınmasını önlemek için ham bir ptr döndürür.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // GÜVENLİK: statik düğüm türü `Internal` tir.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Dahili bir düğümün verilerine özel erişim ödünç alır.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Düğümün uzunluğunu bulur.Bu, anahtarların veya değerlerin sayısıdır.
    /// Kenar sayısı `len() + 1` tir.
    /// Güvenli olmasına rağmen, bu işlevi çağırmanın, güvenli olmayan kodun oluşturduğu değişken referansları geçersiz kılma yan etkisine sahip olabileceğini unutmayın.
    ///
    pub fn len(&self) -> usize {
        // En önemlisi, burada yalnızca `len` alanına erişiyoruz.
        // BorrowType marker::ValMut ise, geçersiz kılmamamız gereken değerlere olağanüstü değişken referanslar olabilir.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Düğümün ayrı olduğu düzeylerin sayısını döndürür.
    /// Sıfır yükseklik, düğümün kendisi bir yaprak olduğu anlamına gelir.
    /// Kök üstte olan ağaçları resmederseniz, sayı, düğümün hangi yükseklikte göründüğünü belirtir.
    /// Üstte yaprakları olan ağaçları resmederseniz, sayı, ağacın düğümün ne kadar yükseğe uzandığını belirtir.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Aynı düğüme geçici olarak başka bir değişmez referansı çıkarır.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Herhangi bir yaprağın veya iç düğümün yaprak kısmını ortaya çıkarır.
    ///
    /// Bu düğüme yapılan diğer başvuruların geçersiz kılınmasını önlemek için ham bir ptr döndürür.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Düğüm, en azından LeafNode kısmı için geçerli olmalıdır.
        // Bu, NodeRef türünde bir referans değildir çünkü benzersiz mi yoksa paylaşımlı mı olması gerektiğini bilmiyoruz.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Geçerli düğümün üstünü bulur.
    /// Geçerli düğümün aslında bir ebeveyni varsa `Ok(handle)` i döndürür; burada `handle`, geçerli düğüme işaret eden ebeveynin edge'sini gösterir.
    ///
    /// Geçerli düğümün ebeveyni yoksa `Err(self)` i döndürür ve orijinal `NodeRef` i geri verir.
    ///
    /// Yöntem adı, kök düğümün üstte olduğu ağaçları resmettiğinizi varsayar.
    ///
    /// `edge.descend().ascend().unwrap()` ve `node.ascend().unwrap().descend()`, başarıya ulaştığında hiçbir şey yapmamalıdır.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Düğümlere ham işaretçiler kullanmalıyız çünkü BorrowType marker::ValMut ise, geçersiz kılmamamız gereken değerlere olağanüstü değişken referanslar olabilir.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` in boş olmaması gerektiğini unutmayın.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` in boş olmaması gerektiğini unutmayın.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Değişmez bir ağaçtaki herhangi bir yaprağın veya iç düğümün yaprak kısmını ortaya çıkarır.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // GÜVENLİK: `Immut` olarak ödünç alınan bu ağaçta değiştirilebilir referanslar olamaz.
        unsafe { &*ptr }
    }

    /// Düğümde depolanan anahtarlara bir görünüm ödünç verir.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` e benzer şekilde, bir düğümün ebeveyn düğümüne bir referans alır, ancak aynı zamanda işlemdeki mevcut düğümü serbest bırakır.
    /// Bu güvensizdir çünkü mevcut düğüm serbest bırakılmasına rağmen hala erişilebilir olacaktır.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Derleyiciye, bu düğümün bir `Leaf` olduğu statik bilgisini güvenli olmayan bir şekilde bildirir.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Derleyiciye, bu düğümün bir `Internal` olduğu statik bilgisini güvenli olmayan bir şekilde bildirir.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Aynı düğüme geçici olarak başka bir değişebilir referansı çıkarır.Dikkat edin, bu yöntem çok tehlikeli olduğundan, iki katına çıkın, çünkü hemen tehlikeli görünmeyebilir.
    ///
    /// Değişken işaretçiler ağacın herhangi bir yerinde dolaşabildiğinden, döndürülen işaretçi orijinal işaretçiyi sarkıtmak, sınırların dışına çıkarmak veya yığılmış ödünç alma kuralları altında geçersiz kılmak için kolayca kullanılabilir.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` e, yeniden ödünç alınan işaretçiler üzerinde gezinme yöntemlerinin kullanımını kısıtlayan ve bu güvensizliği önleyen başka bir tür parametresi eklemeyi düşünün.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Herhangi bir yaprağın veya iç düğümün yaprak kısmına özel erişim ödünç alır.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // GÜVENLİK: Tüm düğüme özel erişime sahibiz.
        unsafe { &mut *ptr }
    }

    /// Herhangi bir yaprağın veya dahili düğümün yaprak kısmına özel erişim sunar.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // GÜVENLİK: Tüm düğüme özel erişime sahibiz.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Anahtar depolama alanının bir öğesine özel erişim sağlar.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY sınırları içinde
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // GÜVENLİK: Arayan kişi kendi kendine başka yöntemler arayamayacaktır.
        // Ödünç alma süresi boyunca benzersiz erişimimiz olduğundan, anahtar dilimi referansı bırakılana kadar.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Düğümün değer depolama alanının bir öğesine veya dilimine özel erişim ödünç alır.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY sınırları içinde
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // GÜVENLİK: Arayan kişi kendi kendine başka yöntemler arayamayacaktır.
        // ödünç alma süresi boyunca benzersiz erişimimiz olduğundan, değer dilim referansı bırakılana kadar.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge içerikleri için düğümün depolama alanının bir öğesine veya dilimine özel erişim ödünç verir.
    ///
    /// # Safety
    /// `index` 0. .KAPASİTE + 1 sınırları içinde
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // GÜVENLİK: Arayan kişi kendi kendine başka yöntemler arayamayacaktır.
        // Ödünç alma süresi boyunca benzersiz erişimimiz olduğundan, edge dilim referansı bırakılana kadar.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Düğüm, `idx` den fazla başlatılmış öğeye sahiptir.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Diğer öğelere, özellikle de daha önceki yinelemelerde arayana geri dönenlere olağanüstü referanslarla örtüşme yapmaktan kaçınmak için, yalnızca ilgilendiğimiz bir öğeye bir referans oluşturuyoruz.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust #74679 sorunu nedeniyle boyutlandırılmamış dizi işaretçilerine baskı yapmalıyız.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Düğümün uzunluğuna özel erişim ödünç alır.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Düğüme yapılan diğer başvuruları geçersiz kılmadan, düğümün kendi üst edge bağlantısını ayarlar.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Kökün üst olan edge ile olan bağlantısını siler.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Düğümün sonuna bir anahtar/değer çifti ekler.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` tarafından döndürülen her öğe, düğüm için geçerli bir edge dizinidir.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Düğümün sonuna bir anahtar/değer çifti ve bu çiftin sağına gitmek için bir edge ekler.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Bir düğümün `Internal` düğümü mü yoksa `Leaf` düğümü mü olduğunu kontrol eder.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Bir düğüm içindeki belirli bir anahtar/değer çifti veya edge referansı.
/// `Node` parametresi bir `NodeRef` olmalı, `Type` ise `KV` (bir anahtar-değer çiftindeki bir tutamacı belirtir) veya `Edge` (bir edge üzerindeki bir tutamacı belirtir) olabilir.
///
/// `Leaf` düğümlerinin bile `Edge` tutamaçlarına sahip olabileceğini unutmayın.
/// Bir alt düğüm için bir gösterici temsil etmek yerine, bunlar alt işaretçilerin anahtar-değer çiftleri arasında gideceği boşlukları temsil eder.
/// Örneğin, uzunluğu 2 olan bir düğümde, biri düğümün solunda, biri iki çift arasında ve biri düğümün sağında olmak üzere 3 olası edge konumu olacaktır.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// `Node` in "Klon" olabileceği tek zaman, değişmez bir referans ve dolayısıyla `Copy` olduğu zaman olduğundan, `#[derive(Clone)]` in tam genelliğine ihtiyacımız yok.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Bu tutamacın işaret ettiği edge veya anahtar/değer çiftini içeren düğümü alır.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Bu tutamacın düğümdeki konumunu döndürür.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` te bir anahtar/değer çifti için yeni bir tutamaç oluşturur.
    /// Güvensiz çünkü arayan kişi `idx < node.len()` i sağlamalıdır.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq'in genel uygulaması olabilir, ancak yalnızca bu modülde kullanılır.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Geçici olarak aynı konumdaki başka bir değişmez tutamaç çıkarır.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Tipimizi bilmediğimiz için Handle::new_kv veya Handle::new_edge kullanamayız
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Güvenli olmayan bir şekilde derleyiciye tutamaç düğümünün bir `Leaf` olduğu statik bilgileri bildirir.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Geçici olarak aynı konumdaki başka bir değiştirilebilir kolu çıkarır.
    /// Dikkat edin, bu yöntem çok tehlikeli olduğundan, iki katına çıkın, çünkü hemen tehlikeli görünmeyebilir.
    ///
    ///
    /// Ayrıntılar için bkz. `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Tipimizi bilmediğimiz için Handle::new_kv veya Handle::new_edge kullanamayız
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` te bir edge için yeni bir tutamaç oluşturur.
    /// Güvensiz çünkü arayan kişi `idx <= node.len()` i sağlamalıdır.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Kapasiteye doldurulmuş bir düğüme eklemek istediğimiz bir edge indeksi verildiğinde, bir bölünme noktasının mantıklı bir KV indeksini ve eklemenin nerede gerçekleştirileceğini hesaplar.
///
/// Bölünme noktasının amacı, anahtarı ve değerinin bir ana düğümde sona ermesidir;
/// bölünme noktasının solundaki anahtarlar, değerler ve kenarlar sol alt öğe olur;
/// bölünme noktasının sağındaki anahtarlar, değerler ve kenarlar doğru alt öğe haline gelir.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust sorunu #74834 bu simetrik kuralları açıklamaya çalışır.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Bu edge'nin sağında ve solunda anahtar/değer çiftleri arasına yeni bir anahtar/değer çifti ekler.
    /// Bu yöntem, düğümde yeni çiftin sığması için yeterli alan olduğunu varsayar.
    ///
    /// Döndürülen işaretçi, eklenen değeri gösterir.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Bu edge'nin sağında ve solunda anahtar/değer çiftleri arasına yeni bir anahtar/değer çifti ekler.
    /// Bu yöntem, yeterli yer yoksa düğümü böler.
    ///
    /// Döndürülen işaretçi, eklenen değeri gösterir.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Bu edge'nin bağlandığı alt düğümdeki üst işaretçiyi ve dizini düzeltir.
    /// Bu, kenarların sıralaması değiştirildiğinde kullanışlıdır,
    fn correct_parent_link(self) {
        // Düğüme yapılan diğer başvuruları geçersiz kılmadan arka nokta oluşturun.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Bu edge ile bu edge'nin sağındaki anahtar/değer çifti arasına bu yeni çiftin sağına gidecek yeni bir anahtar/değer çifti ve bir edge ekler.
    /// Bu yöntem, düğümde yeni çiftin sığması için yeterli alan olduğunu varsayar.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Bu edge ile bu edge'nin sağındaki anahtar/değer çifti arasına bu yeni çiftin sağına gidecek yeni bir anahtar/değer çifti ve bir edge ekler.
    /// Bu yöntem, yeterli yer yoksa düğümü böler.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Bu edge'nin sağında ve solunda anahtar/değer çiftleri arasına yeni bir anahtar/değer çifti ekler.
    /// Bu yöntem, yeterli yer yoksa düğümü böler ve ayrılan kısmı, köke ulaşılana kadar özyinelemeli olarak ana düğüme eklemeye çalışır.
    ///
    ///
    /// Döndürülen sonuç bir `Fit` ise, tutamacının düğümü bu edge düğümü veya bir atası olabilir.
    /// Döndürülen sonuç bir `Split` ise, `left` alanı kök düğüm olacaktır.
    /// Döndürülen işaretçi, eklenen değeri gösterir.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Bu edge ile gösterilen düğümü bulur.
    ///
    /// Yöntem adı, kök düğümün üstte olduğu ağaçları resmettiğinizi varsayar.
    ///
    /// `edge.descend().ascend().unwrap()` ve `node.ascend().unwrap().descend()`, başarıya ulaştığında hiçbir şey yapmamalıdır.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Düğümlere ham işaretçiler kullanmalıyız çünkü BorrowType marker::ValMut ise, geçersiz kılmamamız gereken değerlere olağanüstü değişken referanslar olabilir.
        // Yükseklik alanına erişim konusunda endişelenmenize gerek yok çünkü bu değer kopyalandı.
        // Düğüm işaretçisinin referansı kaldırıldıktan sonra, bir referansla (Rust sorunu #73987) edge dizisine eriştiğimizi ve diziye yönelik veya dizinin içindeki diğer tüm başvuruları, eğer varsa, geçersiz kıldığımıza dikkat edin.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ayrı anahtar ve değer yöntemlerini çağıramayız çünkü ikincisini çağırmak, birincinin döndürdüğü referansı geçersiz kılar.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV tutamacının başvurduğu anahtarı ve değeri değiştirin.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Yaprak verileriyle ilgilenerek belirli bir `NodeType` için `split` uygulamalarına yardımcı olur.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Temeldeki düğümü üç bölüme ayırır:
    ///
    /// - Düğüm, yalnızca bu tutamacın solundaki anahtar-değer çiftlerini içerecek şekilde kesilir.
    /// - Bu tutamaç tarafından gösterilen anahtar ve değer çıkarılır.
    /// - Bu tanıtıcının sağındaki tüm anahtar-değer çiftleri, yeni ayrılmış bir düğüme yerleştirilir.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Bu tutamaç tarafından gösterilen anahtar/değer çiftini kaldırır ve onu, anahtar/değer çiftinin daraltıldığı edge ile birlikte döndürür.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Temeldeki düğümü üç bölüme ayırır:
    ///
    /// - Düğüm, yalnızca bu tutamacın solundaki kenarları ve anahtar/değer çiftlerini içerecek şekilde kesilir.
    /// - Bu tutamaç tarafından gösterilen anahtar ve değer çıkarılır.
    /// - Bu tutamacın sağındaki tüm kenarlar ve anahtar-değer çiftleri, yeni ayrılmış bir düğüme yerleştirilir.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Dahili bir anahtar/değer çifti etrafında bir dengeleme işlemini değerlendirmek ve gerçekleştirmek için bir oturumu temsil eder.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Çocuk olarak düğümü içeren bir dengeleme bağlamı seçer, dolayısıyla KV arasında, ebeveyn düğümde hemen sola veya sağa.
    /// Ebeveyn yoksa bir `Err` döndürür.
    /// Panics üst öğe boşsa.
    ///
    /// Sol tarafı, verilen düğüm bir şekilde yetersizse optimal olmasını tercih eder, yani burada yalnızca sol kardeşinden ve varsa sağ kardeşinden daha az öğeye sahip olduğu anlamına gelir.
    /// Bu durumda, sol kardeşle birleştirme daha hızlıdır, çünkü düğümün N öğelerini sağa kaydırmak ve önde N öğesinden fazlasını taşımak yerine hareket ettirmemiz gerekir.
    /// Sol kardeşten çalmak da tipik olarak daha hızlıdır, çünkü kardeşin öğelerinin en az N'sini sola kaydırmak yerine düğümün N öğelerini sağa kaydırmamız gerekir.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Birleştirmenin mümkün olup olmadığını, yani bir düğümde merkezi KV'yi her iki bitişik alt düğümle birleştirmek için yeterli alan olup olmadığını döndürür.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Birleştirme gerçekleştirir ve kapatmanın neyin geri döneceğine karar vermesine izin verir.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // GÜVENLİK: birleştirilen düğümlerin yüksekliği, yüksekliğin bir altında
                // Bu edge düğümünün, dolayısıyla sıfırın üstünde, dolayısıyla içseldirler.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Üst öğenin anahtar/değer çiftini ve her iki bitişik alt düğümü sol alt düğümde birleştirir ve küçültülmüş üst düğümü döndürür.
    ///
    ///
    /// `.can_merge()` olmadıkça Panics.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Üst öğenin anahtar/değer çiftini ve her iki bitişik alt düğümleri sol alt düğümde birleştirir ve bu alt düğümü döndürür.
    ///
    ///
    /// `.can_merge()` olmadıkça Panics.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Üst öğenin anahtar/değer çiftini ve her iki komşu alt düğümü sol alt düğümde birleştirir ve izlenen edge alt öğesinin sona erdiği bu alt düğümdeki edge tutamacını döndürür,
    ///
    ///
    /// `.can_merge()` olmadıkça Panics.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Bir anahtar/değer çiftini sol alt öğeden kaldırır ve eski üst anahtar/değer çiftini sağ alt öğeye iterken bunu üst öğenin anahtar/değer deposuna yerleştirir.
    ///
    /// Sağ alt öğedeki edge'ye, `track_right_edge_idx` tarafından belirtilen orijinal edge'nin sona erdiği yere karşılık gelen bir tutamaç döndürür.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Bir anahtar/değer çiftini sağ alt öğeden kaldırır ve eski üst anahtar/değer çiftini sol alt öğeye iterken bunu üst öğenin anahtar/değer deposuna yerleştirir.
    ///
    /// `track_left_edge_idx` tarafından belirtilen ve hareket etmeyen sol çocuktaki edge'ye bir tutamaç döndürür.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Bu, `steal_left` e benzer şekilde çalar ancak aynı anda birden fazla öğeyi çalar.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Güvenli bir şekilde çalabileceğimizden emin olun.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Yaprak verilerini taşıyın.
            {
                // Doğru çocukta çalınan öğelere yer açın.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Öğeleri soldaki çocuktan sağa taşıyın.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // En soldaki çalınan çifti ebeveyne taşıyın.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Üst öğenin anahtar/değer çiftini sağdaki alt öğeye taşıyın.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Çalınan kenarlara yer açın.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Kenarları çalın.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` in simetrik klonu.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Güvenli bir şekilde çalabileceğimizden emin olun.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Yaprak verilerini taşıyın.
            {
                // En sağdaki çalınan çifti ebeveyne taşıyın.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Üst öğenin anahtar/değer çiftini soldaki alt öğeye taşıyın.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Öğeleri sağ çocuktan sola taşıyın.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Eskiden çalınan unsurların bulunduğu boşluğu doldurun.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Kenarları çalın.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Eskiden çalınan kenarların olduğu yerlerde boşluğu doldurun.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Bu düğümün bir `Leaf` düğümü olduğunu iddia eden tüm statik bilgileri kaldırır.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Bu düğümün bir `Internal` düğümü olduğunu iddia eden tüm statik bilgileri kaldırır.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Temel düğümün bir `Internal` düğümü mü yoksa bir `Leaf` düğümü mü olduğunu kontrol eder.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` ten sonraki soneki bir düğümden diğerine taşıyın.`right` boş olmalıdır.
    /// `right` in ilk edge'si değişmeden kalır.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Bir düğümün kapasitesinin ötesine geçmesi gerektiğinde yerleştirmenin sonucu.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` in soluna ait öğeler ve kenarlarla mevcut ağaçta değiştirilmiş düğüm.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Bazı anahtar ve değer, başka bir yere eklenmek üzere ayrılır.
    pub kv: (K, V),
    // `kv` in sağına ait öğeler ve kenarlara sahip, sahip olunan, bağlanmamış, yeni düğüm.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Bu ödünç alma türündeki düğüm referanslarının ağaçtaki diğer düğümlere geçişe izin verip vermediği.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Geçiş gerekli değildir, `borrow_mut` in sonucu kullanılarak gerçekleşir.
        // Çapraz geçişi devre dışı bırakarak ve yalnızca köklere yeni referanslar oluşturarak, `Owned` türünün her referansının bir kök düğüme yönelik olduğunu biliyoruz.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Başlatılmış öğeler dilimine bir değer ve ardından başlatılmamış bir öğe ekler.
///
/// # Safety
/// Dilimde `idx` den fazla öğe var.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Tüm başlatılmış öğelerin bir diliminden bir değeri kaldırır ve döndürür, ardında tek bir başlatılmamış öğe bırakır.
///
///
/// # Safety
/// Dilimde `idx` den fazla öğe var.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Bir dilim `distance` konumlarındaki öğeleri sola kaydırır.
///
/// # Safety
/// Dilim en az `distance` öğeye sahiptir.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Bir dilim `distance` konumlarındaki öğeleri sağa kaydırır.
///
/// # Safety
/// Dilim en az `distance` öğeye sahiptir.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Tüm değerleri başlatılmış öğelerden oluşan bir dilimden başlatılmamış öğeler dilimine taşır ve geride tümü başlatılmamış olarak `src` bırakır.
///
/// `dst.copy_from_slice(src)` gibi çalışır ancak `T` in `Copy` olmasını gerektirmez.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;