use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// Ağaçtan bir anahtar/değer çiftini kaldırır ve bu çifti ve bu önceki çifte karşılık gelen edge yaprağını döndürür.
    /// Bu, arayanın ağacı tutan haritadan açması gereken dahili bir kök düğümü boşaltır.
    /// Arayan kişi ayrıca haritanın uzunluğunu azaltmalıdır.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // Çocuk tipini geçici olarak unutmalıyız, çünkü bir yaprağın yakın ebeveynleri için ayrı bir düğüm tipi yoktur.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // GÜVENLİK: `new_pos`, başladığımız yaprak veya kardeşimizdir.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // Yalnızca birleşirsek, üst öğe (varsa) küçüldü, ancak aşağıdaki adımı atlamak, kıyaslamalarda işe yaramaz.
            //
            // GÜVENLİK: `pos` in bulunduğu yaprağı yok etmeyeceğiz veya yeniden düzenlemeyeceğiz
            // üstünü yinelemeli olarak ele alarak;en kötüsü, büyük ebeveyn aracılığıyla ebeveyni yok edeceğiz ya da yeniden düzenleyeceğiz, böylece yaprağın içindeki ebeveynle olan bağı değiştireceğiz.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // Yaprağından bitişik bir KV'yi çıkarın ve ardından kaldırmamız istenen öğenin yerine geri koyun.
        //
        // `choose_parent_kv` te listelenen nedenlerden dolayı soldaki bitişik KV'yi tercih edin.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // Dahili düğüm çalınmış veya birleştirilmiş olabilir.
        // Orijinal KV'nin sona erdiği yeri bulmak için sağa dönün.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}