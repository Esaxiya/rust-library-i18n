use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Aynı aralığın başka bir değişmez eşdeğerini geçici olarak çıkarır.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Bir ağaçta belirli bir aralığı sınırlayan farklı yaprak kenarlarını bulur.
    /// Aynı ağaca bir çift farklı tutamaç veya bir çift boş seçenek döndürür.
    ///
    /// # Safety
    ///
    /// `BorrowType`, `Immut` olmadığı sürece, aynı KV'yi iki kez ziyaret etmek için yinelenen tutamaçları kullanmayın.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())` ile eşdeğer ancak daha verimli.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Bir ağaçta belirli bir aralığı sınırlayan yaprak kenarları çiftini bulur.
    ///
    /// Sonuç, yalnızca ağaç, `BTreeMap` teki ağaç gibi, anahtara göre sıralanırsa anlamlıdır.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // GÜVENLİK: Ödünç alma türümüz değişmez.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Bütün bir ağacı sınırlayan bir çift yaprak kenarını bulur.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Benzersiz bir referansı, belirli bir aralığı sınırlayan bir çift yaprak kenarına böler.
    /// Sonuç, dikkatli kullanılması gereken (some) mutasyonuna izin veren benzersiz olmayan referanslardır.
    ///
    /// Sonuç, yalnızca ağaç, `BTreeMap` teki ağaç gibi, anahtara göre sıralanırsa anlamlıdır.
    ///
    ///
    /// # Safety
    /// Aynı KV'yi iki kez ziyaret etmek için yinelenen tutamaçları kullanmayın.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Benzersiz bir referansı, ağacın tüm aralığını sınırlayan bir çift yaprak kenarına böler.
    /// Sonuçlar, mutasyona (yalnızca değerlerin) izin veren benzersiz olmayan referanslardır, bu nedenle dikkatli kullanılmalıdır.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // NodeRef kökünü burada kopyalıyoruz-aynı KV'yi asla iki kez ziyaret etmeyeceğiz ve asla çakışan değer referanslarıyla sonuçlanmayacağız.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Benzersiz bir referansı, ağacın tüm aralığını sınırlayan bir çift yaprak kenarına böler.
    /// Sonuçlar, büyük ölçüde yıkıcı mutasyona izin veren benzersiz olmayan referanslardır, bu nedenle azami özen gösterilerek kullanılmalıdır.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // NodeRef kökünü burada kopyalıyoruz-kökten elde edilen referanslarla örtüşen bir şekilde ona asla erişemeyeceğiz.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Bir yaprak edge tutamacı verildiğinde, aynı yaprak düğümünde veya bir üst düğümde bulunan sağ taraftaki komşu KV'ye bir tutamacı olan [`Result::Ok`] i döndürür.
    ///
    /// edge yaprağı ağaçtaki son yapraksa, kök düğümle [`Result::Err`] i döndürür.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Bir yaprak edge tutamacı verildiğinde, aynı yaprak düğümünde veya bir üst düğümde bulunan sol taraftaki komşu KV'ye bir tutamacı olan [`Result::Ok`] i döndürür.
    ///
    /// edge yaprağı ağaçtaki ilk yapraksa, kök düğümle [`Result::Err`] i döndürür.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Dahili bir edge tutamacı verildiğinde, aynı dahili düğümde veya bir üst düğümde bulunan sağ taraftaki komşu KV'ye bir tutamacı olan [`Result::Ok`] i döndürür.
    ///
    /// Dahili edge ağaçtaki sonuncuysa, kök düğümle [`Result::Err`] i döndürür.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Ölmekte olan bir ağaçta bir yaprak edge tutamacı verildiğinde, sağ taraftaki bir sonraki yaprak edge'yi ve aradaki anahtar/değer çiftini döndürür; bu, aynı yaprak düğümde, bir üst düğümde veya varolmayan.
    ///
    ///
    /// Bu yöntem aynı zamanda sonuna ulaştığı herhangi bir node(s) i serbest bırakır.
    /// Bu, daha fazla anahtar-değer çifti yoksa, ağacın geri kalanının tamamının ayrılacağı ve geri döndürülecek hiçbir şeyin kalmayacağı anlamına gelir.
    ///
    /// # Safety
    /// Verilen edge, `deallocating_next_back` muadili tarafından daha önce iade edilmemiş olmalıdır.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Ölmekte olan bir ağaçta bir yaprak edge tutamacı verildiğinde, sol taraftaki bir sonraki yaprak edge'yi ve aradaki anahtar/değer çiftini döndürür; bu, aynı yaprak düğümünde, bir üst düğümde bulunur veya varolmaz.
    ///
    ///
    /// Bu yöntem aynı zamanda sonuna ulaştığı herhangi bir node(s) i serbest bırakır.
    /// Bu, daha fazla anahtar-değer çifti yoksa, ağacın geri kalanının tamamının ayrılacağı ve geri döndürülecek hiçbir şeyin kalmayacağı anlamına gelir.
    ///
    /// # Safety
    /// Verilen edge, `deallocating_next` muadili tarafından daha önce iade edilmemiş olmalıdır.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Yapraktan köke kadar bir düğüm yığını ayırır.
    /// Bu, `deallocating_next` ve `deallocating_next_back` ağacın her iki tarafını da kemirip aynı edge'yi vurduktan sonra bir ağacın kalanını kaldırmanın tek yoludur.
    /// Yalnızca tüm anahtarlar ve değerler döndürüldüğünde çağrılması amaçlandığından, anahtarların veya değerlerin hiçbirinde temizleme yapılmaz.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Yaprak edge tutamacını bir sonraki edge yaprağına taşır ve anahtara ve aradaki değere başvuruları döndürür.
    ///
    ///
    /// # Safety
    /// Gidilen yönde başka bir KV olmalıdır.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Yaprak edge tutamacını önceki edge yaprağına taşır ve anahtara ve aradaki değere başvuruları döndürür.
    ///
    ///
    /// # Safety
    /// Gidilen yönde başka bir KV olmalıdır.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Yaprak edge tutamacını bir sonraki edge yaprağına taşır ve anahtara ve aradaki değere başvuruları döndürür.
    ///
    ///
    /// # Safety
    /// Gidilen yönde başka bir KV olmalıdır.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Bunu son olarak yapmak, kıyaslamalara göre daha hızlıdır.
        kv.into_kv_valmut()
    }

    /// Yaprak edge tutamacını önceki yaprağa taşır ve anahtara ve aradaki değere başvuruları döndürür.
    ///
    ///
    /// # Safety
    /// Gidilen yönde başka bir KV olmalıdır.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Bunu son olarak yapmak, kıyaslamalara göre daha hızlıdır.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Yaprak edge tutamacını bir sonraki yaprak edge'ye taşır ve aradaki anahtarı ve değeri döndürür, geride kalan herhangi bir düğümün atamasını kaldırırken, karşılık gelen edge'yi üst düğümünde sarkarken bırakır.
    ///
    /// # Safety
    /// - Gidilen yönde başka bir KV olmalıdır.
    /// - KV, ağaçta ilerlemek için kullanılan tutamaçların herhangi bir kopyasında `next_back_unchecked` tarafından daha önce döndürülmemişti.
    ///
    /// Güncellenen tanıtıcıyla devam etmenin tek güvenli yolu, onu karşılaştırmak, düşürmek, bu yöntemi güvenlik koşullarına bağlı olarak yeniden çağırmak veya güvenlik koşullarına tabi olarak muadili `next_back_unchecked` i çağırmaktır.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Yaprak edge tutamacını önceki yaprak edge'ye taşır ve aradaki anahtarı ve değeri döndürür, geride kalan herhangi bir düğümü kaldırırken, karşılık gelen edge'yi üst düğümünde sarkarken bırakır.
    ///
    /// # Safety
    /// - Gidilen yönde başka bir KV olmalıdır.
    /// - Bu yaprak edge, daha önce `next_unchecked` tarafından ağaçta ilerlemek için kullanılan tutamaçların herhangi bir kopyasında döndürülmedi.
    ///
    /// Güncellenen tanıtıcıyla ilerlemenin tek güvenli yolu, onu karşılaştırmak, düşürmek, bu yöntemi güvenlik koşullarına bağlı olarak yeniden çağırmak veya güvenlik koşullarına tabi olarak muadili `next_unchecked` i çağırmaktır.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Bir düğümün içinde veya altında en soldaki edge yaprağını, başka bir deyişle, ileri giderken (veya geriye doğru giderken son olarak) ihtiyacınız olan edge'yi döndürür.
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Bir düğümün içinde veya altında en sağdaki yaprak edge'yi, başka bir deyişle, ileri giderken (veya geriye doğru giderken ilk olarak) en son ihtiyacınız olan edge'yi döndürür.
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Artan anahtarlar sırasına göre yaprak düğümleri ve dahili KV'leri ziyaret eder ve ayrıca dahili düğümleri bir bütün olarak derinlemesine birinci sırada ziyaret eder; bu, dahili düğümlerin kendi KV'lerinden ve alt düğümlerinden önce geldiği anlamına gelir.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Bir (alt) ağaçtaki elemanların sayısını hesaplar.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// İleri navigasyon için KV'ye en yakın olan edge yaprağını döndürür.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Geriye doğru gezinme için KV'ye en yakın olan edge yaprağını döndürür.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}