use core::marker::PhantomData;
use core::ptr::NonNull;

/// Yeniden ödünç alma ve tüm soyundan gelenlerin (yani, ondan türetilen tüm işaretçiler ve referanslar) bir noktada artık kullanılmayacağını bildiğinizde, bazı benzersiz referansların yeniden ödünç alınmasını modeller, ardından orijinal benzersiz referansı tekrar kullanmak istediğinizde .
///
///
/// Ödünç alma denetleyicisi genellikle bu ödünç alma yığınlarını sizin için yönetir, ancak bu yığınlamayı gerçekleştiren bazı kontrol akışları, derleyicinin izleyemeyeceği kadar karmaşıktır.
/// Bir `DormantMutRef`, yığılmış yapısını ifade etmeye devam ederken kendinizi ödünç almayı kontrol etmenize ve bunu yapmak için gereken ham işaretçi kodunu tanımsız davranışlar olmadan kapsüllemenize olanak tanır.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Benzersiz bir ödünç alın ve hemen yeniden ödünç alın.
    /// Derleyici için, yeni referansın yaşam süresi orijinal referansın yaşam süresiyle aynıdır, ancak daha kısa bir süre kullanmak için promise kullanırsınız.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // GÜVENLİK: Ödünç alma işlemini 'a via `_marker` boyunca tutuyoruz ve
        // sadece bu referans, bu yüzden benzersizdir.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Başlangıçta alınan benzersiz ödünç almaya geri dönün.
    ///
    /// # Safety
    ///
    /// Yeniden ödünç verme sona ermiş olmalıdır, yani `new` tarafından döndürülen referans ve ondan türetilen tüm işaretçiler ve referanslar artık kullanılmamalıdır.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // GÜVENLİK: Kendi güvenlik koşullarımız, bu referansın yine benzersiz olduğunu ima etmektedir.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;