use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Yol boyunca bir `length` değişkenini artırarak, iki artan yineleyicinin birleşiminden tüm anahtar-değer çiftlerini ekler.İkincisi, bir damla işleyici paniklediğinde arayanın sızıntıyı önlemesini kolaylaştırır.
    ///
    /// Her iki yineleyici de aynı anahtarı üretirse, bu yöntem çifti sol yineleyiciden bırakır ve çifti sağ yineleyiciden ekler.
    ///
    /// Ağacın bir `BTreeMap` için olduğu gibi kesin olarak artan bir sırada bitmesini istiyorsanız, her iki yineleyici de, girişte ağaçta zaten bulunan anahtarlar da dahil olmak üzere, her biri ağaçtaki tüm anahtarlardan daha büyük olan anahtarları kesinlikle artan sırada üretmelidir.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // `left` ve `right` i doğrusal zamanda sıralanmış bir sırayla birleştirmeye hazırlanıyoruz.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Bu arada, doğrusal zamanda sıralanmış diziden bir ağaç inşa ediyoruz.
        self.bulk_push(iter, length)
    }

    /// Tüm anahtar/değer çiftlerini ağacın sonuna iter ve yol boyunca bir `length` değişkenini artırır.
    /// İkincisi, yineleyici paniklediğinde arayanın sızıntıyı önlemesini kolaylaştırır.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Tüm anahtar/değer çiftlerini yineleyin ve bunları doğru düzeydeki düğümlere itin.
        for (key, value) in iter {
            // Anahtar/değer çiftini geçerli yaprak düğüme göndermeyi deneyin.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Boşluk kalmadı, yukarı çıkın ve oraya itin.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Solda boşluk olan bir düğüm bul, buraya it.
                                open_node = parent;
                                break;
                            } else {
                                // Tekrar yukarı çıkın.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // En tepedeyiz, yeni bir kök düğüm oluşturup oraya itiyoruz.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Anahtar/değer çiftini ve yeni sağ alt ağacı itin.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Tekrar en sağdaki yaprağa inin.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Yineleyici panikler ilerletirken bile haritanın eklenen öğeleri bıraktığından emin olmak için her yinelemede uzunluğu artırın.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Sıralanmış iki diziyi tek bir dizide birleştirmek için bir yineleyici
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// İki anahtar eşitse, sağ kaynaktan anahtar/değer çiftini döndürür.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}