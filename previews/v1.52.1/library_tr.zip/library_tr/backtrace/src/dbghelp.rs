//! Windows te dbghelp bağlamalarını yönetmeye yardımcı olacak bir modül
//!
//! Windows teki geri izler (en azından MSVC için), büyük ölçüde `dbghelp.dll` ve içerdiği çeşitli işlevler aracılığıyla güçlendirilir.
//! Bu işlevler şu anda `dbghelp.dll` e statik olarak bağlanmak yerine *dinamik olarak* yüklenmektedir.
//! Bu şu anda standart kitaplık tarafından yapılmaktadır (ve teoride gereklidir), ancak geri izlemeler genellikle oldukça isteğe bağlı olduğundan, bir kitaplığın statik dll bağımlılıklarını azaltmaya yardımcı olma çabasıdır.
//!
//! Bununla birlikte, `dbghelp.dll` neredeyse her zaman Windows e başarıyla yüklenir.
//!
//! Tüm bu desteği dinamik olarak yüklediğimiz için `winapi` teki ham tanımları gerçekten kullanamayacağımızı, bunun yerine işlev işaretçi türlerini kendimiz tanımlamamız ve bunu kullanmamız gerektiğini unutmayın.
//! Gerçekten winapi'yi çoğaltma işinde olmak istemiyoruz, bu nedenle tüm bağlamaların winapi'dekilerle eşleştiğini ve bu özelliğin CI'da etkinleştirildiğini iddia eden bir Cargo özelliği `verify-winapi` e sahibiz.
//!
//! Son olarak, burada `dbghelp.dll` için dll'nin hiçbir zaman boşaltılmadığını ve bunun şu anda kasıtlı olduğunu göreceksiniz.
//! Buradaki düşünce, onu küresel olarak önbelleğe alabilir ve pahalı loads/unloads ten kaçınarak API çağrıları arasında kullanabiliriz.
//! Bu sızıntı dedektörleri için bir sorunsa veya buna benzer bir şeyse, oraya vardığımızda köprüyü geçebiliriz.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// `SymGetOptions` ve `SymSetOptions` in winapi'de bulunmadığından emin olun.
// Aksi takdirde, bu yalnızca türleri winapi'ye göre iki kez kontrol ettiğimizde kullanılır.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Henüz winapi'de tanımlanmadı
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Bu winapi'de tanımlanmıştır, ancak yanlıştır (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Henüz winapi'de tanımlanmadı
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Bu makro, yükleyebileceğimiz tüm işlev işaretçilerini dahili olarak içeren bir `Dbghelp` yapısını tanımlamak için kullanılır.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` için yüklenen DLL
            dll: HMODULE,

            // Kullanabileceğimiz her işlev için her işlev işaretçisi
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Başlangıçta DLL'yi yüklemedik
            dll: 0 as *mut _,
            // Başlangıçta tüm işlevler, dinamik olarak yüklenmeleri gerektiğini söylemek için sıfıra ayarlanmıştır.
            //
            $($name: 0,)*
        };

        // Her işlev türü için uygunluk typedef.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` i açmaya çalışır.
            /// Çalışırsa başarı döndürür veya `LoadLibraryW` başarısız olursa hata verir.
            ///
            /// Kitaplık zaten yüklüyse Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Kullanmak istediğimiz her yöntem için işlev.
            // Çağrıldığında, ya önbelleğe alınmış işlev işaretçisini okur ya da yükler ve yüklenen değeri döndürür.
            // Yüklerin başarılı olduğu iddia edilir.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp işlevlerine başvurmak için temizleme kilitlerini kullanmak için uygun proxy.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Bu crate'den `dbghelp` API işlevlerine erişmek için gerekli tüm desteği başlatın.
///
///
/// Bu işlevin **güvenli** olduğunu ve dahili olarak kendi senkronizasyonuna sahip olduğunu unutmayın.
/// Ayrıca, bu işlevi yinelemeli olarak birden çok kez çağırmanın güvenli olduğunu unutmayın.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Yapmamız gereken ilk şey, bu işlevi senkronize etmek.Bu, diğer evrelerden eşzamanlı olarak veya bir iş parçacığı içinde özyinelemeli olarak çağrılabilir.
        // Bundan daha zor olduğunu unutmayın çünkü burada kullandığımız `dbghelp`*ayrıca* bu süreçte diğer tüm arayanlarla `dbghelp` e senkronize edilmelidir.
        //
        // Tipik olarak, aynı süreç içinde `dbghelp` e yapılan çok fazla çağrı yoktur ve muhtemelen ona erişenlerin yalnızca biz olduğumuzu güvenle varsayabiliriz.
        // Bununla birlikte, ironik olarak kendimiz olan, ancak standart kitaplıkta olan hakkında endişelenmemiz gereken bir birincil kullanıcı daha var.
        // Rust standart kitaplığı, geri izleme desteği için bu crate'ye bağlıdır ve bu crate, crates.io te de mevcuttur.
        // Bu, standart kitaplık bir panic geri izini yazdırıyorsa, crates.io ten gelen bu crate ile yarışarak segment hatalarına neden olabileceği anlamına gelir.
        //
        // Bu senkronizasyon sorununu çözmeye yardımcı olmak için burada Windows'a özgü bir numara kullanıyoruz (sonuçta bu, senkronizasyonla ilgili Windows'a özgü bir kısıtlamadır).
        // Bu çağrıyı korumak için mutex adında bir *oturum-yerel* oluşturuyoruz.
        // Buradaki amaç, standart kitaplığın ve bu crate'nin burada senkronize etmek için Rust düzeyindeki API'leri paylaşmak zorunda olmaması, bunun yerine birbirleriyle senkronize olduklarından emin olmak için arka planda çalışabilmeleridir.
        //
        // Bu şekilde, bu işlev standart kitaplık veya crates.io aracılığıyla çağrıldığında, aynı muteksin elde edildiğinden emin olabiliriz.
        //
        // Tüm bunlar, burada yaptığımız ilk şeyin atomik olarak Windows üzerinde adlandırılmış bir muteks olan bir `HANDLE` yaratmak olduğunu söylemektir.
        // Bu işlevi özel olarak paylaşan diğer iş parçacıklarıyla biraz senkronize ediyoruz ve bu işlevin her bir örneği için yalnızca bir tutamaç oluşturulmasını sağlıyoruz.
        // Global olarak depolandıktan sonra tutamacın asla kapatılmayacağını unutmayın.
        //
        // Kilidi gerçekten açtıktan sonra, onu basitçe ediniriz ve dağıttığımız `Init` tutamacımız sonunda onu düşürmekten sorumlu olur.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Tamam, vay be!Artık hepimiz güvenli bir şekilde senkronize edildiğimize göre, aslında her şeyi işlemeye başlayalım.
        // Öncelikle, `dbghelp.dll` in bu süreçte gerçekten yüklendiğinden emin olmalıyız.
        // Statik bir bağımlılıktan kaçınmak için bunu dinamik olarak yapıyoruz.
        // Bu, tarihsel olarak garip bağlantı sorunlarının üstesinden gelmek için yapılmıştır ve ikili dosyaları biraz daha taşınabilir hale getirmeyi amaçlamaktadır, çünkü bu büyük ölçüde sadece bir hata ayıklama aracıdır.
        //
        //
        // `dbghelp.dll` i açtıktan sonra, içinde bazı başlatma işlevlerini çağırmamız gerekiyor ve bu, aşağıda daha ayrıntılı.
        // Yine de bunu yalnızca bir kez yapıyoruz, bu yüzden henüz bitip bitmediğimizi gösteren global bir mantıksal değerimiz var.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` bayrağının ayarlandığından emin olun, çünkü MSVC'nin bu konudaki kendi belgelerine göre: "This is the fastest, most efficient way to use the symbol handler.", hadi bunu yapalım!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Sembolleri MSVC ile gerçekten başlatın.Bunun başarısız olabileceğini unutmayın, ancak bunu görmezden geliyoruz.
        // Bunun için bir ton önceki teknik yok, ancak LLVM buradaki dönüş değerini dahili olarak görmezden geliyor gibi görünüyor ve LLVM'deki dezenfektan kitaplıklarından biri bu başarısız olursa korkutucu bir uyarı yazdırıyor, ancak temelde uzun vadede onu görmezden geliyor.
        //
        //
        // Bunun Rust için çokça ortaya çıktığı bir durum, standart kitaplığın ve crates.io üzerindeki bu crate'nin her ikisinin de `SymInitializeW` için rekabet etmek istemesidir.
        // Standart kütüphane tarihsel olarak çoğu zaman başlatmak ve sonra temizlemek istiyordu, ancak şimdi bu crate'yi kullandığına göre bu, birinin önce başlatmaya gideceği ve diğerinin bu başlatmayı alacağı anlamına geliyor.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}