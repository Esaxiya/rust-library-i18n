use core::ffi::c_void;
use core::fmt;

/// Yığın izini hesaplamak için tüm etkin çerçeveleri sağlanan kapanışa geçirerek mevcut çağrı yığınını inceler.
///
/// Bu işlev, bu kitaplığın bir program için yığın izlerini hesaplamadaki en önemli işlevidir.Verilen kapanış `cb`, yığındaki bu çağrı çerçevesi hakkında bilgiyi temsil eden bir `Frame` in örneklerini verir.
/// Kapanış, yukarıdan aşağıya çerçeveler (en son olarak ilk olarak işlevler olarak adlandırılır) verir.
///
/// Kapanışın dönüş değeri, geri izlemenin devam edip etmeyeceğinin bir göstergesidir.`false` in dönüş değeri geri izlemeyi sonlandıracak ve hemen geri dönecektir.
///
/// Bir `Frame` alındıktan sonra, `ip` i (talimat işaretçisi) veya sembol adresini ad ve/veya dosya adı/satır numarasının öğrenilebileceği bir `Symbol` e dönüştürmek için `backtrace::resolve` i aramak isteyeceksiniz.
///
///
/// Bunun nispeten düşük seviyeli bir işlev olduğunu unutmayın ve örneğin, daha sonra incelenmek üzere bir geri izleme yakalamak isterseniz, `Backtrace` türü daha uygun olabilir.
///
/// # Gerekli özellikler
///
/// Bu işlev, `backtrace` crate'nin `std` özelliğinin etkinleştirilmesini gerektirir ve `std` özelliği varsayılan olarak etkinleştirilir.
///
/// # Panics
///
/// Bu işlev asla panic'yi sağlamamaya çalışır, ancak `cb` panics sağladıysa, bazı platformlar işlemi iptal etmek için çift panic'yi zorlayacaktır.
/// Bazı platformlar, içinden çözülemeyen geri aramaları dahili olarak kullanan bir C kitaplığı kullanır, bu nedenle `cb` ten gelen panik, işlemin durdurulmasını tetikleyebilir.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // geri izlemeye devam et
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` ile aynı, yalnızca senkronize olmadığı için güvensiz.
///
/// Bu işlevin senkronizasyon garantileri yoktur, ancak bu crate'nin `std` özelliği derlenmediğinde kullanılabilir.
/// Daha fazla belge ve örnek için `trace` işlevine bakın.
///
/// # Panics
///
/// `cb` paniklemesiyle ilgili uyarılar için `trace` ile ilgili bilgilere bakın.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Bir geri izlemenin bir çerçevesini temsil eden bir trait, bu crate'nin `trace` fonksiyonunu verdi.
///
/// İzleme işlevinin kapanışına çerçeveler verilecektir ve temel uygulama çalışma zamanına kadar her zaman bilinmediğinden çerçeve sanal olarak gönderilir.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Bu çerçevenin geçerli yönerge işaretçisini döndürür.
    ///
    /// Bu normalde çerçevede yürütülecek bir sonraki talimattır, ancak tüm uygulamalar bunu% 100 doğrulukla listelemez (ancak genellikle oldukça yakındır).
    ///
    ///
    /// Bu değeri bir sembol adına dönüştürmek için `backtrace::resolve` e geçmeniz önerilir.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Bu çerçevenin geçerli yığın işaretçisini döndürür.
    ///
    /// Bir arka ucun bu çerçeve için yığın işaretçisini kurtaramaması durumunda, boş bir işaretçi döndürülür.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Bu işlevin çerçevesinin başlangıç sembolü adresini döndürür.
    ///
    /// Bu, `ip` tarafından döndürülen yönerge işaretçisini işlevin başlangıcına geri sararak bu değeri döndürmeye çalışacaktır.
    ///
    /// Ancak bazı durumlarda, arka uçlar `ip` i bu işlevden döndürür.
    ///
    /// Döndürülen değer bazen `backtrace::resolve` yukarıda verilen `ip` te başarısız olursa kullanılabilir.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Çerçevenin ait olduğu modülün temel adresini döndürür.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Miri'nin ana platform üzerinde önceliğe sahip olmasını sağlamak için bu önce gelmelidir
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // sadece dbghelp sembolünde kullanılır
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}