#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Geri izlemeler için bir formatlayıcı.
///
/// Bu tür, geri izlemenin nereden geldiğine bakılmaksızın bir geri izleme yazdırmak için kullanılabilir.
/// Bir `Backtrace` türünüz varsa, `Debug` uygulaması zaten bu yazdırma biçimini kullanır.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Basabileceğimiz baskı stilleri
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// İdeal olarak yalnızca ilgili bilgileri içeren daha ayrıntılı bir geri izleme yazdırır
    Short,
    /// Olası tüm bilgileri içeren bir geri izleme yazdırır
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Çıktıyı sağlanan `fmt` e yazacak yeni bir `BacktraceFmt` oluşturun.
    ///
    /// `format` bağımsız değişkeni, geri izlemenin yazdırıldığı stili kontrol edecek ve `print_path` bağımsız değişkeni, dosya adlarının `BytesOrWideString` örneklerini yazdırmak için kullanılacaktır.
    /// Bu türün kendisi herhangi bir dosya adı yazdırmaz, ancak bunu yapmak için bu geri çağırma gereklidir.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Yazdırılacak geri izleme için bir başlangıç eki yazdırır.
    ///
    /// Bu, bazı platformlarda geri izlemelerin daha sonra tamamen sembolize edilmesi için gereklidir ve aksi takdirde bu, bir `BacktraceFmt` oluşturduktan sonra aradığınız ilk yöntem olmalıdır.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Geri izleme çıktısına bir çerçeve ekler.
    ///
    /// Bu kayıt, bir çerçeveyi gerçekten yazdırmak için kullanılabilen bir `BacktraceFrameFmt` in RAII örneğini döndürür ve yok edildiğinde çerçeve sayacını artırır.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Geri izleme çıktısını tamamlar.
    ///
    /// Bu şu anda işlemsizdir ancak geri izleme biçimleriyle future uyumluluğu için eklenmiştir.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Şu anda bir işlem yok-future eklemelerine izin vermek için bu hook dahil.
        Ok(())
    }
}

/// Bir geri izlemenin yalnızca bir çerçevesi için biçimlendirici.
///
/// Bu tür, `BacktraceFmt::frame` işlevi tarafından oluşturulur.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Bu çerçeve biçimlendiriciyle bir `BacktraceFrame` yazdırır.
    ///
    /// Bu, `BacktraceFrame` içindeki tüm `BacktraceSymbol` örneklerini yinelemeli olarak yazdıracaktır.
    ///
    /// # Gerekli özellikler
    ///
    /// Bu işlev, `backtrace` crate'nin `std` özelliğinin etkinleştirilmesini gerektirir ve `std` özelliği varsayılan olarak etkinleştirilir.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceFrame` içinde bir `BacktraceSymbol` yazdırır.
    ///
    /// # Gerekli özellikler
    ///
    /// Bu işlev, `backtrace` crate'nin `std` özelliğinin etkinleştirilmesini gerektirir ve `std` özelliği varsayılan olarak etkinleştirilir.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: bu harika değil, sonunda hiçbir şey basmıyor
            // utf8 olmayan dosya adlarıyla.
            // Neyse ki neredeyse her şey utf8, bu yüzden bu çok da kötü olmamalı.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Genellikle bu crate'nin ham geri aramaları içinden ham izlenen bir `Frame` ve `Symbol` yazdırır.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Geri izleme çıktısına bir ham çerçeve ekler.
    ///
    /// Bu yöntem, öncekinden farklı olarak, farklı konumlardan kaynak olmaları durumunda ham argümanları alır.
    /// Bunun bir kare için birden çok kez çağrılabileceğini unutmayın.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Geri izleme çıktısına, sütun bilgileri dahil olmak üzere bir ham çerçeve ekler.
    ///
    /// Bu yöntem, önceki gibi, farklı konumlardan kaynak olmaları durumunda ham argümanları alır.
    /// Bunun bir kare için birden çok kez çağrılabileceğini unutmayın.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuşya, bir süreç içinde sembolize edemez, bu nedenle daha sonra sembolize etmek için kullanılabilecek özel bir formatı vardır.
        // Kendi formatımızdaki adresleri burada yazdırmak yerine bunu yazdırın.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" karelerini yazdırmaya gerek yok, temelde bu sadece sistemin geriye dönük izlemesinin çok uzaklara kadar geriye gitmek için biraz istekli olduğu anlamına geliyor.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx enklavındaki TCB boyutunu azaltmak için, sembol çözünürlüğü işlevini uygulamak istemiyoruz.
        // Bunun yerine, adresin ofsetini buradan yazdırabiliriz, bu daha sonra doğru işlevi için haritalanabilir.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Çerçevenin indeksini ve çerçevenin isteğe bağlı talimat göstergesini yazdırın.
        // Bu çerçevenin ilk sembolünün ötesine geçersek, sadece uygun beyaz boşlukları yazdırırız.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Ardından, tam bir geri izleme isek, daha fazla bilgi için alternatif biçimlendirmeyi kullanarak sembol adını yazın.
        // Burada bir adı olmayan sembolleri de ele alıyoruz.
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Ve son olarak, varsa filename/line numarasını yazdırın.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line sembol adının altındaki satırlara yazdırılır, bu nedenle kendimizi sağa hizalamak için uygun bir boşluk yazdırın.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Dosya adını yazdırmak için dahili geri aramamıza yetki verin ve ardından satır numarasını yazdırın.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Varsa sütun numarası ekleyin.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Bir çerçevenin sadece ilk sembolünü önemsiyoruz
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}