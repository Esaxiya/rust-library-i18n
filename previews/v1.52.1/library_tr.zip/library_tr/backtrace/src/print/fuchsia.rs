use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr, sürece bağlanan her DSO için bir dl_phdr_info işaretçisi alacak bir geri arama alır.
    // dl_iterate_phdr ayrıca dinamik bağlayıcının yinelemenin başından sonuna kadar kilitlenmesini sağlar.
    // Geri arama, sıfır olmayan bir değer döndürürse, yineleme erken sonlandırılır.
    // 'data' her çağrıda geri aramaya üçüncü argüman olarak aktarılacaktır.
    // 'size' dl_phdr_info'nun boyutunu verir.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Yapı kimliğini ve bazı temel program başlık verilerini ayrıştırmamız gerekiyor, bu da ELF spesifikasyonundan biraz şeylere ihtiyacımız olduğu anlamına geliyor.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Şimdi fuchsia'nın şu anki dinamik bağlayıcısı tarafından kullanılan dl_phdr_info tipinin yapısını biraz kopyalamalıyız.
// Chromium ayrıca bu ABI sınırına ve crashpad'e sahiptir.
// Sonunda, bu vakaları elf arama kullanacak şekilde taşımak istiyoruz, ancak bunu SDK'da sağlamamız gerekiyor ve bu henüz yapılmadı.
//
// Bu nedenle biz (ve onlar) fuşya libc ile sıkı bir bağ kuran bu yöntemi kullanmak zorunda kaldık.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // E_phoff ve e_phnum'un geçerli olup olmadığını kontrol etmenin hiçbir yolu yok.
    // libc bunu bizim için sağlamalıdır, böylece burada bir dilim oluşturmak güvenli olur.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr, hedef mimarinin sonluluğundaki 64 bitlik bir ELF program başlığını temsil eder.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr, geçerli bir ELF program başlığını ve içeriğini temsil eder.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // P_addr veya p_memsz'in geçerli olup olmadığını kontrol etmenin bir yolu yok.
    // Fuchsia'nın libc'si önce notları ayrıştırır, ancak bu nedenle burada oldukları için bu başlıklar geçerli olmalıdır.
    //
    // NoteIter, temel alınan verilerin geçerli olmasını gerektirmez, ancak sınırların geçerli olmasını gerektirir.
    // Libc'nin burada bizim için durumun böyle olmasını sağladığına inanıyoruz.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Yapı kimlikleri için not türü.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr, hedefin sonluluğundaki bir ELF not başlığını temsil eder.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Not bir ELF notunu (başlık + içerik) temsil eder.
// İsim bir u8 dilimi olarak bırakılır çünkü her zaman boş olarak sonlandırılmaz ve rust baytların her iki şekilde de eşleşip eşleşmediğini kontrol etmeyi yeterince kolaylaştırır.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter, bir not segmentini güvenle yinelemenize izin verir.
// Bir hata meydana gelir gelmez veya başka not kalmadığında sona erer.
// Geçersiz verileri yinelerseniz, hiçbir not bulunmamış gibi işlev görür.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Verilen işaretçi ve boyutun tümü okunabilen geçerli bir bayt aralığını ifade etmesi, işlevin değişmezidir.
    // Bu baytların içeriği herhangi bir şey olabilir, ancak bunun güvenli olması için aralığın geçerli olması gerekir.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to, 'x' i 'bayta' hizalamaya hizalar; 'to' in 2'nin gücü olduğunu varsayar.
// Bu, (x + to, 1)&-to in kullanıldığı C/C ++ ELF ayrıştırma kodundaki standart bir kalıbı takip eder.
// Rust kullanımı olumsuzlamanıza izin vermiyor, bu yüzden kullanıyorum
// Bunu yeniden oluşturmak için 2'nin tamamlayıcı dönüşümü.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4, dilimden (varsa) sayı bayt tüketir ve ek olarak son dilimin düzgün bir şekilde hizalanmasını sağlar.
// İstenen bayt sayısı çok büyükse veya yeterli bayt kalmadığı için dilim daha sonra yeniden hizalanamazsa, Hiçbiri döndürülür ve dilim değiştirilmez.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Bu işlevin, belki de performans için 'bytes' in (ve bazı mimarilerin doğruluğu) hizalanması dışında, arayanın desteklemesi gereken gerçek değişmezler yoktur.
// Elf_Nhdr alanlarındaki değerler saçma olabilir, ancak bu işlev böyle bir şey sağlamaz.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Yeterli alan olduğu sürece bu güvenlidir ve biz sadece yukarıdaki if ifadesinde bunun güvensiz olmaması gerektiğini teyit ettik.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Sice_of: :<Elf_Nhdr>() her zaman 4 bayt hizalıdır.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Sona ulaşıp ulaşmadığımızı kontrol edin.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Bir nhdr'yi dönüştürüyoruz, ancak ortaya çıkan yapıyı dikkatlice ele alıyoruz.
        // Namesz veya descsz'e güvenmiyoruz ve türe göre güvenli olmayan kararlar vermiyoruz.
        //
        // Yani tam bir çöplükten çıksak bile yine de güvende olmalıyız.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Bir segmentin yürütülebilir olduğunu gösterir.
const PERM_X: u32 = 0b00000001;
/// Bir segmentin yazılabilir olduğunu gösterir.
const PERM_W: u32 = 0b00000010;
/// Bir segmentin okunabilir olduğunu gösterir.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Çalışma zamanında bir ELF segmentini temsil eder.
struct Segment {
    /// Bu segmentin içeriğinin çalışma zamanı sanal adresini verir.
    addr: usize,
    /// Bu segmentin içeriğinin hafıza boyutunu verir.
    size: usize,
    /// ELF dosyası ile bu segmentin modül sanal adresini verir.
    mod_rel_addr: usize,
    /// ELF dosyasında bulunan izinleri verir.
    /// Ancak bu izinler, çalışma zamanında mevcut olan izinler olmayabilir.
    flags: Perm,
}

/// Bir DSO'daki Segmentler üzerinde bir yineleme sağlar.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Bir ELF DSO'yu (Dinamik Paylaşılan Nesne) temsil eder.
/// Bu tür, kendi kopyasını oluşturmak yerine gerçek DSO'da depolanan verilere başvurur.
struct Dso<'a> {
    /// Dinamik bağlayıcı, isim boş olsa bile bize her zaman bir isim verir.
    /// Ana yürütülebilir dosya durumunda bu ad boş olacaktır.
    /// Paylaşılan bir nesne olması durumunda, bu soname olacaktır (bkz. DT_SONAME).
    name: &'a str,
    /// Fuchsia'da neredeyse tüm ikili dosyalar oluşturulmuş kimliklere sahiptir, ancak bu katı bir gereklilik değildir.
    /// Build_id yoksa DSO bilgilerini daha sonra gerçek bir ELF dosyasıyla eşleştirmenin bir yolu yoktur, bu nedenle her DSO'nun burada bir tane olmasını isteriz.
    ///
    /// Build_id içermeyen DSO'lar göz ardı edilir.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Bu DSO'daki Segmentler üzerinde bir yineleyici döndürür.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Bu hatalar, her bir DSO hakkındaki bilgileri ayrıştırırken ortaya çıkan sorunları kodlar.
///
enum Error {
    /// NameError, bir C stil dizesini rust dizesine dönüştürürken bir hata oluştuğu anlamına gelir.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError, bir yapı kimliği bulamadığımız anlamına gelir.
    /// Bunun nedeni, DSO'nun yapı kimliğine sahip olmaması veya yapı kimliğini içeren segmentin hatalı biçimlendirilmiş olması olabilir.
    ///
    BuildIDError,
}

/// Dinamik bağlayıcı tarafından sürece bağlanan her DSO için 'dso' veya 'error' i çağırır.
///
///
/// # Arguments
///
/// * `visitor` - Foreach DSO adı verilen yeme yöntemlerinden birine sahip olacak bir DsoPrinter.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr, info.name in geçerli bir konumu göstermesini sağlar.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Bu işlev, bir DSO'da bulunan tüm bilgiler için Fuchsia simgesel işaretlemesini yazdırır.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}