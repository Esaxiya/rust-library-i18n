use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Bir adresi bir sembole çözümleyin, sembolü belirtilen kapanışa iletin.
///
/// Bu fonksiyon, verilecek sembolleri bulmak için yerel sembol tablosu, dinamik sembol tablosu veya DWARF hata ayıklama bilgisi (etkinleştirilen uygulamaya bağlı olarak) gibi alanlarda verilen adresi arayacaktır.
///
///
/// Çözüm gerçekleştirilemezse kapatma çağrılmayabilir ve ayrıca satır içi işlevler söz konusu olduğunda birden fazla çağrılabilir.
///
/// Verilen semboller, belirtilen `addr` teki yürütmeyi temsil eder ve bu adres için file/line çiftlerini döndürür (varsa).
///
/// Bir `Frame` iniz varsa, bunun yerine `resolve_frame` işlevini kullanmanız önerilir.
///
/// # Gerekli özellikler
///
/// Bu işlev, `backtrace` crate'nin `std` özelliğinin etkinleştirilmesini gerektirir ve `std` özelliği varsayılan olarak etkinleştirilir.
///
/// # Panics
///
/// Bu işlev asla panic'yi sağlamamaya çalışır, ancak `cb` panics sağladıysa, bazı platformlar işlemi iptal etmek için çift panic'yi zorlayacaktır.
/// Bazı platformlar, içinden çözülemeyen geri aramaları dahili olarak kullanan bir C kitaplığı kullanır, bu nedenle `cb` ten gelen panik, işlemin durdurulmasını tetikleyebilir.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // sadece üst çerçeveye bak
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Önceden yakalanan bir kareyi bir sembole çözümleyin, sembolü belirtilen kapanışa iletin.
///
/// Bu işlev, bir adres yerine bağımsız değişken olarak bir `Frame` alması dışında `resolve` ile aynı işlevi gerçekleştirir.
/// Bu, örneğin, geri izleme platform uygulamalarının daha doğru sembol bilgisi veya satır içi çerçeveler hakkında bilgi sağlamasına izin verebilir.
///
/// Mümkünse bunu kullanmanız önerilir.
///
/// # Gerekli özellikler
///
/// Bu işlev, `backtrace` crate'nin `std` özelliğinin etkinleştirilmesini gerektirir ve `std` özelliği varsayılan olarak etkinleştirilir.
///
/// # Panics
///
/// Bu işlev asla panic'yi sağlamamaya çalışır, ancak `cb` panics sağladıysa, bazı platformlar işlemi iptal etmek için çift panic'yi zorlayacaktır.
/// Bazı platformlar, içinden çözülemeyen geri aramaları dahili olarak kullanan bir C kitaplığı kullanır, bu nedenle `cb` ten gelen panik, işlemin durdurulmasını tetikleyebilir.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // sadece üst çerçeveye bak
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Yığın çerçevelerinden gelen IP değerleri tipik olarak (always?), gerçek yığın izleme olan çağrıdan *sonra* talimattır.
// Bunu sembolize etmek, filename/line numarasının bir önde olmasına ve işlevin sonuna yakınsa belki boşluğa girmesine neden olur.
//
// Bu, temelde tüm platformlarda her zaman geçerli gibi görünmektedir, bu nedenle, onu geri döndürülen talimat yerine önceki çağrı talimatına çözmek için çözülmüş bir ipten her zaman bir tane çıkarırız.
//
//
// İdeal olarak bunu yapmayız.
// İdeal olarak, `resolve` API'lerini arayanlardan -1 i manuel olarak yapmalarını ve mevcut değil *önceki* talimat için konum bilgilerini istediklerini hesaba katmalarını isteriz.
// İdeal olarak, eğer gerçekten bir sonraki talimatın veya mevcut talimatın adresi isek, `Frame` i de açığa çıkarırız.
//
// Şimdilik bu oldukça niş bir endişe olmasına rağmen, biz sadece dahili olarak her zaman birini çıkarıyoruz.
// Tüketiciler çalışmaya ve oldukça iyi sonuçlar almaya devam etmeli, bu yüzden yeterince iyi olmalıyız.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` ile aynı, yalnızca senkronize olmadığı için güvensiz.
///
/// Bu işlevin senkronizasyon garantileri yoktur, ancak bu crate'nin `std` özelliği derlenmediğinde kullanılabilir.
/// Daha fazla belge ve örnek için `resolve` işlevine bakın.
///
/// # Panics
///
/// `cb` paniklemesiyle ilgili uyarılar için `resolve` ile ilgili bilgilere bakın.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` ile aynı, yalnızca senkronize olmadığı için güvensiz.
///
/// Bu işlevin senkronizasyon garantileri yoktur, ancak bu crate'nin `std` özelliği derlenmediğinde kullanılabilir.
/// Daha fazla belge ve örnek için `resolve_frame` işlevine bakın.
///
/// # Panics
///
/// `cb` paniklemesiyle ilgili uyarılar için `resolve_frame` ile ilgili bilgilere bakın.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Bir dosyadaki bir sembolün çözünürlüğünü temsil eden bir trait.
///
/// Bu trait, `backtrace::resolve` işlevine verilen kapanışa bir trait nesnesi olarak verilir ve arkasında hangi uygulamanın olduğu bilinmediği için sanal olarak gönderilir.
///
///
/// Bir sembol, bir işlev hakkında bağlamsal bilgi verebilir, örneğin ad, dosya adı, satır numarası, tam adres vb.
/// Bununla birlikte, tüm bilgiler her zaman bir sembolde mevcut değildir, bu nedenle tüm yöntemler bir `Option` döndürür.
///
///
pub struct Symbol {
    // TODO: bu ömür boyu sınırın eninde sonunda `Symbol` e kadar sürdürülmesi gerekir,
    // ancak bu şu anda önemli bir değişiklik.
    // Şimdilik bu güvenli, çünkü `Symbol` yalnızca referans olarak verildi ve klonlanamaz.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Bu işlevin adını döndürür.
    ///
    /// Döndürülen yapı, sembol adıyla ilgili çeşitli özellikleri sorgulamak için kullanılabilir:
    ///
    ///
    /// * `Display` uygulaması, çözülmüş sembolü yazdıracaktır.
    /// * Sembolün ham `str` değerine erişilebilir (geçerli utf-8 ise).
    /// * Sembol adı için ham baytlara erişilebilir.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Bu işlevin başlangıç adresini verir.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Ham dosya adını bir dilim olarak döndürür.
    /// Bu, esas olarak `no_std` ortamları için kullanışlıdır.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Bu sembolün o anda yürütüldüğü yerin sütun numarasını döndürür.
    ///
    /// Yalnızca gimli şu anda burada bir değer sağlar ve o zaman bile yalnızca `filename` `Some` i döndürürse ve bu nedenle sonuç olarak benzer uyarılara tabidir.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Bu sembolün o anda çalışmakta olduğu yerin satır numarasını döndürür.
    ///
    /// `filename`, `Some` döndürürse bu dönüş değeri tipik olarak `Some` tir ve sonuç olarak benzer uyarılara tabidir.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Bu işlevin tanımlandığı dosya adını döndürür.
    ///
    /// Bu, şu anda yalnızca libbacktrace veya gimli kullanıldığında kullanılabilir (örn.
    /// unix platformlar diğer) ve bir ikili dosya debuginfo ile derlendiğinde.
    /// Bu koşullardan hiçbiri karşılanmazsa, bu muhtemelen `None` i döndürecektir.
    ///
    /// # Gerekli özellikler
    ///
    /// Bu işlev, `backtrace` crate'nin `std` özelliğinin etkinleştirilmesini gerektirir ve `std` özelliği varsayılan olarak etkinleştirilir.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Rust olarak karıştırılmış sembol ayrıştırılamazsa, belki bir ayrıştırılmış C++ sembolü.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Bu sıfır boyutunu tuttuğunuzdan emin olun, böylece `cpp_demangle` özelliği devre dışı bırakıldığında hiçbir maliyeti olmaz.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Demangled isme, ham baytlara, ham dizeye vb. Ergonomik erişim sağlayanlar sağlamak için bir sembol adının etrafına bir sarmalayıcı.
///
// `cpp_demangle` özelliği etkinleştirilmediğinde ölü koda izin verin.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Temel alınan ham baytlardan yeni bir sembol adı oluşturur.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Sembol geçerli utf-8 ise, ham (mangled) sembol adını `str` olarak döndürür.
    ///
    /// Demanged versiyonunu istiyorsanız `Display` uygulamasını kullanın.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Ham sembol adını bayt listesi olarak verir
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Bu, ayrılan sembol gerçekten geçerli değilse yazdırabilir, bu nedenle buradaki hatayı dışarı doğru yaymayarak incelikle halledin.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Adresleri sembolize etmek için kullanılan önbelleğe alınmış hafızayı geri almaya çalışın.
///
/// Bu yöntem, aksi takdirde genel olarak önbelleğe alınmış veya tipik olarak ayrıştırılmış DWARF bilgilerini veya benzerini temsil eden iş parçacığında önbelleğe alınmış herhangi bir küresel veri yapısını serbest bırakmaya çalışacaktır.
///
///
/// # Caveats
///
/// Bu işlev her zaman kullanılabilir olsa da, çoğu uygulamada aslında hiçbir şey yapmaz.
/// Dbghelp veya libbacktrace gibi kitaplıklar, durumu serbest bırakmak ve ayrılan belleği yönetmek için olanaklar sağlamaz.
/// Şimdilik bu crate'nin `gimli-symbolize` özelliği, bu işlevin herhangi bir etkisinin olduğu tek özelliktir.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}