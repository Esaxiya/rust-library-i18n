//! Libbacktrace'de DWARF ayrıştırma kodunu kullanan sembolikasyon stratejisi.
//!
//! Tipik olarak gcc ile dağıtılan libbacktrace C kitaplığı, yalnızca bir geri izleme oluşturmayı (aslında kullanmıyoruz) değil, aynı zamanda geri izlemeyi sembolize etmeyi ve satır içi çerçeveler ve diğer şeyler gibi cüce hata ayıklama bilgilerinin işlenmesini de destekler.
//!
//!
//! Bu, buradaki birçok farklı endişeden dolayı nispeten karmaşıktır, ancak temel fikir şudur:
//!
//! * İlk önce `backtrace_syminfo` i arıyoruz.Bu, eğer yapabilirsek dinamik sembol tablosundan sembol bilgilerini alır.
//! * Daha sonra `backtrace_pcinfo` diyoruz.Bu, varsa hata ayıklama bilgi tablolarını ayrıştırır ve satır içi çerçeveler, dosya adları, satır numaraları vb. Hakkında bilgileri kurtarmamıza izin verir.
//!
//! Cüce tablolarını libbacktrace'e sokmakla ilgili pek çok hile var, ancak umarım dünyanın sonu değildir ve aşağıda okurken yeterince açıktır.
//!
//! Bu, MSVC olmayan ve OSX olmayan platformlar için varsayılan sembolikasyon stratejisidir.Libstd'de bu OSX için varsayılan stratejidir.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Mümkünse, hata ayıklama bilgisinden gelen ve genellikle örneğin satır içi çerçeveler için daha doğru olabilen `function` adını tercih edin.
                // Bu mevcut değilse, `symname` te belirtilen sembol tablosu adına geri dönün.
                //
                // Bazen `function` in, örneğin `std::panicking::try::do_call` in `try<i32,closure>` isntead'i olarak listelendiğinde, biraz daha az doğru hissedebileceğini unutmayın.
                //
                // Neden olduğu tam olarak belli değil, ancak genel olarak `function` adı daha doğru görünüyor.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // şimdilik hiçbir şey yapma
}

/// `syminfo_cb` e geçirilen `data` işaretçisinin türü
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Çözümlemeye başladığımızda bu geri arama `backtrace_syminfo` ten çağrıldığında, `backtrace_pcinfo` i çağırmak için daha ileri gidiyoruz.
    // `backtrace_pcinfo` işlevi, hata ayıklama bilgilerine başvurur ve satır içi çerçevelerin yanı sıra file/line bilgilerini kurtarmak gibi şeyler yapmaya çalışır.
    // Hata ayıklama bilgisi yoksa `backtrace_pcinfo` in başarısız olabileceğini veya fazla bir şey yapamayacağını unutmayın; bu durumda, geri aramayı `syminfo_cb` ten en az bir sembolle çağıracağımızdan emin olabilirsiniz.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `pcinfo_cb` e geçirilen `data` işaretçisinin türü
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API bir durum oluşturmayı destekler, ancak bir durumun yok edilmesini desteklemez.
// Şahsen bunu, bir devletin yaratılması ve ardından sonsuza dek yaşanması gerektiği anlamına geliyor.
//
// Bu durumu temizleyen bir at_exit() işleyicisi kaydettirmeyi çok isterdim, ancak libbacktrace bunu yapmanın bir yolunu sunmuyor.
//
// Bu kısıtlamalarla, bu işlev, ilk talep edildiğinde hesaplanan statik olarak önbelleğe alınmış bir duruma sahiptir.
//
// Geri izlemenin tümünün seri olarak gerçekleştiğini unutmayın (tek bir global kilit).
//
// Buradaki senkronizasyon eksikliğinin `resolve` in harici olarak senkronize edilmesi gerekliliğinden kaynaklandığını unutmayın.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Her zaman senkronize bir şekilde çağırdığımız için libbacktrace'in iş parçacığı güvenli yeteneklerini kullanmayın.
        //
        0,
        error_cb,
        ptr::null_mut(), // ekstra veri yok
    );

    return STATE;

    // Libbacktrace'in çalışabilmesi için geçerli çalıştırılabilir dosyanın DWARF hata ayıklama bilgisini bulması gerektiğini unutmayın.Bunu genellikle aşağıdakileri içeren ancak bunlarla sınırlı olmayan bir dizi mekanizma aracılığıyla yapar:
    //
    // * /proc/self/exe desteklenen platformlarda
    // * Durum oluştururken dosya adı açıkça aktarıldı
    //
    // Libbacktrace kitaplığı büyük bir C kodudur.Bu, doğal olarak, özellikle hatalı biçimlendirilmiş hata ayıklama bilgilerini işlerken bellek güvenliği açıklarına sahip olduğu anlamına gelir.
    // Libstd, tarihsel olarak bunlardan bolca karşılaştı.
    //
    // /proc/self/exe kullanılırsa, libbacktrace'in "mostly correct" olduğunu ve aksi takdirde "attempted to be correct" cüce hata ayıklama bilgisiyle garip şeyler yapmadığını varsaydığımız için bunları genellikle göz ardı edebiliriz.
    //
    //
    // Bununla birlikte, bir dosya adı iletirsek, kötü niyetli bir aktörün rastgele bir dosyanın o konuma yerleştirilmesine neden olabileceği bazı platformlarda (BSD'ler gibi) mümkündür.
    // Bu, eğer libbacktrace'e bir dosya adını söylersek, rastgele bir dosya kullanıyor olabileceği ve muhtemelen segfault'lara neden olabileceği anlamına gelir.
    // Ancak libbacktrace'e hiçbir şey söylemezsek, /proc/self/exe gibi yolları desteklemeyen platformlarda hiçbir şey yapmaz!
    //
    // Bir dosya adını *geçirmemek* için olabildiğince çok uğraştığımızdan, ancak /proc/self/exe i hiç desteklemeyen platformlarda yapmalıyız.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // İdeal olarak `std::env::current_exe` kullanacağımızı, ancak burada `std` isteyemeyeceğimizi unutmayın.
            //
            // Mevcut yürütülebilir yolu statik bir alana yüklemek için `_NSGetExecutablePath` i kullanın (eğer çok küçükse pes edin).
            //
            //
            // Bozuk yürütülebilir dosyalar üzerinde ölmemesi için burada libbacktrace'e ciddi şekilde güvendiğimizi unutmayın, ancak kesinlikle öyle ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows dosya açma moduna sahiptir ve açıldıktan sonra silinemez.
            // Burada genel olarak istediğimiz şey budur çünkü çalıştırılabilir dosyamızın, libbacktrace'e teslim ettikten sonra altımızdan değişmediğinden emin olmak istiyoruz, umarım keyfi verileri libbacktrace'e (yanlış yönetilebilir) geçirme yeteneğini azaltır.
            //
            //
            // Kendi imajımıza kilitlenmek için burada biraz dans yaptığımıza göre:
            //
            // * Geçerli sürecin bir tanıtıcısı alın, dosya adını yükleyin.
            // * Bu dosya adına doğru bayraklarla bir dosya açın.
            // * Geçerli işlemin dosya adını yeniden yükleyin, aynı olduğundan emin olun
            //
            // Tüm bunlar geçerse, teoride gerçekten işlemimizin dosyasını açmış oluruz ve bunun değişmeyeceğini garanti ederiz.FWIW bunun bir kısmı geçmişte libstd'den kopyalanmıştır, bu yüzden bu ne olduğuna dair en iyi yorumumdur.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Bu statik hafızada yaşıyor, böylece onu geri verebiliriz ..
                static mut BUF: [i8; N] = [0; N];
                // ... ve bu geçici olduğu için yığında yaşıyor
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // `handle` i kasıtlı olarak buraya sızdırın, çünkü bu açık olması bu dosya adındaki kilidimizi korumalı.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Boş sonlandırılmış bir dilim döndürmek istiyoruz, bu nedenle her şey doldurulmuşsa ve toplam uzunluğa eşitse, bunu başarısızlığa eşitleyin.
                //
                //
                // Aksi takdirde, başarıya dönerken nul baytın dilime dahil edildiğinden emin olun.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // geri izleme hataları şu anda halının altına süpürülüyor
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `syminfo_cb` i tam olarak bir kez çağırması gereken (veya muhtemelen bir hatayla başarısız olan) `backtrace_syminfo` API'yi çağırın.
    // Daha sonra `syminfo_cb` içinde daha fazlasını işliyoruz.
    //
    // Bunu, `syminfo` sembol tablosuna başvuracağından, ikili dosyada hata ayıklama bilgisi olmasa bile sembol isimlerini bulacağından beri yaptığımıza dikkat edin.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}