// şu anda yalnızca Linux te kullanıldı, bu nedenle başka yerlerde ölü koda izin verin
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Bayt arabellekleri için basit bir alan ayırıcı.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Belirtilen boyutta bir arabellek ayırır ve ona değiştirilebilir bir referans döndürür.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // GÜVENLİK: Bu, değiştirilebilir bir
        // `self.buffers` e referans.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // GÜVENLİK: `self.buffers` teki öğeleri asla kaldırmayız, bu nedenle bir referans
        // herhangi bir arabellekteki veriler, `self` in yaşadığı sürece yaşayacaktır.
        &mut buffers[i]
    }
}