//! crates.io te `gimli` crate kullanarak sembolikasyon desteği
//!
//! Bu, Rust için varsayılan simgesel uygulama uygulamasıdır.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // Statik ömür, kendine atıfta bulunan yapılar için destek eksikliğinden kurtulmak için yapılan bir yalandır.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Sembollerin yalnızca `map` ve `stash` i ödünç alması gerektiğinden 'statik yaşam sürelerine dönüştürün ve bunları aşağıda koruyoruz.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows e yerel kitaplıkları yüklemek için, buradaki çeşitli stratejiler için rust-lang/rust#71060 ile ilgili bazı tartışmalara bakın.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW kitaplıkları şu anda ASLR (rust-lang/rust#16514) i desteklemiyor, ancak DLL'ler yine de adres alanında yeniden konumlandırılabilir.
            // Hata ayıklama bilgisindeki adreslerin tümü, sanki bu kitaplık, COFF dosya başlıklarında bir alan olan "image base" e yüklenmiş gibi görünüyor.
            // Hata ayıklama bilgilerinin listelediği şey bu olduğundan, sembol tablosunu ayrıştırır ve adresleri kitaplık "image base" te yüklenmiş gibi saklarız.
            //
            // Bununla birlikte, kitaplık "image base" te yüklenemez.
            // (muhtemelen oraya başka bir şey yüklenmiş olabilir?) Burası `bias` alanı devreye giriyor ve burada `bias` in değerini bulmamız gerekiyor.Ne yazık ki, bunun yüklü bir modülden nasıl elde edileceği net değil.
            // Bununla birlikte, elimizde olan, gerçek yükleme adresi (`modBaseAddr`).
            //
            // Şimdilik bir kopya olarak, dosyayı gözden geçiriyoruz, dosya başlığı bilgilerini okuyoruz ve sonra mmap'i bırakıyoruz.Bu israftır çünkü mmap'i muhtemelen daha sonra yeniden açacağız, ancak bu şimdilik yeterince iyi çalışacaktır.
            //
            // `image_base` e (istenen yükleme konumu) ve `base_addr` e (gerçek yükleme konumu) sahip olduktan sonra, `bias` i (gerçek ve istenen arasındaki fark) doldurabiliriz ve ardından her bölümün belirtilen adresi `image_base` tir, çünkü dosya budur.
            //
            //
            // Şimdilik, ELF/MachO ten farklı olarak, `modBaseSize` i tam boyut olarak kullanarak, kitaplık başına bir segmentle idare edebiliyoruz.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Mach-O dosya biçimini kullanır ve uygulamanın parçası olan yerel kitaplıkların bir listesini yüklemek için DYLD'ye özgü API'leri kullanır.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Bu kitaplığın, nereye yükleneceğine karşılık gelen adını da getirin.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Bu kitaplığın resim başlığını yükleyin ve tüm yükleme komutlarını ayrıştırmak için `object` e delege edin, böylece burada yer alan tüm segmentleri bulabiliriz.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Segmentler üzerinde yineleyin ve bulduğumuz segmentler için bilinen bölgeleri kaydedin.
            // Ek olarak, daha sonra işlenmek üzere metin bölümleri hakkındaki bilgileri kaydedin, aşağıdaki yorumlara bakın.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Bu kitaplık için, bellek nesnelerinin nereye yüklendiğini bulmak için kullandığımız önyargı olan "slide" i belirleyin.
            // Yine de bu biraz garip bir hesaplama ve vahşi ortamda birkaç şeyi denemenin ve neyin yapıştığını görmenin sonucudur.
            //
            // Genel fikir, `bias` artı bir segmentin `stated_virtual_memory_address` inin, segmentin gerçek adres uzayında bulunduğu yerde olacağıdır.
            // Yine de güvendiğimiz bir diğer şey, `bias` in eksi gerçek bir adresin, sembol tablosunda ve hata ayıklama bilgilerinde aranacak dizindir.
            //
            // Yine de, sistem yüklü kitaplıklar için bu hesaplamaların yanlış olduğu ortaya çıktı.Ancak yerel yürütülebilir dosyalar için doğru görünüyor.
            // LLDB'nin kaynağından biraz mantık kaldırıldığında, sıfır olmayan bir boyutta 0 dosya ofsetinden yüklenen ilk `__TEXT` bölümü için bazı özel kasaları vardır.
            // Her ne sebeple olursa olsun, bu mevcut olduğunda, sembol tablosunun kitaplık için sadece vmaddr slaydına göre olduğu anlamına gelir.
            // *Yoksa*, sembol tablosu vmaddr slaydına ve segmentin belirtilen adresine bağlıdır.
            //
            // Bu durumu ele almak için, sıfırdan uzak dosya konumunda bir metin bölümü *bulamazsak*, önyargıyı ilk metin bölümlerinin belirtilen adresi kadar artırır ve belirtilen tüm adresleri de bu miktarda azaltırız.
            //
            // Bu şekilde sembol tablosu her zaman kitaplığın sapma miktarına göre görünür.
            // Bu, sembol tablosu aracılığıyla simgeleştirmek için doğru sonuçlara sahip gibi görünmektedir.
            //
            // Dürüst olmak gerekirse, bunun doğru olup olmadığından veya bunun nasıl yapılacağını göstermesi gereken başka bir şey olup olmadığından tam olarak emin değilim.
            // Şimdilik bu yeterince iyi çalışıyor gibi görünse de (?) ve gerekirse bunu zaman içinde her zaman değiştirebilmeliyiz.
            //
            // Daha fazla bilgi için bkz. #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Diğer Unix (ör.
        // Linux) platformları, nesne dosyası formatı olarak ELF kullanır ve yerel kitaplıkları yüklemek için tipik olarak `dl_iterate_phdr` adlı bir API uygular.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` geçerli bir işaretçi olmalıdır.
        // `vec` `std::Vec` için geçerli bir işaretçi olmalıdır.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 yerel olarak hata ayıklama bilgilerini desteklemez, ancak derleme sistemi hata ayıklama bilgisini `romfs:/debug_info.elf` yoluna yerleştirir.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Diğer her şey ELF kullanmalıdır, ancak yerel kitaplıkların nasıl yükleneceğini bilmiyor.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Yüklenen bilinen tüm paylaşılan kitaplıklar.
    libraries: Vec<Library>,

    /// Ayrıştırılmış cüce bilgilerini sakladığımız eşleme önbelleği.
    ///
    /// Bu liste, tüm kaldırma süresi için asla artmayan sabit bir kapasiteye sahiptir.
    /// Her bir çiftin `usize` öğesi, yukarıda `usize::max_value()` in geçerli yürütülebilir dosyayı temsil ettiği `libraries` e bir dizindir.
    ///
    /// `Mapping`, karşılık gelen ayrıştırılmış cüce bilgisidir.
    ///
    /// Bunun temelde bir LRU önbelleği olduğunu ve adresleri sembolize ederken burada işleri değiştireceğimizi unutmayın.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Bu kitaplığın bölümleri belleğe yüklenir ve nereye yüklenir.
    segments: Vec<LibrarySegment>,
    /// Bu kitaplığın "bias" i, genellikle belleğe yüklendiği yerdir.
    /// Bu değer, segmentin yüklendiği gerçek sanal bellek adresini almak için her segmentin belirtilen adresine eklenir.
    /// Ek olarak bu önyargı, hata ayıklama bilgisi ve sembol tablosuna indekslemek için gerçek sanal bellek adreslerinden çıkarılır.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Bu segmentin nesne dosyasında belirtilen adresi.
    /// Bu aslında segmentin yüklendiği yer değildir, bunun yerine bu adres artı içeren kütüphanenin `bias` i onu nerede bulacağınızdır.
    ///
    stated_virtual_memory_address: usize,
    /// Hafızadaki bu bölümün boyutu.
    len: usize,
}

// güvenli değil çünkü bunun harici olarak senkronize edilmesi gerekiyor
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // güvenli değil çünkü bunun harici olarak senkronize edilmesi gerekiyor
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Hata ayıklama bilgisi eşlemeleri için çok küçük, çok basit bir LRU önbelleği.
        //
        // Tipik yığın birçok paylaşılan kitaplık arasında kesişmediği için isabet oranı çok yüksek olmalıdır.
        //
        // `addr2line::Context` yapılarının oluşturulması oldukça pahalıdır.
        // Maliyetinin, güzel hızlandırmalar elde etmek için "addr2line: : Context" oluştururken inşa edilen yapılardan yararlanan sonraki `locate` sorguları tarafından amorti edilmesi bekleniyor.
        //
        // Bu önbelleğe sahip olmasaydık, bu amortisman asla olmazdı ve geri izleri sembolize etmek ssssllllooooowwww olurdu.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // İlk olarak, bu `lib` in `addr` i içeren herhangi bir segmenti olup olmadığını test edin (yeniden konumlandırma işleme).Bu kontrol başarılı olursa, aşağıdan devam edebilir ve adresi gerçekten tercüme edebiliriz.
                //
                // Taşma kontrollerinden kaçınmak için burada `wrapping_add` kullandığımızı unutmayın.Vahşi doğada SVMA + önyargı hesaplamasının aştığı görüldü.
                // Bu biraz tuhaf görünüyor, ancak muhtemelen uzaya işaret ettikleri için bu bölümleri görmezden gelmekten başka yapabileceğimiz çok büyük bir şey yok.
                //
                // Bu başlangıçta rust-lang/backtrace-rs#329 te ortaya çıktı.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Artık `lib` in `addr` içerdiğini bildiğimize göre, belirtilen sanal bellek adresini bulmak için önyargı ile dengelenebiliriz.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Değişmez: erken dönmeden bu koşul tamamlandıktan sonra
        // bir hatadan, bu yol için önbellek girişi 0 dizinindedir.

        if let Some(idx) = idx {
            // Eşleme zaten önbellekte olduğunda, onu öne taşıyın.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Eşleme önbellekte olmadığında, yeni bir eşleme oluşturun, bunu önbelleğin önüne yerleştirin ve gerekirse en eski önbellek girişini çıkarın.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` in ömrünü sızdırmayın, kapsamının sadece kendimize göre yapıldığından emin olun
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Maalesef burada zorunlu olduğumuz için `sym` in ömrünü `'static` e uzatın, ancak bu sadece bir referans olarak çıkacak, bu yüzden yine de bu çerçevenin ötesinde hiçbir atıfta bulunulmamalıdır.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Son olarak, bu dosya için önbelleğe alınmış bir eşleme alın veya yeni bir eşleme oluşturun ve bu adres için file/line/name i bulmak için DWARF bilgilerini değerlendirin.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Bu sembol için çerçeve bilgilerini bulabildik ve "addr2line" ın çerçevesi dahili olarak tüm nitty cesur ayrıntılara sahip.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Hata ayıklama bilgisini bulamadık, ancak onu çalıştırılabilir elf'in sembol tablosunda bulduk.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}