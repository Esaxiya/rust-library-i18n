//! Yeni makroları tanımlarken makro yazarları için bir destek kitaplığı.
//!
//! Standart dağıtım tarafından sağlanan bu kitaplık, işlev benzeri makrolar `#[proc_macro]`, makro öznitelikleri `#[proc_macro_attribute]` ve özel türetme öznitelikleri "#[proc_macro_derive]" gibi prosedürel olarak tanımlanmış makro tanımlarının arabirimlerinde tüketilen türleri sağlar.
//!
//!
//! Daha fazlası için [the book] e bakın.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Proc_macro'nun o anda çalışan program için erişilebilir hale getirilip getirilmediğini belirler.
///
/// Proc_macro crate, yalnızca prosedür makrolarının uygulanmasında kullanılmak üzere tasarlanmıştır.Bu crate panic'deki tüm işlevler, bir yapı komut dosyası veya birim testi veya sıradan Rust ikili dosyası gibi bir prosedürel makronun dışından çağrılırsa.
///
/// Hem makro hem de makro dışı kullanım durumlarını desteklemek için tasarlanmış Rust kitaplıkları düşünüldüğünde, `proc_macro::is_available()` proc_macro API'sini kullanmak için gerekli altyapının şu anda mevcut olup olmadığını tespit etmek için panik yapmayan bir yol sağlar.
/// Bir yordamsal makronun içinden çağrılırsa true, başka bir ikiliden çağrılırsa false döndürür.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Bu crate tarafından sağlanan ana tip, soyut bir Z0tokensOZ akışını veya daha spesifik olarak bir ZOtokenOZ ağaçları dizisini temsil eder.
/// Tür, bu token ağaçları üzerinde yineleme yapmak ve tersine, bir dizi token ağacını tek bir akışta toplamak için arabirimler sağlar.
///
///
/// Bu, `#[proc_macro]`, `#[proc_macro_attribute]` ve `#[proc_macro_derive]` tanımlarının hem girişi hem de çıkışıdır.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` ten hata döndürüldü.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token ağaçları içermeyen boş bir `TokenStream` döndürür.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Bu `TokenStream` in boş olup olmadığını kontrol eder.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Dizeyi tokens'ye bölme ve bu tokens'yi bir token akışına ayrıştırma girişimleri.
/// Dize dengesiz sınırlayıcılar veya dilde mevcut olmayan karakterler içeriyorsa, bir dizi nedenden dolayı başarısız olabilir.
///
/// Ayrıştırılmış akıştaki tüm tokens, `Span::call_site()` aralıklarını alır.
///
/// NOTE: bazı hatalar `LexError` in döndürülmesi yerine panics'ye neden olabilir.Bu hataları daha sonra "LexError" olarak değiştirme hakkını saklı tutarız.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, köprü yalnızca `to_string` i sağlar, `fmt::Display` i buna göre uygular (ikisi arasındaki olağan ilişkinin tersi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token akışını, muhtemelen `Delimiter::None` sınırlayıcıları ve negatif sayısal değişmez değerleri olan "TokenTree: : Group" haricinde, kayıpsız olarak aynı token akışına (modulo aralıkları) dönüştürülebileceği varsayılan bir dize olarak yazdırır.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// token'yi hata ayıklamaya uygun bir biçimde yazdırır.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Tek bir token ağacı içeren bir token akışı oluşturur.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Bir dizi token ağacını tek bir akışta toplar.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token akışlarındaki bir "flattening" işlemi, birden çok token akışından token ağaçlarını tek bir akışta toplar.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Mümkün olan optimize edilmiş bir if/when uygulaması kullanın.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Yineleyiciler gibi `TokenStream` türü için genel uygulama ayrıntıları.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// "TokenStream" in "TokenTree" si üzerinde bir yineleyici.
    /// Yineleme "shallow" tir, örneğin yineleyici sınırlandırılmış gruplar halinde yinelenmez ve tüm grupları token ağaçları olarak döndürür.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` keyfi tokens'yi kabul eder ve girdiyi açıklayan bir `TokenStream` e genişler.
/// Örneğin, `quote!(a + b)`, değerlendirildiğinde `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Alıntı kaldırma `$` ile yapılır ve bir sonraki tanımlamayı alıntılanmamış terim olarak alarak çalışır.
/// `$` in kendisinden alıntı yapmak için `$$` i kullanın.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Makro genişletme bilgileriyle birlikte bir kaynak kod bölgesi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// `self` aralığında verilen `message` ile yeni bir `Diagnostic` oluşturur.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Makro tanımlama sitesinde çözülen bir aralık.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Mevcut yordamsal makroyu çağırma aralığı.
    /// Bu aralıkla oluşturulan tanımlayıcılar, doğrudan makro arama konumunda (arama yeri hijyeni) yazılmış gibi çözümlenecek ve makro arama sitesindeki diğer kodlar da bunlara başvurabilecektir.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` hijyenini temsil eden ve bazen makro tanımlama sitesinde (yerel değişkenler, etiketler, `$crate`) ve bazen makro arama sitesinde (diğer her şey) çözülen bir aralık.
    ///
    /// Aralık konumu, çağrı sitesinden alınır.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Bu aralığın işaret ettiği orijinal kaynak dosyası.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Varsa, `self` in oluşturulduğu önceki makro genişletmedeki tokens için `Span`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` in oluşturulduğu kaynak kodunun aralığı.
    /// Bu `Span` diğer makro genişletmelerinden oluşturulmadıysa, dönüş değeri `*self` ile aynıdır.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Bu yayılma alanı için kaynak dosyadaki başlangıç line/column değerini alır.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Bu yayılma alanı için kaynak dosyadaki son line/column değerini alır.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` ve `other` i kapsayan yeni bir aralık oluşturur.
    ///
    /// `self` ve `other` farklı dosyalardan ise `None` i döndürür.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` ile aynı line/column bilgisine sahip yeni bir aralık oluşturur, ancak bu, sembolleri `other` teymiş gibi çözer.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` ile aynı ad çözümleme davranışına sahip ancak `other` in line/column bilgileriyle yeni bir aralık oluşturur.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Eşit olup olmadıklarını görmek için aralıklarla karşılaştırır.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Bir aralık arkasında kaynak metni döndürür.
    /// Bu, boşluklar ve yorumlar dahil olmak üzere orijinal kaynak kodunu korur.
    /// Yalnızca aralık gerçek kaynak koduna karşılık gelirse bir sonuç döndürür.
    ///
    /// Note: Bir makronun gözlemlenebilir sonucu, bu kaynak metne değil, yalnızca tokens'ye dayanmalıdır.
    ///
    /// Bu işlevin sonucu, yalnızca teşhis için kullanılacak en iyi çabadır.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Hata ayıklama için uygun bir biçimde bir aralık yazdırır.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Bir `Span` in başlangıcını veya sonunu temsil eden bir satır-sütun çifti.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Yayılma alanının (inclusive) te başladığı veya bittiği kaynak dosyadaki 1 dizinli satır.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Yayılma alanının (inclusive) te başladığı veya bittiği kaynak dosyadaki 0 dizinli sütun (UTF-8 karakterlerinde).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Belirli bir `Span` in kaynak dosyası.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Bu kaynak dosyanın yolunu alır.
    ///
    /// ### Note
    /// Bu `SourceFile` ile ilişkili kod aralığı harici bir makro tarafından oluşturulmuşsa, bu makro, bu dosya sistemindeki gerçek bir yol olmayabilir.
    /// Kontrol etmek için [`is_real`] kullanın.
    ///
    /// Ayrıca, `is_real`, `true` i döndürse bile, `--remap-path-prefix` komut satırında geçirilmişse, verilen yolun gerçekte geçerli olmayabileceğini unutmayın.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Bu kaynak dosya gerçek bir kaynak dosyasıysa ve harici bir makronun genişletmesi tarafından oluşturulmamışsa `true` i döndürür.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Bu, intercrate aralıkları uygulanana kadar bir hack'tir ve harici makrolarda oluşturulan yayılmalar için gerçek kaynak dosyalara sahip olabiliriz.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Tek bir token veya sınırlandırılmış bir token ağaçları dizisi (örneğin, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Parantez sınırlayıcılarla çevrili bir token akışı.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Bir tanımlayıcı.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Tek bir noktalama karakteri ("+", `,`, `$`, vb.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Bir değişmez karakter (`'a'`), (`"hello"`) dizesi, (`2.3`) sayısı vb.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Bu ağacın kapsamını, içerilen token'nin `span` yöntemine veya sınırlandırılmış bir akıma delege ederek döndürür.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *Yalnızca bu token* için aralığı yapılandırır.
    ///
    /// Bu token bir `Group` ise, bu yöntemin dahili tokens'nin her birinin aralığını yapılandırmayacağını, bunun basitçe her varyantın `set_span` yöntemini delege edeceğini unutmayın.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// token ağacını hata ayıklamaya uygun bir biçimde yazdırır.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Bunların her birinin türetilmiş hata ayıklamadaki yapı türünde adı vardır, bu nedenle fazladan bir yönlendirme katmanıyla uğraşmayın
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, köprü yalnızca `to_string` i sağlar, `fmt::Display` i buna göre uygular (ikisi arasındaki olağan ilişkinin tersi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token ağacını, muhtemelen `Delimiter::None` sınırlayıcıları ve negatif sayısal değişmez değerleri olan 'TokenTree: : Group' dışında, kayıpsız olarak aynı token ağacına (modulo aralıkları) dönüştürülebileceği varsayılan bir dize olarak yazdırır.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Sınırlandırılmış bir token akışı.
///
/// Bir `Group` dahili olarak "Sınırlayıcı" larla çevrili bir `TokenStream` içerir.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Bir token ağaç dizisinin nasıl sınırlandırıldığını açıklar.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Örneğin, bir "macro variable" `$var` ten gelen tokens çevresinde görünebilen örtük bir sınırlayıcı.
    /// `$var` in `1 + 2` olduğu `$var * 3` gibi durumlarda operatör önceliklerini korumak önemlidir.
    /// Örtük sınırlayıcılar, bir dizge aracılığıyla bir token akışının gidiş dönüşünden sağ çıkamayabilir.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Verilen sınırlayıcı ve token akışıyla yeni bir `Group` oluşturur.
    ///
    /// Bu kurucu, bu grup için aralığı `Span::call_site()` olarak ayarlayacaktır.
    /// Aralığı değiştirmek için aşağıdaki `set_span` yöntemini kullanabilirsiniz.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Bu `Group` in sınırlayıcısını verir
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Bu `Group` te sınırlandırılmış olan tokens'nin `TokenStream` ini döndürür.
    ///
    /// Döndürülen token akışının yukarıda döndürülen sınırlayıcıyı içermediğini unutmayın.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Tüm `Group` i kapsayan bu token akışının sınırlayıcıları için aralığı döndürür.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Bu grubun açılış sınırlayıcısına işaret eden aralığı döndürür.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Bu grubun kapanış sınırlayıcısına işaret eden aralığı döndürür.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Bu "Grup" sınırlayıcıları için aralığı yapılandırır, ancak dahili tokens'yi yapılandırmaz.
    ///
    /// Bu yöntem, bu grup tarafından kapsanan tüm dahili tokens'nin aralığını **ayarlamaz**, bunun yerine yalnızca tokens sınırlayıcısının aralığını `Group` düzeyinde ayarlayacaktır.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, köprü yalnızca `to_string` i sağlar, `fmt::Display` i buna göre uygular (ikisi arasındaki olağan ilişkinin tersi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Grubu, `Delimiter::None` sınırlayıcıları olan "TokenTree: : Group" dışında, kayıpsız olarak aynı gruba (modulo aralıkları) dönüştürülebilecek bir dize olarak yazdırır.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Bir `Punct`, `+`, `-` veya `#` gibi tek bir noktalama karakteridir.
///
/// `+=` gibi çok karakterli operatörler, `Spacing` in farklı biçimleri döndürülen iki `Punct` örneği olarak temsil edilir.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Bir `Punct` in hemen ardından başka bir `Punct` in mi yoksa başka bir token'nin veya beyaz alanın mı geldiği.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// örneğin, `+`, `+ =`, `+ident` veya `+()` te `Alone` tir.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// örneğin, `+`, `+=` veya `'#` te `Joint` tir.
    /// Ek olarak, tek tırnaklı `'`, `'ident` yaşam sürelerini oluşturmak için tanımlayıcılarla birleştirilebilir.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Verilen karakter ve aralıktan yeni bir `Punct` oluşturur.
    /// `ch` bağımsız değişkeni, dil tarafından izin verilen geçerli bir noktalama karakteri olmalıdır, aksi takdirde işlev panic olacaktır.
    ///
    /// İade edilen `Punct`, aşağıdaki `set_span` yöntemiyle daha da yapılandırılabilen varsayılan `Span::call_site()` aralığına sahip olacaktır.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Bu noktalama karakterinin değerini `char` olarak döndürür.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// token akışında hemen başka bir `Punct` in gelip gelmediğini belirterek bu noktalama karakterinin aralığını döndürür, böylece potansiyel olarak çok karakterli bir operatör (`Joint`) te birleştirilebilirler veya ardından başka bir token veya beyaz boşluk (`Alone`) gelir, böylece operatör kesinlikle Bitti.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Bu noktalama karakterinin aralığını döndürür.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Bu noktalama karakterinin yayılma alanını yapılandırın.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, köprü yalnızca `to_string` i sağlar, `fmt::Display` i buna göre uygular (ikisi arasındaki olağan ilişkinin tersi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Noktalama karakterini kayıpsız bir şekilde aynı karaktere dönüştürülebilecek bir dize olarak yazdırır.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Bir tanımlayıcı (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Verilen `string` ve belirtilen `span` ile yeni bir `Ident` oluşturur.
    /// `string` bağımsız değişkeni, dil tarafından izin verilen geçerli bir tanımlayıcı olmalıdır (anahtar kelimeler dahil, örneğin `self` veya `fn`).Aksi takdirde, işlev panic olacaktır.
    ///
    /// Şu anda rustc'de bulunan `span` in bu tanımlayıcı için hijyen bilgilerini yapılandırdığını unutmayın.
    ///
    /// Bu andan itibaren `Span::call_site()`, "call-site" hijyenini açıkça kabul eder, yani bu aralıkla oluşturulan tanımlayıcılar, doğrudan makro çağrısının konumuna yazılmış gibi çözülecektir ve makro çağrısı sitesindeki diğer kod, onları da.
    ///
    ///
    /// `Span::def_site()` gibi daha sonraki aralıklar, "definition-site" hijyenine katılmaya izin verecektir, yani bu aralıkla oluşturulan tanımlayıcılar, makro tanımının bulunduğu yerde çözülecektir ve makro arama sitesindeki diğer kodlar bunlara başvuramayacaktır.
    ///
    /// Hijyenin mevcut önemi nedeniyle, bu kurucu, diğer tokens'den farklı olarak, yapım aşamasında bir `Span` in belirtilmesini gerektirir.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` ile aynıdır, ancak bir ham tanımlayıcı (`r#ident`) oluşturur.
    /// `string` argümanı, dil tarafından izin verilen geçerli bir tanımlayıcıdır (anahtar kelimeler dahil, örneğin `fn`).
    /// Yol segmentlerinde kullanılabilen anahtar kelimeler (ör.
    /// `self`, "super") desteklenmez ve bir panic'ye neden olur.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// [`to_string`](Self::to_string) tarafından döndürülen tüm dizeyi kapsayan bu `Ident` in aralığını döndürür.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Bu `Ident` in kapsamını, muhtemelen hijyen bağlamını değiştirerek yapılandırır.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, köprü yalnızca `to_string` i sağlar, `fmt::Display` i buna göre uygular (ikisi arasındaki olağan ilişkinin tersi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tanımlayıcıyı, kayıpsız bir şekilde aynı tanımlayıcıya geri dönüştürülebilmesi gereken bir dize olarak yazdırır.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Değişmez bir dizi (`"hello"`), bayt dizesi (`b"hello"`), karakter (`'a'`), bayt karakteri (`b'a'`), son ek içeren veya içermeyen bir tam sayı veya kayan nokta numarası ("1", `1u8`, `2.3`, `2.3f32`).
///
/// `true` ve `false` gibi Boole değişmez değerleri buraya ait değildir, bunlar "Kimlik" dir.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Belirtilen değere sahip yeni bir tamsayı hazır bilgisi oluşturur.
        ///
        /// Bu işlev, belirtilen tamsayı değerinin token'nin ilk parçası olduğu ve integralin de sonuna eklenmiş olduğu `1u32` gibi bir tamsayı oluşturacaktır.
        /// Negatif sayılardan oluşturulan değişmez değerler, `TokenStream` veya dizelerdeki gidiş gelişlerden sağ çıkamayabilir ve iki tokens'ye (`-` ve pozitif değişmez) bölünebilir.
        ///
        ///
        /// Bu yöntemle oluşturulan değişmez değerler, varsayılan olarak `Span::call_site()` aralığına sahiptir ve aşağıdaki `set_span` yöntemiyle yapılandırılabilir.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Belirtilen değere sahip yeni bir sonlandırılmamış tamsayı hazır bilgisi oluşturur.
        ///
        /// Bu işlev, belirtilen tamsayı değerinin token'nin ilk parçası olduğu `1` gibi bir tamsayı yaratacaktır.
        /// Bu token üzerinde herhangi bir son ek belirtilmemiştir, yani `Literal::i8_unsuffixed(1)` gibi çağrıların `Literal::u32_unsuffixed(1)` e eşdeğer olduğu anlamına gelir.
        /// Negatif sayılardan oluşturulan değişmez değerler, `TokenStream` veya dizeler aracılığıyla gezintilere dayanamayabilir ve iki tokens'ye (`-` ve pozitif değişmez) bölünebilir.
        ///
        ///
        /// Bu yöntemle oluşturulan değişmez değerler, varsayılan olarak `Span::call_site()` aralığına sahiptir ve aşağıdaki `set_span` yöntemiyle yapılandırılabilir.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Yeni bir sonlandırılmamış kayan noktalı değişmez değer oluşturur.
    ///
    /// Bu kurucu, float değerinin doğrudan token'ye gönderildiği ancak son ekin kullanılmadığı `Literal::i8_unsuffixed` gibi, derleyicide daha sonra bir `f64` olduğu sonucuna varılabilir.
    ///
    /// Negatif sayılardan oluşturulan değişmez değerler, `TokenStream` veya dizeler aracılığıyla gezintilere dayanamayabilir ve iki tokens'ye (`-` ve pozitif değişmez) bölünebilir.
    ///
    /// # Panics
    ///
    /// Bu işlev, belirtilen float değerinin sonlu olmasını gerektirir, örneğin sonsuzsa veya NaN ise bu işlev panic olacaktır.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Yeni bir son ekli kayan nokta değişmezi oluşturur.
    ///
    /// Bu kurucu, belirtilen değerin token'nin önceki parçası olduğu ve `f32` in token'nin soneki olduğu `1.0f32` gibi bir hazır bilgi yaratacaktır.
    /// Bu token, derleyicide her zaman bir `f32` olarak çıkarılacaktır.
    /// Negatif sayılardan oluşturulan değişmez değerler, `TokenStream` veya dizeler aracılığıyla gezintilere dayanamayabilir ve iki tokens'ye (`-` ve pozitif değişmez) bölünebilir.
    ///
    ///
    /// # Panics
    ///
    /// Bu işlev, belirtilen float değerinin sonlu olmasını gerektirir, örneğin sonsuzsa veya NaN ise bu işlev panic olacaktır.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Yeni bir sonlandırılmamış kayan noktalı değişmez değer oluşturur.
    ///
    /// Bu kurucu, float değerinin doğrudan token'ye gönderildiği ancak son ekin kullanılmadığı `Literal::i8_unsuffixed` gibi, derleyicide daha sonra bir `f64` olduğu sonucuna varılabilir.
    ///
    /// Negatif sayılardan oluşturulan değişmez değerler, `TokenStream` veya dizeler aracılığıyla gezintilere dayanamayabilir ve iki tokens'ye (`-` ve pozitif değişmez) bölünebilir.
    ///
    /// # Panics
    ///
    /// Bu işlev, belirtilen float değerinin sonlu olmasını gerektirir, örneğin sonsuzsa veya NaN ise bu işlev panic olacaktır.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Yeni bir son ekli kayan nokta değişmezi oluşturur.
    ///
    /// Bu kurucu, belirtilen değerin token'nin önceki parçası olduğu ve `f64` in token'nin soneki olduğu `1.0f64` gibi bir hazır bilgi yaratacaktır.
    /// Bu token, derleyicide her zaman bir `f64` olarak çıkarılacaktır.
    /// Negatif sayılardan oluşturulan değişmez değerler, `TokenStream` veya dizeler aracılığıyla gezintilere dayanamayabilir ve iki tokens'ye (`-` ve pozitif değişmez) bölünebilir.
    ///
    ///
    /// # Panics
    ///
    /// Bu işlev, belirtilen float değerinin sonlu olmasını gerektirir, örneğin sonsuzsa veya NaN ise bu işlev panic olacaktır.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Dize değişmezi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Gerçek karakter.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Bayt dizesi değişmez değeri.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Bu değişmezi kapsayan aralığı döndürür.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Bu değişmez değer için ilişkili aralığı yapılandırır.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Yalnızca `range` aralığındaki kaynak baytları içeren bir `self.span()` alt kümesi olan bir `Span` döndürür.
    /// Kırpılacak aralık `self` sınırlarının dışındaysa `None` i döndürür.
    ///
    // FIXME(SergioBenitez): bayt aralığının kaynağın UTF-8 sınırında başlayıp bitmediğini kontrol edin.
    // aksi takdirde, kaynak metin yazdırıldığında başka bir yerde bir panic oluşması muhtemeldir.
    // FIXME(SergioBenitez): kullanıcının `self.span()` in gerçekte neyle eşleştiğini bilmesinin bir yolu yoktur, bu nedenle bu yöntem şu anda yalnızca kör olarak çağrılabilir.
    // Örneğin, 'c' karakteri için `to_string()`, "'\u{63}'" değerini döndürür;kullanıcının kaynak metnin 'c' mi yoksa '\u{63}' mi olduğunu bilmesinin bir yolu yoktur.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` e benzer bir şey, ancak `Bound<&T>` için.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, köprü yalnızca `to_string` i sağlar, `fmt::Display` i buna göre uygular (ikisi arasındaki olağan ilişkinin tersi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Değişmez değeri kayıpsız olarak aynı değişmez değere dönüştürülebilmesi gereken bir dize olarak yazdırır (kayan noktalı değişmez değerler için olası yuvarlama dışında).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Ortam değişkenlerine izlenen erişim.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Bir ortam değişkenini alın ve bağımlılık bilgisi oluşturmak için ekleyin.
    /// Derleyiciyi çalıştıran derleme sistemi, değişkene derleme sırasında erişildiğini bilecek ve bu değişkenin değeri değiştiğinde derlemeyi yeniden çalıştırabilecektir.
    ///
    /// Bağımlılık izlemenin yanı sıra, bu işlev, bağımsız değişkenin UTF-8 olması gerektiği dışında, standart kitaplıktaki `env::var` e eşdeğer olmalıdır.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}