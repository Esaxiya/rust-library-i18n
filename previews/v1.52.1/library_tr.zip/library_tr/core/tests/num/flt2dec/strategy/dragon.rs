use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri çok yavaş
fn exact_sanity_test() {
    // Bu test, kullandığımız her C çalışma zamanında tanımlanan `exp2` kitaplık işlevinin yalnızca bazı köşelerde olduğunu varsayabildiğim şeyi çalıştırıyor.
    // VS 2013'te, bu test bağlandığında başarısız olduğu için bu işlevde bir hata vardı, ancak VS 2015 ile test gayet iyi çalıştığı için hata düzeltilmiş görünüyor.
    //
    // Hata, `exp2(-1057)` in dönüş değerinde bir fark gibi görünüyor, burada VS 2013'te 0x2 bit deseniyle bir double döndürüyor ve VS 2015'te 0x20000 i döndürüyor.
    //
    //
    // Şimdilik, başka bir yerde test edildiği için bu testi tamamen MSVC'de görmezden gelin ve her platformun exp2 uygulamasını test etmekle çok ilgilenmiyoruz.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}