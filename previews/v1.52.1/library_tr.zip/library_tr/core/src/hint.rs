#![stable(feature = "core_hint", since = "1.27.0")]

//! Kodun nasıl yayınlanması veya optimize edilmesi gerektiğini etkileyen derleyici ipuçları.
//! İpuçları derleme zamanı veya çalışma zamanı olabilir.

use crate::intrinsics;

/// Derleyiciye koddaki bu noktaya ulaşılamayacağını bildirerek daha fazla optimizasyon sağlar.
///
/// # Safety
///
/// Bu işleve ulaşmak tamamen *tanımsız bir davranıştır*(UB).Özellikle, derleyici tüm UB'nin asla gerçekleşmemesi gerektiğini varsayar ve bu nedenle `unreachable_unchecked()` e bir çağrıya ulaşan tüm dalları ortadan kaldıracaktır.
///
/// Tüm UB örnekleri gibi, bu varsayımın yanlış olduğu ortaya çıkarsa, yani `unreachable_unchecked()` çağrısına tüm olası kontrol akışları arasında gerçekten ulaşılabilirse, derleyici yanlış optimizasyon stratejisini uygular ve hatta bazen görünüşte ilgisiz kodu bozarak zor-hata ayıklama sorunları.
///
///
/// Bu işlevi yalnızca kodun onu asla çağırmayacağını ispatlayabildiğiniz zaman kullanın.
/// Aksi takdirde, optimizasyonlara izin vermeyen ancak yürütüldüğünde panic olacak olan [`unreachable!`] makrosunu kullanmayı düşünün.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` her zaman pozitiftir (sıfır değil), bu nedenle `checked_div` hiçbir zaman `None` i döndürmez.
/////
///     // Bu nedenle, diğer branch'ye erişilemez.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // GÜVENLİK: `intrinsics::unreachable` için güvenlik sözleşmesi,
    // arayan tarafından desteklenmelidir.
    unsafe { intrinsics::unreachable() }
}

/// İşlemciye meşgul-bekleme dönüş döngüsünde ("döndürme kilidi") çalıştığını bildirmek için bir makine talimatı yayar.
///
/// Döndürme döngüsü sinyalini aldıktan sonra işlemci, örneğin güç tasarrufu yaparak veya hyper ipliklerini değiştirerek davranışını optimize edebilir.
///
/// Bu işlev, [`thread::yield_now`] ten farklıdır ve doğrudan sistemin programlayıcısına yol açar, oysa `spin_loop` işletim sistemiyle etkileşime girmez.
///
/// `spin_loop` için yaygın bir kullanım örneği, senkronizasyon ilkellerinde bir CAS döngüsünde sınırlı iyimser eğirme uygulamaktır.
/// Öncelikli ters çevirme gibi sorunları önlemek için, sonlu sayıda yinelemeden sonra döndürme döngüsünün sonlandırılması ve uygun bir engelleme sistem çağrısı yapıldıktan sonra şiddetle tavsiye edilir.
///
///
/// **Not**: Döndürme döngüsü ipuçlarını almayı desteklemeyen platformlarda bu işlev hiçbir şey yapmaz.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // İpliklerin koordine etmek için kullanacağı paylaşılan bir atomik değer
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Bir arka plan iş parçacığında sonunda değerini ayarlayacağız
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Biraz çalışın, sonra değeri yaşayın
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Mevcut iş parçacığımıza geri dönelim, değerin ayarlanmasını bekliyoruz
/// while !live.load(Ordering::Acquire) {
///     // Döndürme döngüsü, beklediğimiz CPU için bir ipucudur, ancak muhtemelen çok uzun sürmez
/////
///     hint::spin_loop();
/// }
///
/// // Değer şimdi ayarlandı
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // GÜVENLİK: `cfg` özelliği, bunu yalnızca x86 hedeflerinde yürütmemizi sağlar.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // GÜVENLİK: `cfg` özelliği, bunu yalnızca x86_64 hedeflerinde yürütmemizi sağlar.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // GÜVENLİK: `cfg` özelliği, bunu yalnızca aarch64 hedeflerinde yürütmemizi sağlar.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // GÜVENLİK: `cfg` attr, bunu yalnızca silah hedeflerinde yürütmemizi sağlar
            // v6 özelliği desteği ile.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Derleyiciye `black_box` in neler yapabileceği konusunda azami derecede kötümser olmasını * __ ima eden bir kimlik işlevi.
///
/// [`std::convert::identity`] ten farklı olarak, bir Rust derleyicisinin, `black_box` in, `dummy` i, çağıran kodda tanımsız davranışa neden olmadan Rust koduna izin verilen olası herhangi bir geçerli şekilde kullanabileceğini varsayması önerilir.
///
/// Bu özellik, `black_box` i kıyaslamalar gibi belirli optimizasyonların istenmediği kod yazmak için kullanışlı hale getirir.
///
/// Bununla birlikte, `black_box` in yalnızca "best-effort" temelinde sağlandığını (ve yalnızca sağlanabileceğini) unutmayın.Optimizasyonları ne ölçüde engelleyebildiği, kullanılan platforma ve kod-gen arka uca bağlı olarak değişebilir.
/// Programlar hiçbir şekilde *doğruluk* için `black_box` e güvenemezler.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // LLVM'nin iç gözlem yapamayacağı bir şekilde argümanı "use" yapmalıyız ve bunu destekleyen hedeflerde bunu yapmak için tipik olarak satır içi montajdan yararlanabiliriz.
    // LLVM'nin satır içi montaj yorumu, bunun bir kara kutu olduğudur.
    // Muhtemelen istediğimizden daha fazlasını deoptize ettiği için bu en iyi uygulama değil, ama şimdiye kadar yeterince iyi.
    //
    //

    #[cfg(not(miri))] // Bu sadece bir ipucu, bu yüzden Miri'de atlamakta sorun yok.
    // GÜVENLİK: satır içi montaj işlemsizdir.
    unsafe {
        // FIXME: `asm!`, MIPS ve diğer mimarileri desteklemediği için kullanılamaz.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}