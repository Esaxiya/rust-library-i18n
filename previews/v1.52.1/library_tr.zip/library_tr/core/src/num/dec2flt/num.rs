//! Metotlara dönüşmesi çok mantıklı olmayan bignum'lar için yardımcı fonksiyonlar.

// FIXME Bu modülün adı biraz talihsiz, çünkü diğer modüller de `core::num` i içe aktarıyor.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place` ten daha az önemli olan tüm bitlerin kesilmesinin, 0.5 ULP'den daha küçük, eşit veya daha büyük bir bağıl hata oluşturup oluşturmadığını test edin.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Kalan tüm bitler sıfırsa,= 0.5 ULP, aksi takdirde> 0.5 Daha fazla bit yoksa (half_bit==0), aşağıdaki de doğru şekilde Eşit döndürür.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Yalnızca ondalık basamaklar içeren bir ASCII dizesini `u64` e dönüştürür.
///
/// Taşma veya geçersiz karakterler için kontroller gerçekleştirmez, bu nedenle arayan dikkatli değilse, sonuç sahte olur ve panic olabilir (ancak `unsafe` olmayacaktır).
/// Ek olarak, boş dizeler sıfır olarak kabul edilir.
/// Bu işlev vardır çünkü
///
/// 1. `&[u8]` üzerinde `FromStr` kullanmak için `from_utf8_unchecked` gerekir, bu kötüdür ve
/// 2. `integral.parse()` ve `fractional.parse()` in sonuçlarını bir araya getirmek, tüm bu işlevden daha karmaşıktır.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Bir dizi ASCII rakamını bignuma dönüştürür.
///
/// `from_str_unchecked` gibi, bu işlev ayrıştırıcıya basamak olmayanları ayıklamak için dayanır.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Bir bignumu 64 bitlik bir tam sayıya açar.Panics sayı çok büyükse.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Bir dizi biti çıkarır.

/// Endeks 0 en önemsiz bittir ve aralık her zamanki gibi yarı açıktır.
/// Panics, dönüş türüne sığandan daha fazla bit çıkarması istenirse.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}