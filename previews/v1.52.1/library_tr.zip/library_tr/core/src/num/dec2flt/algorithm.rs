//! Makaleden çeşitli algoritmalar.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp'deki anlamlı bit sayısı
const P: u32 = 64;

// Sadece *tüm* üsler için en iyi yaklaşımı saklıyoruz, böylece "h" değişkeni ve ilgili koşullar göz ardı edilebilir.
// Bu, performansı birkaç kilobayt alan için değiş tokuş eder.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Çoğu mimaride, kayan nokta işlemlerinin açık bir bit boyutu vardır, bu nedenle hesaplamanın kesinliği işlem başına belirlenir.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86 te, SSE/SSE2 uzantıları mevcut değilse, x87 FPU kayan işlemler için kullanılır.
// x87 FPU varsayılan olarak 80 bitlik hassasiyetle çalışır, bu da işlemlerin 80 bite yuvarlayacağı ve değerler sonunda şu şekilde temsil edildiğinde çift yuvarlamanın gerçekleşmesine neden olacağı anlamına gelir.
//
// 32/64 bit float değerleri.Bunun üstesinden gelmek için, FPU kontrol sözcüğü, hesaplamaların istenen hassasiyette gerçekleştirileceği şekilde ayarlanabilir.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Yapı düşürüldüğünde geri yüklenebilmesi için FPU kontrol sözcüğünün orijinal değerini korumak için kullanılan bir yapı.
    ///
    ///
    /// x87 FPU, alanları aşağıdaki gibi olan 16 bitlik bir kayıttır:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Tüm alanların belgeleri IA-32 Mimarileri Yazılım Geliştirici Kılavuzu'nda (Cilt 1) mevcuttur.
    ///
    /// Aşağıdaki kodla ilgili olan tek alan PC, Precision Control'dur.
    /// Bu alan, FPU tarafından gerçekleştirilen işlemlerin kesinliğini belirler.
    /// Şu şekilde ayarlanabilir:
    ///  - 0b00, tek duyarlıklı yani 32 bit
    ///  - 0b10, çift kesinlik, yani 64 bit
    ///  - 0b11, çift uzatılmış hassasiyet, yani 80 bit (varsayılan durum) 0b01 değeri ayrılmıştır ve kullanılmamalıdır.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // GÜVENLİK: `fldcw` talimatı, aşağıdakilerle doğru şekilde çalışabilmek için denetlenmiştir:
        // herhangi bir `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: LLVM 8 ve LLVM 9'u desteklemek için ATT sözdizimi kullanıyoruz.
                options(att_syntax, nostack),
            )
        }
    }

    /// FPU'nun kesinlik alanını `T` olarak ayarlar ve bir `FPUControlWord` döndürür.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // `T` için uygun olan Hassas Kontrol alanı değerini hesaplayın.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // varsayılan, 80 bit
        };

        // `FPUControlWord` yapısı bırakıldığında daha sonra geri yüklemek için kontrol kelimesinin orijinal değerini alın GÜVENLİK: `fnstcw` talimatı, herhangi bir `u16` ile doğru şekilde çalışabilmek için denetlenmiştir
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: LLVM 8 ve LLVM 9'u desteklemek için ATT sözdizimi kullanıyoruz.
                options(att_syntax, nostack),
            )
        }

        // Kontrol kelimesini istenen hassasiyete ayarlayın.
        // Bu, eski hassasiyeti (bit 8 ve 9, 0x300) maskeleyerek ve onu yukarıda hesaplanan hassas bayrakla değiştirerek elde edilir.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Makine boyutlu tamsayılar ve kayan değerler kullanan Bellerophon'un hızlı yolu.
///
/// Bu, bir bignum oluşturmadan önce denenebilmesi için ayrı bir işleve çıkarılır.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Tam değeri, sonuna yakın MAX_SIG ile karşılaştırıyoruz, bu sadece hızlı, ucuz bir reddetmedir (ve ayrıca kodun geri kalanını yetersizlik endişesinden kurtarır).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Hızlı yol, aritmetiğin herhangi bir ara yuvarlama olmaksızın doğru bit sayısına yuvarlanmasına bağlıdır.
    // x86 te (SSE veya SSE2 olmadan) bu, x87 FPU yığınının hassasiyetinin doğrudan 64/32 bitine yuvarlanacak şekilde değiştirilmesini gerektirir.
    // `set_precision` işlevi, global durumu değiştirerek (x87 FPU'nun kontrol kelimesi gibi) ayarlamayı gerektiren mimarilerde hassasiyeti ayarlamaya özen gösterir.
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // E <0 durumu diğer branch'ye katlanamaz.
    // Negatif güçler, ikili olarak yinelenen bir kesirli bölümle sonuçlanır, bunlar yuvarlanır ve bu da nihai sonuçta gerçek (ve bazen oldukça önemli!) Hatalara neden olur.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritma Bellerophon, önemsiz olmayan sayısal analizle gerekçelendirilen önemsiz bir koddur.
///
/// `` F '' yi 64 bit anlamlılığa sahip bir kayan noktaya yuvarlar ve onu en iyi `10^e` yaklaşımı ile (aynı kayan nokta formatında) çarpar.Bu genellikle doğru sonucu almak için yeterlidir.
/// Bununla birlikte, sonuç iki bitişik (ordinary) kayan noktasının yarısına yakın olduğunda, iki yaklaşımın çarpılmasından kaynaklanan bileşik yuvarlama hatası, sonucun birkaç bit yanlış olabileceği anlamına gelir.
/// Bu olduğunda, yinelemeli Algoritma R sorunları düzeltir.
///
/// El dalgalı "close to halfway", kağıttaki sayısal analizle hassaslaştırılmıştır.
/// Clinger'ın sözleriyle:
///
/// > En önemsiz bitin birimleriyle ifade edilen eğim, hata için kapsamlı bir sınırdır
/// > f * 10 ^ e'ye yaklaşımın kayan nokta hesaplaması sırasında birikir.(Eğim
/// > gerçek hata için bir sınır değildir, ancak yaklaşık z ve
/// > p anlamlı bitlerini kullanan olası en iyi yaklaşım.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) kasaları fast_path() te
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Eğim, n bite yuvarlarken bir fark yaratacak kadar büyük mü?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// `f * 10^e` in kayan nokta yaklaşımını iyileştiren yinelemeli bir algoritma.
///
/// Her yineleme, son sırada bir birim yaklaştırıyor; `z0` hafif bir şekilde kapalıysa, elbette yakınsaması çok uzun sürüyor.
/// Neyse ki, Bellerophon için geri dönüş olarak kullanıldığında, başlangıç yaklaşımı en fazla bir ULP kadar yanlıştır.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // `x / y` tam olarak `(f *10^e) / (m* 2^k)` olacak şekilde pozitif `x`, `y` tam sayılarını bulun.
        // Bu sadece `e` ve `k` in işaretleriyle uğraşmaktan kaçınmakla kalmaz, aynı zamanda sayıları küçültmek için `10^e` ve `2^k` için ortak olan ikisinin gücünü de ortadan kaldırırız.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Bu biraz garip yazılmış çünkü bignumlarımız negatif sayıları desteklemiyor, bu yüzden mutlak değer + işaret bilgisini kullanıyoruz.
        // M_digits ile çarpma taşamaz.
        // `x` veya `y`, taşma konusunda endişelenmemiz gerekecek kadar büyükse, `make_ratio` in fraksiyonu 2 ^ 64 veya daha fazla azalttığı kadar da büyüktürler.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Artık x'e ihtiyacınız yok, bir clone() kaydedin.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Yine de y'ye ihtiyacım var, bir kopya yap.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `f` in her zamanki gibi giriş ondalık basamaklarını temsil ettiği ve `m` in bir kayan nokta yaklaşımının anlamı olduğu `x = f` ve `y = m` verildiğinde, `x / y` oranını `(f *10^e) / (m* 2^k)` e eşit yapın, muhtemelen her ikisinin de ortak noktası olan ikisinin bir gücü ile azaltılmalıdır.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, tek farkı, kesiri ikinin bir kuvveti kadar azaltmamızdır.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Bu, pozitif `e` ve negatif `k` gerektirdiğinden taşamaz, bu yalnızca 1'e çok yakın değerler için olabilir, bu da `e` ve `k` in nispeten küçük olacağı anlamına gelir.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Bu da aşamaz, yukarıya bakın.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), yine iki ortak güç ile azaltılır.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Kavramsal olarak, Algoritma M, ondalık sayıyı kayan sayıya dönüştürmenin en basit yoludur.
///
/// `f * 10^e` e eşit bir oran oluşturuyoruz, sonra geçerli bir float değeri verene kadar ikinin üslerini atıyoruz.
/// İkili üs `k`, pay veya paydayı ikiyle çarpma sayısıdır, yani `f *10^e` her zaman `(u / v)* 2^k` e eşittir.
/// Anlamlılık bulduğumuzda, yalnızca aşağıdaki yardımcı işlevlerde yapılan bölümün kalanını inceleyerek yuvarlamamız gerekir.
///
///
/// Bu algoritma, `quick_start()` te açıklanan optimizasyonla bile süper yavaştır.
/// Bununla birlikte, taşma, yetersizlik ve normal altı sonuçlar için uyarlanan algoritmaların en basitidir.
/// Bellerophon ve Algorithm R bunaldığında bu uygulama devreye girer.
/// Alt ve taşmayı tespit etmek kolaydır: Oran hala aralık içi bir anlam değildir, ancak minimum/maximum üssüne ulaşılmıştır.
/// Taşma durumunda, basitçe sonsuza döneriz.
///
/// Alt akış ve alt normalleri idare etmek daha zordur.
/// Büyük bir sorun, minimum üs ile oranın bir anlamlılık için hala çok büyük olabilmesidir.
/// Ayrıntılar için underflow() e bakın.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME olası optimizasyonu: big_to_fp'yi genelleştirin, böylece fp_to_float(big_to_fp(u)) in eşdeğerini burada, yalnızca çift yuvarlama olmadan yapabiliriz.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Minimum üsde durmalıyız, eğer `k < T::MIN_EXP_INT` e kadar beklersek, o zaman iki çarpan farkla devre dışı kalırız.
            // Maalesef bu, minimum üslü normal sayıları özel duruma getirmek zorunda olduğumuz anlamına gelir.
            // FIXME daha zarif bir formülasyon bulur, ancak gerçekten doğru olduğundan emin olmak için `tiny-pow10` testini çalıştırın!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Bit uzunluğunu kontrol ederek çoğu Algoritma M yinelemesini atlar.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bit uzunluğu, iki temel logaritmanın bir tahminidir ve log(u / v) = log(u), log(v).
    // Tahmin en fazla 1 yanlıştır, ancak her zaman düşük bir tahmindir, bu nedenle log(u) ve log(v) teki hata aynı işarete sahiptir ve iptal edilir (her ikisi de büyükse).
    // Bu nedenle, log(u / v) için de hata en fazla birdir.
    // Hedef oran, u/v in aralık içi bir anlam içinde olduğu bir orandır.Dolayısıyla, sonlandırma koşulumuz log2(u / v), anlamlı bitler, plus/minus birdir.
    // FIXME İkinci bit'e bakmak, tahmini iyileştirebilir ve daha fazla bölünmeyi önleyebilir.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Düşük veya normal altı.Ana işleve bırak.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Taşma.Ana işleve bırak.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Oran, minimum üslü aralık içi bir anlam değildir, bu nedenle fazla bitleri yuvarlamamız ve üssü buna göre ayarlamamız gerekir.
    // Gerçek değer şimdi şu şekildedir:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(rem ile temsil edilir)
    //
    // Bu nedenle, yuvarlanan bitler!= 0.5 ULP olduğunda, yuvarlamaya kendi başlarına karar verirler.
    // Eşit olduklarında ve kalan sıfır olmadığında, değerin yine de yukarı yuvarlanması gerekir.
    // Yalnızca yuvarlanan bitler 1/2 olduğunda ve geri kalan sıfır olduğunda, yarı-çift durumumuz vardır.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Bir bölümün geri kalanına göre yuvarlanmak zorunda kalındığında, sıradan yuvarlak-çift.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}