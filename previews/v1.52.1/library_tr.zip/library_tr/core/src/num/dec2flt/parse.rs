//! Formun ondalık bir dizesini doğrulama ve ayrıştırma:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Başka bir deyişle, iki istisna dışında standart kayan noktalı sözdizimi: İşaret yok ve "inf" ve "NaN" için işlem yok.Bunlar, (super::dec2flt) sürücü fonksiyonu tarafından idare edilir.
//!
//! Geçerli girdileri tanımak nispeten kolay olsa da, bu modülün sayısız geçersiz varyasyonu da reddetmesi, asla panic'yi reddetmesi ve diğer modüllerin sırayla panic'ye (veya taşma) dayanmadığı çok sayıda kontrol gerçekleştirmesi gerekir.
//!
//! Sorunları daha da kötüleştirmek için, tüm bunlar girdinin üzerinden tek bir geçişte olur.
//! Bu nedenle, herhangi bir şeyi değiştirirken dikkatli olun ve diğer modülleri iki kez kontrol edin.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Ondalık dizenin ilginç kısımları.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Ondalık üs, 18'den az ondalık basamağa sahip olması garantilidir.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Giriş dizesinin geçerli bir kayan nokta numarası olup olmadığını kontrol eder ve öyleyse, içindeki integral kısmı, kesirli kısmı ve üssü bulun.
/// İşaretleri işlemez.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' ten önce rakam yok
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Noktadan önce veya sonra en az tek rakam gerekiyor.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Kesirli bölümden sonra gelen önemsiz şeyler
            }
        }
        _ => Invalid, // İlk rakam dizesinden sonra gelen önemsiz şeyler
    }
}

/// İlk rakam olmayan karaktere kadar ondalık basamakları ayırır.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Üs çıkarma ve hata denetimi.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Üsden sonra gelen önemsiz şeyler
    }
    if number.is_empty() {
        return Invalid; // Boş üs
    }
    // Bu noktada, kesinlikle geçerli bir rakam dizisine sahibiz.Bir `i64` e koymak çok uzun olabilir, ancak bu kadar büyükse, girdi kesinlikle sıfır veya sonsuzdur.
    // Ondalık basamaklardaki her sıfır üssü yalnızca +/-1 ayarladığından, exp=10 ^ 18'de, sonlu olmaya uzaktan bile yaklaşmak için girişin 17 eksabayt (!) sıfır olması gerekir.
    //
    // Bu tam olarak karşılamamız gereken bir kullanım durumu değil.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}