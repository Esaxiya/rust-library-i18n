//! Ondalık dizeleri IEEE 754 ikili kayan noktalı sayılara dönüştürme.
//!
//! # Sorun bildirimi
//!
//! `12.34e56` gibi bir ondalık dize veriliyor.
//! Bu dizi, integral (`12`), kesirli (`34`) ve üslü (`56`) parçalarından oluşur.Tüm parçalar isteğe bağlıdır ve eksik olduğunda sıfır olarak yorumlanır.
//!
//! Ondalık dizenin tam değerine en yakın olan IEEE 754 kayan nokta numarasını ararız.
//! Pek çok ondalık dizgenin ikinci tabanda sonlandırıcı gösterimleri olmadığı iyi bilinmektedir, bu nedenle son sırada 0.5 birimlerine yuvarlıyoruz (başka bir deyişle, mümkün olduğu kadar).
//! İki ardışık kayan nokta arasında tam olarak orta olan ondalık değerler olan bağlar, bankacı yuvarlaması olarak da bilinen yarı-çift stratejisi ile çözülür.
//!
//! Söylemeye gerek yok, bu hem uygulama karmaşıklığı hem de alınan CPU döngüleri açısından oldukça zor.
//!
//! # Implementation
//!
//! İlk olarak, işaretleri görmezden geliyoruz.Daha doğrusu, onu dönüştürme sürecinin en başında kaldırır ve en sonunda yeniden uygularız.
//! Bu, tüm edge durumlarında doğrudur, çünkü IEEE kayar sayıları sıfır etrafında simetriktir, birinin olumsuzlanması ilk biti döndürür.
//!
//! Sonra üssü ayarlayarak ondalık noktayı kaldırıyoruz: Kavramsal olarak, `12.34e56`, pozitif bir `f = 1234` ve `e = 54` tamsayısı ile tanımladığımız `1234e54` e dönüşüyor.
//! `(f, e)` gösterimi, ayrıştırma aşamasından sonraki hemen hemen tüm kodlar tarafından kullanılır.
//!
//! Daha sonra, makine boyutlu tamsayılar ve küçük, sabit boyutlu kayan nokta sayıları (önce `f32`/`f64`, sonra 64 bit anlamlılığa sahip bir tür, `Fp`) kullanan, giderek daha genel ve pahalı özel durumlardan oluşan uzun bir zincir deniyoruz.
//!
//! Tüm bunlar başarısız olduğunda, mermiyi ısırırız ve `f * 10^e` i tam olarak hesaplamayı ve en iyi yaklaşım için yinelemeli bir arama yapmayı içeren basit ama çok yavaş bir algoritmaya başvururuz.
//!
//! Öncelikle, bu modül ve alt öğeleri aşağıda açıklanan algoritmaları uygular:
//! "How to Read Floating Point Numbers Accurately" William D.
//! Clinger, çevrimiçi olarak mevcuttur: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! Ek olarak, kağıtta kullanılan ancak Rust'de (veya en azından özde) bulunmayan çok sayıda yardımcı işlev vardır.
//! Bizim sürümümüz, taşma ve yetersizlik ile başa çıkma ihtiyacı ve normal altı sayılarla başa çıkma arzusu nedeniyle ek olarak karmaşıktır.
//! Bellerophon ve Algorithm R'de taşma, alt normaller ve alt akış sorunları var.
//! Girdiler kritik bölgeye girmeden çok önce, ihtiyatlı olarak Algoritma M'ye (makalenin 8. bölümünde açıklanan değişikliklerle) geçiyoruz.
//!
//! Dikkat edilmesi gereken bir diğer husus da hemen hemen tüm fonksiyonların parametreleştirildiği `` RawFloat '' trait'dir.`f64` e ayrıştırmanın ve sonucu `f32` e aktarmanın yeterli olduğu düşünülebilir.
//! Ne yazık ki bu, içinde yaşadığımız dünya değil ve bunun, iki veya yarıya yuvarlama tabanını kullanmakla hiçbir ilgisi yok.
//!
//! Örneğin, her biri iki ondalık basamak ve dört ondalık basamak içeren bir ondalık türü temsil eden iki tür `d2` ve `d4` düşünün ve "0.01499" i girdi olarak alın.Yarım yukarı yuvarlamayı kullanalım.
//! Doğrudan iki ondalık basamağa gitmek `0.01` i verir, ancak önce dört basamağa yuvarlarsak, `0.0150` i elde ederiz ve bu daha sonra `0.02` e yuvarlanır.
//! Aynı ilke diğer işlemler için de geçerlidir, eğer 0.5 ULP doğruluğunu istiyorsanız *her şeyi* tam hassasiyetle ve yuvarlak *tam olarak bir kez, sonunda* tüm kesilmiş bitleri aynı anda dikkate alarak yapmanız gerekir.
//!
//! FIXME: Bazı kod kopyaları gerekli olsa da, belki kodun bazı kısımları karıştırılarak daha az kod kopyalanabilir.
//! Algoritmaların büyük kısımları, çıktı alınacak float türünden bağımsızdır veya yalnızca parametreler olarak iletilebilecek birkaç sabite erişime ihtiyaç duyar.
//!
//! # Other
//!
//! Dönüşüm *asla* panic olmamalıdır.
//! Kodda iddialar ve açık panics var, ancak bunlar asla tetiklenmemeli ve yalnızca dahili akıl sağlığı kontrolleri olarak hizmet etmelidir.Herhangi bir panics bir hata olarak değerlendirilmelidir.
//!
//! Birim testleri var, ancak doğruluğu sağlamakta ne yazık ki yetersizler, olası hataların yalnızca küçük bir yüzdesini kapsıyorlar.
//! Çok daha kapsamlı testler `src/etc/test-float-parse` dizininde Python komut dosyası olarak bulunur.
//!
//! Tamsayı taşmasıyla ilgili bir not: Bu dosyanın çoğu bölümü `e` ondalık üssü ile aritmetik gerçekleştirir.
//! Öncelikle, ondalık noktayı değiştiririz: İlk ondalık basamaktan önce, son ondalık basamaktan sonra vb.Dikkatsizce yapılırsa bu taşabilir.
//! "sufficient" in "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" anlamına geldiği yerde, yalnızca yeterince küçük üsleri dağıtmak için ayrıştırma alt modülüne güveniyoruz.
//! Daha büyük üsler kabul edilir, ancak onlarla aritmetik yapmıyoruz, hemen {positive,negative} {zero,infinity} e dönüştürülüyorlar.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// Bu ikisinin kendi testleri var.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// 10 tabanındaki bir dizeyi bir kayan noktaya dönüştürür.
            /// İsteğe bağlı bir ondalık üs kabul eder.
            ///
            /// Bu işlev aşağıdaki gibi dizeleri kabul eder
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', Veya eşdeğer olarak, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', Veya eşdeğer olarak, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// Baştaki ve sondaki beyaz boşluk bir hatayı temsil eder.
            ///
            /// # Grammar
            ///
            /// Aşağıdaki [EBNF] dilbilgisine uyan tüm dizeler bir [`Ok`] in döndürülmesiyle sonuçlanacaktır:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Bilinen hatalar
            ///
            /// Bazı durumlarda, geçerli bir kayan nokta oluşturması gereken bazı dizeler bunun yerine bir hata döndürür.
            /// Ayrıntılar için [issue #31407] e bakın.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, Bir dizi
            ///
            /// # Geri dönüş değeri
            ///
            /// `Err(ParseFloatError)` dize geçerli bir sayıyı temsil etmiyorsa.
            /// Aksi takdirde, `Ok(n)`, burada `n`, `src` tarafından temsil edilen kayan nokta sayısıdır.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// Bir kayan nokta ayrıştırılırken döndürülebilecek bir hata.
///
/// Bu hata, [`f32`] ve [`f64`] için [`FromStr`] uygulaması için hata türü olarak kullanılır.
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// Geri kalanını incelemeden veya doğrulamadan ondalık bir dizeyi işarete ve geri kalanına böler.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // Dize geçersizse, işareti asla kullanmayız, bu yüzden burada doğrulamamıza gerek yoktur.
        _ => (Sign::Positive, s),
    }
}

/// Ondalık bir dizeyi kayan noktalı sayıya dönüştürür.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// Ondalıktan kayan noktaya dönüşüm için ana iş gücü: Tüm ön işlemleri düzenleyin ve gerçek dönüşümü hangi algoritmanın yapması gerektiğini belirleyin.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift ondalık nokta dışında.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40, yaklaşık 385 ondalık basamağa çevrilen 1280 bit ile sınırlıdır.
    // Bunu aşarsak, çökeriz, bu yüzden çok yaklaşmadan önce hata yaparız (10 ^ 10 içinde).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // Şimdi üs, ana algoritmalarda kullanılan 16 bit'e kesinlikle uyuyor.
    let e = e as i16;
    // FIXME Bu sınırlar oldukça ihtiyatlıdır.
    // Bellerophon'un başarısızlık modlarının daha dikkatli bir analizi, büyük bir hızlanma için daha fazla durumda kullanılmasına izin verebilir.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// Yazıldığı gibi, bu kötü bir şekilde optimize eder (kodun eski bir sürümüne atıfta bulunmasına rağmen #27130 e bakın).
// `inline(always)` bunun için bir çözümdür.
// Genel olarak yalnızca iki arama sitesi vardır ve kod boyutunu daha da kötüleştirmez.

/// Üssün değiştirilmesini gerektirse bile mümkün olduğunca sıfırları soyun.
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // Bu sıfırların kırpılması hiçbir şeyi değiştirmez ancak hızlı yolu etkinleştirebilir (<15 basamak).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // 0.0 ... x ve x ... 0.0 formundaki sayıları buna göre ayarlayarak sadeleştirin.
    // Bu her zaman bir kazanç olmayabilir (muhtemelen bazı sayıları hızlı yoldan çıkarır), ancak diğer kısımları önemli ölçüde basitleştirir (özellikle değerin büyüklüğüne yaklaşarak).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// Algoritma R ve Algoritma M'nin verilen ondalık sayı üzerinde çalışırken hesaplayacağı en büyük değerin (log10) boyutunda hızlı-kirli üst sınırını döndürür.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // Bizim için en uç girdileri filtreleyen trivial_cases() ve ayrıştırıcı sayesinde burada taşma konusunda çok fazla endişelenmemize gerek yok.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // E>=0 durumunda, her iki algoritma da `f * 10^e` hakkında hesaplama yapar.
        // Algoritma R, bununla bazı karmaşık hesaplamalar yapmaya devam ediyor, ancak bunu üst sınır için göz ardı edebiliriz çünkü önceden kesri azalttığı için, orada bol miktarda tamponumuz var.
        //
        f_len + (e as u64)
    } else {
        // E <0 ise, Algoritma R aşağı yukarı aynı şeyi yapar, ancak Algoritma M farklıdır:
        // `f << k / 10^e` bir aralık içi anlamlı olacak şekilde pozitif bir k sayısı bulmaya çalışır.
        // Bu yaklaşık `2^53 *f* 10^e` <`10^17 *f* 10^e` ile sonuçlanacaktır.
        // Bunu tetikleyen bir giriş 0.33 ... 33'tür (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// Ondalık hanelere bile bakmadan bariz taşmaları ve yetersizlikleri algılar.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // Sıfırlar vardı ama simplify() tarafından çıkarıldılar
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // Bu, ceil(log10(the real value)) in kaba bir yaklaşımıdır.
    // Burada taşma konusunda çok fazla endişelenmemize gerek yok çünkü giriş uzunluğu çok küçük (en azından 2 ^ 64 ile karşılaştırıldığında) ve ayrıştırıcı zaten mutlak değeri 10 ^ 18'den büyük (hala 10 ^ 19 kısa olan üsleri işliyor) arasında 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}