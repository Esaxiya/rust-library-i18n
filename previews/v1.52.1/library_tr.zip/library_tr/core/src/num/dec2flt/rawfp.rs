//! Pozitif IEEE 754 dalgalanmalarında biraz uğraşıyor.Negatif sayılar ele alınmaz ve kullanılmasına da gerek yoktur.
//! Normal kayan noktalı sayılar, değer 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), burada N bit sayısıdır) şeklinde (frac, exp) olarak kanonik bir temsile sahiptir.
//!
//! Alt normaller biraz farklı ve tuhaftır, ancak aynı ilke geçerlidir.
//!
//! Bununla birlikte, burada, onları (sig, k) olarak f pozitif olarak temsil ediyoruz, öyle ki değer f *
//! 2 <sup>e</sup> ."hidden bit" i açık hale getirmenin yanı sıra, bu sözde mantis kayması ile üssü değiştirir.
//!
//! Başka bir deyişle, normalde kayan değerler (1) olarak yazılır, ancak burada (2) olarak yazılırlar:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! (1) e **kesirli gösterim** ve (2) e **integral gösterim** diyoruz.
//!
//! Bu modüldeki birçok işlev yalnızca normal sayıları işler.Dec2flt rutinleri, çok küçük ve çok büyük sayılar için evrensel olarak doğru yavaş yolu (Algoritma M) ihtiyatlı bir şekilde alır.
//! Bu algoritma yalnızca alt normalleri ve sıfırları işleyen next_float() e ihtiyaç duyar.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Temelde `f32` ve `f64` için tüm dönüşüm kodlarının çoğaltılmasını önlemek için bir yardımcı trait.
///
/// Bunun neden gerekli olduğunu öğrenmek için ana modülün doküman yorumuna bakın.
///
/// Diğer türler için **hiçbir zaman** uygulanmamalı veya dec2flt modülünün dışında kullanılmamalıdır.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` ve `from_bits` tarafından kullanılan tür.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Tam sayıya ham bir dönüşüm gerçekleştirir.
    fn to_bits(self) -> Self::Bits;

    /// Bir tamsayıdan ham bir dönüşüm gerçekleştirir.
    fn from_bits(v: Self::Bits) -> Self;

    /// Bu sayının dahil olduğu kategoriyi döndürür.
    fn classify(self) -> FpCategory;

    /// Mantis, üs ve tamsayı olarak işaret verir.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Şamandıranın kodunu çözer.
    fn unpack(self) -> Unpacked;

    /// Tam olarak gösterilebilen küçük bir tam sayıdan yayınlar.
    /// Panic Eğer tamsayı temsil edilemiyorsa, bu modüldeki diğer kod bunun olmasına asla izin vermemesini sağlar.
    fn from_int(x: u64) -> Self;

    /// Önceden hesaplanmış bir tablodan 10 <sup>e</sup> değerini alır.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` için Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// İsim ne diyor.
    /// Sabit kodlama, içsellerle hokkabazlık yapmaktan ve LLVM sabitinin onu katlamasını ummaktan daha kolaydır.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Taşma veya sıfır veya sıfır üretemeyen girişlerin ondalık basamaklarına muhafazakar bir sınır veya
    /// alt normaller.Muhtemelen maksimum normal değerin ondalık üssü, dolayısıyla adı.
    const MAX_NORMAL_DIGITS: usize;

    /// En önemli ondalık basamak bundan daha büyük bir basamak değerine sahipse, sayı kesinlikle sonsuza yuvarlanır.
    ///
    const INF_CUTOFF: i64;

    /// En önemli ondalık basamak bundan daha küçük bir basamak değerine sahipse, sayı kesinlikle sıfıra yuvarlanır.
    ///
    const ZERO_CUTOFF: i64;

    /// Üstteki bit sayısı.
    const EXP_BITS: u8;

    /// Anlamdaki bit sayısı, gizli bit *dahil*.
    const SIG_BITS: u8;

    /// Anlamdaki bit sayısı, gizli bit *hariç*.
    const EXPLICIT_SIG_BITS: u8;

    /// Kesirli temsilde maksimum yasal üs.
    const MAX_EXP: i16;

    /// Alt normaller hariç, kesirli temsildeki minimum yasal üs.
    const MIN_EXP: i16;

    /// `MAX_EXP` integral gösterim için, yani kayma uygulandığında.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kodlanmış (yani ofset önyargılı)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` integral gösterim için, yani kayma uygulandığında.
    const MIN_EXP_INT: i16;

    /// İntegral gösterimde maksimum normalleştirilmiş anlam.
    const MAX_SIG: u64;

    /// İntegral gösterimde minimum normalleştirilmiş anlam.
    const MIN_SIG: u64;
}

// Çoğunlukla #34344 için bir geçici çözüm.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Mantis, üs ve tamsayı olarak işaret verir.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Üst yanlılık + mantis kayması
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe, `as` in tüm platformlarda doğru şekilde yuvarlanıp yuvarlanmayacağından emin değil.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Mantis, üs ve tamsayı olarak işaret verir.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Üst yanlılık + mantis kayması
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe, `as` in tüm platformlarda doğru şekilde yuvarlanıp yuvarlanmayacağından emin değil.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Bir `Fp` i en yakın makine şamandıra türüne dönüştürür.
/// Normal altı sonuçları işlemez.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 bittir, bu nedenle xe'nin mantis kayması 63'tür
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64 bitlik anlamı yarıdan çifte T::SIG_BITS bitlerine yuvarlayın.
/// Üs taşmasını işlemez.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Mantis kaymasını ayarla
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Normalleştirilmiş sayılar için `RawFloat::unpack()` in tersi.
/// Panics anlam veya üs normalleştirilmiş sayılar için geçerli değilse.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Gizli biti kaldırın
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Üs eğilimi ve mantis kayması için üssü ayarlayın
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // İşaret bitini 0 ("+") te bırakın, sayılarımızın hepsi pozitif
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Bir normalin altı oluşturun.0 mantisine izin verilir ve sıfır oluşturur.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kodlanmış üs 0, işaret biti 0, bu yüzden bitleri yeniden yorumlamamız gerekiyor.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Fp ile yaklaşık bir bignum.0.5 ULP içinde yarıya kadar yuvarlar.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // `start` indeksinden önceki tüm bitleri keseriz, yani `start` kadar etkili bir şekilde sağa kaydırırız, yani bu aynı zamanda ihtiyacımız olan üsdür.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Kesilmiş bitlere bağlı olarak yuvarlak (half-to-even).
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Bağımsız değişkenden kesinlikle daha küçük olan en büyük kayan nokta sayısını bulur.
/// Alt normalleri, sıfır veya üstel alt akışı işlemez.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Bağımsız değişkenden kesinlikle daha büyük olan en küçük kayan nokta sayısını bulun.
// Bu işlem doyurucudur, yani next_float(inf) ==inf.
// Bu modüldeki çoğu kodun aksine, bu işlev sıfır, alt normaller ve sonsuzlukları işler.
// Ancak, buradaki diğer tüm kodlar gibi, NaN ve negatif sayılarla ilgilenmez.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Bu gerçek olamayacak kadar iyi görünüyor ama işe yarıyor.
        // 0.0 tamamen sıfır kelimesi olarak kodlanmıştır.Alt normaller 0x000m ... m'dir, burada m mantistir.
        // Özellikle, en küçük normal altı 0x0 ... 01 ve en büyüğü 0x000F ... F'dir.
        // En küçük normal sayı 0x0010 ... 0'dır, bu nedenle bu köşe kasa da çalışır.
        // Artış mantisten taşarsa, taşıma biti üssü istediğimiz gibi artırır ve mantis bitleri sıfır olur.
        // Gizli bit geleneği nedeniyle, bu da tam olarak istediğimiz şey!
        // Son olarak, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}