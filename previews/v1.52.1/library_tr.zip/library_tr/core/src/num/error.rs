//! İntegral türlerine dönüştürme için hata türleri.

use crate::convert::Infallible;
use crate::fmt;

/// Kontrol edilen bir integral tür dönüşümü başarısız olduğunda hata türü döndürüldü.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Yukarıdaki `From<Infallible> for TryFromIntError` gibi kodun, `Infallible`, `!` için bir takma ad olduğunda çalışmaya devam etmesini sağlamak için zorlamak yerine eşleştirin.
        //
        //
        match never {}
    }
}

/// Bir tamsayı ayrıştırırken döndürülebilecek bir hata.
///
/// Bu hata, [`i8::from_str_radix`] gibi temel tam sayı türlerinde `from_str_radix()` işlevleri için hata türü olarak kullanılır.
///
/// # Potansiyel nedenler
///
/// Diğer nedenlerin yanı sıra, `ParseIntError`, dizedeki baştaki veya sondaki boşluktan dolayı, örneğin standart girdiden elde edildiğinde atılabilir.
///
/// [`str::trim()`] yöntemini kullanmak, ayrıştırmadan önce boşluk kalmamasını sağlar.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Bir tamsayının ayrıştırılmasının başarısız olmasına neden olabilecek çeşitli hata türlerini depolamak için enum.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Ayrıştırılan değer boş.
    ///
    /// Diğer nedenlerin yanı sıra, bu değişken boş bir dizge ayrıştırılırken oluşturulacaktır.
    Empty,
    /// Bağlamında geçersiz bir rakam içeriyor.
    ///
    /// Diğer nedenlerin yanı sıra, bu değişken ASCII olmayan bir karakter içeren bir dizge ayrıştırılırken oluşturulacaktır.
    ///
    /// Bu varyant, bir `+` veya `-` bir dizede kendi başına veya bir sayının ortasında yanlış yerleştirildiğinde de oluşturulur.
    ///
    ///
    InvalidDigit,
    /// Tamsayı, hedef tamsayı türünde saklanamayacak kadar büyük.
    PosOverflow,
    /// Tam sayı, hedef tamsayı türünde saklanamayacak kadar küçük.
    NegOverflow,
    /// Değer Sıfırdı
    ///
    /// Bu varyant, ayrıştırma dizesi sıfır değerine sahip olduğunda yayınlanacaktır, bu sıfır olmayan türler için geçersizdir.
    ///
    Zero,
}

impl ParseIntError {
    /// Hatalı bir tamsayının ayrıştırılmasının ayrıntılı nedenini verir.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}