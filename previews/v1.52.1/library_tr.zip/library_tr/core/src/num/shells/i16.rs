//! 16 bitlik işaretli tamsayı türü için sabitler.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Yeni kod, ilişkili sabitleri doğrudan ilkel tür üzerinde kullanmalıdır.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }