//! Grisu3 algoritmasının Rust uyarlaması "Kayan Noktalı Numaraların Tam Sayılarla Hızlı ve Doğru Bir Şekilde Yazdırılması" [^ 1] bölümünde anlatılmıştır.
//! Yaklaşık 1 KB'lık önceden hesaplanmış tablo kullanır ve buna karşılık çoğu girdi için çok hızlıdır.
//!
//! [^1]: Florian Loitsch.2010. Kayan noktalı sayıların hızlı bir şekilde basılması ve
//!   tamsayılarla doğru.SİGPLAN Değil.45, 6 (Haziran 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// Gerekçe için `format_shortest_opt` teki yorumlara bakın.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// `x > 0` verildiğinde, `10^k <= x < 10^(k+1)` şeklinde `(k, 10^k)` döndürür.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Grisu için en kısa mod uygulaması.
///
/// Aksi takdirde kesin olmayan bir temsil döndürdüğünde `None` i döndürür.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // en az üç bitlik ek hassasiyete ihtiyacımız var

    // normalleştirilmiş değerlerle paylaşılan üs ile başlayın
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // `ALPHA <= minusk + plus.e + 64 <= GAMMA` gibi herhangi bir `cached = 10^minusk` bulun.
    // `plus` normalleştirildiğinden, bu `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)` anlamına gelir;
    // `ALPHA` ve `GAMMA` seçeneklerimiz göz önüne alındığında, bu `plus * cached` i `[4, 2^32)` e koyar.
    //
    // Açıkçası, `GAMMA - ALPHA` i maksimize etmek arzu edilir, böylece 10'un çok fazla önbelleğe alınmış gücüne ihtiyacımız olmaz, ancak bazı hususlar vardır:
    //
    //
    // 1. `floor(plus * cached)` i `u32` in içinde tutmak istiyoruz çünkü pahalı bir bölünmeye ihtiyaç duyuyor.
    //    (Bu gerçekten kaçınılmaz değildir, doğruluk tahmini için kalan kısım gereklidir.)
    // 2.
    // `floor(plus * cached)` in geri kalanı tekrar tekrar 10 ile çarpılır ve taşmaması gerekir.
    //
    // ilki `64 + GAMMA <= 32` verirken ikincisi `10 * 2^-ALPHA <= 2^64` verir;
    // -60 ve -32, bu kısıtlamaya sahip maksimum aralıktır ve V8 de bunları kullanır.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // ölçek fps.bu 1 ulp'lik maksimum hata verir (Teorem 5.1 ile kanıtlanmıştır).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-gerçek eksi aralığı
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // `minus` in yukarısı, `v` ve `plus`*nicelleştirilmiş* yaklaşımlardır (hata <1 ulp).
    // Hatanın pozitif veya negatif olduğunu bilmediğimiz için, eşit aralıklı iki yaklaşım kullanırız ve maksimum hata 2 ulps'dir.
    //
    // "unsafe region", başlangıçta ürettiğimiz liberal bir aralıktır.
    // "safe region", yalnızca kabul ettiğimiz muhafazakar bir aralıktır.
    // Güvenli olmayan bölgede doğru repr ile başlıyoruz ve yine güvenli bölge içinde olan `v` e en yakın repr'yi bulmaya çalışıyoruz.
    // yapamazsak pes ederiz.
    //
    let plus1 = plus.f + 1;
    // plus0 = plus.f, 1 olsun;//sadece açıklama için minus0 = minus.f + 1 olsun;//sadece açıklama için
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // paylaşılan üs

    // `plus1` i integral ve kesirli parçalara bölün.
    // Önbelleğe alınan güç `plus < 2^32` i garanti ettiğinden ve normalleştirilmiş `plus.f`, hassasiyet gereksinimi nedeniyle her zaman `2^64 - 2^4` ten daha düşük olduğundan, entegre parçaların u32 e sığması garanti edilir.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // en büyük `10^max_kappa` i `plus1` ten (dolayısıyla `plus1 < 10^(max_kappa+1)`) fazla hesaplamayın.
    // bu, aşağıdaki `kappa` in üst sınırıdır.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorem 6.2: `k` en büyük tamsayı ise st
    // `0 <= y mod 10^k <= y - x`,              daha sonra `V = floor(y / 10^k) * 10^k`, `[x, y]` içindedir ve bu aralıktaki en kısa temsillerden biridir (minimum sayıda anlamlı basamakla).
    //
    //
    // Teorem 6.2 e göre `(minus1, plus1)` arasındaki `kappa` rakam uzunluğunu bulun.
    // Teorem 6.2, bunun yerine `y mod 10^k < y - x` gerektirerek `x` i hariç tutmak için benimsenebilir.
    // (örneğin, `x` =32000, `y` =32777; `kappa` =2 çünkü `y mod 10 ^ 3=777 <y, x=777`.) algoritma, `y` i hariç tutmak için sonraki doğrulama aşamasına dayanır.
    //
    let delta1 = plus1 - minus1;
    // let delta1int=(delta1>> e) kullanım olarak;//sadece açıklama için
    let delta1frac = delta1 & ((1 << e) - 1);

    // her adımda doğruluğunu kontrol ederken, ayrılmaz parçaları işleyin.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // henüz işlenecek rakamlar
    loop {
        // `plus1 >= 10^kappa` değişmezleri olarak her zaman işlenecek en az bir rakamımız vardır:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (`remainder = plus1int % 10^(kappa+1)` i izler)
        //
        //

        // `remainder` i `10^kappa` e bölün.her ikisi de `2^-e` ile ölçeklendirilir.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; doğru `kappa` i bulduk.
            let ten_kappa = (ten_kappa as u64) << e; // paylaşılan üs için 10 ^ kappa ölçeklendirin
            return round_and_weed(
                // GÜVENLİK: Bu hafızayı yukarıda başlattık.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // tüm integral basamakları oluşturduğumuzda döngüyü kıralım.
        // tam basamak sayısı `plus1 < 10^(max_kappa+1)` olarak `max_kappa + 1` tir.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // değişmezleri geri yükle
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // her adımda doğruluğu kontrol ederken kesirli parçaları işleyin.
    // Bölünme hassasiyeti kaybedeceğinden, bu sefer tekrarlanan çarpımlara güveniyoruz.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // değişmezleri ayırmadan önce test ettiğimiz için sonraki rakam anlamlı olmalıdır, burada `m = max_kappa + 1` (integral kısımdaki rakam sayısı):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // taşmayacak `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder` i `10^kappa` e bölün.
        // her ikisi de `2^e / 10^kappa` ile ölçeklenir, bu nedenle ikincisi burada örtüktür.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // örtük bölen
            return round_and_weed(
                // GÜVENLİK: Bu hafızayı yukarıda başlattık.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // değişmezleri geri yükle
        kappa -= 1;
        remainder = r;
    }

    // `plus1` in tüm önemli basamaklarını oluşturduk, ancak bunun en uygun basamak olduğundan emin değiliz.
    // örneğin, `minus1` 3.14153 ... ve `plus1` 3.14158 ... ise, 3.14154 ten 3.14158 e 5 farklı en kısa gösterim vardır, ancak biz sadece en büyüğüne sahibiz.
    // Son basamağı art arda düşürmeli ve bunun optimal repr olup olmadığını kontrol etmeliyiz.
    // en fazla 9 aday var (..1'den ..9'a), bu yüzden bu oldukça hızlı.("rounding" aşaması)
    //
    // işlev, bu "optimal" repr'nin gerçekten ulp aralıkları içinde olup olmadığını kontrol eder ve ayrıca, "second-to-optimal" repr'nin yuvarlama hatası nedeniyle gerçekten optimal olabilmesi mümkündür.
    // her iki durumda da bu `None` i döndürür.
    // ("weeding" aşaması)
    //
    // Buradaki tüm argümanlar ortak (ancak örtük) `k` değerine göre ölçeklenir, böylece:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (ve ayrıca `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (ve ayrıca önceki değişmezlerden `threshold > plus1v`)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // 1.5 ulps içinde `v` e (aslında `plus1 - v`) iki yaklaşım üretir.
        // ortaya çıkan gösterim, her ikisine de en yakın temsil olmalıdır.
        //
        // burada `plus1 - v`, overflow/underflow ten kaçınmak için hesaplamalar `plus1` e göre yapıldığından (dolayısıyla görünüşte değiştirilmiş isimler) kullanıldığından, `plus1 - v` kullanılır.
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // son rakamı azaltın ve `v + 1 ulp` e en yakın temsilde durun.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // Başlangıçta `plus1 - plus1 % 10^kappa` e eşit olan yaklaşık rakamlar `w(n)` ile çalışıyoruz.döngü gövdesini `n` kez çalıştırdıktan sonra, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // Kontrolleri basitleştirmek için `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` i (böylece `kalan= plus1w(0)`) olarak ayarladık.
            // `plus1w(n)` in her zaman arttığını unutmayın.
            //
            // sonlandırmak için üç koşulumuz var.bunlardan herhangi biri döngünün ilerlemesini engelleyecektir, ancak yine de `v + 1 ulp` e en yakın olduğu bilinen en az bir geçerli temsilimiz var.
            // kısaca bunları TC1 ile TC3 arası olarak göstereceğiz.
            //
            // TC1: `w(n) <= v + 1 ulp`, yani bu en yakın olan son repr olabilir.
            // bu `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up` ile eşdeğerdir.
            // TC2 ile birlikte (`w(n+1)` is valid) olup olmadığını kontrol eder, bu, `plus1w(n)` hesaplamasında olası taşmayı önler.
            //
            // TC2: `w(n+1) < minus1`, yani bir sonraki repr kesinlikle `v` e yuvarlanmıyor.
            // bu, `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold` ile eşdeğerdir.
            // sol taraf taşabilir, ancak `threshold > plus1v` i biliyoruz, bu nedenle TC1 yanlışsa, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` ve bunun yerine `threshold - plus1w(n) < 10^kappa` olup olmadığını güvenli bir şekilde test edebiliriz.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, yani bir sonraki repr
            // mevcut repr'den `v + 1 ulp` e yakın değil.
            // `z(n) = plus1v_up - plus1w(n)` verildiğinde, bu `abs(z(n)) <= abs(z(n+1))` olur.Yine TC1 in yanlış olduğunu varsayarsak, `z(n) > 0` e sahibiz.dikkate almamız gereken iki durum var:
            //
            // - `z(n+1) >= 0`: TC3, `z(n) <= z(n+1)` olduğunda.
            // `plus1w(n)` arttıkça, `z(n)` azalmalıdır ve bu açıkça yanlıştır.
            // - ne zaman `z(n+1) < 0`:
            //   - TC3a: Ön koşul `plus1v_up < plus1w(n) + 10^kappa` tir.TC2 in yanlış olduğunu varsayarak, `threshold >= plus1w(n) + 10^kappa` böylece taşamaz.
            //   - TC3b: TC3, `z(n) <= -z(n+1)` olur, yani `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   olumsuzlanan TC1, `plus1v_up > plus1w(n)` verir, bu nedenle TC3a ile birleştirildiğinde taşamaz veya taşamaz.
            //
            // sonuç olarak, `TC1 || TC2 || (TC3a && TC3b)` olduğunda durmalıyız.aşağıdaki tersine eşittir, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // en kısa repr `0` ile bitemez
                plus1w += ten_kappa;
            }
        }

        // bu temsilin aynı zamanda `v - 1 ulp` e en yakın gösterim olup olmadığını kontrol edin.
        //
        // bu, tüm `plus1v_up` yerine `plus1v_down` ile değiştirilerek, `v + 1 ulp` için sonlandırma koşullarıyla tamamen aynıdır.
        // taşma analizi eşit derecede geçerlidir.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // şimdi `plus1` ve `minus1` arasında `v` e en yakın temsile sahibiz.
        // Yine de bu çok liberal, bu yüzden `plus0` ile `minus0` arasında olmayan `w(n)` i, yani `plus1 - plus1w(n) <= minus0` veya `plus1 - plus1w(n) >= plus0` i reddediyoruz.
        // `threshold = plus1 - minus1` ve `plus1 - plus0 = minus0 - minus1 = 2 ulp` in gerçeklerinden yararlanıyoruz.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Ejderha geri dönüşlü Grisu için en kısa mod uygulaması.
///
/// Bu çoğu durumda kullanılmalıdır.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // GÜVENLİK: Ödünç alma denetleyicisi, `buf` i kullanmamıza izin verecek kadar akıllı değil
    // ikinci branch'de, bu yüzden burada yaşamı aklıyoruz.
    // Ancak `buf` i yalnızca `format_shortest_opt` `None` i döndürdüyse yeniden kullanırız, bu yüzden sorun değil.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Grisu için kesin ve sabit mod uygulaması.
///
/// Aksi takdirde kesin olmayan bir temsil döndürdüğünde `None` i döndürür.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // en az üç bitlik ek hassasiyete ihtiyacımız var
    assert!(!buf.is_empty());

    // `v` i normalleştirin ve ölçeklendirin.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v` i integral ve kesirli parçalara bölün.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // hem eski `v` hem de yeni `v` (`10^-k` ile ölçeklendirilmiş) <1 ulp (Teorem 5.1) hata içeriyor.
    // Hatanın pozitif veya negatif olduğunu bilmediğimiz için, eşit aralıklı iki yaklaştırma kullanırız ve 2 ulps'lik maksimum hataya sahibiz (en kısa duruma aynı).
    //
    //
    // amaç, hem `v - 1 ulp` hem de `v + 1 ulp` için ortak olan, tam olarak yuvarlatılmış rakam dizilerini bulmaktır, böylece maksimum düzeyde kendimize güvenebiliriz.
    // bu mümkün değilse, hangisinin `v` için doğru çıktı olduğunu bilmiyoruz, bu yüzden pes edip geri çekiliyoruz.
    //
    // `err` burada `1 ulp * 2^e` olarak tanımlanır (`vfrac` teki ulp ile aynı) ve `v` ölçeklendiğinde onu ölçeklendireceğiz.
    //
    //
    //
    let mut err = 1;

    // en büyük `10^max_kappa` i `v` ten (dolayısıyla `v < 10^(max_kappa+1)`) fazla hesaplamayın.
    // bu, aşağıdaki `kappa` in üst sınırıdır.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // son rakam sınırlamasıyla çalışıyorsak, çift yuvarlamayı önlemek için gerçek oluşturmadan önce tamponu kısaltmamız gerekir.
    //
    // Yuvarlama gerçekleştiğinde tamponu tekrar genişletmemiz gerektiğine dikkat edin!
    let len = if exp <= limit {
        // oops,*bir* rakam bile üretemiyoruz.
        // Bu, diyelim ki 9.5 gibi bir şeye sahip olduğumuzda ve bu 10'a yuvarlandığında mümkündür.
        //
        // prensip olarak boş bir tamponla `possibly_round` i hemen çağırabiliriz, ancak `max_ten_kappa << e` i 10'a ölçeklendirmek taşmaya neden olabilir.
        //
        // bu nedenle burada özensiz davranıyoruz ve hata aralığını 10 kat genişletiyoruz.
        // bu, yanlış negatif oranını artıracaktır, ancak yalnızca çok,*çok* az;
        // sadece mantis 60 bitten büyük olduğunda fark edilir şekilde önemli olabilir.
        //
        // GÜVENLİK: `len=0`, bu nedenle bu hafızayı ilk kullanıma hazırlama zorunluluğu önemsizdir.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // ayrılmaz parçaları oluşturur.
    // hata tamamen kesirli olduğundan bu bölümde kontrol etmemize gerek yok.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // henüz işlenecek rakamlar
    loop {
        // değişmezleri oluşturmak için her zaman en az bir rakamımız vardır:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (`remainder = vint % 10^(kappa+1)` i izler)
        //
        //

        // `remainder` i `10^kappa` e bölün.her ikisi de `2^-e` ile ölçeklendirilir.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // tampon dolu mu?geri kalanıyla yuvarlama geçişini çalıştırın.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // GÜVENLİK: `len` i birçok bayt başlattık.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // tüm integral basamakları oluşturduğumuzda döngüyü kıralım.
        // tam basamak sayısı `plus1 < 10^(max_kappa+1)` olarak `max_kappa + 1` tir.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // değişmezleri geri yükle
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // kesirli parçaları işle.
    //
    // Prensip olarak mevcut son basamağa kadar devam edebilir ve doğruluğunu kontrol edebiliriz.
    // maalesef sonlu boyutlu tamsayılarla çalışıyoruz, bu nedenle taşmayı tespit etmek için bazı kriterlere ihtiyacımız var.
    // V8 `remainder > err` i kullanır ve `v - 1 ulp` ve `v` in ilk `i` önemli basamakları farklı olduğunda yanlış olur.
    // ancak bu, aksi takdirde geçerli olan çok fazla girişi reddeder.
    //
    // sonraki aşama doğru bir taşma tespitine sahip olduğundan, bunun yerine daha sıkı kriter kullanıyoruz:
    // `err` `10^kappa / 2` i aşana kadar devam ediyoruz, böylece `v - 1 ulp` ve `v + 1 ulp` arasındaki aralık kesinlikle iki veya daha fazla yuvarlak temsil içerir.
    //
    // bu referans için `possibly_round` in ilk iki karşılaştırması ile aynıdır.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // değişmezler, burada `m = max_kappa + 1` (integral bölümündeki basamak sayısı):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // taşmayacak `2^e * 10 < 2^64`
        err *= 10; // taşmayacak `err * 10 < 2^e * 5 < 2^64`

        // `remainder` i `10^kappa` e bölün.
        // her ikisi de `2^e / 10^kappa` ile ölçeklenir, bu nedenle ikincisi burada örtüktür.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // tampon dolu mu?geri kalanıyla yuvarlama geçişini çalıştırın.
        if i == len {
            // GÜVENLİK: `len` i birçok bayt başlattık.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // değişmezleri geri yükle
        remainder = r;
    }

    // daha fazla hesaplama işe yaramaz (`possibly_round` kesinlikle başarısız olur), bu yüzden pes ediyoruz.
    return None;

    // `v - 1 ulp` in karşılık gelen basamaklarıyla aynı olması gereken tüm istenen `v` basamaklarını oluşturduk.
    // şimdi hem `v - 1 ulp` hem de `v + 1 ulp` tarafından paylaşılan benzersiz bir temsil olup olmadığını kontrol ediyoruz;bu, üretilen basamaklarla veya bu basamakların yuvarlatılmış sürümleriyle aynı olabilir.
    //
    // aralık aynı uzunlukta birden çok temsil içeriyorsa, emin olamayız ve bunun yerine `None` i döndürmeliyiz.
    //
    // Buradaki tüm argümanlar ortak (ancak örtük) `k` değerine göre ölçeklenir, böylece:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // GÜVENLİK: `buf` in ilk `len` baytı başlatılmalıdır.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (referans için, noktalı çizgi, verilen basamak sayısındaki olası temsiller için tam değeri belirtir.)
        //
        //
        // hatası, `v - 1 ulp` ve `v + 1 ulp` arasında en az üç olası gösterim olacak kadar büyük.
        // hangisinin doğru olduğunu belirleyemiyoruz.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // aslında, 1/2 ulp iki olası gösterimi tanıtmak için yeterlidir.
        // (hem `v - 1 ulp` hem de "v + 1 ulp" için benzersiz bir temsile ihtiyacımız olduğunu unutmayın.) Bu, ilk kontrolden `ulp < ten_kappa` gibi taşmaz.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // `v + 1 ulp`, aşağı yuvarlanmış gösterime daha yakınsa (zaten `buf` te var), o zaman güvenli bir şekilde geri dönebiliriz.
        // `v - 1 ulp`*'in mevcut gösterimden* daha küçük olabileceğini, ancak `1 ulp < 10^kappa / 2` olarak bu koşulun yeterli olduğunu unutmayın:
        // `v - 1 ulp` ile mevcut gösterim arasındaki mesafe `10^kappa / 2` i aşamaz.
        //
        // koşul `remainder + ulp < 10^kappa / 2` e eşittir.
        // bu kolayca taşabileceğinden, önce `remainder < 10^kappa / 2` olup olmadığını kontrol edin.
        // `ulp < 10^kappa / 2` i zaten doğruladık, bu nedenle `10^kappa` her şeye rağmen taşmadığı sürece ikinci kontrol yeterli.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // GÜVENLİK: Arayanımız bu hafızayı başlattı.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------kalan------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // Öte yandan, `v - 1 ulp` yuvarlanmış gösterime daha yakınsa, yuvarlamalı ve geri dönmeliyiz.
        // aynı nedenle `v + 1 ulp` i kontrol etmemize gerek yok.
        //
        // koşul `remainder - ulp >= 10^kappa / 2` e eşittir.
        // yine önce `remainder > ulp` olup olmadığını kontrol ederiz (bunun `remainder >= ulp` olmadığına dikkat edin, çünkü `10^kappa` asla sıfır değildir).
        //
        // Ayrıca, `remainder - ulp <= 10^kappa` in ikinci kontrolün aşılmayacağına dikkat edin.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // GÜVENLİK: Arayanımız bu hafızayı başlatmış olmalı.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // yalnızca sabit hassasiyet talep edildiğinde ek bir rakam ekleyin.
                // Ayrıca, orijinal arabellek boşsa, ek rakamın yalnızca `exp == limit` (edge durumu) olduğunda eklenebileceğini de kontrol etmemiz gerekir.
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // GÜVENLİK: biz ve arayan kişi bu hafızayı başlattık.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // aksi takdirde mahkum oluruz (yani, `v - 1 ulp` ve `v + 1 ulp` arasındaki bazı değerler aşağı yuvarlanır ve diğerleri yuvarlanır) ve pes ederiz.
        //
        None
    }
}

/// Ejderha geri dönüşlü Grisu için kesin ve sabit mod uygulaması.
///
/// Bu çoğu durumda kullanılmalıdır.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // GÜVENLİK: Ödünç alma denetleyicisi, `buf` i kullanmamıza izin verecek kadar akıllı değil
    // ikinci branch'de, bu yüzden burada yaşamı aklıyoruz.
    // Ancak `buf` i yalnızca `format_exact_opt` `None` i döndürdüyse yeniden kullanırız, bu yüzden sorun değil.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}