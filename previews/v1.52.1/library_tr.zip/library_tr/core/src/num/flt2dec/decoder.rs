//! Kayan nokta değerini tek tek parçalara ve hata aralıklarına dönüştürür.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// İmzasız sonlu değerin kodu çözüldü, öyle ki:
///
/// - Orijinal değer `mant * 2^exp` e eşittir.
///
/// - `(mant - minus)*2^exp` ile `(mant + plus)* 2^exp` arasındaki herhangi bir sayı orijinal değere yuvarlanacaktır.
/// Aralık yalnızca `inclusive`, `true` olduğunda kapsayıcıdır.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Ölçekli mantis.
    pub mant: u64,
    /// Daha düşük hata aralığı.
    pub minus: u64,
    /// Üst hata aralığı.
    pub plus: u64,
    /// 2. tabandaki paylaşılan üs.
    pub exp: i16,
    /// Hata aralığı dahil olduğunda doğrudur.
    ///
    /// IEEE 754'te, orijinal mantis çift olduğunda bu doğrudur.
    pub inclusive: bool,
}

/// Kodlanmış işaretsiz değer.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Olumlu ya da olumsuz sonsuzluklar.
    Infinite,
    /// Sıfır, pozitif ya da negatif.
    Zero,
    /// Daha fazla kodu çözülmüş alanlara sahip sonlu sayılar.
    Finite(Decoded),
}

/// "Kodu çözülebilen" bir kayan nokta türü.
pub trait DecodableFloat: RawFloat + Copy {
    /// Minimum pozitif normalleştirilmiş değer.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Verilen kayan nokta sayısından bir işaret (negatif olduğunda doğru) ve `FullDecoded` değeri döndürür.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // komşular: (mant, 2, ifade)-(mant, ifade)-(mant + 2, ifade)
            // Float::integer_decode her zaman üssü korur, böylece mantis alt normaller için ölçeklenir.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // komşular: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // burada maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // komşular: (mant, 1, ifade)-(mant, ifade)-(mant + 1, ifade)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}