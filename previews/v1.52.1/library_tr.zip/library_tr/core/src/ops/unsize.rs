use crate::marker::Unsize;

/// Trait, bunun pointee üzerinde boyutsuzlaştırmanın gerçekleştirilebildiği biri için bir işaretçi veya sarmalayıcı olduğunu belirtir.
///
/// Daha fazla ayrıntı için [DST coercion RFC][dst-coerce] ve [the nomicon entry on coercion][nomicon-coerce] e bakın.
///
/// Yerleşik işaretçi türleri için, `T` e işaretçiler, `T: Unsize<U>` ise ince bir işaretçiden şişman bir işaretçiye dönüştürerek işaretçileri `U` e zorlayacaktır.
///
/// Özel tipler için, buradaki zorlama, `CoerceUnsized<Foo<U>> for Foo<T>` uygulamasının mevcut olması koşuluyla, `Foo<T>` i `Foo<U>` e zorlayarak çalışır.
/// Böyle bir impl yalnızca `Foo<T>`, `T` i içeren tek bir hayali olmayan veri alanına sahipse yazılabilir.
/// Bu alanın türü `Bar<T>` ise, bir `CoerceUnsized<Bar<U>> for Bar<T>` uygulaması mevcut olmalıdır.
/// Zorlama, `Bar<T>` alanını `Bar<U>` e zorlayarak ve bir `Foo<U>` oluşturmak için `Foo<T>` ten kalan alanları doldurarak çalışacaktır.
/// Bu, bir işaretçi alanına etkili bir şekilde inecek ve bunu zorlayacaktır.
///
/// Genel olarak, akıllı işaretçiler için `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` i, `T` in kendisine bağlı isteğe bağlı bir `?Sized` ile uygulayacaksınız.
/// `Cell<T>` ve `RefCell<T>` gibi `T` i doğrudan gömen sarıcı türleri için, `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` i doğrudan uygulayabilirsiniz.
///
/// Bu, `Cell<Box<T>>` gibi türlerin zorlanmasına izin verecektir.
///
/// [`Unsize`][unsize] işaretçilerin arkasındaysa DST'lere zorlanabilecek türleri işaretlemek için kullanılır.Derleyici tarafından otomatik olarak uygulanır.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * sabit U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * sabit U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* sabit U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *sabit T->* sabit U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Bu, bir yöntemin alıcı türünün gönderilebileceğini kontrol etmek için nesne güvenliği için kullanılır.
///
/// trait'nin örnek bir uygulaması:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *sabit T->* sabit U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}