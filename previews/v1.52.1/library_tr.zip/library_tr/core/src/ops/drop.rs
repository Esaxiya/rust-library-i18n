/// Yıkıcı içindeki özel kod.
///
/// Bir değere artık ihtiyaç duyulmadığında, Rust bu değer üzerinde bir "destructor" çalıştıracaktır.
/// Bir değere artık ihtiyaç duyulmamasının en yaygın yolu, kapsam dışına çıktığı zamandır.Yıkıcılar başka durumlarda yine de çalışabilir, ancak buradaki örnekler için kapsama odaklanacağız.
/// Bu diğer durumlardan bazıları hakkında bilgi edinmek için, lütfen yıkıcılarla ilgili [the reference] bölümüne bakın.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Bu yıkıcı iki bileşenden oluşur:
/// - Bu özel `Drop` trait türüne göre uygulanıyorsa, bu değer için `Drop::drop` e bir çağrı.
/// - Otomatik olarak oluşturulan "drop glue", bu değerin tüm alanlarının yıkıcılarını özyinelemeli olarak çağırır.
///
/// Rust, içerilen tüm alanların yıkıcılarını otomatik olarak çağırdığından, çoğu durumda `Drop` i uygulamanız gerekmez.
/// Ancak, örneğin bir kaynağı doğrudan yöneten türler gibi yararlı olduğu bazı durumlar vardır.
/// Bu kaynak bellek olabilir, bir dosya tanımlayıcı olabilir, bir ağ soketi olabilir.
/// Bu türden bir değer artık kullanılmayacaksa, belleği serbest bırakarak veya dosya veya soketi kapatarak kaynağını "clean up" yapmalıdır.
/// Bu bir yıkıcının işidir ve dolayısıyla `Drop::drop` in işidir.
///
/// ## Examples
///
/// Yıkıcıları çalışırken görmek için aşağıdaki programa bir göz atalım:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust, önce `_x` için `Drop::drop` i ve ardından hem `_x.one` hem de `_x.two` i çağıracak, yani bunu çalıştırmanın yazdıracağı
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// `HasTwoDrop` için `Drop` uygulamasını kaldırsak bile, alanlarının yıkıcıları hala çağrılır.
/// Bu sonuçlanır
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## `Drop::drop` i kendiniz arayamazsınız
///
/// `Drop::drop` bir değeri temizlemek için kullanıldığından, bu değeri yöntem çağrıldıktan sonra kullanmak tehlikeli olabilir.
/// `Drop::drop` girişinin sahipliğini almadığından, Rust, `Drop::drop` i doğrudan aramanıza izin vermeyerek kötüye kullanımı önler.
///
/// Başka bir deyişle, yukarıdaki örnekte `Drop::drop` i açıkça aramaya çalışırsanız, bir derleyici hatası alırsınız.
///
/// Bir değerin yıkıcısını açıkça çağırmak isterseniz, bunun yerine [`mem::drop`] kullanılabilir.
///
/// [`mem::drop`]: drop
///
/// ## Siparişi bırak
///
/// Yine de iki `HasDrop` ürünümüzden hangisi önce düşüyor?Yapılar için, bildirildikleri sırayla aynıdır: önce `one`, sonra `two`.
/// Bunu kendiniz denemek isterseniz, yukarıdaki `HasDrop` i tam sayı gibi bazı verileri içerecek şekilde değiştirebilir ve ardından `Drop` in içindeki `println!` te kullanabilirsiniz.
/// Bu davranış dil tarafından garanti edilmektedir.
///
/// Yapıların aksine, yerel değişkenler ters sırada bırakılır:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Bu yazdıracak
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Kuralların tamamı için lütfen [the reference] e bakın.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` ve `Drop` özeldir
///
/// Hem [`Copy`] hem de `Drop` i aynı tipte uygulayamazsınız.`Copy` olan türler derleyici tarafından örtük olarak çoğaltılır, bu da yıkıcıların ne zaman ve ne sıklıkla yürütüleceğini tahmin etmeyi çok zorlaştırır.
///
/// Bu nedenle, bu türlerin yıkıcıları olamaz.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Bu tür için yıkıcıyı yürütür.
    ///
    /// Bu yöntem, değer kapsam dışına çıktığında örtük olarak çağrılır ve açıkça çağrılamaz (bu, derleyici hatası [E0040] dir).
    /// Ancak, prelude'deki [`mem::drop`] işlevi, argümanın `Drop` uygulamasını çağırmak için kullanılabilir.
    ///
    /// Bu yöntem çağrıldığında, `self` henüz serbest bırakılmamıştır.
    /// Bu ancak yöntem bittikten sonra olur.
    /// Durum böyle olmasaydı, `self` sarkan bir referans olurdu.
    ///
    /// # Panics
    ///
    /// Bir [`panic!`] çözülürken `drop` i arayacağı göz önüne alındığında, `drop` uygulamasındaki herhangi bir [`panic!`] büyük olasılıkla iptal olacaktır.
    ///
    /// Bu panics olsa bile, değerin düşülmüş olarak kabul edildiğini unutmayın;
    /// `drop` in yeniden çağrılmasına neden olmamalısınız.
    /// Bu normalde derleyici tarafından otomatik olarak ele alınır, ancak güvenli olmayan kod kullanıldığında, özellikle [`ptr::drop_in_place`] kullanılırken bazen kasıtsız olarak ortaya çıkabilir.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}