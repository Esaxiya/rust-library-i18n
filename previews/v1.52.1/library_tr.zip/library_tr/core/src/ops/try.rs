/// `?` operatörünün davranışını özelleştirmek için bir trait.
///
/// `Try` i uygulayan bir tür, onu bir success/failure ikilemi açısından görmenin kanonik bir yoluna sahip olandır.
/// Bu trait, hem bu başarı veya başarısızlık değerlerinin mevcut bir örnekten çıkarılmasına hem de bir başarı veya başarısızlık değerinden yeni bir örnek oluşturmaya izin verir.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Başarılı olarak görüldüğünde bu değerin türü.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Başarısız olarak görüldüğünde bu değerin türü.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" operatörünü uygular.`Ok(t)` in dönüşü, yürütmenin normal şekilde devam etmesi gerektiği anlamına gelir ve `?` in sonucu `t` değeridir.
    /// `Err(e)` in dönüşü, yürütmenin en içteki `catch` i çevreleyen branch'ye veya işlevden dönmesi gerektiği anlamına gelir.
    ///
    /// Bir `Err(e)` sonucu döndürülürse, `e` değeri, çevreleyen kapsamın dönüş türünde "wrapped" olacaktır (kendi başına `Try` uygulaması gerekir).
    ///
    /// Özellikle, `X::from_error(From::from(e))` değeri döndürülür; burada `X`, çevreleyen işlevin dönüş türüdür.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Bileşik sonucu oluşturmak için bir hata değerini sarın.
    /// Örneğin, `Result::Err(x)` ve `Result::from_error(x)` eşdeğerdir.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Bileşik sonucu oluşturmak için bir OK değerini sarın.
    /// Örneğin, `Result::Ok(x)` ve `Result::from_ok(x)` eşdeğerdir.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}