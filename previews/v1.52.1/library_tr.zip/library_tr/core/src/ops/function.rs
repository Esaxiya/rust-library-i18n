/// Değişmez bir alıcı alan çağrı operatörünün sürümü.
///
/// `Fn` örnekleri, durum değişmeden tekrar tekrar çağrılabilir.
///
/// *Bu trait (`Fn`), [function pointers] (`fn`) ile karıştırılmamalıdır.*
///
/// `Fn` (safe) [function pointers] in yanı sıra yakalanan değişkenlere yalnızca değişmez referanslar alan veya hiçbir şey yakalamayan kapanışlar tarafından otomatik olarak uygulanır (bazı uyarılarla birlikte, daha fazla ayrıntı için belgelerine bakın).
///
/// Ek olarak, `Fn` i uygulayan her tür `F` için `&F`, `Fn` i de uygular.
///
/// Hem [`FnMut`] hem de [`FnOnce`], `Fn` in süper deneyimleri olduğundan, `Fn` in herhangi bir örneği, bir [`FnMut`] veya [`FnOnce`] in beklendiği bir parametre olarak kullanılabilir.
///
/// Fonksiyon benzeri tipte bir parametreyi kabul etmek istediğinizde ve tekrar tekrar ve mutasyona uğramadan (örneğin, aynı anda çağırırken) çağırmanız gerektiğinde, `Fn` i sınır olarak kullanın.
/// Bu kadar katı gereksinimlere ihtiyacınız yoksa sınır olarak [`FnMut`] veya [`FnOnce`] kullanın.
///
/// Bu konu hakkında daha fazla bilgi için [chapter on closures in *The Rust Programming Language*][book] e bakın.
///
/// Ayrıca `Fn` traits için özel sözdizimi de dikkate alınmalıdır (örn.
/// `Fn(usize, bool) -> usize`).Bunun teknik detaylarıyla ilgilenenler [the relevant section in the *Rustonomicon*][nomicon] e başvurabilirler.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kapatma çağrısı
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` parametresi kullanma
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // böylece regex, `&str: !FnMut` e güvenebilir.
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Çağrı işlemini gerçekleştirir.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Değişken bir alıcı alan çağrı operatörünün sürümü.
///
/// `FnMut` örnekleri tekrar tekrar çağrılabilir ve durumu değiştirebilir.
///
/// `FnMut` [`Fn`] i uygulayan tüm türlerin yanı sıra yakalanan değişkenlere değişken referanslar alan kapanışlar tarafından otomatik olarak uygulanır, örneğin, (safe) [function pointers] (çünkü `FnMut`, [`Fn`] in bir süper niteliğidir).
/// Ek olarak, `FnMut` i uygulayan her tür `F` için `&mut F`, `FnMut` i de uygular.
///
/// [`FnOnce`], `FnMut` in bir üst niteliği olduğundan, herhangi bir `FnMut` örneği, bir [`FnOnce`] in beklendiği yerde kullanılabilir ve [`Fn`], `FnMut` in bir alt özelliği olduğundan, [`Fn`] in herhangi bir örneği, `FnMut` in beklendiği yerde kullanılabilir.
///
/// Fonksiyon benzeri tipte bir parametreyi kabul etmek istediğinizde ve durumu değiştirmesine izin verirken tekrar tekrar çağırmanız gerektiğinde `FnMut` i sınır olarak kullanın.
/// Parametrenin durumu değiştirmesini istemiyorsanız, sınır olarak [`Fn`] i kullanın;tekrar tekrar aramanız gerekmiyorsa, [`FnOnce`] i kullanın.
///
/// Bu konu hakkında daha fazla bilgi için [chapter on closures in *The Rust Programming Language*][book] e bakın.
///
/// Ayrıca `Fn` traits için özel sözdizimi de dikkate alınmalıdır (örn.
/// `Fn(usize, bool) -> usize`).Bunun teknik detaylarıyla ilgilenenler [the relevant section in the *Rustonomicon*][nomicon] e başvurabilirler.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Mutabık bir şekilde yakalayan bir kapanış çağrısı
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` parametresi kullanma
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // böylece regex, `&str: !FnMut` e güvenebilir.
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Çağrı işlemini gerçekleştirir.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Bir by-value alıcısı alan çağrı operatörünün sürümü.
///
/// `FnOnce` örnekleri çağrılabilir, ancak birden çok kez çağrılamayabilir.Bu nedenle, bir tür hakkında bilinen tek şey, `FnOnce` i uyguladığıysa, yalnızca bir kez çağrılabilir.
///
/// `FnOnce` [`FnMut`] i uygulayan tüm türlerin yanı sıra yakalanan değişkenleri tüketebilecek kapamalar tarafından otomatik olarak uygulanır, örneğin, (safe) [function pointers] (`FnOnce`, [`FnMut`] in bir süper niteliğidir).
///
///
/// Hem [`Fn`] hem de [`FnMut`], `FnOnce` in alt serileri olduğundan, herhangi bir [`Fn`] veya [`FnMut`] örneği, bir `FnOnce` in beklendiği yerde kullanılabilir.
///
/// İşlev benzeri türde bir parametreyi kabul etmek istediğinizde ve yalnızca bir kez çağırmanız gerektiğinde `FnOnce` i sınır olarak kullanın.
/// Parametreyi tekrar tekrar çağırmanız gerekirse, [`FnMut`] i sınır olarak kullanın;aynı zamanda durumu değiştirmemesine de ihtiyacınız varsa, [`Fn`] i kullanın.
///
/// Bu konu hakkında daha fazla bilgi için [chapter on closures in *The Rust Programming Language*][book] e bakın.
///
/// Ayrıca `Fn` traits için özel sözdizimi de dikkate alınmalıdır (örn.
/// `Fn(usize, bool) -> usize`).Bunun teknik detaylarıyla ilgilenenler [the relevant section in the *Rustonomicon*][nomicon] e başvurabilirler.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` parametresi kullanma
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` yakalanan değişkenlerini tüketir, bu nedenle birden fazla çalıştırılamaz.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` i yeniden çağırmaya çalışmak, `func` için bir `use of moved value` hatası oluşturacaktır.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` artık bu noktada çağrılamaz
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // böylece regex, `&str: !FnMut` e güvenebilir.
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Çağrı operatörü kullanıldıktan sonra döndürülen tür.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Çağrı işlemini gerçekleştirir.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}