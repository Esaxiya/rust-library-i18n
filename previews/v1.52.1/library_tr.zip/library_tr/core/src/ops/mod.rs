//! Aşırı yüklenebilir operatörler.
//!
//! Bu traits'yi uygulamak, belirli operatörleri aşırı yüklemenize izin verir.
//!
//! Bu traits'den bazıları prelude tarafından içe aktarılır, bu nedenle her Rust programında mevcuttur.Yalnızca traits tarafından desteklenen operatörler aşırı yüklenebilir.
//! Örneğin, toplama operatörü (`+`), [`Add`] trait aracılığıyla aşırı yüklenebilir, ancak atama operatörü (`=`) in trait desteğine sahip olmadığı için, anlamını aşırı yüklemenin bir yolu yoktur.
//! Ek olarak, bu modül yeni operatörler yaratmak için herhangi bir mekanizma sağlamaz.
//! Düzensiz aşırı yükleme veya özel operatörler gerekiyorsa, Rust'nin sözdizimini genişletmek için makrolara veya derleyici eklentilerine bakmalısınız.
//!
//! traits operatörünün uygulamaları, her zamanki anlamlarını ve [operator precedence] i akılda tutarak kendi bağlamlarında şaşırtıcı olmamalıdır.
//! Örneğin, [`Mul`] i uygularken, işlemin çarpmaya biraz benzer olması (ve ilişkilendirilebilirlik gibi beklenen özellikleri paylaşması) gerekir.
//!
//! `&&` ve `||` operatörlerinin kısa devre yaptığına dikkat edin, yani yalnızca ikinci işlenenlerini sonuca katkıda bulunuyorsa değerlendirirler.Bu davranış traits tarafından uygulanamadığından, `&&` ve `||` aşırı yüklenebilir operatörler olarak desteklenmez.
//!
//! Operatörlerin çoğu, işlenenlerini değere göre alır.Yerleşik türleri içeren genel olmayan bağlamlarda, bu genellikle bir sorun değildir.
//! Bununla birlikte, bu operatörleri genel kodda kullanmak, operatörlerin tüketmesine izin vermek yerine değerlerin yeniden kullanılması gerekip gerekmediğine biraz dikkat edilmesini gerektirir.Bir seçenek, ara sıra [`clone`] kullanmaktır.
//! Diğer bir seçenek, referanslar için ek operatör uygulamaları sağlayan ilgili tiplere güvenmektir.
//! Örneğin, eklemeyi desteklemesi beklenen kullanıcı tanımlı bir `T` türü için, genel kodun gereksiz klonlama olmadan yazılabilmesi için hem `T` hem de `&T` in traits [`Add<T>`][`Add`] ve [`Add<&T>`][`Add`] i uygulaması muhtemelen iyi bir fikirdir.
//!
//!
//! # Examples
//!
//! Bu örnek, [`Add`] ve [`Sub`] i uygulayan bir `Point` yapısı oluşturur ve ardından iki "Nokta" nın eklenmesini ve çıkarılmasını gösterir.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Örnek bir uygulama için her trait'nin belgelerine bakın.
//!
//! [`Fn`], [`FnMut`] ve [`FnOnce`] traits, işlevler gibi çağrılabilen türler tarafından gerçekleştirilir.[`Fn`] in `&self`, [`FnMut`] in `&mut self` ve [`FnOnce`] in `self` aldığını unutmayın.
//! Bunlar, bir örnekte çağrılabilen üç tür yönteme karşılık gelir: referansa göre çağrı, değişken başvuruya göre çağrı ve değere göre çağrı.
//! Bu traits'nin en yaygın kullanımı, işlevleri veya kapanışları bağımsız değişken olarak alan üst düzey işlevlere sınır olarak hareket etmektir.
//!
//! Bir [`Fn`] i parametre olarak almak:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Bir [`FnMut`] i parametre olarak almak:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Bir [`FnOnce`] i parametre olarak almak:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` yakalanan değişkenlerini tüketir, bu nedenle birden fazla çalıştırılamaz
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` i tekrar çağırmaya çalışmak, `func` için bir `use of moved value` hatası oluşturacaktır.
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` artık bu noktada çağrılamaz
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;