/// Değişmez bağlamlarda (`container[index]`) indeksleme işlemleri için kullanılır.
///
/// `container[index]` aslında `*container.index(index)` için sözdizimsel şekerdir, ancak yalnızca değişmez bir değer olarak kullanıldığında.
/// Değişebilir bir değer istenirse, bunun yerine [`IndexMut`] kullanılır.
/// Bu, `value` türü [`Copy`] i uygularsa, `let value = v[index]` gibi güzel şeylere izin verir.
///
/// # Examples
///
/// Aşağıdaki örnek, `Index` i salt okunur bir `NucleotideCount` kapsayıcısında uygular ve bireysel sayımların dizin sözdizimi ile alınmasını sağlar.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// İndekslemeden sonra döndürülen tür.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Endeksleme (`container[index]`) işlemini gerçekleştirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Değişken bağlamlarda (`container[index]`) indeksleme işlemleri için kullanılır.
///
/// `container[index]` aslında `*container.index_mut(index)` için sözdizimsel şekerdir, ancak yalnızca değişebilir bir değer olarak kullanıldığında.
/// Değişmez bir değer istenirse, bunun yerine [`Index`] trait kullanılır.
/// Bu, `v[index] = value` gibi güzel şeylere izin verir.
///
/// # Examples
///
/// Her birinin değişken ve değişmez bir şekilde indekslenebildiği iki tarafı olan bir `Balance` yapısının çok basit bir uygulaması.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Bu durumda, `balance[Side::Right]`, `*balance.index(Side::Right)` için şekerdir, çünkü biz sadece*`balance[Side::Right]` okuyoruz, onu yazmıyoruz.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Ancak bu durumda `balance[Side::Left]`, `balance[Side::Left]` yazdığımız için `*balance.index_mut(Side::Left)` için şekerdir.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Değiştirilebilir indeksleme (`container[index]`) işlemini gerçekleştirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}