/// `*v` gibi değişmez referans alma işlemleri için kullanılır.
///
/// `Deref`, değişmez bağlamlarda (unary) `*` operatörü ile açıkça başvurudan uzaklaşma işlemleri için kullanılmasının yanı sıra, birçok durumda derleyici tarafından dolaylı olarak da kullanılır.
/// Bu mekanizmaya ['`Deref` coercion'][more] denir.
/// Değişebilir bağlamlarda [`DerefMut`] kullanılır.
///
/// Akıllı işaretçiler için `Deref` in uygulanması, arkalarındaki verilere erişimi kolaylaştırır, bu nedenle `Deref` i uygularlar.
/// Öte yandan, `Deref` ve [`DerefMut`] ile ilgili kurallar, akıllı işaretçileri barındıracak şekilde özel olarak tasarlanmıştır.
/// Bu nedenle,**"Deref", karışıklığı önlemek için yalnızca akıllı işaretçiler** için uygulanmalıdır.
///
/// Benzer nedenlerden dolayı **bu trait asla başarısız olmamalıdır**.`Deref` örtük olarak çağrıldığında başvuruyu kaldırma sırasındaki başarısızlık son derece kafa karıştırıcı olabilir.
///
/// # `Deref` zorlaması hakkında daha fazla bilgi
///
/// `T`, `Deref<Target = U>` i uygularsa ve `x`, `T` türünde bir değerse, o zaman:
///
/// * Değişmez bağlamlarda, `*x` (burada `T` ne referans ne de ham işaretçi değildir) `* Deref::deref(&x)` e eşdeğerdir.
/// * `&T` tipi değerler, `&U` tipi değerlere zorlanır
/// * `T` `U` türündeki tüm (immutable) yöntemlerini örtük olarak uygular.
///
/// Daha fazla ayrıntı için, [the chapter in *The Rust Programming Language*][book] in yanı sıra [the dereference operator][ref-deref-op], [method resolution] ve [type coercions] teki referans bölümlerini ziyaret edin.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Yapıyı referans alarak erişilebilen tek bir alana sahip bir yapı.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Başvurudan sonra ortaya çıkan tür.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Değeri referans alır.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` te olduğu gibi değiştirilebilir referans alma işlemleri için kullanılır.
///
/// `DerefMut`, değiştirilebilir bağlamlarda (unary) `*` operatörü ile açık başvurudan çıkarma işlemleri için kullanılmasının yanı sıra, birçok durumda derleyici tarafından dolaylı olarak da kullanılır.
/// Bu mekanizmaya ['`Deref` coercion'][more] denir.
/// Değişmez bağlamlarda [`Deref`] kullanılır.
///
/// Akıllı işaretçiler için `DerefMut` in uygulanması, arkalarındaki verilerin değiştirilmesini kolaylaştırır, bu nedenle `DerefMut` i uygularlar.
/// Öte yandan, [`Deref`] ve `DerefMut` ile ilgili kurallar, akıllı işaretçileri barındıracak şekilde özel olarak tasarlanmıştır.
/// Bu nedenle **"DerefMut", karışıklığı önlemek için yalnızca akıllı işaretçiler** için uygulanmalıdır.
///
/// Benzer nedenlerden dolayı **bu trait asla başarısız olmamalıdır**.`DerefMut` örtük olarak çağrıldığında başvuruyu kaldırma sırasındaki başarısızlık son derece kafa karıştırıcı olabilir.
///
/// # `Deref` zorlaması hakkında daha fazla bilgi
///
/// `T`, `DerefMut<Target = U>` i uygularsa ve `x`, `T` türünde bir değerse, o zaman:
///
/// * Değişebilir bağlamlarda, `*x` (burada `T` ne bir referans ne de bir ham işaretçi değildir) `* DerefMut::deref_mut(&mut x)` e eşdeğerdir.
/// * `&mut T` tipi değerler, `&mut U` tipi değerlere zorlanır
/// * `T` `U` türündeki tüm (mutable) yöntemlerini örtük olarak uygular.
///
/// Daha fazla ayrıntı için, [the chapter in *The Rust Programming Language*][book] in yanı sıra [the dereference operator][ref-deref-op], [method resolution] ve [type coercions] teki referans bölümlerini ziyaret edin.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Yapının referansını kaldırarak değiştirilebilen tek alanlı bir yapı.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Değeri mutabık bir şekilde farklılaştırır.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Bir yapının `arbitrary_self_types` özelliği olmadan yöntem alıcısı olarak kullanılabileceğini belirtir.
///
/// Bu, `Box<T>`, `Rc<T>`, `&T` ve `Pin<P>` gibi stdlib işaretçi türleri tarafından gerçekleştirilir.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}