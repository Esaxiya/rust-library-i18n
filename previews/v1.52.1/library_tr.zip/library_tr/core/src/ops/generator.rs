use crate::marker::Unpin;
use crate::pin::Pin;

/// Jeneratörün yeniden başlatılmasının sonucu.
///
/// Bu numaralandırma, `Generator::resume` yönteminden döndürülür ve bir jeneratörün olası dönüş değerlerini gösterir.
/// Şu anda bu, (`Yielded`) askıya alma noktasına veya (`Complete`) sonlandırma noktasına karşılık gelir.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Jeneratör bir değerle askıya alındı.
    ///
    /// Bu durum, bir jeneratörün askıya alındığını gösterir ve tipik olarak bir `yield` ifadesine karşılık gelir.
    /// Bu varyantta sağlanan değer, `yield` e iletilen ifadeye karşılık gelir ve üreticilerin her çıktığında bir değer sağlamasına izin verir.
    ///
    ///
    Yielded(Y),

    /// Jeneratör bir dönüş değeri ile tamamlandı.
    ///
    /// Bu durum, bir jeneratörün sağlanan değerle yürütmeyi bitirdiğini gösterir.
    /// Bir jeneratör `Complete` i döndürdüğünde, `resume` i tekrar çağırmak bir programcı hatası olarak kabul edilir.
    ///
    Complete(R),
}

/// Yerleşik jeneratör türleri tarafından uygulanan trait.
///
/// Yaygın olarak eş anlamlılar olarak da adlandırılan oluşturucular, şu anda Rust'de deneysel bir dil özelliğidir.
/// [RFC 2033] e eklenen üreticiler şu anda öncelikle async/await sözdizimi için bir yapı taşı sağlamayı amaçlamaktadır, ancak büyük olasılıkla yineleyiciler ve diğer ilkeller için ergonomik bir tanım sağlamaya genişleyecektir.
///
///
/// Jeneratörlerin sözdizimi ve anlambilim istikrarsızdır ve stabilizasyon için daha fazla RFC gerektirecektir.Ancak şu anda sözdizimi kapanış gibidir:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Kararsız kitapta jeneratörlerle ilgili daha fazla belge bulunabilir.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Bu üreticinin verdiği değer türü.
    ///
    /// Bu ilişkili tür, `yield` ifadesine ve bir jeneratörün her çıkışında döndürülmesine izin verilen değerlere karşılık gelir.
    ///
    /// Örneğin, bir üretici olarak yineleyici bu türe `T` olarak sahip olabilir ve bu tür üzerinde yinelenir.
    ///
    type Yield;

    /// Bu oluşturucunun döndürdüğü değer türü.
    ///
    /// Bu, bir `return` ifadesiyle veya dolaylı olarak bir jeneratör hazır bilgisinin son ifadesi olarak bir jeneratörden döndürülen türe karşılık gelir.
    /// Örneğin futures, tamamlanmış bir future'yi temsil ettiği için bunu `Result<T, E>` olarak kullanır.
    ///
    ///
    type Return;

    /// Bu jeneratörün çalıştırılmasına devam eder.
    ///
    /// Bu işlev, jeneratörün yürütülmesine devam edecek veya henüz yapılmamışsa, yürütmeye başlayacaktır.
    /// Bu çağrı, en son `yield` ten yürütmeye devam ederek jeneratörün son askıya alınma noktasına geri dönecektir.
    /// Jeneratör, ürün verene veya dönene kadar çalışmaya devam edecek ve bu noktada bu fonksiyon geri dönecektir.
    ///
    /// # Geri dönüş değeri
    ///
    /// Bu işlevden döndürülen `GeneratorState` sıralaması, üretecin döndükten sonra hangi durumda olduğunu gösterir.
    /// `Yielded` varyantı iade edilirse, jeneratör bir süspansiyon noktasına ulaşmıştır ve bir değer üretilmiştir.
    /// Bu durumdaki oluşturucular daha sonraki bir noktada yeniden başlatılabilir.
    ///
    /// `Complete` iade edilirse, jeneratör sağlanan değerle tamamen bitirmiştir.Jeneratörün yeniden başlatılması geçersizdir.
    ///
    /// # Panics
    ///
    /// Bu işlev, daha önce `Complete` değişkeni döndürüldükten sonra çağrılırsa panic olabilir.
    /// Dildeki jeneratör hazır değerleri, `Complete` ten sonra devam ederken panic için garanti edilirken, bu, `Generator` trait'nin tüm uygulamaları için garanti edilmez.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}