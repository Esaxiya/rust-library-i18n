//! Ödünç alınan verilerle çalışmak için bir modül.

#![stable(feature = "rust1", since = "1.0.0")]

/// Verileri ödünç almak için bir trait.
///
/// Rust'de, farklı kullanım durumları için bir türün farklı temsillerinin sağlanması yaygındır.
/// Örneğin, bir değer için depolama konumu ve yönetimi, [`Box<T>`] veya [`Rc<T>`] gibi işaretçi türleri aracılığıyla belirli bir kullanım için uygun şekilde özel olarak seçilebilir.
/// Her türle kullanılabilen bu genel sarmalayıcıların ötesinde, bazı türler, potansiyel olarak maliyetli işlevsellik sağlayan isteğe bağlı özellikler sağlar.
/// Böyle bir türe örnek, bir dizeyi temel [`str`] e genişletme yeteneği ekleyen [`String`] tir.
/// Bu, basit, değişmez bir dizge için ek bilgilerin gereksiz tutulmasını gerektirir.
///
/// Bu türler, söz konusu verilerin türüne referanslar aracılığıyla temeldeki verilere erişim sağlar.Bu türden 'ödünç aldıkları' söyleniyor.
/// Örneğin, bir [`Box<T>`] `T` olarak ödünç alınabilirken, [`String`] `str` olarak ödünç alınabilir.
///
/// Türler, `Borrow<T>` uygulanarak `T` türü olarak ödünç alınabileceklerini ve trait'nin [`borrow`] yönteminde bir `T` e referans sağlanabileceğini ifade eder.Bir tür, birkaç farklı türde ödünç almakta serbesttir.
/// Tür olarak mutabık kalınarak ödünç almak isterse-temeldeki verilerin değiştirilmesine izin verirse, ek olarak [`BorrowMut<T>`] i uygulayabilir.
///
/// Ayrıca, ek traits için uygulamalar sağlarken, bu temel tipin bir temsili olarak hareket etmelerinin bir sonucu olarak temeldeki türdekilerle aynı şekilde davranmaları gerekip gerekmediği dikkate alınmalıdır.
/// Genel kod, bu ek trait uygulamalarının aynı davranışına dayandığında genellikle `Borrow<T>` i kullanır.
/// Bu traits büyük olasılıkla ek trait bounds olarak görünecektir.
///
/// Özellikle `Eq`, `Ord` ve `Hash` ödünç alınan ve sahip olunan değerler için eşdeğer olmalıdır: `x.borrow() == y.borrow()`, `x == y` ile aynı sonucu vermelidir.
///
/// Genel kodun yalnızca ilgili `T` türüne bir referans sağlayabilen tüm türler için çalışması gerekiyorsa, daha fazla tür güvenli bir şekilde uygulayabileceği için [`AsRef<T>`] i kullanmak genellikle daha iyidir.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Veri toplama olarak [`HashMap<K, V>`] hem anahtarlara hem de değerlere sahiptir.Anahtarın gerçek verileri bir tür yönetim türüne sarılmışsa, yine de anahtarın verilerine bir referans kullanarak bir değer aramak mümkün olmalıdır.
/// Örneğin, anahtar bir dizeyse, büyük olasılıkla karma eşlemle bir [`String`] olarak depolanır, ancak bir [`&str`][`str`] kullanarak arama yapmak mümkün olmalıdır.
/// Bu nedenle, `insert` in bir `String` üzerinde çalışması gerekirken, `get` in bir `&str` kullanabilmesi gerekir.
///
/// Biraz basitleştirilmiş, `HashMap<K, V>` in ilgili parçaları şu şekildedir:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // alanlar ihmal edildi
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Karma haritanın tamamı, `K` anahtar türü üzerinde geneldir.Bu anahtarlar karma harita ile depolandığından, bu türün anahtarın verilerine sahip olması gerekir.
/// Bir anahtar-değer çifti eklenirken, haritaya böyle bir `K` verilir ve doğru karma grubunu bulması ve bu `K` e göre anahtarın zaten mevcut olup olmadığını kontrol etmesi gerekir.Bu nedenle `K: Hash + Eq` gerektirir.
///
/// Ancak haritada bir değer ararken, aranacak anahtar olarak bir `K` e bir referans sağlamak zorunda kalmak, her zaman böyle bir sahip olunan değer yaratmayı gerektirir.
/// Dize anahtarları için bu, yalnızca bir `str` in mevcut olduğu durumlarda arama yapmak için bir `String` değerinin oluşturulması gerektiği anlamına gelir.
///
/// Bunun yerine, `get` yöntemi, yukarıdaki yöntem imzasında `Q` olarak adlandırılan, temel alınan anahtar verilerinin türüne göre geneldir.`K` in `K: Borrow<Q>` i gerektirerek `Q` olarak ödünç aldığını belirtir.
/// Ek olarak `Q: Hash + Eq` gerektirerek, `K` ve `Q` in aynı sonuçları üreten `Hash` ve `Eq` traits uygulamalarına sahip olması gerekliliğini işaret eder.
///
/// `get` in uygulanması, özellikle `K` değerinden hesaplanan karma değerine dayalı olarak anahtarı yerleştirmiş olsa bile, `Q` değerinde `Hash::hash` i çağırarak anahtarın karma kümesini belirleyerek `Hash` in özdeş uygulamalarına dayanır.
///
///
/// Sonuç olarak, bir `Q` değerini saran bir `K`, `Q` ten farklı bir karma üretirse, karma harita bozulur.Örneğin, bir dizgeyi saran ancak ASCII harflerini büyük/küçük harflerini görmezden gelerek karşılaştıran bir türünüz olduğunu düşünün:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// İki eşit değerin aynı hash değerini üretmesi gerektiğinden, `Hash` uygulamasının ASCII durumunu da göz ardı etmesi gerekir:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString`, `Borrow<str>` i uygulayabilir mi?İçerdiği sahip olduğu dizge aracılığıyla bir dizi dilimine kesinlikle bir başvuru sağlayabilir.
/// Ancak `Hash` uygulaması farklı olduğu için, `str` ten farklı davranır ve bu nedenle aslında `Borrow<str>` i uygulamamalıdır.
/// Başkalarının temeldeki `str` e erişmesine izin vermek istiyorsa, bunu herhangi bir ekstra gereksinim taşımayan `AsRef<str>` aracılığıyla yapabilir.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Sahip olunan bir değerden değişmez bir şekilde ödünç alır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Verileri değişken şekilde ödünç almak için bir trait.
///
/// [`Borrow<T>`] e eşlik eden bu trait, bir türün değişken bir referans sağlayarak temel tür olarak ödünç almasına izin verir.
/// Başka bir tür olarak ödünç alma hakkında daha fazla bilgi için bkz. [`Borrow<T>`].
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Sahip olunan bir değerden mutabık bir şekilde ödünç alır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}