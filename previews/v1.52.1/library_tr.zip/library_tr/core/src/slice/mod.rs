// ignore-tidy-filelength

//! Dilim yönetimi ve manipülasyonu.
//!
//! Daha fazla ayrıntı için bkz. [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Saf rust memchr uygulaması, rust-memchr'den alınmıştır
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Bu işlev halka açıktır çünkü yığın sırasını birim test etmenin başka bir yolu yoktur.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Dilimdeki öğelerin sayısını döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SAFETY: const ses çünkü uzunluk alanını bir kullanım boyutu olarak dönüştürüyoruz (ki bu olmalı)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // GÜVENLİK: Bu güvenlidir çünkü `&[T]` ve `FatPtr<T>` aynı düzene sahiptir.
            // Bu garantiyi yalnızca `std` verebilir.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Sabit kararlı olduğunda `crate::ptr::metadata(self)` ile değiştirin.
            // Bu yazı itibariyle bu bir "Const-stable functions can only call other const-stable functions" hatasına neden olur.
            //

            // GÜVENLİK: `PtrRepr` birleşiminden değere erişmek güvenlidir çünkü * const T
            // ve PtrComponents<T>aynı hafıza düzenlerine sahip.
            // Yalnızca std bu garantiyi verebilir.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Dilimin uzunluğu 0 ise `true` döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Dilimin ilk öğesini veya boşsa `None` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Dilimin ilk öğesine veya boşsa `None` e değiştirilebilir bir işaretçi döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Dilimin ilk ve kalan tüm öğelerini veya boşsa `None` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Dilimin ilk ve kalan tüm öğelerini veya boşsa `None` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Dilimin son ve kalan tüm öğelerini veya boşsa `None` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Dilimin son ve kalan tüm öğelerini veya boşsa `None` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Dilimin son öğesini veya boşsa `None` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Dilimdeki son öğeye değiştirilebilir bir işaretçi döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Dizinin türüne bağlı olarak bir öğeye veya alt dilime bir başvuru döndürür.
    ///
    /// - Bir konum verilirse, o konumdaki öğeye veya sınır dışındaysa `None` e bir başvuru döndürür.
    ///
    /// - Bir aralık verilirse, bu aralığa karşılık gelen alt dilimi veya sınırların dışındaysa `None` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Dizin türüne (bkz. [`get`]) veya dizin sınırların dışındaysa `None` e bağlı olarak bir öğeye veya alt dilime değiştirilebilir bir başvuru döndürür.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Sınır denetimi yapmadan bir öğeye veya alt dilime bir başvuru döndürür.
    ///
    /// Güvenli bir alternatif için [`get`] e bakın.
    ///
    /// # Safety
    ///
    /// Sonuçta ortaya çıkan referans kullanılmasa bile bu yöntemin sınır dışı bir indeksle çağrılması *[tanımsız davranış]* şeklindedir.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // GÜVENLİK: Arayan kişi `get_unchecked` için güvenlik gereksinimlerinin çoğunu karşılamalıdır;
        // dilim referans alınabilir çünkü `self` güvenli bir referanstır.
        // Döndürülen işaretçi güvenlidir çünkü `SliceIndex` in impl'ları bunun garantisini vermelidir.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Sınır kontrolü yapmadan bir öğeye veya alt dilime değiştirilebilir bir başvuru döndürür.
    ///
    /// Güvenli bir alternatif için [`get_mut`] e bakın.
    ///
    /// # Safety
    ///
    /// Sonuçta ortaya çıkan referans kullanılmasa bile bu yöntemin sınır dışı bir indeksle çağrılması *[tanımsız davranış]* şeklindedir.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // GÜVENLİK: Arayan kişi `get_unchecked_mut` için güvenlik gereksinimlerini karşılamalıdır;
        // dilim referans alınabilir çünkü `self` güvenli bir referanstır.
        // Döndürülen işaretçi güvenlidir çünkü `SliceIndex` in impl'ları bunun garantisini vermelidir.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Dilimin arabelleğine ham bir işaretçi döndürür.
    ///
    /// Arayan, dilimin bu işlevin döndürdüğü işaretçiden daha uzun yaşadığından emin olmalıdır, aksi takdirde sonunda çöpü gösterecektir.
    ///
    /// Arayan kişi ayrıca, (non-transitively) işaretçisinin işaret ettiği belleğin bu işaretçi veya ondan türetilen herhangi bir işaretçi kullanılarak asla yazılmamasını (bir `UnsafeCell` içinde olanlar hariç) sağlamalıdır.
    /// Dilimin içeriğini değiştirmeniz gerekirse, [`as_mut_ptr`] kullanın.
    ///
    /// Bu dilim tarafından referans verilen kabı değiştirmek, arabelleğinin yeniden tahsis edilmesine neden olabilir ve bu da herhangi bir göstericiyi geçersiz kılar.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Dilimin arabelleğine güvenli olmayan değiştirilebilir bir işaretçi döndürür.
    ///
    /// Arayan, dilimin bu işlevin döndürdüğü işaretçiden daha uzun yaşadığından emin olmalıdır, aksi takdirde sonunda çöpü gösterecektir.
    ///
    /// Bu dilim tarafından referans verilen kabı değiştirmek, arabelleğinin yeniden tahsis edilmesine neden olabilir ve bu da herhangi bir göstericiyi geçersiz kılar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Dilimi kapsayan iki ham işaretleyiciyi döndürür.
    ///
    /// Döndürülen aralık yarı açıktır, yani bitiş işaretçisinin dilimin son öğesini *bir geçe* işaret ettiği anlamına gelir.
    /// Bu şekilde, boş bir dilim iki eşit işaretçi ile temsil edilir ve iki işaretçi arasındaki fark, dilimin boyutunu temsil eder.
    ///
    /// Bu işaretçileri kullanmayla ilgili uyarılar için [`as_ptr`] e bakın.Son işaretçi, dilimdeki geçerli bir öğeyi göstermediğinden ekstra dikkat gerektirir.
    ///
    /// Bu işlev, C++ 'da yaygın olduğu gibi, bellekteki bir dizi öğeye başvurmak için iki işaretçi kullanan yabancı arabirimlerle etkileşim için kullanışlıdır.
    ///
    ///
    /// Bir elemanın göstericisinin bu dilimin bir elemanına atıfta bulunup bulunmadığını kontrol etmek de yararlı olabilir:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // GÜVENLİK: Buradaki `add` güvenlidir, çünkü:
        //
        //   - Her iki işaretçi de aynı nesnenin parçasıdır, çünkü doğrudan nesnenin üzerine gelmek de önemlidir.
        //
        //   - Dilimin boyutu, burada belirtildiği gibi hiçbir zaman isize::MAX bayttan büyük değildir:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Dilimler adres alanının sonunu geçmediğinden, ilgili etrafta herhangi bir kaydırma yoktur.
        //
        // pointer::add belgelerine bakın.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Dilimi kapsayan iki güvenli olmayan değiştirilebilir işaretçiyi döndürür.
    ///
    /// Döndürülen aralık yarı açıktır, yani bitiş işaretçisinin dilimin son öğesini *bir geçe* işaret ettiği anlamına gelir.
    /// Bu şekilde, boş bir dilim iki eşit işaretçi ile temsil edilir ve iki işaretçi arasındaki fark, dilimin boyutunu temsil eder.
    ///
    /// Bu işaretçileri kullanmayla ilgili uyarılar için [`as_mut_ptr`] e bakın.
    /// Son işaretçi, dilimdeki geçerli bir öğeyi göstermediğinden ekstra dikkat gerektirir.
    ///
    /// Bu işlev, C++ 'da yaygın olduğu gibi, bellekteki bir dizi öğeye başvurmak için iki işaretçi kullanan yabancı arabirimlerle etkileşim için kullanışlıdır.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // GÜVENLİK: `add` in neden güvenli olduğunu görmek için yukarıdaki as_ptr_range() e bakın.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Dilimdeki iki öğeyi değiştirir.
    ///
    /// # Arguments
    ///
    /// * a, ilk elemanın dizini
    /// * b, İkinci elemanın indeksi
    ///
    /// # Panics
    ///
    /// `a` veya `b` sınırların dışındaysa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Bir vector'den iki değişken kredi alınamaz, bu nedenle bunun yerine ham işaretçiler kullanın.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // GÜVENLİK: `pa` ve `pb`, güvenli değiştirilebilir referanslardan oluşturulmuştur ve
        // dilimdeki öğelere bağlıdır ve bu nedenle geçerli ve hizalı olması garanti edilir.
        // `a` ve `b` in arkasındaki öğelere erişimin kontrol edildiğini ve sınırların dışında olduğunda panic olacağını unutmayın.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Dilimdeki öğelerin yerinde sırasını tersine çevirir.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Çok küçük türler için, normal yoldaki tüm tek tek okumalar kötü performans gösterir.
        // Etkili hizalanmamış load/store verildiğinde, daha büyük bir yığın yükleyerek ve bir kaydı ters çevirerek daha iyisini yapabiliriz.
        //

        // İdeal olarak LLVM, hizalanmamış okumaların verimli olup olmadığını (örneğin farklı ARM sürümleri arasında değiştiği için) ve en iyi yığın boyutunun ne olacağını bildiğimizden daha iyi bildiği için bunu bizim için yapacaktır.
        // Ne yazık ki, LLVM 4.0 (2017-05) ten itibaren sadece döngüyü açıyor, bu yüzden bunu kendimiz yapmamız gerekiyor.
        // (Hipotez: Tersi zahmetlidir çünkü kenarlar farklı şekilde hizalanabilir-uzunluk tuhaf olduğunda olur-bu nedenle ortada tamamen hizalanmış SIMD kullanmak için ön ve son ekleri yaymanın bir yolu yoktur.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Bir kullanımda u8'leri tersine çevirmek için llvm.bswap intrinsic'i kullanın
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // GÜVENLİK: Burada kontrol etmeniz gereken birkaç şey var:
                //
                // - Yukarıdaki cfg kontrolü nedeniyle `chunk` in 4 veya 8 olduğunu unutmayın.Yani `chunk - 1` pozitif.
                // - Döngü kontrolü garanti ettiği için `i` indeksi ile indeksleme gayet iyi
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - `ln - i - chunk = ln - (i + chunk)` indeksi ile indeksleme iyidir:
                //   - `i + chunk > 0` önemsiz bir şekilde doğrudur.
                //   - Döngü kontrolü şunları garanti eder:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, dolayısıyla çıkarma aşağı taşmaz.
                // - `read_unaligned` ve `write_unaligned` aramaları gayet iyi:
                //   - `pa` `i` indeksini gösterir burada `i < ln / 2 - (chunk - 1)` (yukarıya bakın) ve `pb`, `ln - i - chunk` indeksini gösterir, bu nedenle her ikisi de `self` in sonundan en az `chunk` birçok bayt uzaktadır.
                //
                //   - Başlatılan herhangi bir bellek geçerli `usize` tir.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // u32 te u16`ları ters çevirmek için 16`lık döndürmeyi kullanın
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // GÜVENLİK: Hizalanmamış bir u32, `i + 1 < ln` ise `i` ten okunabilir
                // (ve tabii ki `i < ln`), çünkü her eleman 2 bayt ve biz 4 okuyoruz.
                //
                // `i + chunk - 1 < ln / 2` # while koşulu
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Uzunluğun 2'ye bölünmesinden daha az olduğu için, sınırlar içinde olması gerekir.
                //
                // Bu aynı zamanda `0 < i + chunk <= ln` koşuluna her zaman saygı duyulduğu anlamına gelir ve `pb` işaretçisinin güvenli bir şekilde kullanılmasını sağlar.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // GÜVENLİK: `i`, dilim uzunluğunun yarısından daha düşüktür, bu nedenle
            // `i` ve `ln - i - 1` e erişim güvenlidir (`i`, 0'dan başlar ve `ln / 2 - 1` ten daha ileri gitmez).
            // Ortaya çıkan işaretçiler `pa` ve `pb` bu nedenle geçerlidir ve hizalıdır ve okunabilir ve yazılabilir.
            //
            //
            unsafe {
                // Güvenli takas sırasında sınır kontrolünden kaçınmak için güvensiz takas.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Dilim üzerinde bir yineleyici döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Her bir değeri değiştirmeye izin veren bir yineleyici döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// `size` uzunluğundaki tüm bitişik windows üzerinden bir yineleyici döndürür.
    /// windows çakışıyor.
    /// Dilim `size` ten daha kısaysa yineleyici hiçbir değer döndürmez.
    ///
    /// # Panics
    ///
    /// `size` 0 ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Dilim `size` ten kısaysa:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Dilimin başlangıcından başlayarak, bir seferde dilimin `chunk_size` öğelerini aşan bir yineleyici döndürür.
    ///
    /// Parçalar dilimlerdir ve örtüşmez.`chunk_size` dilimin uzunluğunu bölemezse, son parçanın uzunluğu `chunk_size` olmayacaktır.
    ///
    /// Bu yineleyicinin her zaman tam olarak `chunk_size` öğelerinin parçalarını döndüren bir varyantı için [`chunks_exact`] e ve aynı yineleyici için ancak dilimin sonundan başlayan [`rchunks`] e bakın.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Dilimin başlangıcından başlayarak, bir seferde dilimin `chunk_size` öğelerini aşan bir yineleyici döndürür.
    ///
    /// Parçalar değiştirilebilir dilimlerdir ve örtüşmez.`chunk_size` dilimin uzunluğunu bölemezse, son parçanın uzunluğu `chunk_size` olmayacaktır.
    ///
    /// Bu yineleyicinin her zaman tam olarak `chunk_size` öğelerinin parçalarını döndüren bir varyantı için [`chunks_exact_mut`] e ve aynı yineleyici için ancak dilimin sonundan başlayan [`rchunks_mut`] e bakın.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Dilimin başlangıcından başlayarak, bir seferde dilimin `chunk_size` öğelerini aşan bir yineleyici döndürür.
    ///
    /// Parçalar dilimlerdir ve örtüşmez.
    /// `chunk_size`, dilimin uzunluğunu bölemezse, `chunk_size-1` e kadar olan son elemanlar çıkarılır ve yineleyicinin `remainder` işlevinden alınabilir.
    ///
    ///
    /// Her parçanın tam olarak `chunk_size` öğelerine sahip olması nedeniyle, derleyici elde edilen kodu genellikle [`chunks`] durumunda olduğundan daha iyi optimize edebilir.
    ///
    /// Kalanı daha küçük bir yığın olarak döndüren bu yineleyicinin bir varyantı için [`chunks`] e ve aynı yineleyici için ancak dilimin sonundan başlayan [`rchunks_exact`] e bakın.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Dilimin başlangıcından başlayarak, bir seferde dilimin `chunk_size` öğelerini aşan bir yineleyici döndürür.
    ///
    /// Parçalar değiştirilebilir dilimlerdir ve örtüşmez.
    /// `chunk_size`, dilimin uzunluğunu bölemezse, `chunk_size-1` e kadar olan son elemanlar çıkarılır ve yineleyicinin `into_remainder` işlevinden alınabilir.
    ///
    ///
    /// Her parçanın tam olarak `chunk_size` öğelerine sahip olması nedeniyle, derleyici elde edilen kodu genellikle [`chunks_mut`] durumunda olduğundan daha iyi optimize edebilir.
    ///
    /// Kalanı daha küçük bir yığın olarak döndüren bu yineleyicinin bir varyantı için [`chunks_mut`] e ve aynı yineleyici için ancak dilimin sonundan başlayan [`rchunks_exact_mut`] e bakın.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Kalan olmadığını varsayarak dilimi "N" elemanlı dizilerin bir dilimine böler.
    ///
    ///
    /// # Safety
    ///
    /// Bu sadece ne zaman çağrılabilir
    /// - Dilim, tam olarak "N" elemanlı parçalara bölünür (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // GÜVENLİK: 1 öğeli parçalarda asla kalıntı kalmaz
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // GÜVENLİK: (6) dilim uzunluğu 3'ün katıdır
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Bunlar sağlam olmaz:
    /// // toplayalım: &[[_;5]]= slice.as_chunks_unchecked()//Dilim uzunluğu 5'in katı değil let parçaları:&[[_;0]]= slice.as_chunks_unchecked()//Sıfır uzunluktaki parçalara asla izin verilmez
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // GÜVENLİK: Bizim ön koşulumuz, buna tam olarak
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // GÜVENLİK: Bir dilim `new_len * N` elemanını
        // bir dilim `new_len` birçok `N` eleman parçası.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Dilimi, dilimin başlangıcından başlayarak "N" elemanlı dizilerin bir dilimine ve `N` ten kesinlikle daha kısa olan bir kalan dilime böler.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ise Panics. Bu kontrol, bu yöntem kararlı hale gelmeden önce büyük olasılıkla bir derleme zamanı hatasıyla değiştirilecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // GÜVENLİK: Zaten sıfır için panikledik ve inşaat ile güvence altına aldık
        // alt dilim uzunluğunun N'nin katı olduğu.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Dilimi, dilimin sonundan başlayarak "N" elemanlı dizilerin bir dilimine ve `N` ten kesinlikle daha kısa olan bir kalan dilime böler.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ise Panics. Bu kontrol, bu yöntem kararlı hale gelmeden önce büyük olasılıkla bir derleme zamanı hatasıyla değiştirilecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // GÜVENLİK: Zaten sıfır için panikledik ve inşaat ile güvence altına aldık
        // alt dilim uzunluğunun N'nin katı olduğu.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Dilimin başlangıcından başlayarak, bir seferde dilimin `N` öğelerini aşan bir yineleyici döndürür.
    ///
    /// Parçalar dizi referanslarıdır ve örtüşmez.
    /// `N`, dilimin uzunluğunu bölemezse, `N-1` e kadar olan son elemanlar çıkarılır ve yineleyicinin `remainder` işlevinden alınabilir.
    ///
    ///
    /// Bu yöntem, [`chunks_exact`] in sabit genel eşdeğeridir.
    ///
    /// # Panics
    ///
    /// `N` 0 ise Panics. Bu kontrol, bu yöntem kararlı hale gelmeden önce büyük olasılıkla bir derleme zamanı hatasıyla değiştirilecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Kalan olmadığını varsayarak dilimi "N" elemanlı dizilerin bir dilimine böler.
    ///
    ///
    /// # Safety
    ///
    /// Bu sadece ne zaman çağrılabilir
    /// - Dilim, tam olarak "N" elemanlı parçalara bölünür (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // GÜVENLİK: 1 öğeli parçalarda asla kalıntı kalmaz
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // GÜVENLİK: (6) dilim uzunluğu 3'ün katıdır
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Bunlar sağlam olmaz:
    /// // toplayalım: &[[_;5]]= slice.as_chunks_unchecked_mut()//Dilim uzunluğu 5'in katı değil let parçaları:&[[_;0]]= slice.as_chunks_unchecked_mut()//Sıfır uzunluktaki parçalara asla izin verilmez
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // GÜVENLİK: Bizim ön koşulumuz, buna tam olarak
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // GÜVENLİK: Bir dilim `new_len * N` elemanını
        // bir dilim `new_len` birçok `N` eleman parçası.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Dilimi, dilimin başlangıcından başlayarak "N" elemanlı dizilerin bir dilimine ve `N` ten kesinlikle daha kısa olan bir kalan dilime böler.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ise Panics. Bu kontrol, bu yöntem kararlı hale gelmeden önce büyük olasılıkla bir derleme zamanı hatasıyla değiştirilecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // GÜVENLİK: Zaten sıfır için panikledik ve inşaat ile güvence altına aldık
        // alt dilim uzunluğunun N'nin katı olduğu.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Dilimi, dilimin sonundan başlayarak "N" elemanlı dizilerin bir dilimine ve `N` ten kesinlikle daha kısa olan bir kalan dilime böler.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ise Panics. Bu kontrol, bu yöntem kararlı hale gelmeden önce büyük olasılıkla bir derleme zamanı hatasıyla değiştirilecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // GÜVENLİK: Zaten sıfır için panikledik ve inşaat ile güvence altına aldık
        // alt dilim uzunluğunun N'nin katı olduğu.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Dilimin başlangıcından başlayarak, bir seferde dilimin `N` öğelerini aşan bir yineleyici döndürür.
    ///
    /// Parçalar değiştirilebilir dizi referanslarıdır ve örtüşmez.
    /// `N`, dilimin uzunluğunu bölemezse, `N-1` e kadar olan son elemanlar çıkarılır ve yineleyicinin `into_remainder` işlevinden alınabilir.
    ///
    ///
    /// Bu yöntem, [`chunks_exact_mut`] in sabit genel eşdeğeridir.
    ///
    /// # Panics
    ///
    /// `N` 0 ise Panics. Bu kontrol, bu yöntem kararlı hale gelmeden önce büyük olasılıkla bir derleme zamanı hatasıyla değiştirilecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Dilimin başlangıcından başlayarak, bir dilimin `N` öğelerinin üst üste binen windows i ile örtüşen bir yineleyici döndürür.
    ///
    ///
    /// Bu, [`windows`] in sabit genel eşdeğeridir.
    ///
    /// `N`, dilimin boyutundan büyükse, windows döndürmez.
    ///
    /// # Panics
    ///
    /// `N` 0 ise Panics.
    /// Bu kontrol, bu yöntem kararlı hale gelmeden önce büyük olasılıkla bir derleme zamanı hatası olarak değiştirilecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Dilimin sonundan başlayarak, bir seferde dilimin `chunk_size` öğelerini aşan bir yineleyici döndürür.
    ///
    /// Parçalar dilimlerdir ve örtüşmez.`chunk_size` dilimin uzunluğunu bölemezse, son parçanın uzunluğu `chunk_size` olmayacaktır.
    ///
    /// Bu yineleyicinin her zaman tam olarak `chunk_size` öğelerinin parçalarını döndüren bir varyantı için [`rchunks_exact`] e ve aynı yineleyici için ancak dilimin başlangıcından başlayan [`chunks`] e bakın.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Dilimin sonundan başlayarak, bir seferde dilimin `chunk_size` öğelerini aşan bir yineleyici döndürür.
    ///
    /// Parçalar değiştirilebilir dilimlerdir ve örtüşmez.`chunk_size` dilimin uzunluğunu bölemezse, son parçanın uzunluğu `chunk_size` olmayacaktır.
    ///
    /// Bu yineleyicinin her zaman tam olarak `chunk_size` öğelerinin parçalarını döndüren bir varyantı için [`rchunks_exact_mut`] e ve aynı yineleyici için ancak dilimin başlangıcından başlayan [`chunks_mut`] e bakın.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Dilimin sonundan başlayarak, bir seferde dilimin `chunk_size` öğelerini aşan bir yineleyici döndürür.
    ///
    /// Parçalar dilimlerdir ve örtüşmez.
    /// `chunk_size`, dilimin uzunluğunu bölemezse, `chunk_size-1` e kadar olan son elemanlar çıkarılır ve yineleyicinin `remainder` işlevinden alınabilir.
    ///
    /// Her parçanın tam olarak `chunk_size` öğelerine sahip olması nedeniyle, derleyici elde edilen kodu genellikle [`chunks`] durumunda olduğundan daha iyi optimize edebilir.
    ///
    /// Kalanı daha küçük bir yığın olarak döndüren bu yineleyicinin bir varyantı için [`rchunks`] e ve aynı yineleyici için ancak dilimin başlangıcından başlayarak [`chunks_exact`] e bakın.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Dilimin sonundan başlayarak, bir seferde dilimin `chunk_size` öğelerini aşan bir yineleyici döndürür.
    ///
    /// Parçalar değiştirilebilir dilimlerdir ve örtüşmez.
    /// `chunk_size`, dilimin uzunluğunu bölemezse, `chunk_size-1` e kadar olan son elemanlar çıkarılır ve yineleyicinin `into_remainder` işlevinden alınabilir.
    ///
    /// Her parçanın tam olarak `chunk_size` öğelerine sahip olması nedeniyle, derleyici elde edilen kodu genellikle [`chunks_mut`] durumunda olduğundan daha iyi optimize edebilir.
    ///
    /// Kalanı daha küçük bir yığın olarak döndüren bu yineleyicinin bir varyantı için [`rchunks_mut`] e ve aynı yineleyici için ancak dilimin başlangıcından başlayarak [`chunks_exact_mut`] e bakın.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Öğeleri ayırmak için koşulu kullanarak, üst üste binmeyen öğe çalıştırmaları üreten dilim üzerinde bir yineleyici döndürür.
    ///
    /// Yüklem, kendilerini takip eden iki öğede çağrılır, bu, yüklemin `slice[0]` ve `slice[1]` te, ardından `slice[1]` ve `slice[2]` te vb. Çağrıldığı anlamına gelir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bu yöntem, sıralanmış alt dilimleri çıkarmak için kullanılabilir:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Dilim üzerinde bir yineleyici döndürerek, öğeleri ayırmak için koşulu kullanarak üst üste binmeyen değiştirilebilir öğe dizileri üretir.
    ///
    /// Yüklem, kendilerini takip eden iki öğede çağrılır, bu, yüklemin `slice[0]` ve `slice[1]` te, ardından `slice[1]` ve `slice[2]` te vb. Çağrıldığı anlamına gelir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bu yöntem, sıralanmış alt dilimleri çıkarmak için kullanılabilir:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Bir dilimi bir dizinde ikiye böler.
    ///
    /// Birincisi, `[0, mid)` teki tüm indisleri içerecektir (`mid` indeksinin kendisi hariç) ve ikincisi, `[mid, len)` teki tüm indisleri içerecektir (`len` indeksinin kendisi hariç).
    ///
    ///
    /// # Panics
    ///
    /// Panics, `mid > len` ise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // GÜVENLİK: `[ptr; mid]` ve `[mid; len]`, `self` in içindedir.
        // `from_raw_parts_mut` in gereksinimlerini karşılar.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Bir değiştirilebilir dilimi bir dizinde ikiye böler.
    ///
    /// Birincisi, `[0, mid)` teki tüm indisleri içerecektir (`mid` indeksinin kendisi hariç) ve ikincisi, `[mid, len)` teki tüm indisleri içerecektir (`len` indeksinin kendisi hariç).
    ///
    ///
    /// # Panics
    ///
    /// Panics, `mid > len` ise.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // GÜVENLİK: `[ptr; mid]` ve `[mid; len]`, `self` in içindedir.
        // `from_raw_parts_mut` in gereksinimlerini karşılar.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Sınır denetimi yapmadan bir dilimi dizinde ikiye böler.
    ///
    /// Birincisi, `[0, mid)` teki tüm indisleri içerecektir (`mid` indeksinin kendisi hariç) ve ikincisi, `[mid, len)` teki tüm indisleri içerecektir (`len` indeksinin kendisi hariç).
    ///
    ///
    /// Güvenli bir alternatif için [`split_at`] e bakın.
    ///
    /// # Safety
    ///
    /// Sonuçta ortaya çıkan başvuru kullanılmasa bile bu yöntemin sınır dışı bir indeksle çağrılması *[tanımsız davranış]* şeklindedir.Arayan, `0 <= mid <= self.len()` in olduğundan emin olmalıdır.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // GÜVENLİK: Arayan kişinin `0 <= mid <= self.len()` in
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Sınır kontrolü yapmadan değiştirilebilir bir dilimi bir dizinde ikiye böler.
    ///
    /// Birincisi, `[0, mid)` teki tüm indisleri içerecektir (`mid` indeksinin kendisi hariç) ve ikincisi, `[mid, len)` teki tüm indisleri içerecektir (`len` indeksinin kendisi hariç).
    ///
    ///
    /// Güvenli bir alternatif için [`split_at_mut`] e bakın.
    ///
    /// # Safety
    ///
    /// Sonuçta ortaya çıkan başvuru kullanılmasa bile bu yöntemin sınır dışı bir indeksle çağrılması *[tanımsız davranış]* şeklindedir.Arayan, `0 <= mid <= self.len()` in olduğundan emin olmalıdır.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // GÜVENLİK: Arayan kişi `0 <= mid <= self.len()` i kontrol etmelidir.
        //
        // `[ptr; mid]` ve `[mid; len]` üst üste binmiyor, bu nedenle değişken bir referans döndürmek sorun değil.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred` ile eşleşen öğelerle ayrılmış alt dilimler üzerinden bir yineleyici döndürür.
    /// Eşleşen öğe, alt bölümlerde yer almıyor.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// İlk öğe eşleşirse, yineleyici tarafından döndürülen ilk öğe boş bir dilim olacaktır.
    /// Benzer şekilde, dilimdeki son öğe eşleşirse, boş bir dilim yineleyici tarafından döndürülen son öğe olacaktır:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Eşleşen iki öğe doğrudan bitişikse, aralarında boş bir dilim olacaktır:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred` ile eşleşen öğelerle ayrılmış, değiştirilebilir alt dilimler üzerinden bir yineleyici döndürür.
    /// Eşleşen öğe, alt bölümlerde yer almıyor.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred` ile eşleşen öğelerle ayrılmış alt dilimler üzerinden bir yineleyici döndürür.
    /// Eşleşen öğe, bir sonlandırıcı olarak önceki alt dilimin sonunda yer alır.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Dilimin son öğesi eşleşirse, bu öğe önceki dilimin sonlandırıcısı olarak kabul edilecektir.
    ///
    /// Bu dilim, yineleyici tarafından döndürülen son öğe olacaktır.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred` ile eşleşen öğelerle ayrılmış, değiştirilebilir alt dilimler üzerinden bir yineleyici döndürür.
    /// Eşleşen öğe, bir sonlandırıcı olarak önceki alt dilimde yer alır.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Dilimin sonundan başlayıp geriye doğru çalışarak, `pred` ile eşleşen öğelerle ayrılmış alt dilimler üzerinde bir yineleyici döndürür.
    /// Eşleşen öğe, alt bölümlerde yer almıyor.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()` te olduğu gibi, ilk veya son öğe eşleşirse, boş bir dilim yineleyici tarafından döndürülen ilk (veya son) öğe olacaktır.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Dilimin sonundan başlayıp geriye doğru çalışarak, `pred` ile eşleşen öğelerle ayrılmış, değiştirilebilir alt dilimler üzerinden bir yineleyici döndürür.
    /// Eşleşen öğe, alt bölümlerde yer almıyor.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// En fazla `n` öğe döndürmekle sınırlı, `pred` ile eşleşen öğelerle ayrılmış alt dilimler üzerinden bir yineleyici döndürür.
    /// Eşleşen öğe, alt bölümlerde yer almıyor.
    ///
    /// Döndürülen son öğe, varsa, dilimin kalanını içerecektir.
    ///
    /// # Examples
    ///
    /// Dilimi 3'e bölünebilen sayılara bölünmüş olarak bir kez yazdırın (yani, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// En fazla `n` öğe döndürmekle sınırlı, `pred` ile eşleşen öğelerle ayrılmış alt dilimler üzerinden bir yineleyici döndürür.
    /// Eşleşen öğe, alt bölümlerde yer almıyor.
    ///
    /// Döndürülen son öğe, varsa, dilimin kalanını içerecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// En çok `n` öğe döndürmekle sınırlı `pred` ile eşleşen öğelerle ayrılmış alt dilimler üzerinden bir yineleyici döndürür.
    /// Bu, dilimin sonunda başlar ve geriye doğru çalışır.
    /// Eşleşen öğe, alt bölümlerde yer almıyor.
    ///
    /// Döndürülen son öğe, varsa, dilimin kalanını içerecektir.
    ///
    /// # Examples
    ///
    /// Dilim bölmesini, sondan başlayarak 3'e bölünebilen sayılarla (yani `[50]`, `[10, 40, 30, 20]`) bir kez yazdırın:
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// En çok `n` öğe döndürmekle sınırlı `pred` ile eşleşen öğelerle ayrılmış alt dilimler üzerinden bir yineleyici döndürür.
    /// Bu, dilimin sonunda başlar ve geriye doğru çalışır.
    /// Eşleşen öğe, alt bölümlerde yer almıyor.
    ///
    /// Döndürülen son öğe, varsa, dilimin kalanını içerecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Dilim, verilen değere sahip bir öğe içeriyorsa `true` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Bir `&T` iniz yoksa, ancak yalnızca `T: Borrow<U>` e sahip bir `&U` iniz varsa (ör.
    /// `String: Borrow<str>`), `iter().any` i kullanabilirsiniz:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` dilimi
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` ile ara
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `needle`, dilimin bir önekiyse, `true` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// `needle` boş bir dilimse her zaman `true` döndürür:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// `needle`, dilimin bir sonekiyse `true` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// `needle` boş bir dilimse her zaman `true` döndürür:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Öneki kaldırılmış bir alt dilimi döndürür.
    ///
    /// Dilim `prefix` ile başlıyorsa, önekten sonra alt dilimi `Some` e sarılmış olarak döndürür.
    /// `prefix` boşsa, orijinal dilimi döndürmeniz yeterlidir.
    ///
    /// Dilim `prefix` ile başlamazsa, `None` döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // SlicePattern daha karmaşık hale geldiğinde bu işlevin yeniden yazılması gerekecektir.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Sonek kaldırılmış bir alt dilimi döndürür.
    ///
    /// Dilim `suffix` ile biterse, sonekten önce alt dilimi `Some` e sarılmış olarak döndürür.
    /// `suffix` boşsa, orijinal dilimi döndürmeniz yeterlidir.
    ///
    /// Dilim `suffix` ile bitmezse, `None` döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // SlicePattern daha karmaşık hale geldiğinde bu işlevin yeniden yazılması gerekecektir.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// İkili, belirli bir eleman için bu sıralanmış dilimi arar.
    ///
    /// Değer bulunursa, eşleşen öğenin dizinini içeren [`Result::Ok`] döndürülür.
    /// Birden fazla eşleşme varsa, eşleşmelerden herhangi biri iade edilebilir.
    /// Değer bulunmazsa, sıralı düzen korunurken eşleşen bir öğenin eklenebileceği dizini içeren [`Result::Err`] döndürülür.
    ///
    ///
    /// Ayrıca bkz. [`binary_search_by`], [`binary_search_by_key`] ve [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Bir dizi dört unsuru arar.
    /// Birincisi, benzersiz bir şekilde belirlenmiş bir konumla bulunur;ikinci ve üçüncü bulunamadı;dördüncü, `[1, 4]` teki herhangi bir konumla eşleşebilir.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Sıralama düzenini korurken sıralı bir vector'ye bir öğe eklemek isterseniz:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// İkili, bu sıralanmış dilimi bir karşılaştırıcı işlevi ile arar.
    ///
    /// Karşılaştırıcı işlevi, temel alınan dilimin sıralama düzeniyle tutarlı bir sıra uygulamalı ve bağımsız değişkeninin istenen hedef olarak `Less`, `Equal` veya `Greater` olup olmadığını gösteren bir sipariş kodu döndürmelidir.
    ///
    ///
    /// Değer bulunursa, eşleşen öğenin dizinini içeren [`Result::Ok`] döndürülür.Birden fazla eşleşme varsa, eşleşmelerden herhangi biri iade edilebilir.
    /// Değer bulunmazsa, sıralı düzen korunurken eşleşen bir öğenin eklenebileceği dizini içeren [`Result::Err`] döndürülür.
    ///
    /// Ayrıca bkz. [`binary_search`], [`binary_search_by_key`] ve [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Bir dizi dört unsuru arar.Birincisi, benzersiz bir şekilde belirlenmiş bir konumla bulunur;ikinci ve üçüncü bulunamadı;dördüncü, `[1, 4]` teki herhangi bir konumla eşleşebilir.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // GÜVENLİK: Çağrı aşağıdaki değişmezler tarafından güvenli hale getirilir:
            // - `mid >= 0`
            // - `mid < size`: `mid`, `[left; right)` ile sınırlıdır.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Eşleştirme yerine if/else kontrol akışını kullanmamızın nedeni, eşleştirmenin karşılaştırma işlemlerini yeniden sıralamasıdır, bu da mükemmel derecede duyarlıdır.
            //
            // u8 için x86 asm: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// İkili, bu sıralanmış dilimi bir anahtar çıkarma işleviyle arar.
    ///
    /// Dilimin anahtara göre sıralandığını varsayar, örneğin [`sort_by_key`] ile aynı anahtar çıkarma işlevi kullanılarak.
    ///
    /// Değer bulunursa, eşleşen öğenin dizinini içeren [`Result::Ok`] döndürülür.
    /// Birden fazla eşleşme varsa, eşleşmelerden herhangi biri iade edilebilir.
    /// Değer bulunmazsa, sıralı düzen korunurken eşleşen bir öğenin eklenebileceği dizini içeren [`Result::Err`] döndürülür.
    ///
    ///
    /// Ayrıca bkz. [`binary_search`], [`binary_search_by`] ve [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// İkinci öğelerine göre sıralanmış bir dilim çiftinde dört öğeden oluşan bir dizi arar.
    /// Birincisi, benzersiz bir şekilde belirlenmiş bir konumla bulunur;ikinci ve üçüncü bulunamadı;dördüncü, `[1, 4]` teki herhangi bir konumla eşleşebilir.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // `slice::sort_by_key`, crate `alloc` te olduğu için Lint rustdoc::broken_intra_doc_links e izin verilir ve bu nedenle `core` i oluştururken henüz mevcut değildir.
    //
    // aşağı akış crate: #74481 e bağlantılar.İlkeller yalnızca libstd (#73423) te belgelendiğinden, bu pratikte asla kopuk bağlantılara yol açmaz.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Dilimi sıralar ancak eşit öğelerin sırasını koruyamayabilir.
    ///
    /// Bu sıralama istikrarsızdır (yani eşit öğeleri yeniden sıralayabilir), yerinde (yani ayırmaz) ve *O*(*n*\*log(* n*)) en kötü durumdur.
    ///
    /// # Mevcut uygulama
    ///
    /// Mevcut algoritma, belirli desenlere sahip dilimlerde doğrusal zaman elde ederken, rasgele sıralamanın hızlı ortalama durumunu en hızlı yığın sıralaması ile birleştiren Orson Peters tarafından geliştirilen [pattern-defeating quicksort][pdqsort] e dayanmaktadır.
    /// Dejenere durumlardan kaçınmak için bir miktar randomizasyon kullanır, ancak her zaman deterministik davranış sağlamak için sabit bir seed ile.
    ///
    /// Birkaç özel durum haricinde, örneğin dilim birleştirilmiş birkaç sıralı diziden oluştuğunda tipik olarak kararlı sıralamadan daha hızlıdır.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Dilimi bir karşılaştırıcı işlevle sıralar, ancak eşit öğelerin sırasını koruyamayabilir.
    ///
    /// Bu sıralama istikrarsızdır (yani eşit öğeleri yeniden sıralayabilir), yerinde (yani ayırmaz) ve *O*(*n*\*log(* n*)) en kötü durumdur.
    ///
    /// Karşılaştırıcı işlevi, dilimdeki öğeler için toplam bir sıralama tanımlamalıdır.Sıralama toplam değilse, elemanların sırası belirtilmez.Bir sipariş, şu ise toplam bir sipariştir (tüm `a`, `b` ve `c` için):
    ///
    /// * toplam ve antisimetrik: `a < b`, `a == b` veya `a > b` ten tam olarak biri doğrudur ve
    /// * geçişli, `a < b` ve `b < c`, `a < c` anlamına gelir.Aynısı hem `==` hem de `>` için geçerli olmalıdır.
    ///
    /// Örneğin, [`f64`], [`Ord`] i `NaN != NaN` nedeniyle gerçekleştirmezken, dilimde `NaN` bulunmadığını bildiğimizde `partial_cmp` i sıralama işlevimiz olarak kullanabiliriz.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Mevcut uygulama
    ///
    /// Mevcut algoritma, belirli desenlere sahip dilimlerde doğrusal zaman elde ederken, rasgele sıralamanın hızlı ortalama durumunu en hızlı yığın sıralaması ile birleştiren Orson Peters tarafından geliştirilen [pattern-defeating quicksort][pdqsort] e dayanmaktadır.
    /// Dejenere durumlardan kaçınmak için bir miktar randomizasyon kullanır, ancak her zaman deterministik davranış sağlamak için sabit bir seed ile.
    ///
    /// Birkaç özel durum haricinde, örneğin dilim birleştirilmiş birkaç sıralı diziden oluştuğunda tipik olarak kararlı sıralamadan daha hızlıdır.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ters sıralama
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Dilimi bir anahtar çıkarma işleviyle sıralar, ancak eşit öğelerin sırasını koruyamayabilir.
    ///
    /// Bu sıralama istikrarsızdır (yani eşit öğeleri yeniden sıralayabilir), yerinde (yani ayırmaz) ve *O*(m\* * n *\* log(*n*)) en kötü durum, burada anahtar işlevi *O*(*m*).
    ///
    /// # Mevcut uygulama
    ///
    /// Mevcut algoritma, belirli desenlere sahip dilimlerde doğrusal zaman elde ederken, rasgele sıralamanın hızlı ortalama durumunu en hızlı yığın sıralaması ile birleştiren Orson Peters tarafından geliştirilen [pattern-defeating quicksort][pdqsort] e dayanmaktadır.
    /// Dejenere durumlardan kaçınmak için bir miktar randomizasyon kullanır, ancak her zaman deterministik davranış sağlamak için sabit bir seed ile.
    ///
    /// Anahtar arama stratejisi nedeniyle, [`sort_unstable_by_key`](#method.sort_unstable_by_key), anahtar işlevinin pahalı olduğu durumlarda muhtemelen [`sort_by_cached_key`](#method.sort_by_cached_key) ten daha yavaş olacaktır.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Dilimi, `index` teki öğe son sıralanmış konumunda olacak şekilde yeniden sıralayın.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Dilimi, `index` teki öğe son sıralanmış konumunda olacak şekilde bir karşılaştırma işleviyle yeniden sıralayın.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Dilimi, `index` teki öğe son sıralanmış konumunda olacak şekilde anahtar çıkarma işleviyle yeniden sıralayın.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Dilimi, `index` teki öğe son sıralanmış konumunda olacak şekilde yeniden sıralayın.
    ///
    /// Bu yeniden sıralama, `i < index` konumundaki herhangi bir değerin `j > index` konumundaki herhangi bir değerden daha küçük veya ona eşit olacağı ek özelliğe sahiptir.
    /// Ek olarak, bu yeniden sıralama istikrarsızdır (ör.
    /// herhangi bir sayıda eşit eleman, yerinde (yani, `index` konumunda sonlanabilir)
    /// ayırmaz) ve *O*(*n*) en kötü durum.
    /// Bu işlev, diğer kitaplıklarda "kth element" olarak da bilinir.
    /// Aşağıdaki değerlerin üçlüsünü döndürür: verilen dizindekinden küçük tüm öğeler, verilen dizindeki değer ve verilen dizindekinden daha büyük tüm öğeler.
    ///
    ///
    /// # Mevcut uygulama
    ///
    /// Mevcut algoritma, [`sort_unstable`] için kullanılan aynı hızlı sıralama algoritmasının hızlı seçim kısmına dayanmaktadır.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, `index >= len()` olduğunda, boş dilimlerde her zaman panics anlamına gelir.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Medyanı bulun
    /// v.select_nth_unstable(2);
    ///
    /// // Belirtilen dizini sıralama şeklimize bağlı olarak, yalnızca dilimin aşağıdakilerden biri olacağı garanti edilmektedir.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Dilimi, `index` teki öğe son sıralanmış konumunda olacak şekilde bir karşılaştırma işleviyle yeniden sıralayın.
    ///
    /// Bu yeniden sıralama, `i < index` konumundaki herhangi bir değerin, karşılaştırma işlevi kullanılarak `j > index` konumundaki herhangi bir değerden daha küçük veya bu değere eşit olacağı ek özelliğe sahiptir.
    /// Ek olarak, bu yeniden sıralama istikrarsızdır (yani, herhangi bir sayıda eşit eleman `index` konumunda sona erebilir), yerinde (yani tahsis etmez) ve *O*(*n*) en kötü durumdur.
    /// Bu işlev, diğer kitaplıklarda "kth element" olarak da bilinir.
    /// Sağlanan karşılaştırma işlevini kullanarak, aşağıdaki değerlerin üçlüsünü döndürür: verilen dizindeki olandan küçük tüm öğeler, verilen dizindeki değer ve verilen dizindekinden daha büyük olan tüm öğeler.
    ///
    ///
    /// # Mevcut uygulama
    ///
    /// Mevcut algoritma, [`sort_unstable`] için kullanılan aynı hızlı sıralama algoritmasının hızlı seçim kısmına dayanmaktadır.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, `index >= len()` olduğunda, boş dilimlerde her zaman panics anlamına gelir.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Medyanı, dilim azalan sırada sıralanmış gibi bulun.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Belirtilen dizini sıralama şeklimize bağlı olarak, yalnızca dilimin aşağıdakilerden biri olacağı garanti edilmektedir.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Dilimi, `index` teki öğe son sıralanmış konumunda olacak şekilde anahtar çıkarma işleviyle yeniden sıralayın.
    ///
    /// Bu yeniden sıralama, anahtar çıkarma işlevi kullanılarak `i < index` konumundaki herhangi bir değerin `j > index` konumundaki herhangi bir değerden daha küçük veya bu değere eşit olacağı ek özelliğe sahiptir.
    /// Ek olarak, bu yeniden sıralama istikrarsızdır (yani, herhangi bir sayıda eşit eleman `index` konumunda sona erebilir), yerinde (yani tahsis etmez) ve *O*(*n*) en kötü durumdur.
    /// Bu işlev, diğer kitaplıklarda "kth element" olarak da bilinir.
    /// Sağlanan anahtar çıkarma işlevini kullanarak, aşağıdaki değerlerin üçlüsünü döndürür: verilen dizindeki olandan küçük tüm öğeler, verilen dizindeki değer ve verilen dizindekinden daha büyük olan tüm öğeler.
    ///
    ///
    /// # Mevcut uygulama
    ///
    /// Mevcut algoritma, [`sort_unstable`] için kullanılan aynı hızlı sıralama algoritmasının hızlı seçim kısmına dayanmaktadır.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, `index >= len()` olduğunda, boş dilimlerde her zaman panics anlamına gelir.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Medyanı, dizi mutlak değere göre sıralanmış gibi döndürün.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Belirtilen dizini sıralama şeklimize bağlı olarak, yalnızca dilimin aşağıdakilerden biri olacağı garanti edilmektedir.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// [`PartialEq`] trait uygulamasına göre tüm ardışık tekrarlanan öğeleri dilimin sonuna taşır.
    ///
    ///
    /// İki dilim döndürür.İlki, ardışık yinelenen öğeler içermez.
    /// İkincisi, tüm kopyaları belirtilmemiş bir sırada içerir.
    ///
    /// Dilim sıralanırsa, döndürülen ilk dilim hiçbir kopya içermez.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Verilen bir eşitlik ilişkisini sağlayan bir dilimin sonuna, ardışık öğelerin ilki hariç tümünü taşır.
    ///
    /// İki dilim döndürür.İlki, ardışık yinelenen öğeler içermez.
    /// İkincisi, tüm kopyaları belirtilmemiş bir sırada içerir.
    ///
    /// `same_bucket` işlevi, dilimden iki öğeye başvurular iletilir ve öğelerin eşit olup olmadığını belirlemelidir.
    /// Öğeler, dilimdeki sıralarının tersi sırayla aktarılır, bu nedenle `same_bucket(a, b)`, `true` döndürürse, `a` dilimin sonunda taşınır.
    ///
    ///
    /// Dilim sıralanırsa, döndürülen ilk dilim hiçbir kopya içermez.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // `self` için değiştirilebilir bir referansımız olmasına rağmen,*keyfi* değişiklikler yapamayız.`same_bucket` çağrıları panic olabilir, bu nedenle dilimin her zaman geçerli bir durumda olduğundan emin olmalıyız.
        //
        // Bunu halletme şeklimiz takas kullanmaktır;Sonunda tutmak istediğimiz öğeler önde, reddetmek istediklerimiz ise arkada olacak şekilde, tüm öğeleri yineleriz, giderken değiş tokuş ederiz.
        // Daha sonra dilimi bölebiliriz.
        // Bu işlem hala `O(n)` tir.
        //
        // Örnek: `r` in "sonraki"
        // oku "ve `w` next_write "ı temsil eder.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // self[r] ile self [w-1] karşılaştırıldığında, bu bir kopya değildir, bu nedenle self[r] ve self[w] i değiştiririz (r==w gibi bir etkisi yoktur) ve ardından hem r hem de w'yi artırarak bize şunu bırakırız:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] ile self [w-1] karşılaştırıldığında, bu değer bir kopyadır, bu nedenle `r` i artırırız ancak diğer her şeyi değiştirmeden bırakırız:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] ile self [w-1] karşılaştırıldığında, bu bir kopya değildir, bu nedenle self[r] ve self[w] i değiştirin ve r ve w'yi ilerletin:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Kopya değil, tekrarlayın:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Yinelenen, advance r. End dilim.W olarak bölün.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // GÜVENLİK: `while` koşulu, `next_read` ve `next_write` i garanti eder
        // `len` ten küçük olduğundan, `self` in içindedir.
        // `prev_ptr_write` `ptr_write` ten önceki bir öğeyi işaret eder, ancak `next_write` 1'den başlar, bu nedenle `prev_ptr_write` hiçbir zaman 0'dan küçük değildir ve dilimin içindedir.
        // Bu, `ptr_read`, `prev_ptr_write` ve `ptr_write` referanslarının kaldırılması ve `ptr.add(next_read)`, `ptr.add(next_write - 1)` ve `prev_ptr_write.offset(1)` in kullanılması için gereksinimleri karşılar.
        //
        //
        // `next_write` ayrıca döngü başına en fazla bir kez artırılır, yani takas edilmesi gerekebileceğinde hiçbir elemanın atlanmaması anlamına gelir.
        //
        // `ptr_read` ve `prev_ptr_write` hiçbir zaman aynı öğeyi göstermez.Bu, `&mut *ptr_read`, `&mut* prev_ptr_write` in güvenli olması için gereklidir.
        // Açıklama basitçe, `next_read >= next_write` in her zaman doğru olduğu, dolayısıyla `next_read > next_write - 1` in de doğru olduğu şeklindedir.
        //
        //
        //
        //
        //
        unsafe {
            // Ham işaretçiler kullanarak sınır kontrollerinden kaçının.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Art arda gelen öğelerin ilki hariç tümünü aynı anahtara çözümlenen dilimin sonuna taşır.
    ///
    ///
    /// İki dilim döndürür.İlki, ardışık yinelenen öğeler içermez.
    /// İkincisi, tüm kopyaları belirtilmemiş bir sırada içerir.
    ///
    /// Dilim sıralanırsa, döndürülen ilk dilim hiçbir kopya içermez.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Dilimi, son `self.len() - mid` öğeleri öne hareket ederken, dilimin ilk `mid` öğeleri sona hareket edecek şekilde yerinde döndürür.
    /// `rotate_left` çağrıldıktan sonra, daha önce `mid` dizininde bulunan eleman, dilimdeki ilk eleman olur.
    ///
    /// # Panics
    ///
    /// `mid`, dilimin uzunluğundan büyükse bu işlev panic olacaktır.`mid == self.len()` in _not_ panic yaptığını ve işlemsiz bir rotasyon olduğunu unutmayın.
    ///
    /// # Complexity
    ///
    /// Doğrusal alır (`self.len()`) zamanında.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Bir alt dilimin döndürülmesi:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // GÜVENLİK: `[p.add(mid) - mid, p.add(mid) + k)` serisi önemsizdir
        // `ptr_rotate` in gerektirdiği şekilde okuma ve yazma için geçerlidir.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Dilimi, son `k` öğeleri öne hareket ederken, dilimin ilk `self.len() - k` öğeleri sona hareket edecek şekilde yerinde döndürür.
    /// `rotate_right` çağrıldıktan sonra, daha önce `self.len() - k` dizininde bulunan eleman, dilimdeki ilk eleman olur.
    ///
    /// # Panics
    ///
    /// `k`, dilimin uzunluğundan büyükse bu işlev panic olacaktır.`k == self.len()` in _not_ panic yaptığını ve işlemsiz bir rotasyon olduğunu unutmayın.
    ///
    /// # Complexity
    ///
    /// Doğrusal alır (`self.len()`) zamanında.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Bir alt dilimi döndürün:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // GÜVENLİK: `[p.add(mid) - mid, p.add(mid) + k)` serisi önemsizdir
        // `ptr_rotate` in gerektirdiği şekilde okuma ve yazma için geçerlidir.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value` i klonlayarak `self` i öğelerle doldurur.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// `self` i tekrar tekrar kapatmayı çağırarak döndürülen öğelerle doldurur.
    ///
    /// Bu yöntem, yeni değerler oluşturmak için bir kapanış kullanır.[`Clone`] i belirli bir değeri tercih ederseniz, [`fill`] i kullanın.
    /// Değerler oluşturmak için [`Default`] trait kullanmak istiyorsanız, [`Default::default`] i bağımsız değişken olarak iletebilirsiniz.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Öğeleri `src` ten `self` e kopyalar.
    ///
    /// `src` in uzunluğu `self` ile aynı olmalıdır.
    ///
    /// `T`, `Copy` i uygularsa, [`copy_from_slice`] i kullanmak daha performanslı olabilir.
    ///
    /// # Panics
    ///
    /// İki dilim farklı uzunluklara sahipse bu işlev panic olacaktır.
    ///
    /// # Examples
    ///
    /// İki öğeyi bir dilimden diğerine klonlamak:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Dilimlerin aynı uzunlukta olması gerektiğinden, kaynak dilimi dört öğeden ikiye böleriz.
    /// // Bunu yapmazsak panic olacak.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust, belirli bir kapsamdaki belirli bir veri parçasına değişmez referanslar olmadan yalnızca bir değişken referans olabileceğini zorlar.
    /// Bu nedenle, `clone_from_slice` i tek bir dilim üzerinde kullanmaya çalışmak derleme hatasına neden olur:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Bunu aşmak için, bir dilimden iki farklı alt dilim oluşturmak için [`split_at_mut`] i kullanabiliriz:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Bir memcpy kullanarak `src` ten `self` e tüm öğeleri kopyalar.
    ///
    /// `src` in uzunluğu `self` ile aynı olmalıdır.
    ///
    /// `T`, `Copy` i uygulamıyorsa, [`clone_from_slice`] i kullanın.
    ///
    /// # Panics
    ///
    /// İki dilim farklı uzunluklara sahipse bu işlev panic olacaktır.
    ///
    /// # Examples
    ///
    /// İki öğeyi bir dilimden diğerine kopyalamak:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Dilimlerin aynı uzunlukta olması gerektiğinden, kaynak dilimi dört öğeden ikiye böleriz.
    /// // Bunu yapmazsak panic olacak.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust, belirli bir kapsamdaki belirli bir veri parçasına değişmez referanslar olmadan yalnızca bir değişken referans olabileceğini zorlar.
    /// Bu nedenle, `copy_from_slice` i tek bir dilim üzerinde kullanmaya çalışmak derleme hatasına neden olur:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Bunu aşmak için, bir dilimden iki farklı alt dilim oluşturmak için [`split_at_mut`] i kullanabiliriz:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic kod yolu, arama sitesini şişirmemek için soğuk bir işleve yerleştirildi.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // GÜVENLİK: `self`, tanım gereği `self.len()` öğeleri için geçerlidir ve `src`
        // aynı uzunluğa sahip olduğu kontrol edildi.
        // Değişken referanslar dışlayıcı olduğundan dilimler çakışamaz.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Bir memmove kullanarak, dilimin bir bölümündeki öğeleri kendi başka bir parçasına kopyalar.
    ///
    /// `src` kopyalanacak `self` içindeki aralıktır.
    /// `dest` `src` ile aynı uzunluğa sahip olacak olan, `self` içinde kopyalanacak aralığın başlangıç dizinidir.
    /// İki aralık çakışabilir.
    /// İki aralığın uçları `self.len()` ten küçük veya ona eşit olmalıdır.
    ///
    /// # Panics
    ///
    /// Bu işlev, aralıklardan biri dilimin sonunu aşarsa veya `src` in sonu başlangıçtan önceyse panic olacaktır.
    ///
    ///
    /// # Examples
    ///
    /// Bir dilim içinde dört baytı kopyalamak:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // GÜVENLİK: `ptr::copy` için tüm koşullar yukarıda kontrol edilmiştir,
        // `ptr::add` için olanlar gibi.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `self` teki tüm öğeleri `other` dekilerle değiştirir.
    ///
    /// `other` in uzunluğu `self` ile aynı olmalıdır.
    ///
    /// # Panics
    ///
    /// İki dilim farklı uzunluklara sahipse bu işlev panic olacaktır.
    ///
    /// # Example
    ///
    /// İki öğeyi dilimler arasında takas etme:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust, belirli bir kapsamdaki belirli bir veri parçasına yalnızca bir değişken referans olabileceğini zorlar.
    ///
    /// Bu nedenle, `swap_with_slice` i tek bir dilim üzerinde kullanmaya çalışmak derleme hatasına neden olur:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Bunu aşmak için, bir dilimden iki farklı değiştirilebilir alt dilim oluşturmak için [`split_at_mut`] i kullanabiliriz:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // GÜVENLİK: `self`, tanım gereği `self.len()` öğeleri için geçerlidir ve `src`
        // aynı uzunluğa sahip olduğu kontrol edildi.
        // Değişken referanslar dışlayıcı olduğundan dilimler çakışamaz.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}` için orta ve son dilimin uzunluklarını hesaplama işlevi.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // `rest` ile ilgili yapacağımız şey, "U" lardan kaç katını en düşük sayıda "T" ye koyabileceğimizi bulmaktır.
        //
        // Ve böyle her bir "multiple" için kaç tane "T" ye ihtiyacımız var.
        //
        // Örneğin T=u8 U=u16'yı düşünün.O zaman 2 Ts'ye 1 U koyabiliriz.Basit.
        // Şimdi, örneğin size_of: :<T>=16, size_of::<U>=24.</u>
        // `rest` diliminde her 3 Ts'nin yerine 2 Us koyabiliriz.
        // Biraz daha karmaşık.
        //
        // Bunu hesaplamak için formül:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Genişletilmiş ve basitleştirilmiş:
        //
        // Bize=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Neyse ki, tüm bunlar sürekli değerlendirildiği için ... buradaki performans önemli değil!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // yinelemeli stein'in algoritması Bu `const fn` i yine de yapmalıyız (ve yaparsak yinelemeli algoritmaya geri dönmeliyiz) çünkü tüm bunları sabitlemek için llvm'ye güvenmek…pekala, beni rahatsız ediyor.
            //
            //

            // GÜVENLİK: `a` ve `b` sıfır olmayan değerler olarak kontrol edilir.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // b'den 2'nin tüm faktörlerini kaldır
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // GÜVENLİK: `b` in sıfır olmadığı kontrol edilir.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Bu bilgiyle donanmış olarak, kaç tane "U" sığdırabileceğimizi bulabiliriz!
        let us_len = self.len() / ts * us;
        // Ve sondaki dilimde kaç tane "T" olacak!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Dilimi başka türden bir dilime dönüştürerek türlerin hizalanmasını sağlayın.
    ///
    /// Bu yöntem dilimi üç farklı dilime ayırır: önek, yeni bir türün doğru şekilde hizalanmış orta dilimi ve sonek dilimi.
    /// Yöntem, orta dilimi belirli bir tür ve giriş dilimi için mümkün olan en büyük uzunluk yapabilir, ancak yalnızca algoritmanızın performansı buna bağlı olmalıdır, doğruluğuna değil.
    ///
    /// Tüm giriş verilerinin önek veya sonek dilimi olarak döndürülmesine izin verilir.
    ///
    /// Bu yöntemin, giriş öğesi `T` veya çıkış öğesi `U` sıfır boyutlu olduğunda ve hiçbir şeyi bölmeden orijinal dilimi döndürdüğünde hiçbir amacı yoktur.
    ///
    /// # Safety
    ///
    /// Bu yöntem, geri dönen orta dilimdeki öğeler açısından esasen bir `transmute` tir, dolayısıyla `transmute::<T, U>` ile ilgili tüm olağan uyarılar burada da geçerlidir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Bu işlevin çoğunun sürekli değerlendirileceğini unutmayın,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST'leri özel olarak ele alın, bu-onları hiç işlemeyin.
            return (self, &[], &[]);
        }

        // İlk olarak, birinci ve 2. dilim arasında hangi noktada ayrıldığımızı bulun.
        // ptr.align_offset ile kolay.
        let ptr = self.as_ptr();
        // GÜVENLİK: Ayrıntılı güvenlik yorumu için `align_to_mut` yöntemine bakın.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // GÜVENLİK: şimdi `rest` kesinlikle hizalandı, bu nedenle aşağıdaki `from_raw_parts` tamam,
            // çünkü arayan kişi `T` i güvenli bir şekilde `U` e dönüştürebileceğimizi garanti ediyor.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Dilimi başka türden bir dilime dönüştürerek türlerin hizalanmasını sağlayın.
    ///
    /// Bu yöntem dilimi üç farklı dilime ayırır: önek, yeni bir türün doğru şekilde hizalanmış orta dilimi ve sonek dilimi.
    /// Yöntem, orta dilimi belirli bir tür ve giriş dilimi için mümkün olan en büyük uzunluk yapabilir, ancak yalnızca algoritmanızın performansı buna bağlı olmalıdır, doğruluğuna değil.
    ///
    /// Tüm giriş verilerinin önek veya sonek dilimi olarak döndürülmesine izin verilir.
    ///
    /// Bu yöntemin, giriş öğesi `T` veya çıkış öğesi `U` sıfır boyutlu olduğunda ve hiçbir şeyi bölmeden orijinal dilimi döndürdüğünde hiçbir amacı yoktur.
    ///
    /// # Safety
    ///
    /// Bu yöntem, geri dönen orta dilimdeki öğeler açısından esasen bir `transmute` tir, dolayısıyla `transmute::<T, U>` ile ilgili tüm olağan uyarılar burada da geçerlidir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Bu işlevin çoğunun sürekli değerlendirileceğini unutmayın,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST'leri özel olarak ele alın, bu-onları hiç işlemeyin.
            return (self, &mut [], &mut []);
        }

        // İlk olarak, birinci ve 2. dilim arasında hangi noktada ayrıldığımızı bulun.
        // ptr.align_offset ile kolay.
        let ptr = self.as_ptr();
        // GÜVENLİK: Burada, U için hizalanmış işaretçileri kullanacağımızdan emin oluyoruz.
        // yöntemin geri kalanı.Bu, U için hedeflenen bir hizalamayla&[T] 'ye bir işaretçi iletilerek yapılır.
        // `crate::ptr::align_offset` doğru şekilde hizalanmış ve geçerli bir işaretçi `ptr` (`self` e referansla gelir) ve güvenlik kısıtlamalarını karşılayan (U için hizalamadan geldiği için) iki kuvvetli bir boyutta çağrılır.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Bundan sonra `rest` i tekrar kullanamayız, bu `mut_ptr` takma adını geçersiz kılar!GÜVENLİK: `align_to` için yorumlara bakın.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Bu dilimin öğelerinin sıralı olup olmadığını kontrol eder.
    ///
    /// Yani, her `a` öğesi ve onu takip eden `b` öğesi için `a <= b` tutmalıdır.Dilim tam olarak sıfır veya bir öğe verirse, `true` döndürülür.
    ///
    /// `Self::Item` yalnızca `PartialOrd` ise, ancak `Ord` değilse, yukarıdaki tanımın, iki ardışık öğe karşılaştırılabilir değilse bu işlevin `false` döndürdüğünü ima ettiğini unutmayın.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Bu dilimin elemanlarının verilen karşılaştırma işlevi kullanılarak sıralanıp sıralanmadığını kontrol eder.
    ///
    /// Bu işlev, `PartialOrd::partial_cmp` kullanmak yerine, iki öğenin sırasını belirlemek için verilen `compare` işlevini kullanır.
    /// Bunun dışında [`is_sorted`] e eşdeğer;daha fazla bilgi için belgelerine bakın.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Bu dilimin öğelerinin verilen anahtar çıkarma işlevi kullanılarak sıralanıp sıralanmadığını kontrol eder.
    ///
    /// Dilimin öğelerini doğrudan karşılaştırmak yerine, bu işlev, `f` tarafından belirlenen öğelerin anahtarlarını karşılaştırır.
    /// Bunun dışında [`is_sorted`] e eşdeğer;daha fazla bilgi için belgelerine bakın.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Verilen yüklemeye göre bölüm noktasının dizinini döndürür (ikinci bölümün ilk öğesinin dizini).
    ///
    /// Dilimin verilen yüklemeye göre bölündüğü varsayılır.
    /// Bu, yüklemin true döndürdüğü tüm öğelerin dilimin başlangıcında olduğu ve yüklemin false döndürdüğü tüm öğelerin sonunda olduğu anlamına gelir.
    ///
    /// Örneğin, [7, 15, 3, 5, 4, 12, 6], x% 2!=0 koşulu altında bölümlenmiştir (tüm tek sayılar başlangıçta, hepsi sonunda çift).
    ///
    /// Bu dilim bölümlenmemişse, döndürülen sonuç belirtilmemiş ve anlamsızdır, çünkü bu yöntem bir tür ikili arama gerçekleştirir.
    ///
    /// Ayrıca bkz. [`binary_search`], [`binary_search_by`] ve [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // GÜVENLİK: `left < right`, `left <= mid < right`.
            // Bu nedenle `left` her zaman artar ve `right` her zaman azalır ve bunlardan biri seçilir.Her iki durumda da `left <= right` memnun.Bu nedenle, `left < right` bir adımda ise, `left <= right` bir sonraki adımda tatmin olur.
            //
            // Bu nedenle, `left != right` olduğu sürece, `0 <= left < right <= len` tatmin olur ve bu durumda `0 <= mid < len` de tatmin olur.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Onları açıkça aynı uzunlukta dilimlemeliyiz
        // optimize edicinin sınır denetimini aşmasını kolaylaştırmak için.
        // Ancak buna güvenilemeyeceğinden, T: Copy için de açık bir uzmanlığımız var.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Boş bir dilim oluşturur.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Değiştirilebilir boş bir dilim oluşturur.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Şu anda yalnızca `strip_prefix` ve `strip_suffix` tarafından kullanılan dilimlerdeki desenler.
/// Bir future noktasında, `core::str::Pattern` i (yazma sırasında `str` ile sınırlıdır) dilimlere genellemeyi umuyoruz ve sonra bu trait değiştirilecek veya kaldırılacaktır.
///
pub trait SlicePattern {
    /// Eşleştirilen dilimin öğe türü.
    type Item;

    /// Şu anda, `SlicePattern` tüketicilerinin bir dilime ihtiyacı var.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}