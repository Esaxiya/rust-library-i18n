//! `&[T]` ve `&mut [T]` oluşturmak için ücretsiz işlevler.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// İşaretçiden ve uzunluktan bir dilim oluşturur.
///
/// `len` argümanı bayt sayısı değil **öğe sayısıdır**.
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `data` `len * mem::size_of::<T>()` için çok bayt okumalar için [valid] olmalı ve uygun şekilde hizalanmalıdır.Bu özellikle şu anlama gelir:
///
///     * Bu dilimin tüm bellek aralığı, tek bir tahsis edilmiş nesne içinde yer almalıdır!
///       Dilimler asla birden fazla tahsis edilmiş nesneye yayılamaz.Bunu yanlışlıkla hesaba katmayan bir örnek için [below](#incorrect-usage) e bakın.
///     * `data` sıfır uzunluklu dilimler için bile boş olmamalı ve hizalı olmalıdır.
///     Bunun bir nedeni, numaralandırma düzeni optimizasyonlarının hizalanmış olan ve diğer verilerden ayırmak için boş olmayan referanslara (herhangi bir uzunluktaki dilimler dahil) güvenebilmesidir.
///     [`NonNull::dangling()`] kullanarak sıfır uzunluklu dilimler için `data` olarak kullanılabilen bir işaretçi elde edebilirsiniz.
///
/// * `data` `T` tipi `len` ardışık doğru şekilde başlatılmış değerleri göstermelidir.
///
/// * Döndürülen dilim tarafından referans verilen bellek, bir `UnsafeCell` in içindekiler dışında, `'a` ömrü boyunca mutasyona uğratılmamalıdır.
///
/// * Dilimin toplam boyutu `len * mem::size_of::<T>()`, `isize::MAX` ten büyük olmamalıdır.
///   [`pointer::offset`] in güvenlik belgelerine bakın.
///
/// # Caveat
///
/// Döndürülen dilim için kullanım ömrü, kullanımından çıkarılır.
/// Yanlışlıkla kötüye kullanımı önlemek için, kullanım ömrünü bağlamda güvenli olan kaynak ömür süresine bağlamanız önerilir; örneğin, dilim için bir ana bilgisayar değerinin ömrünü alan bir yardımcı işlev sağlayarak veya açık ek açıklama ile.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // tek bir eleman için bir dilim tezahür et
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Yanlış kullanım
///
/// Aşağıdaki `join_slices` işlevi **sağlam değil** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Yukarıdaki iddia, `fst` ve `snd` in bitişik olmasını sağlar, ancak bunlar yine de _different allocated objects_ içinde yer alabilir, bu durumda bu dilimi oluşturmak tanımsız bir davranıştır.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ve `b` farklı tahsis edilmiş nesnelerdir ...
///     let a = 42;
///     let b = 27;
///     // ... yine de belleğe bitişik olarak yerleştirilebilir: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // GÜVENLİK: Arayan kişi `from_raw_parts` için güvenlik sözleşmesine uymalıdır.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Değiştirilebilir bir dilim döndürülmesi dışında [`from_raw_parts`] ile aynı işlevselliği gerçekleştirir.
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `data` `len * mem::size_of::<T>()` birçok bayt için hem okuma hem de yazma için [valid] olmalı ve uygun şekilde hizalanmalıdır.Bu özellikle şu anlama gelir:
///
///     * Bu dilimin tüm bellek aralığı, tek bir tahsis edilmiş nesne içinde yer almalıdır!
///       Dilimler asla birden fazla tahsis edilmiş nesneye yayılamaz.
///     * `data` sıfır uzunluklu dilimler için bile boş olmamalı ve hizalı olmalıdır.
///     Bunun bir nedeni, numaralandırma düzeni optimizasyonlarının hizalanmış olan ve diğer verilerden ayırmak için boş olmayan referanslara (herhangi bir uzunluktaki dilimler dahil) güvenebilmesidir.
///
///     [`NonNull::dangling()`] kullanarak sıfır uzunluklu dilimler için `data` olarak kullanılabilen bir işaretçi elde edebilirsiniz.
///
/// * `data` `T` tipi `len` ardışık doğru şekilde başlatılmış değerleri göstermelidir.
///
/// * Döndürülen dilim tarafından referans verilen belleğe, `'a` yaşam süresi boyunca başka herhangi bir işaretçi (dönüş değerinden türetilmez) aracılığıyla erişilmemelidir.
///   Hem okuma hem de yazma erişimi yasaktır.
///
/// * Dilimin toplam boyutu `len * mem::size_of::<T>()`, `isize::MAX` ten büyük olmamalıdır.
///   [`pointer::offset`] in güvenlik belgelerine bakın.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // GÜVENLİK: Arayan kişi `from_raw_parts_mut` için güvenlik sözleşmesine uymalıdır.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// T'ye bir referansı 1 uzunluğunda bir dilime dönüştürür (kopyalamadan).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// T'ye bir referansı 1 uzunluğunda bir dilime dönüştürür (kopyalamadan).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}