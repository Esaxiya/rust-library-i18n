//! Dilim yineleyicileri tarafından kullanılan makrolar.

// Inlining is_empty ve len büyük bir performans farkı yaratıyor
macro_rules! is_empty {
    // Bir ZST yineleyicinin uzunluğunu kodlama şeklimiz, bu hem ZST hem de ZST olmayanlar için çalışır.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Bazı sınır kontrollerinden kurtulmak için (bkz. `position`) uzunluğu biraz beklenmedik bir şekilde hesaplıyoruz.
// ("Codegen/dilim-konum-sınırları-kontrolü" ile test edilmiştir.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // bazen güvenli olmayan bir blok içinde kullanılırız

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Bu _cannot_, `unchecked_sub` kullanıyor çünkü uzun ZST dilim yineleyicilerinin uzunluğunu temsil etmek için sarmalamaya bağlıyız.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // `start <= end` in, imzalı anlaşma gerektiren `offset_from` ten daha iyisini yapabileceğini biliyoruz.
            // Burada uygun bayrakları ayarlayarak LLVM'ye bunu söyleyebiliriz, bu da sınır kontrollerini kaldırmasına yardımcı olur.
            // GÜVENLİK: Türüne göre değişmez, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // LLVM'ye işaretçilerin tür boyutunun tam bir katı kadar ayrı olduğunu söyleyerek, `len() == 0` i `(end - start) < size` yerine `start == end` e kadar optimize edebilir.
            //
            // GÜVENLİK: Tip değişmezliğine göre, işaretçiler hizalanır, böylece
            //         aralarındaki mesafe pointee boyutunun bir katı olmalıdır
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` ve `IterMut` yineleyicilerinin ortak tanımı
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // İlk öğeyi döndürür ve yineleyicinin başlangıcını 1 ileri hareket ettirir.
        // Satır içi bir işleve kıyasla performansı büyük ölçüde artırır.
        // Yineleyici boş olmamalıdır.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Son öğeyi döndürür ve yineleyicinin sonunu 1 geri hareket ettirir.
        // Satır içi bir işleve kıyasla performansı büyük ölçüde artırır.
        // Yineleyici boş olmamalıdır.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // T bir ZST olduğunda yineleyiciyi, yineleyicinin ucunu `n` kadar geriye doğru hareket ettirerek küçültür.
        // `n` `self.len()` i geçmemelidir.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Yineleyiciden bir dilim oluşturmak için yardımcı işlev.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // GÜVENLİK: yineleyici, işaretçi ile bir dilimden oluşturuldu
                // `self.ptr` ve uzunluk `len!(self)`.
                // Bu, `from_raw_parts` için tüm ön koşulların yerine getirildiğini garanti eder.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Yineleyicinin başlangıcını `offset` öğeleriyle ileriye doğru hareket ettirerek eski başlangıca döndüren yardımcı işlev.
            //
            // Güvensiz çünkü ofset `self.len()` i geçmemelidir.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // GÜVENLİK: Arayan kişi, `offset` in `self.len()` i aşmayacağını garanti eder,
                    // bu nedenle bu yeni işaretçi `self` in içindedir ve bu nedenle boş olmaması garanti edilir.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Yineleyicinin ucunu `offset` öğeleriyle geriye doğru hareket ettirmek ve yeni ucu döndürmek için yardımcı işlev.
            //
            // Güvensiz çünkü ofset `self.len()` i geçmemelidir.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // GÜVENLİK: Arayan kişi, `offset` in `self.len()` i aşmayacağını garanti eder,
                    // bir `isize` i aşmaması garanti edilir.
                    // Ayrıca, ortaya çıkan işaretçi, `offset` için diğer gereksinimleri karşılayan `slice` sınırları içindedir.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // dilimlerle uygulanabilir, ancak bu sınır kontrollerini önler

                // GÜVENLİK: `assume` çağrıları, bir dilimin başlangıç işaretçisinden bu yana güvenlidir
                // boş olmamalı ve ZST olmayan dilimlerin de boş olmayan bir son işaretçisi olmalıdır.
                // Önce yineleyicinin boş olup olmadığını kontrol ettiğimiz için `next_unchecked!` e yapılan çağrı güvenlidir.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Bu yineleyici artık boş.
                    if mem::size_of::<T>() == 0 {
                        // `ptr` asla 0 olamayacağı için bunu bu şekilde yapmalıyız, ancak `end` olabilir (sarma nedeniyle).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // GÜVENLİK: T ZST değilse end 0 olamaz çünkü ptr 0 değildir ve end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // GÜVENLİK: Sınırdayız.`post_inc_start`, ZST'ler için bile doğru olanı yapar.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // `try_fold` kullanan varsayılan uygulamayı geçersiz kılıyoruz, çünkü bu basit uygulama daha az LLVM IR üretir ve derlemesi daha hızlıdır.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // `try_fold` kullanan varsayılan uygulamayı geçersiz kılıyoruz, çünkü bu basit uygulama daha az LLVM IR üretir ve derlemesi daha hızlıdır.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // `try_fold` kullanan varsayılan uygulamayı geçersiz kılıyoruz, çünkü bu basit uygulama daha az LLVM IR üretir ve derlemesi daha hızlıdır.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // `try_fold` kullanan varsayılan uygulamayı geçersiz kılıyoruz, çünkü bu basit uygulama daha az LLVM IR üretir ve derlemesi daha hızlıdır.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // `try_fold` kullanan varsayılan uygulamayı geçersiz kılıyoruz, çünkü bu basit uygulama daha az LLVM IR üretir ve derlemesi daha hızlıdır.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // `try_fold` kullanan varsayılan uygulamayı geçersiz kılıyoruz, çünkü bu basit uygulama daha az LLVM IR üretir ve derlemesi daha hızlıdır.
            // Ayrıca, `assume` sınır kontrolünden kaçınır.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // GÜVENLİK: Döngü değişmezi ile sınırlar içinde olduğumuz garanti edilir:
                        // `i >= n`, `self.next()`, `None` i döndürdüğünde ve döngü kesilir.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // `try_fold` kullanan varsayılan uygulamayı geçersiz kılıyoruz, çünkü bu basit uygulama daha az LLVM IR üretir ve derlemesi daha hızlıdır.
            // Ayrıca, `assume` sınır kontrolünden kaçınır.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // GÜVENLİK: `i`, `n` te başladığı için `n` ten daha düşük olmalıdır
                        // ve sadece azalıyor.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // GÜVENLİK: Arayan kişi, `i` in
                // temeldeki dilim, bu nedenle `i`, bir `isize` i aşamaz ve döndürülen referansların, dilimin bir öğesine başvurması garanti edilir ve bu nedenle geçerli olmaları garanti edilir.
                //
                // Ayrıca arayanın, bir daha asla aynı indeksle çağrılmayacağımızı ve bu alt bölüme erişecek başka hiçbir yöntemin çağrılmayacağını garanti ettiğini de unutmayın;
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // dilimlerle uygulanabilir, ancak bu sınır kontrollerini önler

                // GÜVENLİK: Bir dilimin başlangıç işaretçisinin boş olmaması gerektiğinden `assume` çağrıları güvenlidir,
                // ve ZST olmayanlar üzerindeki dilimlerin de boş olmayan bir uç işaretçisine sahip olması gerekir.
                // Önce yineleyicinin boş olup olmadığını kontrol ettiğimiz için `next_back_unchecked!` e yapılan çağrı güvenlidir.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Bu yineleyici artık boş.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // GÜVENLİK: Sınırdayız.`pre_dec_end`, ZST'ler için bile doğru olanı yapar.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}