//! ASCII `[u8]` üzerinde işlemler.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Bu dilimdeki tüm baytların ASCII aralığında olup olmadığını kontrol eder.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// İki dilim ASCII büyük/küçük harfe duyarlı olmayan eşleşme olup olmadığını denetler.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ile aynı, ancak geçiciler ayırmadan ve kopyalamadan.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Bu dilimi yerinde ASCII büyük harf eşdeğerine dönüştürür.
    ///
    /// 'a' ila 'z' arasındaki ASCII harfleri, 'A' ila 'Z' e eşlenir, ancak ASCII olmayan harfler değiştirilmez.
    ///
    /// Mevcut olanı değiştirmeden yeni bir büyük harfli değer döndürmek için [`to_ascii_uppercase`] i kullanın.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Bu dilimi yerinde ASCII küçük harf eşdeğerine dönüştürür.
    ///
    /// 'A' ila 'Z' arasındaki ASCII harfleri, 'a' ila 'z' e eşlenir, ancak ASCII olmayan harfler değiştirilmez.
    ///
    /// Mevcut olanı değiştirmeden yeni bir küçük harfli değer döndürmek için [`to_ascii_lowercase`] i kullanın.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` sözcüğündeki herhangi bir bayt ascii değilse (>=128) `true` döndürür.
/// `../str/mod.rs` ten, utf8 doğrulaması için benzer bir şey yapan snarfed.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Tek seferde bayt işlemleri yerine (mümkün olduğunda) bir seferde bayt işlemlerini kullanacak olan optimize edilmiş ASCII testi.
///
/// Burada kullandığımız algoritma oldukça basit.`s` çok kısaysa, sadece her baytı kontrol ederiz ve işimiz biter.Aksi takdirde:
///
/// - Hizalanmamış bir yükle ilk kelimeyi okuyun.
/// - İmleci hizalayın, sonraki kelimeleri hizalanmış yüklerle sonuna kadar okuyun.
/// - Hizalanmamış bir yükle `s` ten son `usize` i okuyun.
///
/// Bu yüklerden herhangi biri `contains_nonascii` (above) in doğru döndürdüğü bir şey üretirse, cevabın yanlış olduğunu biliyoruz.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Tek seferde kelime uygulamasından bir şey kazanamazsak, skaler bir döngüye geri dönün.
    //
    // Bunu, `size_of::<usize>()` in `usize` için yeterli hizalama olmadığı mimariler için de yapıyoruz, çünkü bu garip bir edge durumu.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Her zaman ilk kelimeyi hizasız okuruz, bu da `align_offset` in
    // 0, hizalanmış okuma için aynı değeri tekrar okurduk.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // GÜVENLİK: Yukarıda `len < USIZE_SIZE` i doğrularız.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Bunu yukarıda biraz dolaylı olarak kontrol ettik.
    // `offset_to_aligned` in `align_offset` veya `USIZE_SIZE` olduğunu ve her ikisinin de yukarıda açıkça kontrol edildiğini unutmayın.
    //
    debug_assert!(offset_to_aligned <= len);

    // GÜVENLİK: word_ptr, okumak için kullandığımız (uygun şekilde hizalanmış) kullanım boyutu ptr'dir.
    // dilimin orta parçası.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` döngü sonu kontrolleri için kullanılan `word_ptr` in bayt dizinidir.
    let mut byte_pos = offset_to_aligned;

    // Paranoya hizalamayı kontrol eder, çünkü bir sürü hizalanmamış yük yapmak üzereyiz.
    // Pratikte, `align_offset` teki bir hatayı engellemek imkansız olmalı.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Kuyruğun her zaman fazladan branch `byte_pos == len` e kadar her zaman bir `usize` olduğundan emin olmak için, son hizalanmış kelimeyi daha sonra kuyruk kontrolünde kendi başına yapılacak hariç, son hizalanan kelimeye kadar takip eden kelimeleri okuyun.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Okumanın sınırlar içinde olup olmadığını kontrol edin
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ve `byte_pos` hakkındaki varsayımlarımız geçerli.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // GÜVENLİK: `word_ptr` in doğru şekilde hizalandığını biliyoruz (çünkü
        // `align_offset`) ve `word_ptr` ile bitiş arasında yeterli bayta sahip olduğumuzu biliyoruz
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // GÜVENLİK: `byte_pos <= len - USIZE_SIZE` in
        // bu `add` ten sonra, `word_ptr` en fazla bir sonda olacaktır.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Gerçekten sadece bir `usize` kaldığından emin olmak için sağlık kontrolü.
    // Bu, döngü koşulumuz tarafından garanti edilmelidir.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // GÜVENLİK: Bu, başlangıçta kontrol ettiğimiz `len >= USIZE_SIZE` e dayanır.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}