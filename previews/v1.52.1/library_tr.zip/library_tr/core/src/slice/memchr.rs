// Orijinal uygulama rust-memchr'den alınmıştır.
// Telif hakkı 2015 Andrew Gallant, bluss ve Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Kesmeyi kullanın.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `x` herhangi bir sıfır bayt içeriyorsa `true` i döndürür.
///
/// Matters Computational *, J. Arndt'tan:
///
/// "Buradaki fikir, her bir bayttan bir tane çıkarmak ve ardından ödünç almanın en anlamlı olana kadar yayıldığı baytları aramaktır.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` te `x` baytıyla eşleşen ilk dizini döndürür.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Küçük dilimler için hızlı yol
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Bir seferde iki `usize` kelimesi okuyarak tek bir bayt değeri için tarama yapın.
    //
    // `text` i üç parçaya bölün
    // - metindeki ilk kelime hizalı adresin önünde, hizalanmamış başlangıç bölümü
    // - gövde, bir seferde 2 kelime ile tarayın
    // - kalan son kısım, <2 kelime boyutu

    // hizalanmış bir sınıra kadar arama
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // metnin gövdesini ara
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // GÜVENLİK: while'ın koşulu en az 2 * usize_byte'lık bir mesafeyi garanti eder
        // ofset ile dilimin sonu arasında.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // eşleşen bir bayt varsa kes
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Gövde döngüsünün durduğu noktadan sonraki baytı bulun.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` te bayt `x` ile eşleşen son dizini döndürür.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Bir seferde iki `usize` kelimesi okuyarak tek bir bayt değeri için tarama yapın.
    //
    // `text` i üç bölüme ayırın:
    // - hizalanmamış kuyruk, metindeki son kelimeden sonra hizalanmış adres,
    // - gövde, bir seferde 2 kelime ile taranır,
    // - kalan ilk bayt, <2 kelime boyutu.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Bunu sadece önek ve son ekin uzunluğunu elde etmek için çağırıyoruz.
        // Ortada her zaman iki parçayı aynı anda işleriz.
        // GÜVENLİK: `[u8]` in `[usize]` e dönüştürülmesi, `align_to` tarafından ele alınan boyut farklılıkları dışında güvenlidir.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Metnin gövdesini arayın, min_aligned_offset'i geçmediğimizden emin olun.
    // ofset her zaman hizalıdır, bu nedenle yalnızca `>` i test etmek yeterlidir ve olası taşmayı önler.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // GÜVENLİK: ofset, suffix.len() ten büyük olduğu sürece len'de başlar.
        // min_aligned_offset (prefix.len()) kalan mesafe en az 2 * yığın_bayttır.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Eşleşen bir bayt varsa kırın.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Vücut döngüsünün durduğu noktadan önceki baytı bulun.
    text[..offset].iter().rposition(|elt| *elt == x)
}