// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` aralığını, `mid` teki öğe ilk öğe olacak şekilde döndürür.Aynı şekilde, aralık `left` öğelerini sola veya `right` öğelerini sağa döndürür.
///
/// # Safety
///
/// Belirtilen aralık okuma ve yazma için geçerli olmalıdır.
///
/// # Algorithm
///
/// Algoritma 1, küçük `left + right` değerleri veya büyük `T` için kullanılır.
/// Öğeler, `mid - left` ten başlayarak ve `right` modulo `left + right` adımlarıyla ilerleyerek birer birer nihai konumlarına taşınır, öyle ki sadece bir geçici gereklidir.
/// Sonunda `mid - left` e geri dönüyoruz.
/// Bununla birlikte, `gcd(left + right, right)` 1 değilse, yukarıdaki adımlar elemanların üzerinden atlanır.
/// Örneğin:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Neyse ki, sonlandırılmış öğeler arasında atlanan öğelerin sayısı her zaman eşittir, bu nedenle başlangıç konumumuzu kaydırabilir ve daha fazla tur yapabiliriz (toplam tur sayısı `gcd(left + right, right)` value) tir.
///
/// Sonuç, tüm unsurların bir kez ve yalnızca bir kez sonlandırılmasıdır.
///
/// Algoritma 2, `left + right` büyükse ancak `min(left, right)` bir yığın arabelleğine sığacak kadar küçükse kullanılır.
/// `min(left, right)` öğeleri tampona kopyalanır, `memmove` diğerlerine uygulanır ve tampon üzerindekiler geldikleri yerin karşı tarafındaki deliğe geri taşınır.
///
/// Vektörize edilebilen algoritmalar, `left + right` yeterince büyük hale geldiğinde yukarıdakilerden daha iyi performans gösterir.
/// Algoritma 1, aynı anda birçok tur atılarak ve gerçekleştirilerek vektörleştirilebilir, ancak `left + right` çok büyük olana kadar ortalamada çok az tur vardır ve tek bir turun en kötü durumu her zaman oradadır.
/// Bunun yerine, algoritma 3, daha küçük bir döndürme sorunu kalana kadar `min(left, right)` öğelerinin tekrar tekrar değiştirilmesini kullanır.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` olduğunda, takas, bunun yerine soldan gerçekleşir.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. Bu durumlar kontrol edilmezse aşağıdaki algoritmalar başarısız olabilir
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritma 1 Microbenchmark, rastgele vardiyalar için ortalama performansın `left + right == 32` e kadar tüm yol boyunca daha iyi olduğunu, ancak en kötü durum performansının 16 civarında kırıldığını gösteriyor.
            // 24 orta yol seçildi.
            // `T` in boyutu 4 "kullanım boyutundan" büyükse, bu algoritma aynı zamanda diğer algoritmalardan daha iyi performans gösterir.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ilk turun başlangıcı
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` i hesaplayarak elden önce bulunabilir, ancak gcd'yi bir yan etki olarak hesaplayan bir döngü yapmak ve ardından yığının geri kalanını yapmak daha hızlıdır.
            //
            //
            let mut gcd = right;
            // Kıyaslamalar, geçici bir tane okumak, geriye doğru kopyalamak ve en sonunda geçici olarak yazmak yerine, geçicilerin tamamını değiştirmenin daha hızlı olduğunu ortaya koymaktadır.
            // Bunun nedeni, muhtemelen geçicilerin değiştirilmesi veya değiştirilmesinin, ikisini yönetmeye ihtiyaç duymak yerine döngüde yalnızca bir bellek adresi kullanması gerçeğidir.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` i artırmak ve ardından sınırların dışında olup olmadığını kontrol etmek yerine, `i` in bir sonraki artışta sınırların dışına çıkıp çıkmayacağını kontrol ederiz.
                // Bu, herhangi bir işaretçi veya `usize` in sarılmasını önler.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // ilk turun sonu
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` ise bu koşul burada olmalıdır
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // daha fazla turla parçayı bitir
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` sıfır boyutlu bir tür olmadığından, boyutuna göre bölmekte sorun yoktur.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritma 2 Buradaki `[T; 0]`, bunun T için uygun şekilde hizalandığından emin olmak içindir.
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritma 3 Bu algoritmanın son takasının nerede olacağını bulmayı ve bu algoritmanın yaptığı gibi bitişik parçaları değiştirmek yerine bu son parçayı kullanarak takas etmeyi içeren alternatif bir takas yolu vardır, ancak bu yol hala daha hızlıdır.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritma 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}