//! Dilim sıralama
//!
//! Bu modül, aşağıdaki adreste yayınlanan Orson Peters'ın kalıp bozucu hızlı sıralamasına dayalı bir sıralama algoritması içerir: <https://github.com/orlp/pdqsort>
//!
//!
//! Kararsız sıralama, kararlı sıralama uygulamamızın aksine, bellek ayırmadığı için libcore ile uyumludur.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Düşürüldüğünde, `src` ten `dest` e kopyalar.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // GÜVENLİK: Bu bir yardımcı sınıftır.
        //          Doğruluk için lütfen kullanımına bakın.
        //          Yani, `src` ve `dst` in `ptr::copy_nonoverlapping` in gerektirdiği gibi çakışmadığından emin olunmalıdır.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// İlk öğeyi daha büyük veya eşit bir öğeyle karşılaşana kadar sağa kaydırır.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // GÜVENLİK: Aşağıdaki güvenli olmayan işlemler, bağlı bir kontrol olmadan indekslemeyi içerir (`get_unchecked` ve `get_unchecked_mut`)
    // ve bellek (`ptr::copy_nonoverlapping`) in kopyalanması.
    //
    // a.Endeksleme:
    //  1. Dizinin boyutunu>=2 olarak kontrol ettik.
    //  2. Yapacağımız tüm indeksleme her zaman en fazla {0 <= index < len} arasındadır.
    //
    // b.Hafıza kopyalama
    //  1. Geçerli olduğu garanti edilen referanslara işaretler alıyoruz.
    //  2. Örtüşemezler çünkü dilimin farklı indekslerini gösteren işaretçiler elde ederiz.
    //     Yani `i` ve `i-1`.
    //  3. Dilim doğru şekilde hizalanmışsa, öğeler düzgün şekilde hizalanır.
    //     Dilimin doğru şekilde hizalandığından emin olmak arayanın sorumluluğundadır.
    //
    // Daha fazla ayrıntı için aşağıdaki yorumlara bakın.
    unsafe {
        // İlk iki öğe arızalıysa ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // İlk öğeyi yığına ayrılmış bir değişkene okuyun.
            // Aşağıdaki bir karşılaştırma işlemi panics ise, `hole` düşecek ve elemanı otomatik olarak dilime geri yazacaktır.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // "İ" öğesini bir sola hareket ettirin, böylece deliği sağa kaydırın.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` düşürülür ve böylece `tmp` i `v` teki kalan deliğe kopyalar.
        }
    }
}

/// Son öğeyi, daha küçük veya eşit bir öğeyle karşılaşana kadar sola kaydırır.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // GÜVENLİK: Aşağıdaki güvenli olmayan işlemler, bağlı bir kontrol olmadan indekslemeyi içerir (`get_unchecked` ve `get_unchecked_mut`)
    // ve bellek (`ptr::copy_nonoverlapping`) in kopyalanması.
    //
    // a.Endeksleme:
    //  1. Dizinin boyutunu>=2 olarak kontrol ettik.
    //  2. Yapacağımız tüm indeksleme her zaman en fazla `0 <= index < len-1` arasındadır.
    //
    // b.Hafıza kopyalama
    //  1. Geçerli olduğu garanti edilen referanslara işaretler alıyoruz.
    //  2. Örtüşemezler çünkü dilimin farklı indekslerini gösteren işaretçiler elde ederiz.
    //     Yani `i` ve `i+1`.
    //  3. Dilim doğru şekilde hizalanmışsa, öğeler düzgün şekilde hizalanır.
    //     Dilimin doğru şekilde hizalandığından emin olmak arayanın sorumluluğundadır.
    //
    // Daha fazla ayrıntı için aşağıdaki yorumlara bakın.
    unsafe {
        // Son iki öğe arızalıysa ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Son öğeyi yığına ayrılmış bir değişkene okuyun.
            // Aşağıdaki bir karşılaştırma işlemi panics ise, `hole` düşecek ve elemanı otomatik olarak dilime geri yazacaktır.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // "İ" öğesinin bir yerini sağa taşıyın, böylece deliği sola kaydırın.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` düşürülür ve böylece `tmp` i `v` teki kalan deliğe kopyalar.
        }
    }
}

/// Birkaç sıra dışı öğeyi kaydırarak bir dilimi kısmen sıralar.
///
/// Dilim sonunda sıralanırsa `true` döndürür.Bu işlev *O*(*n*) en kötü durumdur.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Kaydırılacak maksimum bitişik sıra dışı çift sayısı.
    const MAX_STEPS: usize = 5;
    // Dilim bundan daha kısaysa, herhangi bir öğeyi kaydırmayın.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // GÜVENLİK: `i < len` ile sınır kontrolünü zaten açıkça yaptık.
        // Sonraki tüm indekslememiz yalnızca `0 <= index < len` aralığındadır
        unsafe {
            // Bir sonraki bitişik sıra dışı öğe çiftini bulun.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Tamam mıyız?
        if i == len {
            return true;
        }

        // Performans maliyeti olan kısa dizilerdeki öğeleri kaydırmayın.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Bulunan öğe çiftini değiştirin.Bu onları doğru sıraya koyar.
        v.swap(i - 1, i);

        // Daha küçük öğeyi sola kaydırın.
        shift_tail(&mut v[..i], is_less);
        // Büyük öğeyi sağa kaydırın.
        shift_head(&mut v[i..], is_less);
    }

    // Dilimi sınırlı sayıda adımda sıralamayı başaramadı.
    false
}

/// *O*(*n*^ 2) en kötü durum olan ekleme sıralaması kullanarak bir dilimi sıralar.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// *O*(*n*\*log(* n*)) en kötü durumu garanti eden yığın sıralaması kullanarak `v` i sıralar.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Bu ikili yığın, değişmez `parent >= child` e saygı duyar.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` in çocukları:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Büyük çocuğu seçin.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Değişmez `node` te tutarsa dur.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // `node` i büyük çocukla değiştirin, bir adım aşağı gidin ve elemeye devam edin.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Yığını doğrusal zamanda oluşturun.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Yığından maksimal öğeleri pop.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` i `pivot` ten daha küçük öğelere böler, ardından `pivot` e eşit veya daha büyük öğeler gelir.
///
///
/// `pivot` ten küçük öğelerin sayısını döndürür.
///
/// Dallanma işlemlerinin maliyetini en aza indirmek için bölümleme, bloklar halinde gerçekleştirilir.
/// Bu fikir [BlockQuicksort][pdf] belgesinde sunulmuştur.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Tipik bir bloktaki eleman sayısı.
    const BLOCK: usize = 128;

    // Bölümleme algoritması tamamlanana kadar aşağıdaki adımları tekrarlar:
    //
    // 1. Pivottan büyük veya ona eşit öğeleri belirlemek için sol taraftan bir blok izleyin.
    // 2. Pivottan daha küçük öğeleri belirlemek için sağ taraftan bir blok izleyin.
    // 3. Tanımlanan öğeleri sol ve sağ taraf arasında değiştirin.
    //
    // Bir eleman bloğu için aşağıdaki değişkenleri tutuyoruz:
    //
    // 1. `block` - Bloktaki elemanların sayısı.
    // 2. `start` - İşaretçiyi `offsets` dizisine başlatın.
    // 3. `end` - `offsets` dizisine son işaretçi.
    // 4. `ofsetler, blok içindeki sıra dışı elemanların endeksleri.

    // Sol taraftaki mevcut blok (`l` ten `l.add(block_l)`) e.
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Sağ taraftaki mevcut blok (`r.sub(block_r)` to `r`) ten.
    // GÜVENLİK: .add() belgeleri özellikle `vec.as_ptr().add(vec.len())` in her zaman güvenli olduğunu belirtmektedir`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: VLA'lar aldığımızda, bir dizi uzunluk `min(v.len(), 2 * BLOCK) oluşturmayı deneyin.
    // `BLOCK` uzunluğundaki iki sabit boyutlu diziden daha fazla.VLA'lar önbellek açısından daha verimli olabilir.

    // `l` (inclusive) ve `r` (exclusive) işaretçileri arasındaki öğelerin sayısını döndürür.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` ve `r` çok yaklaştığında blok blok bölümleme işimiz bitti.
        // Ardından, aradaki kalan öğeleri bölümlere ayırmak için bazı yama çalışmaları yaparız.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Kalan elemanların sayısı (hala pivot ile karşılaştırılmamış).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Blok boyutlarını, sol ve sağ blok üst üste binmeyecek şekilde ayarlayın, ancak kalan tüm boşluğu kapatmak için mükemmel bir şekilde hizalayın.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // `block_l` öğelerini sol taraftan izleyin.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // GÜVENLİK: Aşağıdaki güvenlik işlemleri `offset` in kullanımını içerir.
                //         İşlevin gerektirdiği koşullara göre onları tatmin etmekteyiz çünkü:
                //         1. `offsets_l` yığın tahsis edilir ve bu nedenle ayrı tahsis edilmiş nesne olarak kabul edilir.
                //         2. `is_less` işlevi bir `bool` döndürür.
                //            Bir `bool` i kullanmak asla `isize` i aşmaz.
                //         3. `block_l` in `<= BLOCK` olacağını garanti ettik.
                //            Artı, `end_l` başlangıçta yığın üzerinde bildirilen `offsets_` in başlangıç işaretçisine ayarlandı.
                //            Bu nedenle, en kötü durumda bile (`is_less` in tüm çağrıları yanlış döndürür) en fazla 1 bayt sonunda sona ereceğimizi biliyoruz.
                //        Buradaki diğer bir güvenli olmayan işlem, `elem` in referansının kaldırılmasıdır.
                //        Ancak, `elem` başlangıçta her zaman geçerli olan dilimin başlangıç göstergesiydi.
                unsafe {
                    // Dalsız karşılaştırma.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // `block_r` öğelerini sağ taraftan izleyin.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // GÜVENLİK: Aşağıdaki güvenlik işlemleri `offset` in kullanımını içerir.
                //         İşlevin gerektirdiği koşullara göre onları tatmin etmekteyiz çünkü:
                //         1. `offsets_r` yığın tahsis edilir ve bu nedenle ayrı tahsis edilmiş nesne olarak kabul edilir.
                //         2. `is_less` işlevi bir `bool` döndürür.
                //            Bir `bool` i kullanmak asla `isize` i aşmaz.
                //         3. `block_r` in `<= BLOCK` olacağını garanti ettik.
                //            Artı, `end_r` başlangıçta yığın üzerinde bildirilen `offsets_` in başlangıç işaretçisine ayarlandı.
                //            Bu nedenle, en kötü durumda bile (`is_less` in tüm çağrıları doğru döndürür) en fazla 1 baytlık sonda olacağımızı biliyoruz.
                //        Buradaki diğer bir güvenli olmayan işlem, `elem` in referansının kaldırılmasıdır.
                //        Bununla birlikte, `elem` başlangıçta `1 *sizeof(T)` sonunu geçmişti ve erişmeden önce `1* sizeof(T)` kadar düşürdük.
                //        Artı, `block_r` in `BLOCK` ten daha küçük olduğu iddia edildi ve bu nedenle `elem`, en fazla dilimin başlangıcına işaret edecek.
                unsafe {
                    // Dalsız karşılaştırma.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Sol ve sağ taraf arasında değiş tokuş edilecek sıra dışı öğelerin sayısı.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Bir seferde bir çifti değiştirmek yerine, döngüsel bir permütasyon gerçekleştirmek daha verimlidir.
            // Bu, tam anlamıyla takas etmeye eşdeğer değildir, ancak daha az bellek işlemi kullanarak benzer bir sonuç üretir.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Sol bloktaki tüm sıra dışı öğeler taşındı.Sonraki bloğa geçin.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Sağ bloktaki tüm sıra dışı öğeler taşındı.Önceki bloğa git.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Şimdi geriye kalan tek şey, taşınması gereken sıra dışı öğeler içeren en fazla bir bloktur (sol veya sağ).
    // Bu tür kalan elemanlar, blokları içinde basitçe sona kaydırılabilir.
    //

    if start_l < end_l {
        // Sol blok kalır.
        // Kalan sıra dışı öğelerini en sağa taşıyın.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Sağ blok kalır.
        // Kalan sıra dışı öğelerini en sola taşıyın.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Yapacak başka bir şey yok, işimiz bitti.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` i `v[pivot]` ten daha küçük öğelere böler, ardından `v[pivot]` e eşit veya daha büyük öğeler gelir.
///
///
/// Şunların bir demetini döndürür:
///
/// 1. `v[pivot]` ten küçük elemanların sayısı.
/// 2. `v` zaten bölümlenmişse doğrudur.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Pivotu dilimin başlangıcına yerleştirin.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Verimlilik için pivotu yığına ayrılmış bir değişken olarak okuyun.
        // Aşağıdaki bir karşılaştırma işlemi panics ise, pivot otomatik olarak dilime geri yazılacaktır.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // İlk sıra dışı öğe çiftini bulun.
        let mut l = 0;
        let mut r = v.len();

        // GÜVENLİK: Aşağıdaki güvenlik, bir dizinin indekslenmesini içerir.
        // İlki için: `l < r` ile burada sınırları kontrol ediyoruz.
        // İkincisi için: Başlangıçta `l == 0` ve `r == v.len()` e sahibiz ve her indeksleme işleminde `l < r` i kontrol ettik.
        //                     Buradan, `r` in ilkinden geçerli olduğu gösterilen en az `r == l` olması gerektiğini biliyoruz.
        unsafe {
            // Pivot değerine eşit veya daha büyük olan ilk öğeyi bulun.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Pivottan daha küçük olan son öğeyi bulun.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` kapsam dışına çıkar ve pivotu (yığına ayrılmış bir değişken olan) orijinal olduğu dilime geri yazar.
        // Bu adım, güvenliğin sağlanması açısından kritiktir!
        //
    };

    // Pivotu iki bölüm arasına yerleştirin.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` i `v[pivot]` e eşit öğelere ve ardından `v[pivot]` ten büyük öğelere böler.
///
/// Pivota eşit öğelerin sayısını döndürür.
/// `v` in pivottan daha küçük öğeler içermediği varsayılır.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Pivotu dilimin başlangıcına yerleştirin.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Verimlilik için pivotu yığına ayrılmış bir değişken olarak okuyun.
    // Aşağıdaki bir karşılaştırma işlemi panics ise, pivot otomatik olarak dilime geri yazılacaktır.
    // GÜVENLİK: Buradaki işaretçi, bir dilime referansla elde edildiği için geçerlidir.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Şimdi dilimi böl.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // GÜVENLİK: Aşağıdaki güvenlik, bir dizinin indekslenmesini içerir.
        // İlki için: `l < r` ile burada sınırları kontrol ediyoruz.
        // İkincisi için: Başlangıçta `l == 0` ve `r == v.len()` e sahibiz ve her indeksleme işleminde `l < r` i kontrol ettik.
        //                     Buradan, `r` in ilkinden geçerli olduğu gösterilen en az `r == l` olması gerektiğini biliyoruz.
        unsafe {
            // Pivottan daha büyük olan ilk öğeyi bulun.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Pivot'a eşit olan son öğeyi bulun.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Tamam mıyız?
            if l >= r {
                break;
            }

            // Bulunan sıra dışı öğe çiftini değiştirin.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // `l` öğelerini pivota eşit bulduk.Pivotun kendisini hesaba katmak için 1 ekleyin.
    l + 1

    // `_pivot_guard` kapsam dışına çıkar ve pivotu (yığına ayrılmış bir değişken olan) orijinal olduğu dilime geri yazar.
    // Bu adım, güvenliğin sağlanması açısından kritiktir!
}

/// Hızlı sıralamada dengesiz bölümlere neden olabilecek kalıpları kırmak için bazı öğeleri etrafa saçar.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // George Marsaglia'nın yazdığı "Xorshift RNGs" makalesinden sözde rasgele sayı üreteci.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Bu sayıyı modulo rastgele sayılar alın.
        // Sayı `usize` e uyuyor çünkü `len`, `isize::MAX` ten büyük değil.
        let modulus = len.next_power_of_two();

        // Bazı pivot adayları bu dizinin yakınında olacak.Onları rastgele sıralayalım.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Rastgele sayı modulo `len` oluşturun.
            // Bununla birlikte, maliyetli işlemlerden kaçınmak için, önce onu ikiye katlıyoruz ve ardından `[0, len - 1]` aralığına uyana kadar `len` kadar düşürüyoruz.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` ten daha az olması garantilidir.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` te bir pivot seçer ve dilim büyük olasılıkla önceden sıralanmışsa dizini ve `true` i döndürür.
///
/// `v` teki öğeler işlem sırasında yeniden sıralanabilir.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ortanca medyan yöntemini seçmek için minimum uzunluk.
    // Daha kısa dilimler, basit ortanca üç yöntemini kullanır.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Bu işlevde gerçekleştirilebilecek maksimum takas sayısı.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Yakınında bir pivot seçeceğimiz üç endeks.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Endeksleri sıralarken gerçekleştirmek üzere olduğumuz toplam takas sayısını sayar.
    let mut swaps = 0;

    if len >= 8 {
        // Endeksleri `v[a] <= v[b]` olacak şekilde değiştirir.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Endeksleri `v[a] <= v[b] <= v[c]` olacak şekilde değiştirir.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` in medyanını bulur ve dizini `a` e kaydeder.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b` ve `c` mahallelerinde medyanları bulun.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b` ve `c` arasındaki medyanı bulun.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Maksimum sayıda takas yapıldı.
        // Muhtemelen dilim alçalıyor veya çoğunlukla alçalıyor, bu nedenle ters çevirmek muhtemelen daha hızlı sıralamanıza yardımcı olacaktır.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` i yinelemeli olarak sıralar.
///
/// Dilimin orijinal dizide bir öncülü varsa, `pred` olarak belirtilir.
///
/// `limit` `heapsort` e geçmeden önce izin verilen dengesiz bölümlerin sayısıdır.
/// Sıfırsa, bu işlev hemen yığın sırasına geçecektir.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Bu uzunluğa kadar olan dilimler, ekleme sıralaması kullanılarak sıralanır.
    const MAX_INSERTION: usize = 20;

    // Son bölümleme makul bir şekilde dengelenmişse doğrudur.
    let mut was_balanced = true;
    // Son bölümleme öğeleri karıştırmadıysa doğrudur (dilim zaten bölümlenmişti).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Çok kısa dilimler, eklemeli sıralama kullanılarak sıralanır.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Çok fazla kötü pivot seçimi yapılmışsa, `O(n * log(n))` in en kötü durumunu garanti etmek için yığın sıralamasına geri dönün.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Son bölümleme dengesizse, bazı öğeleri karıştırarak dilimdeki desenleri kırmayı deneyin.
        // Umarım bu sefer daha iyi bir pivot seçeriz.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Bir özet seçin ve dilimin önceden sıralanmış olup olmadığını tahmin etmeye çalışın.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Son bölümleme düzgün bir şekilde dengelendiyse ve öğeleri karıştırmadıysa ve pivot seçimi, dilim büyük olasılıkla önceden sıralanmışsa ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Birkaç sıra dışı öğeyi tanımlamayı ve bunları doğru konumlara kaydırmayı deneyin.
            // Dilim tamamen sıralanırsa, işimiz biter.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Seçilen pivot, öncekine eşitse, dilimdeki en küçük öğedir.
        // Dilimi pivota eşit ve pivottan daha büyük öğelere bölün.
        // Bu durum genellikle dilim birçok yinelenen öğe içerdiğinde vurulur.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Pivottan daha büyük öğeleri sıralamaya devam edin.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Dilimi böl.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Dilimi `left`, `pivot` ve `right` e bölün.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Toplam yinelemeli çağrı sayısını en aza indirmek ve daha az yığın alanı tüketmek için yalnızca kısa tarafa yineleyin.
        // Daha sonra uzun tarafla devam edin (bu, kuyruk özyinelemesine benzer).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// *O*(*n*\*log(* n*)) en kötü durum olan desen bozan hızlı sıralama kullanarak `v` i sıralar.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sıralama, sıfır boyutlu türlerde anlamlı bir davranışa sahip değildir.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Dengesiz bölümlerin sayısını `floor(log2(len)) + 1` ile sınırlayın.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Bu uzunluğa kadar dilimler için bunları basitçe sıralamak muhtemelen daha hızlıdır.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Bir pivot seçin
        let (pivot, _) = choose_pivot(v, is_less);

        // Seçilen pivot, öncekine eşitse, dilimdeki en küçük öğedir.
        // Dilimi pivota eşit ve pivottan daha büyük öğelere bölün.
        // Bu durum genellikle dilim birçok yinelenen öğe içerdiğinde vurulur.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Endeksimizi geçtiysek, o zaman iyiyiz.
                if mid > index {
                    return;
                }

                // Aksi takdirde, pivottan daha büyük öğeleri sıralamaya devam edin.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Dilimi `left`, `pivot` ve `right` e bölün.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Mid==indeks ise, işimiz bitti, çünkü partition(), mid'den sonraki tüm öğelerin mid'den büyük veya orta değerine eşit olmasını garanti etti.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sıralama, sıfır boyutlu türlerde anlamlı bir davranışa sahip değildir.Hiçbir şey yapma.
    } else if index == v.len() - 1 {
        // Max elemanını bulun ve dizinin son konumuna yerleştirin.
        // `unwrap()` i burada kullanmakta özgürüz çünkü v'nin boş olmaması gerektiğini biliyoruz.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Min elemanını bulun ve dizinin ilk konumuna yerleştirin.
        // `unwrap()` i burada kullanmakta özgürüz çünkü v'nin boş olmaması gerektiğini biliyoruz.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}