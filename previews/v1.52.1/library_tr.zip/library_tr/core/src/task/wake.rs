#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker`, bir görev yürütücüsünün uygulayıcısının özelleştirilmiş uyandırma davranışı sağlayan bir [`Waker`] oluşturmasına izin verir.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Bir veri işaretçisi ve `RawWaker` in davranışını özelleştiren bir [virtual function pointer table (vtable)][vtable] den oluşur.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Yürütücünün gerektirdiği şekilde rastgele verileri depolamak için kullanılabilen bir veri işaretçisi.
    /// Bu örneğin olabilir
    /// görevle ilişkilendirilmiş bir `Arc` için türü silinmiş bir işaretçi.
    /// Bu alanın değeri, ilk parametre olarak vtable'ın parçası olan tüm işlevlere aktarılır.
    ///
    data: *const (),
    /// Bu uyandırıcının davranışını özelleştiren sanal işlev işaretçi tablosu.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Sağlanan `data` işaretçisinden ve `vtable` ten yeni bir `RawWaker` oluşturur.
    ///
    /// `data` işaretçisi, yürütücünün gerektirdiği şekilde rastgele verileri depolamak için kullanılabilir.Bu örneğin olabilir
    /// görevle ilişkilendirilmiş bir `Arc` için türü silinmiş bir işaretçi.
    /// Bu işaretçinin değeri, ilk parametre olarak `vtable` in parçası olan tüm işlevlere aktarılacaktır.
    ///
    /// `vtable`, bir `RawWaker` ten oluşturulan bir `Waker` in davranışını özelleştirir.
    /// `Waker` üzerindeki her işlem için, temel alınan `RawWaker` in `vtable` indeki ilişkili işlev çağrılacaktır.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Bir [`RawWaker`] in davranışını belirten bir sanal fonksiyon işaretçi tablosu (vtable).
///
/// Vtable içindeki tüm işlevlere aktarılan işaretçi, onu çevreleyen [`RawWaker`] nesnesinden `data` göstericisidir.
///
/// Bu yapının içindeki işlevlerin yalnızca, [`RawWaker`] uygulamasının içinden uygun şekilde oluşturulmuş bir [`RawWaker`] nesnesinin `data` işaretçisinde çağrılması amaçlanmıştır.
/// Diğer herhangi bir `data` işaretçisini kullanarak içerilen işlevlerden birini çağırmak tanımsız davranışa neden olacaktır.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Bu işlev, [`RawWaker`] klonlandığında, örneğin [`RawWaker`] in depolandığı [`Waker`] klonlandığında çağrılacaktır.
    ///
    /// Bu işlevin uygulanması, bir [`RawWaker`] in bu ek örneği ve ilgili görev için gerekli olan tüm kaynakları korumalıdır.
    /// Sonuçta elde edilen [`RawWaker`] te `wake` in çağrılması, orijinal [`RawWaker`] tarafından uyandırılmış olan aynı görevin uyanmasıyla sonuçlanmalıdır.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Bu işlev, [`Waker`] te `wake` çağrıldığında çağrılacaktır.
    /// Bu [`RawWaker`] ile ilişkili görevi uyandırması gerekir.
    ///
    /// Bu işlevin uygulanması, bu [`RawWaker`] örneğiyle ve ilişkili görevle ilişkili tüm kaynakları serbest bıraktığınızdan emin olmalıdır.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Bu işlev, [`Waker`] te `wake_by_ref` çağrıldığında çağrılacaktır.
    /// Bu [`RawWaker`] ile ilişkili görevi uyandırması gerekir.
    ///
    /// Bu işlev `wake` e benzer, ancak sağlanan veri işaretçisini tüketmemelidir.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Bu işlev, bir [`RawWaker`] düştüğünde çağrılır.
    ///
    /// Bu işlevin uygulanması, bu [`RawWaker`] örneğiyle ve ilişkili görevle ilişkili tüm kaynakları serbest bıraktığınızdan emin olmalıdır.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Sağlanan `clone`, `wake`, `wake_by_ref` ve `drop` işlevlerinden yeni bir `RawWakerVTable` oluşturur.
    ///
    /// # `clone`
    ///
    /// Bu işlev, [`RawWaker`] klonlandığında, örneğin [`RawWaker`] in depolandığı [`Waker`] klonlandığında çağrılacaktır.
    ///
    /// Bu işlevin uygulanması, bir [`RawWaker`] in bu ek örneği ve ilgili görev için gerekli olan tüm kaynakları korumalıdır.
    /// Sonuçta elde edilen [`RawWaker`] te `wake` in çağrılması, orijinal [`RawWaker`] tarafından uyandırılmış olan aynı görevin uyanmasıyla sonuçlanmalıdır.
    ///
    /// # `wake`
    ///
    /// Bu işlev, [`Waker`] te `wake` çağrıldığında çağrılacaktır.
    /// Bu [`RawWaker`] ile ilişkili görevi uyandırması gerekir.
    ///
    /// Bu işlevin uygulanması, bu [`RawWaker`] örneğiyle ve ilişkili görevle ilişkili tüm kaynakları serbest bıraktığınızdan emin olmalıdır.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Bu işlev, [`Waker`] te `wake_by_ref` çağrıldığında çağrılacaktır.
    /// Bu [`RawWaker`] ile ilişkili görevi uyandırması gerekir.
    ///
    /// Bu işlev `wake` e benzer, ancak sağlanan veri işaretçisini tüketmemelidir.
    ///
    /// # `drop`
    ///
    /// Bu işlev, bir [`RawWaker`] düştüğünde çağrılır.
    ///
    /// Bu işlevin uygulanması, bu [`RawWaker`] örneğiyle ve ilişkili görevle ilişkili tüm kaynakları serbest bıraktığınızdan emin olmalıdır.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Eşzamansız bir görevin `Context` i.
///
/// Şu anda, `Context` yalnızca mevcut görevi uyandırmak için kullanılabilen bir `&Waker` e erişim sağlamaya hizmet etmektedir.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Ömrü değişmez olmaya zorlayarak varyans değişikliklerine karşı future'ye karşı koruma sağladığımızdan emin olun (bağımsız değişken-konum yaşam süreleri çelişkili, dönüş konumu yaşam süreleri ise eşdeğişken).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Bir `&Waker` ten yeni bir `Context` oluşturun.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Geçerli görev için `Waker` e bir referans döndürür.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Bir `Waker`, bir görevi uygulayıcısına çalıştırılmaya hazır olduğunu bildirerek uyandırmak için kullanılan bir tanıtıcıdır.
///
/// Bu tutamaç, yürütücüye özgü uyandırma davranışını tanımlayan bir [`RawWaker`] örneğini kapsüller.
///
///
/// [`Clone`], [`Send`] ve [`Sync`] i uygular.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Bu `Waker` ile ilişkili görevi uyandırın.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Gerçek uyandırma çağrısı, yürütücü tarafından tanımlanan uygulamaya sanal bir işlev çağrısı aracılığıyla delege edilir.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` i aramayın-waker `wake` tarafından tüketilecektir.
        crate::mem::forget(self);

        // GÜVENLİK: Bu güvenlidir çünkü `Waker::from_raw`,
        // kullanıcının `RawWaker` sözleşmesinin onaylandığını onaylamasını gerektiren `wake` ve `data` i başlatmak için.
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` i tüketmeden bu `Waker` ile ilişkili görevi uyandırın.
    ///
    /// Bu, `wake` e benzer, ancak sahip olunan bir `Waker` in mevcut olduğu durumda biraz daha az verimli olabilir.
    /// Bu yöntem `waker.clone().wake()` i aramaya tercih edilmelidir.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Gerçek uyandırma çağrısı, yürütücü tarafından tanımlanan uygulamaya sanal bir işlev çağrısı aracılığıyla delege edilir.
        //

        // GÜVENLİK: bkz. `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Bu `Waker` ve başka bir `Waker` aynı görevi uyandırdıysa `true` i döndürür.
    ///
    /// Bu işlev en iyi çaba esasına göre çalışır ve "Waker" aynı görevi uyandırsa bile yanlış döndürebilir.
    /// Bununla birlikte, bu işlev `true` i döndürürse, 'Waker'ın aynı görevi uyandıracağı garanti edilir.
    ///
    /// Bu işlev, öncelikle optimizasyon amacıyla kullanılır.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] ten yeni bir `Waker` oluşturur.
    ///
    /// ["RawWaker"] ve ["RawWakerVTable"] belgelerinde tanımlanan sözleşme onaylanmadıysa, döndürülen `Waker` in davranışı tanımsızdır.
    ///
    /// Bu nedenle bu yöntem güvensizdir.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // GÜVENLİK: Bu güvenlidir çünkü `Waker::from_raw`,
            // kullanıcının [`RawWaker`] sözleşmesinin onaylandığını onaylamasını gerektiren `clone` ve `data` i başlatmak için.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // GÜVENLİK: Bu güvenlidir çünkü `Waker::from_raw`,
        // kullanıcının `RawWaker` sözleşmesinin onaylandığını onaylamasını gerektiren `drop` ve `data` i başlatmak için.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}