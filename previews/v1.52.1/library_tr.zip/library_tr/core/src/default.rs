//! Anlamlı varsayılan değerlere sahip olabilecek türler için `Default` trait.

#![stable(feature = "rust1", since = "1.0.0")]

/// Bir türe kullanışlı bir varsayılan değer vermek için bir trait.
///
/// Bazen, bir tür varsayılan değere geri dönmek istersiniz ve bunun ne olduğu pek umurunuzda olmaz.
/// Bu genellikle bir dizi seçeneği tanımlayan "yapı" lar ile ortaya çıkar:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Bazı varsayılan değerleri nasıl tanımlayabiliriz?`Default` i kullanabilirsiniz:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Şimdi, tüm varsayılan değerleri alırsınız.Rust, çeşitli temel türler için `Default` i uygular.
///
/// Belirli bir seçeneği geçersiz kılmak, ancak yine de diğer varsayılanları korumak istiyorsanız:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Bu trait, türün tüm alanları `Default` i uygularsa `#[derive]` ile kullanılabilir.
/// `Derive`d olduğunda, her alanın türü için varsayılan değeri kullanacaktır.
///
/// ## `Default` i nasıl uygulayabilirim?
///
/// Varsayılan olması gereken türünüzün değerini döndüren `default()` yöntemi için bir uygulama sağlayın:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// Bir tür için "default value" i döndürür.
    ///
    /// Varsayılan değerler genellikle bir tür başlangıç değeri, kimlik değeri veya varsayılan olarak anlamlı olabilecek başka herhangi bir şeydir.
    ///
    ///
    /// # Examples
    ///
    /// Yerleşik varsayılan değerleri kullanma:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Kendin yapmak:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait'ye göre bir türün varsayılan değerini döndürür.
///
/// Döndürülecek tür bağlamdan çıkarılır;bu, `Default::default()` e eşdeğerdir ancak yazmak için daha kısadır.
///
/// Örneğin:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` in bir impl'ını oluşturan makro türetin.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }