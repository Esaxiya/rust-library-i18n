//! utf8 hata türünü tanımlar.

use crate::fmt;

/// Bir [`u8`] dizisini bir dizge olarak yorumlamaya çalışırken ortaya çıkabilecek hatalar.
///
/// Bu nedenle, örneğin hem ["String"] hem de ["&str"] için `from_utf8` ailesi işlevler ve yöntemler bu hatayı kullanır.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Bu hata türünün yöntemleri, yığın belleği ayırmadan `String::from_utf8_lossy` e benzer işlevsellik oluşturmak için kullanılabilir:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Geçerli UTF-8 in doğrulanmış olduğu dizideki dizini döndürür.
    ///
    /// `from_utf8(&input[..index])` in `Ok(_)` i döndüreceği maksimum dizindir.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector içinde bazı geçersiz baytlar
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Utf8Error döndürür
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // ikinci bayt burada geçersiz
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Arıza hakkında daha fazla bilgi sağlar:
    ///
    /// * `None`: girişin sonuna beklenmedik bir şekilde ulaşıldı.
    ///   `self.valid_up_to()` girişin sonundan itibaren 1 ila 3 bayttır.
    ///   Bir bayt akışının (bir dosya veya ağ soketi gibi) kodu aşamalı olarak çözülüyorsa, bu, UTF-8 bayt dizisi birden çok parçayı kapsayan geçerli bir `char` olabilir.
    ///
    ///
    /// * `Some(len)`: beklenmeyen bir baytla karşılaşıldı.
    ///   Sağlanan uzunluk, `valid_up_to()` tarafından verilen dizinde başlayan geçersiz bayt dizisidir.
    ///   Kayıplı kod çözme durumunda, bu diziden sonra (bir [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] eklendikten sonra) kod çözme devam etmelidir.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] kullanarak bir `bool` ayrıştırılırken döndürülen bir hata başarısız oluyor
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}