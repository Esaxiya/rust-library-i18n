//! String Pattern API.
//!
//! Desen API'si, bir dizede arama yaparken farklı desen türlerini kullanmak için genel bir mekanizma sağlar.
//!
//! Daha fazla ayrıntı için bkz. traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] ve [`DoubleEndedSearcher`].
//!
//! Bu API kararsız olmasına rağmen, [`str`] tipindeki kararlı API'ler aracılığıyla kullanıma sunulur.
//!
//! # Examples
//!
//! [`Pattern`] [`&str`][`str`], [`char`] için kararlı API'de [implemented][pattern-impls], [`char`] dilimleri ve `FnMut(char) -> bool` i uygulayan işlevler ve kapamalar.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // karakter deseni
//! assert_eq!(s.find('n'), Some(2));
//! // karakter dilimi desen
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // kapatma düzeni
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Bir dizge kalıbı.
///
/// `Pattern<'a>`, uygulama türünün bir [`&'a str`][str] te arama yapmak için bir dize modeli olarak kullanılabileceğini ifade eder.
///
/// Örneğin, hem `'a'` hem de `"aa"`, `"baaaab"` dizesindeki `1` dizininde eşleşen kalıplardır.
///
/// trait'nin kendisi, bir dizedeki modelin oluşumlarını bulmanın asıl işini yapan ilişkili bir [`Searcher`] tipi için bir kurucu görevi görür.
///
///
/// Modelin türüne bağlı olarak, [`str::find`] ve [`str::contains`] gibi yöntemlerin davranışı değişebilir.
/// Aşağıdaki tablo bu davranışlardan bazılarını açıklamaktadır.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Bu model için ilişkili arama
    type Searcher: Searcher<'a>;

    /// Aramak için `self` ve `haystack` ten ilişkili arayıcıyı oluşturur.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Desenin samanlıkta herhangi bir yerde eşleşip eşleşmediğini kontrol eder
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Samanlığın önündeki kalıbın eşleşip eşleşmediğini kontrol eder
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Samanlığın arkasındaki kalıbın eşleşip eşleşmediğini kontrol eder
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Eşleşiyorsa samanlığın önündeki deseni kaldırır.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // GÜVENLİK: `Searcher` in geçerli endeksler döndürdüğü bilinmektedir.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Eşleşiyorsa samanlığın arkasındaki deseni kaldırır.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // GÜVENLİK: `Searcher` in geçerli endeksler döndürdüğü bilinmektedir.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] veya [`ReverseSearcher::next_back()`] aramanın sonucu.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// `haystack[a..b]` te bir model eşleşmesinin bulunduğunu ifade eder.
    ///
    Match(usize, usize),
    /// `haystack[a..b]` in olası bir model eşleşmesi olarak reddedildiğini ifade eder.
    ///
    /// İki "Eşleşme" arasında birden fazla `Reject` olabileceğini unutmayın, bunların tek bir eşleşmede birleştirilmesine gerek yoktur.
    ///
    ///
    Reject(usize, usize),
    /// Yinelemeyi sonlandırarak samanlığın her baytının ziyaret edildiğini ifade eder.
    ///
    Done,
}

/// Bir dizi kalıbı arayan.
///
/// Bu trait, bir dizenin ön (left) inden başlayan bir modelin örtüşmeyen eşleşmelerini aramak için yöntemler sağlar.
///
/// [`Pattern`] trait'nin ilişkili `Searcher` türleri tarafından uygulanacaktır.
///
/// trait, [`next()`][Searcher::next] yöntemleri tarafından döndürülen dizinlerin samanlıktaki geçerli utf8 sınırları üzerinde olması gerektiğinden güvenli değil olarak işaretlenmiştir.
/// Bu, bu trait tüketicilerinin saman yığınını ek çalışma zamanı denetimleri olmadan dilimlemesine olanak tanır.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Aranacak temel dize için Getter
    ///
    /// Her zaman aynı [`&str`][str] i döndürür.
    fn haystack(&self) -> &'a str;

    /// Önden başlayarak bir sonraki arama adımını gerçekleştirir.
    ///
    /// - `haystack[a..b]` modelle eşleşirse [`Match(a, b)`][SearchStep::Match] i döndürür.
    /// - `haystack[a..b]` modelle kısmen de olsa eşleşemezse [`Reject(a, b)`][SearchStep::Reject] i döndürür.
    /// - Saman yığınının her baytı ziyaret edilmişse [`Done`][SearchStep::Done] döndürür.
    ///
    /// Bir [`Done`][SearchStep::Done] e kadar olan [`Match`][SearchStep::Match] ve [`Reject`][SearchStep::Reject] değerlerinin akışı, bitişik, üst üste binmeyen, tüm samanlığı kapsayan ve utf8 sınırlarında uzanan dizin aralıkları içerecektir.
    ///
    ///
    /// Bir [`Match`][SearchStep::Match] sonucunun tüm eşleşen modeli içermesi gerekir, ancak [`Reject`][SearchStep::Reject] sonuçları rastgele birçok bitişik parçaya bölünebilir.Her iki aralık da sıfır uzunluğa sahip olabilir.
    ///
    /// Örnek olarak, `"aaa"` deseni ve samanlık `"cbaaaaab"`, akışı oluşturabilir.
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Sonraki [`Match`][SearchStep::Match] sonucunu bulur.[`next()`][Searcher::next] e bakın.
    ///
    /// [`next()`][Searcher::next] ten farklı olarak, bunun döndürülen aralıklarının ve [`next_reject`][Searcher::next_reject] in çakışacağının garantisi yoktur.
    /// Bu, `(start_match, end_match)` i döndürecektir; burada start_match, eşleşmenin başladığı yerin dizini ve end_match, eşleşmenin bitiminden sonraki dizidir.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Sonraki [`Reject`][SearchStep::Reject] sonucunu bulur.[`next()`][Searcher::next] ve [`next_match()`][Searcher::next_match] e bakın.
    ///
    /// [`next()`][Searcher::next] ten farklı olarak, bunun döndürülen aralıklarının ve [`next_match`][Searcher::next_match] in çakışacağının garantisi yoktur.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Bir dizi modeli için ters arama.
///
/// Bu trait, bir dizenin arka (right) inden başlayarak bir modelin çakışmayan eşleşmelerini aramak için yöntemler sağlar.
///
/// Model arkadan aramayı destekliyorsa, [`Pattern`] trait'nin ilişkili [`Searcher`] türleri tarafından uygulanacaktır.
///
///
/// Bu trait tarafından döndürülen dizin aralıklarının, geriye doğru ileriye doğru aramanınkilerle tam olarak eşleşmesi gerekli değildir.
///
/// Bu trait'nin güvensiz olarak işaretlenmesinin nedeni için, onları ebeveyn trait [`Searcher`] e bakın.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Arkadan başlayarak bir sonraki arama adımını gerçekleştirir.
    ///
    /// - `haystack[a..b]` modelle eşleşirse [`Match(a, b)`][SearchStep::Match] i döndürür.
    /// - `haystack[a..b]` modelle kısmen de olsa eşleşemezse [`Reject(a, b)`][SearchStep::Reject] i döndürür.
    /// - Saman yığınının her baytı ziyaret edilmişse [`Done`][SearchStep::Done] döndürür
    ///
    /// Bir [`Done`][SearchStep::Done] e kadar olan [`Match`][SearchStep::Match] ve [`Reject`][SearchStep::Reject] değerlerinin akışı, bitişik, üst üste binmeyen, tüm samanlığı kapsayan ve utf8 sınırlarında uzanan dizin aralıkları içerecektir.
    ///
    ///
    /// Bir [`Match`][SearchStep::Match] sonucunun tüm eşleşen modeli içermesi gerekir, ancak [`Reject`][SearchStep::Reject] sonuçları rastgele birçok bitişik parçaya bölünebilir.Her iki aralık da sıfır uzunluğa sahip olabilir.
    ///
    /// Örnek olarak, `"aaa"` deseni ve `"cbaaaaab"` saman yığını, `[Reject(7, 8), Match(4, 7), Reject(1, 4) akışını oluşturabilir. Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Sonraki [`Match`][SearchStep::Match] sonucunu bulur.
    /// [`next_back()`][ReverseSearcher::next_back] e bakın.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Sonraki [`Reject`][SearchStep::Reject] sonucunu bulur.
    /// [`next_back()`][ReverseSearcher::next_back] e bakın.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Bir [`ReverseSearcher`] in bir [`DoubleEndedIterator`] uygulaması için kullanılabileceğini ifade eden bir trait işaretçisi.
///
/// Bunun için, [`Searcher`] ve [`ReverseSearcher`] impl'inin şu koşullara uyması gerekir:
///
/// - `next()` in tüm sonuçlarının `next_back()` in sonuçlarıyla ters sırada aynı olması gerekir.
/// - `next()` ve `next_back()` in bir değer aralığının iki ucu gibi davranması gerekir, yani "walk past each other" olamazlar.
///
/// # Examples
///
/// `char::Searcher` bir `DoubleEndedSearcher`, çünkü bir [`char`] i aramak, her iki uçtan da aynı şekilde davranan her seferinde birine bakmayı gerektirir.
///
/// `(&str)::Searcher` bir `DoubleEndedSearcher` değildir çünkü `"aaa"` samanlığındaki `"aa"` modeli, hangi taraftan arandığına bağlı olarak `"[aa]a"` veya `"a[aa]"` ile eşleşir.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Karakter için impl
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` için ilişkili tip.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // güvenlik değişmezi: `finger`/`finger_back`, `haystack` in geçerli bir utf8 bayt indeksi olmalıdır Bu değişmez,*next_match ve next_match_back içinde* kırılabilir, ancak geçerli kod noktası sınırlarında parmaklarla çıkmaları gerekir.
    //
    //
    /// `finger` ileriye doğru aramanın geçerli bayt dizinidir.
    /// İndeksindeki bayttan önce var olduğunu düşünün, yani
    /// `haystack[finger]` ileriye doğru arama sırasında incelememiz gereken dilimin ilk baytıdır
    ///
    finger: usize,
    /// `finger_back` ters aramanın geçerli bayt dizinidir.
    /// İndeksinde bayttan sonra var olduğunu düşünün, yani
    /// samanlık [finger_back, 1], ileriye doğru arama sırasında incelememiz gereken dilimin son baytıdır (ve dolayısıyla next_back()) çağrılırken incelenecek ilk bayttır.
    ///
    finger_back: usize,
    /// Aranan karakter
    needle: char,

    // güvenlikle ilgili değişmez: `utf8_size`, 5'ten küçük olmalıdır
    /// utf8 te kodlandığında `needle` bayt sayısı kaplanır.
    utf8_size: usize,
    /// `needle` in utf8 kodlu bir kopyası
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // GÜVENLİK: 1-4 `get_unchecked` in güvenliğini garanti eder
        // 1. `self.finger` ve `self.finger_back` unicode sınırlarında tutulur (bu değişmez)
        // 2. `self.finger >= 0` 0'da başladığı ve yalnızca arttığı için
        // 3. `self.finger < self.finger_back` çünkü aksi takdirde `iter` karakteri `SearchStep::Done` i döndürür
        // 4.
        // `self.finger` samanlığın sonundan önce gelir çünkü `self.finger_back` sonunda başlar ve yalnızca azalır
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 olarak yeniden kodlamadan mevcut karakterin bayt ofsetini ekle
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // bulunan son karakterden sonra samanlığı al
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 kodlu iğnenin son baytı GÜVENLİK: `utf8_size < 5` in
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Karakterin son baytını hatırladığımız için yeni parmak, bulduğumuz bayt artı bir dizinidir.
                //
                // Bunun bize her zaman UTF8 sınırında bir parmak vermediğini unutmayın.
                // Karakterimizi *bulamadıysak*, 3 baytlık veya 4 baytlık bir karakterin son olmayan baytını indekslemiş olabiliriz.
                // Bir sonraki geçerli başlangıç baytına geçemeyiz çünkü (U + A041 YI HECE PA), utf-8 `EA 81 81` gibi bir karakter üçüncü baytı ararken her zaman ikinci baytı bulmamızı sağlayacaktır.
                //
                //
                // Ancak, bu tamamen sorun değil.
                // self.finger in bir UTF8 sınırında olduğu değişmezine sahip olsak da, bu değişmez bu yöntemde güvenilmez (CharSearcher::next()) te güvenilmektedir.
                //
                // Bu yöntemden yalnızca dizenin sonuna ulaştığımızda veya bir şey bulduğumuzda çıkıyoruz.Bir şey bulduğumuzda, `finger` bir UTF8 sınırına ayarlanacaktır.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // hiçbir şey bulunamadı, çık
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // next_reject'in Searcher trait'deki varsayılan uygulamayı kullanmasına izin verin
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // GÜVENLİK: yukarıdaki next() yorumuna bakın
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // utf-8 olarak yeniden kodlamadan mevcut karakterin bayt ofsetini çıkarın
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // samanlığı getirin, ancak aranan son karakteri dahil etmeyin
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 kodlu iğnenin son baytı GÜVENLİK: `utf8_size < 5` in
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // self.finger ile dengelenmiş bir dilim aradık, orijinal dizini telafi etmek için self.finger ekleyin
                //
                let index = self.finger + index;
                // memrchr, bulmak istediğimiz baytın dizinini döndürecektir.
                // Bir ASCII karakter durumunda, bu gerçekten de yeni parmağımızın olmasını diliyorduk ("after" ters iterasyon paradigmasında bulunan karakter).
                //
                // Çok baytlı karakterler için ASCII'den daha fazla bayta sahip olduklarına göre atlamamız gerekir.
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // parmağınızı bulunan karakterin öncesine hareket ettirin (yani başlangıç dizininde)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Burada finger_back=index, size + 1 kullanamayız.
                // Farklı boyutta bir karakterin son karakterini (veya farklı bir karakterin orta baytını) bulursak, finger_back'i `index` e düşürmemiz gerekir.
                // Bu benzer şekilde `finger_back` in artık bir sınırda olma potansiyeline sahip olmasını sağlar, ancak bu tamamdır çünkü bu işlevden yalnızca bir sınırda veya samanlık tamamen arandığında çıkıyoruz.
                //
                //
                // Next_match'in aksine, bu utf-8 te tekrarlanan bayt sorununa sahip değildir çünkü son baytı arıyoruz ve yalnızca son baytı ters yönde arama yaparken bulabiliriz.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // hiçbir şey bulunamadı, çık
                return None;
            }
        }
    }

    // next_reject_back'in Searcher trait'deki varsayılan uygulamayı kullanmasına izin verin
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Belirli bir [`char`] e eşit olan karakterleri arar.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// MultiCharEq sarmalayıcı için impl
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Mevcut karakterin uzunluğunu bulmak için dahili bayt dilim yineleyicisinin uzunluklarını karşılaştırın
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Mevcut karakterin uzunluğunu bulmak için dahili bayt dilim yineleyicisinin uzunluklarını karşılaştırın
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// &[Char] için impl
/////////////////////////////////////////////////////////////////////////////

// Todo: Anlamdaki belirsizlik nedeniyle Değiştir/Kaldır.

/// `<&[char] as Pattern<'a>>::Searcher` için ilişkili tip.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Dilimdeki [`char`] 'lerden herhangi birine eşit olan karakterleri arar.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// F için impl: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` için ilişkili tip.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Verilen yüklemle eşleşen ["karakter" leri arar.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&str için impl
/////////////////////////////////////////////////////////////////////////////

/// `&str` impl. Delegeleri
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str için impl
/////////////////////////////////////////////////////////////////////////////

/// Tahsis etmeyen alt dize araması.
///
/// `""` kalıbını, her karakter sınırında boş eşleşmeler döndürerek ele alır.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Samanlığın önündeki kalıbın eşleşip eşleşmediğini kontrol eder.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Eşleşiyorsa samanlığın önündeki deseni kaldırır.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // GÜVENLİK: önek az önce var olduğu doğrulandı.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Saman yığınının arkasındaki kalıbın eşleşip eşleşmediğini kontrol eder.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Eşleşiyorsa samanlığın arkasındaki deseni kaldırır.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // GÜVENLİK: son ekin var olduğu doğrulandı.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// İki Yönlü alt dize arayıcı
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` için ilişkili tip.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // boş iğne her karakteri reddeder ve aralarındaki her boş dizeyi eşleştirir
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher, doğru eşleştirme yaptığı ve samanlık ve iğne geçerli olduğu sürece karakter sınırlarında bölünen geçerli *Eşleşme* endeksleri üretir. , böylece utf-8 güvenli olurlar.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // sonraki karakter sınırına geç
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // derleyiciyi iki durumu ayrı ayrı uzmanlaştırmaya teşvik etmek için `true` ve `false` vakalarını yazın.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // sonraki karakter sınırına geç
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `next_match` gibi `true` ve `false` i yazın
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// İki yönlü alt dize arama algoritmasının dahili durumu.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// kritik çarpanlara ayırma indeksi
    crit_pos: usize,
    /// ters iğne için kritik çarpanlara ayırma indeksi
    crit_pos_back: usize,
    period: usize,
    /// `byteset` bir uzantıdır (iki yönlü algoritmanın parçası değildir);
    /// bu 64-bit bir "fingerprint" tir, burada her set biti `j`, iğnede bulunan bir (bayt&63)==j'ye karşılık gelir.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// daha önce eşleştirdiğimiz iğne indeksi
    memory: usize,
    /// daha sonra eşleştirdiğimiz iğneye indeks
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Burada neler olup bittiğinin özellikle okunabilir bir açıklaması Crochemore ve Rytter'ın "Text Algorithms", bölüm 13 kitabında bulunabilir.
        // Özellikle "Algorithm CP" koduna bakın.
        // 323.
        //
        // Neler oluyor, iğnenin bazı kritik çarpanlarına (u, v) sahip olması ve u'nun&v [.. nokta] son eki olup olmadığını belirlemek istiyoruz.
        // Eğer öyleyse, "Algorithm CP1" kullanıyoruz.
        // Aksi takdirde, iğne süresinin büyük olduğu zamanlar için optimize edilmiş olan "Algorithm CP2" i kullanırız.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // kısa dönem durumu-dönem tamdır, ters iğne için ayrı bir kritik çarpanlara ayırma hesaplayın x=u 'v' burada | v '|<period(x).
            //
            // Bu zaten bilinen döneme göre hızlanır.
            // X= "acba" gibi bir durumun tam olarak ileriye doğru çarpanlarına ayrılabileceğini unutmayın (crit_pos=1, period=3), ancak yaklaşık dönem tersine (crit_pos=2, period=2) çarpanlarına ayrılabilir.
            // Verilen ters çarpanlara ayırmayı kullanıyoruz ancak tam süreyi koruyoruz.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // uzun dönem durumu-gerçek döneme bir tahminimiz var ve ezberleme kullanmıyoruz.
            //
            //
            // Süresi alt sınır max(|u|, |v|) + 1 ile yaklaşık olarak hesaplayın.
            // Kritik çarpanlara ayırma, hem ileri hem de ters aramada kullanmak için etkilidir.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Dönemin uzun olduğunu belirten kukla değer
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Two-Way'in ana fikirlerinden biri, iğneyi (u, v) ikiye ayırmamız ve samanlıkta v'yi soldan sağa tarayarak bulmaya başlamamızdır.
    // V eşleşirse, sağdan sola tarayarak u eşleştirmeye çalışırız.
    // Bir uyuşmazlıkla karşılaştığımızda ne kadar uzağa sıçrayabileceğimizin tümü, (u, v) 'nin iğne için kritik bir çarpanlara ayırma olduğu gerçeğine dayanır.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` imleci olarak `self.position` i kullanır
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Konumda aramak için yerimiz olduğunu kontrol edin + needle_last, dilimlerin isize aralığı ile sınırlandırıldığını varsayarsak, taşamaz.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Alt dizimizle ilgisi olmayan büyük bölümleri hızla atlayın
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // İğnenin sağ kısmının eşleşip eşleşmediğine bakın.
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // İğnenin sol kısmının eşleşip eşleşmediğine bakın.
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Bir eşleşme bulduk!
            let match_pos = self.position;

            // Note: örtüşen eşleşmelere sahip olmak için needle.len() yerine self.period ekleyin
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // örtüşen eşleşmeler için needle.len(), self.period olarak ayarlayın
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()` teki fikirleri takip eder.
    //
    // Tanımlar, period(x) = period(reverse(x)) ve local_period(u, v) = local_period(reverse(v), reverse(u)) ile simetriktir, dolayısıyla (u, v) kritik bir çarpanlara ayırma ise, (reverse(v) de öyle, reverse(u)).
    //
    //
    // Tersi durum için, kritik bir çarpanlara ayırma x=u 'v' (`crit_pos_back` alanı) hesapladık.İhtiyacımız var | u |<İleri durum için period(x) ve dolayısıyla | v '|Ters için <period(x).
    //
    // Samanlıkta geriye doğru arama yapmak için, önce u 've sonra v' ile eşleşen ters iğne ile ters çevrilmiş samanlıkta ileriye doğru arama yaparız.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` imleci olarak `self.end` i kullanır-böylece `next()` ve `next_back()` bağımsızdır.
        //
        let old_end = self.end;
        'search: loop {
            // Sonunda arayacak yerimiz olduğunu kontrol edin, needle.len() daha fazla yer kalmadığında etrafını saracaktır, ancak dilim uzunluk sınırları nedeniyle asla samanlık uzunluğuna tamamen geri sarılamaz.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Alt dizimizle ilgisi olmayan büyük bölümleri hızla atlayın
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // İğnenin sol kısmının eşleşip eşleşmediğine bakın.
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // İğnenin sağ kısmının eşleşip eşleşmediğine bakın.
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Bir eşleşme bulduk!
            let match_pos = self.end - needle.len();
            // Note: örtüşen eşleşmelere sahip olmak için needle.len() yerine alt self.period
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` in maksimum sonekini hesaplayın.
    //
    // Maksimum son ek, `arr` in olası bir kritik çarpanlarına ayırmasıdır (u, v).
    //
    // `i`, v'nin başlangıç dizini ve `p`, v'nin periyodudur ("i", `p`) döndürür.
    //
    // `order_greater` sözcük sırasının `<` mi yoksa `>` mi olduğunu belirler.
    // Her iki sipariş de hesaplanmalıdır-en büyük `i` ile sipariş kritik bir çarpanlara ayırma sağlar.
    //
    //
    // Uzun dönem vakalar için ortaya çıkan süre kesin değildir (çok kısadır).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Makalede i'ye karşılık gelir
        let mut right = 1; // Kağıtta j'ye karşılık gelir
        let mut offset = 0; // Makalede k'ye karşılık gelir, ancak 0'dan başlar
        // 0 tabanlı indekslemeyle eşleşecek.
        let mut period = 1; // Kağıtta p'ye karşılık gelir

        while let Some(&a) = arr.get(right + offset) {
            // `left` `right` olduğunda gelen olacaktır.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Sonek daha küçük, nokta şimdiye kadarki tüm ön ek.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Cari dönemin tekrarı yoluyla ilerleyin.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Sonek daha büyük, mevcut konumdan baştan başlayın.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` in tersinin maksimum sonekini hesaplayın.
    //
    // Maksimum son ek, `arr` in olası bir kritik çarpanlarına ayırmasıdır (u ', v').
    //
    // `i` i döndürür; burada `i`, arkadan, v '' nin başlangıç dizinidir;
    // `known_period` dönemine ulaşıldığında hemen geri döner.
    //
    // `order_greater` sözcük sırasının `<` mi yoksa `>` mi olduğunu belirler.
    // Her iki sipariş de hesaplanmalıdır-en büyük `i` ile sipariş kritik bir çarpanlara ayırma sağlar.
    //
    //
    // Uzun dönem vakalar için ortaya çıkan süre kesin değildir (çok kısadır).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Makalede i'ye karşılık gelir
        let mut right = 1; // Kağıtta j'ye karşılık gelir
        let mut offset = 0; // Makalede k'ye karşılık gelir, ancak 0'dan başlar
        // 0 tabanlı indekslemeyle eşleşecek.
        let mut period = 1; // Kağıtta p'ye karşılık gelir
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Sonek daha küçük, nokta şimdiye kadarki tüm ön ek.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Cari dönemin tekrarı yoluyla ilerleyin.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Sonek daha büyük, mevcut konumdan baştan başlayın.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy, algoritmanın eşleşmeyenleri olabildiğince çabuk atlamasına veya Rejects'i nispeten hızlı bir şekilde gönderdiği bir modda çalışmasına izin verir.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Aralıkları olabildiğince çabuk eşleştirmek için atlayın
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Düzenli olarak Reddetme
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}