//! `str` için Trait uygulamaları.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Dizelerin sıralanmasını uygular.
///
/// Dizeler [lexicographically](Ord#lexicographical-comparison) bayt değerlerine göre sıralanır.
/// Bu, Unicode kod noktalarını kod çizelgelerindeki konumlarına göre sıralar.
/// Bu, dile ve yerel ayara göre değişen "alphabetical" düzeniyle aynı olmak zorunda değildir.
/// Dizeleri kültürel olarak kabul edilmiş standartlara göre sıralamak, `str` türünün kapsamı dışında kalan yerel özel veriler gerektirir.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Dizelerde karşılaştırma işlemlerini uygular.
///
/// Dizeler, [lexicographically](Ord#lexicographical-comparison) bayt değerlerine göre karşılaştırılır.
/// Bu, Unicode kod noktalarını kod çizelgelerindeki konumlarına göre karşılaştırır.
/// Bu, dile ve yerel ayara göre değişen "alphabetical" düzeniyle aynı olmak zorunda değildir.
/// Dizeleri kültürel olarak kabul edilmiş standartlara göre karşılaştırmak için, `str` türünün kapsamı dışında olan yerel ayara özgü veriler gerekir.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// `&self[..]` veya `&mut self[..]` sözdizimi ile alt dize dilimlemeyi uygular.
///
/// Tüm dizenin bir dilimini döndürür, yani `&self` veya `&mut self` i döndürür."&Self [0 ..
/// len] `veya`&mut self [0 ..
/// len]`.
/// Diğer indeksleme işlemlerinden farklı olarak, bu asla panic olamaz.
///
/// Bu işlem *O*(1) şeklindedir.
///
/// 1.20.0 ten önce, bu indeksleme işlemleri `Index` ve `IndexMut` in doğrudan uygulanmasıyla hala destekleniyordu.
///
/// `&self[0 .. len]` veya `&mut self[0 .. len]` e eşdeğerdir.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// `&self[begin .. end]` veya `&mut self[begin .. end]` sözdizimi ile alt dize dilimlemeyi uygular.
///
/// Belirtilen dizenin bayt aralığından ["başla", `end`) bir dilimini döndürür.
///
/// Bu işlem *O*(1) şeklindedir.
///
/// 1.20.0 ten önce, bu indeksleme işlemleri `Index` ve `IndexMut` in doğrudan uygulanmasıyla hala destekleniyordu.
///
/// # Panics
///
/// Panics, `begin` veya `end`, `begin > end` veya `end > len` ise, bir karakterin (`is_char_boundary` ile tanımlandığı gibi) başlangıç bayt ofsetini göstermiyorsa.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // bunlar panic olacaktır:
/// // bayt 2, `ö` içinde yer alır:
/// // &s [2 ..3];
///
/// // bayt 8, `老`&s [1 ..
/// // 8];
///
/// // bayt 100, dizenin dışında&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // GÜVENLİK: `start` ve `end` in bir karakter sınırında olduğunu kontrol ettim,
            // ve güvenli bir referanstan geçiyoruz, bu nedenle dönüş değeri de bir olacaktır.
            // Ayrıca karakter sınırlarını da kontrol ettik, bu nedenle bu UTF-8 geçerli.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // GÜVENLİK: `start` ve `end` in bir karakter sınırında olduğunu kontrol ettim.
            // İşaretçinin benzersiz olduğunu biliyoruz çünkü onu `slice` ten aldık.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // GÜVENLİK: Arayan, `self` in `slice` sınırları içinde olduğunu garanti eder
        // `add` için tüm koşulları karşılayan.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // GÜVENLİK: `get_unchecked` için yorumlara bakın.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary dizinin [0'da olduğunu kontrol eder, .len()], NLL sorunu nedeniyle `get` i yukarıdaki gibi yeniden kullanamaz
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // GÜVENLİK: `start` ve `end` in bir karakter sınırında olduğunu kontrol ettim,
            // ve güvenli bir referanstan geçiyoruz, bu nedenle dönüş değeri de bir olacaktır.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// `&self[.. end]` veya `&mut self[.. end]` sözdizimi ile alt dize dilimlemeyi uygular.
///
/// Belirtilen dizenin ["0", `end`) bayt aralığından bir dilimini döndürür.
/// `&self[0 .. end]` veya `&mut self[0 .. end]` e eşdeğerdir.
///
/// Bu işlem *O*(1) şeklindedir.
///
/// 1.20.0 ten önce, bu indeksleme işlemleri `Index` ve `IndexMut` in doğrudan uygulanmasıyla hala destekleniyordu.
///
/// # Panics
///
/// Panics, `end` bir karakterin başlangıç bayt ofsetini göstermiyorsa (`is_char_boundary` ile tanımlandığı gibi) veya `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // GÜVENLİK: `end` in bir karakter sınırında olduğunu kontrol ettim,
            // ve güvenli bir referanstan geçiyoruz, bu nedenle dönüş değeri de bir olacaktır.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // GÜVENLİK: `end` in bir karakter sınırında olduğunu kontrol ettim,
            // ve güvenli bir referanstan geçiyoruz, bu nedenle dönüş değeri de bir olacaktır.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // GÜVENLİK: `end` in bir karakter sınırında olduğunu kontrol ettim,
            // ve güvenli bir referanstan geçiyoruz, bu nedenle dönüş değeri de bir olacaktır.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// `&self[begin ..]` veya `&mut self[begin ..]` sözdizimi ile alt dize dilimlemeyi uygular.
///
/// Belirtilen dizenin bayt aralığından ["başla", `len`) bir dilimini döndürür."&Self [begin ..
/// len] `veya"&mut self [başla ..
/// len]`.
///
/// Bu işlem *O*(1) şeklindedir.
///
/// 1.20.0 ten önce, bu indeksleme işlemleri `Index` ve `IndexMut` in doğrudan uygulanmasıyla hala destekleniyordu.
///
/// # Panics
///
/// Panics, `begin` bir karakterin başlangıç bayt ofsetini göstermiyorsa (`is_char_boundary` ile tanımlandığı gibi) veya `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // GÜVENLİK: `start` in bir karakter sınırında olduğunu kontrol ettim,
            // ve güvenli bir referanstan geçiyoruz, bu nedenle dönüş değeri de bir olacaktır.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // GÜVENLİK: `start` in bir karakter sınırında olduğunu kontrol ettim,
            // ve güvenli bir referanstan geçiyoruz, bu nedenle dönüş değeri de bir olacaktır.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // GÜVENLİK: Arayan, `self` in `slice` sınırları içinde olduğunu garanti eder
        // `add` için tüm koşulları karşılayan.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // GÜVENLİK: `get_unchecked` ile aynı.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // GÜVENLİK: `start` in bir karakter sınırında olduğunu kontrol ettim,
            // ve güvenli bir referanstan geçiyoruz, bu nedenle dönüş değeri de bir olacaktır.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// `&self[begin ..= end]` veya `&mut self[begin ..= end]` sözdizimi ile alt dize dilimlemeyi uygular.
///
/// [`begin`, `end`] bayt aralığından verilen dizenin bir dilimini döndürür.`end` in `usize` için maksimum değere sahip olması dışında, `&self [begin .. end + 1]` veya `&mut self[begin .. end + 1]` e eşdeğerdir.
///
/// Bu işlem *O*(1) şeklindedir.
///
/// # Panics
///
/// Panics `begin` bir karakterin başlangıç bayt ofsetini göstermiyorsa (`is_char_boundary` ile tanımlandığı gibi), eğer `end` bir karakterin bitiş bayt ofsetini göstermiyorsa (`end + 1` ya bir başlangıç bayt uzaklığıdır veya `len` e eşittir), eğer `begin > end` veya `end >= len` ise.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // GÜVENLİK: Arayan kişi `get_unchecked` için güvenlik sözleşmesine uymalıdır.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // GÜVENLİK: Arayan kişi `get_unchecked_mut` için güvenlik sözleşmesine uymalıdır.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// `&self[..= end]` veya `&mut self[..= end]` sözdizimi ile alt dize dilimlemeyi uygular.
///
/// [0, `end`] bayt aralığından verilen dizenin bir dilimini döndürür.
/// `end` in `usize` için maksimum değere sahip olması dışında `&self [0 .. end + 1]` e eşdeğerdir.
///
/// Bu işlem *O*(1) şeklindedir.
///
/// # Panics
///
/// Panics, `end` bir karakterin bitiş bayt ofsetini göstermiyorsa (`end + 1`, `is_char_boundary` ile tanımlanan bir başlangıç bayt uzaklığıdır veya `len` e eşittir) veya `end >= len` ise.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // GÜVENLİK: Arayan kişi `get_unchecked` için güvenlik sözleşmesine uymalıdır.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // GÜVENLİK: Arayan kişi `get_unchecked_mut` için güvenlik sözleşmesine uymalıdır.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Bir dizeden bir değeri ayrıştırma
///
/// "FromStr" nin [`from_str`] yöntemi genellikle ["str"] [`parse`] yöntemi aracılığıyla örtük olarak kullanılır.
/// Örnekler için [`parse`] belgelerine bakın.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` bir yaşam süresi parametresine sahip değildir ve bu nedenle yalnızca kendileri bir yaşam süresi parametresi içermeyen türleri ayrıştırabilirsiniz.
///
/// Başka bir deyişle, bir `i32` i `FromStr` ile ayrıştırabilirsiniz, ancak bir `&i32` i ayrıştıramazsınız.
/// `i32` içeren ancak `&i32` içeren bir yapıyı ayrıştırabilirsiniz.
///
/// # Examples
///
/// Örnek bir `Point` tipinde `FromStr` in temel uygulaması:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Ayrıştırmadan döndürülebilecek ilişkili hata.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Bu türden bir değer döndürmek için `s` dizesini ayrıştırır.
    ///
    /// Ayrıştırma başarılı olursa, değeri [`Ok`] içinde döndürün, aksi takdirde dizge yanlış biçimlendirildiğinde [`Err`] içine özgü bir hata döndürür.
    /// Hata tipi, trait'nin uygulanmasına özgüdür.
    ///
    /// # Examples
    ///
    /// `FromStr` i uygulayan bir tür olan [`i32`] ile temel kullanım:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Bir dizeden bir `bool` ayrıştırın.
    ///
    /// Bir `Result<bool, ParseBoolError>` verir, çünkü `s` gerçekte ayrıştırılabilir olabilir veya olmayabilir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Unutmayın, çoğu durumda, `str` üzerindeki `.parse()` yöntemi daha uygundur.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}