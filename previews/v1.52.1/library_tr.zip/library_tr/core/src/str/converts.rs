//! Bayt diliminden `str` oluşturmanın yolları.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Bir bayt dilimini bir dize dilimine dönüştürür.
///
/// Bir dizgi dilimi ([`&str`]), bayt ([`u8`]) ten yapılır ve bir bayt dilimi ([`&[u8]`][byteslice]) baytlardan yapılır, bu nedenle bu işlev ikisi arasında dönüşüm sağlar.
/// Tüm bayt dilimleri geçerli dize dilimleri değildir, ancak: [`&str`], geçerli UTF-8 olmasını gerektirir.
/// `from_utf8()` baytların geçerli UTF-8 olduğundan emin olmak için kontrol eder ve sonra dönüştürmeyi yapar.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Bayt diliminin geçerli UTF-8 olduğundan eminseniz ve geçerlilik kontrolünün ek yüküne maruz kalmak istemiyorsanız, bu işlevin aynı davranışa sahip olan ancak denetimi atlayan güvenli olmayan bir [`from_utf8_unchecked`] sürümü vardır.
///
///
/// `&str` yerine bir `String` e ihtiyacınız varsa, [`String::from_utf8`][string] i düşünün.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Bir `[u8; N]` i yığın-tahsis edebileceğinizden ve [`&[u8]`][byteslice] ini alabileceğiniz için, bu fonksiyon yığın-ayrılmış dizgeye sahip olmanın bir yoludur.Aşağıdaki örnekler bölümünde bunun bir örneği var.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Dilim UTF-8 değilse, sağlanan dilimin neden UTF-8 olmadığına dair bir açıklama ile `Err` döndürür.
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::str;
///
/// // vector içinde bazı baytlar
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Bu baytların geçerli olduğunu biliyoruz, bu yüzden sadece `unwrap()` kullanın.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Yanlış baytlar:
///
/// ```
/// use std::str;
///
/// // vector içinde bazı geçersiz baytlar
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Döndürülebilecek hata türleri hakkında daha fazla ayrıntı için [`Utf8Error`] belgelerine bakın.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // Yığın ayrılmış bir dizide bazı baytlar
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Bu baytların geçerli olduğunu biliyoruz, bu yüzden sadece `unwrap()` kullanın.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // GÜVENLİK: Doğrulamayı çalıştırdım.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Değiştirilebilir bir bayt dilimini, değiştirilebilir bir dize dilimine dönüştürür.
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" değiştirilebilir bir vector olarak
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Bu baytların geçerli olduğunu bildiğimiz için `unwrap()` kullanabiliriz
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Yanlış baytlar:
///
/// ```
/// use std::str;
///
/// // Değişken bir vector içinde bazı geçersiz baytlar
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Döndürülebilecek hata türleri hakkında daha fazla ayrıntı için [`Utf8Error`] belgelerine bakın.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // GÜVENLİK: Doğrulamayı çalıştırdım.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Dizenin geçerli UTF-8 içerip içermediğini kontrol etmeden bir bayt dilimini bir dize dilimine dönüştürür.
///
/// Daha fazla bilgi için güvenli sürüm olan [`from_utf8`] e bakın.
///
/// # Safety
///
/// Bu işlev güvensizdir çünkü kendisine aktarılan baytların geçerli UTF-8 olup olmadığını kontrol etmez.
/// Bu kısıtlama ihlal edilirse, Rust'nin geri kalanı [`&str`] 'lerin geçerli UTF-8 olduğunu varsaydığından, tanımlanmamış davranış ortaya çıkar.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::str;
///
/// // vector içinde bazı baytlar
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // GÜVENLİK: Arayan kişi, `v` baytlarının geçerli UTF-8 olduğunu garanti etmelidir.
    // Ayrıca `&str` ve `&[u8]` in aynı düzene sahip olmasına güvenir.
    unsafe { mem::transmute(v) }
}

/// Dizenin geçerli UTF-8 içerip içermediğini kontrol etmeden bir bayt dilimini bir dize dilimine dönüştürür;değiştirilebilir sürüm.
///
///
/// Daha fazla bilgi için değişmez versiyon olan [`from_utf8_unchecked()`] e bakın.
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // GÜVENLİK: Arayan kişi, `v` baytlarının
    // UTF-8 geçerlidir, bu nedenle `*mut str` e yayınlama güvenlidir.
    // Ayrıca, işaretçi özümlemesi güvenlidir, çünkü bu işaretçi yazma işlemleri için geçerli olması garantili bir referanstan gelir.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}