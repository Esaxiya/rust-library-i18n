use crate::future::Future;

/// `Future` e dönüştürme.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future'nin tamamlandığında üreteceği çıktı.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Bunu hangi tür future'ye dönüştürüyoruz?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Bir değerden future oluşturur.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}