#![stable(feature = "futures_api", since = "1.36.0")]

//! Eşzamansız değerler.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Bu tür gerekli çünkü:
///
/// a) Jeneratörler `for<'a, 'b> Generator<&'a mut Context<'b>>` i uygulayamaz, bu yüzden ham bir gösterici geçmemiz gerekir (bkz. <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Ham işaretçiler ve `NonNull`, `Send` veya `Sync` değildir, bu nedenle bu her bir future non-Send/Sync anlamına gelir ve biz bunu istemiyoruz.
///
/// Ayrıca `.await` in HIR'ın düşürülmesini de basitleştirir.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Bir jeneratörü bir future'ye sarın.
///
/// Bu işlev altında bir `GenFuture` döndürür, ancak daha iyi hata mesajları vermek için `impl Trait` te gizler (`GenFuture<[closure.....]>` yerine `impl Future`).
///
// Bu, `const async fn` ten kurtardıktan sonra ekstra hataları önlemek için `const`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Temel oluşturucuda kendine referanslı ödünç alanlar oluşturmak için async/await futures'nin taşınamaz olduğuna güveniyoruz.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // GÜVENLİK: Güvenli çünkü biz !Unpin + !Drop iz ve bu sadece bir alan projeksiyonu.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // `&mut Context` i bir `NonNull` ham işaretçisine dönüştürerek jeneratörü devam ettirin.
            // `.await` in indirilmesi, bunu güvenli bir şekilde `&mut Context` e geri döndürecektir.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // GÜVENLİK: Arayan kişi `cx.0` in geçerli bir işaretçi olduğunu garanti etmelidir
    // değiştirilebilir bir referans için tüm gereksinimleri karşılayan.
    unsafe { &mut *cx.0.as_ptr().cast() }
}