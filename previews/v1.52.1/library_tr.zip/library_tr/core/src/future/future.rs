#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Bir future, eşzamansız bir hesaplamayı temsil eder.
///
/// future, hesaplama işlemini henüz bitirmemiş olabilecek bir değerdir.
/// Bu tür bir "asynchronous value", bir iş parçacığının değerin kullanılabilir olmasını beklerken faydalı işler yapmaya devam etmesini mümkün kılar.
///
///
/// # `poll` yöntemi
///
/// future, `poll`,*temel yöntemi, future'yi nihai bir değere dönüştürmeye* çalışır.
/// Değer hazır değilse bu yöntem engellemez.
/// Bunun yerine, mevcut görev, tekrar "yoklama" yaparak daha fazla ilerleme kaydetmek mümkün olduğunda uyandırılmak üzere planlanmıştır.
/// `poll` yöntemine geçirilen `context`, mevcut görevi uyandırmak için bir tutamaç olan bir [`Waker`] sağlayabilir.
///
/// Bir future kullanırken, genellikle doğrudan `poll` i çağırmazsınız, bunun yerine değeri `.await` i çağırırsınız.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Tamamlandığında üretilen değerin türü.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// future'yi son bir değere çözümlemeye çalışın, değer henüz mevcut değilse geçerli görevi uyandırma için kaydettirin.
    ///
    /// # Geri dönüş değeri
    ///
    /// Bu işlev şunu döndürür:
    ///
    /// - [`Poll::Pending`] future henüz hazır değilse
    /// - [`Poll::Ready(val)`] Başarıyla tamamlandıysa, bu future'nin sonucu `val` ile.
    ///
    /// Bir future bittiğinde, istemciler onu tekrar `poll` yapmamalıdır.
    ///
    /// Bir future henüz hazır olmadığında, `poll`, `Poll::Pending` i döndürür ve mevcut [`Context`] ten kopyalanan [`Waker`] in bir klonunu saklar.
    /// Bu [`Waker`], future ilerleme kaydettikten sonra uyandırılır.
    /// Örneğin, bir soketin okunabilir olmasını bekleyen bir future, [`Waker`] üzerinde `.clone()` i çağırır ve onu depolar.
    /// Soketin okunabilir olduğunu gösteren başka bir sinyal geldiğinde, [`Waker::wake`] çağrılır ve soket future'nin görevi uyandırılır.
    /// Bir görev uyandırıldığında, future'yi yeniden `poll` yapmaya çalışmalıdır, bu da nihai bir değer üretebilir veya üretmeyebilir.
    ///
    /// `poll` e yapılan çoklu aramalarda, yalnızca [`Context`] ten en son aramaya geçen [`Waker`] in bir uyandırma alacak şekilde programlanması gerektiğini unutmayın.
    ///
    /// # Çalışma zamanı özellikleri
    ///
    /// Futures tek başına *eylemsizdir*;ilerleme sağlamak için *aktif olarak*"oylanmalı", yani mevcut görev her uyandırıldığında, hala ilgisinin olduğu futures'yi beklerken aktif olarak yeniden "toplanmalı".
    ///
    /// `poll` işlevi sıkı bir döngüde tekrar tekrar çağrılmaz-bunun yerine, yalnızca future ilerlemeye hazır olduğunu gösterdiğinde (`wake()`) i arayarak) çağrılmalıdır.
    /// Unix teki `poll(2)` veya `select(2)` sistem çağrılarına aşina iseniz, futures'nin tipik olarak "all wakeups must poll all events" ile aynı sorunları *yaşamadığını* belirtmekte fayda var;onlar daha çok `epoll(4)` gibiler.
    ///
    /// Bir `poll` uygulaması hızlı bir şekilde geri dönmeye çalışmalı ve engellenmemelidir.Hızlı bir şekilde geri dönmek, gereksiz iş parçacıklarının veya olay döngülerinin tıkanmasını önler.
    /// Önceden `poll` e yapılan bir aramanın biraz zaman alabileceği biliniyorsa, `poll` in hızlı bir şekilde geri dönebilmesini sağlamak için iş bir iş parçacığı havuzuna (veya benzer bir şeye) aktarılmalıdır.
    ///
    /// # Panics
    ///
    /// Bir future tamamlandıktan sonra (`poll` ten `Ready` i döndürdü), `poll` yöntemini tekrar çağırmak panic, sonsuza kadar bloke olabilir veya başka tür sorunlara neden olabilir;`Future` trait, böyle bir çağrının etkilerine ilişkin herhangi bir gereksinim getirmez.
    /// Bununla birlikte, `poll` yöntemi `unsafe` olarak işaretlenmediğinden, Rust'nin olağan kuralları geçerlidir: çağrılar, future'nin durumuna bakılmaksızın hiçbir zaman tanımlanmamış davranışlara (bellek bozulması, `unsafe` işlevlerinin yanlış kullanımı veya benzeri) neden olmamalıdır.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}