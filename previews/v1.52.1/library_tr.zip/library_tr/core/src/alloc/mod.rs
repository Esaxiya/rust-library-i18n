//! Bellek ayırma API'leri

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` hatası, kaynakların tükenmesinden veya verilen girdi bağımsız değişkenlerini bu ayırıcıyla birleştirirken yanlış bir şeyden kaynaklanabilecek bir ayırma hatasını gösterir.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (buna trait Hatasının aşağı akış uygulaması için ihtiyacımız var)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Bir `Allocator` uygulaması, [`Layout`][] aracılığıyla tanımlanan rasgele veri bloklarını tahsis edebilir, büyütebilir, küçültebilir ve serbest bırakabilir.
///
/// `Allocator` ZST'ler, referanslar veya akıllı işaretçiler üzerinde uygulanmak üzere tasarlanmıştır, çünkü `MyAlloc([u8; N])` gibi bir ayırıcıya sahip olmak, işaretçileri ayrılmış belleğe güncellemeden taşınamaz.
///
/// [`GlobalAlloc`][] in aksine, sıfır boyutlu tahsislere `Allocator` te izin verilir.
/// Bir temel ayırıcı bunu desteklemiyorsa (jemalloc gibi) veya bir boş gösterici (`libc::malloc` gibi) döndürmüyorsa, bu uygulama tarafından yakalanmalıdır.
///
/// ### Şu anda ayrılmış bellek
///
/// Yöntemlerden bazıları, bir bellek bloğunun bir ayırıcı aracılığıyla *şu anda tahsis edilmesini* gerektirir.Bunun anlamı şudur ki:
///
/// * o bellek bloğunun başlangıç adresi daha önce [`allocate`], [`grow`] veya [`shrink`] tarafından döndürülmüş ve
///
/// * bellek bloğu daha sonra serbest bırakılmadı, burada bloklar ya doğrudan [`deallocate`] e geçirilerek serbest bırakıldı ya da `Ok` i döndüren [`grow`] veya [`shrink`] e geçirilerek değiştirildi.
///
/// `grow` veya `shrink`, `Err` i döndürdüyse, geçen işaretçi geçerli kalır.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Bellek uydurma
///
/// Yöntemlerden bazıları, bir düzenin bir bellek bloğuna *sığmasını* gerektirir.
/// "fit" için bir yerleşim düzeni için bir bellek bloğu anlamına gelir (veya eşdeğer olarak, "fit" e bir bellek bloğu için bir yerleşim düzeni), aşağıdaki koşulların tutulması gerektiği anlamına gelir:
///
/// * Blok, [`layout.align()`] ile aynı hizalamayla tahsis edilmelidir ve
///
/// * Sağlanan [`layout.size()`], `min ..= max` aralığında olmalıdır, burada:
///   - `min` bloğu tahsis etmek için en son kullanılan düzenin boyutudur ve
///   - `max` [`allocate`], [`grow`] veya [`shrink`] ten döndürülen en son gerçek boyuttur.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Bir ayırıcıdan döndürülen bellek blokları, örnek ve tüm klonları bırakılana kadar geçerli belleğe işaret etmeli ve geçerliliğini korumalıdır.
///
/// * ayırıcının klonlanması veya taşınması, bu ayırıcıdan döndürülen bellek bloklarını geçersiz kılmamalıdır.Klonlanmış bir ayırıcı, aynı ayırıcı gibi davranmalıdır ve
///
/// * [*currently allocated*] olan bir bellek bloğuna yönelik herhangi bir işaretçi, ayırıcının herhangi bir başka yöntemine geçirilebilir.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Bir bellek bloğu ayırmaya çalışır.
    ///
    /// Başarı durumunda, `layout` in boyut ve hizalama garantilerini karşılayan bir [`NonNull<[u8]>`][NonNull] döndürür.
    ///
    /// Döndürülen bloğun boyutu `layout.size()` tarafından belirtilenden daha büyük olabilir ve içeriği başlatılmış olabilir veya olmayabilir.
    ///
    /// # Errors
    ///
    /// Geri dönen `Err`, belleğin tükendiğini veya `layout` in ayırıcının boyutunu veya hizalama kısıtlamalarını karşılamadığını gösterir.
    ///
    /// Uygulamaların panik yapmak veya iptal etmek yerine `Err` i bellek tükenmesi durumunda iade etmeleri önerilir, ancak bu kesin bir gereklilik değildir.
    /// (Spesifik olarak: Bu trait'yi bellek tükenmesini durduran temel bir yerel ayırma kitaplığının üstüne uygulamak *yasaldır*.)
    ///
    /// Bir ayırma hatasına yanıt olarak hesaplamayı iptal etmek isteyen istemcilerin, `panic!` veya benzerini doğrudan çağırmak yerine [`handle_alloc_error`] işlevini çağırmaları önerilir.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` gibi davranır, ancak aynı zamanda döndürülen belleğin sıfır başlatılmasını da sağlar.
    ///
    /// # Errors
    ///
    /// Geri dönen `Err`, belleğin tükendiğini veya `layout` in ayırıcının boyutunu veya hizalama kısıtlamalarını karşılamadığını gösterir.
    ///
    /// Uygulamaların panik yapmak veya iptal etmek yerine `Err` i bellek tükenmesi durumunda iade etmeleri önerilir, ancak bu kesin bir gereklilik değildir.
    /// (Spesifik olarak: Bu trait'yi bellek tükenmesini durduran temel bir yerel ayırma kitaplığının üstüne uygulamak *yasaldır*.)
    ///
    /// Bir ayırma hatasına yanıt olarak hesaplamayı iptal etmek isteyen istemcilerin, `panic!` veya benzerini doğrudan çağırmak yerine [`handle_alloc_error`] işlevini çağırmaları önerilir.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // GÜVENLİK: `alloc` geçerli bir bellek bloğu döndürür
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` tarafından referans verilen hafızanın tahsisini kaldırır.
    ///
    /// # Safety
    ///
    /// * `ptr` bu ayırıcı aracılığıyla bir bellek bloğu [*currently allocated*] i göstermelidir ve
    /// * `layout` bu bellek bloğunu [*fit*] olmalıdır.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Bellek bloğunu genişletme girişimleri.
    ///
    /// Bir işaretçi ve ayrılmış belleğin gerçek boyutunu içeren yeni bir [`NonNull<[u8]>`][NonNull] döndürür.İşaretçi, `new_layout` tarafından tanımlanan verileri tutmak için uygundur.
    /// Bunu başarmak için ayırıcı, `ptr` tarafından atıfta bulunulan tahsisi yeni düzene uyacak şekilde genişletebilir.
    ///
    /// Bu `Ok` i döndürürse, `ptr` tarafından referans verilen bellek bloğunun sahipliği bu ayırıcıya aktarılır.
    /// Hafıza serbest bırakılmış olabilir veya olmayabilir ve bu yöntemin dönüş değeri aracılığıyla tekrar arayana geri aktarılmadıkça kullanılamaz olarak kabul edilmelidir.
    ///
    /// Bu yöntem `Err` i döndürürse, bellek bloğunun sahipliği bu ayırıcıya aktarılmaz ve bellek bloğunun içeriği değiştirilmez.
    ///
    /// # Safety
    ///
    /// * `ptr` bu ayırıcı aracılığıyla bir bellek bloğu [*currently allocated*] i belirtmelidir.
    /// * `old_layout` Bu bellek bloğu [*fit*] olmalıdır (`new_layout` argümanının buna uyması gerekmez.).
    /// * `new_layout.size()` `old_layout.size()` e eşit veya daha büyük olmalıdır.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Yeni düzen ayırıcının boyutu ve ayırıcının hizalama kısıtlamalarına uymuyorsa veya büyümesi başka türlü başarısız olursa `Err` i döndürür.
    ///
    /// Uygulamaların panik yapmak veya iptal etmek yerine `Err` i bellek tükenmesi durumunda iade etmeleri önerilir, ancak bu kesin bir gereklilik değildir.
    /// (Spesifik olarak: Bu trait'yi bellek tükenmesini durduran temel bir yerel ayırma kitaplığının üstüne uygulamak *yasaldır*.)
    ///
    /// Bir ayırma hatasına yanıt olarak hesaplamayı iptal etmek isteyen istemcilerin, `panic!` veya benzerini doğrudan çağırmak yerine [`handle_alloc_error`] işlevini çağırmaları önerilir.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // GÜVENLİK: çünkü `new_layout.size()`, daha büyük veya eşit olmalıdır
        // `old_layout.size()`, hem eski hem de yeni bellek tahsisi `old_layout.size()` bayt okuma ve yazma işlemleri için geçerlidir.
        // Ayrıca, eski tahsis henüz serbest bırakılmadığı için `new_ptr` ile çakışamaz.
        // Bu nedenle, `copy_nonoverlapping` e yapılan çağrı güvenlidir.
        // `dealloc` için güvenlik sözleşmesi arayan tarafından onaylanmalıdır.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` gibi davranır, ancak aynı zamanda yeni içeriklerin iade edilmeden önce sıfıra ayarlanmasını sağlar.
    ///
    /// Hafıza bloğu, başarılı bir çağrıdan sonra aşağıdaki içerikleri içerecektir.
    /// `grow_zeroed`:
    ///   * Bayt `0..old_layout.size()`, orijinal tahsisattan korunur.
    ///   * Bayt `old_layout.size()..old_size`, ayırıcı uygulamasına bağlı olarak korunacak veya sıfırlanacaktır.
    ///   `old_size` `grow_zeroed` çağrısından önceki bellek bloğunun boyutunu ifade eder ve bu, tahsis edildiğinde orijinal olarak talep edilen boyuttan daha büyük olabilir.
    ///   * Bayt `old_size..new_size` sıfırlanır.`new_size`, `grow_zeroed` çağrısı tarafından döndürülen bellek bloğunun boyutunu ifade eder.
    ///
    /// # Safety
    ///
    /// * `ptr` bu ayırıcı aracılığıyla bir bellek bloğu [*currently allocated*] i belirtmelidir.
    /// * `old_layout` Bu bellek bloğu [*fit*] olmalıdır (`new_layout` argümanının buna uyması gerekmez.).
    /// * `new_layout.size()` `old_layout.size()` e eşit veya daha büyük olmalıdır.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Yeni düzen ayırıcının boyutu ve ayırıcının hizalama kısıtlamalarına uymuyorsa veya büyümesi başka türlü başarısız olursa `Err` i döndürür.
    ///
    /// Uygulamaların panik yapmak veya iptal etmek yerine `Err` i bellek tükenmesi durumunda iade etmeleri önerilir, ancak bu kesin bir gereklilik değildir.
    /// (Spesifik olarak: Bu trait'yi bellek tükenmesini durduran temel bir yerel ayırma kitaplığının üstüne uygulamak *yasaldır*.)
    ///
    /// Bir ayırma hatasına yanıt olarak hesaplamayı iptal etmek isteyen istemcilerin, `panic!` veya benzerini doğrudan çağırmak yerine [`handle_alloc_error`] işlevini çağırmaları önerilir.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // GÜVENLİK: çünkü `new_layout.size()`, daha büyük veya eşit olmalıdır
        // `old_layout.size()`, hem eski hem de yeni bellek tahsisi `old_layout.size()` bayt okuma ve yazma işlemleri için geçerlidir.
        // Ayrıca, eski tahsis henüz serbest bırakılmadığı için `new_ptr` ile çakışamaz.
        // Bu nedenle, `copy_nonoverlapping` e yapılan çağrı güvenlidir.
        // `dealloc` için güvenlik sözleşmesi arayan tarafından onaylanmalıdır.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Bellek bloğunu küçültme girişimleri.
    ///
    /// Bir işaretçi ve ayrılmış belleğin gerçek boyutunu içeren yeni bir [`NonNull<[u8]>`][NonNull] döndürür.İşaretçi, `new_layout` tarafından tanımlanan verileri tutmak için uygundur.
    /// Bunu başarmak için ayırıcı, `ptr` tarafından atıfta bulunulan tahsisi yeni düzene uyacak şekilde küçültebilir.
    ///
    /// Bu `Ok` i döndürürse, `ptr` tarafından referans verilen bellek bloğunun sahipliği bu ayırıcıya aktarılır.
    /// Hafıza serbest bırakılmış olabilir veya olmayabilir ve bu yöntemin dönüş değeri aracılığıyla tekrar arayana geri aktarılmadıkça kullanılamaz olarak kabul edilmelidir.
    ///
    /// Bu yöntem `Err` i döndürürse, bellek bloğunun sahipliği bu ayırıcıya aktarılmaz ve bellek bloğunun içeriği değiştirilmez.
    ///
    /// # Safety
    ///
    /// * `ptr` bu ayırıcı aracılığıyla bir bellek bloğu [*currently allocated*] i belirtmelidir.
    /// * `old_layout` Bu bellek bloğu [*fit*] olmalıdır (`new_layout` argümanının buna uyması gerekmez.).
    /// * `new_layout.size()` `old_layout.size()` e eşit veya daha küçük olmalıdır.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Yeni düzen ayırıcının boyutu ve ayırıcının hizalama kısıtlamalarına uymuyorsa veya küçültme başarısız olursa `Err` i döndürür.
    ///
    /// Uygulamaların panik yapmak veya iptal etmek yerine `Err` i bellek tükenmesi durumunda iade etmeleri önerilir, ancak bu kesin bir gereklilik değildir.
    /// (Spesifik olarak: Bu trait'yi bellek tükenmesini durduran temel bir yerel ayırma kitaplığının üstüne uygulamak *yasaldır*.)
    ///
    /// Bir ayırma hatasına yanıt olarak hesaplamayı iptal etmek isteyen istemcilerin, `panic!` veya benzerini doğrudan çağırmak yerine [`handle_alloc_error`] işlevini çağırmaları önerilir.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // GÜVENLİK: çünkü `new_layout.size()`, daha küçük veya eşit olmalıdır
        // `old_layout.size()`, hem eski hem de yeni bellek tahsisi `new_layout.size()` bayt okuma ve yazma işlemleri için geçerlidir.
        // Ayrıca, eski tahsis henüz serbest bırakılmadığı için `new_ptr` ile çakışamaz.
        // Bu nedenle, `copy_nonoverlapping` e yapılan çağrı güvenlidir.
        // `dealloc` için güvenlik sözleşmesi arayan tarafından onaylanmalıdır.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Bu `Allocator` örneği için bir "by reference" adaptörü oluşturur.
    ///
    /// İade edilen adaptör ayrıca `Allocator` i de uygular ve bunu ödünç alır.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // GÜVENLİK: güvenlik sözleşmesi arayan tarafından onaylanmalıdır
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // GÜVENLİK: güvenlik sözleşmesi arayan tarafından onaylanmalıdır
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // GÜVENLİK: güvenlik sözleşmesi arayan tarafından onaylanmalıdır
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // GÜVENLİK: güvenlik sözleşmesi arayan tarafından onaylanmalıdır
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}