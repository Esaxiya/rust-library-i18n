use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Bu işlev tek bir yerde kullanılırken ve uygulaması satır içi olabilirken, bunu yapmaya yönelik önceki girişimler rustc'yi daha yavaş hale getirdi:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Bir bellek bloğunun düzeni.
///
/// Bir `Layout` örneği, belirli bir bellek düzenini açıklar.
/// Bir ayırıcıya bir girdi olarak bir `Layout` inşa edersiniz.
///
/// Tüm düzenlerin ilişkili bir boyutu ve ikinin gücü hizalaması vardır.
///
/// (`GlobalAlloc` tüm bellek isteklerinin boyut olarak sıfırdan farklı olmasını gerektirse bile, düzenlerin sıfır olmayan boyuta sahip olması *gerekmediğini* unutmayın.
/// Arayan kişi ya bunun gibi koşulların karşılandığından emin olmalı, gereksinimleri daha düşük olan belirli ayırıcılar kullanmalı ya da daha esnek `Allocator` arayüzünü kullanmalıdır.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // bayt cinsinden ölçülen, istenen bellek bloğunun boyutu.
    size_: usize,

    // bayt cinsinden ölçülen istenen bellek bloğunun hizalanması.
    // Bunun her zaman ikinin gücü olmasını sağlarız, çünkü API gibi `posix_memalign` bunu gerektirir ve Layout kurucularına empoze etmek makul bir kısıtlamadır.
    //
    //
    // (Bununla birlikte, benzer şekilde `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Belirli bir `size` ve `align` ten bir `Layout` oluşturur veya aşağıdaki koşullardan herhangi biri karşılanmazsa `LayoutError` i döndürür:
    ///
    /// * `align` sıfır olmamalı,
    ///
    /// * `align` ikinin gücü olmalı,
    ///
    /// * `size`, `align` in en yakın katına yuvarlandığında, taşmaması gerekir (yani, yuvarlanan değer `usize::MAX` ten küçük veya ona eşit olmalıdır).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (ikinin üssü hizalama anlamına gelir!=0)

        // Yuvarlanan boyut:
        //   size_rounded_up=(boyut + hizala, 1)&! (hizala, 1);
        //
        // Yukarıdan hizalayın!=0 olduğunu biliyoruz.
        // Ekleme (hizala, 1) taşmazsa, yukarı yuvarlama iyi olur.
        //
        // Tersine,&-maskleme! (Hizala, 1) ile sadece düşük dereceli bitleri çıkaracaktır.
        // Dolayısıyla, toplamda taşma meydana gelirse,&-mask bu taşmayı geri almak için yeterince çıkarma yapamaz.
        //
        //
        // Yukarıda, toplama taşması kontrolünün hem gerekli hem de yeterli olduğu belirtilmektedir.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // GÜVENLİK: `from_size_align_unchecked` için koşullar
        // yukarıda kontrol edildi.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Tüm kontrolleri atlayarak bir düzen oluşturur.
    ///
    /// # Safety
    ///
    /// Bu işlev, [`Layout::from_size_align`] in ön koşullarını doğrulamadığı için güvensizdir.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // GÜVENLİK: Arayan, `align` in sıfırdan büyük olduğundan emin olmalıdır.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Bu düzenin bir bellek bloğu için bayt cinsinden minimum boyut.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Bu düzenin bir bellek bloğu için minimum bayt hizalaması.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` tipi bir değeri tutmaya uygun bir `Layout` oluşturur.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // GÜVENLİK: hizalama, Rust tarafından iki kişilik bir güç olarak garanti edilir ve
        // boyut + hizalama kombinasyonunun adres alanımıza sığması garanti edilir.
        // Sonuç olarak, yeterince iyi optimize edilmemişse, panics kodunu girmekten kaçınmak için burada denetlenmemiş kurucuyu kullanın.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` için destek yapısını tahsis etmek için kullanılabilecek bir kaydı açıklayan düzen üretir (bu, bir trait veya bir dilim gibi başka bir boyutlandırılmamış tip olabilir).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // GÜVENLİK: Bunun neden güvenli olmayan varyantı kullandığını öğrenmek için `new` teki gerekçeye bakın
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` için destek yapısını tahsis etmek için kullanılabilecek bir kaydı açıklayan düzen üretir (bu, bir trait veya bir dilim gibi başka bir boyutlandırılmamış tip olabilir).
    ///
    /// # Safety
    ///
    /// Bu işlevi yalnızca aşağıdaki koşullar geçerliyse aramak güvenlidir:
    ///
    /// - `T`, `Sized` ise, bu işlevi aramak her zaman güvenlidir.
    /// - `T` in boyutlandırılmamış kuyruğu:
    ///     - bir [slice], bu durumda dilim kuyruğunun uzunluğu önceden belirlenmiş bir tamsayı olmalı ve *tüm değerin* boyutu (dinamik kuyruk uzunluğu + statik olarak boyutlandırılmış önek) `isize` e sığmalıdır.
    ///     - bir [trait object], ardından işaretçinin vtable kısmı, boyutsuz bir kodlama ile elde edilen `T` türü için geçerli bir vtable'a işaret etmeli ve *tüm değerin* boyutu (dinamik kuyruk uzunluğu + statik olarak boyutlandırılmış önek) `isize` e sığmalıdır.
    ///
    ///     - bir (unstable) [extern type], bu durumda bu işlevi aramak her zaman güvenlidir, ancak panic olabilir veya harici tipin düzeni bilinmediğinden yanlış değeri döndürebilir.
    ///     Bu, harici tip kuyruğa referansla [`Layout::for_value`] ile aynı davranıştır.
    ///     - aksi takdirde, ihtiyatlı olarak bu işlevi çağırmasına izin verilmez.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // GÜVENLİK: Bu işlevlerin ön koşullarını arayan kişiye iletiriz
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // GÜVENLİK: Bunun neden güvenli olmayan varyantı kullandığını öğrenmek için `new` teki gerekçeye bakın
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Sarkan ancak bu Düzen için iyi hizalanmış bir `NonNull` oluşturur.
    ///
    /// İşaretçi değerinin potansiyel olarak geçerli bir göstericiyi temsil edebileceğine dikkat edin, bu da bunun bir "not yet initialized" sentinel değeri olarak kullanılmaması gerektiği anlamına gelir.
    /// Tembel olarak tahsis edilen türler, başlatmayı başka yollarla izlemelidir.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // GÜVENLİK: hizalamanın sıfır olmaması garanti edilir
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` ile aynı mizanpajın değerini tutabilen, ancak aynı zamanda `align` hizalamasına da hizalanan (bayt cinsinden ölçülen) kaydı açıklayan bir mizanpaj oluşturur.
    ///
    ///
    /// `self` önceden belirlenen hizalamayı zaten karşılıyorsa, `self` i döndürür.
    ///
    /// Bu yöntemin, döndürülen düzenin farklı bir hizalamaya sahip olup olmadığına bakılmaksızın, genel boyuta herhangi bir dolgu eklemediğini unutmayın.
    /// Diğer bir deyişle, `K` in boyutu 16 ise, `K.align_to(32)`*yine de* 16 boyutuna sahip olacaktır.
    ///
    /// `self.size()` ve verilen `align` kombinasyonu [`Layout::from_size_align`] te listelenen koşulları ihlal ederse bir hata döndürür.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Aşağıdaki adresin `align` i karşılayacağından emin olmak için `self` ten sonra eklememiz gereken dolgu miktarını döndürür (bayt cinsinden ölçülür).
    ///
    /// Örneğin, `self.size()` 9 ise, `self.padding_needed_for(4)` 3 döndürür, çünkü bu, 4 hizalı bir adres almak için gereken minimum doldurma bayt sayısıdır (karşılık gelen bellek bloğunun 4 hizalı bir adreste başladığı varsayılarak).
    ///
    ///
    /// `align` ikinin gücü değilse, bu işlevin dönüş değerinin bir anlamı yoktur.
    ///
    /// Döndürülen değerin faydasının, `align` in tahsis edilen tüm bellek bloğu için başlangıç adresinin hizalamasından daha küçük veya ona eşit olmasını gerektirdiğine dikkat edin.Bu kısıtlamayı karşılamanın bir yolu, `align <= self.align()` i sağlamaktır.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Yukarı yuvarlanan değer:
        //   len_rounded_up=(len + hizala, 1)&! (hizala, 1);
        // ve sonra dolgu farkını döndürüyoruz: `len_rounded_up - len`.
        //
        // Modüler aritmetik kullanıyoruz:
        //
        // 1. hizalamanın> 0 olması garanti edilir, bu nedenle hizala, 1 her zaman geçerlidir.
        //
        // 2.
        // `len + align - 1` en fazla `align - 1` kadar taşabilir, bu nedenle `!(align - 1)` ile&-mask, taşma durumunda `len_rounded_up` in kendisinin 0 olmasını sağlar.
        //
        //    Böylece, `len` e eklendiğinde, döndürülen dolgu, `align` hizalamasını önemsiz bir şekilde karşılayan 0 değerini verir.
        //
        // (Elbette, yukarıdaki şekilde boyutu ve dolgu taşması olan bellek bloklarını tahsis etme girişimleri, ayırıcının yine de bir hata vermesine neden olacaktır.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Bu mizanpajın boyutunu, mizanpajın hizalamasının birden çok katına yuvarlayarak bir mizanpaj oluşturur.
    ///
    ///
    /// Bu, `padding_needed_for` sonucunu mizanpajın mevcut boyutuna eklemeye eşdeğerdir.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Bu taşamaz.Düzen değişmezinden alıntı yapmak:
        // > `size`, `align` in en yakın katına yuvarlandığında,
        // > taşmamalıdır (yani yuvarlanan değer şundan küçük olmalıdır:
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` in `n` örnekleri için kaydı açıklayan bir düzen oluşturur ve her bir örneğe istenen boyut ve hizalamasının verilmesini sağlamak için her biri arasında uygun miktarda dolgu bulunur.
    /// Başarı durumunda, `(k, offs)` i döndürür; burada `k`, dizinin düzenidir ve `offs`, dizideki her öğenin başlangıcı arasındaki mesafedir.
    ///
    /// Aritmetik taşmada `LayoutError` döndürür.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Bu taşamaz.Düzen değişmezinden alıntı yapmak:
        // > `size`, `align` in en yakın katına yuvarlandığında,
        // > taşmamalıdır (yani yuvarlanan değer şundan küçük olmalıdır:
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // GÜVENLİK: self.align in zaten geçerli olduğu biliniyor ve tahsis_size
        // zaten yastıklı.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `next` in düzgün şekilde hizalandığından emin olmak için gerekli her türlü doldurma dahil, `self` ve ardından `next` kaydını açıklayan bir düzen oluşturur, ancak *takip eden dolgu yok*.
    ///
    /// C gösterim düzeni `repr(C)` ile eşleşmek için, düzeni tüm alanlarla genişlettikten sonra `pad_to_align` i çağırmalısınız.
    /// (Varsayılan Rust gösterim düzeni `repr(Rust)`, as it is unspecified.) ile eşleşmenin bir yolu yoktur
    ///
    /// Her iki parçanın da hizalanmasını sağlamak için, ortaya çıkan düzenin hizalamasının `self` ve `next` in hizalamasının maksimum olacağını unutmayın.
    ///
    /// `Ok((k, offset))` i döndürür; burada `k`, birleştirilmiş kaydın düzenidir ve `offset`, bitiştirilmiş kaydın içine gömülü `next` in başlangıcının bayt cinsinden göreceli konumudur (kaydın 0 ofsetinde başladığı varsayılarak).
    ///
    ///
    /// Aritmetik taşmada `LayoutError` döndürür.
    ///
    /// # Examples
    ///
    /// Bir `#[repr(C)]` yapısının düzenini ve alanların alanlarının düzenlerinden ofsetlerini hesaplamak için:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` ile sonlandırmayı unutmayın!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // çalıştığını test et
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Her örnek arasında dolgu olmadan, `self` in `n` örnekleri için kaydı açıklayan bir düzen oluşturur.
    ///
    /// `repeat` ten farklı olarak, `repeat_packed` in, belirli bir `self` örneği düzgün şekilde hizalanmış olsa bile, `self` in tekrarlanan örneklerinin düzgün şekilde hizalanacağını garanti etmediğini unutmayın.
    /// Başka bir deyişle, `repeat_packed` tarafından döndürülen düzen bir diziyi ayırmak için kullanılıyorsa, dizideki tüm öğelerin düzgün şekilde hizalanacağı garanti edilmez.
    ///
    /// Aritmetik taşmada `LayoutError` döndürür.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// İkisi arasında ek dolgu olmaksızın `self` kaydını ve ardından `next` kaydını açıklayan bir düzen oluşturur.
    /// Dolgu eklenmediğinden, `next` in hizalaması önemsizdir ve ortaya çıkan düzene *hiçbir şekilde* dahil edilmez.
    ///
    ///
    /// Aritmetik taşmada `LayoutError` döndürür.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Bir `[T; n]` için kaydı açıklayan bir düzen oluşturur.
    ///
    /// Aritmetik taşmada `LayoutError` döndürür.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` veya başka bir `Layout` yapıcısına verilen parametreler, belgelenmiş kısıtlamalarını karşılamıyor.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (buna trait Hatasının aşağı akış uygulaması için ihtiyacımız var)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}