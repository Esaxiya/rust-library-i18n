use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// `#[global_allocator]` özelliği aracılığıyla standart kitaplığın varsayılanı olarak kaydedilebilen bir bellek ayırıcı.
///
/// Yöntemlerden bazıları, bir bellek bloğunun bir ayırıcı aracılığıyla *şu anda tahsis edilmesini* gerektirir.Bunun anlamı şudur ki:
///
/// * bu bellek bloğunun başlangıç adresi daha önce `alloc` gibi bir ayırma yöntemine yapılan önceki bir çağrı tarafından döndürülmüş ve
///
/// * bellek bloğu daha sonra serbest bırakılmamıştır, burada bloklar ya `dealloc` gibi bir serbest bırakma yöntemine geçirilerek ya da boş olmayan bir işaretçi döndüren bir yeniden ayırma yöntemine geçirilerek serbest bırakılır.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait, çeşitli nedenlerden dolayı bir `unsafe` trait'dir ve uygulayıcılar bu sözleşmelere uymalarını sağlamalıdır:
///
/// * Küresel ayırıcılar çözülürse bu tanımlanmamış bir davranıştır.Bu kısıtlama future'de kaldırılabilir, ancak şu anda bu işlevlerden herhangi birinden bir panic bellek güvenliğine yol açabilir.
///
/// * `Layout` genel olarak sorgular ve hesaplamalar doğru olmalıdır.Bu trait'yi arayanların, her yöntemde tanımlanan sözleşmelere güvenmesine izin verilir ve uygulayıcılar, bu tür sözleşmelerin doğru kalmasını sağlamalıdır.
///
/// * Kaynakta açık yığın tahsisleri olsa bile, gerçekte gerçekleşen tahsislere güvenemezsiniz.
/// İyileştirici, tamamen ortadan kaldırabileceği veya yığına taşınabileceği ve böylelikle ayırıcıyı asla çağırmayacağı kullanılmayan tahsisleri tespit edebilir.
/// İyileştirici ayrıca ayırmanın hatasız olduğunu varsayabilir, bu nedenle ayırıcı arızaları nedeniyle başarısız olan kod şimdi aniden çalışabilir çünkü optimize edici bir tahsis ihtiyacı etrafında çalıştı.
/// Daha somut bir şekilde, aşağıdaki kod örneği, özel ayırıcınızın kaç ayırmanın gerçekleştiğini saymaya izin verip vermediğine bakılmaksızın sağlam değildir.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Yukarıda bahsedilen optimizasyonların uygulanabilecek tek optimizasyon olmadığını unutmayın.Program davranışını değiştirmeden kaldırılabilirlerse, genellikle yığın tahsislerine güvenmeyebilirsiniz.
///   Tahsislerin gerçekleşip gerçekleşmemesi, tahsisleri yazdırarak izleyen veya başka bir şekilde yan etkilere sahip olan bir ayırıcı yoluyla tespit edilebilecek olsa bile, program davranışının bir parçası değildir.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Verilen `layout` te açıklandığı gibi bellek ayırın.
    ///
    /// Yeni ayrılmış belleğe bir gösterici döndürür veya ayırma hatasını belirtmek için boş.
    ///
    /// # Safety
    ///
    /// Bu işlev güvensizdir çünkü arayan kişi `layout` in sıfır olmayan bir boyuta sahip olmasını sağlamazsa tanımlanmamış davranış ortaya çıkabilir.
    ///
    /// (Uzantı alt yazıları, davranış üzerinde daha spesifik sınırlar sağlayabilir, örneğin, sıfır boyutlu bir tahsis talebine yanıt olarak bir nöbetçi adresi veya bir boş gösterici garanti edebilir.)
    ///
    /// Tahsis edilen bellek bloğu başlatılmış olabilir veya olmayabilir.
    ///
    /// # Errors
    ///
    /// Boş gösterici döndürmek, belleğin tükendiğini veya `layout` in bu ayırıcının boyutunu veya hizalama kısıtlamalarını karşılamadığını gösterir.
    ///
    /// Uygulamalar, iptal etmek yerine bellek tükenmesi durumunda boş değer döndürmeye teşvik edilir, ancak bu kesin bir gereklilik değildir.
    /// (Spesifik olarak: Bu trait'yi bellek tükenmesini durduran temel bir yerel ayırma kitaplığının üstüne uygulamak *yasaldır*.)
    ///
    /// Bir ayırma hatasına yanıt olarak hesaplamayı iptal etmek isteyen istemcilerin, `panic!` veya benzerini doğrudan çağırmak yerine [`handle_alloc_error`] işlevini çağırmaları önerilir.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Verilen `layout` ile verilen `ptr` işaretçisindeki bellek bloğunu serbest bırakın.
    ///
    /// # Safety
    ///
    /// Bu işlev güvensizdir çünkü arayan kişi aşağıdakilerin tümünü sağlamazsa tanımlanmamış davranış ortaya çıkabilir:
    ///
    ///
    /// * `ptr` bu ayırıcı aracılığıyla halihazırda tahsis edilmiş bir bellek bloğunu belirtmelidir,
    ///
    /// * `layout` bu bellek bloğunu ayırmak için kullanılan düzen ile aynı olmalıdır.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// `alloc` gibi davranır, ancak aynı zamanda içeriğin iade edilmeden önce sıfıra ayarlanmasını sağlar.
    ///
    /// # Safety
    ///
    /// Bu işlev, `alloc` ile aynı nedenlerden dolayı güvensizdir.
    /// Bununla birlikte, ayrılan bellek bloğunun başlatılması garanti edilir.
    ///
    /// # Errors
    ///
    /// Boş gösterici döndürmek, belleğin tükendiğini veya `layout` in ayırıcının boyutunu veya hizalama kısıtlamalarını `alloc` te olduğu gibi karşılamadığını gösterir.
    ///
    /// Bir ayırma hatasına yanıt olarak hesaplamayı iptal etmek isteyen istemcilerin, `panic!` veya benzerini doğrudan çağırmak yerine [`handle_alloc_error`] işlevini çağırmaları önerilir.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // GÜVENLİK: `alloc` için güvenlik sözleşmesi arayan tarafından onaylanmalıdır.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // GÜVENLİK: Tahsis başarılı olduktan sonra, `ptr` ten bölge
            // `size` boyutunun yazmalar için geçerli olması garanti edilir.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Verilen `new_size` e bir bellek bloğunu küçültün veya büyütün.
    /// Blok, verilen `ptr` işaretçisi ve `layout` ile tanımlanır.
    ///
    /// Bu, boş olmayan bir işaretçi döndürürse, `ptr` tarafından referans verilen bellek bloğunun sahipliği bu ayırıcıya aktarılmıştır.
    /// Hafızanın tahsisi kaldırılmış olabilir veya olmayabilir ve kullanılamaz olarak kabul edilmelidir (tabii ki bu yöntemin dönüş değeri aracılığıyla tekrar arayana geri aktarılmadıkça).
    /// Yeni bellek bloğu `layout` ile tahsis edilir, ancak `size` `new_size` e güncellendi.
    /// Bu yeni düzen, yeni bellek bloğunun `dealloc` ile ayrılması sırasında kullanılmalıdır.
    /// Yeni bellek bloğunun `0..min(layout.size(), new_size) `aralığının orijinal blok ile aynı değerlere sahip olması garanti edilir.
    ///
    /// Bu yöntem null döndürürse, bellek bloğunun sahipliği bu ayırıcıya aktarılmamıştır ve bellek bloğunun içeriği değiştirilmemiştir.
    ///
    /// # Safety
    ///
    /// Bu işlev güvensizdir çünkü arayan kişi aşağıdakilerin tümünü sağlamazsa tanımlanmamış davranış ortaya çıkabilir:
    ///
    /// * `ptr` şu anda bu ayırıcı aracılığıyla tahsis edilmelidir,
    ///
    /// * `layout` bu bellek bloğunu ayırmak için kullanılan düzen ile aynı olmalıdır,
    ///
    /// * `new_size` sıfırdan büyük olmalıdır.
    ///
    /// * `new_size`, `layout.align()` in en yakın katına yuvarlandığında, taşmaması gerekir (yani, yuvarlanan değer `usize::MAX` ten küçük olmalıdır).
    ///
    /// (Uzantı alt yazıları, davranış üzerinde daha spesifik sınırlar sağlayabilir, örneğin, sıfır boyutlu bir tahsis talebine yanıt olarak bir nöbetçi adresi veya bir boş gösterici garanti edebilir.)
    ///
    /// # Errors
    ///
    /// Yeni düzen, ayırıcının boyut ve hizalama kısıtlamalarına uymuyorsa veya başka bir şekilde yeniden tahsis başarısız olursa null döndürür.
    ///
    /// Uygulamalar, paniğe kapılmak veya iptal etmek yerine bellek tükenmesi durumunda boşa dönmeye teşvik edilir, ancak bu kesin bir gereklilik değildir.
    /// (Spesifik olarak: Bu trait'yi bellek tükenmesini durduran temel bir yerel ayırma kitaplığının üstüne uygulamak *yasaldır*.)
    ///
    /// Bir yeniden tahsis hatasına yanıt olarak hesaplamayı iptal etmek isteyen istemcilerin, `panic!` veya benzerini doğrudan çağırmak yerine [`handle_alloc_error`] işlevini çağırmaları önerilir.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // GÜVENLİK: Arayan, `new_size` in taşmamasını sağlamalıdır.
        // `layout.align()` bir `Layout` ten gelir ve bu nedenle geçerli olması garanti edilir.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // GÜVENLİK: Arayan, `new_layout` in sıfırdan büyük olduğundan emin olmalıdır.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // GÜVENLİK: Önceden tahsis edilmiş blok, yeni tahsis edilmiş blok ile çakışamaz.
            // `dealloc` için güvenlik sözleşmesi arayan tarafından onaylanmalıdır.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}