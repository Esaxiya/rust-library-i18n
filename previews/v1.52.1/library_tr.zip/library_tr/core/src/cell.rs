//! Paylaşılabilir değiştirilebilir kaplar.
//!
//! Rust bellek güvenliği şu kurala dayanmaktadır: Bir nesne `T` verildiğinde, yalnızca aşağıdakilerden birine sahip olmak mümkündür:
//!
//! - Nesneye (`&T`) birkaç değişmez referansa sahip olmak (**takma ad** olarak da bilinir).
//! - Nesneye bir değişken referansa ("&mut T`) sahip olmak (aynı zamanda **değişebilirlik** olarak da bilinir).
//!
//! Bu, Rust derleyicisi tarafından uygulanır.Ancak, bu kuralın yeterince esnek olmadığı durumlar vardır.Bazen bir nesneye birden fazla referans olması ve yine de onu değiştirmesi gerekir.
//!
//! Örtüşme varlığında bile kontrollü bir şekilde değişkenliğe izin vermek için paylaşılabilir değiştirilebilir kaplar mevcuttur.Hem [`Cell<T>`] hem de [`RefCell<T>`], bunu tek iş parçacıklı bir şekilde yapmaya izin verir.
//! Ancak, ne `Cell<T>` ne de `RefCell<T>` iş parçacığı açısından güvenli değildir ([`Sync`] i uygulamazlar).
//! Birden çok iş parçacığı arasında takma ad ve mutasyon yapmanız gerekiyorsa, [`Mutex<T>`], [`RwLock<T>`] veya [`atomic`] türlerini kullanmak mümkündür.
//!
//! `Cell<T>` ve `RefCell<T>` türlerinin değerleri, paylaşılan referanslar aracılığıyla değiştirilebilir (ör.
//! ortak `&T` türü), oysa çoğu Rust türü yalnızca benzersiz ("&mut T") referanslarla değiştirilebilir.
//! `Cell<T>` ve `RefCell<T>` in, 'kalıtsal değişkenlik' sergileyen tipik Rust türlerinin aksine 'dahili değişkenlik' sağladığını söylüyoruz.
//!
//! Hücre tiplerinin iki çeşidi vardır: `Cell<T>` ve `RefCell<T>`.`Cell<T>`, değerleri `Cell<T>` in içine ve dışına taşıyarak dahili değişkenliği uygular.
//! Değerler yerine referansları kullanmak için, `RefCell<T>` tipi kullanılmalı, mutasyona uğratmadan önce bir yazma kilidi edinilmelidir.`Cell<T>`, mevcut iç değeri almak ve değiştirmek için yöntemler sağlar:
//!
//!  - [`Copy`] i uygulayan türler için, [`get`](Cell::get) yöntemi geçerli iç değeri alır.
//!  - [`Default`] i uygulayan tipler için, [`take`](Cell::take) yöntemi mevcut iç değeri [`Default::default()`] ile değiştirir ve değiştirilen değeri döndürür.
//!  - Tüm tipler için, [`replace`](Cell::replace) yöntemi mevcut iç değeri değiştirir ve değiştirilen değeri döndürür ve [`into_inner`](Cell::into_inner) yöntemi `Cell<T>` i tüketir ve iç değeri döndürür.
//!  Ek olarak, [`set`](Cell::set) yöntemi, değiştirilen değeri düşürerek iç değeri değiştirir.
//!
//! `RefCell<T>` Rust'nin yaşam sürelerini, kişinin iç değere geçici, münhasır, değişken erişim talep edebileceği bir süreç olan 'dinamik ödünç alma' uygulamak için kullanır.
//! ``RefCell '' için ödünç alan<T>Rust'nin derleme zamanında tamamen statik olarak izlenen yerel referans türlerinin aksine"s"çalışma zamanında"izlenir.
//! `RefCell<T>` ödünç alımları dinamik olduğu için, zaten karşılıklı olarak ödünç alınmış bir değeri ödünç almaya çalışmak mümkündür;bu olduğunda, panic iş parçacığı ile sonuçlanır.
//!
//! # İç değişkenlik ne zaman seçilir?
//!
//! Bir değeri mutasyona uğratmak için benzersiz erişime sahip olunması gereken daha yaygın miras alınan değişkenlik, Rust'nin işaretçi takma adıyla ilgili güçlü bir şekilde mantık yürütmesini sağlayarak kilitlenme hatalarını statik olarak önleyen anahtar dil öğelerinden biridir.
//! Bu nedenle, kalıtsal değişkenlik tercih edilir ve içsel değişkenlik son çare olarak kabul edilir.
//! Hücre tipleri, aksi takdirde izin verilmeyeceği durumlarda mutasyonu mümkün kıldığından, içsel değişkenliğin uygun olabileceği veya hatta *kullanılması gereken* durumlar vardır, örn.
//!
//! * Değişmez bir şeyin değişkenliği 'inside' ile tanışın
//! * Mantıksal olarak değişmez yöntemlerin uygulama ayrıntıları.
//! * [`Clone`] uygulamalarını değiştiriyor.
//!
//! ## Değişmez bir şeyin değişkenliği 'inside' ile tanışın
//!
//! [`Rc<T>`] ve [`Arc<T>`] dahil olmak üzere birçok paylaşılan akıllı işaretçi türü, klonlanabilen ve birden çok taraf arasında paylaşılabilen kapsayıcılar sağlar.
//! İçerdiği değerler birden fazla takma adla adlandırılabileceğinden, `&mut` ile değil, yalnızca `&` ile ödünç alınabilir.
//! Hücreler olmadan bu akıllı işaretçilerin içindeki verileri mutasyona uğratmak imkansız olurdu.
//!
//! O zaman, değişkenliği yeniden başlatmak için paylaşılan işaretçi türlerinin içine bir `RefCell<T>` koymak çok yaygındır:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Dinamik ödünç almanın kapsamını sınırlamak için yeni bir blok oluşturun
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Önbelleğin önceki ödünç almasının kapsam dışına çıkmasına izin vermemiş olsaydık, sonraki ödünç almanın dinamik bir iş parçacığı panic'ye neden olacağını unutmayın.
//!     //
//!     // Bu, `RefCell` kullanmanın en büyük tehlikesidir.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Bu örneğin `Arc<T>` değil, `Rc<T>` kullandığını unutmayın.`RefCell<T>"ler tek iş parçacıklı senaryolar içindir.Çok iş parçacıklı bir durumda paylaşılan değişkenliğe ihtiyacınız varsa [`RwLock<T>`] veya [`Mutex<T>`] kullanmayı düşünün.
//!
//! ## Mantıksal olarak değişmez yöntemlerin uygulama ayrıntıları
//!
//! Ara sıra, bir API'de "under the hood" te meydana gelen mutasyonların ortaya çıkarılmaması istenebilir.
//! Bunun nedeni mantıksal olarak işlemin değişmez olması olabilir, ancak örneğin, önbelleğe alma, uygulamayı mutasyonu gerçekleştirmeye zorlar;veya orijinal olarak `&self` almak için tanımlanan bir trait yöntemini uygulamak için mutasyon kullanmanız gerektiğinden.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Pahalı hesaplama buraya gelir
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` uygulamalarını değiştiriyor
//!
//! Bu sadece bir öncekinin özel ama yaygın bir durumudur: değişmez gibi görünen işlemler için değişkenliği gizleme.
//! [`clone`](Clone::clone) yönteminin kaynak değerini değiştirmemesi beklenir ve `&mut self` değil, `&self` alacağı bildirilir.
//! Bu nedenle, `clone` yönteminde meydana gelen herhangi bir mutasyon, hücre türlerini kullanmalıdır.
//! Örneğin, [`Rc<T>`] referans sayılarını bir `Cell<T>` içinde tutar.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Değişken bir hafıza konumu.
///
/// # Examples
///
/// Bu örnekte, `Cell<T>` in değişmez bir yapı içinde mutasyonu etkinleştirdiğini görebilirsiniz.
/// Başka bir deyişle, "interior mutability" i etkinleştirir.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // HATA: `my_struct` değişmez
/// // my_struct.regular_field =yeni_değer;
///
/// // İŞLER: `my_struct` değişmez olsa da, `special_field` bir `Cell`,
/// // her zaman mutasyona uğrayabilen
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Daha fazlası için [module-level documentation](self) e bakın.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T için `Default` değeriyle bir `Cell<T>` oluşturur.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Verilen değeri içeren yeni bir `Cell` oluşturur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// İçerdiği değeri ayarlar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// İki Hücrenin değerlerini değiştirir.
    /// `std::mem::swap` ile farkı, bu işlevin `&mut` referansı gerektirmemesidir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // GÜVENLİK: Bu, ayrı iş parçacıklarından çağrılırsa riskli olabilir, ancak `Cell`
        // `!Sync` olduğu için bu olmayacak.
        // `Cell` başka hiçbir şeyin bu "Hücrelerden" herhangi birine işaret etmediğinden emin olduğundan, bu aynı zamanda herhangi bir işaretçiyi geçersiz kılmaz.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// İçerilen değeri `val` ile değiştirir ve eski içerilen değeri döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // GÜVENLİK: Bu, ayrı bir iş parçacığından çağrılırsa veri yarışlarına neden olabilir,
        // ancak `Cell` `!Sync` olduğundan bu olmayacak.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Değerin paketini açar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// İçerdiği değerin bir kopyasını döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // GÜVENLİK: Bu, ayrı bir iş parçacığından çağrılırsa veri yarışlarına neden olabilir,
        // ancak `Cell` `!Sync` olduğundan bu olmayacak.
        unsafe { *self.value.get() }
    }

    /// Bir işlev kullanarak içerilen değeri günceller ve yeni değeri döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Bu hücredeki temel verilere ham bir işaretçi döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Temel verilere değiştirilebilir bir referans döndürür.
    ///
    /// Bu çağrı, `Cell` i mutabık bir şekilde (derleme zamanında) ödünç alarak tek referansa sahip olduğumuzu garanti eder.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` ten bir `&Cell<T>` döndürür
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // GÜVENLİK: `&mut` benzersiz erişim sağlar.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Hücrenin değerini alarak yerine `Default::default()` i bırakır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` ten bir `&[Cell<T>]` döndürür
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // GÜVENLİK: `Cell<T>`, `T` ile aynı bellek düzenine sahiptir.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Dinamik olarak kontrol edilen ödünç alma kurallarına sahip değiştirilebilir bir bellek konumu
///
/// Daha fazlası için [module-level documentation](self) e bakın.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] tarafından döndürülen bir hata.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] tarafından döndürülen bir hata.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Pozitif değerler, aktif `Ref` sayısını temsil eder.Negatif değerler, aktif `RefMut` sayısını temsil eder.
// Birden fazla "RefMut", yalnızca bir `RefCell` in ayrı, örtüşmeyen bileşenlerine (örneğin, bir dilimin farklı aralıkları) atıfta bulunuyorlarsa, aynı anda aktif olabilir.
//
// `Ref` ve `RefMut` iki kelime boyutundadır ve bu nedenle `usize` aralığının yarısını aşacak kadar "Ref" veya "RefMut" bulunmayacaktır.
// Bu nedenle, bir `BorrowFlag` muhtemelen hiçbir zaman taşmayacak veya yetersiz kalmayacaktır.
// Bununla birlikte, bu bir garanti değildir, çünkü patolojik bir program tekrar tekrar ve ardından mem::forget "Ref" veya "RefMut" oluşturabilir.
// Bu nedenle, tüm kodun, güvenlikten kaçınmak için taşma ve yetersizlik durumunu açıkça kontrol etmesi veya en azından taşma veya yetersizlik olması durumunda doğru davranması gerekir (örn., BorrowRef::new e bakın).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` içeren yeni bir `RefCell` oluşturur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` i tüketerek sarılmış değeri döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Bu işlev `self` i (`RefCell`) değer olarak aldığından, derleyici o anda ödünç alınmadığını statik olarak doğrular.
        //
        self.value.into_inner()
    }

    /// Sarılmış değeri yenisiyle değiştirir, her ikisini de başlatmadan eski değeri döndürür.
    ///
    ///
    /// Bu işlev [`std::mem::replace`](../mem/fn.replace.html) e karşılık gelir.
    ///
    /// # Panics
    ///
    /// Değer şu anda ödünç alınmışsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Sarılmış değeri `f` ten hesaplanan yenisiyle değiştirir, her ikisini de başlatmadan eski değeri döndürür.
    ///
    ///
    /// # Panics
    ///
    /// Değer şu anda ödünç alınmışsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self` in sarmalanmış değerini, `other` in sarmalanmış değeriyle, ikisini de başlatmadan değiştirmeden değiştirir.
    ///
    ///
    /// Bu işlev [`std::mem::swap`](../mem/fn.swap.html) e karşılık gelir.
    ///
    /// # Panics
    ///
    /// Panics, `RefCell` teki değer şu anda ödünç alınmışsa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Değişmez bir şekilde sarılmış değeri ödünç alır.
    ///
    /// Ödünç alma, iade edilen `Ref` kapsamdan çıkana kadar sürer.
    /// Birden fazla değişmez ödünç aynı anda alınabilir.
    ///
    /// # Panics
    ///
    /// Panics, eğer değer şu anda karşılıklı olarak ödünç alınmışsa.
    /// Panik yapmayan bir varyant için [`try_borrow`](#method.try_borrow) kullanın.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic'ye bir örnek:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Değişmez bir şekilde sarılmış değeri ödünç alır ve değer şu anda değişken olarak ödünç alınmışsa bir hata döndürür.
    ///
    ///
    /// Ödünç alma, iade edilen `Ref` kapsamdan çıkana kadar sürer.
    /// Birden fazla değişmez ödünç aynı anda alınabilir.
    ///
    /// Bu, [`borrow`](#method.borrow) in panik yapmayan çeşididir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // GÜVENLİK: `BorrowRef`, yalnızca değişmez erişimin olmasını sağlar
            // ödünç alındığında değere.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Sarılmış değeri mutabık bir şekilde ödünç alır.
    ///
    /// Ödünç, iade edilen `RefMut` veya tüm "RefMut" lar çıkış kapsamından türetilene kadar sürer.
    ///
    /// Bu borçlanma aktifken değer ödünç alınamaz.
    ///
    /// # Panics
    ///
    /// Değer şu anda ödünç alınmışsa Panics.
    /// Panik yapmayan bir varyant için [`try_borrow_mut`](#method.try_borrow_mut) kullanın.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic'ye bir örnek:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Değer şu anda ödünç alınmışsa bir hata döndürerek, sarılmış değeri mutabık bir şekilde ödünç alır.
    ///
    ///
    /// Ödünç, iade edilen `RefMut` veya tüm "RefMut" lar çıkış kapsamından türetilene kadar sürer.
    /// Bu borçlanma aktifken değer ödünç alınamaz.
    ///
    /// Bu, [`borrow_mut`](#method.borrow_mut) in panik yapmayan çeşididir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // GÜVENLİK: `BorrowRef` benzersiz erişimi garanti eder.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Bu hücredeki temel verilere ham bir işaretçi döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Temel verilere değiştirilebilir bir referans döndürür.
    ///
    /// Bu çağrı `RefCell` i değişken olarak (derleme zamanında) ödünç aldığından dinamik kontrollere gerek kalmaz.
    ///
    /// Ancak dikkatli olun: Bu yöntem, `self` in değiştirilebilir olmasını bekler, bu genellikle bir `RefCell` kullanılırken geçerli değildir.
    ///
    /// `self` değiştirilebilir değilse bunun yerine [`borrow_mut`] yöntemine bir göz atın.
    ///
    /// Ayrıca, bu yöntemin yalnızca özel durumlar için olduğunu ve genellikle istediğiniz şey olmadığını lütfen unutmayın.
    /// Şüphe durumunda, bunun yerine [`borrow_mut`] kullanın.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Sızan korumaların `RefCell` in ödünç alma durumu üzerindeki etkisini geri alın.
    ///
    /// Bu çağrı [`get_mut`] e benzer ancak daha özeldir.
    /// Hiçbir ödünç almanın mevcut olmadığından emin olmak için `RefCell` i mutabık bir şekilde ödünç alır ve ardından paylaşılan ödünç alanların izlenmesini sıfırlar.
    /// Bu, bazı `Ref` veya `RefMut` ödünç alanların sızdırılmış olması durumunda geçerlidir.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Değişmez bir şekilde sarılmış değeri ödünç alır ve değer şu anda değişken olarak ödünç alınmışsa bir hata döndürür.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` ten farklı olarak, bu yöntem güvenli değildir çünkü bir `Ref` döndürmez ve ödünç alma bayrağına dokunulmaz.
    /// Bu yöntemle döndürülen referans canlıyken `RefCell` i mutabık bir şekilde ödünç almak tanımsız bir davranıştır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // GÜVENLİK: Şu anda kimsenin aktif olarak yazmadığını kontrol ediyoruz, ancak
            // Arayanın, geri gönderilen referans artık kullanılmayana kadar kimsenin yazmamasını sağlama sorumluluğu.
            // Ayrıca, `self.value.get()`, `self` in sahip olduğu değeri ifade eder ve bu nedenle `self` in kullanım ömrü boyunca geçerli olması garanti edilir.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Sarılmış değeri alır ve `Default::default()` i yerinde bırakır.
    ///
    /// # Panics
    ///
    /// Değer şu anda ödünç alınmışsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, eğer değer şu anda karşılıklı olarak ödünç alınmışsa.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T için `Default` değeriyle bir `RefCell<T>` oluşturur.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, `RefCell` teki değer şu anda ödünç alınmışsa.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, `RefCell` teki değer şu anda ödünç alınmışsa.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, `RefCell` teki değer şu anda ödünç alınmışsa.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, `RefCell` teki değer şu anda ödünç alınmışsa.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, `RefCell` teki değer şu anda ödünç alınmışsa.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, `RefCell` teki değer şu anda ödünç alınmışsa.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, `RefCell` teki değer şu anda ödünç alınmışsa.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Ödünç almanın artması, aşağıdaki durumlarda okunmayan bir değere (<=0) neden olabilir:
            // 1. <0 idi, yani yazı ödünç alındı, bu yüzden Rust'nin referans örtüşme kuralları nedeniyle bir okuma ödünç almasına izin veremiyoruz
            // 2.
            // isize::MAX ti (maksimum okuma ödünç alma miktarı) ve isize::MIN e (maksimum yazma ödünç alma miktarı) taştı, bu nedenle ek bir okuma ödünç almasına izin veremeyiz çünkü isize çok fazla okuma ödünç aldığını temsil edemez (bu yalnızca mem::forget küçük bir sabit miktardan daha fazla "Ref", bu iyi bir uygulama değildir)
            //
            //
            //
            //
            None
        } else {
            // Ödünç almanın artırılması şu durumlarda bir okuma değerine (> 0) neden olabilir:
            // 1. =0 idi, yani ödünç alınmadı ve ilk okuma ödünç alıyoruz
            // 2. > 0 ve <isize::MAX idi, yani
            // okunan ödünç alanlar vardı ve isize, bir tane daha ödünç okuma okumayı temsil edecek kadar büyük
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Bu Referans var olduğundan, ödünç alma bayrağının bir okuma ödünç alma olduğunu biliyoruz.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Ödünç alma sayacının bir yazı ödünç almaya taşmasını önleyin.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Ödünç alınmış bir referansı bir `RefCell` kutusundaki bir değere sarar.
/// Bir `RefCell<T>` ten değişmez bir şekilde ödünç alınan bir değer için bir sarmalayıcı türü.
///
/// Daha fazlası için [module-level documentation](self) e bakın.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Bir `Ref` kopyalar.
    ///
    /// `RefCell` zaten değişmez bir şekilde ödünç alındı, bu yüzden bu başarısız olamaz.
    ///
    /// Bu, `Ref::clone(...)` olarak kullanılması gereken ilişkili bir işlevdir.
    /// Bir `Clone` uygulaması veya bir yöntem, bir `RefCell` in içeriğini klonlamak için `r.borrow().clone()` in yaygın kullanımına müdahale edebilir.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Ödünç alınan verilerin bir bileşeni için yeni bir `Ref` yapar.
    ///
    /// `RefCell` zaten değişmez bir şekilde ödünç alındı, bu yüzden bu başarısız olamaz.
    ///
    /// Bu, `Ref::map(...)` olarak kullanılması gereken ilişkili bir işlevdir.
    /// Bir yöntem, `Deref` aracılığıyla kullanılan bir `RefCell` in içeriğinde aynı adlı yöntemlere müdahale edebilir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Ödünç alınan verilerin isteğe bağlı bir bileşeni için yeni bir `Ref` yapar.
    /// Kapatma `None` i döndürürse, orijinal koruma bir `Err(..)` olarak iade edilir.
    ///
    /// `RefCell` zaten değişmez bir şekilde ödünç alındı, bu yüzden bu başarısız olamaz.
    ///
    /// Bu, `Ref::filter_map(...)` olarak kullanılması gereken ilişkili bir işlevdir.
    /// Bir yöntem, `Deref` aracılığıyla kullanılan bir `RefCell` in içeriğinde aynı adlı yöntemlere müdahale edebilir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Ödünç alınan verilerin farklı bileşenleri için bir `Ref` i birden çok "Ref" e böler.
    ///
    /// `RefCell` zaten değişmez bir şekilde ödünç alındı, bu yüzden bu başarısız olamaz.
    ///
    /// Bu, `Ref::map_split(...)` olarak kullanılması gereken ilişkili bir işlevdir.
    /// Bir yöntem, `Deref` aracılığıyla kullanılan bir `RefCell` in içeriğinde aynı adlı yöntemlere müdahale edebilir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Temel verilere bir referansa dönüştürün.
    ///
    /// Temel alınan `RefCell`, bir daha asla karşılıklı olarak ödünç alınamaz ve her zaman zaten değişmez bir şekilde ödünç alınmış görünecektir.
    ///
    /// Sabit sayıdaki referanslardan fazlasını sızdırmak iyi bir fikir değildir.
    /// `RefCell`, toplamda yalnızca daha az sayıda sızıntı meydana gelirse, değişmez bir şekilde tekrar ödünç alınabilir.
    ///
    /// Bu, `Ref::leak(...)` olarak kullanılması gereken ilişkili bir işlevdir.
    /// Bir yöntem, `Deref` aracılığıyla kullanılan bir `RefCell` in içeriğinde aynı adlı yöntemlere müdahale edebilir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Bu Referans'ı unutarak, RefCell'deki ödünç sayacının `'b` ömrü içinde KULLANILMIŞ durumuna geri dönememesini sağlıyoruz.
        // Referans izleme durumunun sıfırlanması, ödünç alınan RefCell'e benzersiz bir referans gerektirir.
        // Orijinal hücreden başka değiştirilebilir referanslar oluşturulamaz.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Ödünç alınan verinin bir bileşeni için yeni bir `RefMut` yapar, örneğin bir enum varyantı.
    ///
    /// `RefCell` zaten mutabık kalınarak ödünç alındı, bu yüzden bu başarısız olamaz.
    ///
    /// Bu, `RefMut::map(...)` olarak kullanılması gereken ilişkili bir işlevdir.
    /// Bir yöntem, `Deref` aracılığıyla kullanılan bir `RefCell` in içeriğinde aynı adlı yöntemlere müdahale edebilir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ödünç kontrolünü düzelt
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Ödünç alınan verilerin isteğe bağlı bir bileşeni için yeni bir `RefMut` yapar.
    /// Kapatma `None` i döndürürse, orijinal koruma bir `Err(..)` olarak iade edilir.
    ///
    /// `RefCell` zaten mutabık kalınarak ödünç alındı, bu yüzden bu başarısız olamaz.
    ///
    /// Bu, `RefMut::filter_map(...)` olarak kullanılması gereken ilişkili bir işlevdir.
    /// Bir yöntem, `Deref` aracılığıyla kullanılan bir `RefCell` in içeriğinde aynı adlı yöntemlere müdahale edebilir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ödünç kontrolünü düzelt
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // GÜVENLİK: işlev, süre boyunca özel bir referansa sahiptir
        // `orig` aracılığıyla çağrılır ve göstericinin yalnızca işlev çağrısının içinde referansı kaldırılır, özel referansın kaçmasına asla izin vermez.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // GÜVENLİK: yukarıdakiyle aynı.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Ödünç alınan verilerin farklı bileşenleri için bir `RefMut` i birden çok "RefMut" a böler.
    ///
    /// Temel alınan `RefCell`, iade edilen her iki "RefMut" kapsam dışına çıkıncaya kadar karşılıklı olarak ödünç alınmaya devam edecektir.
    ///
    /// `RefCell` zaten mutabık kalınarak ödünç alındı, bu yüzden bu başarısız olamaz.
    ///
    /// Bu, `RefMut::map_split(...)` olarak kullanılması gereken ilişkili bir işlevdir.
    /// Bir yöntem, `Deref` aracılığıyla kullanılan bir `RefCell` in içeriğinde aynı adlı yöntemlere müdahale edebilir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Temel verilere değiştirilebilir bir referansa dönüştürün.
    ///
    /// Altta yatan `RefCell` tekrar ödünç alınamaz ve her zaman karşılıklı olarak ödünç alınmış gibi görünür, bu da geri gönderilen referansı yalnızca iç mekana yapar.
    ///
    ///
    /// Bu, `RefMut::leak(...)` olarak kullanılması gereken ilişkili bir işlevdir.
    /// Bir yöntem, `Deref` aracılığıyla kullanılan bir `RefCell` in içeriğinde aynı adlı yöntemlere müdahale edebilir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Bu BorrowRefMut'u unutarak, RefCell'deki ödünç sayacının `'b` ömrü içinde KULLANILMAYAN duruma geri dönememesini sağlıyoruz.
        // Referans izleme durumunun sıfırlanması, ödünç alınan RefCell'e benzersiz bir referans gerektirir.
        // Bu ömür içinde orijinal hücreden başka referans oluşturulamaz, bu da mevcut ödünç almayı kalan ömür için tek referans yapar.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone ten farklı olarak, yeni, ilkini oluşturmak için çağrılır.
        // değiştirilebilir referans ve bu nedenle şu anda mevcut referanslar olmamalıdır.
        // Bu nedenle, klon değişken yeniden sayımı artırırken, burada yalnızca KULLANILMAYAN'dan KULLANILMAYAN'a geçişe açıkça izin veriyoruz, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut` i klonlar.
    //
    // Bu yalnızca, her `BorrowRefMut` orijinal nesnenin farklı, örtüşmeyen aralığına yönelik değişken bir referansı izlemek için kullanılıyorsa geçerlidir.
    //
    // Bu bir Klon uygulamasında değildir, böylece kod bunu örtük olarak çağırmaz.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Ödünç sayacının yetersiz kalmasını önleyin.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Bir `RefCell<T>` ten mutabık bir şekilde ödünç alınan bir değer için bir sarmalayıcı türü.
///
/// Daha fazlası için [module-level documentation](self) e bakın.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust'de dahili değişkenlik için temel ilkel.
///
/// Bir referans `&T` iniz varsa, o zaman normalde Rust'de derleyici, `&T` in değişmez verilere işaret ettiği bilgiye dayalı optimizasyonları gerçekleştirir.Bu verileri, örneğin bir takma ad aracılığıyla veya bir `&T` i bir `&mut T` e dönüştürerek değiştirmek, tanımlanmamış davranış olarak kabul edilir.
/// `UnsafeCell<T>` `&T` için değişmezlik garantisini devre dışı bırakır: paylaşılan bir referans `&UnsafeCell<T>`, değiştirilmekte olan verilere işaret edebilir.Buna "interior mutability" denir.
///
/// `Cell<T>` ve `RefCell<T>` gibi dahili değişkenliğe izin veren diğer tüm türler, verilerini sarmak için dahili olarak `UnsafeCell` kullanır.
///
/// Yalnızca paylaşılan referanslar için değişmezlik garantisinin `UnsafeCell` ten etkilendiğini unutmayın.Değişebilir referanslar için benzersizlik garantisi etkilenmez.`UnsafeCell<T>` ile bile `&mut` takma adını almanın yasal bir yolu yoktur.
///
/// `UnsafeCell` API'nin kendisi teknik olarak çok basittir: [`.get()`], içeriğine ilişkin ham bir `*mut T` işaretçisi verir.Soyutlama tasarımcısı olarak bu ham işaretçiyi doğru kullanmak _you_ e kalmıştır.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Kesin Rust örtüşme kuralları biraz değişim içindedir, ancak ana noktalar tartışmalı değildir:
///
/// - Güvenli kodla erişilebilen (örneğin, onu döndürdüğünüz için) ömür boyu `'a` (bir `&T` veya `&mut T` referansı) ile güvenli bir referans oluşturursanız, geri kalan için bu referansla çelişecek şekilde verilere erişmemelisiniz. `'a`.
/// Örneğin, bu, `*mut T` i bir `UnsafeCell<T>` ten alıp bir `&T` e atarsanız, `T` teki verilerin bu referansın ömrü sona erene kadar değişmez kalması gerektiği anlamına gelir (tabii ki `T` te bulunan herhangi bir `UnsafeCell` verisini modulo).
/// Benzer şekilde, güvenli koda bırakılan bir `&mut T` referansı oluşturursanız, bu referansın süresi dolana kadar `UnsafeCell` içindeki verilere erişmemelisiniz.
///
/// - Her zaman veri yarışlarından kaçınmalısınız.Birden fazla iş parçacığının aynı `UnsafeCell` e erişimi varsa, o zaman herhangi bir yazma işleminin diğer tüm erişimlerle (veya atomik kullanmadan) önce uygun bir ilişkiye sahip olması gerekir.
///
/// Doğru tasarıma yardımcı olmak için, aşağıdaki senaryolar tek iş parçacıklı kod için açıkça yasal olarak ilan edilmiştir:
///
/// 1. Bir `&T` referansı güvenli koda bırakılabilir ve orada diğer `&T` referanslarıyla birlikte var olabilir, ancak bir `&mut T` ile olamaz
///
/// 2. Bir `&mut T` referansı, ne başka `&mut T` ne de `&T` onunla birlikte var olmadıkça güvenli koda bırakılabilir.Bir `&mut T` her zaman benzersiz olmalıdır.
///
/// Bir `&UnsafeCell<T>` in içeriğini değiştirirken (diğer `&UnsafeCell<T>` referansları hücreye takma ad olsa bile) sorun olmaz (yukarıdaki değişmezleri başka bir şekilde uygulamanız koşuluyla), birden çok `&mut UnsafeCell<T>` takma adına sahip olmanın hala tanımlanmamış bir davranış olduğunu unutmayın.
/// Yani, `UnsafeCell`, bir `&UnsafeCell<_>` referansı aracılığıyla _shared_ accesses (_i.e._ ile özel bir etkileşime sahip olacak şekilde tasarlanmış bir sarmalayıcıdır);_exclusive_ accesses (_e.g._ ile `&mut UnsafeCell<_>` aracılığıyla uğraşırken hiçbir sihir yoktur): `&mut` ödünç alma süresi boyunca ne hücre ne de sarılmış değerin adı değiştirilemez.
///
/// Bu, `&mut T` veren bir _safe_ getter olan [`.get_mut()`] erişimcisi tarafından sergileniyor.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Hücreyi takma ad birden fazla referans olmasına rağmen, bir `UnsafeCell<_>` içeriğinin nasıl sağlıklı bir şekilde değiştirileceğini gösteren bir örnek:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Aynı `x` için birden fazla/eşzamanlı/paylaşılan referans alın.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // GÜVENLİK: Bu kapsamda "x" içeriklerine başka referans yoktur,
///     // bu yüzden bizimki etkili bir şekilde benzersizdir.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- ödünç-+
///     *p1_exclusive += 27; // |
/// } // <---------- bu noktanın ötesine geçemez -------------------+
///
/// unsafe {
///     // GÜVENLİK: Bu kapsamda hiç kimse "x" içeriğine özel erişime sahip olmayı beklemiyor,
///     // böylece aynı anda birden fazla paylaşılan erişime sahip olabiliriz.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Aşağıdaki örnek, bir `UnsafeCell<T>` e özel erişimin, `T` e özel erişim anlamına geldiği gerçeğini göstermektedir:
///
/// ```rust
/// #![forbid(unsafe_code)] // özel erişimlerle,
///                         // `UnsafeCell` şeffaf, işlemsiz bir paketleyicidir, bu nedenle burada `unsafe` e gerek yoktur.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` için derleme zamanı kontrol edilmiş benzersiz bir referans alın.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Özel bir referansla içeriği ücretsiz olarak değiştirebiliriz.
/// *p_unique.get_mut() = 0;
/// // Veya eşdeğer olarak:
/// x = UnsafeCell::new(0);
///
/// // Değere sahip olduğumuzda, içeriği ücretsiz olarak çıkarabiliriz.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Belirtilen değeri saracak yeni bir `UnsafeCell` örneği oluşturur.
    ///
    ///
    /// Yöntemler aracılığıyla iç değere tüm erişim `unsafe` tir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Değerin paketini açar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Sarmalanmış değere değiştirilebilir bir işaretçi alır.
    ///
    /// Bu, herhangi bir tür işaretçiye atılabilir.
    /// `&mut T` e yayın yaparken erişimin benzersiz olduğundan (etkin referanslar yok, değiştirilebilir veya değil) emin olun ve `&T` e döküm yaparken hiçbir mutasyon veya değiştirilebilir takma ad olmadığından emin olun
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // İşaretçiyi #[repr(transparent)] nedeniyle `UnsafeCell<T>` ten `T` e aktarabiliriz.
        // Bu, libstd'nin özel statüsünden yararlanır, kullanıcı kodunun derleyicinin future sürümlerinde çalışacağına dair bir garanti yoktur!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Temel verilere değiştirilebilir bir referans döndürür.
    ///
    /// Bu çağrı, `UnsafeCell` i mutabık bir şekilde (derleme zamanında) ödünç alır, bu da tek referansa sahip olduğumuzu garanti eder.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Sarmalanmış değere değiştirilebilir bir işaretçi alır.
    /// [`get`] ten farkı, bu işlevin ham bir gösterici kabul etmesidir, bu da geçici referansların oluşturulmasını önlemek için yararlıdır.
    ///
    /// Sonuç, herhangi bir türden bir işaretçiye dönüştürülebilir.
    /// `&mut T` e çevrim yaparken erişimin benzersiz olduğundan (aktif referanslar yok, değiştirilebilir veya değil) emin olun ve `&T` e çevrim yaparken hiçbir mutasyon veya değiştirilebilir takma ad olmadığından emin olun.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Bir `UnsafeCell` in aşamalı olarak başlatılması, `raw_get` i gerektirir, çünkü `get` i çağırmak, başlatılmamış verilere bir referans oluşturmayı gerektirecektir:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // İşaretçiyi #[repr(transparent)] nedeniyle `UnsafeCell<T>` ten `T` e aktarabiliriz.
        // Bu, libstd'nin özel statüsünden yararlanır, kullanıcı kodunun derleyicinin future sürümlerinde çalışacağına dair bir garanti yoktur!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T için `Default` değeriyle bir `UnsafeCell` oluşturur.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}