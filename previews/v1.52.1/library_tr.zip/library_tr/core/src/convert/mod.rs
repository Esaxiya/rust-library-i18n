//! Türler arasındaki dönüşümler için Traits.
//!
//! Bu modüldeki traits, bir türden diğerine dönüştürmek için bir yol sağlar.
//! Her trait farklı bir amaca hizmet eder:
//!
//! - Ucuz referanstan referansa dönüşümler için [`AsRef`] trait'yi uygulayın
//! - Ucuz değiştirilebilir-değiştirilebilir dönüşümler için [`AsMut`] trait'yi uygulayın
//! - Değer-değer dönüşümlerini tüketmek için [`From`] trait'yi uygulayın
//! - Mevcut crate dışındaki türlere değer-değer dönüşümlerini tüketmek için [`Into`] trait'yi uygulayın
//! - [`TryFrom`] ve [`TryInto`] traits, [`From`] ve [`Into`] gibi davranır, ancak dönüştürme başarısız olduğunda uygulanmalıdır.
//!
//! Bu modüldeki traits, birden çok türde argümanların desteklendiği genel işlevler için genellikle trait bounds olarak kullanılır.Örnekler için her bir trait belgesine bakın.
//!
//! Bir kitaplık yazarı olarak, standart kitaplıktaki kapsamlı uygulama sayesinde [`From`] ve [`TryFrom`] daha fazla esneklik sağladığından ve eşdeğer [`Into`] veya [`TryInto`] uygulamalarını ücretsiz sunduğundan, [`Into<U>`][`Into`] veya [`TryInto<U>`][`TryInto`] yerine her zaman [`From<T>`][`From`] veya [`TryFrom<T>`][`TryFrom`] i uygulamayı tercih etmelisiniz.
//! Rust 1.41 ten önceki bir sürümü hedeflerken, mevcut crate dışındaki bir türe dönüştürürken [`Into`] veya [`TryInto`] i doğrudan uygulamak gerekebilir.
//!
//! # Genel Uygulamalar
//!
//! - [`AsRef`] ve iç tip bir referans ise [`AsMut`] otomatik referans
//! - [`From`]`<U>for T`, [`Into`]`anlamına gelir</u><T><U>U` için</u>
//! - [`TryFrom`]`<U>for T`, [`TryInto`]`anlamına gelir</u><T><U>U` için</u>
//! - [`From`] ve [`Into`] yansıtıcıdır, bu da her tür `into` in kendisinin ve `from` in kendisinin yapabileceği anlamına gelir
//!
//! Kullanım örnekleri için her bir trait'ye bakın.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Kimlik işlevi.
///
/// Bu işlevle ilgili iki noktaya dikkat etmek önemlidir:
///
/// - Kapatma `x` i farklı bir türe zorlayabileceğinden, her zaman `|x| x` gibi bir kapamaya eşdeğer değildir.
///
/// - İşleve geçirilen `x` girişini taşır.
///
/// Sadece girdiyi geri döndüren bir işleve sahip olmak garip görünse de, bazı ilginç kullanımlar vardır.
///
///
/// # Examples
///
/// `identity` i başka, ilginç işlevler dizisi içinde hiçbir şey yapmamak için kullanma:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Bir tane eklemenin ilginç bir fonksiyon olduğunu varsayalım.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity` i bir koşulda "do nothing" temel durum olarak kullanma:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Daha ilginç şeyler yapın ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` yineleyicisinin `Some` varyantlarını korumak için `identity` i kullanma:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Ucuz bir referanstan referansa dönüştürme yapmak için kullanılır.
///
/// Bu trait, değiştirilebilir referanslar arasında dönüştürme için kullanılan [`AsMut`] e benzer.
/// Pahalı bir dönüştürme yapmanız gerekiyorsa, [`From`] i `&T` tipi ile uygulamak veya özel bir işlev yazmak daha iyidir.
///
/// `AsRef` [`Borrow`] ile aynı imzaya sahiptir, ancak [`Borrow`] birkaç yönden farklıdır:
///
/// - `AsRef` ten farklı olarak, [`Borrow`], herhangi bir `T` için kapsamlı bir içeriğe sahiptir ve bir referansı veya bir değeri kabul etmek için kullanılabilir.
/// - [`Borrow`] ayrıca ödünç alınan değer için [`Hash`], [`Eq`] ve [`Ord`] in sahip olunan değerle eşdeğer olmasını gerektirir.
/// Bu nedenle, bir yapının yalnızca tek bir alanını ödünç almak istiyorsanız, `AsRef` i uygulayabilirsiniz, ancak [`Borrow`] i uygulayamazsınız.
///
/// **Note: Bu trait başarısız olmamalıdır **.Dönüştürme başarısız olursa, [`Option<T>`] veya [`Result<T, E>`] döndüren özel bir yöntem kullanın.
///
/// # Genel Uygulamalar
///
/// - `AsRef` iç tip bir referans veya değiştirilebilir bir referans ise otomatik referanslar (örneğin: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds kullanarak, belirtilen `T` türüne dönüştürülebildikleri sürece farklı türlerdeki argümanları kabul edebiliriz.
///
/// Örneğin: `AsRef<str>` i alan genel bir işlev oluşturarak, [`&str`] e dönüştürülebilecek tüm referansları bir argüman olarak kabul etmek istediğimizi ifade ederiz.
/// Hem [`String`] hem de [`&str`], `AsRef<str>` i uyguladığından, ikisini de girdi argümanı olarak kabul edebiliriz.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Dönüştürmeyi gerçekleştirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Ucuz, değiştirilebilir-değiştirilebilir bir referans dönüşümü yapmak için kullanılır.
///
/// Bu trait, [`AsRef`] e benzer, ancak değişken referanslar arasında dönüştürme yapmak için kullanılır.
/// Pahalı bir dönüştürme yapmanız gerekiyorsa, [`From`] i `&mut T` tipi ile uygulamak veya özel bir işlev yazmak daha iyidir.
///
/// **Note: Bu trait başarısız olmamalıdır **.Dönüştürme başarısız olursa, [`Option<T>`] veya [`Result<T, E>`] döndüren özel bir yöntem kullanın.
///
/// # Genel Uygulamalar
///
/// - `AsMut` iç tür değiştirilebilir bir referans ise otomatik başvurular (örneğin: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// `AsMut` i genel bir fonksiyon için trait bound olarak kullanarak, `&mut T` tipine dönüştürülebilen tüm değişken referansları kabul edebiliriz.
/// [`Box<T>`], `AsMut<T>` i uyguladığından, `&mut u64` e dönüştürülebilen tüm argümanları alan bir `add_one` işlevi yazabiliriz.
/// [`Box<T>`], `AsMut<T>` i uyguladığından, `add_one`, `&mut Box<u64>` tipi argümanları da kabul eder:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Dönüştürmeyi gerçekleştirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Girdi değerini tüketen bir değer-değer dönüşümü.[`From`] in tersi.
///
/// [`Into`] uygulamasından kaçınılmalı ve bunun yerine [`From`] uygulanmalıdır.
/// [`From`] in uygulanması, standart kitaplıktaki kapsamlı uygulama sayesinde otomatik olarak bir [`Into`] uygulaması sağlar.
///
/// Yalnızca [`Into`] i uygulayan türlerin de kullanılabilmesini sağlamak için genel bir işlevde trait bounds'yi belirtirken [`From`] yerine [`Into`] kullanmayı tercih edin.
///
/// **Note: Bu trait başarısız olmamalıdır **.Dönüştürme başarısız olursa, [`TryInto`] kullanın.
///
/// # Genel Uygulamalar
///
/// - [`Kimden`]`<T>U` için `Into<U> for T` anlamına gelir
/// - [`Into`] dönüşlüdür, bu `Into<T> for T` in uygulandığı anlamına gelir
///
/// # Rust'nin eski sürümlerinde harici tiplere dönüştürme için [`Into`] in uygulanması
///
/// Rust 1.41 ten önce, hedef türü mevcut crate'nin bir parçası değilse, [`From`] i doğrudan uygulayamazsınız.
/// Örneğin, şu kodu alın:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Bu, dilin eski sürümlerinde derlenemeyecek çünkü Rust'nin artık kuralları biraz daha katıydı.
/// Bunu atlamak için [`Into`] i doğrudan uygulayabilirsiniz:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// [`Into`] in bir [`From`] uygulaması sağlamadığını anlamak önemlidir ([`From`] in [`Into`] ile yaptığı gibi).
/// Bu nedenle, her zaman [`From`] i uygulamaya çalışmalı ve [`From`] uygulanamazsa [`Into`] e geri dönmelisiniz.
///
/// # Examples
///
/// [`String`] [`İçine`]"<`[`Vec`] `<` [`u8`]`>>`uygular:
///
/// Genel bir işlevin, belirli bir `T` türüne dönüştürülebilecek tüm argümanları almasını istediğimizi ifade etmek için, [`İçine`] 'nin bir trait bound kullanabiliriz.<T>.
///
/// Örneğin: `is_hello` işlevi, ["Vec"] "<" ["u8"] ">" biçimine dönüştürülebilecek tüm bağımsız değişkenleri alır.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Dönüştürmeyi gerçekleştirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Girdi değerini tüketirken değer-değer dönüşümleri yapmak için kullanılır.[`Into`] in tersidir.
///
/// `From` in uygulanması, standart kütüphanedeki kapsamlı uygulama sayesinde [`Into`] in bir uygulamasını otomatik olarak sağladığından, `From` i [`Into`] e uygulamayı her zaman tercih etmelisiniz.
///
///
/// [`Into`] i yalnızca Rust 1.41 ten önceki bir sürümü hedeflerken ve mevcut crate dışındaki bir türe dönüştürürken uygulayın.
/// `From` Rust'nin artık kuralları nedeniyle bu tür dönüştürmeleri önceki sürümlerde yapamıyordu.
/// Daha fazla ayrıntı için [`Into`] e bakın.
///
/// Genel bir işlevde trait bounds'yi belirtirken `From` yerine [`Into`] kullanmayı tercih edin.
/// Bu şekilde, [`Into`] i doğrudan uygulayan türler de bağımsız değişken olarak kullanılabilir.
///
/// `From`, hata işleme sırasında da çok kullanışlıdır.Başarısız olabilen bir işlev oluştururken, dönüş türü genellikle `Result<T, E>` biçiminde olacaktır.
/// `From` trait, bir işlevin birden çok hata türünü kapsayan tek bir hata türü döndürmesine izin vererek hata işlemeyi basitleştirir.Daha fazla ayrıntı için "Examples" bölümüne ve [the book][book] e bakın.
///
/// **Note: Bu trait başarısız olmamalıdır **.Dönüştürme başarısız olursa, [`TryFrom`] kullanın.
///
/// # Genel Uygulamalar
///
/// - `From<T> for U` T`<U>için</u> [`Into`]` anlamına gelir
/// - `From` dönüşlüdür, bu `From<T> for T` in uygulandığı anlamına gelir
///
/// # Examples
///
/// [`String`] `From<&str>` i uygular:
///
/// Bir `&str` ten bir String'e açık bir dönüşüm şu şekilde yapılır:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Hata işlemeyi gerçekleştirirken `From` i kendi hata türünüz için uygulamak genellikle yararlıdır.
/// Altta yatan hata türlerini, temeldeki hata türünü kapsayan kendi özel hata türümüze dönüştürerek, temel nedene ilişkin bilgileri kaybetmeden tek bir hata türü döndürebiliriz.
/// '?' operatörü, `From` i uygularken otomatik olarak sağlanan `Into<CliError>::into` i çağırarak temeldeki hata tipini otomatik olarak özel hata tipimize dönüştürür.
/// Derleyici daha sonra hangi `Into` uygulamasının kullanılması gerektiğini belirler.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Dönüştürmeyi gerçekleştirir.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Pahalı olabilecek veya olmayabilecek `self` tüketen bir dönüştürme girişimidir.
///
/// Kitaplık yazarları genellikle bu trait'yi doğrudan uygulamamalı, ancak standart kitaplıktaki kapsamlı bir uygulama sayesinde daha fazla esneklik sunan ve eşdeğer bir `TryInto` uygulamasını ücretsiz olarak sağlayan [`TryFrom`] trait'yi uygulamayı tercih etmelidir.
/// Bununla ilgili daha fazla bilgi için [`Into`] belgelerine bakın.
///
/// # `TryInto` in Uygulanması
///
/// Bu, [`Into`] in uygulanmasıyla aynı kısıtlamalara ve mantığa sahiptir, ayrıntılar için oraya bakın.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Bir dönüştürme hatası durumunda döndürülen tür.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Dönüştürmeyi gerçekleştirir.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Bazı durumlarda kontrollü bir şekilde başarısız olabilen basit ve güvenli tür dönüştürmeleri.[`TryInto`] in tersidir.
///
/// Bu, önemsiz bir şekilde başarılı olabilecek ancak aynı zamanda özel işlem gerektirebilecek bir tür dönüşümü yaparken kullanışlıdır.
/// Örneğin, [`From`] trait kullanarak bir [`i64`] i [`i32`] e dönüştürmenin bir yolu yoktur, çünkü bir [`i64`], [`i32`] in temsil edemeyeceği bir değer içerebilir ve bu nedenle dönüştürme verileri kaybedebilir.
///
/// Bu, [`i64`] i bir [`i32`] e kırparak (esasen ["i64`] modülünün [`i32::MAX`] değerini verir) veya sadece [`i32::MAX`] i döndürerek veya başka bir yöntemle halledilebilir.
/// [`From`] trait, mükemmel dönüşümler için tasarlanmıştır, bu nedenle `TryFrom` trait, programcıya bir tür dönüşümünün ne zaman kötü gidebileceğini bildirir ve bunun nasıl ele alınacağına karar vermelerini sağlar.
///
/// # Genel Uygulamalar
///
/// - `TryFrom<T> for U` "T" <U>için</u> ["TryInto"] "anlamına gelir
/// - [`try_from`] dönüşlüdür, bu da `TryFrom<T> for T` in uygulandığı ve başarısız olamayacağı anlamına gelir-`T` türünde bir değerde `T::try_from()` i çağırmak için ilişkili `Error` türü [`Infallible`] tir.
/// [`!`] tipi stabilize edildiğinde [`Infallible`] ve [`!`] eşdeğer olacaktır.
///
/// `TryFrom<T>` aşağıdaki gibi uygulanabilir:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Açıklandığı gibi, [`i32`] "TryFrom <" ["i64`]">"uygular:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Sessizce `big_number` i keser, kesmenin gerçeğin ardından tespit edilmesini ve ele alınmasını gerektirir.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number`, bir `i32` e sığamayacak kadar büyük olduğu için bir hata döndürür.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` döndürür.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Bir dönüştürme hatası durumunda döndürülen tür.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Dönüştürmeyi gerçekleştirir.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENEL UYGULAMALAR
////////////////////////////////////////////////////////////////////////////////

// Asansörler gibi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut üzerindeki asansörler gibi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): &/&mut için yukarıdaki gösterimleri aşağıdaki daha genel olanla değiştirin:
// // Deref üzerindeki asansörler gibi
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut, &mut in üzerine çıktı
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut için yukarıdaki impl'yi aşağıdaki daha genel olanla değiştirin:
// // AsMut, DerefMut üzerinden yükseliyor
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Into'dan
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (ve böylece Into) dönüşlüdür
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Kararlılık notu:** Bu uygulama henüz mevcut değil, ancak onu future'ye eklemek için "reserving space" iz.
/// Ayrıntılar için [rust-lang/rust#64715][#64715] e bakın.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): bunun yerine ilkeli bir düzeltme yapın.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom, TryInto anlamına gelir
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Hatasız dönüştürmeler, anlamsal olarak ıssız bir hata türüne sahip yanılabilir dönüşümlere eşdeğerdir.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETON IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// HATA OLMAYAN HATA TÜRÜ
////////////////////////////////////////////////////////////////////////////////

/// Asla oluşamayacak hatalar için hata türü.
///
/// Bu numaralamanın değişkeni olmadığından, bu türden bir değer hiçbir zaman gerçekten var olamaz.
/// Bu, sonucun her zaman [`Ok`] olduğunu belirtmek için [`Result`] kullanan ve hata türünü parametreleştiren genel API'ler için yararlı olabilir.
///
/// Örneğin, [`TryFrom`] trait (bir [`Result`] döndüren dönüşüm), ters [`Into`] uygulamasının mevcut olduğu tüm türler için kapsamlı bir uygulamaya sahiptir.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future uyumluluğu
///
/// Bu numaralandırma, Rust'nin bu sürümünde kararsız olan [the `!`“never”type][never] ile aynı role sahiptir.
/// `!` stabilize edildiğinde, `Infallible` i bunun için bir tür takma adı yapmayı planlıyoruz:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Ve sonunda `Infallible` i kullanımdan kaldırır.
///
/// Bununla birlikte, `!` sözdiziminin, `!` tam teşekküllü bir tür olarak stabilize edilmeden önce kullanılabileceği bir durum vardır: bir işlevin dönüş türü konumunda.
/// Spesifik olarak, iki farklı işlev işaretçisi türü için olası uygulamalar vardır:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` bir numaralandırma olduğu için bu kod geçerlidir.
/// Ancak `Infallible`, never type için bir takma ad haline geldiğinde, iki "impl" örtüşmeye başlayacak ve bu nedenle dilin trait tutarlılık kuralları tarafından izin verilmeyecektir.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}