//! Diziler için `IntoIter` in sahip olduğu yineleyiciyi tanımlar.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Bir by-value [array] yineleyici.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Bu, üzerinde yinelediğimiz dizi.
    ///
    /// Henüz `alive.start <= i < alive.end` in verilmediği ve geçerli dizi girişleri olduğu `i` dizinine sahip öğeler.
    /// `i < alive.start` veya `i >= alive.end` endeksli elemanlar zaten verilmiş ve artık erişilmemelidir!Bu ölü elemanlar tamamen başlatılmamış bir durumda bile olabilir!
    ///
    ///
    /// Yani değişmezler:
    /// - `data[alive]` yaşıyor (yani geçerli öğeler içeriyor)
    /// - `data[..alive.start]` ve `data[alive.end..]` öldü (yani öğeler zaten okundu ve artık dokunulmaması gerekiyor!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` te henüz verilemeyen öğeler.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Verilen `array` üzerinde yeni bir yineleyici oluşturur.
    ///
    /// *Not*: Bu yöntem, [`IntoIterator` is implemented for arrays][array-into-iter] ten sonra future'de kullanımdan kaldırılmış olabilir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` türü burada `&i32` yerine `i32` tir
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // GÜVENLİK: Buradaki dönüşüm aslında güvenlidir.`MaybeUninit` belgeleri
        // promise:
        //
        // > `MaybeUninit<T>` aynı boyut ve hizada olması garantilidir
        // > `T` olarak.
        //
        // Dokümanlar, bir `MaybeUninit<T>` dizisinden bir `T` dizisine bir dönüşümü bile gösterir.
        //
        //
        // Bununla birlikte, bu başlatma değişmezleri tatmin eder.

        // FIXME(LukasKalbertodt): Aslında burada `mem::transmute` i kullanın, bir kez const jenerikleriyle çalıştığında:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // O zamana kadar, farklı bir tür olarak bitsel bir kopya oluşturmak için `mem::transmute_copy` i kullanabiliriz, sonra bırakılmaması için `array` i unutabiliriz.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Henüz verilmemiş tüm öğelerin değişmez bir dilimini döndürür.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // GÜVENLİK: `alive` içindeki tüm öğelerin uygun şekilde başlatıldığını biliyoruz.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Henüz verilmemiş tüm öğelerin değiştirilebilir bir dilimini döndürür.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // GÜVENLİK: `alive` içindeki tüm öğelerin uygun şekilde başlatıldığını biliyoruz.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Önden bir sonraki dizini alın.
        //
        // `alive.start` i 1 artırmak, `alive` ile ilgili değişmezliği korur.
        // Ancak bu değişiklik nedeniyle kısa bir süre için canlı bölge artık `data[alive]` değil, `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Öğeyi diziden okuyun.
            // GÜVENLİK: `idx`, eski "alive" bölgesine bir indekstir.
            // dizi.Bu öğenin okunması, `data[idx]` in artık ölü olarak kabul edildiği anlamına gelir (yani dokunmayın).
            // `idx`, canlı bölgenin başlangıcı olduğundan, canlı bölge şimdi yeniden `data[alive]` ve tüm değişmezleri geri yüklüyor.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Bir sonraki dizini arkadan alın.
        //
        // `alive.end` i 1 azaltmak, `alive` ile ilgili değişmezliği korur.
        // Ancak bu değişiklik nedeniyle kısa bir süre için canlı bölge artık `data[alive]` değil, `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Öğeyi diziden okuyun.
            // GÜVENLİK: `idx`, eski "alive" bölgesine bir indekstir.
            // dizi.Bu öğenin okunması, `data[idx]` in artık ölü olarak kabul edildiği anlamına gelir (yani dokunmayın).
            // `idx`, canlı bölgenin sonu olduğu için, canlı bölge şimdi yeniden `data[alive]` ve tüm değişmezleri geri yüklüyor.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // GÜVENLİK: Bu güvenlidir: `as_mut_slice` tam olarak alt dilimi döndürür
        // Henüz taşınmamış ve düşürülecek kalan öğeler.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Değişmez "alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Yineleyici gerçekten de doğru uzunluğu bildirir.
// "alive" öğelerinin sayısı (hala verilecek olan), `alive` aralığının uzunluğudur.
// Bu aralığın uzunluğu, `next` veya `next_back` te azaltılır.
// Bu yöntemlerde her zaman 1 azaltılır, ancak yalnızca `Some(_)` döndürülürse.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Unutmayın, aynı canlı aralığı eşleştirmemize gerçekten gerek yok, bu yüzden `self` nerede olursa olsun sadece ofset 0'a klonlayabiliriz.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Tüm canlı öğeleri klonlayın.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Yeni diziye bir klon yazın, ardından canlı aralığını güncelleyin.
            // panics klonlanıyorsa, önceki öğeleri doğru bir şekilde bırakacağız.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Yalnızca henüz verilmeyen öğeleri yazdırın: artık verilen öğelere erişemiyoruz.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}