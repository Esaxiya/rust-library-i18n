//! `Result` tipi ile hata işleme.
//!
//! [`Result<T, E>`][`Result`] hataları döndürmek ve yaymak için kullanılan türdür.
//! Başarıyı temsil eden ve bir değer içeren [`Ok(T)`] ve hatayı temsil eden ve bir hata değeri içeren [`Err(E)`] varyantlarına sahip bir numaralandırmadır.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! Hatalar beklendiğinde ve kurtarılabilir olduğunda işlevler [`Result`] i döndürür.`std` crate'de, [`Result`] en belirgin şekilde [I/O](../../std/io/index.html) için kullanılır.
//!
//! [`Result`] i döndüren basit bir işlev şu şekilde tanımlanabilir ve kullanılabilir:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! [`Result`] 'larda kalıp eşleştirme basit durumlar için açık ve anlaşılırdır, ancak [`Result`], onunla çalışmayı daha kısa ve öz hale getiren bazı kolaylık yöntemleriyle birlikte gelir.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` ve `is_err` yöntemleri söylediklerini yapar.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` `Result` i tüketir ve başka bir tane üretir.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // Hesaplamaya devam etmek için `and_then` kullanın.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // Hatayı işlemek için `or_else` kullanın.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // Sonucu tüketin ve içeriği `unwrap` ile iade edin.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # Sonuçlar kullanılmalıdır
//!
//! Hataları belirtmek için dönüş değerlerini kullanmakla ilgili yaygın bir sorun, dönüş değerini göz ardı etmenin kolay olması ve dolayısıyla hatayı ele alamamasıdır.
//! [`Result`] `#[must_use]` özniteliğiyle not edilir ve bu, bir Sonuç değeri yok sayıldığında derleyicinin bir uyarı vermesine neden olur.
//! Bu, [`Result`] i özellikle hatalarla karşılaşabilecek ancak başka türlü yararlı bir değer döndürmeyen işlevler için yararlı kılar.
//!
//! [`Write`] trait tarafından I/O türleri için tanımlanan [`write_all`] yöntemini göz önünde bulundurun:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`] in gerçek tanımı, yalnızca ["Sonuç"] ile eşanlamlı olan [`io::Result`] i kullanır.<T, `[`io: :Error`]`>.*
//!
//! Bu yöntem bir değer üretmez, ancak yazma başarısız olabilir.Hata durumunu halletmek ve buna benzer bir şey *yazmamak* çok önemlidir:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // Eğer `write_all` hatası varsa, o zaman asla bilemeyeceğiz, çünkü dönüş değeri göz ardı edilir.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! Bunu Rust'de *yaparsanız* yazarsanız, derleyici size bir uyarı verecektir (varsayılan olarak, `unused_must_use` lint tarafından kontrol edilir).
//!
//! Bunun yerine, hatayı işlemek istemiyorsanız, [`expect`] ile başarıyı kanıtlayabilirsiniz.
//! Bu, yazma başarısız olursa panic olur ve nedenini belirten marjinal olarak yararlı bir mesaj sağlar:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! Ayrıca basitçe başarıyı da iddia edebilirsiniz:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! Veya hatayı [`?`] ile çağrı yığınına yayın:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # Soru işareti operatörü, `?`
//!
//! [`Result`] türünü döndüren birçok işlevi çağıran kod yazarken, hata işleme sıkıcı olabilir.
//! Soru işareti operatörü [`?`], çağrı yığınında yukarı doğru yayılan hataların bazılarını gizler.
//!
//! Bunun yerine geçer:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // Hatanın erken dönüşü
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! Bununla:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // Hatanın erken dönüşü
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *Bu çok daha güzel!*
//!
//! İfadenin [`?`] ile sonlandırılması, sonuç [`Err`] olmadıkça sarılmamış ([`Ok`]) değeriyle sonuçlanacaktır; bu durumda [`Err`], çevreleyen işlevden erken döndürülür.
//!
//!
//! [`?`] [`Err`] in sağladığı erken dönüş nedeniyle yalnızca [`Result`] döndüren işlevlerde kullanılabilir.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` ([`Ok`]) başarısını veya ([`Err`]) hatasını temsil eden bir türdür.
///
/// Ayrıntılar için [module documentation](self) e bakın.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// Başarı değerini içerir
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// Hata değerini içerir
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// Tip uygulaması
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // İçerilen değerleri sorgulama
    /////////////////////////////////////////////////////////////////////////

    /// Sonuç [`Ok`] ise `true` döndürür.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// Sonuç [`Err`] ise `true` döndürür.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// Sonuç, verilen değeri içeren bir [`Ok`] değeriyse `true` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// Sonuç, verilen değeri içeren bir [`Err`] değeriyse `true` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Her varyant için adaptör
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>` ten [`Option<T>`] e dönüştürür.
    ///
    /// `self` i [`Option<T>`] e dönüştürür, `self` tüketir ve varsa hatayı atar.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// `Result<T, E>` ten [`Option<E>`] e dönüştürür.
    ///
    /// `self` i [`Option<E>`] e dönüştürür, `self` tüketir ve varsa başarı değerini atar.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Referanslarla çalışmak için adaptör
    /////////////////////////////////////////////////////////////////////////

    /// `&Result<T, E>` ten `Result<&T, &E>` e dönüştürür.
    ///
    /// Orijinali yerinde bırakarak, orijinale bir referans içeren yeni bir `Result` üretir.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// `&mut Result<T, E>` ten `Result<&mut T, &mut E>` e dönüştürür.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // İçerilen değerleri dönüştürme
    /////////////////////////////////////////////////////////////////////////

    /// İçerdiği bir [`Ok`] değerine bir işlev uygulayarak bir [`Err`] değerini el değmeden bırakarak bir `Result<T, E>` ile `Result<U, E>` i eşler.
    ///
    ///
    /// Bu işlev, iki işlevin sonuçlarını oluşturmak için kullanılabilir.
    ///
    /// # Examples
    ///
    /// Bir dizenin her satırındaki sayıları ikiyle çarparak yazdırın.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// İçerdiği değere bir işlev uygular ([`Ok`] ise) veya sağlanan varsayılanı ([`Err`] ise) döndürür.
    ///
    /// `map_or` e aktarılan argümanlar hevesle değerlendirilir;Bir işlev çağrısının sonucunu iletiyorsanız, tembel olarak değerlendirilen [`map_or_else`] i kullanmanız önerilir.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// İçerdiği bir [`Ok`] değerine bir işlev veya içerilen bir [`Err`] değerine bir geri dönüş işlevi uygulayarak bir `Result<T, E>` ile `U` i eşler.
    ///
    ///
    /// Bu işlev, bir hatayı ele alırken başarılı bir sonucun paketini açmak için kullanılabilir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// İçerdiği bir [`Err`] değerine bir işlev uygulayarak bir [`Ok`] değerini el değmeden bırakarak bir `Result<T, E>` ile `Result<T, F>` i eşler.
    ///
    ///
    /// Bu işlev, bir hatayı ele alırken başarılı bir sonucu geçmek için kullanılabilir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Yineleyici oluşturucular
    /////////////////////////////////////////////////////////////////////////

    /// Muhtemelen içerilen değerin üzerinde bir yineleyici döndürür.
    ///
    /// Yineleyici, sonuç [`Result::Ok`] ise bir değer verir, aksi takdirde hiçbiri olmaz.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// Muhtemelen içerilen değerin üzerinde değiştirilebilir bir yineleyici döndürür.
    ///
    /// Yineleyici, sonuç [`Result::Ok`] ise bir değer verir, aksi takdirde hiçbiri olmaz.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // Değerler üzerinde Boole işlemleri, istekli ve tembel
    /////////////////////////////////////////////////////////////////////////

    /// Sonuç [`Ok`] ise `res` i, aksi takdirde `self` in [`Err`] değerini döndürür.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// Sonuç [`Ok`] ise `op` i çağırır, aksi takdirde `self` in [`Err`] değerini döndürür.
    ///
    ///
    /// Bu fonksiyon, `Result` değerlerine göre kontrol akışı için kullanılabilir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// Sonuç [`Err`] ise `res` i, aksi takdirde `self` in [`Ok`] değerini döndürür.
    ///
    /// `or` e aktarılan argümanlar hevesle değerlendirilir;Bir işlev çağrısının sonucunu iletiyorsanız, tembel olarak değerlendirilen [`or_else`] i kullanmanız önerilir.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// Sonuç [`Err`] ise `op` i çağırır, aksi takdirde `self` in [`Ok`] değerini döndürür.
    ///
    ///
    /// Bu fonksiyon, sonuç değerlerine göre kontrol akışı için kullanılabilir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// İçerdiği [`Ok`] değerini veya sağlanan bir varsayılanı döndürür.
    ///
    /// `unwrap_or` e aktarılan argümanlar hevesle değerlendirilir;Bir işlev çağrısının sonucunu iletiyorsanız, tembel olarak değerlendirilen [`unwrap_or_else`] i kullanmanız önerilir.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// İçerilen [`Ok`] değerini döndürür veya bir kapanıştan hesaplar.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// Değerin bir [`Err`] olmadığını kontrol etmeden, `self` değerini tüketerek içerilen [`Ok`] değerini döndürür.
    ///
    ///
    /// # Safety
    ///
    /// Bu yöntemi bir [`Err`] te çağırmak *[tanımsız davranış]*'dır.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // Tanımsız davranış!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // GÜVENLİK: güvenlik sözleşmesi arayan tarafından onaylanmalıdır.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// Değerin bir [`Ok`] olmadığını kontrol etmeden, `self` değerini tüketerek içerilen [`Err`] değerini döndürür.
    ///
    ///
    /// # Safety
    ///
    /// Bu yöntemi bir [`Ok`] te çağırmak *[tanımsız davranış]*'dır.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // Tanımsız davranış!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // GÜVENLİK: güvenlik sözleşmesi arayan tarafından onaylanmalıdır.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// `Ok` parçasının içeriğini kopyalayarak bir `Result<&T, E>` i bir `Result<T, E>` ile eşler.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// `Ok` parçasının içeriğini kopyalayarak bir `Result<&mut T, E>` i bir `Result<T, E>` ile eşler.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// `Ok` parçasının içeriğini klonlayarak bir `Result<&T, E>` i bir `Result<T, E>` e eşler.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// `Ok` parçasının içeriğini klonlayarak bir `Result<&mut T, E>` i bir `Result<T, E>` e eşler.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// `self` değerini tüketerek içerilen [`Ok`] değerini döndürür.
    ///
    /// # Panics
    ///
    /// Panics, değer bir [`Err`] ise, aktarılan mesajı ve [`Err`] içeriğini içeren bir panic mesajı.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// `self` değerini tüketerek içerilen [`Ok`] değerini döndürür.
    ///
    /// Bu işlev panic olabileceğinden, kullanımı genellikle tavsiye edilmez.
    /// Bunun yerine, desen eşleştirmeyi kullanmayı ve [`Err`] durumunu açıkça işlemeyi veya [`unwrap_or`], [`unwrap_or_else`] veya [`unwrap_or_default`] i çağırmayı tercih edin.
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics, değer bir [`Err`] ise, panic mesajı [`Err`] 'nin değeri tarafından sağlanır.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// `self` değerini tüketerek içerilen [`Err`] değerini döndürür.
    ///
    /// # Panics
    ///
    /// Panics, değer bir [`Ok`] ise, aktarılan mesajı ve [`Ok`] içeriğini içeren bir panic mesajı.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// `self` değerini tüketerek içerilen [`Err`] değerini döndürür.
    ///
    /// # Panics
    ///
    /// Panics, değer bir [`Ok`] ise, [`Ok`] 'un değeri tarafından sağlanan özel bir panic mesajı.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// İçerdiği [`Ok`] değerini veya varsayılanı döndürür
    ///
    /// `self` bağımsız değişkenini tüketir, ardından [`Ok`], içerilen değeri döndürür, aksi takdirde [`Err`], bu tür için varsayılan değeri döndürür.
    ///
    ///
    /// # Examples
    ///
    /// Bir dizeyi tam sayıya dönüştürerek zayıf biçimlendirilmiş dizeleri 0'a (tamsayılar için varsayılan değer) dönüştürür.
    /// [`parse`] bir dizeyi [`FromStr`] i uygulayan başka bir türe dönüştürür ve hata durumunda bir [`Err`] döndürür.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// İçerdiği [`Ok`] değerini döndürür, ancak asla panics değerini döndürmez.
    ///
    /// [`unwrap`] ten farklı olarak, bu yöntemin uygulandığı sonuç türleri üzerinde asla panic olmadığı bilinmektedir.
    /// Bu nedenle, `unwrap` yerine, `Result` in hata türü daha sonra gerçekten meydana gelebilecek bir hatayla değiştirilirse derlenemeyecek bir sürdürülebilirlik koruması olarak kullanılabilir.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// `Result<T, E>` ten (veya `&Result<T, E>`) `Result<&<T as Deref>::Target, &E>` e dönüştürür.
    ///
    /// Orijinal [`Result`] in [`Ok`] varyantını [`Deref`](crate::ops::Deref) aracılığıyla zorlar ve yeni [`Result`] i döndürür.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// `Result<T, E>` ten (veya `&mut Result<T, E>`) `Result<&mut <T as DerefMut>::Target, &mut E>` e dönüştürür.
    ///
    /// Orijinal [`Result`] in [`Ok`] varyantını [`DerefMut`](crate::ops::DerefMut) aracılığıyla zorlar ve yeni [`Result`] i döndürür.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// Bir `Option` in `Result` ini bir `Result` in `Option` ine transpoze eder.
    ///
    /// `Ok(None)` `None` ile eşlenecek.
    /// `Ok(Some(_))` ve `Err(_)`, `Some(Ok(_))` ve `Some(Err(_))` ile eşleştirilecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// `Result<Result<T, E>, E>` ten `Result<T, E>` e dönüştürür
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// Düzleştirme, bir seferde yalnızca bir düzey iç içe geçmeyi kaldırır:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// `self` `Ok` ise [`Ok`] değerini ve `self` `Err` ise [`Err`] değerini döndürür.
    ///
    /// Başka bir deyişle, bu işlev, sonucun `Ok` veya `Err` olup olmadığına bakılmaksızın, bir `Result<T, T>` in değerini (`T`) döndürür.
    ///
    /// Bu, [`Atomic*::compare_exchange`] veya [`slice::binary_search`] gibi API'ler ile bağlantılı olarak yararlı olabilir, ancak yalnızca sonucun `Ok` olup olmadığını umursamadığınız durumlarda.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// Bu, yöntemlerin kod boyutunu azaltmak için ayrı bir işlevdir.
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait uygulamaları
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Muhtemelen içerilen değer üzerinden tüketen bir yineleyici döndürür.
    ///
    /// Yineleyici, sonuç [`Result::Ok`] ise bir değer verir, aksi takdirde hiçbiri olmaz.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Sonuç Yineleyiciler
/////////////////////////////////////////////////////////////////////////////

/// Bir [`Result`] in [`Ok`] varyantına referans üzerinden bir yineleyici.
///
/// Yineleyici, sonuç [`Ok`] ise bir değer verir, aksi takdirde hiçbiri olmaz.
///
/// [`Result::iter`] tarafından oluşturulmuştur.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// Bir [`Result`] in [`Ok`] varyantına değiştirilebilir bir referans üzerinde bir yineleyici.
///
/// [`Result::iter_mut`] tarafından oluşturulmuştur.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// Bir [`Result`] in [`Ok`] varyantındaki değerin üzerinde bir yineleyici.
///
/// Yineleyici, sonuç [`Ok`] ise bir değer verir, aksi takdirde hiçbiri olmaz.
///
/// Bu yapı, [`Result`] üzerinde [`into_iter`] yöntemi ile oluşturulur ([`IntoIterator`] trait tarafından sağlanır).
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// `Iterator` teki her bir öğeyi alır: eğer bir `Err` ise, başka öğeler alınmaz ve `Err` döndürülür.
    /// `Err` oluşmazsa, her `Result` in değerlerine sahip bir kap döndürülür.
    ///
    /// İşte bir vector içindeki her tamsayıyı artırarak taşmayı kontrol eden bir örnek:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// İşte başka bir tamsayı listesinden bir tane çıkarmaya çalışan başka bir örnek, bu sefer alttan taşmayı kontrol ediyor:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// İlk `Err` ten sonra `iter` ten başka öğelerin alınmadığını gösteren önceki örnekteki bir varyasyon.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Üçüncü öğe bir yetersizliğe neden olduğundan, başka öğe alınmadı, bu nedenle `shared` in son değeri 16 değil 6'dır (= `3 + 2 + 1`).
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): Bu performans hatası kapatıldığında bu Iterator::scan ile değiştirilebilir.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}