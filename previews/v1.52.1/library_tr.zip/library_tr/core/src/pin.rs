//! Verileri bellekteki konumuna sabitleyen türler.
//!
//! Hafızadaki yerlerinin değişmemesi ve dolayısıyla güvenilebilmesi açısından hareket etmemesi garanti edilen nesnelere sahip olmak bazen yararlıdır.
//! Bu tür bir senaryonun en iyi örneği, işaretçilerle bir nesneyi kendisine taşımak onları geçersiz kılarak tanımsız davranışa neden olabileceğinden, kendine referanslı yapılar oluşturmak olabilir.
//!
//! Yüksek düzeyde, [`Pin<P>`] herhangi bir işaretçi türü `P` in noktasının bellekte sabit bir konuma sahip olmasını sağlar, yani başka bir yere taşınamaz ve belleği düşene kadar ayrılamaz.Pointee'nin "pinned" olduğunu söylüyoruz.Sabitlenmiş verilerle sabitlenmemiş verileri birleştiren türleri tartışırken işler daha ince hale gelir;Daha fazla ayrıntı için [see below](#projections-and-structural-pinning).
//!
//! Varsayılan olarak, Rust'deki tüm türler hareketlidir.
//! Rust, tüm türleri değer bazında aktarmaya izin verir ve [`Box<T>`] ve `&mut T` gibi yaygın akıllı işaretçi türleri, içerdikleri değerleri değiştirmeye ve taşımaya izin verir: bir [`Box<T>`] ten çıkabilir veya [`mem::swap`] i kullanabilirsiniz.
//! [`Pin<P>`] `P` türünde bir işaretçi sarar, böylece [`Pin`]"<"[`Box`] `<T>>`normal bir
//!
//! [`Box<T>`]: when bir [`Pin`]"<"[`Box`] `<T>>`düşerse, içeriği de düşer ve hafıza
//!
//! serbest bırakıldı.Benzer şekilde, ["Pin`]"<&mut T>", `&mut T` e çok benzer.Ancak, [`Pin<P>`], istemcilerin sabitlenmiş verilere bir [`Box<T>`] veya `&mut T` almasına izin vermez, bu da [`mem::swap`] gibi işlemleri kullanamayacağınız anlamına gelir:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` `&mut T` e ihtiyacı var, ancak alamıyoruz.
//!     // Sıkıştık, bu referansların içeriğini değiştiremiyoruz.
//!     // `Pin::get_unchecked_mut` kullanabilirdik, ancak bu bir nedenden dolayı güvensiz:
//!     // onu `Pin` in dışına taşımak için kullanmamıza izin verilmiyor.
//! }
//! ```
//!
//! [`Pin<P>`] in bir Rust derleyicisinin tüm türleri taşınabilir olarak kabul ettiği gerçeğini *değiştirmediğini* tekrarlamakta fayda var.[`mem::swap`], herhangi bir `T` için çağrılabilir olmaya devam eder.Bunun yerine, [`Pin<P>`], `&mut T` gerektiren yöntemlerin ([`mem::swap`] gibi) çağrılmasını imkansız hale getirerek belirli *değerlerin*([`Pin<P>`] e sarılmış işaretçilerle işaret edilen) taşınmasını önler.
//!
//! [`Pin<P>`] `P` tipi herhangi bir işaretçi sarmak için kullanılabilir ve bu nedenle [`Deref`] ve [`DerefMut`] ile etkileşime girer.`P: Deref` in sabitlenmiş bir `P::Target` e "`P`-style pointer" olarak kabul edilmesi gereken bir [`Pin<P>`]-bu nedenle, bir [`Pin`]"<"["Box`] "<T>>", sabitlenmiş bir `T` için sahip olunan bir işaretçidir ve bir ["Sabitle"]"<"["Rc"]"<T>>`sabitlenmiş bir `T` için referans sayılan bir işaretçidir.
//! Doğruluk açısından, [`Pin<P>`], [`Deref`] ve [`DerefMut`] uygulamalarının `self` parametrelerinden çıkmamasına ve yalnızca iğnelenmiş bir işaretçi üzerinde çağrıldıklarında iğnelenmiş verilere bir işaretçi döndürmesine güvenir.
//!
//! # `Unpin`
//!
//! Sabit bir adrese sahip olmadıkları için birçok tür sabitlenmiş olsa bile her zaman serbestçe taşınabilir.Bu, tüm temel türleri ([`bool`], [`i32`] ve referanslar gibi) ve yalnızca bu türlerden oluşan türleri içerir.Sabitlemeyi önemsemeyen türler, [`Pin<P>`] in etkisini iptal eden [`Unpin`] auto-trait'yi uygular.
//! `T: Unpin` için, [`Pin`]"<"[`Box`] `<T>>`ve [`Box<T>`], [`Pin`] "<&mut T>" ve `&mut T` gibi aynı şekilde çalışır.
//!
//! Sabitlemenin ve [`Unpin`] in yalnızca işaretli `P::Target` türünü etkilediğini, [`Pin<P>`] e sarılmış olan `P` işaretçi türünün kendisini etkilemediğini unutmayın.Örneğin, [`Box<T>`] in [`Unpin`] olup olmaması, [`Pin`]"<"["Box`] "davranışını etkilemez.<T>>`(burada, `T` işaretli yazıdır).
//!
//! # Örnek: kendine referanslı yapı
//!
//! `Pin<T>` ile ilgili garantileri ve seçenekleri açıklamak için daha fazla ayrıntıya girmeden önce, nasıl kullanılabileceğine dair bazı örnekleri tartışıyoruz.
//! [skip to where the theoretical discussion continues](#drop-guarantee) ten çekinmeyin.
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Dilim alanı veri alanını işaret ettiği için bu kendi kendine başvuran bir yapıdır.
//! // Derleyiciye normal bir referansla bu konuda bilgi veremeyiz, çünkü bu kalıp olağan ödünç alma kuralları ile açıklanamaz.
//! //
//! // Bunun yerine, dizgeye işaret ettiğini bildiğimiz için boş olmadığı bilinen bir ham işaretçi kullanıyoruz.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // İşlev döndüğünde verilerin hareket etmemesini sağlamak için, onu nesnenin ömrü boyunca kalacağı yığına yerleştiririz ve ona erişmenin tek yolu ona bir işaretçi kullanmaktır.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // İşaretçiyi yalnızca veriler yerinde olduğunda oluştururuz, aksi takdirde daha başlamadan önce hareket etmiş olur.
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // bunun güvenli olduğunu biliyoruz çünkü bir alanı değiştirmek tüm yapıyı hareket ettirmez
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Yapı hareket etmediği sürece işaretçi doğru konumu göstermelidir.
//! //
//! // Bu arada, işaretçiyi hareket ettirmekte özgürüz.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Bizim tipimiz Unpin'i uygulamadığından, bu derlenemez:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Örnek: izinsiz çift bağlantılı liste
//!
//! İzinsiz çift bağlantılı bir listede, koleksiyon aslında öğelerin kendisi için bellek ayırmaz.
//! Tahsis, istemciler tarafından kontrol edilir ve öğeler, koleksiyonun sağladığından daha kısa süren bir yığın çerçevesi üzerinde yaşayabilir.
//!
//! Bunun işe yaraması için, her öğenin listedeki selefi ve halefi için işaretçileri vardır.Öğeler yalnızca sabitlendiklerinde eklenebilir, çünkü öğelerin hareket ettirilmesi işaretçileri geçersiz kılar.Ayrıca, bağlantılı bir liste öğesinin [`Drop`] uygulaması, kendisini listeden çıkarmak için selefinin ve halefinin işaretçilerine yama uygulayacaktır.
//!
//! En önemlisi, aranan [`drop`] e güvenebilmeliyiz.Eğer bir eleman [`drop`] çağrılmadan serbest bırakılabilir veya başka şekilde geçersiz kılınabilirse, ona komşu elemanlardan gelen işaretçiler geçersiz hale gelir ve bu da veri yapısını bozar.
//!
//! Bu nedenle, sabitleme aynı zamanda ["düşme" ile ilgili bir garantiyle birlikte gelir.
//!
//! # `Drop` guarantee
//!
//! Sabitlemenin amacı, bellekteki bazı verilerin yerleştirilmesine güvenebilmektir.
//! Bunun işe yaraması için, sadece verilerin taşınması kısıtlanmıştır;Verileri depolamak için kullanılan belleğin serbest bırakılması, yeniden kullanılması veya başka bir şekilde geçersiz kılınması da kısıtlanmıştır.
//! Somut olarak, sabitlenmiş veriler için, sabitlendiği andan [`drop`]*çağrılana kadar belleğinin geçersiz kılınmayacağı veya başka bir amaçla kullanılmayacağı* değişmezliğini korumanız gerekir.Yalnızca [`drop`] döndüğünde veya panics, bellek yeniden kullanılabilir.
//!
//! Bellek, serbest bırakma yoluyla "invalidated" olabilir, ancak aynı zamanda bir [`Some(v)`] i [`None`] ile değiştirerek veya [`Vec::set_len`] i "kill" e bir vector'den bazı öğeleri çağırarak da yapılabilir.Önce yıkıcıyı çağırmadan üzerine yazmak için [`ptr::write`] kullanılarak yeniden kullanılabilir.[`drop`] çağrılmadan sabitlenmiş veriler için bunların hiçbirine izin verilmez.
//!
//! Bu tam olarak, önceki bölümdeki izinsiz bağlantılı listenin doğru çalışması gerektiğinin garantisidir.
//!
//! Bu garantinin belleğin sızmadığı anlamına gelmediğini *unutmayın![`drop`] i sabitlenmiş bir elemanda çağırmamak yine de tamamen uygundur (örneğin, [`mem::forget`] i bir ["Pin"] "<" ["Box"] "üzerinden çağırabilirsiniz.<T>>`).Çift bağlantılı liste örneğinde, bu eleman listede kalacaktır.Ancak [`drop`]* çağrısı yapmadan depolamayı * serbest bırakamaz veya yeniden kullanamazsınız.
//!
//! # `Drop` implementation
//!
//! Türünüz sabitleme kullanıyorsa (yukarıdaki iki örnek gibi), [`Drop`] i uygularken dikkatli olmalısınız.[`drop`] işlevi `&mut self` i alır, ancak buna *türünüz önceden sabitlenmiş olsa bile* denir!Sanki derleyici otomatik olarak [`Pin::get_unchecked_mut`] i çağırır.
//!
//! Bu, güvenli kodda asla bir soruna neden olmaz çünkü sabitlemeye dayanan bir türü uygulamak güvenli olmayan kod gerektirir, ancak türünüzde sabitlemeyi kullanmaya karar vermenin (örneğin [`Pin`]"<&Self üzerinde bazı işlemler uygulayarak>`veya [`Pin`] "<&mut Self>") [`Drop`] uygulamanız için de sonuçlara sahiptir: türünüzden bir öğe sabitlenmiş olsaydı, [`Drop`] i örtük olarak [`Pin`]"<&mut Öz>`.
//!
//!
//! Örneğin, `Drop` i aşağıdaki gibi uygulayabilirsiniz:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` sorun değil çünkü bu değerin düşürüldükten sonra bir daha asla kullanılmayacağını biliyoruz.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Gerçek bırakma kodu buraya gelir.
//!         }
//!     }
//! }
//! ```
//!
//! `inner_drop` işlevi, [`drop`]*'in sahip olması gereken* türe sahiptir, bu nedenle bu, `self`/`this` i yanlışlıkla pinlemeyle çakışacak şekilde kullanmamanızı sağlar.
//!
//! Ayrıca, türünüz `#[repr(packed)]` ise, derleyici alanları bırakabilmek için otomatik olarak hareket ettirecektir.Yeterince hizalanmış alanlar için bile bunu yapabilir.Sonuç olarak, bir `#[repr(packed)]` tipi ile sabitlemeyi kullanamazsınız.
//!
//! # Projeksiyonlar ve Yapısal Sabitleme
//!
//! Sabitlenmiş yapılar ile çalışırken, sadece ["Pin"] "<&mut Struct>" alan bir yöntemde bu yapının alanlarına nasıl erişilebileceği sorusu ortaya çıkar.
//! Genel yaklaşım, [`Pin`]"<&mut Struct>"'ı alana referansa dönüştüren yardımcı yöntemler (*projeksiyonlar* olarak adlandırılır) yazmaktır, ancak bu referansın hangi türe sahip olması gerekir?Bu [`Pin`]"<&mut Field>`veya `&mut Field` mi?
//! Aynı soru, bir `enum` in alanlarında ve ayrıca [`Vec<T>`], [`Box<T>`] veya [`RefCell<T>`] gibi container/wrapper türleri dikkate alındığında ortaya çıkar.
//! (Bu soru hem değiştirilebilir hem de paylaşılan referanslar için geçerlidir, burada örnek olarak daha yaygın olan değiştirilebilir referansları kullanıyoruz.)
//!
//! Belirli bir alan için sabitlenmiş projeksiyonun ["Sabitle"] "<&mut Struct>" öğesini ["Pin"] "<&mut Field>" konumuna mı yoksa `&mut Field`.Yine de bazı kısıtlamalar vardır ve en önemli kısıtlama *tutarlılıktır*:
//! her alan *ya* sabitlenmiş bir referansa yansıtılabilir *ya da* projeksiyonun bir parçası olarak sabitleme kaldırılabilir.
//! Her ikisi de aynı alan için yapılırsa, bu muhtemelen sağlam olmayacaktır!
//!
//! Bir veri yapısının yazarı olarak, her alan için "propagates" in bu alana sabitlenip sabitlenmeyeceğine karar vereceksiniz.
//! Yayılan sabitlemeye "structural" de denir, çünkü türün yapısını takip eder.
//! Aşağıdaki alt bölümlerde, her iki seçim için yapılması gereken hususları açıklıyoruz.
//!
//! ## `field` için sabitleme *yapısal değildir*
//!
//! Sabitlenmiş bir yapının alanı sabitlenmemiş olabilir, ancak bu aslında en kolay seçimdir: eğer bir ["Pin"] "<&mut Alanı>" asla oluşturulmazsa, hiçbir şey ters gidemez!Bu nedenle, bazı alanların yapısal sabitlemeye sahip olmadığına karar verirseniz, tek yapmanız gereken, o alana hiçbir zaman sabitlenmiş bir referans oluşturmadığınızdır.
//!
//! Yapısal sabitlemesi olmayan alanlar, ["Sabitle"] "<&mut Struct>" öğesini `&mut Field` e dönüştüren bir projeksiyon yöntemine sahip olabilir:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Sorun değil çünkü `field` hiçbir zaman sabitlenmiş olarak kabul edilmez.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! `field` tipi [`Unpin`] olmasa bile *`impl Unpin for Struct`* yapabilirsiniz.Bu türün sabitleme hakkında ne düşündüğü, hiçbir zaman ["Sabitle"] "<&mut Alanı>" oluşturulmadığında alakalı değildir.
//!
//! ## Sabitleme * `field` için yapısaldır
//!
//! Diğer seçenek, sabitlemenin `field` için "structural" olduğuna karar vermektir, yani yapı sabitlenmişse alan da sabitlenir.
//!
//! Bu, bir ["Pin"] "<&mut Alanı>" oluşturan bir projeksiyon yazmaya izin verir, böylece alanın sabitlendiğine tanık olur:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Bu sorun değil çünkü `field`, `self` sabitlendiğinde sabitleniyor.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Bununla birlikte, yapısal sabitlemenin birkaç ekstra gereksinimi vardır:
//!
//! 1. Yapı, tüm yapısal alanlar [`Unpin`] ise yalnızca [`Unpin`] olmalıdır.Bu varsayılandır, ancak [`Unpin`] güvenli bir trait'dir, bu nedenle yapının yazarı `impl<T> Unpin for Struct<T>` gibi bir şey eklemek *değil* sizin sorumluluğunuzdadır.
//! (Bir projeksiyon işlemi eklemenin güvenli olmayan kod gerektirdiğine dikkat edin, bu nedenle [`Unpin`] in güvenli bir trait olduğu gerçeği, bunlardan yalnızca `` güvenli olmayan '' kullanırsanız endişelenmeniz gerektiği ilkesini bozmaz.)
//! 2. Yapının yıkıcısı yapısal alanları argümanının dışına taşımamalıdır.[previous section][drop-impl] te ortaya çıkan tam nokta budur: `drop`, `&mut self` i alır, ancak yapı (ve dolayısıyla alanları) daha önce sabitlenmiş olabilir.
//!     [`Drop`] uygulamanızın içinde bir alanı taşımayacağınızı garanti etmelisiniz.
//!     Özellikle, daha önce açıklandığı gibi, bu, yapınızın `#[repr(packed)]`*olmaması* gerektiği anlamına gelir.
//!     [`drop`] in, derleyicinin yanlışlıkla sabitlemeyi bozmamanıza yardımcı olabileceği bir şekilde nasıl yazılacağını öğrenmek için bu bölüme bakın.
//! 3. [`Drop` guarantee][drop-guarantee] i koruduğunuzdan emin olmalısınız:
//!     Yapınız sabitlendiğinde, içeriği içeren belleğin üzerine yazılmaz veya içeriğin yıkıcıları çağrılmadan serbest bırakılmaz.
//!     Bu, [`VecDeque<T>`] in tanıklık ettiği gibi yanıltıcı olabilir: [`VecDeque<T>`] in yıkıcısı, panics yıkıcılarından biri olursa, [`drop`] i tüm unsurlarda arayamayabilir.Bu, [`Drop`] garantisini ihlal eder, çünkü parçaların yıkıcıları çağrılmadan serbest bırakılmasına neden olabilir.([`VecDeque<T>`] sabitleme projeksiyonlarına sahip değildir, bu nedenle bu, ses bozukluğuna neden olmaz.)
//! 4. Türünüz sabitlendiğinde verilerin yapısal alanların dışına taşınmasına neden olabilecek başka işlemler sunmamalısınız.Örneğin, yapı bir [`Option<T>`] içeriyorsa ve `fn(Pin<&mut Struct<T>>) -> Option<T>` türünde "alma" benzeri bir işlem varsa, bu işlem bir `T` i sabitlenmiş bir `Struct<T>` ten çıkarmak için kullanılabilir-bu, sabitlemenin bunu tutan alan için yapısal olamayacağı anlamına gelir. veri.
//!
//!     Verileri sabitlenmiş bir türden taşımanın daha karmaşık bir örneği için, [`RefCell<T>`] in bir `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` yöntemine sahip olup olmadığını hayal edin.
//!     Sonra şunları yapabiliriz:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Bu felaket bir durum, yani önce [`RefCell<T>`] in içeriğini (`RefCell::get_pin_mut` kullanarak) sabitleyebileceğimiz ve sonra bu içeriği daha sonra aldığımız değiştirilebilir referansı kullanarak taşıyabileceğimiz anlamına geliyor.
//!
//! ## Examples
//!
//! [`Vec<T>`] gibi bir tip için, her iki olasılık da (yapısal sabitleme veya değil) anlamlıdır.
//! Yapısal sabitlemeye sahip bir [`Vec<T>`], öğelere sabitlenmiş referanslar almak için `get_pin`/`get_pin_mut` yöntemlerine sahip olabilir.Ancak, sabitlenmiş bir [`Vec<T>`] te [`pop`][Vec::pop] in çağrılmasına izin veremez * çünkü bu (yapısal olarak sabitlenmiş) içerikleri hareket ettirir![`push`][Vec::push] e de izin veremez, bu da içeriği yeniden tahsis edebilir ve böylece içeriği de hareket ettirebilir.
//!
//! Yapısal sabitleme olmayan bir [`Vec<T>`], `impl<T> Unpin for Vec<T>` olabilir, çünkü içerikler hiçbir zaman sabitlenmez ve [`Vec<T>`] in kendisi de hareket ettirilebilir.
//! Bu noktada sabitlemenin vector üzerinde hiçbir etkisi yoktur.
//!
//! Standart kitaplıkta, işaretçi türleri genellikle yapısal sabitlemeye sahip değildir ve bu nedenle sabitleme projeksiyonları sunmazlar.`Box<T>: Unpin` in tüm `T` için geçerli olmasının nedeni budur.
//! İşaretçi türleri için bunu yapmak mantıklıdır, çünkü `Box<T>` i hareket ettirmek aslında `T` i hareket ettirmez: [`Box<T>`], `T` olmasa bile serbestçe hareket ettirilebilir (`Unpin` olarak da bilinir).Aslında, ["Sabitle"] "<" ["Kutu"] "<T>>"ve ["Pin"]"<&mut T>"aynı nedenden dolayı her zaman [`Unpin`] in kendisidir: içerikleri (`T`) sabitlenmiştir, ancak işaretçiler sabitlenmiş verileri hareket ettirmeden taşınabilir.
//! Hem [`Box<T>`] hem de [`Pin`]"<"["Box`] "için<T>>`, içeriğin sabitlenmiş olup olmadığı, işaretçinin sabitlenip sabitlenmediğinden tamamen bağımsızdır, yani sabitleme *yapısal değildir*.
//!
//! Bir [`Future`] birleştirici uygularken, [`poll`] i çağırmak için bunlara sabitlenmiş referanslar almanız gerektiğinden, genellikle iç içe yerleştirilmiş futures için yapısal sabitlemeye ihtiyacınız olacaktır.
//! Ancak birleştiriciniz sabitlenmesi gerekmeyen başka herhangi bir veri içeriyorsa, bu alanları yapısal olmayan hale getirebilir ve bu nedenle, yalnızca ["Pin"] "<&mut Self>" (böyle bir kendi [`poll`] uygulamanızda olduğu gibi).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Sabitlenmiş bir işaretçi.
///
/// Bu, işaretçi "pin" i kendi değeri haline getiren ve bu işaretçinin referans verdiği değerin [`Unpin`] i uygulamadıkça hareket etmesini engelleyen bir tür göstericinin etrafındaki bir sarmalayıcıdır.
///
///
/// *Sabitlemeyle ilgili açıklama için [`pin` module] belgelerine bakın.*
///
/// [`pin` module]: self
///
// Note: Aşağıdaki `Clone` türetilmesi, uygulanması mümkün olduğu için ses bozukluğuna neden olur
// `Clone` değiştirilebilir referanslar için.
// Daha fazla ayrıntı için <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> e bakın.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Sağlamlık sorunlarını önlemek için aşağıdaki uygulamalar türetilmemiştir.
// `&self.pointer` güvenilmeyen trait uygulamaları için erişilebilir olmamalıdır.
//
// Daha fazla ayrıntı için <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> e bakın.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// [`Unpin`] i uygulayan bir türdeki bazı verilere yönelik bir işaretçi etrafında yeni bir `Pin<P>` oluşturun.
    ///
    /// `Pin::new_unchecked` ten farklı olarak, bu yöntem güvenlidir çünkü `P` işaretçisi, sabitleme garantilerini iptal eden bir [`Unpin`] tipine başvurur.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // GÜVENLİK: işaret edilen değer `Unpin` tir ve bu nedenle hiçbir gereksinimi yoktur
        // sabitleme etrafında.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Temeldeki işaretçiyi döndüren bu `Pin<P>` in paketini açar.
    ///
    /// Bu, bu `Pin` in içindeki verilerin [`Unpin`] olmasını gerektirir, böylece sarmayı açarken sabitleme değişmezlerini göz ardı edebiliriz.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// `Unpin` i uygulayabilecek veya uygulamayacak bazı verilere referans etrafında yeni bir `Pin<P>` oluşturun.
    ///
    /// `pointer`, bir `Unpin` tipine referans veriyorsa, bunun yerine `Pin::new` kullanılmalıdır.
    ///
    /// # Safety
    ///
    /// Bu kurucu güvensizdir çünkü `pointer` tarafından işaret edilen verilerin sabitlendiğini garanti edemeyiz, bu da verilerin taşınmayacağı veya bırakılıncaya kadar depolanmasının geçersiz kılınmayacağı anlamına gelir.
    /// Oluşturulan `Pin<P>`, `P` in işaret ettiği verilerin sabitlendiğini garanti etmiyorsa, bu API sözleşmesinin ihlalidir ve sonraki (safe) işlemlerinde tanımlanmamış davranışlara yol açabilir.
    ///
    /// Bu yöntemi kullanarak, varsa `P::Deref` ve `P::DerefMut` uygulamaları hakkında bir promise yaparsınız.
    /// En önemlisi, `self` argümanlarından çıkmamalılar: `Pin::as_mut` ve `Pin::as_ref`, sabitlenmiş işaretçi *üzerinde `DerefMut::deref_mut` ve `Deref::deref`*'i çağıracak ve bu yöntemlerin sabitleme değişmezlerini desteklemesini bekleyecektir.
    /// Dahası, bu yöntemi çağırdığınızda, `P` referansının ayrıldığı promise, tekrar dışarı taşınmayacaktır;özellikle, bir `&mut P::Target` elde etmek ve sonra bu referanstan çıkmak (örneğin [`mem::swap`] kullanarak) mümkün olmamalıdır.
    ///
    ///
    /// Örneğin, bir `&'a mut T` te `Pin::new_unchecked` i aramak güvensizdir çünkü onu verilen `'a` ömrü boyunca sabitleyebiliyorsanız, `'a` sona erdiğinde sabitlenip sabitlenmeyeceği konusunda hiçbir kontrolünüz yoktur:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Bu, Pointee `a` in bir daha asla hareket edemeyeceği anlamına gelmelidir.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // `a` in adresi "b" nin yığın yuvası olarak değiştirildi, bu nedenle `a`, daha önce sabitlemiş olsak bile taşındı!Sabitleme API sözleşmesini ihlal ettik.
    /////
    /// }
    /// ```
    ///
    /// Bir değer sabitlendikten sonra sonsuza kadar sabitlenmiş kalmalıdır (türü `Unpin` i uygulamadıkça).
    ///
    /// Benzer şekilde, bir `Rc<T>` te `Pin::new_unchecked` i aramak güvensizdir çünkü aynı verilere sabitleme kısıtlamalarına tabi olmayan diğer adlar olabilir:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Bu, pointee'nin bir daha asla hareket edemeyeceği anlamına gelmelidir.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Şimdi, eğer `x` tek referans ise, yukarıda sabitlediğimiz verilere, önceki örnekte gördüğümüz gibi onu hareket ettirmek için kullanabileceğimiz değişken bir referansımız var.
    ///     // Sabitleme API sözleşmesini ihlal ettik.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Bu sabitlenmiş işaretçiden sabitlenmiş bir paylaşılan başvuru alır.
    ///
    /// Bu, `&Pin<Pointer<T>>` ten `Pin<&T>` e gitmek için genel bir yöntemdir.
    /// Güvenlidir çünkü `Pin::new_unchecked` sözleşmesinin bir parçası olarak, `Pin<Pointer<T>>` oluşturulduktan sonra pointee hareket edemez.
    ///
    /// "Malicious" `Pointer::Deref` uygulamaları da aynı şekilde `Pin::new_unchecked` sözleşmesi ile reddedilir.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // GÜVENLİK: bu işlevle ilgili belgelere bakın
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Temeldeki işaretçiyi döndüren bu `Pin<P>` in paketini açar.
    ///
    /// # Safety
    ///
    /// Bu işlev güvenli değildir.Bu işlevi çağırdıktan sonra `P` işaretçisini sabitlenmiş olarak işlemeye devam edeceğinizi garanti etmelisiniz, böylece `Pin` türündeki değişmezler korunabilir.
    /// Sonuçta elde edilen `P` i kullanan kod, API sözleşmesinin ihlali olan sabitleme değişmezlerini korumaya devam etmezse ve sonraki (safe) işlemlerinde tanımsız davranışa yol açabilir.
    ///
    ///
    /// Temel alınan veriler [`Unpin`] ise, bunun yerine [`Pin::into_inner`] kullanılmalıdır.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Bu sabitlenmiş işaretçiden sabitlenmiş bir değişken başvuru alır.
    ///
    /// Bu, `&mut Pin<Pointer<T>>` ten `Pin<&mut T>` e gitmek için genel bir yöntemdir.
    /// Güvenlidir çünkü `Pin::new_unchecked` sözleşmesinin bir parçası olarak, `Pin<Pointer<T>>` oluşturulduktan sonra pointee hareket edemez.
    ///
    /// "Malicious" `Pointer::DerefMut` uygulamaları da aynı şekilde `Pin::new_unchecked` sözleşmesi ile reddedilir.
    ///
    /// Bu yöntem, sabitlenmiş türü kullanan işlevlere birden çok çağrı yapıldığında kullanışlıdır.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // bir şey yap
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` `self` tüketir, bu nedenle `Pin<&mut Self>` i `as_mut` aracılığıyla yeniden ödünç alın.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // GÜVENLİK: bu işlevle ilgili belgelere bakın
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Sabitlenmiş referansın arkasındaki belleğe yeni bir değer atar.
    ///
    /// Bu, sabitlenmiş verilerin üzerine yazar, ancak sorun değil: yok edicisi, üzerine yazılmadan önce çalıştırılır, bu nedenle hiçbir sabitleme garantisi ihlal edilmez.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// İç değeri eşleyerek yeni bir pim oluşturur.
    ///
    /// Örneğin, bir şeyin bir `Pin` alanını almak istiyorsanız, bu alana bir satır kodla erişmek için bunu kullanabilirsiniz.
    /// Ancak, bu "pinning projections" ile birkaç sorun var;
    /// bu konuyla ilgili daha fazla ayrıntı için [`pin` module] belgelerine bakın.
    ///
    /// # Safety
    ///
    /// Bu işlev güvenli değildir.
    /// Döndürdüğünüz verilerin, bağımsız değişken değeri hareket etmediği sürece (örneğin, bu değerin alanlarından biri olduğu için) hareket etmeyeceğini ve ayrıca aldığınız bağımsız değişkenin dışına çıkmayacağınızı garanti etmelisiniz. iç işlev.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // GÜVENLİK: `new_unchecked` için güvenlik sözleşmesi,
        // Arayan tarafından onaylandı.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Bir iğneden paylaşılan bir referans alır.
    ///
    /// Bu güvenlidir çünkü paylaşılan bir referanstan çıkmak mümkün değildir.
    /// Burada dahili değişkenlikle ilgili bir sorun varmış gibi görünebilir: Aslında, bir `T` i `&RefCell<T>` ten çıkarmak *mümkündür*.
    /// Ancak, aynı verilere işaret eden bir `Pin<&T>` olmadığı ve `RefCell<T>` içeriğine sabitlenmiş bir referans oluşturmanıza izin vermediği sürece bu bir sorun değildir.
    ///
    /// Daha fazla ayrıntı için ["pinning projections"] ile ilgili tartışmaya bakın.
    ///
    /// Note: `Pin` ayrıca iç değere erişmek için kullanılabilen `Deref` i hedefe uygular.
    /// Bununla birlikte, `Deref`, `Pin` in ömrü boyunca değil, yalnızca `Pin` ödünç alındığı sürece yaşayan bir referans sağlar.
    /// Bu yöntem, `Pin` i orijinal `Pin` ile aynı kullanım ömrüne sahip bir referansa dönüştürmeye izin verir.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Bu `Pin<&mut T>` i aynı ömre sahip bir `Pin<&T>` e dönüştürür.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Bu `Pin` in içindeki verilere değiştirilebilir bir referans alır.
    ///
    /// Bu, bu `Pin` içindeki verilerin `Unpin` olmasını gerektirir.
    ///
    /// Note: `Pin` ayrıca, iç değere erişmek için kullanılabilen `DerefMut` i verilere uygular.
    /// Bununla birlikte, `DerefMut`, `Pin` in ömrü boyunca değil, yalnızca `Pin` ödünç alındığı sürece yaşayan bir referans sağlar.
    ///
    /// Bu yöntem, `Pin` i orijinal `Pin` ile aynı kullanım ömrüne sahip bir referansa dönüştürmeye izin verir.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Bu `Pin` in içindeki verilere değiştirilebilir bir referans alır.
    ///
    /// # Safety
    ///
    /// Bu işlev güvenli değildir.
    /// `Pin` tipindeki değişmezlerin korunabilmesi için, bu işlevi çağırdığınızda aldığınız değişken referansın dışına asla veriyi taşımayacağınızı garanti etmelisiniz.
    ///
    ///
    /// Temel alınan veriler `Unpin` ise, bunun yerine `Pin::get_mut` kullanılmalıdır.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// İç değeri eşleyerek yeni bir pim oluşturun.
    ///
    /// Örneğin, bir şeyin bir `Pin` alanını almak istiyorsanız, bu alana bir satır kodla erişmek için bunu kullanabilirsiniz.
    /// Ancak, bu "pinning projections" ile birkaç sorun var;
    /// bu konuyla ilgili daha fazla ayrıntı için [`pin` module] belgelerine bakın.
    ///
    /// # Safety
    ///
    /// Bu işlev güvenli değildir.
    /// Döndürdüğünüz verilerin, bağımsız değişken değeri hareket etmediği sürece (örneğin, bu değerin alanlarından biri olduğu için) hareket etmeyeceğini ve ayrıca aldığınız bağımsız değişkenin dışına çıkmayacağınızı garanti etmelisiniz. iç işlev.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // GÜVENLİK: Arayan kişi telefonun yerini değiştirmemekten sorumludur.
        // bu referans dışında değer.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // GÜVENLİK: `this` in değerine sahip olmayacağı garanti edildiğinden
        // başka yere taşındığında, `new_unchecked` e yapılan bu çağrı güvenlidir.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Statik bir referanstan sabitlenmiş bir referans alın.
    ///
    /// Bu güvenlidir, çünkü `T`, `'static` ömrü boyunca ödünç alınır ve asla bitmez.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // GÜVENLİK: 'Statik ödünç alma, verilerin
        // moved/invalidated düşene kadar (ki bu asla değildir).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Statik değiştirilebilir bir referanstan sabitlenmiş değiştirilebilir bir referans alın.
    ///
    /// Bu güvenlidir, çünkü `T`, `'static` ömrü boyunca ödünç alınır ve asla bitmez.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // GÜVENLİK: 'Statik ödünç alma, verilerin
        // moved/invalidated düşene kadar (ki bu asla değildir).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: bu, `CoerceUnsized` in herhangi bir uygulamadan zorlanmaya izin verdiği anlamına gelir.
// `Deref<Target=impl !Unpin>` i `Deref<Target=Unpin>` i içeren bir türe dahil eden bir tür sağlam değil.
// Bu tür herhangi bir impl muhtemelen başka nedenlerden ötürü sağlıksız olacaktır, bu yüzden bu tür impl'lerin std'ye inmesine izin vermemeye özen göstermemiz gerekiyor.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}