//! Derleyici iç bilgileri.
//!
//! Karşılık gelen tanımlar `compiler/rustc_codegen_llvm/src/intrinsic.rs` içindedir.
//! Karşılık gelen const uygulamaları `compiler/rustc_mir/src/interpret/intrinsics.rs` te
//!
//! # Const intrinsics
//!
//! Note: Özün tutarlılığındaki herhangi bir değişiklik dil ekibiyle tartışılmalıdır.
//! Bu, sabitliğin kararlılığındaki değişiklikleri içerir.
//!
//! Derleme zamanında bir içsel kullanılabilir kılmak için, uygulamanın <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ten `compiler/rustc_mir/src/interpret/intrinsics.rs` e kopyalanması ve içsel olana bir `#[rustc_const_unstable(feature = "foo", issue = "01234")]` in eklenmesi gerekir.
//!
//!
//! Bir `rustc_const_stable` özniteliğine sahip bir `const fn` den bir intrinsic kullanılması gerekiyorsa, intrinsic özniteliği de `rustc_const_stable` olmalıdır.
//! Böyle bir değişiklik T-lang danışmanlığı olmadan yapılmamalıdır, çünkü kullanıcı kodunda derleyici desteği olmadan kopyalanamayan bir özelliği dile getirir.
//!
//! # Volatiles
//!
//! Uçucu özler, derleyici tarafından diğer uçucu özler arasında yeniden sıralanmaması garanti edilen, I/O belleğine etki etmesi amaçlanan işlemler sağlar.[[volatile]] üzerindeki LLVM belgelerine bakın.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atomik içsel bilgiler, birden çok olası bellek sıralamasıyla makine sözcükleri üzerinde ortak atomik işlemler sağlar.C ++ 11 ile aynı semantiğe uyarlar.[[atomics]] üzerindeki LLVM belgelerine bakın.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Hafıza sıralaması hakkında hızlı bir tazeleme:
//!
//! * Bir kilit elde etmek için bir bariyer edinin.Sonraki okuma ve yazma işlemleri bariyerden sonra gerçekleşir.
//! * Bir kilidi açmak için bir bariyer bırakın.Engelden önce okuma ve yazma işlemleri gerçekleşir.
//! * Sıralı olarak tutarlı, sıralı olarak tutarlı işlemlerin sırayla gerçekleşmesi garanti edilir.Bu, atomik türlerle çalışmak için standart moddur ve Java'nin `volatile` ine eşdeğerdir.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Bu içe aktarmalar, belge içi bağlantıları basitleştirmek için kullanılır
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // GÜVENLİK: bkz. `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, bu intrinsics ham işaretçileri alır çünkü `&` veya `&mut` için geçerli olmayan diğer adlı belleği değiştirirler.
    //

    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange` yöntemi aracılığıyla [`Ordering::SeqCst`] i hem `success` hem de `failure` parametreleri olarak geçirerek kullanılabilir.
    ///
    /// Örneğin, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange` yöntemi aracılığıyla [`Ordering::Acquire`] i hem `success` hem de `failure` parametreleri olarak geçirerek kullanılabilir.
    ///
    /// Örneğin, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange` yöntemi aracılığıyla [`Ordering::Release`] i `success` ve [`Ordering::Relaxed`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange` yöntemi aracılığıyla [`Ordering::AcqRel`] i `success` ve [`Ordering::Acquire`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange` yöntemi aracılığıyla [`Ordering::Relaxed`] i hem `success` hem de `failure` parametreleri olarak geçirerek kullanılabilir.
    ///
    /// Örneğin, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange` yöntemi aracılığıyla [`Ordering::SeqCst`] i `success` ve [`Ordering::Relaxed`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange` yöntemi aracılığıyla [`Ordering::SeqCst`] i `success` ve [`Ordering::Acquire`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange` yöntemi aracılığıyla [`Ordering::Acquire`] i `success` ve [`Ordering::Relaxed`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange` yöntemi aracılığıyla [`Ordering::AcqRel`] i `success` ve [`Ordering::Relaxed`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange_weak` yöntemi aracılığıyla [`Ordering::SeqCst`] i hem `success` hem de `failure` parametreleri olarak geçirerek kullanılabilir.
    ///
    /// Örneğin, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange_weak` yöntemi aracılığıyla [`Ordering::Acquire`] i hem `success` hem de `failure` parametreleri olarak geçirerek kullanılabilir.
    ///
    /// Örneğin, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange_weak` yöntemi aracılığıyla [`Ordering::Release`] i `success` ve [`Ordering::Relaxed`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange_weak` yöntemi aracılığıyla [`Ordering::AcqRel`] i `success` ve [`Ordering::Acquire`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange_weak` yöntemi aracılığıyla [`Ordering::Relaxed`] i hem `success` hem de `failure` parametreleri olarak geçirerek kullanılabilir.
    ///
    /// Örneğin, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange_weak` yöntemi aracılığıyla [`Ordering::SeqCst`] i `success` ve [`Ordering::Relaxed`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange_weak` yöntemi aracılığıyla [`Ordering::SeqCst`] i `success` ve [`Ordering::Acquire`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange_weak` yöntemi aracılığıyla [`Ordering::Acquire`] i `success` ve [`Ordering::Relaxed`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Mevcut değer `old` değeriyle aynıysa bir değer depolar.
    ///
    /// Bu intrinsikin stabilize versiyonu, [`atomic`] tiplerinde `compare_exchange_weak` yöntemi aracılığıyla [`Ordering::AcqRel`] i `success` ve [`Ordering::Relaxed`] i `failure` parametreleri olarak geçirerek kullanılabilir.
    /// Örneğin, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// İmlecin mevcut değerini yükler.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `load` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// İmlecin mevcut değerini yükler.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `load` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// İmlecin mevcut değerini yükler.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `load` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Değeri belirtilen bellek konumunda depolar.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `store` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Değeri belirtilen bellek konumunda depolar.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `store` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Değeri belirtilen bellek konumunda depolar.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `store` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Değeri belirtilen bellek konumunda saklar ve eski değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `swap` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Değeri belirtilen bellek konumunda saklar ve eski değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `swap` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Değeri belirtilen bellek konumunda saklar ve eski değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `swap` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Değeri belirtilen bellek konumunda saklar ve eski değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek `swap` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Değeri belirtilen bellek konumunda saklar ve eski değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `swap` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Önceki değeri döndürerek mevcut değere ekler.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `fetch_add` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Önceki değeri döndürerek mevcut değere ekler.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `fetch_add` yöntemi aracılığıyla [`atomic`] tiplerinde kullanılabilir.
    /// Örneğin, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Önceki değeri döndürerek mevcut değere ekler.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `fetch_add` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Önceki değeri döndürerek mevcut değere ekler.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek `fetch_add` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Önceki değeri döndürerek mevcut değere ekler.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `fetch_add` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Önceki değeri döndürerek mevcut değerden çıkarın.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `fetch_sub` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Önceki değeri döndürerek mevcut değerden çıkarın.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `fetch_sub` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Önceki değeri döndürerek mevcut değerden çıkarın.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `fetch_sub` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Önceki değeri döndürerek mevcut değerden çıkarın.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek `fetch_sub` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Önceki değeri döndürerek mevcut değerden çıkarın.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `fetch_sub` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitsel ve mevcut değerle, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `fetch_and` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsel ve mevcut değerle, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `fetch_and` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsel ve mevcut değerle, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `fetch_and` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsel ve mevcut değerle, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek `fetch_and` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsel ve mevcut değerle, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `fetch_and` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mevcut değerle bitsel nand, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `fetch_nand` yöntemi aracılığıyla [`AtomicBool`] tipinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mevcut değerle bitsel nand, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `fetch_nand` yöntemi aracılığıyla [`AtomicBool`] tipinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mevcut değerle bitsel nand, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `fetch_nand` yöntemi aracılığıyla [`AtomicBool`] tipinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mevcut değerle bitsel nand, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek `fetch_nand` yöntemi aracılığıyla [`AtomicBool`] tipinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mevcut değerle bitsel nand, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `fetch_nand` yöntemi aracılığıyla [`AtomicBool`] tipinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitsel veya mevcut değerle, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `fetch_or` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsel veya mevcut değerle, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `fetch_or` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsel veya mevcut değerle, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `fetch_or` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsel veya mevcut değerle, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek `fetch_or` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitsel veya mevcut değerle, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `fetch_or` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mevcut değerle bitsel xor, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `fetch_xor` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mevcut değerle bitsel xor, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `fetch_xor` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mevcut değerle bitsel xor, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `fetch_xor` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mevcut değerle bitsel xor, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek `fetch_xor` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mevcut değerle bitsel xor, önceki değeri döndürür.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `fetch_xor` yöntemi aracılığıyla [`atomic`] tiplerinde mevcuttur.
    /// Örneğin, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// İşaretli bir karşılaştırma kullanarak mevcut değerle maksimum.
    ///
    /// Bu içselin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `fetch_max` yöntemi aracılığıyla [`atomic`] işaretli tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretli bir karşılaştırma kullanarak mevcut değerle maksimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `fetch_max` yöntemi aracılığıyla [`atomic`] işaretli tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretli bir karşılaştırma kullanarak mevcut değerle maksimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `fetch_max` yöntemi aracılığıyla [`atomic`] işaretli tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretli bir karşılaştırma kullanarak mevcut değerle maksimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek `fetch_max` yöntemi aracılığıyla [`atomic`] işaretli tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mevcut değerle maksimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `fetch_max` yöntemi aracılığıyla [`atomic`] işaretli tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// İşaretli bir karşılaştırma kullanarak mevcut değerle minimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `fetch_min` yöntemi aracılığıyla [`atomic`] işaretli tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretli bir karşılaştırma kullanarak mevcut değerle minimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `fetch_min` yöntemi aracılığıyla [`atomic`] işaretli tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretli bir karşılaştırma kullanarak mevcut değerle minimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `fetch_min` yöntemi aracılığıyla [`atomic`] işaretli tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretli bir karşılaştırma kullanarak mevcut değerle minimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek `fetch_min` yöntemi aracılığıyla [`atomic`] işaretli tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretli bir karşılaştırma kullanarak mevcut değerle minimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `fetch_min` yöntemi aracılığıyla [`atomic`] işaretli tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// İşaretsiz bir karşılaştırma kullanarak mevcut değerle minimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `fetch_min` yöntemi aracılığıyla [`atomic`] işaretsiz tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretsiz bir karşılaştırma kullanarak mevcut değerle minimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `fetch_min` yöntemi aracılığıyla [`atomic`] işaretsiz tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretsiz bir karşılaştırma kullanarak mevcut değerle minimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `fetch_min` yöntemi aracılığıyla [`atomic`] işaretsiz tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretsiz bir karşılaştırma kullanarak mevcut değerle minimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek `fetch_min` yöntemi aracılığıyla [`atomic`] işaretsiz tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretsiz bir karşılaştırma kullanarak mevcut değerle minimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `fetch_min` yöntemi aracılığıyla [`atomic`] işaretsiz tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// İşaretsiz bir karşılaştırma kullanarak mevcut değerle maksimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek `fetch_max` yöntemi aracılığıyla [`atomic`] işaretsiz tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretsiz bir karşılaştırma kullanarak mevcut değerle maksimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek `fetch_max` yöntemi aracılığıyla [`atomic`] işaretsiz tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretsiz bir karşılaştırma kullanarak mevcut değerle maksimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek `fetch_max` yöntemi aracılığıyla [`atomic`] işaretsiz tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretsiz bir karşılaştırma kullanarak mevcut değerle maksimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek `fetch_max` yöntemi aracılığıyla [`atomic`] işaretsiz tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İşaretsiz bir karşılaştırma kullanarak mevcut değerle maksimum.
    ///
    /// Bu intrinsicin stabilize versiyonu, [`Ordering::Relaxed`] i `order` olarak geçerek `fetch_max` yöntemi aracılığıyla [`atomic`] işaretsiz tamsayı türlerinde kullanılabilir.
    /// Örneğin, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` içsel özelliği, destekleniyorsa bir ön getirme talimatı eklemek için kod üretecine bir ipucudur;aksi takdirde işlem yapılmaz.
    /// Ön yüklemelerin programın davranışı üzerinde hiçbir etkisi yoktur, ancak performans özelliklerini değiştirebilir.
    ///
    /// `locality` bağımsız değişkeni sabit bir tam sayı olmalıdır ve (0) ten (yerellik yok) (3) e kadar, son derece yerel önbellekte tutulan bir zamansal yerellik belirleyicisidir.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` içsel özelliği, destekleniyorsa bir ön getirme talimatı eklemek için kod üretecine bir ipucudur;aksi takdirde işlem yapılmaz.
    /// Ön yüklemelerin programın davranışı üzerinde hiçbir etkisi yoktur, ancak performans özelliklerini değiştirebilir.
    ///
    /// `locality` bağımsız değişkeni sabit bir tam sayı olmalıdır ve (0) ten (yerellik yok) (3) e kadar, son derece yerel önbellekte tutulan bir zamansal yerellik belirleyicisidir.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` içsel özelliği, destekleniyorsa bir ön getirme talimatı eklemek için kod üretecine bir ipucudur;aksi takdirde işlem yapılmaz.
    /// Ön yüklemelerin programın davranışı üzerinde hiçbir etkisi yoktur, ancak performans özelliklerini değiştirebilir.
    ///
    /// `locality` bağımsız değişkeni sabit bir tam sayı olmalıdır ve (0) ten (yerellik yok) (3) e kadar, son derece yerel önbellekte tutulan bir zamansal yerellik belirleyicisidir.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` içsel özelliği, destekleniyorsa bir ön getirme talimatı eklemek için kod üretecine bir ipucudur;aksi takdirde işlem yapılmaz.
    /// Ön yüklemelerin programın davranışı üzerinde hiçbir etkisi yoktur, ancak performans özelliklerini değiştirebilir.
    ///
    /// `locality` bağımsız değişkeni sabit bir tam sayı olmalıdır ve (0) ten (yerellik yok) (3) e kadar, son derece yerel önbellekte tutulan bir zamansal yerellik belirleyicisidir.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atomik bir çit.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek [`atomic::fence`] te mevcuttur.
    ///
    ///
    pub fn atomic_fence();
    /// Atomik bir çit.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek [`atomic::fence`] te mevcuttur.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atomik bir çit.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek [`atomic::fence`] te mevcuttur.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atomik bir çit.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek [`atomic::fence`] te mevcuttur.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Yalnızca derleyici bellek engeli.
    ///
    /// Bellek erişimleri hiçbir zaman bu engel boyunca derleyici tarafından yeniden düzenlenmeyecek, ancak bunun için herhangi bir talimat yayınlanmayacaktır.
    /// Bu, sinyal işleyicileri ile etkileşimde olduğu gibi, aynı iş parçacığı üzerinde önceden alınabilecek işlemler için uygundur.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::SeqCst`] i `order` olarak geçerek [`atomic::compiler_fence`] te mevcuttur.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Yalnızca derleyici bellek engeli.
    ///
    /// Bellek erişimleri hiçbir zaman bu engel boyunca derleyici tarafından yeniden düzenlenmeyecek, ancak bunun için herhangi bir talimat yayınlanmayacaktır.
    /// Bu, sinyal işleyicileri ile etkileşimde olduğu gibi, aynı iş parçacığı üzerinde önceden alınabilecek işlemler için uygundur.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Acquire`] i `order` olarak geçerek [`atomic::compiler_fence`] te mevcuttur.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Yalnızca derleyici bellek engeli.
    ///
    /// Bellek erişimleri hiçbir zaman bu engel boyunca derleyici tarafından yeniden düzenlenmeyecek, ancak bunun için herhangi bir talimat yayınlanmayacaktır.
    /// Bu, sinyal işleyicileri ile etkileşimde olduğu gibi, aynı iş parçacığı üzerinde önceden alınabilecek işlemler için uygundur.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::Release`] i `order` olarak geçerek [`atomic::compiler_fence`] te mevcuttur.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Yalnızca derleyici bellek engeli.
    ///
    /// Bellek erişimleri hiçbir zaman bu engel boyunca derleyici tarafından yeniden düzenlenmeyecek, ancak bunun için herhangi bir talimat yayınlanmayacaktır.
    /// Bu, sinyal işleyicileri ile etkileşimde olduğu gibi, aynı iş parçacığı üzerinde önceden alınabilecek işlemler için uygundur.
    ///
    /// Bu içkin stabilize versiyonu, [`Ordering::AcqRel`] i `order` olarak geçerek [`atomic::compiler_fence`] te mevcuttur.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Anlamını işleve eklenen özelliklerden alan sihirli içsel.
    ///
    /// Örneğin, veri akışı bunu statik iddiaları enjekte etmek için kullanır, böylece `rustc_peek(potentially_uninitialized)`, veri akışının gerçekten de kontrol akışının o noktasında başlatılmamış olduğunu hesapladığını iki kez kontrol eder.
    ///
    ///
    /// Bu içsel, derleyicinin dışında kullanılmamalıdır.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// İşlemin yürütülmesini iptal eder.
    ///
    /// Bu işlemin daha kullanıcı dostu ve kararlı bir versiyonu [`std::process::abort`](../../std/process/fn.abort.html) tir.
    ///
    pub fn abort() -> !;

    /// Optimize ediciye koddaki bu noktaya ulaşılamayacağını bildirerek daha fazla optimizasyon yapılmasını sağlar.
    ///
    /// Not, bu `unreachable!()` makrosundan çok farklıdır: panics'nin çalıştırıldığında yaptığı makrodan farklı olarak, bu işlevle işaretlenmiş koda ulaşmak *tanımsız davranıştır*.
    ///
    ///
    /// Bu özün stabilize versiyonu [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) tir.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Optimize ediciye bir koşulun her zaman doğru olduğunu bildirir.
    /// Koşul yanlışsa, davranış tanımsızdır.
    ///
    /// Bu içsel için hiçbir kod üretilmez, ancak optimize edici geçişler arasında kodu (ve durumunu) korumaya çalışır, bu da çevreleyen kodun optimizasyonunu engelleyebilir ve performansı düşürebilir.
    /// Değişmez, optimize edici tarafından kendi başına keşfedilebiliyorsa veya önemli optimizasyonları etkinleştirmiyorsa kullanılmamalıdır.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Derleyiciye branch koşulunun büyük olasılıkla doğru olduğuna dair ipuçları.
    /// Kendisine aktarılan değeri döndürür.
    ///
    /// `if` ifadeleri dışında herhangi bir kullanımın muhtemelen bir etkisi olmayacaktır.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Derleyiciye branch koşulunun büyük olasılıkla yanlış olduğuna dair ipuçları.
    /// Kendisine aktarılan değeri döndürür.
    ///
    /// `if` ifadeleri dışında herhangi bir kullanımın muhtemelen bir etkisi olmayacaktır.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Hata ayıklayıcı tarafından incelenmek üzere bir kesme noktası tuzağı yürütür.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn breakpoint();

    /// Bir türün bayt cinsinden boyutu.
    ///
    /// Daha spesifik olarak, bu, hizalama dolgusu dahil, aynı türden ardışık öğeler arasındaki bayt cinsinden kaymadır.
    ///
    ///
    /// Bu özün stabilize versiyonu [`core::mem::size_of`](crate::mem::size_of) tir.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Bir türün minimum hizalaması.
    ///
    /// Bu özün stabilize versiyonu [`core::mem::align_of`](crate::mem::align_of) tir.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Bir türün tercih edilen hizalaması.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Başvurulan değerin bayt cinsinden boyutu.
    ///
    /// Bu özün stabilize versiyonu [`mem::size_of_val`] tir.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Başvurulan değerin gerekli hizalaması.
    ///
    /// Bu özün stabilize versiyonu [`core::mem::align_of_val`](crate::mem::align_of_val) tir.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Bir türün adını içeren statik bir dize dilimi alır.
    ///
    /// Bu özün stabilize versiyonu [`core::any::type_name`](crate::any::type_name) tir.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Belirtilen türe genel olarak benzersiz olan bir tanımlayıcı alır.
    /// Bu işlev, hangi crate içinde çağrılırsa kullanılsın, bir tür için aynı değeri döndürecektir.
    ///
    ///
    /// Bu özün stabilize versiyonu [`core::any::TypeId::of`](crate::any::TypeId::of) tir.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// `T` oturulmadığında hiçbir zaman yürütülemeyecek güvenli olmayan işlevler için bir koruma:
    /// Bu statik olarak ya panic yapacak ya da hiçbir şey yapmayacaktır.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// `T` sıfır başlatmaya izin vermiyorsa hiçbir zaman yürütülemeyen güvenli olmayan işlevler için bir koruma: Bu statik olarak ya panic olacak ya da hiçbir şey yapmayacaktır.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn assert_zero_valid<T>();

    /// `T` geçersiz bit desenlerine sahipse hiçbir zaman yürütülemeyecek güvenli olmayan işlevler için bir koruma: Bu statik olarak ya panic olacak ya da hiçbir şey yapmayacaktır.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn assert_uninit_valid<T>();

    /// Nerede çağrıldığını belirten statik bir `Location` başvurusunu alır.
    ///
    /// Bunun yerine [`core::panic::Location::caller`](crate::panic::Location::caller) kullanmayı düşünün.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Damla yapıştırıcıyı çalıştırmadan bir değeri kapsam dışına taşır.
    ///
    /// Bu yalnızca [`mem::forget_unsized`] için mevcuttur;normal `forget` bunun yerine `ManuallyDrop` kullanır.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Bir türün değerinin bitlerini başka bir tür olarak yeniden yorumlar.
    ///
    /// Her iki türün de aynı boyutta olması gerekir.
    /// Ne orijinal ne de sonuç bir [invalid value](../../nomicon/what-unsafe-does.html) olabilir.
    ///
    /// `transmute` anlamsal olarak bir türün diğerine bitsel hareketine eşdeğerdir.Bitleri kaynak değerden hedef değere kopyalar, ardından orijinali unutur.
    /// Aynı `transmute_copy` gibi, kaputun altındaki C'nin `memcpy` ine eşdeğerdir.
    ///
    /// `transmute` bir by-value işlem olduğu için,*dönüştürülen değerlerin kendilerinin* hizalanması bir sorun oluşturmaz.
    /// Diğer herhangi bir işlevde olduğu gibi, derleyici zaten hem `T` hem de `U` in düzgün şekilde hizalanmasını sağlar.
    /// Bununla birlikte,*başka bir yere* işaret eden değerleri dönüştürürken (örneğin işaretçiler, referanslar, kutular…), arayan kişi, işaret edilen değerlerin uygun şekilde hizalanmasını sağlamalıdır.
    ///
    /// `transmute` **inanılmaz derecede** güvensiz.Bu işlevle [undefined behavior][ub] e neden olmanın çok sayıda yolu vardır.`transmute` mutlak son çare olmalıdır.
    ///
    /// [nomicon](../../nomicon/transmutes.html) ek belgelere sahiptir.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` in gerçekten yararlı olduğu birkaç şey var.
    ///
    /// Bir işaretçiyi bir işlev işaretçisine dönüştürmek.Bu, işlev işaretçilerinin ve veri işaretçilerinin farklı boyutlara sahip olduğu makinelerde taşınabilir *değildir*.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Bir yaşam süresini uzatmak veya değişmeyen bir ömrü kısaltmak.Bu gelişmiş, çok güvensiz Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Umutsuzluğa kapılmayın: `transmute` in birçok kullanımı başka yollarla sağlanabilir.
    /// Aşağıda, daha güvenli yapılarla değiştirilebilen yaygın `transmute` uygulamaları verilmiştir.
    ///
    /// Ham bytes(`&[u8]`) i `u32`, `f64`, vb .'ye çevirmek:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // bunun yerine `u32::from_ne_bytes` kullanın
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // veya sonu belirtmek için `u32::from_le_bytes` veya `u32::from_be_bytes` kullanın
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Bir işaretçiyi `usize` e dönüştürmek:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Bunun yerine bir `as` döküm kullanın
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Bir `*mut T` i `&mut T` e dönüştürmek:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Bunun yerine yeniden ödünç al
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` i `&mut U` e dönüştürmek:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Şimdi, `as` ve yeniden ödünç almayı bir araya getirin, `as` `as` in zincirlemesinin geçişli olmadığını unutmayın
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` i `&[u8]` e dönüştürmek:
    ///
    /// ```
    /// // bu, bunu yapmanın iyi bir yolu değil.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // `str::as_bytes` kullanabilirsiniz
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Veya, dizge değişmezi üzerinde kontrolünüz varsa, sadece bir bayt dizesi kullanın
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` i `Vec<Option<&T>>` e dönüştürme.
    ///
    /// Bir kabın içeriğinin iç türünü dönüştürmek için, kabın hiçbir değişmezini ihlal etmediğinizden emin olmalısınız.
    /// `Vec` için bu, iç tiplerin hem boyutunun *hem de hizalamasının* eşleşmesi gerektiği anlamına gelir.
    /// Diğer kaplar, türün boyutuna, hizasına ve hatta `TypeId` e bağlı olabilir, bu durumda, kap değişmezlerini ihlal etmeden dönüştürme hiç mümkün olmayacaktır.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector'yi daha sonra yeniden kullanacağımız için klonlayın
    /// let v_clone = v_orig.clone();
    ///
    /// // Dönüştürmeyi kullanma: Bu, kötü bir fikir olan ve Tanımsız Davranışa neden olabilecek `Vec` in belirtilmemiş veri düzenine dayanır.
    /////
    /// // Ancak kopya değildir.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Bu önerilen, güvenli yoldur.
    /// // vector'nin tamamını yeni bir diziye kopyalar.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Bu, veri düzenine güvenmeksizin "transmuting" a `Vec` in kopyasız, güvenli olmayan yoludur.
    /// // Kelimenin tam anlamıyla `transmute` i çağırmak yerine, bir işaretçi atışı gerçekleştiriyoruz, ancak orijinal iç tip (`&i32`) i yeni olan (`Option<&i32>`) e dönüştürmek açısından, bu aynı uyarılara sahip.
    /////
    /// // Yukarıda verilen bilgilerin yanı sıra, [`from_raw_parts`] belgelerine de bakın.
    /////
    /// let v_from_raw = unsafe {
    ///     // DÜZELTME vec_into_raw_parts stabilize edildiğinde bunu güncelleyin.
    ///     // Orijinal vector'nin düşürülmediğinden emin olun.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` in uygulanması:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Bunu yapmanın birden çok yolu vardır ve aşağıdaki (transmute) yöntemiyle ilgili birden çok sorun vardır.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // ilk: dönüştürme türü güvenli değildir;tüm kontrol ettiği şu T ve
    ///         // U aynı boyuttadır.
    ///         // İkincisi, tam burada, aynı belleğe işaret eden iki değişken referansınız var.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Bu tür güvenlik sorunlarından kurtulur;`&mut *`* yalnızca *size bir `&mut T` veya `* mut T` ten bir `&mut T` verecektir.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // ancak yine de aynı belleğe işaret eden iki değişken referansınız var.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Standart kitaplık bunu böyle yapar.
    /// // Böyle bir şey yapmanız gerekiyorsa en iyi yöntem budur.
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Bu artık aynı hafızayı işaret eden üç değişken referansa sahiptir.`slice`, rvalue ret.0 ve rvalue ret.1.
    ///         // `slice` `let ptr = ...` ten sonra asla kullanılmaz ve bu nedenle "dead" olarak değerlendirilebilir ve bu nedenle, yalnızca iki gerçek değiştirilebilir diliminiz olur.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Bu, intrinsic const'ı kararlı hale getirirken, const fn'de bazı özel kodlarımız var.
    // `const fn` içinde kullanımını engelleyen kontroller.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `T` olarak verilen gerçek tür damla yapıştırıcı gerektiriyorsa `true` i döndürür;`T` için sağlanan gerçek tür `Copy` i uygularsa `false` i döndürür.
    ///
    ///
    /// Gerçek tip ne damla yapıştırıcısı gerektiriyorsa ne de `Copy` uyguluyorsa, bu fonksiyonun dönüş değeri belirtilmez.
    ///
    /// Bu özün stabilize versiyonu [`mem::needs_drop`](crate::mem::needs_drop) tir.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Bir işaretçiden ofseti hesaplar.
    ///
    /// Bu, bir tamsayıya ve bir tamsayıdan dönüştürmekten kaçınmak için bir içsel olarak uygulanır, çünkü dönüştürme takma ad bilgisini atacaktır.
    ///
    /// # Safety
    ///
    /// Hem başlangıç hem de sonuç göstericisi, sınırlar içinde veya tahsis edilen nesnenin sonunu geçen bir bayt olmalıdır.
    /// İşaretçilerden biri sınırların dışındaysa veya aritmetik taşma meydana gelirse, döndürülen değerin daha fazla kullanılması tanımsız davranışla sonuçlanacaktır.
    ///
    ///
    /// Bu özün stabilize versiyonu [`pointer::offset`] tir.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Bir işaretçiden ofseti, potansiyel olarak kaydırarak hesaplar.
    ///
    /// Bu, dönüşüm belirli optimizasyonları engellediğinden, bir tamsayıya ve tamsayıdan dönüştürmeyi önlemek için bir içsel olarak uygulanır.
    ///
    /// # Safety
    ///
    /// `offset` içselinden farklı olarak, bu içsel, sonuçta ortaya çıkan işaretçiyi, tahsis edilen nesnenin sonunu gösterecek veya bir bayta geçecek şekilde sınırlamaz ve ikinin tamamlayıcı aritmetiğiyle sarılır.
    /// Ortaya çıkan değerin belleğe gerçekten erişmek için kullanılması zorunlu değildir.
    ///
    /// Bu özün stabilize versiyonu [`pointer::wrapping_offset`] tir.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Bir `count`*`size_of::<T>()` boyutunda ve bir hizalamayla uygun `llvm.memcpy.p0i8.0i8.*` içseline eşdeğerdir.
    ///
    /// `min_align_of::<T>()`
    ///
    /// Uçucu parametre `true` olarak ayarlanmıştır, bu nedenle boyut sıfıra eşit olmadığı sürece optimize edilmeyecektir.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Bir `count *size_of::<T>()` boyutunda ve bir hizalamayla uygun `llvm.memmove.p0i8.0i8.*` içseline eşdeğerdir.
    ///
    /// `min_align_of::<T>()`
    ///
    /// Uçucu parametre `true` olarak ayarlanmıştır, bu nedenle boyut sıfıra eşit olmadığı sürece optimize edilmeyecektir.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` boyutunda ve `min_align_of::<T>()` hizalamasında uygun `llvm.memset.p0i8.*` içseline eşdeğerdir.
    ///
    ///
    /// Uçucu parametre `true` olarak ayarlanmıştır, bu nedenle boyut sıfıra eşit olmadığı sürece optimize edilmeyecektir.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` işaretçisinden geçici bir yükleme gerçekleştirir.
    ///
    /// Bu özün stabilize versiyonu [`core::ptr::read_volatile`](crate::ptr::read_volatile) tir.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` işaretçisine geçici bir depolama gerçekleştirir.
    ///
    /// Bu özün stabilize versiyonu [`core::ptr::write_volatile`](crate::ptr::write_volatile) tir.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` işaretçisinden geçici bir yük gerçekleştirir İşaretçinin hizalanması gerekmez.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` işaretçisine geçici bir depolama gerçekleştirir.
    /// İşaretçinin hizalanması gerekli değildir.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Bir `f32` in karekökünü verir
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Bir `f64` in karekökünü verir
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` i tam sayı gücüne yükseltir.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` i tam sayı gücüne yükseltir.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Bir `f32` in sinüsünü döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Bir `f64` in sinüsünü döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Bir `f32` in kosinüsünü döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Bir `f64` in kosinüsünü döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` i `f32` gücüne yükseltir.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` i `f64` gücüne yükseltir.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Bir `f32` in üstelini döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Bir `f64` in üstelini döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// `f32` in gücüne yükseltilmiş 2 döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// `f64` in gücüne yükseltilmiş 2 döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Bir `f32` in doğal logaritmasını döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Bir `f64` in doğal logaritmasını döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Bir `f32` in 10 tabanındaki logaritmasını döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Bir `f64` in 10 tabanındaki logaritmasını döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Bir `f32` in 2 tabanındaki logaritmasını döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Bir `f64` in 2 tabanındaki logaritmasını döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` değerleri için `a * b + c` i döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` değerleri için `a * b + c` i döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Bir `f32` in mutlak değerini döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Bir `f64` in mutlak değerini döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Minimum iki `f32` değerini döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Minimum iki `f64` değerini döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// En fazla iki `f32` değerini döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// En fazla iki `f64` değerini döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` değerleri için işareti `y` ten `x` e kopyalar.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` değerleri için işareti `y` ten `x` e kopyalar.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` ten küçük veya ona eşit en büyük tamsayıyı döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` ten küçük veya ona eşit en büyük tamsayıyı döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` e eşit veya daha büyük olan en küçük tamsayıyı döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` e eşit veya daha büyük olan en küçük tamsayıyı döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Bir `f32` in tam sayı kısmını döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Bir `f64` in tam sayı kısmını döndürür.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// En yakın tam sayıyı `f32` e döndürür.
    /// Bağımsız değişken bir tamsayı değilse, kesin olmayan bir kayan nokta istisnası ortaya çıkabilir.
    pub fn rintf32(x: f32) -> f32;
    /// En yakın tam sayıyı `f64` e döndürür.
    /// Bağımsız değişken bir tamsayı değilse, kesin olmayan bir kayan nokta istisnası ortaya çıkabilir.
    pub fn rintf64(x: f64) -> f64;

    /// En yakın tam sayıyı `f32` e döndürür.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn nearbyintf32(x: f32) -> f32;
    /// En yakın tam sayıyı `f64` e döndürür.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn nearbyintf64(x: f64) -> f64;

    /// En yakın tam sayıyı `f32` e döndürür.Servis taleplerini sıfırdan uzağa yarı yuvarlar.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// En yakın tam sayıyı `f64` e döndürür.Servis taleplerini sıfırdan uzağa yarı yuvarlar.
    ///
    /// Bu içkin stabilize versiyonu
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Cebirsel kurallara dayalı optimizasyonlara izin veren kayan toplama.
    /// Girdilerin sonlu olduğunu varsayabilir.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Cebirsel kurallara dayalı optimizasyonlara izin veren kayan nokta çıkarma.
    /// Girdilerin sonlu olduğunu varsayabilir.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Cebirsel kurallara dayalı optimizasyonlara izin veren kayan çarpma.
    /// Girdilerin sonlu olduğunu varsayabilir.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Cebirsel kurallara dayalı optimizasyonlara izin veren kayan bölme.
    /// Girdilerin sonlu olduğunu varsayabilir.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Cebirsel kurallara dayalı optimizasyonlara izin veren float kalanı.
    /// Girdilerin sonlu olduğunu varsayabilir.
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// LLVM'nin fptoui/fptosi ile dönüştürme, aralık dışındaki değerler için undef döndürebilir
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] ve [`f64::to_int_unchecked`] olarak stabilize edildi.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// `T` tamsayı türünde ayarlanan bit sayısını verir
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `count_ones` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// `T` tamsayı türünde önde gelen set edilmemiş bitlerin sayısını (zeroes) döndürür.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `leading_zeros` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` değerine sahip bir `x`, `T` in bit genişliğini döndürür.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` gibi, ancak `0` değerine sahip bir `x` verildiğinde `undef` döndürdüğü için ekstra güvensizdir.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// `T` tamsayı türünde (zeroes) sondaki set edilmemiş bitlerin sayısını döndürür.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `trailing_zeros` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` değerine sahip bir `x`, `T` in bit genişliğini döndürür:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` gibi, ancak `0` değerine sahip bir `x` verildiğinde `undef` döndürdüğü için ekstra güvensizdir.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Baytları `T` tamsayı türünde ters çevirir.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `swap_bytes` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// `T` tamsayı türündeki bitleri ters çevirir.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `reverse_bits` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Kontrol edilen tamsayı toplamayı gerçekleştirir.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `overflowing_add` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Kontrol edilen tamsayı çıkarma işlemini gerçekleştirir
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `overflowing_sub` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Kontrol edilen tamsayı çarpma işlemini gerçekleştirir
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `overflowing_mul` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Tam bir bölme gerçekleştirerek `x % y != 0` veya `y == 0` veya `x == T::MIN && y == -1` te tanımlanmamış davranışla sonuçlanır
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Kontrolsüz bir bölme gerçekleştirerek, `y == 0` veya `x == T::MIN && y == -1` in
    ///
    ///
    /// Bu içsel için güvenli sarmalayıcılar, `checked_div` yöntemi aracılığıyla tamsayı temel öğelerinde mevcuttur.
    /// Örneğin,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Kontrol edilmemiş bir bölümün kalanını döndürür ve `y == 0` veya `x == T::MIN && y == -1` olduğunda tanımsız davranışla sonuçlanır.
    ///
    ///
    /// Bu içsel için güvenli sarmalayıcılar, `checked_rem` yöntemi aracılığıyla tamsayı temel öğelerinde mevcuttur.
    /// Örneğin,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Kontrolsüz bir sola kaydırma gerçekleştirerek, `y < 0` veya `y >= N` olduğunda tanımsız davranışla sonuçlanır; burada N, bit cinsinden T'nin genişliğidir.
    ///
    ///
    /// Bu içsel için güvenli sarmalayıcılar, `checked_shl` yöntemi aracılığıyla tamsayı temel öğelerinde mevcuttur.
    /// Örneğin,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Kontrolsüz bir sağa kaydırma gerçekleştirerek, `y < 0` veya `y >= N` olduğunda tanımsız davranışla sonuçlanır; burada N, bit cinsinden T'nin genişliğidir.
    ///
    ///
    /// Bu içsel için güvenli sarmalayıcılar, `checked_shr` yöntemi aracılığıyla tamsayı temel öğelerinde mevcuttur.
    /// Örneğin,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Denetlenmemiş bir eklemenin sonucunu döndürür ve `x + y > T::MAX` veya `x + y < T::MIN` olduğunda tanımsız davranışla sonuçlanır.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Denetlenmemiş bir çıkarma işleminin sonucunu döndürür ve `x - y > T::MAX` veya `x - y < T::MIN` olduğunda tanımsız davranışla sonuçlanır.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Denetlenmemiş bir çarpmanın sonucunu döndürür ve `x *y > T::MAX` veya `x* y < T::MIN` olduğunda tanımsız davranışla sonuçlanır.
    ///
    ///
    /// Bu özün kararlı bir karşılığı yoktur.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Sola döndürmeyi gerçekleştirir.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `rotate_left` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Sağa döndürmeyi gerçekleştirir.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `rotate_right` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// (A + b) mod 2 <sup>N'yi</sup> döndürür; burada N, bit cinsinden T'nin genişliğidir.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `wrapping_add` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (A, b) mod 2 <sup>N'yi</sup> döndürür; burada N, bit cinsinden T'nin genişliğidir.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `wrapping_sub` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// (A * b) mod 2 <sup>N</sup> döndürür, burada N, bit cinsinden T genişliğidir.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `wrapping_mul` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Sayısal sınırlarda doygunluk veren `a + b` i hesaplar.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `saturating_add` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Sayısal sınırlarda doygunluk veren `a - b` i hesaplar.
    ///
    /// Bu intrinsicin stabilize edilmiş versiyonları, `saturating_sub` metodu aracılığıyla tamsayı ilkellerinde mevcuttur.
    /// Örneğin,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' teki varyant için ayırt edicinin değerini döndürür;
    /// `T` in ayırt edici özelliği yoksa, `0` i döndürür.
    ///
    /// Bu özün stabilize versiyonu [`core::mem::discriminant`](crate::mem::discriminant) tir.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Bir `usize` e dönüştürülen `T` tipi varyantların sayısını döndürür;
    /// `T` in hiçbir çeşidi yoksa, `0` i döndürür.Yerleşik olmayan varyantlar sayılacaktır.
    ///
    /// Bu özün stabilize edilecek versiyonu [`mem::variant_count`] tir.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust'nin "try catch" yapısı, `try_fn` işlev işaretçisini `data` veri işaretçisi ile çağırır.
    ///
    /// Üçüncü argüman, bir panic meydana gelirse çağrılan bir işlevdir.
    /// Bu işlev, veri işaretçisini ve yakalanan hedefe özgü istisna nesnesine bir işaretçiyi alır.
    ///
    /// Daha fazla bilgi için derleyicinin kaynağına ve std'nin catch uygulamasına bakın.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM'ye göre bir `!nontemporal` deposu yayar (belgelerine bakın).
    /// Muhtemelen asla stabil olmayacak.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Ayrıntılar için `<*const T>::offset_from` belgelerine bakın.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Ayrıntılar için `<*const T>::guaranteed_eq` belgelerine bakın.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Ayrıntılar için `<*const T>::guaranteed_ne` belgelerine bakın.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Derleme zamanında ayırın.Çalışma zamanında çağrılmamalıdır.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Bazı işlevler burada tanımlanmıştır çünkü bunlar yanlışlıkla bu modülde kararlı olarak kullanılabilir hale getirilmiştir.
// <https://github.com/rust-lang/rust/issues/15702> e bakın.
// (`transmute` de bu kategoriye girer, ancak `T` ve `U` in aynı boyutta olup olmadığı kontrol edildiği için paketlenemez.)
//

/// `ptr` in `align_of::<T>()` e göre doğru şekilde hizalanıp hizalanmadığını kontrol eder.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `src` ten `dst` e `count *size_of::<T>()` bayt kopyalar.Kaynak ve hedef çakışmamalıdır*.
///
/// Çakışabilecek bellek bölgeleri için bunun yerine [`copy`] kullanın.
///
/// `copy_nonoverlapping` anlamsal olarak C'nin [`memcpy`] ine eşdeğerdir, ancak argüman sırası değiştirilir.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `src` `count * size_of::<T>()` bayt okumaları için [valid] olmalıdır.
///
/// * `dst` `count * size_of::<T>()` bayt yazmaları için [valid] olmalıdır.
///
/// * Hem `src` hem de `dst` düzgün şekilde hizalanmalıdır.
///
/// * `src` ile başlayan bellek bölgesi "count" boyutuyla *
///   boyutu: :<T>() `bayt, aynı boyutta `dst` te başlayan bellek bölgesi ile *örtüşmemelidir*.
///
/// [`read`] gibi, `copy_nonoverlapping`, `T` in [`Copy`] olup olmadığına bakılmaksızın, `T` in bitsel bir kopyasını oluşturur.
/// `T`, [`Copy`] değilse,*her iki* de kullanıldığında `*src` te başlayan bölgedeki değer ve `* dst` te başlayan bölge [violate memory safety][read-ownership] olabilir.
///
///
/// Etkili bir şekilde kopyalanan boyut (`count * size_of: :<T>()`) `0`, işaretçiler NULL olmamalı ve doğru şekilde hizalanmalıdır.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] i manuel olarak uygulayın:
///
/// ```
/// use std::ptr;
///
/// /// `src` in tüm öğelerini `dst` e taşır ve `src` i boş bırakır.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst` in tüm `src` i tutmaya yetecek kapasiteye sahip olduğundan emin olun.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Offset çağrısı her zaman güvenlidir çünkü `Vec` hiçbir zaman `isize::MAX` bayttan fazlasını ayırmaz.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // `src` i içeriğini düşürmeden kesin.
///         // Bunu önce panics'de bir şey olması durumunda problemleri önlemek için yapıyoruz.
///         src.set_len(0);
///
///         // İki bölge çakışamaz çünkü değiştirilebilir referanslar diğer adlara sahip değildir ve iki farklı vectors aynı belleğe sahip olamaz.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst` e artık `src` içeriğini tuttuğunu bildirin.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Bu kontrolleri yalnızca çalışma zamanında gerçekleştirin
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Kod oluşturucu etkisini daha küçük tutmak için panik yapmamak.
        abort();
    }*/

    // GÜVENLİK: `copy_nonoverlapping` için güvenlik sözleşmesi,
    // Arayan tarafından onaylandı.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `src` ten `dst` e `count * size_of::<T>()` bayt kopyalar.Kaynak ve hedef çakışabilir.
///
/// Kaynak ve hedef *hiçbir zaman* çakışmayacaksa, bunun yerine [`copy_nonoverlapping`] kullanılabilir.
///
/// `copy` anlamsal olarak C'nin [`memmove`] ine eşdeğerdir, ancak argüman sırası değiştirilir.
/// Kopyalama, baytlar `src` ten geçici bir diziye kopyalanmış ve ardından diziden `dst` e kopyalanmış gibi gerçekleşir.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `src` `count * size_of::<T>()` bayt okumaları için [valid] olmalıdır.
///
/// * `dst` `count * size_of::<T>()` bayt yazmaları için [valid] olmalıdır.
///
/// * Hem `src` hem de `dst` düzgün şekilde hizalanmalıdır.
///
/// [`read`] gibi, `copy`, `T` in [`Copy`] olup olmadığına bakılmaksızın, `T` in bitsel bir kopyasını oluşturur.
/// `T`, [`Copy`] değilse, hem bölgedeki `*src` te başlayan değerlerin hem de `* dst` te başlayan bölgenin kullanılması [violate memory safety][read-ownership] olabilir.
///
///
/// Etkili bir şekilde kopyalanan boyut (`count * size_of: :<T>()`) `0`, işaretçiler NULL olmamalı ve doğru şekilde hizalanmalıdır.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Güvenli olmayan bir arabellekten verimli bir şekilde Rust vector oluşturun:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` sıfır olmayan türüne göre doğru şekilde hizalanmalıdır.
/// /// * `ptr` `T` tipi `elts` bitişik öğelerinin okunması için geçerli olmalıdır.
/// /// * Bu elemanlar, `T: Copy` olmadıkça bu fonksiyon çağrıldıktan sonra kullanılmamalıdır.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // GÜVENLİK: Ön koşulumuz kaynağın uyumlu ve geçerli olmasını sağlar,
///     // ve `Vec::with_capacity` bunları yazmak için kullanılabilir alanımız olmasını sağlar.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // GÜVENLİK: Daha önce bu kadar kapasite ile yarattık,
///     // ve önceki `copy` bu öğeleri başlattı.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Bu kontrolleri yalnızca çalışma zamanında gerçekleştirin
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Kod oluşturucu etkisini daha küçük tutmak için panik yapmamak.
        abort();
    }*/

    // GÜVENLİK: `copy` için güvenlik sözleşmesi arayan tarafından onaylanmalıdır.
    unsafe { copy(src, dst, count) }
}

/// `dst` ten `val` e `count * size_of::<T>()` bayt bellek ayarlar.
///
/// `write_bytes` C'nin [`memset`] ine benzer, ancak `count * size_of::<T>()` baytını `val` e ayarlar.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `dst` `count * size_of::<T>()` bayt yazmaları için [valid] olmalıdır.
///
/// * `dst` uygun şekilde hizalanmalıdır.
///
/// Ek olarak, arayan kişi, belirli bellek bölgesine `count * size_of::<T>()` bayt yazmanın geçerli bir `T` değeri ile sonuçlandığından emin olmalıdır.
/// Geçersiz bir `T` değeri içeren bir `T` olarak yazılan bir bellek bölgesinin kullanılması tanımsız bir davranıştır.
///
/// Etkili bir şekilde kopyalanan boyut (`count * size_of: :<T>()`) `0`, işaretçi NULL olmamalı ve doğru şekilde hizalanmalıdır.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Geçersiz bir değer yaratmak:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // `Box<T>` in üzerine boş bir işaretçi yazarak önceden tutulan değeri sızdırır.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Bu noktada, `v` in kullanılması veya bırakılması, tanımsız davranışa neden olur.
/// // drop(v); // ERROR
///
/// // Hatta `v` "uses" sızdırıyor ve dolayısıyla tanımsız bir davranış.
/// // mem::forget(v); // ERROR
///
/// // Aslında, `v` temel tip düzen değişmezlerine göre geçersizdir, bu nedenle ona dokunan *herhangi* bir işlem tanımsız bir davranıştır.
/////
/// // v2 =v olsun;//HATA
///
/// unsafe {
///     // Bunun yerine geçerli bir değer koyalım
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Şimdi kutu iyi
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // GÜVENLİK: `write_bytes` için güvenlik sözleşmesi arayan tarafından onaylanmalıdır.
    unsafe { write_bytes(dst, val, count) }
}