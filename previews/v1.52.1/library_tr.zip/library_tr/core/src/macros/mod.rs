#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Arayanın sürümüne bağlı olarak `$crate::panic::panic_2015` veya `$crate::panic::panic_2021` e genişler.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// İki ifadenin birbirine eşit olduğunu iddia eder ([`PartialEq`] kullanarak).
///
/// panic üzerinde bu makro, ifadelerin değerlerini hata ayıklama temsilleriyle birlikte yazdıracaktır.
///
///
/// [`assert!`] gibi, bu makronun özel bir panic mesajının sağlanabildiği ikinci bir formu vardır.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Aşağıdaki reborrows kasıtlıdır.
                    // Bunlar olmadan, ödünç alma için yığın yuvası, değerler karşılaştırılmadan önce bile başlatılır ve bu da gözle görülür bir yavaşlamaya yol açar.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Aşağıdaki reborrows kasıtlıdır.
                    // Bunlar olmadan, ödünç alma için yığın yuvası, değerler karşılaştırılmadan önce bile başlatılır ve bu da gözle görülür bir yavaşlamaya yol açar.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// İki ifadenin birbirine eşit olmadığını iddia eder ([`PartialEq`] kullanarak).
///
/// panic üzerinde bu makro, ifadelerin değerlerini hata ayıklama temsilleriyle birlikte yazdıracaktır.
///
///
/// [`assert!`] gibi, bu makronun özel bir panic mesajının sağlanabildiği ikinci bir formu vardır.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Aşağıdaki reborrows kasıtlıdır.
                    // Bunlar olmadan, ödünç alma için yığın yuvası, değerler karşılaştırılmadan önce bile başlatılır ve bu da gözle görülür bir yavaşlamaya yol açar.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Aşağıdaki reborrows kasıtlıdır.
                    // Bunlar olmadan, ödünç alma için yığın yuvası, değerler karşılaştırılmadan önce bile başlatılır ve bu da gözle görülür bir yavaşlamaya yol açar.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Çalışma zamanında bir boole ifadesinin `true` olduğunu iddia eder.
///
/// Bu, sağlanan ifade çalışma zamanında `true` e değerlendirilemezse [`panic!`] makrosunu çağırır.
///
/// [`assert!`] gibi, bu makronun da özel bir panic mesajının sağlanabildiği ikinci bir sürümü vardır.
///
/// # Uses
///
/// [`assert!`] ten farklı olarak, `debug_assert!` deyimleri yalnızca optimize edilmemiş yapılarda varsayılan olarak etkinleştirilir.
/// Optimize edilmiş bir derleme, `-C debug-assertions` derleyiciye iletilmedikçe `debug_assert!` deyimlerini yürütmez.
/// Bu, `debug_assert!` i bir sürüm yapısında bulunamayacak kadar pahalı olan ancak geliştirme sırasında yardımcı olabilecek kontroller için kullanışlı hale getirir.
/// `debug_assert!` i genişletmenin sonucu her zaman tip kontrol edilir.
///
/// Denetlenmemiş bir iddia, tutarsız durumdaki bir programın çalışmaya devam etmesine izin verir; bu, beklenmedik sonuçlara neden olabilir, ancak bu yalnızca güvenli kodda olduğu sürece güvensizlik getirmez.
///
/// Ancak, iddiaların performans maliyeti genel olarak ölçülemez.
/// [`assert!`] in `debug_assert!` ile değiştirilmesi bu nedenle yalnızca kapsamlı profillemeden sonra ve daha da önemlisi yalnızca güvenli kodda teşvik edilir!
///
/// # Examples
///
/// ```
/// // bu iddialar için panic mesajı verilen ifadenin dizgeli değeridir.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // çok basit bir işlev
/// debug_assert!(some_expensive_computation());
///
/// // özel bir mesajla ileri sürmek
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// İki ifadenin birbirine eşit olduğunu iddia eder.
///
/// panic üzerinde bu makro, ifadelerin değerlerini hata ayıklama temsilleriyle birlikte yazdıracaktır.
///
/// [`assert_eq!`] ten farklı olarak, `debug_assert_eq!` deyimleri yalnızca optimize edilmemiş yapılarda varsayılan olarak etkinleştirilir.
/// Optimize edilmiş bir derleme, `-C debug-assertions` derleyiciye iletilmedikçe `debug_assert_eq!` deyimlerini yürütmez.
/// Bu, `debug_assert_eq!` i bir sürüm yapısında bulunamayacak kadar pahalı olan ancak geliştirme sırasında yardımcı olabilecek kontroller için kullanışlı hale getirir.
///
/// `debug_assert_eq!` i genişletmenin sonucu her zaman tip kontrol edilir.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// İki ifadenin birbirine eşit olmadığını iddia eder.
///
/// panic üzerinde bu makro, ifadelerin değerlerini hata ayıklama temsilleriyle birlikte yazdıracaktır.
///
/// [`assert_ne!`] ten farklı olarak, `debug_assert_ne!` deyimleri yalnızca optimize edilmemiş yapılarda varsayılan olarak etkinleştirilir.
/// Optimize edilmiş bir derleme, `-C debug-assertions` derleyiciye iletilmedikçe `debug_assert_ne!` deyimlerini yürütmez.
/// Bu, `debug_assert_ne!` i bir sürüm yapısında bulunamayacak kadar pahalı olan ancak geliştirme sırasında yardımcı olabilecek kontroller için kullanışlı hale getirir.
///
/// `debug_assert_ne!` i genişletmenin sonucu her zaman tip kontrol edilir.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Verilen ifadenin verilen kalıplardan herhangi biriyle eşleşip eşleşmediğini döndürür.
///
/// Bir `match` ifadesindeki gibi, desen isteğe bağlı olarak `if` ve desenle bağlanan adlara erişimi olan bir koruma ifadesi izleyebilir.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Bir sonucun paketini açar veya hatasını yayar.
///
/// `?` operatörü, `try!` in yerine eklenmiştir ve bunun yerine kullanılmalıdır.
/// Ayrıca, `try`, Rust 2018'de ayrılmış bir kelimedir, bu nedenle kullanmanız gerekiyorsa, [raw-identifier syntax][ris] i kullanmanız gerekecektir: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` verilen [`Result`] ile eşleşir.`Ok` varyantı durumunda ifade, sarılmış değerin değerine sahiptir.
///
/// `Err` varyantı durumunda, iç hatayı alır.`try!` daha sonra `From` kullanarak dönüştürme gerçekleştirir.
/// Bu, özel hatalar ve daha genel hatalar arasında otomatik dönüşüm sağlar.
/// Ortaya çıkan hata daha sonra hemen iade edilir.
///
/// Erken dönüş nedeniyle, `try!` yalnızca [`Result`] döndüren işlevlerde kullanılabilir.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Hataları geri döndürmek için tercih edilen yöntem
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Hızlı döndürme Hataları için önceki yöntem
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Bu şuna eşdeğerdir:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Biçimlendirilmiş verileri bir arabelleğe yazar.
///
/// Bu makro bir 'writer', bir biçim dizesi ve bir argüman listesi kabul eder.
/// Bağımsız değişkenler, belirtilen biçim dizesine göre biçimlendirilecek ve sonuç yazara iletilecektir.
/// Yazar, `write_fmt` yöntemiyle herhangi bir değer olabilir;genellikle bu, [`fmt::Write`] veya [`io::Write`] trait uygulamasından gelir.
/// Makro, `write_fmt` yöntemi ne döndürürse döndürür;genellikle bir [`fmt::Result`] veya bir [`io::Result`].
///
/// Biçim dizesi sözdizimi hakkında daha fazla bilgi için bkz. [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Bir modül, hem `std::fmt::Write` hem de `std::io::Write` i içe aktarabilir ve nesneler tipik olarak her ikisini birden uygulamadığından `write!` i her ikisini de uygulayan nesnelerde çağırabilir.
///
/// Ancak modül, isimlerinin çakışmaması için nitelikli traits'yi içe aktarmalıdır:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt kullanır
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt kullanır
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Bu makro, `no_std` kurulumlarında da kullanılabilir.
/// Bir `no_std` kurulumunda, bileşenlerin uygulama ayrıntılarından siz sorumlusunuz.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Biçimlendirilmiş verileri bir satırsonu eklenerek arabelleğe yazın.
///
/// Tüm platformlarda, satırsonu yalnızca LINE FEED karakteridir (`\n`/`U+000A`) (ek CARRIAGE RETURN (`\r`/`U+000D`) yoktur.
///
/// Daha fazla bilgi için bkz. [`write!`].Biçim dizesi sözdizimi hakkında bilgi için, bkz. [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Bir modül, hem `std::fmt::Write` hem de `std::io::Write` i içe aktarabilir ve nesneler tipik olarak her ikisini birden uygulamadığından `write!` i her ikisini de uygulayan nesnelerde çağırabilir.
/// Ancak modül, isimlerinin çakışmaması için nitelikli traits'yi içe aktarmalıdır:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt kullanır
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt kullanır
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Erişilemez kodu gösterir.
///
/// Bu, derleyicinin bazı kodların erişilemez olduğunu belirleyemediği her zaman kullanışlıdır.Örneğin:
///
/// * Kolları koruma koşullarıyla eşleştirin.
/// * Dinamik olarak sona eren döngüler.
/// * Dinamik olarak sona eren yineleyiciler.
///
/// Kodun erişilemez olduğunun tespitinin yanlış olduğu kanıtlanırsa, program bir [`panic!`] ile derhal sonlandırılır.
///
/// Bu makronun güvenli olmayan karşılığı [`unreachable_unchecked`] işlevidir ve koda ulaşılırsa tanımsız davranışa neden olur.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Bu her zaman [`panic!`] olacaktır.
///
/// # Examples
///
/// Maç kolları:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // yorumlanırsa derleme hatası
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 in en zayıf uygulamalarından biri
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Bir "not implemented" mesajı ile paniğe girerek uygulanmamış kodu gösterir.
///
/// Bu, kodunuzun tip kontrolü yapmasına izin verir; bu, hepsini kullanmayı planlamadığınız birden çok yöntemi gerektiren bir trait prototipini oluşturuyorsanız veya uyguluyorsanız yararlıdır.
///
/// `unimplemented!` ve [`todo!`] arasındaki fark, `todo!` işlevselliği daha sonra uygulama niyetini iletirken ve mesaj "not yet implemented" iken, `unimplemented!` böyle bir iddiada bulunmaz.
/// Mesajı "not implemented" tir.
/// Ayrıca bazı IDE'ler yapılacaklar olarak işaretleyecektir.
///
/// # Panics
///
/// Bu her zaman [`panic!`] olacaktır çünkü `unimplemented!`, sabit, özel bir mesajla `panic!` için sadece bir kısaltmadır.
///
/// `panic!` gibi, bu makronun özel değerleri görüntülemek için ikinci bir formu vardır.
///
/// # Examples
///
/// Bir trait `Foo` imiz olduğunu varsayalım:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// 'MyStruct' için `Foo` i uygulamak istiyoruz, ancak bazı nedenlerden dolayı yalnızca `bar()` işlevini uygulamak mantıklı.
/// `baz()` ve `qux()` in yine de `Foo` uygulamamızda tanımlanması gerekecek, ancak kodumuzun derlenmesine izin vermek için tanımlarında `unimplemented!` i kullanabiliriz.
///
/// Uygulanmayan yöntemlere ulaşılırsa programımızın çalışmasını yine de durdurmak istiyoruz.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` a `MyStruct` için bir anlam ifade etmiyor, bu yüzden burada hiçbir mantığımız yok.
/////
///         // Bu "thread 'main' panicked at 'not implemented'" i gösterecektir.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Burada biraz mantığımız var, uygulanmayanlara mesaj ekleyebiliriz!ihmalimizi göstermek için.
///         // Bu şunu gösterecektir: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Bitmemiş kodu gösterir.
///
/// Bu, prototip oluşturuyorsanız ve yalnızca kodunuzun tipini kontrol etmesini istiyorsanız yararlı olabilir.
///
/// [`unimplemented!`] ve `todo!` arasındaki fark, `todo!` işlevselliği daha sonra uygulama niyetini iletirken ve mesaj "not yet implemented" iken, `unimplemented!` böyle bir iddiada bulunmaz.
/// Mesajı "not implemented" tir.
/// Ayrıca bazı IDE'ler yapılacaklar olarak işaretleyecektir.
///
/// # Panics
///
/// Bu her zaman [`panic!`] olacaktır.
///
/// # Examples
///
/// İşte devam eden bazı kodlara bir örnek.Bir trait `Foo` imiz var:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// `Foo` i türlerimizden birine uygulamak istiyoruz, ancak önce sadece `bar()` üzerinde çalışmak istiyoruz.Kodumuzun derlenebilmesi için `baz()` i uygulamamız gerekir, böylece `todo!` i kullanabiliriz:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // uygulama buraya gider
///     }
///
///     fn baz(&self) {
///         // şimdilik baz() i uygulama konusunda endişelenmeyelim
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // baz() i bile kullanmıyoruz, bu yüzden bu sorun değil.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Yerleşik makroların tanımları.
///
/// Makro özelliklerin çoğu (kararlılık, görünürlük, vb.), Makro girdileri çıktılara dönüştüren genişletme işlevleri haricinde, buradaki kaynak kodundan alınır, bu işlevler derleyici tarafından sağlanır.
///
///
pub(crate) mod builtin {

    /// Karşılaşıldığında verilen hata mesajıyla derlemenin başarısız olmasına neden olur.
    ///
    /// Bu makro, bir crate hatalı koşullar için daha iyi hata mesajları sağlamak için koşullu bir derleme stratejisi kullandığında kullanılmalıdır.
    ///
    /// Bu, [`panic!`] in derleyici düzeyindeki biçimidir, ancak *çalışma zamanında* yerine *derleme* sırasında bir hata verir.
    ///
    /// # Examples
    ///
    /// Bu tür iki örnek, makrolar ve `#[cfg]` ortamlarıdır.
    ///
    /// Bir makroya geçersiz değerler iletilirse daha iyi derleyici hatası verir.
    /// Son branch olmadan, derleyici yine de bir hata verir, ancak hatanın mesajı iki geçerli değerden bahsetmez.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Bazı özelliklerden biri mevcut değilse derleyici hatası verir.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Diğer dize biçimlendirme makroları için parametreler oluşturur.
    ///
    /// Bu makro, geçirilen her ek bağımsız değişken için `{}` içeren bir biçimlendirme dizesi hazır bilgisi alarak çalışır.
    /// `format_args!` çıktının bir dizge olarak yorumlanabilmesini sağlamak için ek parametreleri hazırlar ve bağımsız değişkenleri tek bir tipte standartlaştırır.
    /// [`Display`] trait'yi uygulayan herhangi bir değer, herhangi bir [`Debug`] uygulaması biçimlendirme dizesi içindeki bir `{:?}` e geçirilebilir.
    ///
    ///
    /// Bu makro, [`fmt::Arguments`] türünde bir değer üretir.Bu değer, yararlı yeniden yönlendirme gerçekleştirmek için [`std::fmt`] içindeki makrolara geçirilebilir.
    /// Diğer tüm biçimlendirme makroları (["format!"], [`write!`], [`println!`], vb.) Bu makro üzerinden proxy'ye tabi tutulur.
    /// `format_args!`, türetilmiş makrolardan farklı olarak, yığın tahsislerinden kaçınır.
    ///
    /// `format_args!` in `Debug` ve `Display` bağlamlarında döndürdüğü [`fmt::Arguments`] değerini aşağıda görüldüğü gibi kullanabilirsiniz.
    /// Örnek ayrıca `Debug` ve `Display` formatlarının aynı şeyi gösterdiğini de gösterir: `format_args!` teki enterpolasyonlu format dizesi.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Daha fazla bilgi için [`std::fmt`] teki belgelere bakın.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` ile aynıdır, ancak sonuna bir yeni satır ekler.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Derleme zamanında bir ortam değişkenini inceler.
    ///
    /// Bu makro, derleme zamanında adlandırılan ortam değişkeninin değerine genişler ve `&'static str` tipi bir ifade verir.
    ///
    ///
    /// Ortam değişkeni tanımlanmamışsa, bir derleme hatası verilecektir.
    /// Derleme hatası vermemek için, bunun yerine [`option_env!`] makrosunu kullanın.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// İkinci parametre olarak bir dize ileterek hata mesajını özelleştirebilirsiniz:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// `documentation` ortam değişkeni tanımlanmamışsa, aşağıdaki hatayı alırsınız:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// İsteğe bağlı olarak, derleme zamanında bir ortam değişkenini inceler.
    ///
    /// Adlandırılmış ortam değişkeni derleme zamanında mevcutsa, bu, değeri ortam değişkeninin değerinin `Some` i olan `Option<&'static str>` türünde bir ifadeye genişleyecektir.
    /// Ortam değişkeni yoksa, bu `None` e genişleyecektir.
    /// Bu tür hakkında daha fazla bilgi için [`Option<T>`][Option] e bakın.
    ///
    /// Ortam değişkeninin mevcut olup olmadığına bakılmaksızın, bu makroyu kullanırken asla bir derleme zamanı hatası verilmez.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tanımlayıcıları tek bir tanımlayıcıda birleştirir.
    ///
    /// Bu makro, virgülle ayrılmış herhangi bir sayıda tanımlayıcıyı alır ve hepsini bir araya getirerek yeni bir tanımlayıcı olan bir ifade verir.
    /// Hijyenin, bu makronun yerel değişkenleri yakalayamayacağı şekilde olmasını sağladığını unutmayın.
    /// Ayrıca, genel bir kural olarak, makrolara yalnızca öğe, ifade veya ifade konumunda izin verilir.
    /// Bu, bu makroyu mevcut değişkenlere, işlevlere veya modüllere vb. Başvurmak için kullanabilirsiniz, ancak onunla yeni bir tane tanımlayamazsınız.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (yeni, eğlenceli, ad) { }//bu şekilde kullanılamaz!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Değişmez değerleri bir statik dize diliminde birleştirir.
    ///
    /// Bu makro, virgülle ayrılmış herhangi bir sayıda değişmez değeri alarak, soldan sağa birleştirilmiş tüm değişmez değerleri temsil eden `&'static str` türünde bir ifade verir.
    ///
    ///
    /// Tamsayı ve kayan noktalı değişmez değerler, birleştirilmek üzere dizilir.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Çağrıldığı satır numarasına genişler.
    ///
    /// [`column!`] ve [`file!`] ile bu makrolar, geliştiricilere kaynak içindeki konum hakkında hata ayıklama bilgileri sağlar.
    ///
    /// Genişletilmiş ifade `u32` türüne sahiptir ve 1 tabanlıdır, bu nedenle her dosyadaki ilk satır 1, ikincisi 2 vb. Olarak değerlendirilir.
    /// Bu, yaygın derleyiciler veya popüler editörlerin hata mesajlarıyla tutarlıdır.
    /// Döndürülen satır,*zorunlu olarak*`line!` çağrısının satırının kendisidir, daha ziyade `line!` makrosunun çağrılmasına yol açan ilk makro çağrısıdır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Çağrıldığı sütun numarasına genişler.
    ///
    /// [`line!`] ve [`file!`] ile bu makrolar, geliştiricilere kaynak içindeki konum hakkında hata ayıklama bilgileri sağlar.
    ///
    /// Genişletilmiş ifade `u32` türüne sahiptir ve 1 tabanlıdır, bu nedenle her satırdaki ilk sütun 1, ikincisi 2 vb. Olarak değerlendirilir.
    /// Bu, yaygın derleyiciler veya popüler editörlerin hata mesajlarıyla tutarlıdır.
    /// Döndürülen sütun,*zorunlu olarak*`column!` çağrısının satırının kendisidir, daha ziyade `column!` makrosunun çağrılmasına yol açan ilk makro çağrısıdır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Çağrıldığı dosya adına genişler.
    ///
    /// [`line!`] ve [`column!`] ile bu makrolar, geliştiricilere kaynak içindeki konum hakkında hata ayıklama bilgileri sağlar.
    ///
    /// Genişletilmiş ifade, `&'static str` tipine sahiptir ve döndürülen dosya, `file!` makrosunun kendisi değil, `file!` makrosunun başlatılmasına yol açan ilk makro çağrısıdır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Argümanlarını dizgiler.
    ///
    /// Bu makro, makroya geçirilen tüm tokens'nin dizgeleştirmesi olan `&'static str` türünde bir ifade verecektir.
    /// Makro çağrının sözdizimine hiçbir kısıtlama getirilmez.
    ///
    /// tokens girişinin genişletilmiş sonuçlarının future'de değişebileceğini unutmayın.Çıktıya güveniyorsanız dikkatli olmalısınız.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Dize olarak UTF-8 kodlanmış bir dosyayı içerir.
    ///
    /// Dosya, geçerli dosyaya göre bulunur (modüllerin nasıl bulunduğuna benzer şekilde).
    /// Sağlanan yol, derleme zamanında platforma özgü bir şekilde yorumlanır.
    /// Bu nedenle, örneğin, `\` ters eğik çizgi içeren bir Windows yoluna sahip bir çağrı, Unix te doğru şekilde derlenmeyecektir.
    ///
    ///
    /// Bu makro, dosyanın içeriği olan `&'static str` türünde bir ifade verecektir.
    ///
    /// # Examples
    ///
    /// Aynı dizinde aşağıdaki içeriğe sahip iki dosya olduğunu varsayalım:
    ///
    /// Dosya 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Dosya 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' i derlemek ve elde edilen ikili dosyayı çalıştırmak "adiós" i yazdıracaktır.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Bir bayt dizisine başvuru olarak bir dosya içerir.
    ///
    /// Dosya, geçerli dosyaya göre bulunur (modüllerin nasıl bulunduğuna benzer şekilde).
    /// Sağlanan yol, derleme zamanında platforma özgü bir şekilde yorumlanır.
    /// Bu nedenle, örneğin, `\` ters eğik çizgi içeren bir Windows yoluna sahip bir çağrı, Unix te doğru şekilde derlenmeyecektir.
    ///
    ///
    /// Bu makro, dosyanın içeriği olan `&'static [u8; N]` türünde bir ifade verecektir.
    ///
    /// # Examples
    ///
    /// Aynı dizinde aşağıdaki içeriğe sahip iki dosya olduğunu varsayalım:
    ///
    /// Dosya 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Dosya 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' i derlemek ve elde edilen ikili dosyayı çalıştırmak "adiós" i yazdıracaktır.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Geçerli modül yolunu temsil eden bir dizeye genişler.
    ///
    /// Mevcut modül yolu, crate root'ye geri dönen modüllerin hiyerarşisi olarak düşünülebilir.
    /// Döndürülen yolun ilk bileşeni, halihazırda derlenmekte olan crate'nin adıdır.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Derleme zamanında yapılandırma bayraklarının boole kombinasyonlarını değerlendirir.
    ///
    /// `#[cfg]` özniteliğine ek olarak, bu makro, yapılandırma bayraklarının mantıksal ifade değerlendirmesine izin vermek için sağlanmıştır.
    /// Bu genellikle daha az yinelenen koda yol açar.
    ///
    /// Bu makroya verilen sözdizimi, [`cfg`] özniteliğiyle aynı sözdizimidir.
    ///
    /// `cfg!`, `#[cfg]` in aksine, herhangi bir kodu kaldırmaz ve yalnızca doğru veya yanlış olarak değerlendirilir.
    /// Örneğin, `cfg!` in ne değerlendirdiğine bakılmaksızın, `cfg!` koşul için kullanıldığında if/else ifadesindeki tüm blokların geçerli olması gerekir.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Bir dosyayı bağlama göre bir ifade veya öğe olarak ayrıştırır.
    ///
    /// Dosya, geçerli dosyaya göre bulunur (modüllerin nasıl bulunduğuna benzer şekilde).Sağlanan yol, derleme zamanında platforma özgü bir şekilde yorumlanır.
    /// Bu nedenle, örneğin, `\` ters eğik çizgi içeren bir Windows yoluna sahip bir çağrı, Unix te doğru şekilde derlenmeyecektir.
    ///
    /// Bu makroyu kullanmak genellikle kötü bir fikirdir, çünkü dosya bir ifade olarak ayrıştırılırsa, çevre koda hijyenik olmayan bir şekilde yerleştirilecektir.
    /// Bu, geçerli dosyada aynı ada sahip değişkenler veya işlevler varsa, değişkenlerin veya işlevlerin dosyanın beklenenden farklı olmasına neden olabilir.
    ///
    ///
    /// # Examples
    ///
    /// Aynı dizinde aşağıdaki içeriğe sahip iki dosya olduğunu varsayalım:
    ///
    /// Dosya 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Dosya 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' i derlemek ve elde edilen ikili dosyayı çalıştırmak "🙈🙊🙉🙈🙊🙉" i yazdıracaktır.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Çalışma zamanında bir boole ifadesinin `true` olduğunu iddia eder.
    ///
    /// Bu, sağlanan ifade çalışma zamanında `true` e değerlendirilemezse [`panic!`] makrosunu çağırır.
    ///
    /// # Uses
    ///
    /// Onaylar her zaman hem hata ayıklama hem de yayın yapılarında kontrol edilir ve devre dışı bırakılamaz.
    /// Varsayılan olarak yayın yapılarında etkinleştirilmemiş olan onaylar için [`debug_assert!`] e bakın.
    ///
    /// Güvenli olmayan kod, ihlal edilmesi durumunda güvensizliğe yol açabilecek çalışma zamanı değişmezlerini zorlamak için `assert!` e güvenebilir.
    ///
    /// `assert!` in diğer kullanım durumları, çalışma zamanı değişmezlerinin güvenli kodda test edilmesini ve zorunlu kılınmasını içerir (ihlali güvensizlikle sonuçlanamaz).
    ///
    ///
    /// # Özel Mesajlar
    ///
    /// Bu makronun, özel bir panic mesajının biçimlendirme için bağımsız değişkenlerle veya bağımsız değişkenlerle sağlanabildiği ikinci bir formu vardır.
    /// Bu formun sözdizimi için [`std::fmt`] e bakın.
    /// Biçim bağımsız değişkeni olarak kullanılan ifadeler, yalnızca iddia başarısız olursa değerlendirilecektir.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // bu iddialar için panic mesajı verilen ifadenin dizgeli değeridir.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // çok basit bir işlev
    ///
    /// assert!(some_computation());
    ///
    /// // özel bir mesajla ileri sürmek
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Satır içi montaj.
    ///
    /// Kullanım için [unstable book] i okuyun.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM tarzı satır içi montaj.
    ///
    /// Kullanım için [unstable book] i okuyun.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Modül düzeyinde satır içi montaj.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Baskılar tokens'yi standart çıktıya geçirdi.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Diğer makrolarda hata ayıklamak için kullanılan izleme işlevini etkinleştirir veya devre dışı bırakır.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Makro türetmek için kullanılan öznitelik makrosu.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Bir işlevi birim testine dönüştürmek için bir işleve uygulanan öznitelik makrosu.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Bir karşılaştırma testine dönüştürmek için bir işleve uygulanan öznitelik makrosu.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` ve `#[bench]` makrolarının uygulama ayrıntısı.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Genel ayırıcı olarak kaydetmek için bir durağanlığa uygulanan öznitelik makrosu.
    ///
    /// Ayrıca bkz. [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Geçilen yol erişilebilirse uygulandığı öğeyi korur, aksi takdirde kaldırır.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Uygulandığı kod parçasındaki tüm `#[cfg]` ve `#[cfg_attr]` özelliklerini genişletir.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` derleyicisinin kararsız uygulama detaylarını kullanmayın.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` derleyicisinin kararsız uygulama detaylarını kullanmayın.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}