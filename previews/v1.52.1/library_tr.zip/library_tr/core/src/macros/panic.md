Panics mevcut iş parçacığı.

Bu, bir programın derhal sonlandırılmasına ve programı arayan kişiye geri bildirim sağlamasına olanak tanır.
`panic!` bir program kurtarılamaz bir duruma ulaştığında kullanılmalıdır.

Bu makro, örnek kodda ve testlerde koşulları ortaya koymanın mükemmel bir yoludur.
`panic!` hem [`Option`][ounwrap] hem de [`Result`][runwrap] numaralandırmalarının `unwrap` yöntemiyle yakından bağlantılıdır.
Her iki uygulama, [`None`] veya [`Err`] varyantlarına ayarlandıklarında `panic!` i çağırır.

`panic!()` kullanırken, [`format!`] sözdizimi kullanılarak oluşturulan bir dize yükü belirtebilirsiniz.
Bu yük, panic'yi çağıran Rust iş parçacığına enjekte ederken kullanılır ve iş parçacığı tamamen panic'ye neden olur.

Varsayılan `std` hook'nin davranışı, yani
panic çağrıldıktan hemen sonra çalışan kod, `panic!()` çağrısının file/line/column bilgisi ile birlikte mesaj yükünü `stderr` e yazdırmaktır.

[`std::panic::set_hook()`] kullanarak panic hook'yi geçersiz kılabilirsiniz.
hook içinde, normal `panic!()` çağrıları için bir `&str` veya `String` içeren bir panic'ye `&dyn Any + Send` olarak erişilebilir.
Başka türden bir değere sahip panic için [`panic_any`] kullanılabilir.

[`Result`] enum, hatalardan kurtulmak için `panic!` makrosunu kullanmaktan daha iyi bir çözümdür.
Bu makro, harici kaynaklar gibi yanlış değerler kullanarak ilerlemekten kaçınmak için kullanılmalıdır.
Hata işlemeyle ilgili ayrıntılı bilgiler [book] te bulunur.

Derleme sırasında hataları artırmak için makro [`compile_error!`] e de bakın.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Mevcut uygulama

Ana iş parçacığı panics ise, tüm iş parçacıklarınızı sonlandıracak ve programınızı `101` koduyla sonlandıracaktır.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





