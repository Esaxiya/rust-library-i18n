//! İlkel traits ve türlerin temel özelliklerini temsil eden türler.
//!
//! Rust tipleri, iç özelliklerine göre çeşitli faydalı şekillerde sınıflandırılabilir.
//! Bu sınıflandırmalar traits olarak temsil edilir.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// İş parçacığı sınırları boyunca aktarılabilen türler.
///
/// Bu trait, derleyici uygun olduğunu belirlediğinde otomatik olarak uygulanır.
///
/// "Gönderilmeyen" türlere bir örnek, referans sayma işaretçisi [`rc::Rc`][`Rc`] tir.
/// İki iş parçacığı aynı referans sayılan değere işaret eden ["Rc" leri klonlamaya çalışırsa, referans sayısını aynı anda güncellemeye çalışabilirler, bu [undefined behavior][ub] tir çünkü [`Rc`] atomik işlemleri kullanmaz.
///
/// Kuzeni [`sync::Arc`][arc] atomik işlemler kullanıyor (bazı ek yüklere maruz kalıyor) ve dolayısıyla `Send`.
///
/// Daha fazla ayrıntı için [the Nomicon](../../nomicon/send-and-sync.html) e bakın.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Derleme zamanında bilinen sabit boyuta sahip türler.
///
/// Tüm tür parametrelerinin üstü kapalı bir `Sized` sınırı vardır.Özel sözdizimi `?Sized`, uygun değilse bu bağı kaldırmak için kullanılabilir.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//hata: Boyut [i32] için uygulanmaz
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Tek istisna, bir trait'nin örtük `Self` tipidir.
/// Bir trait'nin örtük bir `Sized` bağı yoktur, çünkü bu, tanım gereği trait'nin tüm olası uygulayıcılarla çalışması gerektiği ve bu nedenle herhangi bir boyutta olabileceği [trait nesnesi] ile uyumsuzdur.
///
///
/// Rust, `Sized` i bir trait'ye bağlamanıza izin verse de, daha sonra onu bir trait nesnesi oluşturmak için kullanamayacaksınız:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // let y: &dyn Çubuk= &Impl;//hata: trait `Bar` bir nesneye dönüştürülemez
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // Varsayılan için, örneğin, `[T]: !Default` in değerlendirilebilir olmasını gerektirir
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// "unsized" ten dinamik boyutlu bir türe dönüştürülebilen türler.
///
/// Örneğin, boyutlandırılmış dizi türü `[i8; 2]`, `Unsize<[i8]>` ve `Unsize<dyn fmt::Debug>` i uygular.
///
/// `Unsize` in tüm uygulamaları derleyici tarafından otomatik olarak sağlanır.
///
/// `Unsize` şunun için uygulanır:
///
/// - `[T; N]` `Unsize<[T]>`
/// - `T` `T: Trait` olduğunda `Unsize<dyn Trait>`
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>`, eğer:
///   - `T: Unsize<U>`
///   - Foo bir yapıdır
///   - Yalnızca `Foo` in son alanı `T` i içeren bir türe sahiptir
///   - `T` diğer alanların türünün bir parçası değil
///   - `Bar<T>: Unsize<Bar<U>>`, `Foo` in son alanı `Bar<T>` tipine sahipse
///
/// `Unsize` [`Rc`] gibi "user-defined" konteynerlerinin dinamik boyutlu tipler içermesine izin vermek için [`ops::CoerceUnsized`] ile birlikte kullanılır.
/// Daha fazla ayrıntı için [DST coercion RFC][RFC982] ve [the nomicon entry on coercion][nomicon-coerce] e bakın.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Örüntü eşleşmelerinde kullanılan sabitler için gerekli trait.
///
/// `PartialEq` i türeten herhangi bir tür, tür parametrelerinin `Eq` i uygulayıp uygulamadığına bakılmaksızın * bu trait'yi otomatik olarak uygular.
///
/// Bir `const` öğesi, bu trait'yi uygulamayan bir tür içeriyorsa, bu tür (1.), `PartialEq` i uygulamaz (bu, sabitin, bu karşılaştırma yöntemini sağlamayacağı anlamına gelir, kod üretmenin mevcut olduğunu varsayar) veya (2.),*kendi uygular** `PartialEq` sürümü (yapısal eşitlik karşılaştırmasına uymadığını varsayıyoruz).
///
///
/// Yukarıdaki iki senaryodan birinde, bir model eşleşmesinde böyle bir sabitin kullanılmasını reddediyoruz.
///
/// Öznitelik tabanlı tasarımdan bu trait'ye geçişi motive eden [structural match RFC][RFC1445] ve [issue 63438] e de bakın.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Örüntü eşleşmelerinde kullanılan sabitler için gerekli trait.
///
/// `Eq` i türeten herhangi bir tür, tür parametrelerinin `Eq` i uygulayıp uygulamadığına bakılmaksızın * bu trait'yi otomatik olarak uygular.
///
/// Bu, tür sistemimizdeki bir sınırlamayı aşmak için yapılan bir hack'tir.
///
/// # Background
///
/// Kalıp eşleşmelerinde kullanılan sabit türlerinin `#[derive(PartialEq, Eq)]` özniteliğine sahip olmasını zorunlu kılmak istiyoruz.
///
/// Daha ideal bir dünyada, söz konusu türün hem `StructuralPartialEq` trait *hem de*`Eq` trait'yi uygulayıp uygulamadığını kontrol ederek bu gereksinimi kontrol edebiliriz.
/// Ancak, `derive(PartialEq, Eq)`*yapan* ADT'lere sahip olabilirsiniz ve derleyicinin kabul etmesini istediğimiz bir durum olabilir, ancak sabitin türü `Eq` i uygulamada başarısız olur.
///
/// Yani şöyle bir durum:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Yukarıdaki koddaki sorun, `Wrap<fn(&())>` in `PartialEq` veya `Eq` i uygulamamasıdır, çünkü "<'a> fn(&'a _)` does not implement those traits.) için
///
/// Bu nedenle, `StructuralPartialEq` ve yalnızca `Eq` için saf kontrollere güvenemeyiz.
///
/// Bunu aşmak için bir hack olarak, (`#[derive(PartialEq)]` ve `#[derive(Eq)]`) türevlerinin her biri tarafından enjekte edilen iki ayrı traits kullanıyoruz ve yapısal eşleşme kontrolünün bir parçası olarak ikisinin de mevcut olup olmadığını kontrol ediyoruz.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Değerleri sadece bitleri kopyalayarak çoğaltılabilen tipler.
///
/// Varsayılan olarak, değişken bağlamaların 'taşıma semantiği' vardır.Diğer bir deyişle:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` e taşındı ve bu nedenle kullanılamaz
///
/// // println! ("{: ?}", x);//hata: taşınan değer kullanımı
/// ```
///
/// Bununla birlikte, bir tür `Copy` i uygularsa, bunun yerine 'kopyalama anlambilimine' sahiptir:
///
/// ```
/// // Bir `Copy` uygulaması türetebiliriz.
/// // `Clone` `Copy` in bir süper özelliği olduğu için de gereklidir.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` in bir kopyasıdır
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Bu iki örnekteki tek farkın, atamadan sonra `x` e erişiminizin olup olmadığıdır.
/// Kaputun altında, hem bir kopya hem de bir hareket, bitlerin bellekte kopyalanmasına neden olabilir, ancak bu bazen optimize edilememektedir.
///
/// ## `Copy` i nasıl uygulayabilirim?
///
/// Türünüzde `Copy` i uygulamanın iki yolu vardır.En basit olanı `derive` kullanmaktır:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// `Copy` ve `Clone` i manuel olarak da uygulayabilirsiniz:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// İkisi arasında küçük bir fark var: `derive` stratejisi, her zaman istenmeyen tür parametrelerine de bir `Copy` bağlayacaktır.
///
/// ## `Copy` ve `Clone` arasındaki fark nedir?
///
/// Kopyalar örtük olarak, örneğin bir `y = x` atamasının parçası olarak gerçekleşir.`Copy` in davranışı aşırı yüklenemez;her zaman basit, bit bazında bir kopyadır.
///
/// Klonlama açık bir eylemdir, `x.clone()`.[`Clone`] in uygulanması, değerleri güvenli bir şekilde kopyalamak için gereken tipe özgü herhangi bir davranışı sağlayabilir.
/// Örneğin, [`String`] için [`Clone`] uygulamasının, öbek içindeki işaretli dizge arabelleğini kopyalaması gerekir.
/// [`String`] değerlerinin basit bir bitsel kopyası, yalnızca işaretçiyi kopyalayarak satırın aşağısında iki kat boşluğa yol açar.
/// Bu nedenle, [`String`], [`Clone`] dir, ancak `Copy` değildir.
///
/// [`Clone`] `Copy` in bir süper niteliğidir, bu nedenle `Copy` olan her şey [`Clone`] i de uygulamalıdır.
/// Bir tür `Copy` ise, [`Clone`] uygulamasının yalnızca `*self` i döndürmesi gerekir (yukarıdaki örneğe bakın).
///
/// ## Tipim ne zaman `Copy` olabilir?
///
/// Bir tür, tüm bileşenleri `Copy` i uygularsa `Copy` i uygulayabilir.Örneğin, bu yapı `Copy` olabilir:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Bir yapı `Copy` olabilir ve [`i32`] `Copy` olabilir, bu nedenle `Point`, `Copy` olmaya uygundur.
/// Aksine, düşünün
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` yapısı `Copy` i uygulayamaz çünkü [`Vec<T>`], `Copy` değildir.Bir `Copy` uygulaması türetmeye çalışırsak, bir hata alırız:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Paylaşılan referanslar (`&T`) de `Copy` tir, bu nedenle bir tür, `Copy`*olmayan*`T` türlerinin paylaşılan referanslarını barındırsa bile `Copy` olabilir.
/// `Copy` i uygulayabilen aşağıdaki yapıyı göz önünde bulundurun, çünkü yukarıdan `Kopya olmayan tip `PointList` imize yalnızca *paylaşılan bir referans* tutuyor:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Benim türüm ne zaman `Copy`*olamaz*?
///
/// Bazı türler güvenli bir şekilde kopyalanamaz.Örneğin, `&mut T` in kopyalanması, takma adı verilen değiştirilebilir bir referans oluşturacaktır.
/// [`String`] in kopyalanması, [`String`] 'in arabelleğini yönetme sorumluluğunu iki katına çıkararak iki kat boşluğa yol açar.
///
/// İkinci durumu genellemek gerekirse, [`Drop`] i uygulayan herhangi bir tür `Copy` olamaz, çünkü kendi [`size_of::<T>`] baytlarının yanı sıra bazı kaynakları da yönetir.
///
/// `Copy` i "Kopyalama" olmayan verileri içeren bir yapı veya enum üzerinde uygulamaya çalışırsanız, [E0204] hatası alırsınız.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Türüm ne zaman `Copy` olmalı *?
///
/// Genel olarak, _can_ türünüz `Copy` i uyguluyorsa, bunu yapmalıdır.
/// Bununla birlikte, `Copy` in uygulanmasının, türünüzün genel API'sinin bir parçası olduğunu unutmayın.
/// Tür, future'de "Kopya olmayan" hale gelebilirse, API değişikliğini bozmamak için `Copy` uygulamasını şimdi atlamak akıllıca olabilir.
///
/// ## Ek uygulayıcılar
///
/// [implementors listed below][impls] e ek olarak, aşağıdaki tipler de `Copy` i uygular:
///
/// * İşlev öğesi türleri (yani, her işlev için tanımlanan farklı türler)
/// * İşlev işaretçi türleri (ör. `fn() -> i32`)
/// * Öğe türü `Copy` i de uyguluyorsa, tüm boyutlar için dizi türleri (ör. `[i32; 123456]`)
/// * Tuple türleri, eğer her bileşen `Copy` i de uyguluyorsa (örneğin, `()`, `(i32, bool)`)
/// * Kapatma türleri, çevreden hiçbir değer yakalamıyorlarsa veya bu tür yakalanan değerlerin tümü `Copy` i kendileri uyguluyorsa.
///   Paylaşılan referans tarafından yakalanan değişkenlerin her zaman `Copy` i uyguladığını (referans olmasa bile), değişken referans tarafından yakalanan değişkenlerin hiçbir zaman `Copy` i uygulamadığını unutmayın.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Bu, tatmin edilmeyen yaşam süresi sınırları nedeniyle `Copy` i uygulamayan bir türün kopyalanmasına izin verir (yalnızca `A<'static>: Copy` ve `A<'_>: Clone` olduğunda `A<'_>` in kopyalanması).
// Bu özelliğe şimdilik burada sahibiz çünkü `Copy` te zaten standart kitaplıkta zaten var olan pek çok uzmanlık var ve şu anda bu davranışı güvenli bir şekilde elde etmenin bir yolu yok.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` in bir impl'ını oluşturan makro türetin.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// İş parçacıkları arasında başvuru paylaşmanın güvenli olduğu türler.
///
/// Bu trait, derleyici uygun olduğunu belirlediğinde otomatik olarak uygulanır.
///
/// Kesin tanım şudur: bir `T` tipi, ancak ve ancak `&T` [`Send`] ise [`Sync`] dir.
/// Başka bir deyişle, `&T` referanslarını iş parçacıkları arasında geçirirken [undefined behavior][ub] (veri yarışları dahil) olasılığı yoksa.
///
/// Beklendiği gibi, [`u8`] ve [`f64`] gibi ilkel türlerin tümü [`Sync`] tir ve bu nedenle, bunları içeren tuples, structs ve enumlar gibi basit toplama türleridir.
/// Temel [`Sync`] türlerinin daha fazla örneği, `&T` gibi "immutable" türlerini ve [`Box<T>`][box], [`Vec<T>`][vec] ve diğer koleksiyon türlerinin çoğu gibi basit miras alınan değişkenliğe sahip olanları içerir.
///
/// (Kapsayıcılarının ["Sync"] olması için genel parametrelerin [`Sync`] olması gerekir.)
///
/// Tanımın biraz şaşırtıcı bir sonucu, `&mut T` in `Sync` olmasıdır (`T`, `Sync` ise), bu, senkronize edilmemiş mutasyon sağlayabilir gibi görünse de.
/// İşin püf noktası, paylaşılan bir referansın (yani, `& &mut T`) arkasındaki değiştirilebilir bir referansın, bir `& &T` gibi salt okunur hale gelmesidir.
/// Dolayısıyla bir veri yarışı riski yoktur.
///
/// `Sync` olmayan türler, [`Cell`][cell] ve [`RefCell`][refcell] gibi iş parçacığı güvenli olmayan bir biçimde "interior mutability" e sahip olanlardır.
/// Bu türler, değişmez, paylaşılan bir referans aracılığıyla bile içeriklerinin mutasyona uğramasına izin verir.
/// Örneğin, [`Cell<T>`][cell] teki `set` yöntemi `&self` i alır, bu nedenle yalnızca paylaşılan bir referans [`&Cell<T>`][cell] gerektirir.
/// Yöntem senkronizasyon yapmaz, bu nedenle [`Cell`][cell] `Sync` olamaz.
///
/// "Eşitleme" olmayan bir türün başka bir örneği, referans sayma işaretçisi [`Rc`][rc] tir.
/// Herhangi bir referans [`&Rc<T>`][rc] verildiğinde, referans sayılarını atomik olmayan bir şekilde değiştirerek yeni bir [`Rc<T>`][rc] klonlayabilirsiniz.
///
/// Rust, iş parçacığı emniyetli dahili değişkenliğe ihtiyaç duyulan durumlarda, [atomic data types] in yanı sıra [`sync::Mutex`][mutex] ve [`sync::RwLock`][rwlock] aracılığıyla açık kilitleme sağlar.
/// Bu türler, herhangi bir mutasyonun veri yarışlarına neden olmamasını sağlar, bu nedenle türler `Sync` tir.
/// Aynı şekilde, [`sync::Arc`][arc], [`Rc`][rc] in iş parçacığı emniyetli bir analogunu sağlar.
///
/// Dahili değişkenlik özelliğine sahip her tür, paylaşılan bir referansla mutasyona uğratılabilen value(s) etrafındaki [`cell::UnsafeCell`][unsafecell] sarıcıyı da kullanmalıdır.
/// Bunu yapmamak [undefined behavior][ub] tir.
/// Örneğin, `&T` ten `&mut T` e [`transmute`][transmute]-ing geçersizdir.
///
/// `Sync` hakkında daha fazla ayrıntı için bkz. [the Nomicon][nomicon-send-and-sync].
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): Beta sürümünde `rustc_on_unimplemented` alanlarına not ekleme desteği ve gereksinim zincirinin herhangi bir yerinde bir kapanış olup olmadığını kontrol etmek için genişletildiğinde, bunu şu şekilde genişletin: (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Sıfır boyutlu tip, "act like" in bir `T` e sahip olduğu şeyleri işaretlemek için kullanılır.
///
/// Türünüze bir `PhantomData<T>` alanı eklemek, derleyiciye türünüzün gerçekten olmasa da `T` türünde bir değer depoluyormuş gibi davrandığını söyler.
/// Bu bilgi, belirli güvenlik özelliklerini hesaplarken kullanılır.
///
/// `PhantomData<T>` in nasıl kullanılacağına dair daha ayrıntılı bir açıklama için lütfen [the Nomicon](../../nomicon/phantom-data.html) e bakın.
///
/// # Korkunç bir not 👻
///
/// Her ikisinin de korkunç isimleri olsa da, `PhantomData` ve 'hayalet türleri' birbiriyle ilişkilidir, ancak aynı değildir.Bir hayali tip parametresi, asla kullanılmayan bir tür parametresidir.
/// Rust'de bu genellikle derleyicinin şikayet etmesine neden olur ve çözüm, `PhantomData` yoluyla bir "dummy" kullanımı eklemektir.
///
/// # Examples
///
/// ## Kullanılmayan ömür parametreleri
///
/// Belki de `PhantomData` için en yaygın kullanım durumu, tipik olarak bazı güvenli olmayan kodların bir parçası olarak, kullanılmayan bir ömür süresi parametresine sahip bir yapıdır.
/// Örneğin, burada `*const T` tipinde iki işaretleyiciye sahip bir yapı `Slice` var, muhtemelen bir yerlerde bir diziye işaret ediyor:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Amaç, temel verilerin yalnızca `'a` ömrü için geçerli olmasıdır, bu nedenle `Slice`, `'a` ten daha uzun yaşamamalıdır.
/// Bununla birlikte, bu niyet kodda ifade edilmemiştir, çünkü `'a` ömrünün hiçbir kullanımı yoktur ve bu nedenle hangi verilere uygulandığı açık değildir.
/// Bunu, derleyiciye *`Slice` yapısı bir referans `&'a T` içeriyormuş* gibi davranmasını söyleyerek düzeltebiliriz:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Bu da `T` teki herhangi bir referansın `'a` ömrü boyunca geçerli olduğunu belirten `T: 'a` notunu gerektirir.
///
/// Bir `Slice` i başlatırken, `phantom` alanı için `PhantomData` değerini girmeniz yeterlidir:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Kullanılmayan tip parametreleri
///
/// Bazen, veri aslında yapının kendisinde bulunmasa bile, bir yapının "tied" için ne tür veri olduğunu belirten kullanılmamış tür parametreleriniz olur.
/// İşte bunun [FFI] ile ortaya çıktığı bir örnek.
/// Yabancı arabirim, farklı türlerdeki Rust değerlerine başvurmak için `*mut ()` türü tutamaçları kullanır.
/// Rust tipini, `ExternalResource` yapısında bir tutamacı saran bir hayali tip parametresi kullanarak izliyoruz.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Sahiplik ve iptal kontrolü
///
/// `PhantomData<T>` tipi bir alan eklemek, türünüzün `T` tipi verilere sahip olduğunu gösterir.Bu da, türünüz bırakıldığında, `T` türünün bir veya daha fazla örneğinin düşebileceği anlamına gelir.
/// Bu, Rust derleyicisinin [drop check] analizine bağlıdır.
///
/// Yapınız aslında `T` türündeki verilere *sahip değilse*, sahipliği belirtmemek için `PhantomData<&'a T>` (ideally) veya `PhantomData<*const T>` gibi bir referans türü (yaşam süresi geçerli değilse) kullanmak daha iyidir.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Enum ayırt edici türlerini belirtmek için kullanılan derleyici dahili trait.
///
/// Bu trait, her tür için otomatik olarak uygulanır ve [`mem::Discriminant`] e herhangi bir garanti eklemez.
/// `DiscriminantKind::Discriminant` ve `mem::Discriminant` arasında dönüşüm **tanımlanmamış bir davranış**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// `mem::Discriminant` in gerektirdiği trait bounds'yi karşılaması gereken ayırıcı türü.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Derleyici dahili trait, bir türün dahili olarak herhangi bir `UnsafeCell` içerip içermediğini, ancak dolaylı olarak değil, belirlemek için kullanılır.
///
/// Bu, örneğin, bu türden bir `static` in salt okunur statik belleğe mi yoksa yazılabilir statik belleğe mi yerleştirileceğini etkiler.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Sabitlendikten sonra güvenle taşınabilen türler.
///
/// Rust'nin kendisinde taşınmaz türler kavramı yoktur ve hareketlerin (örneğin, atama veya [`mem::replace`] yoluyla) her zaman güvenli olduğunu düşünür.
///
/// Bunun yerine, [`Pin`][Pin] türü, tür sistemindeki hareketleri önlemek için kullanılır.[`Pin<P<T>>`][Pin] paketleyicisine sarılmış işaretçiler `P<T>`, dışarı çıkarılamaz.
/// Sabitleme hakkında daha fazla bilgi için [`pin` module] belgelerine bakın.
///
/// `T` için `Unpin` trait'nin uygulanması, türü sabitleme kısıtlamalarını kaldırır, bu da `T` in [`mem::replace`] gibi işlevlerle [`Pin<P<T>>`][Pin] ten çıkarılmasına izin verir.
///
///
/// `Unpin` sabitlenmemiş veriler için hiçbir sonucu yoktur.
/// Özellikle, [`mem::replace`], `!Unpin` verilerini mutlu bir şekilde taşır (yalnızca `T: Unpin` te değil, herhangi bir `&mut T` için çalışır).
/// Ancak, [`mem::replace`] i bir [`Pin<P<T>>`][Pin] içine sarılmış verilerde kullanamazsınız çünkü bunun için ihtiyacınız olan `&mut T` i alamazsınız ve *bu* bu sistemin çalışmasını sağlayan şeydir.
///
/// Dolayısıyla bu, örneğin, yalnızca `Unpin` i uygulayan türlerde yapılabilir:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` i aramak için değiştirilebilir bir referansa ihtiyacımız var.
/// // (implicitly), `Pin::deref_mut` i çağırarak böyle bir referans elde edebiliriz, ancak bu yalnızca `String`, `Unpin` i uyguladığı için mümkündür.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Bu trait hemen hemen her tür için otomatik olarak uygulanır.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` i uygulamayan bir işaret tipi.
///
/// Bir tür `PhantomPinned` içeriyorsa, varsayılan olarak `Unpin` uygulamayacaktır.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// İlkel tipler için `Copy` uygulamaları.
///
/// Rust'de açıklanamayan uygulamalar `rustc_trait_selection` te `traits::SelectionContext::copy_clone_conditions()` te uygulanmaktadır.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Paylaşılan referanslar kopyalanabilir, ancak değiştirilebilir referanslar *olamaz*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}