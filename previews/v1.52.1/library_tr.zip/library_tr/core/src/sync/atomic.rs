//! Atom türleri
//!
//! Atomik türler, iş parçacıkları arasında ilkel paylaşılan bellek iletişimi sağlar ve diğer eşzamanlı türlerin yapı taşlarıdır.
//!
//! Bu modül, [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] vb. Dahil olmak üzere belirli sayıda ilkel türün atomik sürümlerini tanımlar.
//! Atomik türler, doğru kullanıldığında, iş parçacıkları arasında güncellemeleri senkronize eden işlemler sunar.
//!
//! Her yöntem, o işlem için bellek engelinin gücünü temsil eden bir [`Ordering`] alır.Bu sıralamalar [C++20 atomic orderings][1] ile aynıdır.Daha fazla bilgi için [nomicon][2] e bakın.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomik değişkenler iş parçacıkları arasında paylaşmak için güvenlidir ([`Sync`] i uygularlar) ancak kendileri Rust'nin [threading model](../../../std/thread/index.html#the-threading-model) i paylaşmak ve izlemek için bir mekanizma sağlamazlar.
//!
//! Bir atomik değişkeni paylaşmanın en yaygın yolu, onu bir [`Arc`][arc] e (atom olarak referansla sayılan paylaşılan bir işaretçi) yerleştirmektir.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomik tipler, [`AtomicBool::new`] gibi sabit başlatıcılar kullanılarak başlatılan statik değişkenlerde depolanabilir.Atomik statik genellikle tembel küresel başlatma için kullanılır.
//!
//! # Portability
//!
//! Bu modüldeki tüm atomik türler, mevcutsa [lock-free] garantilidir.Bu, dahili olarak küresel bir muteks edinmedikleri anlamına gelir.Atom türlerinin ve işlemlerinin beklemesiz olacağı garanti edilmez.
//! Bu, `fetch_or` gibi işlemlerin bir karşılaştırma ve takas döngüsü ile uygulanabileceği anlamına gelir.
//!
//! Atomik işlemler, daha büyük boyutlu atomlarla komut katmanında uygulanabilir.Örneğin, bazı platformlar `AtomicI8` i uygulamak için 4 baytlık atomik talimatlar kullanır.
//! Bu öykünmenin kodun doğruluğu üzerinde bir etkisi olmaması gerektiğini unutmayın, bu sadece farkında olunması gereken bir şeydir.
//!
//! Bu modüldeki atom türleri tüm platformlarda bulunmayabilir.Bununla birlikte, buradaki atomik türlerin tümü yaygın olarak mevcuttur ve genellikle varoluşa güvenilebilir.Bazı önemli istisnalar şunlardır:
//!
//! * PowerPC ve 32 bit işaretçiler içeren MIPS platformlarının `AtomicU64` veya `AtomicI64` türleri yoktur.
//! * ARM Linux için olmayan `armv5te` gibi platformlar yalnızca `load` ve `store` işlemlerini sağlar ve `swap`, `fetch_add` gibi (CAS) Karşılaştırma ve Takas işlemlerini desteklemez.
//! Ek olarak Linux te, bu CAS işlemleri [operating system support] aracılığıyla gerçekleştirilir ve bu da bir performans cezası ile gelebilir.
//! * ARM `thumbv6m` li hedefler yalnızca `load` ve `store` işlemlerini sağlar ve `swap`, `fetch_add` vb. Gibi (CAS) Karşılaştırma ve Takas işlemlerini desteklemez.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Bazı atomik işlemler için desteği olmayan future platformlarının da eklenebileceğini unutmayın.Maksimum taşınabilir kod, hangi atom türlerinin kullanıldığına dikkat etmek isteyecektir.
//! `AtomicUsize` ve `AtomicIsize` genellikle en taşınabilir olanıdır, ancak o zaman bile her yerde bulunmazlar.
//! Başvuru için, `std` kitaplığı işaretçi boyutlu atomlar gerektirir, ancak `core` bunu yapmaz.
//!
//! Şu anda, atomik ile kodda koşullu olarak derlemek için `#[cfg(target_arch)]` i kullanmanız gerekecek.future'de stabilize edilebilen kararsız bir `#[cfg(target_has_atomic)]` de var.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Basit bir spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Diğer ipliğin kilidi açmasını bekleyin
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Global bir dizi canlı ileti dizisi bulundurun:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// İş parçacıkları arasında güvenle paylaşılabilen bir boole türü.
///
/// Bu tür, bir [`bool`] ile aynı bellek içi temsiline sahiptir.
///
/// **Not**: Bu tür yalnızca `u8` in atomik yüklerini ve depolarını destekleyen platformlarda mevcuttur.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` e başlatılmış bir `AtomicBool` oluşturur.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Gönderme, AtomicBool için örtük olarak uygulanır.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// İş parçacıkları arasında güvenle paylaşılabilen ham bir işaretçi türü.
///
/// Bu tür, bir `*mut T` ile aynı bellek içi temsiline sahiptir.
///
/// **Not**: Bu tür yalnızca atomik yükleri ve işaretçi depolarını destekleyen platformlarda kullanılabilir.
/// Boyutu, hedef işaretçinin boyutuna bağlıdır.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Boş bir `AtomicPtr<T>` oluşturur.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomik hafıza sıralaması
///
/// Bellek sıralamaları, atomik işlemlerin belleği senkronize etme şeklini belirtir.
/// En zayıf [`Ordering::Relaxed`] inde, yalnızca işlemin doğrudan dokunduğu bellek senkronize edilir.
/// Öte yandan, bir depo-yük [`Ordering::SeqCst`] işlemi çifti diğer belleği senkronize ederken, ek olarak tüm iş parçacıkları genelinde bu tür işlemlerin toplam sırasını korur.
///
///
/// Rust'nin bellek sıralamaları [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) tir.
///
/// Daha fazla bilgi için [nomicon] e bakın.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Sıralama kısıtlaması yok, sadece atomik işlemler.
    ///
    /// C ++ 20'de [`memory_order_relaxed`] e karşılık gelir.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Bir mağaza ile birleştirildiğinde, önceki tüm işlemler [`Acquire`] (veya daha güçlü) sipariş ile bu değerin herhangi bir yüklemesinden önce sipariş edilir.
    ///
    /// Özellikle, önceki tüm yazma işlemleri, bu değerin [`Acquire`] (veya daha güçlü) yükünü gerçekleştiren tüm iş parçacıkları tarafından görülebilir hale gelir.
    ///
    /// Yükleri ve depoları birleştiren bir işlem için bu sıralamayı kullanmanın bir [`Relaxed`] yükleme işlemine yol açtığına dikkat edin!
    ///
    /// Bu sıralama yalnızca bir mağaza gerçekleştirebilen işlemler için geçerlidir.
    ///
    /// C ++ 20'de [`memory_order_release`] e karşılık gelir.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Bir yük ile birleştirildiğinde, yüklenen değer [`Release`] (veya daha güçlü) siparişiyle bir mağaza işlemiyle yazıldıysa, sonraki tüm işlemler bu mağazadan sonra sipariş edilir.
    /// Özellikle, sonraki tüm yüklemeler, depodan önce yazılan verileri görecektir.
    ///
    /// Yükleri ve depoları birleştiren bir işlem için bu siparişi kullanmanın bir [`Relaxed`] mağaza işlemine yol açtığına dikkat edin!
    ///
    /// Bu sıralama yalnızca bir yükleme gerçekleştirebilen işlemler için geçerlidir.
    ///
    /// C ++ 20'de [`memory_order_acquire`] e karşılık gelir.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Hem [`Acquire`] hem de [`Release`] in etkilerine birlikte sahiptir:
    /// Yükler için [`Acquire`] sıralaması kullanır.Mağazalar için [`Release`] siparişini kullanır.
    ///
    /// `compare_and_swap` durumunda, işlemin herhangi bir mağaza gerçekleştirmemesi ve dolayısıyla sadece [`Acquire`] siparişinin olması olasıdır.
    ///
    /// Ancak, `AcqRel` hiçbir zaman [`Relaxed`] erişimlerini gerçekleştirmeyecektir.
    ///
    /// Bu sıralama yalnızca hem yükleri hem de depoları birleştiren işlemler için geçerlidir.
    ///
    /// C ++ 20'de [`memory_order_acq_rel`] e karşılık gelir.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// [`Acquire`]/[`Release`]/[`AcqRel`](sırasıyla yükleme, depolama ve mağazayla yükleme işlemleri için) gibi, tüm iş parçacığının tüm iş parçacığının sıralı olarak tutarlı işlemleri aynı sırayla görmesini sağlayan ek garanti .
    ///
    ///
    /// C ++ 20'de [`memory_order_seq_cst`] e karşılık gelir.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Bir [`AtomicBool`], `false` olarak başlatıldı.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Yeni bir `AtomicBool` oluşturur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Temel alınan [`bool`] e değiştirilebilir bir referans döndürür.
    ///
    /// Bu güvenlidir, çünkü değiştirilebilir referans başka hiçbir iş parçacığının aynı anda atomik verilere erişmediğini garanti eder.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // GÜVENLİK: Değiştirilebilir referans, benzersiz bir sahipliği garanti eder.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Bir `&mut bool` e atomik erişim sağlayın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // GÜVENLİK: değiştirilebilir referans, benzersiz sahipliği garanti eder ve
        // hem `bool` hem de `Self` in hizası 1'dir.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Atomik olanı tüketir ve içerdiği değeri döndürür.
    ///
    /// Bu güvenlidir çünkü `self` i değere göre geçirmek, başka hiçbir iş parçacığının aynı anda atomik verilere erişmemesini garanti eder.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool'den bir değer yükler.
    ///
    /// `load` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.
    /// Olası değerler [`SeqCst`], [`Acquire`] ve [`Relaxed`] tir.
    ///
    /// # Panics
    ///
    /// `order`, [`Release`] veya [`AcqRel`] ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // GÜVENLİK: herhangi bir veri yarışması atomik içsel ve işlenmemiş veriler tarafından engellenir.
        // iletilen işaretçi geçerlidir çünkü onu bir referanstan aldık.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool'ye bir değer kaydeder.
    ///
    /// `store` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.
    /// Olası değerler [`SeqCst`], [`Release`] ve [`Relaxed`] tir.
    ///
    /// # Panics
    ///
    /// `order`, [`Acquire`] veya [`AcqRel`] ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // GÜVENLİK: herhangi bir veri yarışması atomik içsel ve işlenmemiş veriler tarafından engellenir.
        // iletilen işaretçi geçerlidir çünkü onu bir referanstan aldık.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// bool'ye bir değer kaydederek önceki değeri döndürür.
    ///
    /// `swap` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
    /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
    ///
    ///
    /// **Note:** Bu yöntem yalnızca `u8` te atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Mevcut değer `current` değeriyle aynıysa [`bool`] e bir değer kaydeder.
    ///
    /// Dönüş değeri her zaman önceki değerdir.`current` e eşitse, değer güncellenmiştir.
    ///
    /// `compare_and_swap` ayrıca bu işlemin bellek sıralamasını açıklayan bir [`Ordering`] argümanı alır.
    /// [`AcqRel`] kullanırken bile, işlemin başarısız olabileceğine ve bu nedenle yalnızca bir `Acquire` yüklemesi gerçekleştirebileceğine, ancak `Release` semantiğine sahip olmadığına dikkat edin.
    /// [`Acquire`] in kullanılması, bu işlemin gerçekleşmesi durumunda [`Relaxed`] in mağaza bölümünü oluşturur ve [`Release`] in kullanılması, [`Relaxed`] yük parçasını oluşturur.
    ///
    /// **Note:** Bu yöntem yalnızca `u8` te atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # `compare_exchange` ve `compare_exchange_weak` e Geçiş
    ///
    /// `compare_and_swap` bellek sıralamaları için aşağıdaki eşlemeyle `compare_exchange` e eşdeğerdir:
    ///
    /// Orijinal |Başarı |Başarısızlık
    /// -------- | ------- | -------
    /// Rahat |Rahat |Rahat Edin |Edinme |Yayın Al |Yayın |Rahat AcqRel |AcqRel |SeqCst Edin |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` Karşılaştırma başarılı olduğunda bile sahte bir şekilde başarısız olmasına izin verilir, bu da derleyicinin karşılaştırma ve takas döngüde kullanıldığında daha iyi derleme kodu oluşturmasına olanak tanır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Mevcut değer `current` değeriyle aynıysa [`bool`] e bir değer kaydeder.
    ///
    /// Dönüş değeri, yeni değerin yazılıp yazılmadığını gösteren ve önceki değeri içeren bir sonuçtur.
    /// Başarı durumunda bu değerin `current` e eşit olması garanti edilir.
    ///
    /// `compare_exchange` bu işlemin bellek sıralamasını açıklamak için iki [`Ordering`] argümanı alır.
    /// `success` `current` ile karşılaştırma başarılı olursa gerçekleşecek olan okuma-değiştirme-yazma işlemi için gerekli sıralamayı açıklar.
    /// `failure` Karşılaştırma başarısız olduğunda gerçekleşen yükleme işlemi için gerekli sıralamayı açıklar.
    /// [`Acquire`] i başarılı sipariş olarak kullanmak, mağazayı bu işlemin [`Relaxed`] in bir parçası haline getirir ve [`Release`] in kullanılması [`Relaxed`] in başarılı bir şekilde yüklenmesini sağlar.
    ///
    /// Arıza sıralaması yalnızca [`SeqCst`], [`Acquire`] veya [`Relaxed`] olabilir ve başarılı sıralamaya eşdeğer veya daha zayıf olmalıdır.
    ///
    /// **Note:** Bu yöntem yalnızca `u8` te atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Mevcut değer `current` değeriyle aynıysa [`bool`] e bir değer kaydeder.
    ///
    /// [`AtomicBool::compare_exchange`] ten farklı olarak, bu işlevin karşılaştırma başarılı olsa bile sahte bir şekilde başarısız olmasına izin verilir, bu da bazı platformlarda daha verimli kodla sonuçlanabilir.
    ///
    /// Dönüş değeri, yeni değerin yazılıp yazılmadığını gösteren ve önceki değeri içeren bir sonuçtur.
    ///
    /// `compare_exchange_weak` bu işlemin bellek sıralamasını açıklamak için iki [`Ordering`] argümanı alır.
    /// `success` `current` ile karşılaştırma başarılı olursa gerçekleşecek olan okuma-değiştirme-yazma işlemi için gerekli sıralamayı açıklar.
    /// `failure` Karşılaştırma başarısız olduğunda gerçekleşen yükleme işlemi için gerekli sıralamayı açıklar.
    /// [`Acquire`] i başarılı sipariş olarak kullanmak, mağazayı bu işlemin [`Relaxed`] in bir parçası haline getirir ve [`Release`] in kullanılması [`Relaxed`] in başarılı bir şekilde yüklenmesini sağlar.
    /// Arıza sıralaması yalnızca [`SeqCst`], [`Acquire`] veya [`Relaxed`] olabilir ve başarılı sıralamaya eşdeğer veya daha zayıf olmalıdır.
    ///
    /// **Note:** Bu yöntem yalnızca `u8` te atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Boole değerine sahip mantıksal "and".
    ///
    /// Geçerli değer ve `val` bağımsız değişkeni üzerinde mantıksal bir "and" işlemi gerçekleştirir ve sonuca yeni değeri ayarlar.
    ///
    /// Önceki değeri döndürür.
    ///
    /// `fetch_and` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
    /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
    ///
    ///
    /// **Note:** Bu yöntem yalnızca `u8` te atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Boole değerine sahip mantıksal "nand".
    ///
    /// Geçerli değer ve `val` bağımsız değişkeni üzerinde mantıksal bir "nand" işlemi gerçekleştirir ve sonuca yeni değeri ayarlar.
    ///
    /// Önceki değeri döndürür.
    ///
    /// `fetch_nand` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
    /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
    ///
    ///
    /// **Note:** Bu yöntem yalnızca `u8` te atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Burada atomic_nand'i kullanamayız çünkü bu geçersiz bir değere sahip bir bool ile sonuçlanabilir.
        // Bunun nedeni, atomik işlemin dahili olarak 8 bitlik bir tamsayı ile yapılmasıdır, bu da üstteki 7 biti ayarlayacaktır.
        //
        // Bunun yerine fetch_xor veya swap kullanıyoruz.
        if val {
            // ! (x&true)== !x bool'yi tersine çevirmeliyiz.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true bool'yi true olarak ayarlamalıyız.
            //
            self.swap(true, order)
        }
    }

    /// Boole değerine sahip mantıksal "or".
    ///
    /// Geçerli değer ve `val` bağımsız değişkeni üzerinde mantıksal bir "or" işlemi gerçekleştirir ve sonuca yeni değeri ayarlar.
    ///
    /// Önceki değeri döndürür.
    ///
    /// `fetch_or` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
    /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
    ///
    ///
    /// **Note:** Bu yöntem yalnızca `u8` te atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Boole değerine sahip mantıksal "xor".
    ///
    /// Geçerli değer ve `val` bağımsız değişkeni üzerinde mantıksal bir "xor" işlemi gerçekleştirir ve sonuca yeni değeri ayarlar.
    ///
    /// Önceki değeri döndürür.
    ///
    /// `fetch_xor` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
    /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
    ///
    ///
    /// **Note:** Bu yöntem yalnızca `u8` te atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Temeldeki [`bool`] e değiştirilebilir bir işaretçi döndürür.
    ///
    /// Sonuçta ortaya çıkan tam sayıya atomik olmayan okuma ve yazma işlemleri yapmak bir veri yarışı olabilir.
    /// Bu yöntem çoğunlukla, işlev imzasının `&AtomicBool` yerine `*mut bool` i kullanabildiği FFI için kullanışlıdır.
    ///
    /// Bu atomikle ilgili paylaşılan bir referanstan bir `*mut` işaretçisini döndürmek güvenlidir çünkü atomik türler dahili değişkenlikle çalışır.
    /// Bir atomun tüm modifikasyonları, değeri paylaşılan bir referans yoluyla değiştirir ve atomik işlemleri kullandıkları sürece bunu güvenli bir şekilde yapabilir.
    /// Döndürülen ham göstericinin herhangi bir şekilde kullanılması bir `unsafe` bloğu gerektirir ve yine de aynı kısıtlamayı sürdürmek zorundadır: üzerindeki işlemler atomik olmalıdır.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Değeri alır ve ona isteğe bağlı yeni bir değer döndüren bir işlev uygular.İşlev `Some(_)`, aksi takdirde `Err(previous_value)` döndürdüyse `Ok(previous_value)` `Result` döndürür.
    ///
    /// Note: Bu, işlev `Some(_)` döndürdüğü sürece, değer diğer evrelerden değiştirilmişse, işlevi birden çok kez çağırabilir, ancak işlev, saklanan değere yalnızca bir kez uygulanmış olacaktır.
    ///
    ///
    /// `fetch_update` bu işlemin bellek sıralamasını açıklamak için iki [`Ordering`] argümanı alır.
    /// İlki, işlemin sonunda başarılı olduğu zaman için gerekli sıralamayı açıklarken, ikincisi yükler için gerekli sıralamayı açıklar.
    /// Bunlar sırasıyla [`AtomicBool::compare_exchange`] in başarı ve başarısızlık sıralamalarına karşılık gelir.
    ///
    /// [`Acquire`] i başarılı sipariş olarak kullanmak, mağazayı bu işlemin [`Relaxed`] in bir parçası haline getirir ve [`Release`] in kullanılması, son başarılı [`Relaxed`] yüklemesini yapar.
    /// (failed) yük sıralaması yalnızca [`SeqCst`], [`Acquire`] veya [`Relaxed`] olabilir ve başarılı sıralamaya eşdeğer veya daha zayıf olmalıdır.
    ///
    /// **Note:** Bu yöntem yalnızca `u8` te atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Yeni bir `AtomicPtr` oluşturur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Temeldeki işaretçiye değiştirilebilir bir başvuru döndürür.
    ///
    /// Bu güvenlidir, çünkü değiştirilebilir referans başka hiçbir iş parçacığının aynı anda atomik verilere erişmediğini garanti eder.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Bir işaretçiye atomik erişim sağlayın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - değişebilir referans, benzersiz sahipliği garanti eder.
        //  - `*mut T` ve `Self` in hizalanması, yukarıda doğrulandığı gibi rust tarafından desteklenen tüm platformlarda aynıdır.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Atomik olanı tüketir ve içerdiği değeri döndürür.
    ///
    /// Bu güvenlidir çünkü `self` i değere göre geçirmek, başka hiçbir iş parçacığının aynı anda atomik verilere erişmemesini garanti eder.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// İşaretçiden bir değer yükler.
    ///
    /// `load` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.
    /// Olası değerler [`SeqCst`], [`Acquire`] ve [`Relaxed`] tir.
    ///
    /// # Panics
    ///
    /// `order`, [`Release`] veya [`AcqRel`] ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// İşaretçiye bir değer kaydeder.
    ///
    /// `store` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.
    /// Olası değerler [`SeqCst`], [`Release`] ve [`Relaxed`] tir.
    ///
    /// # Panics
    ///
    /// `order`, [`Acquire`] veya [`AcqRel`] ise Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// İşaretçiye bir değer kaydederek önceki değeri döndürür.
    ///
    /// `swap` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
    /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
    ///
    ///
    /// **Note:** Bu yöntem yalnızca işaretçiler üzerindeki atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Mevcut değer `current` değeriyle aynıysa işaretçiye bir değer kaydeder.
    ///
    /// Dönüş değeri her zaman önceki değerdir.`current` e eşitse, değer güncellenmiştir.
    ///
    /// `compare_and_swap` ayrıca bu işlemin bellek sıralamasını açıklayan bir [`Ordering`] argümanı alır.
    /// [`AcqRel`] kullanırken bile, işlemin başarısız olabileceğine ve bu nedenle yalnızca bir `Acquire` yüklemesi gerçekleştirebileceğine, ancak `Release` semantiğine sahip olmadığına dikkat edin.
    /// [`Acquire`] in kullanılması, bu işlemin gerçekleşmesi durumunda [`Relaxed`] in mağaza bölümünü oluşturur ve [`Release`] in kullanılması, [`Relaxed`] yük parçasını oluşturur.
    ///
    /// **Note:** Bu yöntem yalnızca işaretçiler üzerindeki atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # `compare_exchange` ve `compare_exchange_weak` e Geçiş
    ///
    /// `compare_and_swap` bellek sıralamaları için aşağıdaki eşlemeyle `compare_exchange` e eşdeğerdir:
    ///
    /// Orijinal |Başarı |Başarısızlık
    /// -------- | ------- | -------
    /// Rahat |Rahat |Rahat Edin |Edinme |Yayın Al |Yayın |Rahat AcqRel |AcqRel |SeqCst Edin |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` Karşılaştırma başarılı olduğunda bile sahte bir şekilde başarısız olmasına izin verilir, bu da derleyicinin karşılaştırma ve takas döngüde kullanıldığında daha iyi derleme kodu oluşturmasına olanak tanır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Mevcut değer `current` değeriyle aynıysa işaretçiye bir değer kaydeder.
    ///
    /// Dönüş değeri, yeni değerin yazılıp yazılmadığını gösteren ve önceki değeri içeren bir sonuçtur.
    /// Başarı durumunda bu değerin `current` e eşit olması garanti edilir.
    ///
    /// `compare_exchange` bu işlemin bellek sıralamasını açıklamak için iki [`Ordering`] argümanı alır.
    /// `success` `current` ile karşılaştırma başarılı olursa gerçekleşecek olan okuma-değiştirme-yazma işlemi için gerekli sıralamayı açıklar.
    /// `failure` Karşılaştırma başarısız olduğunda gerçekleşen yükleme işlemi için gerekli sıralamayı açıklar.
    /// [`Acquire`] i başarılı sipariş olarak kullanmak, mağazayı bu işlemin [`Relaxed`] in bir parçası haline getirir ve [`Release`] in kullanılması [`Relaxed`] in başarılı bir şekilde yüklenmesini sağlar.
    ///
    /// Arıza sıralaması yalnızca [`SeqCst`], [`Acquire`] veya [`Relaxed`] olabilir ve başarılı sıralamaya eşdeğer veya daha zayıf olmalıdır.
    ///
    /// **Note:** Bu yöntem yalnızca işaretçiler üzerindeki atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Mevcut değer `current` değeriyle aynıysa işaretçiye bir değer kaydeder.
    ///
    /// [`AtomicPtr::compare_exchange`] ten farklı olarak, bu işlevin karşılaştırma başarılı olsa bile sahte bir şekilde başarısız olmasına izin verilir, bu da bazı platformlarda daha verimli kodla sonuçlanabilir.
    ///
    /// Dönüş değeri, yeni değerin yazılıp yazılmadığını gösteren ve önceki değeri içeren bir sonuçtur.
    ///
    /// `compare_exchange_weak` bu işlemin bellek sıralamasını açıklamak için iki [`Ordering`] argümanı alır.
    /// `success` `current` ile karşılaştırma başarılı olursa gerçekleşecek olan okuma-değiştirme-yazma işlemi için gerekli sıralamayı açıklar.
    /// `failure` Karşılaştırma başarısız olduğunda gerçekleşen yükleme işlemi için gerekli sıralamayı açıklar.
    /// [`Acquire`] i başarılı sipariş olarak kullanmak, mağazayı bu işlemin [`Relaxed`] in bir parçası haline getirir ve [`Release`] in kullanılması [`Relaxed`] in başarılı bir şekilde yüklenmesini sağlar.
    /// Arıza sıralaması yalnızca [`SeqCst`], [`Acquire`] veya [`Relaxed`] olabilir ve başarılı sıralamaya eşdeğer veya daha zayıf olmalıdır.
    ///
    /// **Note:** Bu yöntem yalnızca işaretçiler üzerindeki atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // GÜVENLİK: Bu öz güvensizdir çünkü ham bir işaretçi üzerinde çalışır.
        // ancak işaretçinin geçerli olduğundan (bunu referans olarak sahip olduğumuz bir `UnsafeCell` ten aldık) ve atomik işlemin kendisinin `UnsafeCell` içeriğini güvenli bir şekilde değiştirmemize izin verdiğinden emin olduğumuzu biliyoruz.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Değeri alır ve ona isteğe bağlı yeni bir değer döndüren bir işlev uygular.İşlev `Some(_)`, aksi takdirde `Err(previous_value)` döndürdüyse `Ok(previous_value)` `Result` döndürür.
    ///
    /// Note: Bu, işlev `Some(_)` döndürdüğü sürece, değer diğer evrelerden değiştirilmişse, işlevi birden çok kez çağırabilir, ancak işlev, saklanan değere yalnızca bir kez uygulanmış olacaktır.
    ///
    ///
    /// `fetch_update` bu işlemin bellek sıralamasını açıklamak için iki [`Ordering`] argümanı alır.
    /// İlki, işlemin sonunda başarılı olduğu zaman için gerekli sıralamayı açıklarken, ikincisi yükler için gerekli sıralamayı açıklar.
    /// Bunlar sırasıyla [`AtomicPtr::compare_exchange`] in başarı ve başarısızlık sıralamalarına karşılık gelir.
    ///
    /// [`Acquire`] i başarılı sipariş olarak kullanmak, mağazayı bu işlemin [`Relaxed`] in bir parçası haline getirir ve [`Release`] in kullanılması, son başarılı [`Relaxed`] yüklemesini yapar.
    /// (failed) yük sıralaması yalnızca [`SeqCst`], [`Acquire`] veya [`Relaxed`] olabilir ve başarılı sıralamaya eşdeğer veya daha zayıf olmalıdır.
    ///
    /// **Note:** Bu yöntem yalnızca işaretçiler üzerindeki atomik işlemleri destekleyen platformlarda kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` i `AtomicBool` e dönüştürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Bu makro bazı mimarilerde kullanılmaz hale gelir.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// İş parçacıkları arasında güvenle paylaşılabilen bir tamsayı türü.
        ///
        /// Bu tür, temeldeki tamsayı türüyle aynı bellek içi temsiline sahiptir, ["
        ///
        #[doc = $s_int_type]
        /// `].
        /// Atomik türler ve atomik olmayan türler arasındaki farkların yanı sıra bu türün taşınabilirliği hakkında daha fazla bilgi için lütfen [module-level documentation] e bakın.
        ///
        ///
        /// **Note:** Bu tür yalnızca atomik yükleri ve ["
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// `0` olarak başlatılan atomik bir tamsayı.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Gönderme dolaylı olarak uygulanır.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Yeni bir atomik tam sayı oluşturur.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Temeldeki tam sayıya değiştirilebilir bir başvuru döndürür.
            ///
            /// Bu güvenlidir, çünkü değiştirilebilir referans başka hiçbir iş parçacığının aynı anda atomik verilere erişmediğini garanti eder.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// let mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (bir_it, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - değişebilir referans, benzersiz sahipliği garanti eder.
                //  - `$int_type` ve `Self` in hizalanması, $cfg_align tarafından vaat edilen ve yukarıda doğrulandığı gibi aynıdır.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Atomik olanı tüketir ve içerdiği değeri döndürür.
            ///
            /// Bu güvenlidir çünkü `self` i değere göre geçirmek, başka hiçbir iş parçacığının aynı anda atomik verilere erişmemesini garanti eder.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Atomik tamsayıdan bir değer yükler.
            ///
            /// `load` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.
            /// Olası değerler [`SeqCst`], [`Acquire`] ve [`Relaxed`] tir.
            ///
            /// # Panics
            ///
            /// `order`, [`Release`] veya [`AcqRel`] ise Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Atomik tam sayıya bir değer depolar.
            ///
            /// `store` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.
            ///  Olası değerler [`SeqCst`], [`Release`] ve [`Relaxed`] tir.
            ///
            /// # Panics
            ///
            /// `order`, [`Acquire`] veya [`AcqRel`] ise Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Atomik tam sayıya bir değer kaydederek önceki değeri döndürür.
            ///
            /// `swap` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
            /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
            ///
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Mevcut değer `current` değeriyle aynıysa atomik tamsayıda bir değer depolar.
            ///
            /// Dönüş değeri her zaman önceki değerdir.`current` e eşitse, değer güncellenmiştir.
            ///
            /// `compare_and_swap` ayrıca bu işlemin bellek sıralamasını açıklayan bir [`Ordering`] argümanı alır.
            /// [`AcqRel`] kullanırken bile, işlemin başarısız olabileceğine ve bu nedenle yalnızca bir `Acquire` yüklemesi gerçekleştirebileceğine, ancak `Release` semantiğine sahip olmadığına dikkat edin.
            ///
            /// [`Acquire`] in kullanılması, bu işlemin gerçekleşmesi durumunda [`Relaxed`] in mağaza bölümünü oluşturur ve [`Release`] in kullanılması, [`Relaxed`] yük parçasını oluşturur.
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` ve `compare_exchange_weak` e Geçiş
            ///
            /// `compare_and_swap` bellek sıralamaları için aşağıdaki eşlemeyle `compare_exchange` e eşdeğerdir:
            ///
            /// Orijinal |Başarı |Başarısızlık
            /// -------- | ------- | -------
            /// Rahat |Rahat |Rahat Edin |Edinme |Yayın Al |Yayın |Rahat AcqRel |AcqRel |SeqCst Edin |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` Karşılaştırma başarılı olduğunda bile sahte bir şekilde başarısız olmasına izin verilir, bu da derleyicinin karşılaştırma ve takas döngüde kullanıldığında daha iyi derleme kodu oluşturmasına olanak tanır.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Mevcut değer `current` değeriyle aynıysa atomik tamsayıda bir değer depolar.
            ///
            /// Dönüş değeri, yeni değerin yazılıp yazılmadığını gösteren ve önceki değeri içeren bir sonuçtur.
            /// Başarı durumunda bu değerin `current` e eşit olması garanti edilir.
            ///
            /// `compare_exchange` bu işlemin bellek sıralamasını açıklamak için iki [`Ordering`] argümanı alır.
            /// `success` `current` ile karşılaştırma başarılı olursa gerçekleşecek olan okuma-değiştirme-yazma işlemi için gerekli sıralamayı açıklar.
            /// `failure` Karşılaştırma başarısız olduğunda gerçekleşen yükleme işlemi için gerekli sıralamayı açıklar.
            /// [`Acquire`] i başarılı sipariş olarak kullanmak, mağazayı bu işlemin [`Relaxed`] in bir parçası haline getirir ve [`Release`] in kullanılması [`Relaxed`] in başarılı bir şekilde yüklenmesini sağlar.
            ///
            /// Arıza sıralaması yalnızca [`SeqCst`], [`Acquire`] veya [`Relaxed`] olabilir ve başarılı sıralamaya eşdeğer veya daha zayıf olmalıdır.
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Mevcut değer `current` değeriyle aynıysa atomik tamsayıda bir değer depolar.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// karşılaştırma başarılı olsa bile bu işlevin sahte bir şekilde başarısız olmasına izin verilir, bu da bazı platformlarda daha verimli kodla sonuçlanabilir.
            /// Dönüş değeri, yeni değerin yazılıp yazılmadığını gösteren ve önceki değeri içeren bir sonuçtur.
            ///
            /// `compare_exchange_weak` bu işlemin bellek sıralamasını açıklamak için iki [`Ordering`] argümanı alır.
            /// `success` `current` ile karşılaştırma başarılı olursa gerçekleşecek olan okuma-değiştirme-yazma işlemi için gerekli sıralamayı açıklar.
            /// `failure` Karşılaştırma başarısız olduğunda gerçekleşen yükleme işlemi için gerekli sıralamayı açıklar.
            /// [`Acquire`] i başarılı sipariş olarak kullanmak, mağazayı bu işlemin [`Relaxed`] in bir parçası haline getirir ve [`Release`] in kullanılması [`Relaxed`] in başarılı bir şekilde yüklenmesini sağlar.
            ///
            /// Arıza sıralaması yalnızca [`SeqCst`], [`Acquire`] veya [`Relaxed`] olabilir ve başarılı sıralamaya eşdeğer veya daha zayıf olmalıdır.
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// let mut old= val.load(Ordering::Relaxed);
            /// döngü {let new=old * 2;
            ///     val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, } ile eşleşir}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Önceki değeri döndürerek mevcut değere ekler.
            ///
            /// Bu işlem taşma üzerine sarılır.
            ///
            /// `fetch_add` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
            /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
            ///
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Geçerli değerden çıkararak önceki değeri döndürür.
            ///
            /// Bu işlem taşma üzerine sarılır.
            ///
            /// `fetch_sub` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
            /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
            ///
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Mevcut değer ile Bitsel "and".
            ///
            /// Geçerli değer ve `val` bağımsız değişkeni üzerinde bitsel bir "and" işlemi gerçekleştirir ve yeni değeri sonuca ayarlar.
            ///
            /// Önceki değeri döndürür.
            ///
            /// `fetch_and` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
            /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
            ///
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Mevcut değer ile Bitsel "nand".
            ///
            /// Geçerli değer ve `val` bağımsız değişkeni üzerinde bitsel bir "nand" işlemi gerçekleştirir ve yeni değeri sonuca ayarlar.
            ///
            /// Önceki değeri döndürür.
            ///
            /// `fetch_nand` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
            /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
            ///
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13 ve 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Mevcut değer ile Bitsel "or".
            ///
            /// Geçerli değer ve `val` bağımsız değişkeni üzerinde bitsel bir "or" işlemi gerçekleştirir ve yeni değeri sonuca ayarlar.
            ///
            /// Önceki değeri döndürür.
            ///
            /// `fetch_or` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
            /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
            ///
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Mevcut değer ile Bitsel "xor".
            ///
            /// Geçerli değer ve `val` bağımsız değişkeni üzerinde bitsel bir "xor" işlemi gerçekleştirir ve yeni değeri sonuca ayarlar.
            ///
            /// Önceki değeri döndürür.
            ///
            /// `fetch_xor` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
            /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
            ///
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Değeri alır ve ona isteğe bağlı yeni bir değer döndüren bir işlev uygular.İşlev `Some(_)`, aksi takdirde `Err(previous_value)` döndürdüyse `Ok(previous_value)` `Result` döndürür.
            ///
            /// Note: Bu, işlev `Some(_)` döndürdüğü sürece, değer diğer evrelerden değiştirilmişse, işlevi birden çok kez çağırabilir, ancak işlev, saklanan değere yalnızca bir kez uygulanmış olacaktır.
            ///
            ///
            /// `fetch_update` bu işlemin bellek sıralamasını açıklamak için iki [`Ordering`] argümanı alır.
            /// İlki, işlemin sonunda başarılı olduğu zaman için gerekli sıralamayı açıklarken, ikincisi yükler için gerekli sıralamayı açıklar.Bunlar, başarı ve başarısızlık sıralamalarına karşılık gelir.
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] i başarılı sipariş olarak kullanmak, mağazayı bu işlemin [`Relaxed`] in bir parçası haline getirir ve [`Release`] in kullanılması, son başarılı [`Relaxed`] yüklemesini yapar.
            /// (failed) yük sıralaması yalnızca [`SeqCst`], [`Acquire`] veya [`Relaxed`] olabilir ve başarılı sıralamaya eşdeğer veya daha zayıf olmalıdır.
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Sıralama: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Sıralama: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Mevcut değerle maksimum.
            ///
            /// Geçerli değerin ve `val` bağımsız değişkeninin maksimumunu bulur ve sonuca yeni değeri ayarlar.
            ///
            /// Önceki değeri döndürür.
            ///
            /// `fetch_max` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
            /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
            ///
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=42;
            /// let max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// iddia! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Mevcut değerle minimum.
            ///
            /// Geçerli değerin minimumunu ve `val` bağımsız değişkenini bulur ve sonuca yeni değeri ayarlar.
            ///
            /// Önceki değeri döndürür.
            ///
            /// `fetch_min` bu işlemin bellek sırasını tanımlayan bir [`Ordering`] argümanını alır.Tüm sipariş modları mümkündür.
            /// [`Acquire`] i kullanmanın bu işlemin [`Relaxed`] i ve [`Release`] i kullanmanın [`Relaxed`] yük parçasını oluşturduğunu unutmayın.
            ///
            ///
            /// **Not**: Bu yöntem yalnızca atomik işlemleri destekleyen platformlarda mevcuttur.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=12;
            /// min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // GÜVENLİK: veri yarışları atomik içseller tarafından engellenir.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Temel tam sayıya değiştirilebilir bir işaretçi döndürür.
            ///
            /// Sonuçta ortaya çıkan tam sayıya atomik olmayan okuma ve yazma işlemleri yapmak bir veri yarışı olabilir.
            /// Bu yöntem çoğunlukla işlev imzasının kullanabileceği FFI için kullanışlıdır.
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Bu atomikle ilgili paylaşılan bir referanstan bir `*mut` işaretçisini döndürmek güvenlidir çünkü atomik türler dahili değişkenlikle çalışır.
            /// Bir atomun tüm modifikasyonları, değeri paylaşılan bir referans yoluyla değiştirir ve atomik işlemleri kullandıkları sürece bunu güvenli bir şekilde yapabilir.
            /// Döndürülen ham göstericinin herhangi bir şekilde kullanılması bir `unsafe` bloğu gerektirir ve yine de aynı kısıtlamayı sürdürmek zorundadır: üzerindeki işlemler atomik olmalıdır.
            ///
            ///
            /// # Examples
            ///
            /// `` (extern-declaration) i yok say
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // GÜVENLİK: `my_atomic_op` atomik olduğu sürece güvenlidir.
            /// güvensiz {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // GÜVENLİK: Arayan kişi `atomic_store` için güvenlik sözleşmesine uymalıdır.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_load` için güvenlik sözleşmesine uymalıdır.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_swap` için güvenlik sözleşmesine uymalıdır.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Önceki değeri döndürür (__sync_fetch_and_add gibi).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_add` için güvenlik sözleşmesine uymalıdır.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Önceki değeri döndürür (__sync_fetch_and_sub gibi).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_sub` için güvenlik sözleşmesine uymalıdır.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // GÜVENLİK: Arayan kişi `atomic_compare_exchange` için güvenlik sözleşmesine uymalıdır.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // GÜVENLİK: Arayan kişi `atomic_compare_exchange_weak` için güvenlik sözleşmesine uymalıdır.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_and` için güvenlik sözleşmesine uymalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_nand` için güvenlik sözleşmesine uymalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_or` için güvenlik sözleşmesine uymalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_xor` için güvenlik sözleşmesine uymalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// maksimum değeri döndürür (işaretli karşılaştırma)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_max` için güvenlik sözleşmesine uymalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// minimum değeri verir (işaretli karşılaştırma)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_min` için güvenlik sözleşmesine uymalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// maksimum değeri döndürür (işaretsiz karşılaştırma)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_umax` için güvenlik sözleşmesine uymalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// minimum değeri verir (işaretsiz karşılaştırma)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // GÜVENLİK: Arayan kişi `atomic_umin` için güvenlik sözleşmesine uymalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Atomik bir çit.
///
/// Belirlenen sıraya bağlı olarak, bir çit, derleyicinin ve CPU'nun çevresindeki belirli bellek işlemlerini yeniden düzenlemesini engeller.
/// Bu, onunla atomik işlemler veya diğer ipliklerdeki çitler arasındaki ilişkilerle senkronize olur.
///
/// [`Release`] sıralama semantiğine (en azından) sahip olan bir çit 'A', 'B' çitiyle (en azından) [`Acquire`] semantiği ile senkronize olur, ancak ve ancak X ve Y işlemleri varsa, her ikisi de A'nın daha önce sıralandığı şekilde 'M' atomik nesnesi üzerinde çalışır. X, Y, B ve Y, M'ye olan değişikliği gözlemlemeden önce senkronize edilir.
/// Bu, A ve B arasında bir önceden gerçekleşme bağımlılığı sağlar.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] veya [`Acquire`] semantiğiyle yapılan atomik işlemler de bir çitle senkronize edilebilir.
///
/// Hem [`Acquire`] hem de [`Release`] semantiğine ek olarak [`SeqCst`] sıralamasına sahip bir çit, diğer [`SeqCst`] işlemlerinin ve/veya çitlerinin genel program sırasına katılır.
///
/// [`Acquire`], [`Release`], [`AcqRel`] ve [`SeqCst`] siparişlerini kabul eder.
///
/// # Panics
///
/// `order`, [`Relaxed`] ise Panics.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Spinlock'a dayalı bir karşılıklı dışlama ilkeli.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Eski değer `false` olana kadar bekleyin.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Bu çit, `unlock` teki mağazayla senkronize olur.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // GÜVENLİK: atomik bir çit kullanmak güvenlidir.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Derleyici bellek çiti.
///
/// `compiler_fence` herhangi bir makine kodu yaymaz, ancak derleyicinin yapmasına izin verilen bellek türlerini yeniden sıralamayı kısıtlar.Spesifik olarak, verilen [`Ordering`] semantiğine bağlı olarak, derleyicinin aramadan önceki veya sonraki okumaları veya yazmaları `compiler_fence` e çağrının diğer tarafına taşımasına izin verilmeyebilir.*Donanımın* bu tür bir yeniden sıralama yapmasını **engellemediğini** unutmayın.
///
/// Bu, tek iş parçacıklı, yürütme bağlamında bir sorun değildir, ancak diğer iş parçacıkları aynı anda belleği değiştirebildiğinde, [`fence`] gibi daha güçlü senkronizasyon ilkelleri gereklidir.
///
/// Farklı sıralama anlambilimlerinin önlediği yeniden sıralama şunlardır:
///
///  - [`SeqCst`] ile bu noktada okuma ve yazma işlemlerinin yeniden sıralanmasına izin verilmez.
///  - [`Release`] ile, önceki okumalar ve yazmalar sonraki yazma işlemlerinin ötesine taşınamaz.
///  - [`Acquire`] ile, sonraki okumalar ve yazmalar önceki okumaların önüne taşınamaz.
///  - [`AcqRel`] ile yukarıdaki kuralların her ikisi de uygulanır.
///
/// `compiler_fence` genellikle yalnızca bir iş parçacığının kendisiyle *yarışmasını* önlemek için kullanışlıdır.Yani, belirli bir iş parçacığı bir kod parçasını çalıştırıyorsa ve ardından kesintiye uğrarsa ve başka bir yerde kodu yürütmeye başlarsa (hala aynı iş parçacığında ve kavramsal olarak hala aynı çekirdekte).Geleneksel programlarda, bu yalnızca bir sinyal tutucusu kaydedildiğinde gerçekleşebilir.
/// Daha düşük seviyeli kodda, bu tür durumlar ayrıca kesintileri ele alırken, ön emmeli yeşil iş parçacıkları uygularken vb. Ortaya çıkabilir.
/// Meraklı okuyucular, Linux çekirdeğinin [memory barriers] tartışmasını okumaya teşvik edilir.
///
/// # Panics
///
/// `order`, [`Relaxed`] ise Panics.
///
/// # Examples
///
/// `compiler_fence` olmadan, aşağıdaki koddaki `assert_eq!` in, tek bir iş parçacığında olan her şeye rağmen başarılı olacağı *garanti edilmez*.
/// Nedenini görmek için, derleyicinin mağazaları `IMPORTANT_VARIABLE` ve `IS_READ` ile değiştirmekte özgür olduğunu unutmayın, çünkü ikisi de `Ordering::Relaxed` dir.Olursa ve sinyal işleyici `IS_READY` güncellendikten hemen sonra çalıştırılırsa, sinyal işleyici `IS_READY=1` i ancak `IMPORTANT_VARIABLE=0` i görecektir.
/// Bir `compiler_fence` kullanmak bu durumu çözer.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // Daha önceki yazıların bu noktanın ötesine geçmesini önleyin
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // GÜVENLİK: atomik bir çit kullanmak güvenlidir.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// İşlemciye meşgul bekleme döngüsü ("döndürme kilidi") içinde olduğunu bildirir.
///
/// Bu işlev, [`hint::spin_loop`] lehine kullanımdan kaldırılmıştır.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}