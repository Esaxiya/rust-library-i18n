//! Libcore için Panic desteği
//!
//! Çekirdek kütüphane paniklemeyi tanımlayamaz, ancak paniklemeyi *ilan eder*.
//! Bu, libcore'un içindeki işlevlere panic için izin verildiği anlamına gelir, ancak yararlı olması için bir yukarı akış crate, libcore'un kullanması için paniklemeyi tanımlamalıdır.
//! Panik için mevcut arayüz:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Bu tanım, herhangi bir genel mesajla paniğe izin verir, ancak bir `Box<Any>` değeri ile başarısız olmaya izin vermez.
//! (`PanicInfo` sadece bir `&(dyn Any + Send)` içerir, bunun için "PanicInfo: : internal_constructor" da bir yapay değer doldururuz.) Bunun nedeni libcore'un tahsis edilmesine izin verilmemesidir.
//!
//!
//! Bu modül birkaç başka panikleme işlevi içerir, ancak bunlar yalnızca derleyici için gerekli dil öğeleridir.Tüm panics, bu tek işlev aracılığıyla yönlendirilir.
//! Gerçek sembol, `#[panic_handler]` özelliği aracılığıyla bildirilir.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Biçimlendirme kullanılmadığında libcore'un `panic!` makrosunun temel uygulaması.
#[cold]
// Çağrı sitelerinde mümkün olduğunca kod şişmesini önlemek için panic_immediate_abort olmadıkça asla satır içi yapmayın
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // taşma ve diğer `Assert` MIR sonlandırıcılarda panic için codegen tarafından gerekli
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Boyut ek yükünü potansiyel olarak azaltmak için format_args! ("{}", İfade) yerine Arguments::new_v1 kullanın.
    // Format_args!makrosu ifade yazmak için str'nin Display trait'sini kullanır, bu ifade Formatter::pad i çağırır, bu da dize kesme ve doldurmayı barındırmalıdır (burada hiçbiri kullanılmasa bile).
    //
    // Arguments::new_v1 in kullanılması, derleyicinin Formatter::pad i çıktı ikili dosyasından çıkarmasına ve birkaç kilobayta kadar tasarruf etmesine izin verebilir.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // sabit değerlendirilmiş panics için gerekli
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice erişiminde panic için codegen tarafından gerekli
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Biçimlendirme kullanıldığında libcore `panic!` makrosunun temel uygulaması.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOT Bu işlev hiçbir zaman FFI sınırını geçmez;bu, `#[panic_handler]` işlevine çözümlenen bir Rust-to-Rust çağrısıdır.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // GÜVENLİK: `panic_impl` güvenli Rust kodunda tanımlanmıştır ve bu nedenle aramak güvenlidir.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` ve `assert_ne!` makroları için dahili işlev
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}