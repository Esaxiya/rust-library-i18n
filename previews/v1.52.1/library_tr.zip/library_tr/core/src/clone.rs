//! 'Örtük olarak kopyalanamayan' tipler için `Clone` trait.
//!
//! Rust'de, bazı basit türler "implicitly copyable" tir ve bunları bağımsız değişken olarak atadığınızda veya ilettiğinizde, alıcı orijinal değeri yerinde bırakarak bir kopya alır.
//! Bu türler, kopyalamak için tahsis gerektirmez ve sonlandırıcılara sahip değildir (yani, sahip olunan kutuları içermezler veya [`Drop`] gerçekleştirmezler), bu nedenle derleyici bunları ucuz ve kopyalanması güvenli olarak değerlendirir.
//!
//! Diğer türler için kopyalar, [`Clone`] trait uygulanarak ve [`clone`] yöntemini çağırarak açıkça yapılmalıdır.
//!
//! [`clone`]: Clone::clone
//!
//! Temel kullanım örneği:
//!
//! ```
//! let s = String::new(); // Dize türü Klonu uygular
//! let copy = s.clone(); // böylece onu klonlayabiliriz
//! ```
//!
//! Clone trait'yi kolayca uygulamak için `#[derive(Clone)]` i de kullanabilirsiniz.Misal:
//!
//! ```
//! #[derive(Clone)] // Klon trait'yi Morpheus yapısına ekliyoruz
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ve şimdi onu klonlayabiliriz!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Bir nesneyi açıkça çoğaltma becerisi için ortak bir trait.
///
/// [`Copy`] ten farklıdır, çünkü [`Copy`] örtük ve son derece ucuzdur, `Clone` her zaman açıktır ve pahalı olabilir veya olmayabilir.
/// Bu özellikleri uygulamak için Rust, [`Copy`] i yeniden uygulamanıza izin vermez, ancak `Clone` i yeniden uygulayabilir ve rastgele kod çalıştırabilirsiniz.
///
/// `Clone`, [`Copy`] ten daha genel olduğundan, [`Copy`] i otomatik olarak `Clone` yapabilirsiniz.
///
/// ## Derivable
///
/// Bu trait, tüm alanlar `Clone` ise `#[derive]` ile kullanılabilir.[`Clone`] in "derive" uygulaması, her alanda [`clone`] i çağırır.
///
/// [`clone`]: Clone::clone
///
/// Genel bir yapı için, `#[derive]`, genel parametrelere bağlı `Clone` ekleyerek `Clone` i koşullu olarak uygular.
///
/// ```
/// // `derive` Okuma için Klonu uygular<T>T Clone olduğunda.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## `Clone` i nasıl uygulayabilirim?
///
/// [`Copy`] olan türler, önemsiz bir `Clone` uygulamasına sahip olmalıdır.Daha resmi:
/// `T: Copy`, `x: T` ve `y: &T` ise, `let x = y.clone();`, `let x = *y;` e eşdeğerdir.
/// Manuel uygulamalar bu değişmezi korumak için dikkatli olmalıdır;ancak güvenli olmayan kod, bellek güvenliğini sağlamak için ona güvenmemelidir.
///
/// Bir örnek, bir işlev işaretçisi tutan genel bir yapıdır.Bu durumda, `Clone` uygulaması "derive`d olamaz, ancak şu şekilde uygulanabilir:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Ek uygulayıcılar
///
/// [implementors listed below][impls] e ek olarak, aşağıdaki tipler de `Clone` i uygular:
///
/// * İşlev öğesi türleri (yani, her işlev için tanımlanan farklı türler)
/// * İşlev işaretçi türleri (ör. `fn() -> i32`)
/// * Öğe türü `Clone` i de uyguluyorsa, tüm boyutlar için dizi türleri (ör. `[i32; 123456]`)
/// * Tuple türleri, eğer her bileşen `Clone` i de uyguluyorsa (örneğin, `()`, `(i32, bool)`)
/// * Kapatma türleri, çevreden hiçbir değer yakalamıyorlarsa veya bu tür yakalanan değerlerin tümü `Clone` i kendileri uyguluyorsa.
///   Paylaşılan referans tarafından yakalanan değişkenlerin her zaman `Clone` i uyguladığını (referans olmasa bile), değişken referans tarafından yakalanan değişkenlerin hiçbir zaman `Clone` i uygulamadığını unutmayın.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Değerin bir kopyasını döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str Klonu uygular
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` ten kopya atama gerçekleştirir.
    ///
    /// `a.clone_from(&b)` işlevsellik açısından `a = b.clone()` e eşdeğerdir, ancak gereksiz tahsisleri önlemek için `a` kaynaklarını yeniden kullanmak için geçersiz kılınabilir.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` in bir impl'ını oluşturan makro türetin.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): bu yapılar yalnızca#[derive] tarafından bir türün her bileşeninin Klonlama veya Kopyalama uyguladığını iddia etmek için kullanılır.
//
//
// Bu yapılar asla kullanıcı kodunda görünmemelidir.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// İlkel tipler için `Clone` uygulamaları.
///
/// Rust'de açıklanamayan uygulamalar `rustc_trait_selection` te `traits::SelectionContext::copy_clone_conditions()` te uygulanmaktadır.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Paylaşılan referanslar klonlanabilir, ancak değiştirilebilir referanslar *olamaz*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Paylaşılan referanslar klonlanabilir, ancak değiştirilebilir referanslar *olamaz*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}