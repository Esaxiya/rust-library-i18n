//! Birleştirilebilir eşzamansız yineleme.
//!
//! futures eşzamansız değerler ise, akışlar eşzamansız yineleyicilerdir.
//! Kendinizi bir tür eşzamansız koleksiyonla bulduysanız ve söz konusu koleksiyonun öğeleri üzerinde bir işlem yapmanız gerekiyorsa, hızlı bir şekilde 'streams' ile karşılaşacaksınız.
//! Akışlar, deyimsel eşzamansız Rust kodunda yoğun bir şekilde kullanılır, bu nedenle onlara aşina olmaya değer.
//!
//! Daha fazlasını açıklamadan önce, bu modülün nasıl yapılandırıldığından bahsedelim:
//!
//! # Organization
//!
//! Bu modül büyük ölçüde türe göre düzenlenmiştir:
//!
//! * [Traits] çekirdek kısımdır: bu traits, ne tür akışların var olduğunu ve onlarla neler yapabileceğinizi tanımlar.Bu traits'nin yöntemleri, biraz daha fazla çalışma süresi ayırmaya değer.
//! * İşlevler, bazı temel akışları oluşturmak için bazı yararlı yollar sağlar.
//! * Yapılar genellikle bu modülün traits'sindeki çeşitli yöntemlerin dönüş türleridir.Genellikle `struct` in kendisi yerine `struct` i oluşturan yönteme bakmak isteyeceksiniz.
//! Nedeniyle ilgili daha fazla ayrıntı için bkz. '[Uygulama Akışı](#uygulama-akışı)'.
//!
//! [Traits]: #traits
//!
//! Bu kadar!Akarsuları inceleyelim.
//!
//! # Stream
//!
//! Bu modülün kalbi ve ruhu [`Stream`] trait'dir.[`Stream`] in çekirdeği şuna benzer:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! `Iterator` in aksine, `Stream`, bir `Stream` i uygularken kullanılan [`poll_next`] yöntemi ile bir akışı tüketirken kullanılan (to-be-implemented) `next` yöntemi arasında bir ayrım yapar.
//!
//! `Stream` tüketicilerinin yalnızca, çağrıldığında `Option<Stream::Item>` veren bir future döndüren `next` i dikkate almaları gerekir.
//!
//! `next` tarafından döndürülen future, öğeler olduğu sürece `Some(Item)` verecek ve tümü tükendikten sonra, yinelemenin bittiğini belirtmek için `None` verecektir.
//! Eğer eşzamanlı olmayan bir şeyin çözülmesini bekliyorsak, future akışın tekrar üretilmeye hazır olmasını bekleyecektir.
//!
//! Bireysel akışlar yinelemeye devam etmeyi seçebilir ve bu nedenle `next` i tekrar çağırmak, bir noktada sonunda `Some(Item)` i yeniden verebilir veya vermeyebilir.
//!
//! [`Stream`] 'in tam tanımı bir dizi başka yöntemi de içerir, ancak bunlar varsayılan yöntemlerdir, [`poll_next`] üzerine inşa edilmiştir ve bu nedenle bunları ücretsiz olarak edinebilirsiniz.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Akışı Uygulama
//!
//! Kendi akışınızı oluşturmak iki adımdan oluşur: Akışın durumunu tutmak için bir `struct` oluşturmak ve ardından bu `struct` için [`Stream`] i uygulamak.
//!
//! `1` ten `5` e kadar sayılan `Counter` adlı bir akış yapalım:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // İlk olarak, yapı:
//!
//! /// Birden beşe kadar sayılan bir akış
//! struct Counter {
//!     count: usize,
//! }
//!
//! // sayımımızın birde başlamasını istiyoruz, bu yüzden yardımcı olması için bir new() yöntemi ekleyelim.
//! // Bu kesinlikle gerekli değildir, ancak uygundur.
//! // `count` i sıfırdan başlattığımıza dikkat edin, neden aşağıda `poll_next()`'s uygulamasında göreceğiz.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ardından, `Counter` imiz için `Stream` i uyguluyoruz:
//!
//! impl Stream for Counter {
//!     // usize ile sayıyor olacağız
//!     type Item = usize;
//!
//!     // poll_next() gerekli tek yöntem
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Sayımızı artırın.Bu yüzden sıfırdan başladık.
//!         self.count += 1;
//!
//!         // Saymayı bitirip bitirmediğimizi kontrol edin.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Akışlar *tembeldir*.Bu, sadece bir akış oluşturmanın çok fazla _do_ olmadığı anlamına gelir.`next` i arayana kadar gerçekten hiçbir şey olmuyor.
//! Bu bazen yalnızca yan etkileri için bir akış oluştururken kafa karışıklığı yaratır.
//! Derleyici bizi bu tür davranışlar hakkında uyaracaktır:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;