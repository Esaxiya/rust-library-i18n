use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Eşzamansız yineleyicilerle uğraşmak için bir arabirim.
///
/// Bu ana akım trait'dir.
/// Genel olarak akış kavramı hakkında daha fazla bilgi için lütfen [module-level documentation] e bakın.
/// Özellikle, [implement `Stream`][impl] in nasıl yapıldığını bilmek isteyebilirsiniz.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Akış tarafından sağlanan öğelerin türü.
    type Item;

    /// Bu akışın bir sonraki değerini çıkarmayı, değer henüz mevcut değilse uyandırmak için geçerli görevi kaydetmeyi ve akış bittiyse `None` i döndürmeyi deneyin.
    ///
    /// # Geri dönüş değeri
    ///
    /// Her biri farklı bir akış durumunu gösteren birkaç olası dönüş değeri vardır:
    ///
    /// - `Poll::Pending` bu akışın bir sonraki değerinin henüz hazır olmadığı anlamına gelir.Uygulamalar, bir sonraki değer hazır olduğunda mevcut görevin bildirilmesini sağlayacaktır.
    ///
    /// - `Poll::Ready(Some(val))` akışın `val` değerini başarıyla ürettiği ve sonraki `poll_next` çağrılarında başka değerler üretebileceği anlamına gelir.
    ///
    /// - `Poll::Ready(None)` akışın sona erdiği ve `poll_next` in tekrar çağrılmaması gerektiği anlamına gelir.
    ///
    /// # Panics
    ///
    /// Bir akış bittiğinde (`Ready(None)` from `poll_next`) döndürüldüğünde, `poll_next` yönteminin tekrar çağrılması panic, sonsuza kadar bloke olabilir veya başka tür sorunlara neden olabilir; `Stream` trait, böyle bir çağrının etkilerine herhangi bir gereksinim getirmez.
    ///
    /// Bununla birlikte, `poll_next` yöntemi `unsafe` olarak işaretlenmediğinden, Rust'nin olağan kuralları geçerlidir: Çağrılar, akışın durumuna bakılmaksızın hiçbir zaman tanımlanmamış davranışlara (bellek bozulması, `unsafe` işlevlerinin yanlış kullanımı veya benzeri) neden olmamalıdır.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Akışın kalan uzunluğunun sınırlarını döndürür.
    ///
    /// Özellikle, `size_hint()`, birinci öğenin alt sınır ve ikinci öğenin üst sınır olduğu bir demet döndürür.
    ///
    /// Döndürülen dizinin ikinci yarısı bir ["Option"] "<" ["usize"] ">" şeklindedir.
    /// Buradaki bir [`None`], bilinen bir üst sınır olmadığı veya üst sınırın [`usize`] ten daha büyük olduğu anlamına gelir.
    ///
    /// # Uygulama notları
    ///
    /// Bir akış uygulamasının beyan edilen eleman sayısını vermesi zorunlu değildir.Hatalı bir akım, öğelerin alt sınırından daha az veya üst sınırından daha fazla akabilir.
    ///
    /// `size_hint()` öncelikle akışın öğeleri için alan ayırmak gibi optimizasyonlar için kullanılması amaçlanmıştır, ancak örneğin güvenli olmayan kodda sınır kontrollerini atlamak için güvenilmemelidir.
    /// `size_hint()` in yanlış uygulanması, bellek güvenliği ihlallerine yol açmamalıdır.
    ///
    /// Bununla birlikte, uygulama doğru bir tahmin sağlamalıdır, çünkü aksi takdirde trait protokolünün ihlali olur.
    ///
    /// Varsayılan uygulama, herhangi bir akış için doğru olan "(0," ["Hiçbiri"] ")" döndürür.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}