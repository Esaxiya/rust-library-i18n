//! Libcore prelude
//!
//! Bu modül, libstd'ye de bağlanmayan libcore kullanıcıları için tasarlanmıştır.
//! Bu modül, `#![no_std]` standart kitaplığın prelude ile aynı şekilde kullanıldığında varsayılan olarak içe aktarılır.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// prelude çekirdeğinin 2015 sürümü.
///
/// Daha fazlası için [module-level documentation](self) e bakın.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Çekirdek prelude'nin 2018 sürümü.
///
/// Daha fazlası için [module-level documentation](self) e bakın.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude çekirdeğinin 2021 versiyonu.
///
/// Daha fazlası için [module-level documentation](self) e bakın.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Daha fazla şey ekleyin.
}