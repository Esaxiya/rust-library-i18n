//! Standart kitaplıkta Panic desteği.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Bir panic hakkında bilgi sağlayan bir yapı.
///
/// `PanicInfo` yapı, [`set_hook`] işlevi tarafından ayarlanan bir panic hook'ye geçirilir.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic ile ilişkili yükü döndürür.
    ///
    /// Bu genellikle, ancak her zaman değil, `&'static str` veya [`String`] olacaktır.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// `core` crate'den (`std` ten değil) gelen `panic!` makrosu bir biçimlendirme dizesi ve bazı ek argümanlarla kullanılmışsa, bu mesajı örneğin [`fmt::write`] ile kullanılmaya hazır olarak döndürür.
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Varsa, panic'nin çıktığı konum hakkında bilgi verir.
    ///
    /// Bu yöntem şu anda her zaman [`Some`] döndürür, ancak bu future sürümlerinde değişebilir.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Bu bazen Hiçbiri döndürmek için değiştirilirse,
        // std::panicking::default_hook ve std::panicking::begin_panic_fmt te bu durumla ilgilenin.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: downcast_ref kullanamayız: :<String>() İşte
        // String libcore'da bulunmadığından!
        // Yük, `std::panic!` birden çok argümanla çağrıldığında bir Dizedir, ancak bu durumda mesaj da kullanılabilir.
        //

        self.location.fmt(formatter)
    }
}

/// Bir panic'nin konumu hakkında bilgi içeren bir yapı.
///
/// Bu yapı [`PanicInfo::location()`] tarafından oluşturulmuştur.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Eşitlik ve sıralama için karşılaştırmalar dosya, satır ve sütun önceliği olarak yapılır.
/// Dosyalar, `Path` ile değil, dizeler olarak karşılaştırılır ve bu beklenmedik olabilir.
/// Daha fazla tartışma için [`Location: : file`] belgelerine bakın.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Bu işlevi arayanın kaynak konumunu döndürür.
    /// Bu işlevin arayanı açıklanırsa, çağrı konumu geri döndürülür ve yığın, izlenmeyen bir işlev gövdesi içindeki ilk çağrıya kadar devam eder.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Çağrıldığı [`Location`] i döndürür.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Bu işlevin tanımının içinden bir [`Location`] döndürür.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // aynı izlenmeyen işlevi farklı bir konumda çalıştırmak bize aynı sonucu verir
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // izlenen işlevi farklı bir konumda çalıştırmak farklı bir değer üretir
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic'nin kaynaklandığı kaynak dosyanın adını döndürür.
    ///
    /// # `&str`, `&Path` değil
    ///
    /// Döndürülen ad, derleme sistemindeki bir kaynak yoluna atıfta bulunur, ancak bunu doğrudan bir `&Path` olarak temsil etmek geçerli değildir.
    /// Derlenen kod, içeriği sağlayan sistemden farklı bir `Path` uygulamasına sahip farklı bir sistemde çalışabilir ve bu kitaplık şu anda farklı bir "host path" türüne sahip değildir.
    ///
    /// En şaşırtıcı davranış, "the same" dosyasına modül sistemindeki birden fazla yoldan erişilebildiğinde (genellikle `#[path = "..."]` özniteliği veya benzeri kullanılarak) ortaya çıkar, bu da aynı kod gibi görünen şeyin bu işlevden farklı değerler döndürmesine neden olabilir.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Bu değer, ana bilgisayar platformu ve hedef platform farklı olduğunda `Path::new` veya benzeri kuruculara geçmek için uygun değildir.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic'nin kaynaklandığı satır numarasını döndürür.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic'nin kaynaklandığı sütunu döndürür.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Libstd tarafından libstd'den `panic_unwind` e ve diğer panic çalışma zamanlarına veri aktarmak için kullanılan dahili bir trait.
/// Yakında herhangi bir zamanda stabilize edilmesi amaçlanmamıştır, kullanmayın.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// İçeriğin tam sahipliğini alın.
    /// Dönüş türü aslında `Box<dyn Any + Send>`, ancak `Box` i libcore'da kullanamayız.
    ///
    /// Bu yöntem çağrıldıktan sonra, `self` te yalnızca bazı kukla varsayılan değerler kalır.
    /// Bu yöntemi iki kez çağırmak veya bu yöntemi çağırdıktan sonra `get` i çağırmak bir hatadır.
    ///
    /// Bağımsız değişken ödünç alınmıştır çünkü panic çalışma zamanı (`__rust_start_panic`) yalnızca ödünç alınmış bir `dyn BoxMeUp` alır.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Sadece içeriği ödünç al.
    fn get(&mut self) -> &(dyn Any + Send);
}