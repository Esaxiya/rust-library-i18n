#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Yabancı işlev arabirimi (FFI) bağlamalarıyla ilgili yardımcı programlar.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// [pointer] olarak kullanıldığında C'nin `void` tipine eşdeğerdir.
///
/// Özünde, `*const c_void`, C'nin `const void*` ine eşdeğerdir ve `*mut c_void`, C'nin `void*` ine eşdeğerdir.
/// Bununla birlikte, bu, Rust'nin `()` türü olan C'nin `void` dönüş türü ile aynı *değildir*.
///
/// İşaretçileri FFI'daki opak türlere modellemek için, `extern type` sabitlenene kadar boş bir bayt dizisi etrafında bir newtype sarıcı kullanılması önerilir.
///
/// Ayrıntılar için [Nomicon] e bakın.
///
/// Eski Rust derleyicisini 1.1.0 e kadar desteklemek istiyorlarsa `std::os::raw::c_void` kullanılabilir.
/// Rust 1.30.0 ten sonra bu tanıma göre yeniden ihraç edildi.
/// Daha fazla bilgi için lütfen [RFC 2521] i okuyun.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, LLVM'nin void işaretçi tipini tanıması için ve malloc() gibi uzantı işlevleriyle, onu LLVM bit kodunda i8 * olarak temsil etmemiz gerekir.
// Burada kullanılan sıralama bunu sağlar ve yalnızca özel değişkenlere sahip olarak "raw" türünün kötüye kullanılmasını önler.
// İki değişkene ihtiyacımız var, çünkü derleyici repr özniteliğinden aksi halde şikayet ediyor ve en az bir değişkene ihtiyacımız var, aksi takdirde numaralandırma kullanılamaz ve en azından bu tür işaretçilerin referanslarının kaldırılması UB olur.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Bir `va_list` in temel uygulaması.
// Adı WIP, şimdilik `VaListImpl` kullanıyor.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` üzerinde değişmez, bu nedenle her `VaListImpl<'f>` nesnesi, içinde tanımlandığı işlevin bölgesine bağlanır.
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 `va_list` in ABI uygulaması.
/// Daha fazla ayrıntı için [AArch64 Procedure Call Standard] e bakın.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC `va_list` in ABI uygulaması.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 `va_list` in ABI uygulaması.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` için bir paketleyici
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Bir `VaListImpl` i, C'nin `va_list` iyle ikili uyumlu bir `VaList` e dönüştürün.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Bir `VaListImpl` i, C'nin `va_list` iyle ikili uyumlu bir `VaList` e dönüştürün.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait'nin genel arabirimlerde kullanılması gerekir, ancak trait'nin bu modül dışında kullanılmasına izin verilmemelidir.
// Kullanıcıların trait'yi yeni bir tür için uygulamalarına izin vermek (böylece va_arg intrinsic'in yeni bir tür üzerinde kullanılmasına izin vermek) muhtemelen tanımlanmamış davranışlara neden olacaktır.
//
// FIXME(dlrobertson): VaArgSafe trait'yi genel bir arabirimde kullanmak, ancak başka bir yerde de kullanılamadığından emin olmak için, trait'nin özel bir modül içinde herkese açık olması gerekir.
// RFC 2145 uygulandıktan sonra bunu iyileştirmeye bakın.
//
//
//
//
mod sealed_trait {
    /// İzin verilen türlerin [super::VaListImpl::arg] ile kullanılmasına izin veren Trait.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Bir sonraki argümana geçin.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // GÜVENLİK: Arayan kişi `va_arg` için güvenlik sözleşmesine uymalıdır.
        unsafe { va_arg(self) }
    }

    /// Mevcut konumdaki `va_list` i kopyalar.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // GÜVENLİK: Arayan kişi `va_end` için güvenlik sözleşmesine uymalıdır.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // GÜVENLİK: `MaybeUninit` e yazıyoruz, böylece başlatılıyor ve `assume_init` yasal
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: bu `va_end` i aramalıdır, ancak bunu yapmanın temiz bir yolu yoktur.
        // `drop` in her zaman arayana dahil edilmesini garanti eder, böylece `va_end`, karşılık gelen `va_copy` ile aynı işlevden doğrudan çağrılır.
        // `man va_end` C'nin bunu gerektirdiğini ve LLVM'nin temelde C semantiğini izlediğini belirtir, bu nedenle `va_end` in her zaman `va_copy` ile aynı işlevden çağrıldığından emin olmamız gerekir.
        //
        // Daha fazla ayrıntı için, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Bu şimdilik işe yarıyor, çünkü `va_end` mevcut tüm LLVM hedeflerinde işlemsiz.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` veya `va_copy` ile başlattıktan sonra arglist `ap` i yok edin.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Arglist `src` in mevcut konumunu arglist `dst` e kopyalar.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` ten `T` tipi bir argüman yükler ve `ap` in işaret ettiği argümanı arttırır.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}