use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Derleyicinin otomatik olarak "T" nin yıkıcısını çağırmasını engelleyen bir sarmalayıcı.
/// Bu ambalaj 0 maliyetlidir.
///
/// `ManuallyDrop<T>` `T` ile aynı düzen optimizasyonlarına tabidir.
/// Sonuç olarak, derleyicinin içeriği hakkında yaptığı varsayımlar üzerinde *hiçbir etkisi yoktur*.
/// Örneğin, `ManuallyDrop<&mut T>` i [`mem::zeroed`] ile başlatmak tanımsız bir davranıştır.
/// Başlatılmamış verileri işlemeniz gerekiyorsa, bunun yerine [`MaybeUninit<T>`] kullanın.
///
/// Bir `ManuallyDrop<T>` içindeki değere erişmenin güvenli olduğunu unutmayın.
/// Bu, içeriği düşürülmüş bir `ManuallyDrop<T>` in genel güvenli bir API aracılığıyla açığa çıkarılmaması gerektiği anlamına gelir.
/// Buna paralel olarak, `ManuallyDrop::drop` güvensizdir.
///
/// # `ManuallyDrop` ve sipariş bırak.
///
/// Rust, iyi tanımlanmış [drop order] değerlerine sahiptir.
/// Alanların veya yerellerin belirli bir sırada bırakıldığından emin olmak için, bildirimleri örtük bırakma sırası doğru olacak şekilde yeniden sıralayın.
///
/// Bırakma sırasını kontrol etmek için `ManuallyDrop` kullanmak mümkündür, ancak bu güvenli olmayan kod gerektirir ve çözülme durumunda doğru şekilde yapılması zordur.
///
///
/// Örneğin, belirli bir alanın diğerlerinden sonra bırakıldığından emin olmak istiyorsanız, bunu bir yapının son alanı yapın:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` ten sonra bırakılacaktır.
///     // Rust, alanların bildirim sırasına göre kaldırılmasını garanti eder.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Manuel olarak bırakılacak bir değeri sarın.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Hala güvenle değer üzerinde çalışabilirsiniz
    /// assert_eq!(*x, "Hello");
    /// // Ancak `Drop` burada çalıştırılmayacak
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Değeri `ManuallyDrop` kapsayıcısından çıkarır.
    ///
    /// Bu, değerin tekrar düşürülmesine izin verir.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Bu, `Box` i düşürür.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` kapsayıcısındaki değeri çıkarır.
    ///
    /// Bu yöntem esas olarak değerleri düşerken dışarı taşımak için tasarlanmıştır.
    /// Değeri manuel olarak düşürmek için [`ManuallyDrop::drop`] kullanmak yerine, değeri almak ve istediğiniz gibi kullanmak için bu yöntemi kullanabilirsiniz.
    ///
    /// Mümkün olduğunda, `ManuallyDrop<T>` içeriğinin kopyalanmasını önleyen [`into_inner`][`ManuallyDrop::into_inner`] kullanılması tercih edilir.
    ///
    ///
    /// # Safety
    ///
    /// Bu işlev, daha fazla kullanımı engellemeden içerilen değeri anlamsal olarak dışarı taşır ve bu kabın durumunu değiştirmeden bırakır.
    /// Bu `ManuallyDrop` in tekrar kullanılmamasını sağlamak sizin sorumluluğunuzdadır.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // GÜVENLİK: garantili bir referanstan okuyoruz
        // okumalar için geçerli olması.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// İçerdiği değeri manuel olarak düşürür.Bu, [`ptr::drop_in_place`] i içerilen değere bir gösterici ile çağırmaya tam olarak eşdeğerdir.
    /// Bu nedenle, içerilen değer paketlenmiş bir yapı olmadığı sürece, yıkıcı değeri hareket ettirmeden yerinde çağrılır ve böylece [pinned] verilerini güvenli bir şekilde bırakmak için kullanılabilir.
    ///
    /// Değerin sahibi sizseniz, bunun yerine [`ManuallyDrop::into_inner`] i kullanabilirsiniz.
    ///
    /// # Safety
    ///
    /// Bu işlev, içerilen değerin yıkıcısını çalıştırır.
    /// Yıkıcının kendisi tarafından yapılan değişiklikler dışında, bellek değişmeden bırakılır ve derleyici söz konusu olduğu sürece, `T` tipi için geçerli olan bir bit modelini tutmaya devam eder.
    ///
    ///
    /// Ancak bu "zombie" değeri güvenli koda maruz bırakılmamalı ve bu işlev birden fazla çağrılmamalıdır.
    /// Düşürüldükten sonra bir değer kullanmak veya bir değeri birden çok kez düşürmek, Tanımsız Davranışa neden olabilir (`drop` in ne yaptığına bağlı olarak).
    /// Bu normalde tip sistemi tarafından engellenir, ancak `ManuallyDrop` kullanıcılarının bu garantileri derleyicinin yardımı olmadan sürdürmeleri gerekir.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // GÜVENLİK: değişken bir referansla gösterilen değeri düşürüyoruz
        // yazmalar için geçerli olması garantilidir.
        // `slot` in tekrar düşürülmemesi arayan kişiye bağlıdır.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}