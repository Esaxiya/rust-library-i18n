use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Başlatılmamış `T` örneklerini oluşturmak için bir sarmalayıcı türü.
///
/// # Başlatma değişmez
///
/// Derleyici, genel olarak, bir değişkenin, değişken türünün gereksinimlerine göre uygun şekilde başlatıldığını varsayar.Örneğin, referans türündeki bir değişken hizalanmalı ve NULL olmamalıdır.
/// Bu, güvenli olmayan kodda bile *her zaman* korunması gereken bir değişmezdir.
/// Sonuç olarak, referans türündeki bir değişkeni sıfırlamak, bu referansın belleğe erişmek için kullanılıp kullanılmadığına bakılmaksızın, anında [undefined behavior][ub] e neden olur:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // tanımsız davranış!⚠️
/// // `MaybeUninit<&i32>` ile eşdeğer kod:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // tanımsız davranış!⚠️
/// ```
///
/// Bu, derleyici tarafından çalışma zamanı kontrollerini ortadan kaldırmak ve `enum` düzenini optimize etmek gibi çeşitli optimizasyonlar için kullanır.
///
/// Benzer şekilde, tamamen başlatılmamış bellek herhangi bir içeriğe sahip olabilirken, `bool` her zaman `true` veya `false` olmalıdır.Bu nedenle, başlatılmamış bir `bool` oluşturmak tanımsız bir davranıştır:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // tanımsız davranış!⚠️
/// // `MaybeUninit<bool>` ile eşdeğer kod:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // tanımsız davranış!⚠️
/// ```
///
/// Ayrıca, başlatılmamış bellek sabit bir değere sahip olmaması açısından özeldir ("fixed", "it won't change without being written to" anlamına gelir).Aynı başlatılmamış baytı birden çok kez okumak farklı sonuçlar verebilir.
/// Bu, değişken bir tamsayı türüne sahip olsa bile, bir değişkende başlatılmamış veriye sahip olmayı tanımsız bir davranış haline getirir, aksi takdirde *sabit* bit modelini tutabilir:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // tanımsız davranış!⚠️
/// // `MaybeUninit<i32>` ile eşdeğer kod:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // tanımsız davranış!⚠️
/// ```
/// (Başlatılmamış tamsayılarla ilgili kuralların henüz kesinleşmediğine dikkat edin, ancak tamamlanıncaya kadar bunlardan kaçınmanız önerilir.)
///
/// Bunun da ötesinde, çoğu türün yalnızca tür düzeyinde başlatılmış sayılmanın ötesinde ek değişmezlere sahip olduğunu unutmayın.
/// Örneğin, "1" ile başlatılmış bir [`Vec<T>`] başlatılmış olarak kabul edilir (mevcut uygulama altında; bu kararlı bir garanti oluşturmaz) çünkü derleyicinin bildiği tek gereksinim, veri göstericisinin boş olmaması gerektiğidir.
/// Böyle bir `Vec<T>` in oluşturulması *anında* tanımsız davranışa neden olmaz, ancak çoğu güvenli işlemle (düşürmek dahil) tanımlanmamış davranışlara neden olur.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` güvenli olmayan kodun başlatılmamış verilerle başa çıkmasını sağlar.
/// Derleyiciye buradaki verilerin *başlatılamayacağını* belirten bir sinyaldir:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Açıkça başlatılmamış bir referans oluşturun.
/// // Derleyici bir `MaybeUninit<T>` içindeki verilerin geçersiz olabileceğini bilir ve dolayısıyla bu UB değildir:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Geçerli bir değere ayarlayın.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Başlatılan verileri çıkarın-buna yalnızca `x` düzgün şekilde başlatıldıktan *sonra* izin verilir!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Derleyici daha sonra bu kod üzerinde herhangi bir yanlış varsayım veya optimizasyon yapmayacağını bilir.
///
/// `MaybeUninit<T>` i biraz `Option<T>` gibi düşünebilirsiniz, ancak herhangi bir çalışma süresi takibi ve herhangi bir güvenlik kontrolü olmadan.
///
/// ## out-pointers
///
/// "out-pointers" i uygulamak için `MaybeUninit<T>` i kullanabilirsiniz: bir fonksiyondan veri döndürmek yerine, sonucu içine koymak için bazı (uninitialized) belleğine bir işaretçi iletin.
/// Bu, arayanın sonucun depolandığı belleğin nasıl tahsis edileceğini kontrol etmesi önemli olduğunda ve gereksiz hareketlerden kaçınmak istediğinizde yararlı olabilir.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` önemli olan eski içeriği düşürmez.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Artık `v` in başlatıldığını biliyoruz!Bu ayrıca vector'nin düzgün şekilde düşürülmesini sağlar.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Bir dizi öğesi öğe başlatma
///
/// `MaybeUninit<T>` eleman eleman büyük bir dizi başlatmak için kullanılabilir:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Başlatılmamış bir `MaybeUninit` dizisi oluşturun.
///     // `assume_init` güvenlidir çünkü burada başlattığımızı iddia ettiğimiz tür, başlatma gerektirmeyen bir grup "MaybeUninit" dir.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Bir `MaybeUninit` i düşürmek hiçbir şey yapmaz.
///     // Bu nedenle, `ptr::write` yerine ham işaretçi atamasının kullanılması, eski başlatılmamış değerin düşmesine neden olmaz.
/////
///     // Ayrıca bu döngü sırasında bir panic varsa, bir bellek sızıntımız var, ancak bellek güvenliği sorunu yok.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Her şey başlatıldı.
///     // Diziyi başlatılmış türe dönüştürün.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Düşük seviyeli veri yapılarında bulunabilen kısmen başlatılmış dizilerle de çalışabilirsiniz.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Başlatılmamış bir `MaybeUninit` dizisi oluşturun.
/// // `assume_init` güvenlidir çünkü burada başlattığımızı iddia ettiğimiz tür, başlatma gerektirmeyen bir grup "MaybeUninit" dir.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Atadığımız elemanların sayısını sayın.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Dizideki her öğe için, ayırırsak bırakın.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Alan bazında bir yapı başlatma
///
/// Yapıları alanlara göre başlatmak için `MaybeUninit<T>` ve [`std::ptr::addr_of_mut`] makrosunu kullanabilirsiniz:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` alanını başlatma
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` alanını başlatma Burada bir panic varsa, `name` alanındaki `String` sızıntı yapar.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Tüm alanlar başlatılır, bu nedenle başlatılmış bir Foo almak için `assume_init` i çağırırız.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` ile aynı boyuta, hizaya ve ABI'ye sahip olması garanti edilir:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Ancak, bir `MaybeUninit<T>` i *içeren* bir türün mutlaka aynı düzende olması gerekmediğini unutmayın;Rust, genel olarak, `T` ve `U` aynı boyut ve hizalamaya sahip olsa bile, bir `Foo<T>` in alanlarının `Foo<U>` ile aynı sıraya sahip olduğunu garanti etmez.
///
/// Ayrıca, herhangi bir bit değeri bir `MaybeUninit<T>` için geçerli olduğundan, derleyici non-zero/niche-filling optimizasyonlarını uygulayamaz ve potansiyel olarak daha büyük bir boyuta neden olur:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` FFI güvenliyse, `MaybeUninit<T>` de öyledir.
///
/// `MaybeUninit` `#[repr(transparent)]` iken (`T` ile aynı boyutu, hizalamayı ve ABI'yi garanti ettiğini gösterir), bu önceki uyarıların hiçbirini *değiştirmez*.
/// `Option<T>` ve `Option<MaybeUninit<T>>` hala farklı boyutlara sahip olabilir ve `T` tipi bir alan içeren tipler, bu alanın `MaybeUninit<T>` olmasından farklı bir şekilde yerleştirilebilir (ve boyutlandırılabilir).
/// `MaybeUninit` bir birleşim türüdür ve sendikalarda `#[repr(transparent)]` dengesizdir (bkz. [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Zamanla, `#[repr(transparent)]` in sendikalar üzerindeki kesin garantileri değişebilir ve `MaybeUninit`, `#[repr(transparent)]` olarak kalabilir veya kalmayabilir.
/// Bununla birlikte, `MaybeUninit<T>`*her zaman*`T` ile aynı boyuta, hizalamaya ve ABI'ye sahip olduğunu garanti edecektir;sadece `MaybeUninit` in bu garantiyi uygulama şekli gelişebilir.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Diğer türleri içine sarabilmemiz için dil öğesi.Bu, jeneratörler için kullanışlıdır.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` i aramıyoruz, bunun için yeterince başlatılıp başlatılmadığımızı bilemeyiz.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Verilen değerle başlatılan yeni bir `MaybeUninit<T>` oluşturur.
    /// Bu işlevin dönüş değeri üzerinde [`assume_init`] i çağırmak güvenlidir.
    ///
    /// Bir `MaybeUninit<T>` i düşürmenin asla "T" nin bırakma kodunu çağırmayacağını unutmayın.
    /// Başlatılırsa `T` in düşürülmesini sağlamak sizin sorumluluğunuzdadır.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Başlatılmamış durumda yeni bir `MaybeUninit<T>` oluşturur.
    ///
    /// Bir `MaybeUninit<T>` i düşürmenin asla "T" nin bırakma kodunu çağırmayacağını unutmayın.
    /// Başlatılırsa `T` in düşürülmesini sağlamak sizin sorumluluğunuzdadır.
    ///
    /// Bazı örnekler için [type-level documentation][MaybeUninit] e bakın.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Başlatılmamış bir durumda yeni bir `MaybeUninit<T>` öğe dizisi oluşturun.
    ///
    /// Note: bir future Rust sürümünde, dizi değişmez sözdizimi [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) e izin verdiğinde bu yöntem gereksiz hale gelebilir.
    ///
    /// Aşağıdaki örnek daha sonra `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` i kullanabilir.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Gerçekte okunmuş (muhtemelen daha küçük) bir veri dilimi döndürür
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // GÜVENLİK: Başlatılmamış bir `[MaybeUninit<_>; LEN]` geçerlidir.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Hafızanın `0` baytlarla doldurulduğu, başlatılmamış durumda yeni bir `MaybeUninit<T>` oluşturur.Bunun zaten uygun şekilde başlatılıp başlatılmayacağı `T` e bağlıdır.
    ///
    /// Örneğin, `MaybeUninit<usize>::zeroed()` başlatılır, ancak `MaybeUninit<&'static i32>::zeroed()`, referansların boş olmaması gerektiğinden değildir.
    ///
    /// Bir `MaybeUninit<T>` i düşürmenin asla "T" nin bırakma kodunu çağırmayacağını unutmayın.
    /// Başlatılırsa `T` in düşürülmesini sağlamak sizin sorumluluğunuzdadır.
    ///
    /// # Example
    ///
    /// Bu fonksiyonun doğru kullanımı: yapının tüm alanlarının 0 bit modelini geçerli bir değer olarak tutabildiği bir yapıyı sıfır ile başlatmak.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// Bu işlevin *yanlış* kullanımı: `0`, tür için geçerli bir bit modeli olmadığında `x.zeroed().assume_init()` in çağrılması:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Bir çiftin içinde, geçerli bir ayırıcıya sahip olmayan bir `NotZero` oluştururuz.
    /// // Bu tanımlanmamış bir davranıştır.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // GÜVENLİK: `u.as_mut_ptr()`, ayrılmış belleği işaret eder.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` in değerini ayarlar.
    /// Bu, herhangi bir önceki değeri düşürmeden üzerine yazar, bu yüzden yıkıcıyı çalıştırmayı atlamak istemiyorsanız, bunu iki kez kullanmamaya dikkat edin.
    ///
    /// Size kolaylık sağlamak için, bu aynı zamanda `self` in (artık güvenli bir şekilde başlatılmış) içeriklerine değiştirilebilir bir referans döndürür.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // GÜVENLİK: Bu değeri yeni başlattık.
        unsafe { self.assume_init_mut() }
    }

    /// İçerilen değere bir işaretçi alır.
    /// Bu işaretçiden okumak veya onu bir referansa dönüştürmek, `MaybeUninit<T>` başlatılmadıkça tanımsız bir davranıştır.
    /// Bu işaretçi (non-transitively) in işaret ettiği belleğe yazmak tanımsız bir davranıştır (bir `UnsafeCell<T>` in içinde olanlar hariç).
    ///
    /// # Examples
    ///
    /// Bu yöntemin doğru kullanımı:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` e bir referans oluşturun.Sorun değil çünkü onu başlattık.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Bu yöntemin *yanlış* kullanımı:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Başlatılmamış bir vector için bir referans oluşturduk!Bu tanımlanmamış bir davranıştır.⚠️
    /// ```
    ///
    /// (Başlatılmamış verilere referanslarla ilgili kuralların henüz kesinleşmediğine dikkat edin, ancak tamamlanıncaya kadar bunlardan kaçınmanız önerilir.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ve `ManuallyDrop` in her ikisi de `repr(transparent)` olduğundan işaretçiyi atabiliriz.
        self as *const _ as *const T
    }

    /// İçerilen değere değiştirilebilir bir işaretçi alır.
    /// Bu işaretçiden okumak veya onu bir referansa dönüştürmek, `MaybeUninit<T>` başlatılmadıkça tanımsız bir davranıştır.
    ///
    /// # Examples
    ///
    /// Bu yöntemin doğru kullanımı:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` e bir referans oluşturun.
    /// // Sorun değil çünkü onu başlattık.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Bu yöntemin *yanlış* kullanımı:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Başlatılmamış bir vector için bir referans oluşturduk!Bu tanımlanmamış bir davranıştır.⚠️
    /// ```
    ///
    /// (Başlatılmamış verilere referanslarla ilgili kuralların henüz kesinleşmediğine dikkat edin, ancak tamamlanıncaya kadar bunlardan kaçınmanız önerilir.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ve `ManuallyDrop` in her ikisi de `repr(transparent)` olduğundan işaretçiyi atabiliriz.
        self as *mut _ as *mut T
    }

    /// Değeri `MaybeUninit<T>` kapsayıcısından çıkarır.Bu, verilerin düşmesini sağlamanın harika bir yoludur, çünkü ortaya çıkan `T`, olağan düşürme işlemine tabidir.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` in gerçekten başlatılmış durumda olduğunu garanti etmek arayan kişiye bağlıdır.İçerik henüz tam olarak başlatılmadığında bunu çağırmak, anında tanımlanmamış davranışa neden olur.
    /// [type-level documentation][inv], bu başlatma değişmezi hakkında daha fazla bilgi içerir.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Bunun da ötesinde, çoğu türün yalnızca tür düzeyinde başlatılmış sayılmanın ötesinde ek değişmezlere sahip olduğunu unutmayın.
    /// Örneğin, "1" ile başlatılmış bir [`Vec<T>`] başlatılmış olarak kabul edilir (mevcut uygulama altında; bu kararlı bir garanti oluşturmaz) çünkü derleyicinin bildiği tek gereksinim, veri göstericisinin boş olmaması gerektiğidir.
    ///
    /// Böyle bir `Vec<T>` in oluşturulması *anında* tanımsız davranışa neden olmaz, ancak çoğu güvenli işlemle (düşürmek dahil) tanımlanmamış davranışlara neden olur.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Bu yöntemin doğru kullanımı:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Bu yöntemin *yanlış* kullanımı:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` henüz başlatılmamıştı, bu nedenle bu son satır tanımsız davranışa neden oldu.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // GÜVENLİK: Arayan, `self` in başlatıldığını garanti etmelidir.
        // Bu aynı zamanda `self` in bir `value` varyantı olması gerektiği anlamına gelir.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` konteynerindeki değeri okur.Ortaya çıkan `T`, normal düşürme işlemine tabidir.
    ///
    /// Mümkün olduğunda, `MaybeUninit<T>` içeriğinin kopyalanmasını önleyen [`assume_init`] kullanılması tercih edilir.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` in gerçekten başlatılmış durumda olduğunu garanti etmek arayan kişiye bağlıdır.İçerik henüz tam olarak başlatılmadığında bunu çağırmak tanımsız davranışa neden olur.
    /// [type-level documentation][inv], bu başlatma değişmezi hakkında daha fazla bilgi içerir.
    ///
    /// Dahası, bu `MaybeUninit<T>` te aynı verilerin bir kopyasını geride bırakır.
    /// Verilerin birden çok kopyasını kullanırken (`assume_init_read` i birden çok kez arayarak veya önce `assume_init_read` ve ardından [`assume_init`] i arayarak), verilerin gerçekten kopyalanmasını sağlamak sizin sorumluluğunuzdadır.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Bu yöntemin doğru kullanımı:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` olduğundan, birden çok kez okuyabiliriz.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Bir `None` değerini çoğaltmak sorun değil, bu yüzden birden çok kez okuyabiliriz.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Bu yöntemin *yanlış* kullanımı:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Şimdi aynı vector'nin iki kopyasını oluşturduk, böylece ikisi de düştüğünde çifte ücretsiz ⚠️ elde ettik!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // GÜVENLİK: Arayan, `self` in başlatıldığını garanti etmelidir.
        // `self.as_ptr()` ten okumak, `self` in başlatılması gerektiğinden güvenlidir.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// İçerilen değeri yerinde düşürür.
    ///
    /// `MaybeUninit` in sahibiyseniz, bunun yerine [`assume_init`] i kullanabilirsiniz.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` in gerçekten başlatılmış durumda olduğunu garanti etmek arayan kişiye bağlıdır.İçerik henüz tam olarak başlatılmadığında bunu çağırmak tanımsız davranışa neden olur.
    ///
    /// Üstelik, `T` in (veya üyelerinin) `Drop` uygulaması buna güvenebileceğinden, `T` türünün tüm ek değişmezleri karşılanmalıdır.
    /// Örneğin, "1" ile başlatılmış bir [`Vec<T>`] başlatılmış olarak kabul edilir (mevcut uygulama altında; bu kararlı bir garanti oluşturmaz) çünkü derleyicinin bildiği tek gereksinim, veri göstericisinin boş olmaması gerektiğidir.
    ///
    /// Ancak böyle bir `Vec<T>` i düşürmek tanımsız davranışa neden olur.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // GÜVENLİK: Arayan kişi, `self` in başlatıldığını ve
        // `T` in tüm değişmezlerini karşılar.
        // Bu durumda değeri yerinde düşürmek güvenlidir.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// İçerilen değere paylaşılan bir başvuru alır.
    ///
    /// Bu, başlatılmış ancak `MaybeUninit` e sahip olmayan bir `MaybeUninit` e erişmek istediğimizde yararlı olabilir (`.assume_init()`) in kullanımını engelliyor.
    ///
    /// # Safety
    ///
    /// İçerik henüz tam olarak başlatılmadığında bunu çağırmak tanımsız davranışa neden olur: `MaybeUninit<T>` in gerçekten başlatılmış durumda olduğundan emin olmak arayan kişiye bağlıdır.
    ///
    ///
    /// # Examples
    ///
    /// ### Bu yöntemin doğru kullanımı:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` i başlatın:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Artık `MaybeUninit<_>` inizin başlatıldığı bilindiğine göre, ona paylaşılan bir referans oluşturmakta sorun yoktur:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // GÜVENLİK: `x` başlatıldı.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Bu yöntemin *yanlış* kullanımları:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Başlatılmamış bir vector için bir referans oluşturduk!Bu tanımlanmamış bir davranıştır.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` kullanarak `MaybeUninit` i başlatın:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Başlatılmamış bir `Cell<bool>` e referans: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // GÜVENLİK: Arayan, `self` in başlatıldığını garanti etmelidir.
        // Bu aynı zamanda `self` in bir `value` varyantı olması gerektiği anlamına gelir.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// İçerilen değere değiştirilebilir bir (unique) başvurusu alır.
    ///
    /// Bu, başlatılmış ancak `MaybeUninit` e sahip olmayan bir `MaybeUninit` e erişmek istediğimizde yararlı olabilir (`.assume_init()`) in kullanımını engelliyor.
    ///
    /// # Safety
    ///
    /// İçerik henüz tam olarak başlatılmadığında bunu çağırmak tanımsız davranışa neden olur: `MaybeUninit<T>` in gerçekten başlatılmış durumda olduğundan emin olmak arayan kişiye bağlıdır.
    /// Örneğin, `.assume_init_mut()`, bir `MaybeUninit` i başlatmak için kullanılamaz.
    ///
    /// # Examples
    ///
    /// ### Bu yöntemin doğru kullanımı:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Giriş arabelleğinin *tüm* baytlarını başlatır.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` i başlatın:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Artık `buf` in başlatıldığını biliyoruz, böylece `.assume_init()` yapabiliriz.
    /// // Ancak, `.assume_init()` kullanmak 2048 baytlık bir `memcpy` i tetikleyebilir.
    /// // Arabelleğimizin kopyalanmadan başlatıldığını iddia etmek için `&mut MaybeUninit<[u8; 2048]>` i `&mut [u8; 2048]` e yükselttik:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // GÜVENLİK: `buf` başlatıldı.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Artık `buf` i normal bir dilim olarak kullanabiliriz:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Bu yöntemin *yanlış* kullanımları:
    ///
    /// Bir değeri başlatmak için `.assume_init_mut()` i kullanamazsınız:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Başlatılmamış bir `bool` e bir (mutable) referansı oluşturduk!
    ///     // Bu tanımlanmamış bir davranıştır.⚠️
    /// }
    /// ```
    ///
    /// Örneğin, başlatılmamış bir arabelleğe [`Read`] koyamazsınız:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) başlatılmamış belleğe referans!
    ///                             // Bu tanımlanmamış bir davranıştır.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Alan bazında kademeli başlatma yapmak için doğrudan alan erişimini de kullanamazsınız:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) başlatılmamış belleğe referans!
    ///                  // Bu tanımlanmamış bir davranıştır.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) başlatılmamış belleğe referans!
    ///                  // Bu tanımlanmamış bir davranıştır.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Şu anda yukarıdakilerin yanlış olduğuna güveniyoruz, yani başlatılmamış verilere referanslarımız var (örneğin, `libcore/fmt/float.rs` te).
    // İstikrara kavuşmadan önce kurallar hakkında son bir karar vermeliyiz.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // GÜVENLİK: Arayan, `self` in başlatıldığını garanti etmelidir.
        // Bu aynı zamanda `self` in bir `value` varyantı olması gerektiği anlamına gelir.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Bir `MaybeUninit` kapsayıcı dizisinden değerleri çıkarır.
    ///
    /// # Safety
    ///
    /// Dizinin tüm öğelerinin başlatılmış durumda olmasını garanti etmek arayana bağlıdır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // GÜVENLİK: Tüm öğeleri ilklendirdiğimiz için artık güvenli
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Arayan, dizinin tüm öğelerinin başlatıldığını garanti eder
        // * `MaybeUninit<T>` ve T'nin aynı düzene sahip olması garanti edilir
        // * BelkiUnint düşmez, bu nedenle çift serbestlik yoktur ve bu nedenle dönüşüm güvenlidir
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Tüm elemanların başlatıldığını varsayarak, onlara bir dilim alın.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` elemanlarının gerçekten başlatılmış durumda olduğundan emin olmak arayan kişiye bağlıdır.
    ///
    /// İçerik henüz tam olarak başlatılmadığında bunu çağırmak tanımsız davranışa neden olur.
    ///
    /// Daha fazla ayrıntı ve örnek için [`assume_init_ref`] e bakın.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // GÜVENLİK: Arayan kişi bunu garanti ettiği için `*const [T]` e dilim atmak güvenlidir
        // `slice` başlatılır ve "BelkiUninit" in `T` ile aynı düzene sahip olacağı garanti edilir.
        // Elde edilen işaretçi, referans olan ve dolayısıyla okumalar için geçerli olması garantili olan `slice` e ait belleğe atıfta bulunduğundan geçerlidir.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Tüm elemanların başlatıldığını varsayarak, onlara değiştirilebilir bir dilim alın.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` elemanlarının gerçekten başlatılmış durumda olduğundan emin olmak arayan kişiye bağlıdır.
    ///
    /// İçerik henüz tam olarak başlatılmadığında bunu çağırmak tanımsız davranışa neden olur.
    ///
    /// Daha fazla ayrıntı ve örnek için [`assume_init_mut`] e bakın.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // GÜVENLİK: `slice_get_ref` için güvenlik notlarına benzer, ancak bizde
        // Yazmalar için de geçerli olması garantili olan değiştirilebilir referans.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Dizinin ilk öğesine bir işaretçi alır.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Dizinin ilk öğesine değiştirilebilir bir işaretçi alır.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` den `this` e öğeleri kopyalar ve `this` in artık aktifleştirilmiş içeriğine değiştirilebilir bir referans döndürür.
    ///
    /// `T`, `Copy` i uygulamıyorsa, [`write_slice_cloned`] i kullanın
    ///
    /// Bu, [`slice::copy_from_slice`] e benzer.
    ///
    /// # Panics
    ///
    /// İki dilim farklı uzunluklara sahipse bu işlev panic olacaktır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // GÜVENLİK: Len'in tüm unsurlarını az önce yedek kapasiteye kopyaladık
    /// // vec'in ilk src.len() elemanları artık geçerlidir.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // GÜVENLİK: &[T] ve&[MaybeUninit<T>] aynı düzene sahip
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // GÜVENLİK: Geçerli öğeler az önce `this` e kopyalandı, bu nedenle başlangıç durumuna getirildi
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Öğeleri `src` ten `this` e klonlar ve `this` in artık haritalandırılmış içeriğine değiştirilebilir bir referans döndürür.
    /// Zaten büyük harfle yazılmış herhangi bir öğe bırakılmayacaktır.
    ///
    /// `T`, `Copy` i uygularsa, [`write_slice`] i kullanın
    ///
    /// Bu, [`slice::clone_from_slice`] e benzer, ancak mevcut öğeleri düşürmez.
    ///
    /// # Panics
    ///
    /// Bu işlev, iki dilim farklı uzunluklara sahipse veya `Clone` panics uygulamasıysa panic olacaktır.
    ///
    /// Bir panic varsa, önceden klonlanmış öğeler bırakılacaktır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // GÜVENLİK: len'in tüm unsurlarını yedek kapasiteye klonladık
    /// // vec'in ilk src.len() elemanları artık geçerlidir.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice'ın aksine bu, dilim üzerinde clone_from_slice'ı çağırmaz, bunun nedeni `MaybeUninit<T: Clone>` in Klonu uygulamamasıdır.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // GÜVENLİK: bu ham dilim yalnızca başlatılmış nesneleri içerecektir
                // bu yüzden düşürmesine izin veriliyor.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Onları açıkça aynı uzunlukta dilimlemeliyiz
        // sınır kontrolünün atlanması ve optimize edici basit durumlar için memcpy üretecektir (örneğin T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // koruma gereklidir b/c panic bir klon sırasında meydana gelebilir
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // GÜVENLİK: Geçerli öğeler `this` e henüz yazılmıştır, bu nedenle başlangıç durumuna getirilmiştir
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}