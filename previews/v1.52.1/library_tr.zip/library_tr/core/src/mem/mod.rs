//! Hafıza ile uğraşmak için temel fonksiyonlar.
//!
//! Bu modül, türlerin boyutunu ve hizalamasını sorgulamak, belleği başlatmak ve değiştirmek için işlevler içerir.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Yok ediciyi çalıştırmadan **değeri hakkında sahiplik ve "forgets" alır**.
///
/// Yığın bellek veya dosya tanıtıcısı gibi değerin yönettiği herhangi bir kaynak, erişilemez bir durumda sonsuza kadar kalacaktır.Ancak, bu belleğe yönelik işaretçilerin geçerli kalacağını garanti etmez.
///
/// * Bellek sızdırmak istiyorsanız, [`Box::leak`] e bakın.
/// * Hafızaya ham bir işaretçi elde etmek istiyorsanız, bkz. [`Box::into_raw`].
/// * Bir değeri düzgün bir şekilde yok etmek istiyorsanız, yok ediciyi çalıştırarak, bkz. [`mem::drop`].
///
/// # Safety
///
/// `forget` Rust'nin güvenlik garantileri, yıkıcıların her zaman çalışacağına dair bir garanti içermediğinden, `unsafe` olarak işaretlenmemiştir.
/// Örneğin, bir program [`Rc`][rc] kullanarak bir referans döngüsü oluşturabilir veya yıkıcıları çalıştırmadan çıkmak için [`process::exit`][exit] i çağırabilir.
/// Bu nedenle, `mem::forget` in güvenli koddan izin verilmesi, Rust'nin güvenlik garantilerini temelden değiştirmez.
///
/// Bununla birlikte, bellek veya I/O nesneleri gibi kaynakların sızdırılması genellikle istenmeyen bir durumdur.
/// FFI veya güvenli olmayan kod için bazı özel kullanım durumlarında ihtiyaç ortaya çıkar, ancak o zaman bile, genellikle [`ManuallyDrop`] tercih edilir.
///
/// Bir değeri unutmaya izin verildiğinden, yazdığınız herhangi bir `unsafe` kodu bu olasılığa izin vermelidir.Bir değer döndüremez ve arayanın mutlaka değerin yıkıcısını çalıştırmasını bekleyemezsiniz.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` in kanonik güvenli kullanımı, `Drop` trait tarafından uygulanan bir değerin yıkıcısını aşmaktır.Örneğin, bu bir `File` sızdırır, yani
/// değişkenin kapladığı alanı geri kazanın, ancak temeldeki sistem kaynağını asla kapatmayın:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Bu, temeldeki kaynağın sahipliği önceden Rust dışındaki koda aktarıldığında, örneğin ham dosya tanımlayıcısının C koduna aktarılmasıyla yararlıdır.
///
/// # `ManuallyDrop` ile İlişki
///
/// `mem::forget` ayrıca *bellek* sahipliğini aktarmak için de kullanılabilir, ancak bunu yapmak hataya açıktır.
/// [`ManuallyDrop`] bunun yerine kullanılmalıdır.Örneğin şu kodu düşünün:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` in içeriğini kullanarak bir `String` oluşturun
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` sızıntısı çünkü belleği artık `s` tarafından yönetiliyor
/// mem::forget(v);  // HATA, v geçersiz ve bir işleve geçirilmemelidir
/// assert_eq!(s, "Az");
/// // `s` dolaylı olarak bırakılır ve hafızası serbest bırakılır.
/// ```
///
/// Yukarıdaki örnekte iki sorun var:
///
/// * `String` in yapısı ve `mem::forget()` in çağrılması arasına daha fazla kod eklenirse, içindeki bir panic çift boşluğa neden olur çünkü aynı bellek hem `v` hem de `s` tarafından işlenir.
/// * `v.as_mut_ptr()` i aradıktan ve verilerin sahipliğini `s` e ilettikten sonra, `v` değeri geçersizdir.
/// Bir değer `mem::forget` e yeni taşındığında bile (bu onu incelemeyecektir), bazı türlerin değerleri üzerinde, sarkarken veya artık sahip olunmadığında onları geçersiz kılan katı gereksinimleri vardır.
/// Geçersiz değerleri herhangi bir şekilde kullanmak, onları işlevlere geçirmek veya işlevlerden döndürmek de dahil olmak üzere, tanımsız davranış oluşturur ve derleyici tarafından yapılan varsayımları bozabilir.
///
/// `ManuallyDrop` e geçiş her iki sorunu da önler:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // `v` i işlenmemiş parçalarına ayırmadan önce düşmediğinden emin olun!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Şimdi `v` i sökün.Bu işlemler panic olamaz, bu nedenle bir sızıntı olamaz.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Son olarak, bir `String` oluşturun.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` dolaylı olarak bırakılır ve hafızası serbest bırakılır.
/// ```
///
/// `ManuallyDrop` başka bir şey yapmadan önce "v" nin yıkıcısını devre dışı bıraktığımız için çift özgürlüğü sağlam bir şekilde önler.
/// `mem::forget()` buna izin vermiyor çünkü argümanını tüketiyor, bizi sadece `v` ten ihtiyacımız olan her şeyi çıkardıktan sonra aramaya zorluyor.
/// `ManuallyDrop` in yapımı ile dizginin oluşturulması arasında bir panic tanıtılsa bile (gösterildiği gibi kodda olamaz), bu bir sızıntıya neden olur ve çifte serbestlik olmaz.
/// Başka bir deyişle, `ManuallyDrop` (çift) düşme tarafında hata yapmak yerine sızıntı tarafında hata yapar.
///
/// Ayrıca, `ManuallyDrop`, mülkiyeti `s` e aktardıktan sonra "touch" `v` e sahip olmamızı engeller-`v` ile etkileşimde bulunmanın son adımı, yok ediciyi çalıştırmadan elden çıkarmaktan tamamen kaçınılır.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] gibi, ancak boyutlandırılmamış değerleri de kabul eder.
///
/// Bu işlev, yalnızca `unsized_locals` özelliği sabitlendiğinde kaldırılması amaçlanan bir şimdir.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Bir türün boyutunu bayt cinsinden döndürür.
///
/// Daha spesifik olarak, bu, hizalama dolgusu da dahil olmak üzere bu öğe türüne sahip bir dizideki ardışık öğeler arasındaki bayt cinsinden kaymadır.
///
/// Bu nedenle, herhangi bir `T` tipi ve `n` uzunluğu için, `[T; n]`, `n * size_of::<T>()` boyutuna sahiptir.
///
/// Genel olarak, bir türün boyutu derlemeler arasında sabit değildir, ancak ilkeller gibi belirli türler öyledir.
///
/// Aşağıdaki tablo ilkellerin boyutunu vermektedir.
///
/// Türü |boyutu: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 karakter |4
///
/// Ayrıca, `usize` ve `isize` aynı boyuta sahiptir.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` ve `Option<Box<T>>` tiplerinin tümü aynı boyuta sahiptir.
/// `T` Boyutlandırılmışsa, bu türlerin tümü `usize` ile aynı boyuta sahiptir.
///
/// Bir işaretçinin değişkenliği, boyutunu değiştirmez.Bu nedenle, `&T` ve `&mut T` aynı boyuta sahiptir.
/// Aynı şekilde `*const T` ve `* mut T` için.
///
/// # `#[repr(C)]` öğelerinin boyutu
///
/// Öğeler için `C` gösteriminin tanımlı bir düzeni vardır.
/// Bu düzen ile, tüm alanlar sabit bir boyuta sahip olduğu sürece öğelerin boyutu da sabittir.
///
/// ## Yapıların Boyutu
///
/// `structs` için boyut aşağıdaki algoritma ile belirlenir.
///
/// Bildirim sırasına göre sıralanmış yapıdaki her alan için:
///
/// 1. Alanın boyutunu ekleyin.
/// 2. Geçerli boyutu, sonraki alanın [alignment] inin en yakın katına yuvarlayın.
///
/// Son olarak, yapının boyutunu [alignment] in en yakın katına yuvarlayın.
/// Yapının hizalaması genellikle tüm alanlarının en büyük hizalamasıdır;bu `repr(align(N))` kullanımıyla değiştirilebilir.
///
/// `C` in aksine, sıfır boyutlu yapılar boyut olarak bir bayta yuvarlanmaz.
///
/// ## Numaralandırmanın Boyutu
///
/// Ayırıcı dışında hiçbir veri taşımayan numaralandırmalar, derlendikleri platformdaki C numaralandırmalarıyla aynı boyuta sahiptir.
///
/// ## Sendikaların Boyutu
///
/// Bir sendikanın boyutu, en büyük alanının boyutudur.
///
/// `C` ten farklı olarak, sıfır boyutlu birlikler boyut olarak bir bayta yuvarlanmaz.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Bazı ilkeller
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Bazı diziler
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // İşaretçi boyutu eşitliği
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` kullanarak.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // İlk alanın boyutu 1 olduğundan, boyuta 1 ekleyin.Boyut 1'dir.
/// // İkinci alanın hizası 2'dir, bu nedenle dolgu boyutuna 1 ekleyin.Boyut 2'dir.
/// // İkinci alanın boyutu 2'dir, bu nedenle boyuta 2 ekleyin.Boyut 4'tür.
/// // Üçüncü alanın hizalaması 1'dir, bu nedenle dolgu boyutuna 0 ekleyin.Boyut 4'tür.
/// // Üçüncü alanın boyutu 1'dir, bu nedenle boyuta 1 ekleyin.Boyut 5'tir.
/// // Son olarak, yapının hizalaması 2'dir (çünkü alanları arasındaki en büyük hizalama 2'dir), bu nedenle dolgu için boyuta 1 ekleyin.
/// // Boyut 6'dır.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple yapıları aynı kuralları izler.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Alanları yeniden sıralamanın boyutu düşürebileceğini unutmayın.
/// // `third` i `second` in önüne koyarak her iki padding baytını da kaldırabiliriz.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Birlik boyutu, en büyük alanın boyutudur.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Bayt cinsinden işaret edilen değerin boyutunu döndürür.
///
/// Bu genellikle `size_of::<T>()` ile aynıdır.
/// Ancak, `T`*statik olarak bilinen bir boyuta* sahip olmadığında, örneğin bir dilim [`[T]`][slice] veya [trait object] olduğunda, dinamik olarak bilinen boyutu elde etmek için `size_of_val` kullanılabilir.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // GÜVENLİK: `val` bir referanstır, bu nedenle geçerli bir ham işaretçi
    unsafe { intrinsics::size_of_val(val) }
}

/// Bayt cinsinden işaret edilen değerin boyutunu döndürür.
///
/// Bu genellikle `size_of::<T>()` ile aynıdır.Ancak, `T`*statik olarak bilinen bir boyuta* sahip olmadığında, örneğin bir dilim [`[T]`][slice] veya bir [trait object], dinamik olarak bilinen boyutu elde etmek için `size_of_val_raw` kullanılabilir.
///
/// # Safety
///
/// Bu işlevi yalnızca aşağıdaki koşullar geçerliyse aramak güvenlidir:
///
/// - `T`, `Sized` ise, bu işlevi aramak her zaman güvenlidir.
/// - `T` in boyutlandırılmamış kuyruğu:
///     - bir [slice] ise, dilim kuyruğunun uzunluğu başlatılmış bir tamsayı olmalı ve *tüm değerin* boyutu (dinamik kuyruk uzunluğu + statik olarak boyutlandırılmış önek) `isize` e sığmalıdır.
///     - bir [trait object], ardından işaretçinin vtable kısmı boyutsuz bir zorlama ile elde edilen geçerli bir vtable'a işaret etmeli ve *tüm değerin* boyutu (dinamik kuyruk uzunluğu + statik olarak boyutlandırılmış önek) `isize` e sığmalıdır.
///
///     - bir (unstable) [extern type], bu durumda bu işlevi aramak her zaman güvenlidir, ancak panic olabilir veya harici tipin düzeni bilinmediğinden yanlış değeri döndürebilir.
///     Bu, extern tipi kuyruğu olan bir türe referans olarak [`size_of_val`] ile aynı davranıştır.
///     - aksi takdirde, ihtiyatlı olarak bu işlevi çağırmasına izin verilmez.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // GÜVENLİK: arayan geçerli bir ham işaretçi sağlamalıdır
    unsafe { intrinsics::size_of_val(val) }
}

/// Bir türün [ABI]-gerekli minimum hizalamasını döndürür.
///
/// `T` türündeki bir değere yapılan her başvuru, bu sayının katı olmalıdır.
///
/// Bu, yapı alanları için kullanılan hizalamadır.Tercih edilen hizalamadan daha küçük olabilir.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` in işaret ettiği değer türünün [ABI]-gereken minimum hizalamasını döndürür.
///
/// `T` türündeki bir değere yapılan her başvuru, bu sayının katı olmalıdır.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // GÜVENLİK: val bir referanstır, bu nedenle geçerli bir ham göstericidir
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Bir türün [ABI]-gerekli minimum hizalamasını döndürür.
///
/// `T` türündeki bir değere yapılan her başvuru, bu sayının katı olmalıdır.
///
/// Bu, yapı alanları için kullanılan hizalamadır.Tercih edilen hizalamadan daha küçük olabilir.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` in işaret ettiği değer türünün [ABI]-gereken minimum hizalamasını döndürür.
///
/// `T` türündeki bir değere yapılan her başvuru, bu sayının katı olmalıdır.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // GÜVENLİK: val bir referanstır, bu nedenle geçerli bir ham göstericidir
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` in işaret ettiği değer türünün [ABI]-gereken minimum hizalamasını döndürür.
///
/// `T` türündeki bir değere yapılan her başvuru, bu sayının katı olmalıdır.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Bu işlevi yalnızca aşağıdaki koşullar geçerliyse aramak güvenlidir:
///
/// - `T`, `Sized` ise, bu işlevi aramak her zaman güvenlidir.
/// - `T` in boyutlandırılmamış kuyruğu:
///     - bir [slice] ise, dilim kuyruğunun uzunluğu başlatılmış bir tamsayı olmalı ve *tüm değerin* boyutu (dinamik kuyruk uzunluğu + statik olarak boyutlandırılmış önek) `isize` e sığmalıdır.
///     - bir [trait object], ardından işaretçinin vtable kısmı boyutsuz bir zorlama ile elde edilen geçerli bir vtable'a işaret etmeli ve *tüm değerin* boyutu (dinamik kuyruk uzunluğu + statik olarak boyutlandırılmış önek) `isize` e sığmalıdır.
///
///     - bir (unstable) [extern type], bu durumda bu işlevi aramak her zaman güvenlidir, ancak panic olabilir veya harici tipin düzeni bilinmediğinden yanlış değeri döndürebilir.
///     Bu, extern tipi kuyruğu olan bir türe referans olarak [`align_of_val`] ile aynı davranıştır.
///     - aksi takdirde, ihtiyatlı olarak bu işlevi çağırmasına izin verilmez.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // GÜVENLİK: arayan geçerli bir ham işaretçi sağlamalıdır
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `T` türü değerlerin düşürülmesi önemliyse `true` döndürür.
///
/// Bu tamamen bir optimizasyon ipucudur ve ihtiyatlı bir şekilde uygulanabilir:
/// gerçekten düşürülmesi gerekmeyen türler için `true` döndürebilir.
/// Her zaman olduğu gibi `true` i döndürmek, bu işlevin geçerli bir uygulaması olacaktır.Ancak bu işlev gerçekten `false` döndürürse, `T` i düşürmenin hiçbir yan etkisi olmayacağından emin olabilirsiniz.
///
/// Koleksiyonlar gibi verilerini manuel olarak bırakması gereken düşük seviyeli uygulamalar, yok edildiklerinde tüm içeriklerini gereksiz yere bırakmaya çalışmaktan kaçınmak için bu işlevi kullanmalıdır.
///
/// Bu, sürüm yapılarında (yan etkisi olmayan bir döngünün kolayca tespit edilip ortadan kaldırıldığı) bir fark yaratmayabilir, ancak genellikle hata ayıklama yapıları için büyük bir kazançtır.
///
/// [`drop_in_place`] in bu kontrolü halihazırda gerçekleştirdiğini unutmayın, bu nedenle iş yükünüz az sayıda [`drop_in_place`] çağrısına indirgenebiliyorsa, bunu kullanmak gereksizdir.
/// Özellikle bir dilim [`drop_in_place`] yapabileceğinizi ve bunun tüm değerler için tek bir ihtiyaç_ bırakma kontrolü yapacağını unutmayın.
///
/// Bu nedenle Vec gibi türler, `needs_drop` i açıkça kullanmadan yalnızca `drop_in_place(&mut self[..])`.
/// Öte yandan [`HashMap`] gibi türler, değerleri birer birer düşürmeli ve bu API'yi kullanmalıdır.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// İşte bir koleksiyonun `needs_drop` i nasıl kullanabileceğine dair bir örnek:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // veriyi bırak
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Tamamen sıfır bayt modeliyle temsil edilen `T` türünün değerini döndürür.
///
/// Bu, örneğin, `(u8, u16)` teki dolgu baytının mutlaka sıfırlanmadığı anlamına gelir.
///
/// Tamamen sıfır olan bir bayt modelinin, bazı `T` türünün geçerli bir değerini temsil ettiğinin garantisi yoktur.
/// Örneğin, tümü sıfır bayt modeli, referans türleri ("&T", `&mut T`) ve işlev işaretçileri için geçerli bir değer değildir.
/// `zeroed` in bu tür türlerde kullanılması anında [undefined behavior][ub] e neden olur çünkü [the Rust compiler assumes][inv], başlatılmış olduğunu düşündüğü bir değişkende her zaman geçerli bir değer olduğunu belirtir.
///
///
/// Bu, [`MaybeUninit::zeroed().assume_init()`][zeroed] ile aynı etkiye sahiptir.
/// Bazen FFI için yararlıdır, ancak genellikle kaçınılmalıdır.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Bu işlevin doğru kullanımı: bir tamsayıyı sıfır ile başlatmak.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// Bu işlevin *yanlış* kullanımı: sıfır ile bir referansın başlatılması.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Tanımsız davranış!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ve yeniden!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // GÜVENLİK: Arayan kişi `T` için tamamen sıfır değerinin geçerli olduğunu garanti etmelidir.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Rust'nin normal bellek başlatma kontrollerini, hiçbir şey yapmadan `T` tipi bir değer üretiyormuş gibi yaparak atlar.
///
/// **Bu işlev kullanımdan kaldırılmıştır.** Bunun yerine [`MaybeUninit<T>`] kullanın.
///
/// Kullanımdan kaldırılmasının nedeni, işlevin temelde doğru şekilde kullanılamamasıdır: [`MaybeUninit::uninit().assume_init()`][uninit] ile aynı etkiye sahiptir.
///
/// [`assume_init` documentation][assume_init] in açıkladığı gibi, [the Rust compiler assumes][inv] değerlerin doğru şekilde başlatıldığını.
/// Sonuç olarak, örneğin arama
/// `mem::uninitialized::<bool>()` kesinlikle `true` veya `false` olmayan bir `bool` i döndürmek için anında tanımlanmamış davranışa neden olur.
/// Daha kötüsü, burada döndürülen gibi gerçekten başlatılmamış bellek, derleyicinin sabit bir değere sahip olmadığını bildiğinden özeldir.
/// Bu, değişken bir tamsayı türüne sahip olsa bile, bir değişkende başlatılmamış veriye sahip olmayı tanımsız davranış haline getirir.
/// (Başlatılmamış tamsayılarla ilgili kuralların henüz kesinleşmediğine dikkat edin, ancak tamamlanıncaya kadar bunlardan kaçınmanız önerilir.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // GÜVENLİK: Arayan, birimselleştirilmiş bir değerin `T` için geçerli olduğunu garanti etmelidir.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Her ikisini de başlatmadan değerleri iki değiştirilebilir konumda değiştirir.
///
/// * Varsayılan veya yapay bir değerle takas etmek istiyorsanız, bkz. [`take`].
/// * Eski değeri döndürerek geçilen bir değerle takas etmek istiyorsanız, bkz. [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // GÜVENLİK: İşlenmemiş işaretçiler, tüm özellikleri karşılayan güvenli değiştirilebilir referanslardan oluşturulmuştur.
    // `ptr::swap_nonoverlapping_one` üzerindeki kısıtlamalar
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` i varsayılan `T` değeriyle değiştirir ve önceki `dest` değerini döndürür.
///
/// * İki değişkenin değerlerini değiştirmek istiyorsanız, bkz. [`swap`].
/// * Varsayılan değer yerine geçilen bir değerle değiştirmek isterseniz, bkz. [`replace`].
///
/// # Examples
///
/// Basit bir örnek:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` bir yapı alanının bir "empty" değeri ile değiştirilerek sahipliğinin alınmasına izin verir.
/// `take` olmadan aşağıdaki gibi sorunlarla karşılaşabilirsiniz:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// `T` in mutlaka [`Clone`] i uygulamadığını, dolayısıyla `self.buf` i klonlayıp sıfırlayamayacağını unutmayın.
/// Ancak `take`, `self.buf` in orijinal değerinin `self` ile olan ilişkisini kesmek için kullanılabilir, bu da döndürülmesine izin verir:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` i referans alınan `dest` e taşır ve önceki `dest` değerini döndürür.
///
/// Her iki değer de düşürülmez.
///
/// * İki değişkenin değerlerini değiştirmek istiyorsanız, bkz. [`swap`].
/// * Varsayılan bir değerle değiştirmek istiyorsanız, bkz. [`take`].
///
/// # Examples
///
/// Basit bir örnek:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` bir yapı alanının başka bir değerle değiştirilerek tüketilmesine izin verir.
/// `replace` olmadan aşağıdaki gibi sorunlarla karşılaşabilirsiniz:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// `T` in mutlaka [`Clone`] i uygulamadığını unutmayın, bu nedenle `self.buf[i]` i hareketi önlemek için bile klonlayamayız.
/// Ancak `replace`, bu dizindeki orijinal değerin `self` ile olan ilişkisini kesmek için kullanılabilir ve bu değerin döndürülmesine izin verir:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // GÜVENLİK: `dest` ten okuyoruz ancak daha sonra `src` i doğrudan içine yazıyoruz,
    // eski değer yinelenmeyecek şekilde.
    // Hiçbir şey düşürülmez ve burada hiçbir şey panic yapamaz.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Bir değeri elden çıkarır.
///
/// Bunu, argümanın [`Drop`][drop] uygulamasını çağırarak yapar.
///
/// Bu, `Copy` i uygulayan türler için etkili bir şekilde hiçbir şey yapmaz, örn.
/// integers.
/// Bu tür değerler kopyalanır ve _then_ işleve taşınır, böylece değer bu işlev çağrısından sonra kalır.
///
///
/// Bu işlev sihir değildir;tam anlamıyla şu şekilde tanımlanır:
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` işleve taşındığından, işlev dönmeden önce otomatik olarak bırakılır.
///
/// [drop]: Drop
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // vector'yi açıkça bırakın
/// ```
///
/// [`RefCell`] çalışma zamanında ödünç alma kurallarını uyguladığından, `drop` bir [`RefCell`] ödünç alabilir:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // bu slotta değiştirilebilir ödünç almaktan vazgeçin
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] i uygulayan tamsayılar ve diğer türler `drop` ten etkilenmez.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` in bir kopyası taşındı ve bırakıldı
/// drop(y); // `y` in bir kopyası taşındı ve bırakıldı
///
/// println!("x: {}, y: {}", x, y.0); // hala uygun
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` i `&U` tipine sahip olarak yorumlar ve ardından içerilen değeri hareket ettirmeden `src` i okur.
///
/// Bu işlev, `&T` i `&U` e dönüştürerek ve ardından `&U` i okuyarak `src` işaretçisinin [`size_of::<U>`][size_of] baytları için geçerli olduğunu güvenli bir şekilde varsayacaktır (bunun dışında, `&U`, `&T` ten daha sıkı hizalama gereksinimleri sağladığında bile doğru bir şekilde yapılır).
/// Ayrıca, `src` ten çıkmak yerine güvenli bir şekilde içerilen değerin bir kopyasını oluşturacaktır.
///
/// `T` ve `U` farklı boyutlara sahipse bu bir derleme zamanı hatası değildir, ancak bu işlevi yalnızca `T` ve `U` in aynı boyuta sahip olduğu durumlarda çalıştırmanız şiddetle tavsiye edilir.`U`, `T` ten büyükse bu işlev [undefined behavior][ub] i tetikler.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Verileri 'foo_array' ten kopyalayın ve 'Foo' olarak değerlendirin
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Kopyalanan verileri değiştirin
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' in içeriği değişmemeliydi
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // U'nun daha yüksek bir hizalama gereksinimi varsa, src uygun şekilde hizalanmayabilir.
    if align_of::<U>() > align_of::<T>() {
        // GÜVENLİK: `src`, okumalar için geçerli olması garantili bir referanstır.
        // Arayan, gerçek dönüşümün güvenli olduğunu garanti etmelidir.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // GÜVENLİK: `src`, okumalar için geçerli olması garantili bir referanstır.
        // `src as *const U` in düzgün bir şekilde hizalandığını kontrol ettik.
        // Arayan, gerçek dönüşümün güvenli olduğunu garanti etmelidir.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Bir numaralamanın ayırt edicisini temsil eden opak tip.
///
/// Daha fazla bilgi için bu modüldeki [`discriminant`] işlevine bakın.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Bu trait uygulamaları türetilemez çünkü T'de herhangi bir sınır istemiyoruz.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` teki enum varyantını benzersiz şekilde tanımlayan bir değer döndürür.
///
/// `T` bir enum değilse, bu işlevi çağırmak tanımsız davranışa neden olmaz, ancak dönüş değeri belirtilmez.
///
///
/// # Stability
///
/// Bir enum varyantının ayırt edici özelliği, enum tanımı değişirse değişebilir.
/// Bazı varyantların ayırt edici özelliği, aynı derleyiciye sahip derlemeler arasında değişmeyecektir.
///
/// # Examples
///
/// Bu, gerçek verileri göz ardı ederek veri taşıyan numaralandırmaları karşılaştırmak için kullanılabilir:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// `T` enum türündeki değişkenlerin sayısını döndürür.
///
/// `T` bir enum değilse, bu işlevi çağırmak tanımsız davranışa neden olmaz, ancak dönüş değeri belirtilmez.
/// Aynı şekilde, `T`, `usize::MAX` ten daha fazla değişkene sahip bir enum ise, dönüş değeri belirtilmez.
/// Yerleşik olmayan varyantlar sayılacaktır.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}