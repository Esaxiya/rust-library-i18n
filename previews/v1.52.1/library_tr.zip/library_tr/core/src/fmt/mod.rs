//! Dizeleri biçimlendirmek ve yazdırmak için yardımcı programlar.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` tarafından döndürülen olası hizalamalar
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// İçeriğin sola hizalanması gerektiğine dair gösterge.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// İçeriğin sağa hizalanması gerektiğine dair gösterge.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// İçeriğin ortaya hizalanması gerektiğine dair gösterge.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Biçimlendirici yöntemleri tarafından döndürülen tür.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Bir mesajın bir akışa biçimlendirilmesinden döndürülen hata türü.
///
/// Bu tür, bir hatanın meydana gelmesinden başka bir hatanın iletimini desteklemez.
/// Herhangi bir ekstra bilgi başka yollarla iletilecek şekilde düzenlenmelidir.
///
/// Unutulmaması gereken önemli bir nokta, `fmt::Error` tipinin, kapsam olarak da sahip olabileceğiniz [`std::io::Error`] veya [`std::error::Error`] ile karıştırılmaması gerektiğidir.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// Unicode kabul eden tamponlara veya akışlara yazmak veya biçimlendirmek için bir trait.
///
/// Bu trait yalnızca UTF-8 kodlu verileri kabul eder ve [flushable] değildir.
/// Yalnızca Unicode'u kabul etmek istiyorsanız ve temizlemeye ihtiyacınız yoksa, bu trait'yi uygulamalısınız;
/// aksi takdirde [`std::io::Write`] uygulamalısınız.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Bu yazıcıya bir dize dilimi yazar ve yazma işleminin başarılı olup olmadığını döndürür.
    ///
    /// Bu yöntem yalnızca tüm dize dilimi başarıyla yazıldıysa başarılı olabilir ve bu yöntem tüm veriler yazılıncaya veya bir hata oluşana kadar geri dönmeyecektir.
    ///
    ///
    /// # Errors
    ///
    /// Bu işlev, hata durumunda [`Error`] örneğini döndürecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Bu yazıcıya bir [`char`] yazar ve yazmanın başarılı olup olmadığını döndürür.
    ///
    /// Tek bir [`char`], birden fazla bayt olarak kodlanabilir.
    /// Bu yöntem yalnızca tüm bayt dizisi başarıyla yazıldıysa başarılı olabilir ve bu yöntem tüm veriler yazılıncaya veya bir hata oluşana kadar geri dönmeyecektir.
    ///
    ///
    /// # Errors
    ///
    /// Bu işlev, hata durumunda [`Error`] örneğini döndürecektir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Bu trait uygulayıcıları ile [`write!`] makrosunun kullanımı için yapıştırıcı.
    ///
    /// Bu yöntem genellikle manuel olarak değil, [`write!`] makrosunun kendisi aracılığıyla başlatılmalıdır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Biçimlendirme için yapılandırma.
///
/// `Formatter`, biçimlendirmeyle ilgili çeşitli seçenekleri temsil eder.
/// Kullanıcılar doğrudan "Biçimlendiriciyi" oluşturmaz;[`Debug`] ve [`Display`] gibi tüm traits biçimlendirmelerinin `fmt` yöntemine değiştirilebilir bir referans aktarılır.
///
///
/// Bir `Formatter` ile etkileşim kurmak için, biçimlendirmeyle ilgili çeşitli seçenekleri değiştirmek için çeşitli yöntemler çağıracaksınız.
/// Örnekler için lütfen aşağıdaki `Formatter` te tanımlanan yöntemlerin belgelerine bakın.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Bağımsız değişken, esasen, `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` e eşdeğer, optimize edilmiş kısmen uygulanan bir biçimlendirme işlevidir.

extern "C" {
    type Opaque;
}

/// Bu yapı, Xprintf fonksiyon ailesi tarafından alınan genel "argument" i temsil eder.Verilen değeri biçimlendirmek için bir işlev içerir.
/// Derleme zamanında, işlevin ve değerin doğru türlere sahip olması sağlanır ve daha sonra bu yapı, bağımsız değişkenleri bir türe standartlaştırmak için kullanılır.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Bu, biçimlendirme altyapısında indices/counts ile ilişkili işlev işaretçisi için tek bir kararlı değeri garanti eder.
//
// Bu şekilde tanımlanan bir işlevin doğru olmayacağına dikkat edin, çünkü işlevler her zaman LLVM IR'ye geçerli indirgeme ile unnamed_addr olarak etiketlenir, bu nedenle adreslerinin LLVM için önemli olmadığı ve bu nedenle as_usize dönüştürmesi yanlış derlenmiş olabilir.
//
// Uygulamada, non-usize içeren verileri (biçimlendirme argümanlarının statik olarak üretilmesinin bir sorunu olarak) asla as_usize olarak adlandırmayız, bu nedenle bu yalnızca ek bir kontroldür.
//
// Öncelikle, `USIZE_MARKER` teki işlev işaretçisinin, `&usize` i ilk argüman olarak alan işlevlere *yalnızca* karşılık gelen bir adrese sahip olduğundan emin olmak istiyoruz.
// Buradaki read_volatile, geçirilen referanstan bir kullanımı güvenli bir şekilde hazırlayabilmemizi ve bu adresin kullanım dışı alma işlevine işaret etmemesini sağlar.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // GÜVENLİK: ptr bir referanstır
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // GÜVENLİK: `mem::transmute(x)` güvenlidir çünkü
        //     1. `&'b T` `'b` ile ortaya çıktığı ömrü korur (sınırsız bir ömre sahip olmamak için)
        //     2.
        //     `&'b T` ve `&'b Opaque` aynı bellek düzenine sahiptir (burada olduğu gibi `T` `Sized` olduğunda) `mem::transmute(f)` güvenlidir çünkü `fn(&T, &mut Formatter<'_>) -> Result` ve `fn(&Opaque, &mut Formatter<'_>) -> Result` aynı ABI'ye sahiptir (`T` `Sized` olduğu sürece)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // GÜVENLİK: `formatter` alanı yalnızca aşağıdaki durumlarda USIZE_MARKER olarak ayarlanır
            // değer bir kullanımdır, bu yüzden bu güvenlidir
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// v1 format_args formatında mevcut bayraklar
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Format_args! () Makrosunu kullanırken, bu işlev Arguments yapısını oluşturmak için kullanılır.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Bu işlev, standart olmayan biçimlendirme parametrelerini belirtmek için kullanılır.
    /// Geçerli bir Argümanlar yapısı oluşturmak için `pieces` dizisi en az `fmt` kadar uzun olmalıdır.
    /// Ayrıca, `fmt` içindeki `CountIsParam` veya `CountIsNextParam` olan herhangi bir `Count`, `argumentusize` ile oluşturulan bir argümana işaret etmelidir.
    ///
    /// Ancak, bunu yapmamak güvensizliğe neden olmaz, ancak geçersizliği göz ardı eder.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Biçimlendirilmiş metnin uzunluğunu tahmin eder.
    ///
    /// Bu, `format!` kullanılırken ilk `String` kapasitesini ayarlamak için kullanılmak üzere tasarlanmıştır.
    /// Note: bu ne alt ne de üst sınırdır.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Biçim dizesi bir bağımsız değişkenle başlıyorsa, parçaların uzunluğu önemli olmadığı sürece hiçbir şeyi önceden tahsis etmeyin.
            //
            //
            0
        } else {
            // Bazı argümanlar vardır, bu nedenle herhangi bir ek itme dizeyi yeniden tahsis edecektir.
            //
            // Bundan kaçınmak için, burada kapasitenin "pre-doubling" iyiz.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Bu yapı, bir biçim dizesinin ve argümanlarının güvenli bir şekilde önceden derlenmiş bir sürümünü temsil eder.
/// Bu, çalışma zamanında oluşturulamaz çünkü güvenli bir şekilde yapılamaz, bu nedenle hiçbir kurucu verilmez ve değiştirmeyi önlemek için alanlar özeldir.
///
///
/// [`format_args!`] makrosu, bu yapının bir örneğini güvenli bir şekilde oluşturacaktır.
/// Makro, biçim dizesini derleme zamanında doğrular, böylece [`write()`] ve [`format()`] işlevlerinin kullanımı güvenli bir şekilde gerçekleştirilebilir.
///
/// [`format_args!`] in `Debug` ve `Display` bağlamlarında döndürdüğü `Arguments<'a>` i aşağıda görüldüğü gibi kullanabilirsiniz.
/// Örnek ayrıca `Debug` ve `Display` formatlarının aynı şeyi gösterdiğini de gösterir: `format_args!` teki enterpolasyonlu format dizesi.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Yazdırılacak dizi parçalarını biçimlendirin.
    pieces: &'a [&'static str],

    // Yer tutucu özellikleri veya tüm özellikler varsayılansa `None` ("{}{}" teki gibi).
    fmt: Option<&'a [rt::v1::Argument]>,

    // Dize parçalarıyla aralanacak enterpolasyon için dinamik argümanlar.
    // (Her argümanın önünde bir dizge parçası bulunur.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Biçimlendirilecek bağımsız değişken yoksa biçimlendirilmiş dizeyi alın.
    ///
    /// Bu, en önemsiz durumda tahsisleri önlemek için kullanılabilir.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` çıktıyı programcıya dönük, hata ayıklama bağlamında biçimlendirmelidir.
///
/// Genel olarak konuşursak, sadece `derive` bir `Debug` uygulaması yapmalısınız.
///
/// Alternatif biçim belirleyicisi `#?` ile kullanıldığında, çıktı oldukça yazdırılır.
///
/// Biçimlendiriciler hakkında daha fazla bilgi için bkz. [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Bu trait, tüm alanlar `Debug` i uygularsa `#[derive]` ile kullanılabilir.
/// Yapılar için `derive`d olduğunda, `struct` in adını, ardından `{` i, ardından her alanın adının ve `Debug` değerinin virgülle ayrılmış bir listesini ve ardından `}` i kullanacaktır.
/// "Enum" lar için, varyantın adını ve geçerliyse `(` i, ardından alanların `Debug` değerlerini ve ardından `)` i kullanacaktır.
///
/// # Stability
///
/// Türetilmiş `Debug` formatları kararlı değildir ve bu nedenle future Rust sürümleriyle değişebilir.
/// Ek olarak, standart kitaplık tarafından sağlanan türlerin `Debug` uygulamaları ("libstd", `libcore`, `liballoc`, vb.) Kararlı değildir ve future Rust sürümleriyle de değişebilir.
///
///
/// # Examples
///
/// Bir uygulama türetmek:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Manuel olarak uygulama:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`Formatter`] yapısında, [`debug_struct`] gibi manuel uygulamalarda size yardımcı olacak bir dizi yardımcı yöntem vardır.
///
/// `Debug` `derive` veya [`Formatter`] üzerinde hata ayıklama oluşturucu API'sini kullanan uygulamalar, alternatif bayrağı kullanarak oldukça yazdırmayı destekler: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` ile güzel baskı:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Verilen biçimlendiriciyi kullanarak değeri biçimlendirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` olmadan makro `Debug` i prelude'den yeniden dışa aktarmak için ayrı modül.
pub(crate) mod macros {
    /// trait `Debug` in bir impl'ını oluşturan makro türetin.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Boş bir biçim için trait biçimlendirin, `{}`.
///
/// `Display` [`Debug`] e benzer, ancak `Display` kullanıcıya dönük çıktı içindir ve bu nedenle türetilemez.
///
///
/// Biçimlendiriciler hakkında daha fazla bilgi için bkz. [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `Display` in bir türe uygulanması:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Verilen biçimlendiriciyi kullanarak değeri biçimlendirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait, çıktısını base-8 te bir sayı olarak biçimlendirmelidir.
///
/// İlkel işaretli tamsayılar için (`i8`-`i128` ve `isize`), negatif değerler, ikisinin tamamlayıcı temsili olarak biçimlendirilir.
///
///
/// Alternatif bayrak `#`, çıktının önüne bir `0o` ekler.
///
/// Biçimlendiriciler hakkında daha fazla bilgi için bkz. [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ile temel kullanım:
///
/// ```
/// let x = 42; // 42, sekizlik olarak '52'
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// `Octal` in bir türe uygulanması:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 uygulamasına delege
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Verilen biçimlendiriciyi kullanarak değeri biçimlendirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait, çıktısını ikili olarak bir sayı olarak biçimlendirmelidir.
///
/// İlkel işaretli tamsayılar için ([`i8`]-[`i128`] ve [`isize`]), negatif değerler, ikisinin tamamlayıcı temsili olarak biçimlendirilir.
///
///
/// Alternatif bayrak `#`, çıktının önüne bir `0b` ekler.
///
/// Biçimlendiriciler hakkında daha fazla bilgi için bkz. [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] ile temel kullanım:
///
/// ```
/// let x = 42; // 42, ikili olarak '101010'
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// `Binary` in bir türe uygulanması:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 uygulamasına delege
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Verilen biçimlendiriciyi kullanarak değeri biçimlendirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait, çıktısını `a` ile `f` arası küçük harf olacak şekilde onaltılık bir sayı olarak biçimlendirmelidir.
///
/// İlkel işaretli tamsayılar için (`i8`-`i128` ve `isize`), negatif değerler, ikisinin tamamlayıcı temsili olarak biçimlendirilir.
///
///
/// Alternatif bayrak `#`, çıktının önüne bir `0x` ekler.
///
/// Biçimlendiriciler hakkında daha fazla bilgi için bkz. [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ile temel kullanım:
///
/// ```
/// let x = 42; // 42, onaltılık '2a' dir
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// `LowerHex` in bir türe uygulanması:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 uygulamasına delege
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Verilen biçimlendiriciyi kullanarak değeri biçimlendirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait, çıktısını `A` ile `F` arası büyük harf olacak şekilde onaltılık bir sayı olarak biçimlendirmelidir.
///
/// İlkel işaretli tamsayılar için (`i8`-`i128` ve `isize`), negatif değerler, ikisinin tamamlayıcı temsili olarak biçimlendirilir.
///
///
/// Alternatif bayrak `#`, çıktının önüne bir `0x` ekler.
///
/// Biçimlendiriciler hakkında daha fazla bilgi için bkz. [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ile temel kullanım:
///
/// ```
/// let x = 42; // 42, onaltılık '2A' dir
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// `UpperHex` in bir türe uygulanması:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 uygulamasına delege
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Verilen biçimlendiriciyi kullanarak değeri biçimlendirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait, çıktısını bir bellek konumu olarak biçimlendirmelidir.
/// Bu genellikle onaltılık olarak sunulur.
///
/// Biçimlendiriciler hakkında daha fazla bilgi için bkz. [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` ile temel kullanım:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // bu '0x7f06092ac6d0' gibi bir şey üretir
/// ```
///
/// `Pointer` in bir türe uygulanması:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // Kullanabileceğimiz İşaretçiyi uygulayan bir `*const T` e dönüştürmek için `as` i kullanın
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Verilen biçimlendiriciyi kullanarak değeri biçimlendirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait, çıktısını küçük harfli `e` ile bilimsel gösterimde biçimlendirmelidir.
///
/// Biçimlendiriciler hakkında daha fazla bilgi için bkz. [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` ile temel kullanım:
///
/// ```
/// let x = 42.0; // 42.0 '4.2e1' bilimsel gösterimde
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// `LowerExp` in bir türe uygulanması:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 uygulamasına delege
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Verilen biçimlendiriciyi kullanarak değeri biçimlendirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait, çıktısını büyük harf `E` ile bilimsel gösterimde biçimlendirmelidir.
///
/// Biçimlendiriciler hakkında daha fazla bilgi için bkz. [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` ile temel kullanım:
///
/// ```
/// let x = 42.0; // 42.0 '4.2E1' bilimsel gösterimde
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// `UpperExp` in bir türe uygulanması:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 uygulamasına delege
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Verilen biçimlendiriciyi kullanarak değeri biçimlendirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` işlevi, bir çıktı akışı ve `format_args!` makrosu ile önceden derlenebilen bir `Arguments` yapısı alır.
///
///
/// Bağımsız değişkenler, sağlanan çıktı akışına belirtilen biçim dizesine göre biçimlendirilecektir.
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Lütfen [`write!`] kullanmanın tercih edilebileceğini unutmayın.Misal:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Tüm argümanlar için varsayılan biçimlendirme parametrelerini kullanabiliriz.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Her spesifikasyonun önünde bir dize parçası bulunan karşılık gelen bir argüman vardır.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // GÜVENLİK: arg ve args.args aynı Argümanlardan gelir,
                // bu da dizinlerin her zaman sınırlar içinde olmasını garanti eder.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Sonda yalnızca bir dize parçası kalmış olabilir.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // GÜVENLİK: argümanlar ve argümanlar aynı argümanlardan gelir,
    // bu da dizinlerin her zaman sınırlar içinde olmasını garanti eder.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Doğru argümanı çıkarın
    debug_assert!(arg.position < args.len());
    // GÜVENLİK: argümanlar ve argümanlar aynı argümanlardan gelir,
    // endeksinin her zaman sınırlar içinde olduğunu garanti eder.
    let value = unsafe { args.get_unchecked(arg.position) };

    // O zaman gerçekten biraz baskı yapın
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // GÜVENLİK: cnt ve args aynı Argümanlardan gelir,
            // bu da bu endeksin her zaman sınırlar içinde olduğunu garanti eder.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Bir şeyin bitiminden sonra dolgu.`Formatter::padding` tarafından iade edildi.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Bu yazı dolgusunu yazın.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Bunu değiştirmek istiyoruz
            buf: wrap(self.buf),

            // Ve bunları koru
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Tüm traits biçimlendirmesinin kullanabileceği biçimlendirme bağımsız değişkenlerini doldurmak ve işlemek için kullanılan yardımcı yöntemler.
    //

    /// Bir dizeye zaten verilmiş olan bir tamsayı için doğru doldurmayı gerçekleştirir.
    /// Str, bu yöntemle eklenecek olan tamsayı işaretini *içermemelidir*.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, orijinal tamsayının pozitif veya sıfır olup olmadığı.
    /// * önek, '#' karakteri (Alternate) sağlanmışsa, numaranın önüne konulacak önek budur.
    ///
    /// * buf, sayının biçimlendirildiği bayt dizisi
    ///
    /// Bu işlev, sağlanan bayrakların yanı sıra minimum genişliği de doğru bir şekilde hesaba katacaktır.
    /// Hassasiyeti hesaba katmayacaktır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // "-" i sayı çıktısından çıkarmamız gerekiyor.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Varsa işareti ve ardından istenmişse ön eki yazar
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width` alanı bu noktada daha çok bir `min-width` parametresidir.
        match self.width {
            // Minimum uzunluk gereksinimi yoksa baytları yazabiliriz.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Minimum genişliğin üzerinde olup olmadığımızı kontrol edin, öyleyse sadece baytları da yazabiliriz.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Doldurma karakteri sıfırsa işaret ve önek dolgudan önce gelir
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Aksi takdirde, işaret ve önek dolgudan sonra gelir
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Bu işlev bir dizgi dilimini alır ve belirtilen ilgili biçimlendirme bayraklarını uyguladıktan sonra bunu dahili tampona yayınlar.
    /// Genel dizeler için tanınan bayraklar şunlardır:
    ///
    /// * genişlik, ne yayılacağının minimum genişliği
    /// * fill/align - Sağlanan dizenin doldurulması gerekiyorsa ne yayılır ve nerede yayılır
    /// * kesinlik, yayılacak maksimum uzunluk, dizge bu uzunluktan daha uzunsa kesilir
    ///
    /// Özellikle bu işlev `flag` parametrelerini yok sayar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Önde hızlı bir yol olduğundan emin olun
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` alanı, formatlanmakta olan dizi için `max-width` olarak yorumlanabilir.
        //
        let s = if let Some(max) = self.precision {
            // Dizimiz hassasiyetten daha uzunsa, o zaman kesmemiz gerekir.
            // Ancak `fill`, `width` ve `align` gibi diğer bayraklar her zamanki gibi davranmalıdır.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // Buradaki LLVM, `..i` in panic `&s[..i]` olmayacağını kanıtlayamaz, ancak panic yapamayacağını biliyoruz.
                // `unsafe` ten kaçınmak için `get` + `unwrap_or` kullanın ve aksi takdirde burada panic ile ilgili herhangi bir kod yayınlamayın.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width` alanı bu noktada daha çok bir `min-width` parametresidir.
        match self.width {
            // Maksimum uzunluğun altındaysak ve minimum uzunluk gereksinimi yoksa, o zaman sadece dizeyi yayınlayabiliriz
            //
            None => self.buf.write_str(s),
            // Maksimum genişliğin altındaysak, minimum genişliğin üzerinde olup olmadığımızı kontrol edin, eğer öyleyse, dizeyi yaymak kadar kolaydır.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Hem maksimum hem de minimum genişliğin altındaysak, minimum genişliği belirtilen dize + biraz hizalama ile doldurun.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Ön dolguyu yazın ve yazılmamış son dolguyu iade edin.
    /// Arayanlar, doldurulan şeyden sonra dolgu sonrasının yazılmasını sağlamaktan sorumludur.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Biçimlendirilmiş parçaları alır ve dolguyu uygular.
    /// Arayanın, `self.precision` in göz ardı edilebilmesi için parçaları gerekli hassasiyette oluşturduğunu varsayar.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // işarete duyarlı sıfır dolgusu için, önce işareti oluştururuz ve baştan işaretimiz yokmuş gibi davranırız.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // bir işaret her zaman önce gelir
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // işareti biçimlendirilmiş parçalardan kaldırın
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // kalan kısımlar normal dolgu işleminden geçer.
            let len = formatted.len();
            let ret = if width <= len {
                // dolgu yok
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // bu yaygın bir durumdur ve bir kısayol kullanırız
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // GÜVENLİK: Bu, `flt2dec::Part::Num` ve `flt2dec::Part::Copy` için kullanılır.
            // Her `c` `b'0'` ve `b'9'` arasında olduğundan `flt2dec::Part::Num` için kullanmak güvenlidir, bu da `s` in geçerli UTF-8 olduğu anlamına gelir.
            // Ayrıca, `buf` in düz ASCII olması gerektiğinden, pratikte `flt2dec::Part::Copy(buf)` için kullanmak muhtemelen güvenlidir, ancak birisinin `buf` için kötü bir değeri `flt2dec::to_shortest_str` e geçirmesi mümkündür, çünkü bu genel bir işlevdir.
            //
            // FIXME: Bunun UB ile sonuçlanıp sonuçlanmayacağını belirleyin.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 sıfır
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Bu biçimlendiricinin içerdiği temeldeki arabelleğe bazı verileri yazar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Bu şuna eşdeğerdir:
    ///         // yaz! (biçimlendirici, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Bu örneğe bazı biçimlendirilmiş bilgiler yazar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Biçimlendirme için bayraklar
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Hizalama olduğunda 'fill' olarak kullanılan karakter.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // ">" ile sağa hizaladık.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Hangi tür uyum talep edildiğini gösteren bayrak.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Çıktının olması gereken isteğe bağlı olarak belirtilen tamsayı genişliği.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Bir genişlik aldıysak, kullanırız
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Aksi takdirde özel bir şey yapmayız
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Sayısal türler için isteğe bağlı olarak belirtilen hassasiyet.
    /// Alternatif olarak, dize türleri için maksimum genişlik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Bir hassasiyet aldıysak onu kullanırız.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Aksi takdirde varsayılan olarak 2 olur.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` bayrağının belirtilip belirtilmediğini belirler.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` bayrağının belirtilip belirtilmediğini belirler.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Eksi işareti mi istiyorsun?Bir tane var!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` bayrağının belirtilip belirtilmediğini belirler.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` bayrağının belirtilip belirtilmediğini belirler.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Biçimlendiricinin seçeneklerini göz ardı ediyoruz.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Bu iki bayrak için hangi genel API istediğimize karar verin.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Yapılar için [`fmt::Debug`] uygulamalarının oluşturulmasına yardımcı olmak için tasarlanmış bir [`DebugStruct`] oluşturucu oluşturur.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Tuple yapıları için `fmt::Debug` uygulamalarının oluşturulmasına yardımcı olmak üzere tasarlanmış bir `DebugTuple` oluşturucu oluşturur.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Liste benzeri yapılar için `fmt::Debug` uygulamalarının oluşturulmasına yardımcı olmak üzere tasarlanmış bir `DebugList` oluşturucu oluşturur.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Set benzeri yapılar için `fmt::Debug` uygulamalarının oluşturulmasına yardımcı olmak üzere tasarlanmış bir `DebugSet` oluşturucu oluşturur.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Bu daha karmaşık örnekte, bir eşleştirme kolları listesi oluşturmak için [`format_args!`] ve `.debug_set()` i kullanıyoruz:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Harita benzeri yapılar için `fmt::Debug` uygulamalarının oluşturulmasına yardımcı olmak üzere tasarlanmış bir `DebugMap` oluşturucu oluşturur.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// traits çekirdek biçimlendirme uygulamaları

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Char'ın kaçması gerekiyorsa, biriktirme listesini şimdiye kadar boşaltın ve yazın, aksi takdirde atlayın
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Alternatif bayrak, LowerHex tarafından zaten özel olarak ele alınır-0x öneki olup olmayacağını belirtir.
        // Sıfır genişlemenin olup olmayacağını hesaplamak için kullanırız ve daha sonra koşulsuz olarak öneki almak için ayarlarız.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Display/Debug in çeşitli çekirdek türleri için uygulanması

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell mutabık bir şekilde ödünç alındı, bu yüzden burada değerine bakamayız.
                // Bunun yerine bir yer tutucu gösterin.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Testlerin burada olmasını bekliyorsanız, bunun yerine core/tests/fmt.rs dosyasına bakın, burada tüm rt::Piece yapılarını oluşturmaktan çok daha kolaydır.
//
// Tahsisatlara ihtiyaç duyanlar için crate tahsisinde testler de vardır.