//! Bu, ifmt tarafından kullanılan dahili bir modüldür!Çalışma süresi.Bu yapılar, önceden biçim dizelerini önceden derlemek için statik dizilere gönderilir.
//!
//! Bu tanımlar, `ct` eşdeğerlerine benzer, ancak bunların statik olarak tahsis edilebilmesi ve çalışma zamanı için biraz optimize edilmesi bakımından farklılık gösterir.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Biçimlendirme yönergesinin bir parçası olarak talep edilebilecek olası hizalamalar.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// İçeriğin sola hizalanması gerektiğine dair gösterge.
    Left,
    /// İçeriğin sağa hizalanması gerektiğine dair gösterge.
    Right,
    /// İçeriğin ortaya hizalanması gerektiğine dair gösterge.
    Center,
    /// Hizalama istenmedi.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) ve [precision](https://doc.rust-lang.org/std/fmt/#precision) belirleyicileri tarafından kullanılır.
#[derive(Copy, Clone)]
pub enum Count {
    /// Değişmez bir sayı ile belirtilmiş, değeri depolar
    Is(usize),
    /// `$` ve `*` sözdizimleri kullanılarak belirtilir, dizini `args` te depolar
    Param(usize),
    /// Belirtilmemiş
    Implied,
}