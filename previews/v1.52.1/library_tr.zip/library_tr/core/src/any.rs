//! Bu modül, çalışma zamanı yansıması aracılığıyla herhangi bir `'static` türünün dinamik yazımını sağlayan `Any` trait'yi uygular.
//!
//! `Any` kendisi bir `TypeId` almak için kullanılabilir ve bir trait nesnesi olarak kullanıldığında daha fazla özelliğe sahiptir.
//! `&dyn Any` (ödünç alınmış bir trait nesnesi) olarak, içerilen değerin belirli bir türde olup olmadığını test etmek ve bir tür olarak iç değere referans almak için `is` ve `downcast_ref` yöntemlerine sahiptir.
//! `&mut dyn Any` olarak, iç değere değiştirilebilir bir referans elde etmek için `downcast_mut` yöntemi de vardır.
//! `Box<dyn Any>` `Box<T>` e dönüştürmeye çalışan `downcast` yöntemini ekler.
//! Tüm ayrıntılar için [`Box`] belgelerine bakın.
//!
//! `&dyn Any` in, bir değerin belirli bir somut türde olup olmadığını test etmekle sınırlı olduğunu ve bir türün bir trait uygulayıp uygulamadığını test etmek için kullanılamayacağını unutmayın.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Akıllı işaretçiler ve `dyn Any`
//!
//! `Any` i bir trait nesnesi olarak kullanırken, özellikle `Box<dyn Any>` veya `Arc<dyn Any>` gibi türlerde, akılda tutulması gereken bir davranış parçası, yalnızca `.type_id()` i değer üzerinde çağırmanın, temeldeki trait nesnesini değil,*konteynerin*`TypeId` ini üreteceğidir.
//!
//! Bunun yerine akıllı işaretçiyi `&dyn Any` e dönüştürerek önlenebilir, bu da nesnenin `TypeId` ini döndürür.
//! Örneğin:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Bunu istemeniz daha olasıdır:
//! let actual_id = (&*boxed).type_id();
//! // ... Bundan daha:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Bir işleve aktarılan bir değeri oturumu kapatmak istediğimiz bir durumu düşünün.
//! Üzerinde çalıştığımız değerin Debug'ı uyguladığını biliyoruz, ancak somut türünü bilmiyoruz.Belirli türlere özel muamele vermek istiyoruz: bu durumda String değerlerinin uzunluğunu değerlerinden önce yazdırmak.
//! Derleme zamanında değerimizin somut türünü bilmiyoruz, bu yüzden bunun yerine çalışma zamanı yansımasını kullanmalıyız.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Debug uygulayan herhangi bir tür için günlükçü işlevi.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Değerimizi `String` e dönüştürmeye çalışın.
//!     // Başarılı olursa, String`in uzunluğunun yanı sıra değerini de vermek istiyoruz.
//!     // Değilse, farklı bir türdür: süslemesiz yazdırın.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Bu işlev, kendisiyle çalışmadan önce parametresini kapatmak istiyor.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... başka bir iş yap
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Herhangi bir trait
///////////////////////////////////////////////////////////////////////////////

/// Dinamik yazmayı taklit etmek için bir trait.
///
/// Çoğu tür `Any` i uygular.Ancak, "statik" olmayan bir referans içeren hiçbir tür içermez.
/// Daha fazla ayrıntı için [module-level documentation][mod] e bakın.
///
/// [mod]: crate::any
// Bu trait, güvenli olmayan koddaki (örn., `downcast`) yegane impl'nin `type_id` işlevinin özelliklerine güvenmemize rağmen güvensiz değildir.Normalde, bu bir sorun olur, ancak `Any` in tek impl'si kapsamlı bir uygulama olduğu için, başka hiçbir kod `Any` i uygulayamaz.
//
// Bu trait'yi makul bir şekilde güvensiz hale getirebiliriz-tüm uygulamaları kontrol ettiğimiz için kırılmaya neden olmaz-ancak bu hem gerçekten gerekli olmadığından hem de kullanıcıların güvenli olmayan traits ve güvenli olmayan yöntemler (yani, `type_id` i aramak yine de güvenli olacaktır, ancak muhtemelen bunu belgelerde belirtmek isteriz).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` in `TypeId` ini alır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Herhangi bir trait nesnesi için uzatma yöntemleri.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Örneğin, bir ipliğin birleştirilmesinin sonucunun yazdırılabildiğinden ve dolayısıyla `unwrap` ile kullanılabildiğinden emin olun.
// Gönderim, yukarı yayınlama ile çalışıyorsa, nihayetinde artık ihtiyaç duyulmayabilir.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Kutulu tip `T` ile aynıysa `true` i döndürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Bu işlevin somutlaştırıldığı türden `TypeId` i alın.
        let t = TypeId::of::<T>();

        // trait nesnesi (`self`) teki türün `TypeId` ini alın.
        let concrete = self.type_id();

        // Eşitlik açısından her iki "TypeId" yi karşılaştırın.
        t == concrete
    }

    /// `T` türündeyse kutulu değere veya değilse `None` e bir referans döndürür.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // GÜVENLİK: sadece doğru türü işaret edip etmediğimizi kontrol ettik ve güvenebiliriz
            // bu, bellek güvenliğini kontrol eder, çünkü tüm türler için Herhangi birini uyguladık;bizim impl'mizle çelişecekleri için başka hiçbir ima var olamaz.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Kutulu değere, `T` türündeyse, değilse `None` e bazı değiştirilebilir referanslar döndürür.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // GÜVENLİK: sadece doğru türü işaret edip etmediğimizi kontrol ettik ve güvenebiliriz
            // bu, bellek güvenliğini kontrol eder, çünkü tüm türler için Herhangi birini uyguladık;bizim impl'mizle çelişecekleri için başka hiçbir ima var olamaz.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` tipinde tanımlanan yönteme yönlendirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` tipinde tanımlanan yönteme yönlendirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` tipinde tanımlanan yönteme yönlendirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` tipinde tanımlanan yönteme yönlendirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` tipinde tanımlanan yönteme yönlendirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` tipinde tanımlanan yönteme yönlendirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ve yöntemleri
///////////////////////////////////////////////////////////////////////////////

/// `TypeId`, bir tür için küresel olarak benzersiz bir tanımlayıcıyı temsil eder.
///
/// Her `TypeId`, içindekinin incelenmesine izin vermeyen ancak klonlama, karşılaştırma, yazdırma ve gösterme gibi temel işlemlere izin veren opak bir nesnedir.
///
///
/// Bir `TypeId` şu anda yalnızca `'static` e atfedilen tipler için mevcuttur, ancak bu sınırlama future'de kaldırılabilir.
///
/// `TypeId`, `Hash`, `PartialOrd` ve `Ord` i uygularken, karma değerlerin ve sıralamanın Rust sürümleri arasında değişeceğini belirtmek gerekir.
/// Kodunuzun içinde bunlara güvenmeye dikkat edin!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Bu genel işlevin somutlaştırıldığı türdeki `TypeId` i döndürür.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Bir türün adını dize dilimi olarak döndürür.
///
/// # Note
///
/// Bu, teşhis amaçlı kullanım içindir.
/// Döndürülen dizenin tam içeriği ve biçimi, türün en iyi çaba açıklaması dışında belirtilmez.
/// Örneğin, `type_name::<Option<String>>()` in döndürebileceği dizeler arasında `"Option<String>"` ve `"std::option::Option<std::string::String>"` vardır.
///
///
/// Birden çok tür aynı tür adıyla eşleşebileceğinden, döndürülen dizge bir türün benzersiz bir tanımlayıcısı olarak değerlendirilmemelidir.
/// Benzer şekilde, bir türün tüm parçalarının döndürülen dizede görüneceğinin garantisi yoktur: örneğin, yaşam süresi belirticileri şu anda dahil edilmemiştir.
/// Ek olarak, çıktı, derleyicinin sürümleri arasında değişebilir.
///
/// Mevcut uygulama, derleyici tanılama ve hata ayıklama bilgileri ile aynı altyapıyı kullanır, ancak bu garanti edilmez.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// İşaret edilen değerin türünün adını bir dize dilimi olarak döndürür.
/// Bu, `type_name::<T>()` ile aynıdır, ancak bir değişkenin türünün kolayca mevcut olmadığı durumlarda kullanılabilir.
///
/// # Note
///
/// Bu, teşhis amaçlı kullanım içindir.Dizenin tam içeriği ve biçimi, türün en iyi çaba açıklaması dışında belirtilmemiştir.
/// Örneğin, `type_name_of_val::<Option<String>>(None)`, `"Option<String>"` veya `"std::option::Option<std::string::String>"` i döndürebilir, ancak `"foobar"` i döndüremez.
///
/// Ek olarak, çıktı, derleyicinin sürümleri arasında değişebilir.
///
/// Bu işlev trait nesnelerini çözmez, yani `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` i döndürebilir, ancak `"u32"` i döndüremez.
///
/// Tür adı, bir türün benzersiz bir tanımlayıcısı olarak düşünülmemelidir;
/// birden çok tür aynı tür adını paylaşabilir.
///
/// Mevcut uygulama, derleyici tanılama ve hata ayıklama bilgileri ile aynı altyapıyı kullanır, ancak bu garanti edilmez.
///
/// # Examples
///
/// Varsayılan tam sayı ve kayan sayı türlerini yazdırır.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}