use crate::iter::{FusedIterator, TrustedLen};

/// Sağlanan kapanışı çağırarak tam olarak bir kez değer üreten bir yineleyici oluşturur.
///
/// Bu, genellikle tek bir değer üretecini diğer türden yinelemelerin bir [`chain()`] ine uyarlamak için kullanılır.
/// Belki hemen hemen her şeyi kapsayan bir yineleyiciniz vardır, ancak ekstra özel bir duruma ihtiyacınız vardır.
/// Belki yineleyiciler üzerinde çalışan bir işleviniz vardır, ancak yalnızca bir değeri işlemeniz gerekir.
///
/// [`once()`] ten farklı olarak, bu işlev değeri istek üzerine tembel olarak üretecektir.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::iter;
///
/// // biri en yalnız sayıdır
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // sadece bir, tüm aldığımız bu
/// assert_eq!(None, one.next());
/// ```
///
/// Başka bir yineleyici ile birlikte zincirleme.
/// Diyelim ki `.foo` dizininin her dosyası üzerinde, aynı zamanda bir yapılandırma dosyası üzerinde yineleme yapmak istediğimizi varsayalım.
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // Bir DirEntry-s yineleyicisinden PathBufs yineleyicisine dönüştürmemiz gerekiyor, bu yüzden map kullanıyoruz
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // şimdi, yineleyicimiz yalnızca yapılandırma dosyamız için
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // iki yineleyiciyi tek bir büyük yineleyicide birbirine zincirleyin
/// let files = dirs.chain(config);
///
/// // bu bize .foorc in yanı sıra .foo teki tüm dosyaları verecektir.
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Sağlanan kapanış `F: FnOnce() -> A` i uygulayarak `A` türünde tek bir öğe veren bir yineleyici.
///
///
/// Bu `struct`, [`once_with()`] işlevi tarafından oluşturulur.
/// Daha fazla bilgi için belgelerine bakın.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}