use crate::iter::{FusedIterator, TrustedLen};

/// Sağlanan kapanışı, tekrarlayıcıyı uygulayarak `A` tipi öğeleri sonsuz bir şekilde tekrarlayan yeni bir yineleyici oluşturur, `F: FnMut() -> A`.
///
/// `repeat_with()` işlevi, tekrarlayıcıyı tekrar tekrar çağırır.
///
/// `repeat_with()` gibi sonsuz yineleyiciler, onları sonlu hale getirmek için genellikle [`Iterator::take()`] gibi adaptörlerle kullanılır.
///
/// İhtiyacınız olan yineleyicinin öğe türü [`Clone`] i uyguluyorsa ve kaynak öğeyi bellekte tutmakta sorun yoksa, bunun yerine [`repeat()`] işlevini kullanmalısınız.
///
///
/// `repeat_with()` tarafından üretilen bir yineleyici, [`DoubleEndedIterator`] değildir.
/// Bir [`DoubleEndedIterator`] i iade etmek için `repeat_with()` e ihtiyacınız varsa, lütfen kullanım durumunuzu açıklayan bir GitHub sorunu açın.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::iter;
///
/// // `Clone` olmayan veya henüz pahalı olduğu için hafızada olmasını istemeyen bir türden bir değerimiz olduğunu varsayalım:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // sonsuza kadar belirli bir değer:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Mutasyonu kullanma ve sonlu olma:
///
/// ```rust
/// use std::iter;
///
/// // Sıfırdan ikinin üçüncü kuvvetine:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ve şimdi bitti
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Sağlanan `F: FnMut() -> A` kapanışını uygulayarak `A` tipi öğeleri sonsuz bir şekilde tekrarlayan bir yineleyici.
///
///
/// Bu `struct`, [`repeat_with()`] işlevi tarafından oluşturulur.
/// Daha fazla bilgi için belgelerine bakın.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}