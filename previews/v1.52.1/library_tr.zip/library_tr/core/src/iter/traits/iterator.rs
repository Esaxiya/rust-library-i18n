// ignore-tidy-filelength Bu dosya neredeyse yalnızca `Iterator` tanımından oluşur.
// Bunu birden fazla dosyaya bölemeyiz.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Yineleyicilerle uğraşmak için bir arayüz.
///
/// Bu, ana yineleyici trait'dir.
/// Genel olarak yineleyiciler kavramı hakkında daha fazla bilgi için lütfen [module-level documentation] e bakın.
/// Özellikle, [implement `Iterator`][impl] in nasıl yapıldığını bilmek isteyebilirsiniz.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Üzerinde yinelenen öğelerin türü.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Yineleyiciyi ilerletir ve sonraki değeri döndürür.
    ///
    /// Yineleme bittiğinde [`None`] i döndürür.
    /// Bireysel yineleyici uygulamaları yinelemeyi devam ettirmeyi seçebilir ve bu nedenle `next()` i yeniden çağırmak, sonunda [`Some(Item)`] i bir noktada yeniden döndürmeye başlayabilir veya başlamayabilir.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() e yapılan bir çağrı bir sonraki değeri döndürür ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ve sonra bittiğinde Yok.
    /// assert_eq!(None, iter.next());
    ///
    /// // Daha fazla çağrı `None` e dönebilir veya dönmeyebilir.Burada her zaman yapacaklar.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Yineleyicinin kalan uzunluğunun sınırlarını döndürür.
    ///
    /// Özellikle, `size_hint()`, birinci öğenin alt sınır ve ikinci öğenin üst sınır olduğu bir demet döndürür.
    ///
    /// Döndürülen dizinin ikinci yarısı bir ["Option"] "<" ["usize"] ">" şeklindedir.
    /// Buradaki bir [`None`], bilinen bir üst sınır olmadığı veya üst sınırın [`usize`] ten daha büyük olduğu anlamına gelir.
    ///
    /// # Uygulama notları
    ///
    /// Bir yineleyici uygulamasının beyan edilen öğe sayısını vermesi zorunlu değildir.Bir hatalı yineleyici, öğelerin alt sınırından daha az veya üst sınırından daha fazla sonuç verebilir.
    ///
    /// `size_hint()` öncelikli olarak yineleyicinin öğeleri için alan ayırma gibi optimizasyonlar için kullanılması amaçlanmıştır, ancak örneğin güvenli olmayan kodda sınır denetimlerini atlamak için güvenilmemelidir.
    /// `size_hint()` in yanlış uygulanması, bellek güvenliği ihlallerine yol açmamalıdır.
    ///
    /// Bununla birlikte, uygulama doğru bir tahmin sağlamalıdır, çünkü aksi takdirde trait protokolünün ihlali olur.
    ///
    /// Varsayılan uygulama, herhangi bir yineleyici için doğru olan "(0," ["Hiçbiri"] ")" döndürür.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Daha karmaşık bir örnek:
    ///
    /// ```
    /// // Sıfırdan ona kadar olan çift sayılar.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Sıfırdan on kez yineleyebiliriz.
    /// // Bunun tam olarak beş olduğunu bilmek, filter() i çalıştırmadan mümkün olmazdı.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() ile beş numara daha ekleyelim
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // şimdi her iki sınır da beş artırıldı
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Bir üst sınır için geri dönen `None`:
    ///
    /// ```
    /// // sonsuz bir yineleyicinin üst sınırı yoktur ve olası maksimum alt sınırı
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Yineleyiciyi tüketir, yinelemelerin sayısını sayar ve döndürür.
    ///
    /// Bu yöntem, [`None`] ile karşılaşılıncaya kadar [`next`] i tekrar tekrar çağıracak ve [`Some`] i görme sayısını döndürecektir.
    /// Yineleyicinin herhangi bir öğesi olmasa bile [`next`] in en az bir kez çağrılması gerektiğini unutmayın.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Taşma Davranışı
    ///
    /// Yöntem, taşmalara karşı koruma sağlamaz, bu nedenle, [`usize::MAX`] den fazla öğeye sahip bir yineleyicinin öğelerini saymak, yanlış sonucu veya panics'yi üretir.
    ///
    /// Hata ayıklama iddiaları etkinleştirilirse, bir panic garantilidir.
    ///
    /// # Panics
    ///
    /// Yineleyici [`usize::MAX`] öğesinden daha fazlasına sahipse bu işlev panic olabilir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Son öğeyi döndürerek yineleyiciyi tüketir.
    ///
    /// Bu yöntem, yineleyiciyi [`None`] döndürene kadar değerlendirecektir.
    /// Bunu yaparken mevcut öğeyi izler.
    /// [`None`] iade edildikten sonra, `last()` gördüğü son öğeyi döndürür.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Yineleyiciyi `n` öğeleriyle ilerletir.
    ///
    /// Bu yöntem, [`None`] ile karşılaşılıncaya kadar [`next`] i `n` kez çağırarak `n` elemanlarını hevesle atlayacaktır.
    ///
    /// `advance_by(n)` Yineleyici `n` öğeleriyle başarılı bir şekilde ilerlerse [`Ok(())`][Ok] veya [`None`] ile karşılaşılırsa [`Err(k)`][Err] döndürür; burada `k`, öğeler tükenmeden önce yineleyicinin geliştirildiği öğelerin sayısıdır (ör.
    /// yineleyicinin uzunluğu).
    /// `k` in her zaman `n` ten küçük olduğuna dikkat edin.
    ///
    /// `advance_by(0)` i çağırmak herhangi bir öğe tüketmez ve her zaman [`Ok(())`][Ok] i döndürür.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // sadece `&4` atlandı
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Yineleyicinin "n" inci öğesini döndürür.
    ///
    /// Çoğu indeksleme işleminde olduğu gibi, sayım sıfırdan başlar, bu nedenle `nth(0)` ilk değeri, `nth(1)` ikinci değeri verir ve bu böyle devam eder.
    ///
    /// Tüm önceki öğelerin yanı sıra döndürülen öğenin yineleyici tarafından tüketileceğini unutmayın.
    /// Bu, önceki öğelerin atılacağı ve aynı yineleyici üzerinde `nth(0)` in birden çok kez çağrılmasının farklı öğeler döndüreceği anlamına gelir.
    ///
    ///
    /// `nth()` `n` yineleyicinin uzunluğundan büyük veya ona eşitse [`None`] döndürür.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` i birden çok kez aramak yineleyiciyi geri sarmaz:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1` ten daha az öğe varsa `None` döndürülür:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Aynı noktadan başlayan, ancak her yinelemede verilen miktarda adım adım ilerleyen bir yineleyici oluşturur.
    ///
    /// Not 1: Yineleyicinin ilk öğesi, verilen adıma bakılmaksızın her zaman döndürülecektir.
    ///
    /// Not 2: Göz ardı edilen öğelerin çekildiği saat sabit değildir.
    /// `StepBy` `next(), nth(step-1), nth(step-1),…` dizisi gibi davranır, ancak aynı zamanda dizi gibi davranmakta da özgürdür
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Performans nedenleriyle bazı yineleyiciler için hangi yolun kullanıldığı değişebilir.
    /// İkinci yol, yineleyiciyi daha erken ilerletir ve daha fazla öğe tüketebilir.
    ///
    /// `advance_n_and_return_first` şunun eşdeğeridir:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Verilen adım `0` ise yöntem panic olacaktır.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// İki yineleyici alır ve her ikisi üzerinde sırayla yeni bir yineleyici oluşturur.
    ///
    /// `chain()` yeni bir yineleyici döndürecektir, bu ilk yineleyicideki değerlerin üzerinde ve ardından ikinci yineleyicinin değerlerinin üzerinde yineleme yapacak.
    ///
    /// Başka bir deyişle, iki yineleyiciyi bir zincirde birbirine bağlar.🔗
    ///
    /// [`once`] genellikle tek bir değeri diğer türden yineleme zincirine uyarlamak için kullanılır.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` argümanı [`IntoIterator`] kullandığından, yalnızca [`Iterator`] in kendisine değil, [`Iterator`] e dönüştürülebilecek her şeyi aktarabiliriz.
    /// Örneğin, (`&[T]`) dilimleri [`IntoIterator`] i uygular ve böylece `chain()` e doğrudan aktarılabilir:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Windows API ile çalışıyorsanız, [`OsStr`] i `Vec<u16>` e dönüştürmek isteyebilirsiniz:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// İki yineleyiciyi tek bir çift yineleyiciye 'sıkıştırır'.
    ///
    /// `zip()` diğer iki yineleyici üzerinde yineleyecek yeni bir yineleyici döndürür, ilk öğenin ilk yineleyiciden geldiği ve ikinci öğenin ikinci yineleyiciden geldiği bir demet döndürür.
    ///
    ///
    /// Başka bir deyişle, iki yineleyiciyi tek bir yineleyiciye sıkıştırır.
    ///
    /// Yineleyicilerden biri [`None`] i döndürürse, sıkıştırılmış yineleyiciden [`next`], [`None`] i döndürür.
    /// İlk yineleyici [`None`] i döndürürse, `zip` kısa devre yapacak ve `next` ikinci yineleyicide çağrılmayacaktır.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` argümanı [`IntoIterator`] kullandığından, yalnızca [`Iterator`] in kendisine değil, [`Iterator`] e dönüştürülebilecek her şeyi aktarabiliriz.
    /// Örneğin, (`&[T]`) dilimleri [`IntoIterator`] i uygular ve böylece `zip()` e doğrudan aktarılabilir:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` genellikle sonsuz bir yineleyiciyi sonlu bir yineleyiciye sıkıştırmak için kullanılır.
    /// Bu işe yarar çünkü sonlu yineleyici sonunda [`None`] i döndürecek ve fermuarı sonlandıracaktır.`(0..)` ile sıkıştırma [`enumerate`] e çok benzeyebilir:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Orijinal yineleyicinin bitişik öğeleri arasına `separator` in bir kopyasını yerleştiren yeni bir yineleyici oluşturur.
    ///
    /// `separator` in [`Clone`] i uygulamaması veya her seferinde hesaplanması gerekiyorsa, [`intersperse_with`] i kullanın.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` ten ilk öğe.
    /// assert_eq!(a.next(), Some(&100)); // Ayırıcı.
    /// assert_eq!(a.next(), Some(&1));   // `a` ten sonraki öğe.
    /// assert_eq!(a.next(), Some(&100)); // Ayırıcı.
    /// assert_eq!(a.next(), Some(&2));   // `a` in son elemanı.
    /// assert_eq!(a.next(), None);       // Yineleyici bitti.
    /// ```
    ///
    /// `intersperse` bir yineleyicinin öğelerine ortak bir öğe kullanarak katılmak çok yararlı olabilir:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// `separator` tarafından oluşturulan bir öğeyi orijinal yineleyicinin bitişik öğeleri arasına yerleştiren yeni bir yineleyici oluşturur.
    ///
    /// Kapanış, temel yineleyiciden iki bitişik öğe arasına bir öğe yerleştirildiğinde tam olarak bir kez çağrılacaktır;
    /// özellikle, temel yineleyici ikiden az öğe verirse ve son öğe verildikten sonra kapanış çağrılmaz.
    ///
    ///
    /// Yineleyicinin öğesi [`Clone`] i uygularsa, [`intersperse`] i kullanmak daha kolay olabilir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` ten ilk öğe.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ayırıcı.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` ten sonraki öğe.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ayırıcı.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` in son elemanı.
    /// assert_eq!(it.next(), None);               // Yineleyici bitti.
    /// ```
    ///
    /// `intersperse_with` ayırıcının hesaplanması gereken durumlarda kullanılabilir:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Kapanış, bir öğe oluşturmak için bağlamını mutabık bir şekilde ödünç alır.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Bir kapanış alır ve her öğede bu kapanışı çağıran bir yineleyici oluşturur.
    ///
    /// `map()` argümanı aracılığıyla bir yineleyiciyi diğerine dönüştürür:
    /// [`FnMut`] i uygulayan bir şey.Orijinal yineleyicinin her bir öğesi için bu kapanışı çağıran yeni bir yineleyici üretir.
    ///
    /// Türleri düşünmekte iyiyseniz, `map()` i şöyle düşünebilirsiniz:
    /// Size `A` türü öğeler veren bir yineleyiciniz varsa ve başka türden bir `B` yineleyicisi istiyorsanız, `map()` i kullanarak `A` alan ve `B` döndüren bir kapanışı geçebilirsiniz.
    ///
    ///
    /// `map()` kavramsal olarak bir [`for`] döngüsüne benzer.Bununla birlikte, `map()` tembel olduğu için, halihazırda diğer yineleyicilerle çalışırken en iyi şekilde kullanılır.
    /// Bir yan etki için bir tür döngü yapıyorsanız, [`for`] i kullanmak `map()` ten daha deyimsel olarak kabul edilir.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bir çeşit yan etki yapıyorsanız, [`for`] i `map()` e tercih edin:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // bunu yapma:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // tembel olduğu için bile yürütmez.Rust sizi bu konuda uyaracaktır.
    ///
    /// // Bunun yerine şunun için kullanın:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Bir yineleyicinin her bir öğesi için bir kapatma çağırır.
    ///
    /// Bu, yineleyicide bir [`for`] döngüsü kullanmaya eşdeğerdir, ancak `break` ve `continue` bir kapanıştan mümkün değildir.
    /// Bir `for` döngüsü kullanmak genellikle daha deyimseldir, ancak `for_each`, daha uzun yineleme zincirlerinin sonundaki öğeleri işlerken daha okunaklı olabilir.
    ///
    /// Bazı durumlarda `for_each`, bir döngüden daha hızlı olabilir, çünkü `Chain` gibi adaptörlerde dahili yineleme kullanacaktır.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Bu kadar küçük bir örnek için, bir `for` döngüsü daha temiz olabilir, ancak `for_each`, daha uzun yineleyicilerle işlevsel bir stili korumak için tercih edilebilir:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Bir elemanın verilmesi gerekip gerekmediğini belirlemek için bir kapanış kullanan bir yineleyici oluşturur.
    ///
    /// Bir öğe verildiğinde, kapanış `true` veya `false` döndürmelidir.Döndürülen yineleyici, yalnızca kapanışın true döndürdüğü öğeleri verecektir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `filter()` e aktarılan kapanış bir referans aldığından ve birçok yineleyici referansları yinelediğinden, bu, kapanış türünün çift referans olduğu muhtemelen kafa karıştırıcı bir duruma yol açar:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // iki * 'ye ihtiyacım var!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bunun yerine argümanda yıkıcı kullanmak yaygın bir durumdur:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ikisi ve *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ya da her ikisi de:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // iki &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bu katmanların.
    ///
    /// `iter.filter(f).next()` in `iter.find(f)` e eşdeğer olduğunu unutmayın.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Hem filtreler hem de eşleyen bir yineleyici oluşturur.
    ///
    /// Döndürülen yineleyici, yalnızca sağlanan kapanışın `Some(value)` döndürdüğü "değeri" verir.
    ///
    /// `filter_map` [`filter`] ve [`map`] zincirlerini daha özlü yapmak için kullanılabilir.
    /// Aşağıdaki örnek, bir `map().filter().map()` in tek bir `filter_map` aramasına nasıl kısaltılabileceğini göstermektedir.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// İşte aynı örnek, ancak [`filter`] ve [`map`] ile:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Geçerli yineleme sayısını ve sonraki değeri veren bir yineleyici oluşturur.
    ///
    /// Yineleyici, `(i, val)` çiftlerini verir; burada `i`, yinelemenin geçerli indeksidir ve `val`, yineleyici tarafından döndürülen değerdir.
    ///
    ///
    /// `enumerate()` bir [`usize`] olarak sayılır.
    /// Farklı büyüklükte bir tamsayı ile saymak isterseniz, [`zip`] işlevi benzer işlevsellik sağlar.
    ///
    /// # Taşma Davranışı
    ///
    /// Yöntem taşmalara karşı koruma sağlamaz, bu nedenle [`usize::MAX`] elemanlarından daha fazlasını numaralandırmak ya yanlış sonuç ya da panics verir.
    /// Hata ayıklama iddiaları etkinleştirilirse, bir panic garantilidir.
    ///
    /// # Panics
    ///
    /// Dönen yineleyici, döndürülecek dizin bir [`usize`] i aşacaksa panic olabilir.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Yineleyicinin bir sonraki öğesine tüketmeden bakmak için [`peek`] i kullanabilen bir yineleyici oluşturur.
    ///
    /// Yineleyiciye bir [`peek`] yöntemi ekler.Daha fazla bilgi için belgelerine bakın.
    ///
    /// [`peek`] ilk kez çağrıldığında temel yineleyicinin hala gelişmiş olduğuna dikkat edin: Bir sonraki öğeyi almak için, temel yineleyicide [`next`] çağrılır, dolayısıyla herhangi bir yan etki (örn.
    ///
    /// [`next`] yönteminin sonraki değerini getirmekten başka herhangi bir şey meydana gelecektir.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future'yi görmemizi sağlar
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // peek() i birden çok kez yapabiliriz, yineleyici ilerlemeyecek
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // yineleyici bittikten sonra peek() de
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Bir koşula göre öğelerini [`atlayan '] bir yineleyici oluşturur.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` argüman olarak bir kapanış alır.Yineleyicinin her bir öğesi için bu kapatmayı çağıracak ve `false` döndürene kadar öğeleri yok sayacaktır.
    ///
    /// `false` iade edildikten sonra, `skip_while()`'s işi biter ve geri kalan öğeler verilir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `skip_while()` e iletilen kapanış bir referans aldığından ve birçok yineleyici referansları yinelediğinden, bu, kapanış argümanının türünün çift referans olduğu muhtemelen kafa karıştırıcı bir duruma yol açar:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // iki * 'ye ihtiyacım var!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// İlk `false` ten sonra durdurma:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // bu yanlış olsa da, zaten bir yanlış aldığımız için skip_while() artık kullanılmıyor
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Bir koşula dayalı öğeler veren bir yineleyici oluşturur.
    ///
    /// `take_while()` argüman olarak bir kapanış alır.Yineleyicinin her bir öğesi için bu kapanışı çağıracak ve `true` döndürürken öğeler verecektir.
    ///
    /// `false` iade edildikten sonra, `take_while()`'s işi biter ve geri kalan öğeler yok sayılır.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` e aktarılan kapanış bir referans aldığından ve birçok yineleyici referansları yinelediğinden, bu, kapanış türünün çift referans olduğu muhtemelen kafa karıştırıcı bir duruma yol açar:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // iki * 'ye ihtiyacım var!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// İlk `false` ten sonra durdurma:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Sıfırdan küçük olan daha fazla öğemiz var, ancak zaten yanlış aldığımız için take_while() artık kullanılmıyor
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` in dahil edilip edilmeyeceğini görmek için değere bakması gerektiğinden, tüketen yineleyiciler onun kaldırıldığını görecektir:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` artık orada değil, çünkü yinelemenin durması gerekip gerekmediğini görmek için tüketildi, ancak yineleyiciye geri yerleştirilmedi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Hem bir koşula hem de haritalara dayalı olarak öğeler veren bir yineleyici oluşturur.
    ///
    /// `map_while()` argüman olarak bir kapanış alır.
    /// Yineleyicinin her bir öğesi için bu kapanışı çağıracak ve [`Some(_)`][`Some`] döndürürken öğeler verecektir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// İşte aynı örnek, ancak [`take_while`] ve [`map`] ile:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// İlk [`None`] ten sonra durdurma:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // u32 e (4, 5) sığabilecek daha fazla öğemiz var, ancak `map_while`, `-3` için `None` i döndürdü (`predicate`, `None` i döndürdüğü için) ve karşılaşılan ilk `None` te `collect` durakları.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()` in dahil edilip edilmeyeceğini görmek için değere bakması gerektiğinden, tüketen yineleyiciler onun kaldırıldığını görecektir:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` artık orada değil, çünkü yinelemenin durması gerekip gerekmediğini görmek için tüketildi, ancak yineleyiciye geri yerleştirilmedi.
    ///
    /// [`take_while`] ten farklı olarak bu yineleyicinin kaynaşmış **olmadığını** unutmayın.
    /// Ayrıca, ilk [`None`] döndürüldükten sonra bu yineleyicinin ne döndürdüğü belirtilmemiştir.
    /// Birleştirilmiş yineleyiciye ihtiyacınız varsa, [`fuse`] kullanın.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// İlk `n` öğelerini atlayan bir yineleyici oluşturur.
    ///
    /// Tükendikten sonra, elementlerin geri kalanı verilir.
    /// Bu yöntemi doğrudan geçersiz kılmak yerine, `nth` yöntemini geçersiz kılın.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// İlk `n` öğelerini veren bir yineleyici oluşturur.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` genellikle onu sonlu hale getirmek için sonsuz bir yineleyici ile kullanılır:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `n` ten daha az öğe varsa, `take` kendisini temeldeki yineleyicinin boyutuyla sınırlar:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Dahili durumu tutan ve yeni bir yineleyici üreten, [`fold`] e benzer bir yineleyici adaptörü.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` iki argüman alır: iç durumu tohumlayan bir başlangıç değeri ve iki argüman içeren bir kapanış, birincisi iç duruma değişken bir referans ve ikincisi bir yineleyici öğedir.
    ///
    /// Kapanış, durumu yinelemeler arasında paylaşmak için dahili duruma atayabilir.
    ///
    /// Yinelemede, kapanış yineleyicinin her bir öğesine uygulanacak ve kapanıştan dönüş değeri, bir [`Option`] yineleyici tarafından verilecektir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // her yinelemede, durumu öğeyle çarpacağız
    ///     *state = *state * x;
    ///
    ///     // o zaman, devletin olumsuzlamasını vereceğiz
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Harita gibi çalışan ancak iç içe geçmiş yapıyı düzleştiren bir yineleyici oluşturur.
    ///
    /// [`map`] bağdaştırıcısı çok kullanışlıdır, ancak yalnızca kapanış argümanı değer ürettiğinde.
    /// Bunun yerine bir yineleyici üretirse, fazladan bir yönlendirme katmanı vardır.
    /// `flat_map()` bu ekstra katmanı kendi başına kaldıracaktır.
    ///
    /// `flat_map(f)` i ["harita"] ping'in anlamsal eşdeğeri olarak düşünebilir ve ardından `map(f).flatten()` teki gibi ["düzleştirme" yapabilirsiniz.
    ///
    /// `flat_map()` hakkında düşünmenin başka bir yolu: ["harita"] 'nın kapanışı her öğe için bir öğe döndürür ve `flat_map()`'s kapanışı her öğe için bir yineleyici döndürür.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() bir yineleyici döndürür
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// İç içe geçmiş yapıyı düzleştiren bir yineleyici oluşturur.
    ///
    /// Bu, bir yineleyici yineleyiciniz veya yineleyicilere dönüştürülebilecek şeylerin yineleyicisine sahip olduğunuzda ve bir düzey dolaylılığı kaldırmak istediğinizde kullanışlıdır.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Haritalama ve ardından düzleştirme:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() bir yineleyici döndürür
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Bunu, amacı daha net bir şekilde ifade ettiği için bu durumda tercih edilen [`flat_map()`] açısından da yeniden yazabilirsiniz:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() bir yineleyici döndürür
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Düzleştirme, bir seferde yalnızca bir düzey iç içe geçmeyi kaldırır:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Burada `flatten()` in "deep" düzleştirme yapmadığını görüyoruz.
    /// Bunun yerine, yalnızca bir düzey iç içe geçme kaldırılır.Yani, üç boyutlu bir dizi `flatten()` yaparsanız, sonuç tek boyutlu değil iki boyutlu olacaktır.
    /// Tek boyutlu bir yapı elde etmek için tekrar `flatten()` e ihtiyacınız var.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// İlk [`None`] ten sonra biten bir yineleyici oluşturur.
    ///
    /// Bir yineleyici [`None`] i döndürdükten sonra, future çağrıları yeniden [`Some(T)`] verebilir veya vermeyebilir.
    /// `fuse()` bir yineleyiciyi uyarlayarak, bir [`None`] verildikten sonra daima [`None`] i sonsuza kadar döndürmesini sağlar.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// // Some ve None arasında değişen bir yineleyici
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // eğer çiftse, Some(i32), yoksa Yok
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // yineleyicimizin ileri geri gittiğini görebiliriz
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ancak, bir kez kaynaştırdığımızda ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // her zaman `None` i ilk seferden sonra geri döndürür.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Bir yineleyicinin her öğesiyle bir şeyler yaparak değeri aktarır.
    ///
    /// Yineleyicileri kullanırken, genellikle birkaçını birbirine zincirleyeceksiniz.
    /// Bu tür bir kod üzerinde çalışırken, boru hattının çeşitli bölümlerinde neler olduğunu kontrol etmek isteyebilirsiniz.Bunu yapmak için `inspect()` e bir çağrı ekleyin.
    ///
    /// `inspect()` in bir hata ayıklama aracı olarak kullanılması, son kodunuzda bulunmasından daha yaygındır, ancak uygulamalar, hataların atılmadan önce günlüğe kaydedilmesi gereken belirli durumlarda yararlı bulabilir.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // bu yineleyici dizisi karmaşıktır.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // neler olduğunu araştırmak için bazı inspect() çağrıları ekleyelim
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Bu yazdıracak:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Hataları atmadan önce günlüğe kaydetme:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Bu yazdıracak:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Bir yineleyiciyi tüketmek yerine ödünç alır.
    ///
    /// Bu, orijinal yineleyicinin sahipliğini korurken yineleyici bağdaştırıcılarının uygulanmasına izin vermek için kullanışlıdır.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // iter'i tekrar kullanmayı denersek işe yaramaz.
    /// // Aşağıdaki satır "hata: taşınan değer kullanımı: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // tekrar deneyelim
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // bunun yerine bir .by_ref() ekliyoruz
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // şimdi bu gayet iyi:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Bir yineleyiciyi bir koleksiyona dönüştürür.
    ///
    /// `collect()` yinelenebilir her şeyi alabilir ve ilgili bir koleksiyona dönüştürebilir.
    /// Bu, çeşitli bağlamlarda kullanılan standart kitaplıkta daha güçlü yöntemlerden biridir.
    ///
    /// `collect()` in kullanıldığı en temel model, bir koleksiyonu diğerine dönüştürmektir.
    /// Bir koleksiyon alırsınız, üzerinde [`iter`] i çağırırsınız, bir dizi dönüştürme yaparsınız ve sonra `collect()` i en sonunda yaparsınız.
    ///
    /// `collect()` tipik koleksiyon olmayan türlerin örneklerini de oluşturabilir.
    /// Örneğin, bir [`String`] [`char`] 'lardan oluşturulabilir ve [`Result<T, E>`][`Result`] öğelerinin bir yineleyicisi `Result<Collection<T>, E>` e toplanabilir.
    ///
    /// Daha fazla bilgi için aşağıdaki örneklere bakın.
    ///
    /// `collect()` çok genel olduğu için tür çıkarımıyla ilgili sorunlara neden olabilir.
    /// Bu nedenle, `collect()`, sevgiyle 'turbofish' olarak bilinen sözdizimini göreceğiniz birkaç seferden biridir: `::<>`.
    /// Bu, çıkarım algoritmasının özellikle hangi koleksiyonda toplamaya çalıştığınızı anlamasına yardımcı olur.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Sol tarafta `: Vec<i32>` e ihtiyacımız olduğunu unutmayın.Bunun nedeni, örneğin bir [`VecDeque<T>`] e toplayabilmemizdir:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` e açıklama eklemek yerine 'turbofish' i kullanma:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` yalnızca ne topladığınızla ilgilendiğinden, turbofish ile kısmi bir tür ipucu, `_` kullanmaya devam edebilirsiniz:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] yapmak için `collect()` i kullanma:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// [`Sonuç<T, E>`][`Result`], `collect()` i herhangi birinin başarısız olup olmadığını görmek için kullanabilirsiniz:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // bize ilk hatayı verir
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // bize cevapların listesini verir
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Bir yineleyici tüketir ve ondan iki koleksiyon oluşturur.
    ///
    /// `partition()` e aktarılan tahmin, `true` veya `false` i döndürebilir.
    /// `partition()` `true` i döndürdüğü tüm öğeleri ve `false` i döndürdüğü tüm öğeleri bir çift döndürür.
    ///
    ///
    /// Ayrıca bkz. [`is_partitioned()`] ve [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Bu yineleyicinin öğelerini *yerinde* verilen koşula göre yeniden sıralar, böylece `true` döndürenlerin tümü `false` döndürenlerin hepsinden önce gelir.
    ///
    /// Bulunan `true` öğelerinin sayısını döndürür.
    ///
    /// Bölümlenmiş öğelerin göreceli sırası korunmaz.
    ///
    /// Ayrıca bkz. [`is_partitioned()`] ve [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Çiftler ve oranlar arasında yerinde bölünme
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: sayımın taşması konusunda endişelenmeli miyiz?Daha fazlasına sahip olmanın tek yolu
        // `usize::MAX` değiştirilebilir referanslar, bölümleme için kullanışlı olmayan ZST'lerdedir ...

        // Bu kapatma "factory" işlevleri, `Self` te jenerikliği önlemek için mevcuttur.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Tekrar tekrar ilk `false` i bulun ve son `true` ile değiştirin.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Bu yineleyicinin öğelerinin, `true` döndürenlerin tümü `false` döndürenlerden önce gelecek şekilde, verilen koşula göre bölümlenip bölümlenmediğini kontrol eder.
    ///
    ///
    /// Ayrıca bkz. [`partition()`] ve [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ya tüm öğeler `true` i test eder ya da ilk fıkra `false` te durur ve bundan sonra başka `true` öğesi olmadığını kontrol ederiz.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Başarıyla döndüğü sürece bir işlevi uygulayan ve tek bir son değer üreten bir yineleme yöntemi.
    ///
    /// `try_fold()` iki bağımsız değişken alır: bir başlangıç değeri ve iki bağımsız değişkenli bir kapanış: bir 'accumulator' ve bir öğe.
    /// Kapanış, ya akümülatörün bir sonraki yineleme için sahip olması gereken değerle başarılı bir şekilde geri döner ya da hemen arayana (short-circuiting) geri yayılan bir hata değeriyle başarısızlık döndürür.
    ///
    ///
    /// Başlangıç değeri, akümülatörün ilk çağrıda sahip olacağı değerdir.Kapatma işlemi yineleyicinin her öğesine karşı başarılı olursa, `try_fold()` son toplayıcıyı başarı olarak döndürür.
    ///
    /// Katlama, bir koleksiyonunuz olduğunda ve ondan tek bir değer üretmek istediğinizde kullanışlıdır.
    ///
    /// # Uygulayıcılara Not
    ///
    /// Diğer (forward) yöntemlerinin birçoğunun bu bağlamda varsayılan uygulamaları vardır, bu nedenle varsayılan `for` döngü uygulamasından daha iyi bir şey yapabiliyorsa bunu açıkça uygulamaya çalışın.
    ///
    /// Özellikle, bu yineleyicinin oluşturulduğu dahili parçalarda bu `try_fold()` çağrısını yapmaya çalışın.
    /// Birden fazla çağrı gerekirse, `?` operatörü akümülatör değerini zincirlemek için uygun olabilir, ancak bu erken dönüşlerden önce korunması gereken tüm değişmezlere dikkat edin.
    /// Bu bir `&mut self` yöntemidir, bu nedenle burada bir hataya basıldıktan sonra yinelemenin devam ettirilebilir olması gerekir.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // dizinin tüm öğelerinin kontrol edilen toplamı
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Bu toplam, 100 öğe eklenirken taşıyor
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Kısa devre olduğu için, kalan öğeler yineleyici aracılığıyla hala kullanılabilir.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Yineleyicideki her öğeye bir hata yapma işlevi uygulayan, ilk hatada durduran ve bu hatayı döndüren bir yineleme yöntemi.
    ///
    ///
    /// Bu, [`for_each()`] in yanılabilir formu veya [`try_fold()`] in durumsuz versiyonu olarak da düşünülebilir.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Kısa devre yaptı, bu nedenle kalan öğeler hala yineleyicide:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Bir işlem uygulayarak her öğeyi bir akümülatöre katlar ve nihai sonucu döndürür.
    ///
    /// `fold()` iki bağımsız değişken alır: bir başlangıç değeri ve iki bağımsız değişkenli bir kapanış: bir 'accumulator' ve bir öğe.
    /// Kapanış, akümülatörün bir sonraki yineleme için sahip olması gereken değeri döndürür.
    ///
    /// Başlangıç değeri, akümülatörün ilk çağrıda sahip olacağı değerdir.
    ///
    /// Bu kapanışı yineleyicinin her öğesine uyguladıktan sonra, `fold()` akümülatörü döndürür.
    ///
    /// Bu işleme bazen 'reduce' veya 'inject' adı verilir.
    ///
    /// Katlama, bir koleksiyonunuz olduğunda ve ondan tek bir değer üretmek istediğinizde kullanışlıdır.
    ///
    /// Note: `fold()` ve tüm yineleyiciyi geçen benzer yöntemler, bir sonucun sonlu zamanda belirlenebilir olduğu traits'de bile sonsuz yineleyiciler için sona ermeyebilir.
    ///
    /// Note: Toplayıcı türü ve öğe türü aynıysa, [`reduce()`] ilk öğeyi başlangıç değeri olarak kullanmak için kullanılabilir.
    ///
    /// # Uygulayıcılara Not
    ///
    /// Diğer (forward) yöntemlerinin birçoğunun bu bağlamda varsayılan uygulamaları vardır, bu nedenle varsayılan `for` döngü uygulamasından daha iyi bir şey yapabiliyorsa bunu açıkça uygulamaya çalışın.
    ///
    ///
    /// Özellikle, bu yineleyicinin oluşturulduğu dahili parçalarda bu `fold()` çağrısını yapmaya çalışın.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // dizinin tüm öğelerinin toplamı
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Burada yinelemenin her adımını inceleyelim:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Ve böylece, nihai sonucumuz, `6`.
    ///
    /// Yineleyicileri çok fazla kullanmayanların, bir sonuç oluşturmak için bir şeyler listesi içeren bir `for` döngüsünü kullanması yaygındır.Bunlar `fold()`s e dönüştürülebilir:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // döngü için:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // onlar aynı
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Art arda bir indirgeme işlemi uygulayarak elemanları tek bir değere indirir.
    ///
    /// Yineleyici boşsa, [`None`] i döndürür;aksi takdirde, indirgemenin sonucunu döndürür.
    ///
    /// En az bir elemanı olan yineleyiciler için bu, ilk değer olarak yineleyicinin ilk elemanıyla [`fold()`] ile aynıdır ve sonraki her elemanı içine katlar.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Maksimum değeri bulun:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Yineleyicinin her öğesinin bir yüklemle eşleşip eşleşmediğini test eder.
    ///
    /// `all()` `true` veya `false` döndüren bir kapanış alır.Bu kapanışı yineleyicinin her bir öğesine uygular ve hepsi `true` döndürürse, `all()` de yapar.
    /// Bunlardan herhangi biri `false` döndürürse, `false` döndürür.
    ///
    /// `all()` kısa devre yapıyor;başka bir deyişle, bir `false` bulduğu anda işlemeyi durduracaktır, çünkü başka ne olursa olsun, sonuç da `false` olacaktır.
    ///
    ///
    /// Boş bir yineleyici `true` i döndürür.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// İlk `false` te durmak:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // Daha fazla öğe olduğu için `iter` i hala kullanabiliriz.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Yineleyicinin herhangi bir öğesinin bir yüklemle eşleşip eşleşmediğini test eder.
    ///
    /// `any()` `true` veya `false` döndüren bir kapanış alır.Bu kapatmayı yineleyicinin her bir öğesine uygular ve bunlardan herhangi biri `true` döndürürse, `any()` de yapar.
    /// Hepsi `false` döndürürse, `false` döndürür.
    ///
    /// `any()` kısa devre yapıyor;başka bir deyişle, bir `true` bulduğu anda işlemeyi durduracaktır, çünkü başka ne olursa olsun, sonuç da `true` olacaktır.
    ///
    ///
    /// Boş bir yineleyici `false` i döndürür.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// İlk `true` te durmak:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // Daha fazla öğe olduğu için `iter` i hala kullanabiliriz.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Bir yüklemi karşılayan bir yineleyicinin bir öğesini arar.
    ///
    /// `find()` `true` veya `false` döndüren bir kapanış alır.
    /// Bu kapatmayı yineleyicinin her bir öğesine uygular ve bunlardan herhangi biri `true` döndürürse, `find()` [`Some(element)`] i döndürür.
    /// Hepsi `false` döndürürse, [`None`] döndürür.
    ///
    /// `find()` kısa devre yapıyor;başka bir deyişle, kapanış `true` i döndürür döndürmez işlemeyi durduracaktır.
    ///
    /// `find()` bir referans aldığından ve birçok yineleyici referansların üzerinde yinelediğinden, bu, argümanın bir çift referans olduğu muhtemelen kafa karıştırıcı bir duruma yol açar.
    ///
    /// Bu etkiyi aşağıdaki örneklerde `&&x` ile görebilirsiniz.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// İlk `true` te durmak:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // Daha fazla öğe olduğu için `iter` i hala kullanabiliriz.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)` in `iter.filter(f).next()` e eşdeğer olduğunu unutmayın.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Yineleyicinin öğelerine işlev uygular ve hiçbiri olmayan ilk sonucu döndürür.
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` e eşdeğerdir.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Yineleyicinin öğelerine işlevi uygular ve ilk doğru sonucu veya ilk hatayı döndürür.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Bir yineleyicide bir öğeyi arar ve dizinini döndürür.
    ///
    /// `position()` `true` veya `false` döndüren bir kapanış alır.
    /// Bu kapatmayı yineleyicinin her bir öğesine uygular ve bunlardan biri `true` i döndürürse, `position()` [`Some(index)`] i döndürür.
    /// Hepsi `false` döndürürse, [`None`] döndürür.
    ///
    /// `position()` kısa devre yapıyor;başka bir deyişle, bir `true` bulduğu anda işlemeyi durduracaktır.
    ///
    /// # Taşma Davranışı
    ///
    /// Yöntem taşmalara karşı koruma sağlamaz, bu nedenle [`usize::MAX`] ten fazla eşleşmeyen öğe varsa, ya yanlış sonuç ya da panics üretir.
    ///
    /// Hata ayıklama iddiaları etkinleştirilirse, bir panic garantilidir.
    ///
    /// # Panics
    ///
    /// Yineleyicide `usize::MAX` ten fazla eşleşmeyen öğe varsa, bu işlev panic olabilir.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// İlk `true` te durmak:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // Daha fazla öğe olduğu için `iter` i hala kullanabiliriz.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Döndürülen dizin yineleyici durumuna bağlıdır
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Sağdan bir yineleyicide bir öğe arar ve dizinini döndürür.
    ///
    /// `rposition()` `true` veya `false` döndüren bir kapanış alır.
    /// Bu kapanışı, sondan başlayarak yineleyicinin her bir öğesine uygular ve bunlardan biri `true` i döndürürse, `rposition()`, [`Some(index)`] i döndürür.
    ///
    /// Hepsi `false` döndürürse, [`None`] döndürür.
    ///
    /// `rposition()` kısa devre yapıyor;başka bir deyişle, bir `true` bulduğu anda işlemeyi durduracaktır.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// İlk `true` te durmak:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // Daha fazla öğe olduğu için `iter` i hala kullanabiliriz.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Burada bir taşma kontrolüne gerek yok, çünkü `ExactSizeIterator`, eleman sayısının bir `usize` e sığdığını ima ediyor.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Bir yineleyicinin maksimum öğesini döndürür.
    ///
    /// Birkaç eleman eşit derecede maksimumsa, son eleman döndürülür.
    /// Yineleyici boşsa, [`None`] döndürülür.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Bir yineleyicinin minimum öğesini döndürür.
    ///
    /// Birkaç eleman eşit derecede minimum ise, ilk eleman döndürülür.
    /// Yineleyici boşsa, [`None`] döndürülür.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Belirtilen işlevden maksimum değeri veren öğeyi döndürür.
    ///
    ///
    /// Birkaç eleman eşit derecede maksimumsa, son eleman döndürülür.
    /// Yineleyici boşsa, [`None`] döndürülür.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Belirtilen karşılaştırma işlevine göre maksimum değeri veren öğeyi döndürür.
    ///
    ///
    /// Birkaç eleman eşit derecede maksimumsa, son eleman döndürülür.
    /// Yineleyici boşsa, [`None`] döndürülür.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Belirtilen işlevden minimum değeri veren öğeyi döndürür.
    ///
    ///
    /// Birkaç eleman eşit derecede minimum ise, ilk eleman döndürülür.
    /// Yineleyici boşsa, [`None`] döndürülür.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Belirtilen karşılaştırma işlevine göre minimum değeri veren öğeyi döndürür.
    ///
    ///
    /// Birkaç eleman eşit derecede minimum ise, ilk eleman döndürülür.
    /// Yineleyici boşsa, [`None`] döndürülür.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Yineleyicinin yönünü tersine çevirir.
    ///
    /// Genellikle yineleyiciler soldan sağa yineler.
    /// `rev()` i kullandıktan sonra, bir yineleyici bunun yerine sağdan sola yineleme yapacaktır.
    ///
    /// Bu yalnızca yineleyicinin bir sonu varsa mümkündür, bu nedenle `rev()` yalnızca [`DoubleEndedIterator`] 'larda çalışır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Bir çift yineleyiciyi bir çift kaba dönüştürür.
    ///
    /// `unzip()` çift yineleyicinin tamamını tüketerek iki koleksiyon oluşturur: biri çiftlerin sol öğelerinden, diğeri sağ öğelerden.
    ///
    ///
    /// Bu işlev bir anlamda [`zip`] in tersidir.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Tüm öğelerini kopyalayan bir yineleyici oluşturur.
    ///
    /// Bu, `&T` üzerinde bir yineleyiciniz olduğunda kullanışlıdır, ancak `T` üzerinde bir yineleyiciye ihtiyacınız vardır.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopyalanan .map(|&x| x) ile aynı
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Tüm öğelerini ["klonlayan" bir yineleyici oluşturur.
    ///
    /// Bu, `&T` üzerinde bir yineleyiciniz olduğunda kullanışlıdır, ancak `T` üzerinde bir yineleyiciye ihtiyacınız vardır.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klonlanmış tamsayılar için .map(|&x| x) ile aynıdır
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Bir yineleyiciyi hiç durmadan tekrarlar.
    ///
    /// [`None`] te durmak yerine, yineleyici en baştan yeniden başlayacaktır.Tekrar yineledikten sonra, yeniden baştan başlayacaktır.Ve yeniden.
    /// Ve yeniden.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Bir yineleyicinin öğelerini toplar.
    ///
    /// Her bir öğeyi alır, onları bir araya getirir ve sonucu döndürür.
    ///
    /// Boş bir yineleyici, türün sıfır değerini döndürür.
    ///
    /// # Panics
    ///
    /// `sum()` çağrılırken ve ilkel bir tamsayı türü döndürülürken, hesaplama taşmaları ve hata ayıklama iddiaları etkinleştirilirse bu yöntem panic olacaktır.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Tüm yineleyici üzerinde yineler, tüm öğeleri çoğaltır
    ///
    /// Boş bir yineleyici, türün bir değerini döndürür.
    ///
    /// # Panics
    ///
    /// `product()` çağrılırken ve bir ilkel tamsayı türü döndürülürken, hesaplama taşmaları ve hata ayıklama iddiaları etkinleştirilirse yöntem panic olacaktır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) bu [`Iterator`] in öğelerini diğerleriyle karşılaştırır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) Bu [`Iterator`] in öğelerini, belirtilen karşılaştırma işlevi açısından diğerinin öğeleriyle karşılaştırır.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) bu [`Iterator`] in öğelerini diğerleriyle karşılaştırır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) Bu [`Iterator`] in öğelerini, belirtilen karşılaştırma işlevi açısından diğerinin öğeleriyle karşılaştırır.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Bu [`Iterator`] in elemanlarının diğerine eşit olup olmadığını belirler.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Bu [`Iterator`] in öğelerinin, belirtilen eşitlik işlevi açısından diğerinin öğelerine eşit olup olmadığını belirler.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Bu [`Iterator`] in elemanlarının diğerine eşit olup olmadığını belirler.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Bu [`Iterator`] in elemanlarının diğerlerinden [lexicographically](Ord#lexicographical-comparison) daha az olup olmadığını belirler.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Bu [`Iterator`] in elemanlarının [lexicographically](Ord#lexicographical-comparison) daha küçük veya başka birine eşit olup olmadığını belirler.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Bu [`Iterator`] in elemanlarının diğerlerinden [lexicographically](Ord#lexicographical-comparison) daha büyük olup olmadığını belirler.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Bu [`Iterator`] in elemanlarının [lexicographically](Ord#lexicographical-comparison) in diğerine eşit veya daha büyük olup olmadığını belirler.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Bu yineleyicinin öğelerinin sıralanıp sıralanmadığını kontrol eder.
    ///
    /// Yani, her `a` öğesi ve onu takip eden `b` öğesi için `a <= b` tutmalıdır.Yineleyici tam olarak sıfır veya bir öğe verirse, `true` döndürülür.
    ///
    /// `Self::Item` yalnızca `PartialOrd` ise, ancak `Ord` değilse, yukarıdaki tanımın, iki ardışık öğe karşılaştırılabilir değilse bu işlevin `false` döndürdüğünü ima ettiğini unutmayın.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Bu yineleyicinin öğelerinin verilen karşılaştırma işlevi kullanılarak sıralanıp sıralanmadığını kontrol eder.
    ///
    /// Bu işlev, `PartialOrd::partial_cmp` kullanmak yerine, iki öğenin sırasını belirlemek için verilen `compare` işlevini kullanır.
    /// Bunun dışında [`is_sorted`] e eşdeğer;daha fazla bilgi için belgelerine bakın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Bu yineleyicinin öğelerinin verilen anahtar çıkarma işlevi kullanılarak sıralanıp sıralanmadığını kontrol eder.
    ///
    /// Yineleyicinin öğelerini doğrudan karşılaştırmak yerine, bu işlev öğelerin anahtarlarını `f` tarafından belirlenen şekilde karşılaştırır.
    /// Bunun dışında [`is_sorted`] e eşdeğer;daha fazla bilgi için belgelerine bakın.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] e bakın
    // Alışılmadık ad, yöntem çözümlemesinde ad çakışmalarını önlemektir, bkz. #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}