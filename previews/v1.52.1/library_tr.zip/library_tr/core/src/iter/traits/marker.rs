/// Bittiğinde her zaman `None` vermeyi sürdüren bir yineleyici.
///
/// `None` i bir kez döndüren sigortalı bir yineleyicide bir sonraki çağrının [`None`] i tekrar döndürmesi garanti edilir.
/// Bu trait, [`Iterator::fuse()`] in optimize edilmesine izin verdiği için bu şekilde davranan tüm yineleyiciler tarafından uygulanmalıdır.
///
///
/// Note: Genel olarak, sigortalı bir yineleyiciye ihtiyacınız varsa, `FusedIterator` i genel sınırlarda kullanmamalısınız.
/// Bunun yerine, yineleyicide [`Iterator::fuse()`] i aramalısınız.
/// Yineleyici zaten kaynaşmışsa, ek [`Fuse`] sarıcı, performans kesintisi olmaksızın işlemsiz olacaktır.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Size_hint kullanarak doğru bir uzunluk bildiren bir yineleyici.
///
/// Yineleyici, kesin olduğu (alt sınırın üst sınıra eşit olduğu) veya üst sınırın [`None`] olduğu bir boyut ipucu bildirir.
///
/// Gerçek yineleyici uzunluğu [`usize::MAX`] ten büyükse, üst sınır yalnızca [`None`] olmalıdır.
/// Bu durumda, alt sınır [`usize::MAX`] olmalı ve [`Iterator::size_hint()`] `(usize::MAX, None)` ile sonuçlanmalıdır.
///
/// Yineleyici, sona ulaşmadan önce rapor ettiği veya birbirinden uzaklaştığı öğe sayısını tam olarak üretmelidir.
///
/// # Safety
///
/// Bu trait yalnızca sözleşme onaylandığında uygulanmalıdır.
/// Bu trait tüketicileri [`Iterator::size_hint()`]’s üst sınırını incelemelidir.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Bir öğeyi verirken temeldeki [`SourceIter`] ten en az bir öğe almış olacak bir yineleyici.
///
/// Yineleyiciyi ilerleten herhangi bir yöntemi çağırmak, örneğin
/// [`next()`] veya [`try_fold()`], kaynağın yapısal kısıtlamalarının böyle bir eklemeye izin verdiği varsayılarak, her adım için yineleyicinin temelindeki kaynağın en az bir değerinin çıkarıldığını ve yineleyici zincirinin sonucunun yerine yerleştirilebileceğini garanti eder.
///
/// Diğer bir deyişle, bu trait, bir yineleyici boru hattının yerinde toplanabileceğini gösterir.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}