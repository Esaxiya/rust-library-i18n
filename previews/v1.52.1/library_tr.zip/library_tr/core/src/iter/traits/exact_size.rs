/// Tam uzunluğunu bilen bir yineleyici.
///
/// Çoğu ["Yineleyici", kaç kez yineleme yapacağını bilmez, ancak bazıları yineler.
/// Bir yineleyici kaç kez yineleyebileceğini biliyorsa, bu bilgilere erişim sağlamak yararlı olabilir.
/// Örneğin, geriye doğru yinelemek istiyorsanız, sonun nerede olduğunu bilmek iyi bir başlangıçtır.
///
/// Bir `ExactSizeIterator` uygularken, [`Iterator`] i de uygulamanız gerekir.
/// Bunu yaparken, [`Iterator::size_hint`]*uygulaması yineleyicinin tam boyutunu döndürmelidir*.
///
/// [`len`] yönteminin varsayılan bir uygulaması vardır, bu nedenle genellikle onu uygulamamalısınız.
/// Bununla birlikte, varsayılandan daha performanslı bir uygulama sağlayabilirsiniz, bu nedenle bu durumda onu geçersiz kılmak mantıklıdır.
///
///
/// Bu trait'nin güvenli bir trait olduğunu ve bu nedenle döndürülen uzunluğun doğru olduğunu *garanti edemeyeceğini* ve * garanti edemeyeceğini unutmayın.
/// Bu, `unsafe` kodunun **[`Iterator::size_hint`] in doğruluğuna güvenmemesi** gerektiği anlamına gelir.
/// Kararsız ve güvenli olmayan [`TrustedLen`](super::marker::TrustedLen) trait bu ek garantiyi verir.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// // sonlu bir aralık tam olarak kaç kez yineleyeceğini bilir
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] te bir [`Iterator`] uyguladık, `Counter`.
/// Bunun için `ExactSizeIterator` i de uygulayalım:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Kalan yineleme sayısını kolayca hesaplayabiliriz.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ve şimdi onu kullanabiliriz!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Yineleyicinin tam uzunluğunu döndürür.
    ///
    /// Uygulama, yineleyicinin [`None`] i döndürmeden önce bir [`Some(T)`] değerinin tam olarak `len()` katı döndürmesini sağlar.
    ///
    /// Bu yöntemin varsayılan bir uygulaması vardır, bu nedenle genellikle onu doğrudan uygulamamalısınız.
    /// Ancak, daha verimli bir uygulama sağlayabilirseniz, bunu yapabilirsiniz.
    /// Örnek için [trait-level] belgelerine bakın.
    ///
    /// Bu işlev, [`Iterator::size_hint`] işlevi ile aynı güvenlik garantilerine sahiptir.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// // sonlu bir aralık tam olarak kaç kez yineleyeceğini bilir
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Bu iddia aşırı savunmacıdır, ancak değişmezliği kontrol eder.
        // trait garantilidir.
        // Bu trait rust-internal olsaydı, debug_assert! Kullanabilirdik.assert_eq!tüm Rust kullanıcı uygulamalarını da kontrol edecek.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Yineleyici boşsa `true` i döndürür.
    ///
    /// Bu yöntemin [`ExactSizeIterator::len()`] kullanan varsayılan bir uygulaması vardır, bu nedenle onu kendiniz uygulamanıza gerek yoktur.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}