/// [`Iterator`] ten dönüştürme.
///
/// Bir tür için `FromIterator` uygulayarak, bir yineleyiciden nasıl oluşturulacağını tanımlarsınız.
/// Bu, bir tür koleksiyonu tanımlayan türler için yaygındır.
///
/// [`FromIterator::from_iter()`] nadiren açıkça çağrılır ve bunun yerine [`Iterator::collect()`] yöntemi ile kullanılır.
///
/// Daha fazla örnek için [`Iterator::collect()`]'s belgelerine bakın.
///
/// Ayrıca bakınız: [`IntoIterator`].
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` i dolaylı olarak kullanmak için [`Iterator::collect()`] i kullanma:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Türünüz için `FromIterator` in uygulanması:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Örnek bir koleksiyon, bu sadece Vec üzerinden bir paketleyicidir<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ona bazı yöntemler verelim, böylece bir tane oluşturabilir ve ona bir şeyler ekleyebiliriz.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ve FromIterator'ı uygulayacağız
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Şimdi yeni bir yineleyici yapabiliriz ...
/// let iter = (0..5).into_iter();
///
/// // ... ve bundan bir MyCollection yapın
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // işleri de topla!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Bir yineleyiciden bir değer oluşturur.
    ///
    /// Daha fazlası için [module-level documentation] e bakın.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] e dönüştürme.
///
/// Bir tür için `IntoIterator` uygulayarak, onun bir yineleyiciye nasıl dönüştürüleceğini tanımlarsınız.
/// Bu, bir tür koleksiyonu tanımlayan türler için yaygındır.
///
/// `IntoIterator` i uygulamanın bir yararı, türünüzün [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) olmasıdır.
///
///
/// Ayrıca bakınız: [`FromIterator`].
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Türünüz için `IntoIterator` in uygulanması:
///
/// ```
/// // Örnek bir koleksiyon, bu sadece Vec üzerinden bir paketleyicidir<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ona bazı yöntemler verelim, böylece bir tane oluşturabilir ve ona bir şeyler ekleyebiliriz.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ve IntoIterator'ı uygulayacağız
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Artık yeni bir koleksiyon yapabiliriz ...
/// let mut c = MyCollection::new();
///
/// // ... ona bir şeyler ekle ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ve sonra onu bir Yineleyiciye dönüştürün:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` i trait bound olarak kullanmak yaygındır.Bu, hala bir yineleyici olduğu sürece girdi toplama türünün değişmesine izin verir.
/// Sınırlama yapılarak ek sınırlar belirlenebilir
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Üzerinde yinelenen öğelerin türü.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Bunu hangi tür tekrarlayıcıya dönüştürüyoruz?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Bir değerden bir yineleyici oluşturur.
    ///
    /// Daha fazlası için [module-level documentation] e bakın.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Bir yineleyicinin içeriğiyle bir koleksiyonu genişletin.
///
/// Yineleyiciler bir dizi değer üretir ve koleksiyonlar bir dizi değer olarak da düşünülebilir.
/// `Extend` trait bu boşluğu doldurur ve bu yineleyicinin içeriğini dahil ederek bir koleksiyonu genişletmenize olanak tanır.
/// Zaten var olan bir anahtarla bir koleksiyonu genişletirken, bu giriş güncellenir veya eşit anahtarlarla birden çok girişe izin veren koleksiyonlar söz konusu olduğunda, bu giriş eklenir.
///
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// // Bir Stringi bazı karakterlerle uzatabilirsiniz:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` in uygulanması:
///
/// ```
/// // Örnek bir koleksiyon, bu sadece Vec üzerinden bir paketleyicidir<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ona bazı yöntemler verelim, böylece bir tane oluşturabilir ve ona bir şeyler ekleyebiliriz.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection bir i32 listesine sahip olduğundan, i32 için Extend uyguluyoruz
/// impl Extend<i32> for MyCollection {
///
///     // Somut tip imzasıyla bu biraz daha basittir: Bize i32'leri veren bir Yineleyiciye dönüştürülebilecek her şeye genişleme diyebiliriz.
///     // Çünkü MyCollection'a koymak için i32'lere ihtiyacımız var.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Uygulama çok basittir: yineleyici aracılığıyla döngü yapın ve her bir öğeyi kendimize add().
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // koleksiyonumuzu üç numara ile genişletelim
/// c.extend(vec![1, 2, 3]);
///
/// // bu unsurları sonuna ekledik
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Bir yineleyicinin içeriğiyle bir koleksiyonu genişletir.
    ///
    /// Bu trait için gerekli olan tek yöntem bu olduğundan, [trait-level] belgeleri daha fazla ayrıntı içerir.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// // Bir Stringi bazı karakterlerle uzatabilirsiniz:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Tam olarak bir öğe içeren bir koleksiyonu genişletir.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Verilen sayıda ek öğe için bir koleksiyondaki kapasiteyi rezerve eder.
    ///
    /// Varsayılan uygulama hiçbir şey yapmaz.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}