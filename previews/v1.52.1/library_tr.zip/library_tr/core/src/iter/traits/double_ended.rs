use crate::ops::{ControlFlow, Try};

/// Her iki uçtan da öğeler elde edebilen bir yineleyici.
///
/// `DoubleEndedIterator` i uygulayan bir şeyin, [`Iterator`] i uygulayan bir şeye göre fazladan bir yeteneği vardır: hem arkadan hem de önden "Öğeler" alma yeteneği.
///
///
/// Hem ileri hem de geri aynı aralıkta çalıştığına ve kesişmediğine dikkat etmek önemlidir: ortada buluştuklarında yineleme sona erer.
///
/// [`Iterator`] protokolüne benzer bir şekilde, bir `DoubleEndedIterator`, [`next_back()`] ten [`None`] i döndürdüğünde, onu tekrar çağırmak, [`Some`] i bir daha geri döndürebilir ya da vermeyebilir.
/// [`next()`] ve [`next_back()`] bu amaç için birbirinin yerine kullanılabilir.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Yineleyicinin sonundan bir öğeyi kaldırır ve döndürür.
    ///
    /// Başka öğe kalmadığında `None` i döndürür.
    ///
    /// [trait-level] belgeleri daha fazla ayrıntı içerir.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// "DoubleEndedIterator" yöntemlerinin sağladığı öğeler, ["Iterator"] yöntemlerinin sağladığı öğelerden farklı olabilir:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Yineleyiciyi arkadan `n` öğeleriyle ilerletir.
    ///
    /// `advance_back_by` [`advance_by`] in ters sürümüdür.Bu yöntem, [`None`] ile karşılaşılıncaya kadar `n` i `n` e kadar `n` kez çağırarak arkadan başlayarak `n` öğelerini hevesle atlayacaktır.
    ///
    /// `advance_back_by(n)` Yineleyici `n` öğeleriyle başarılı bir şekilde ilerlerse [`Ok(())`] i veya [`None`] ile karşılaşılırsa [`Err(k)`] i döndürür; burada `k`, öğeler tükenmeden önce yineleyicinin geliştirildiği öğelerin sayısıdır (ör.
    /// yineleyicinin uzunluğu).
    /// `k` in her zaman `n` ten küçük olduğuna dikkat edin.
    ///
    /// `advance_back_by(0)` i çağırmak herhangi bir öğe tüketmez ve her zaman [`Ok(())`] i döndürür.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // sadece `&3` atlandı
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Yineleyicinin sonundan "n" inci öğeyi döndürür.
    ///
    /// Bu, esasen [`Iterator::nth()`] in tersine çevrilmiş versiyonudur.
    /// Çoğu indeksleme işleminde olduğu gibi, sayım sıfırdan başlar, bu nedenle `nth_back(0)` sondan ilk değeri, `nth_back(1)` ikinciyi vb. Döndürür.
    ///
    ///
    /// Son ve döndürülen öğe arasındaki tüm öğelerin, döndürülen öğe de dahil olmak üzere tüketileceğini unutmayın.
    /// Bu aynı zamanda `nth_back(0)` i aynı yineleyici üzerinde birden çok kez çağırmanın farklı öğeler getireceği anlamına gelir.
    ///
    /// `nth_back()` `n` yineleyicinin uzunluğundan büyük veya ona eşitse [`None`] döndürür.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` i birden çok kez aramak yineleyiciyi geri sarmaz:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1` ten daha az öğe varsa `None` döndürülür:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Bu, [`Iterator::try_fold()`] in ters sürümüdür: öğeleri yineleyicinin arkasından başlayarak alır.
    ///
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Kısa devre olduğu için, kalan öğeler yineleyici aracılığıyla hala kullanılabilir.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Yineleyicinin öğelerini arkadan başlayarak tek bir son değere indirgeyen bir yineleme yöntemi.
    ///
    /// Bu, [`Iterator::fold()`] in ters sürümüdür: öğeleri yineleyicinin arkasından başlayarak alır.
    ///
    /// `rfold()` iki bağımsız değişken alır: bir başlangıç değeri ve iki bağımsız değişkenli bir kapanış: bir 'accumulator' ve bir öğe.
    /// Kapanış, akümülatörün bir sonraki yineleme için sahip olması gereken değeri döndürür.
    ///
    /// Başlangıç değeri, akümülatörün ilk çağrıda sahip olacağı değerdir.
    ///
    /// Bu kapanışı yineleyicinin her öğesine uyguladıktan sonra, `rfold()` akümülatörü döndürür.
    ///
    /// Bu işleme bazen 'reduce' veya 'inject' adı verilir.
    ///
    /// Katlama, bir koleksiyonunuz olduğunda ve ondan tek bir değer üretmek istediğinizde kullanışlıdır.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a'nın tüm öğelerinin toplamı
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Bu örnek, bir başlangıç değeriyle başlayıp arkadan öne kadar her öğeyle devam eden bir dize oluşturur:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Arka taraftan bir yüklemi karşılayan bir yineleyicinin bir öğesini arar.
    ///
    /// `rfind()` `true` veya `false` döndüren bir kapanış alır.
    /// Bu kapanışı, sondan başlayarak yineleyicinin her bir öğesine uygular ve bunlardan herhangi biri `true` döndürürse, `rfind()`, [`Some(element)`] i döndürür.
    /// Hepsi `false` döndürürse, [`None`] döndürür.
    ///
    /// `rfind()` kısa devre yapıyor;başka bir deyişle, kapanış `true` i döndürür döndürmez işlemeyi durduracaktır.
    ///
    /// `rfind()` bir referans aldığından ve birçok yineleyici referansların üzerinde yinelediğinden, bu, argümanın bir çift referans olduğu muhtemelen kafa karıştırıcı bir duruma yol açar.
    ///
    /// Bu etkiyi aşağıdaki örneklerde `&&x` ile görebilirsiniz.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// İlk `true` te durmak:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // Daha fazla öğe olduğu için `iter` i hala kullanabiliriz.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}