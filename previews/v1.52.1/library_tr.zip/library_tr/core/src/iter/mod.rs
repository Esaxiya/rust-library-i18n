//! Oluşturulabilir harici yineleme.
//!
//! Kendinizi bir tür koleksiyonla bulduysanız ve söz konusu koleksiyonun öğeleri üzerinde bir işlem yapmanız gerekiyorsa, hızlı bir şekilde 'iterators' ile karşılaşacaksınız.
//! Yineleyiciler, deyimsel Rust kodunda yoğun bir şekilde kullanılır, bu yüzden onlara aşina olmaya değer.
//!
//! Daha fazlasını açıklamadan önce, bu modülün nasıl yapılandırıldığından bahsedelim:
//!
//! # Organization
//!
//! Bu modül büyük ölçüde türe göre düzenlenmiştir:
//!
//! * [Traits] çekirdek kısımdır: bu traits, ne tür yineleyicilerin var olduğunu ve onlarla neler yapabileceğinizi tanımlar.Bu traits'nin yöntemleri, biraz daha fazla çalışma süresi ayırmaya değer.
//! * [Functions] bazı temel yineleyiciler oluşturmanın bazı yararlı yollarını sağlayın.
//! * [Structs] genellikle bu modülün traits'sindeki çeşitli yöntemlerin dönüş türleridir.Genellikle `struct` in kendisi yerine `struct` i oluşturan yönteme bakmak isteyeceksiniz.
//! Nedeniyle ilgili daha fazla ayrıntı için bkz. '[Yineleyici Uygulama](#implementing-yineleyici)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Bu kadar!Yineleyicileri inceleyelim.
//!
//! # Iterator
//!
//! Bu modülün kalbi ve ruhu [`Iterator`] trait'dir.[`Iterator`] in çekirdeği şuna benzer:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Bir yineleyici, çağrıldığında bir [`Option`]` döndüren bir [`next`] yöntemine sahiptir.<Item>.
//! [`next`] öğeler olduğu sürece [`Some(Item)`] i döndürecektir ve hepsi tükendiğinde, yinelemenin bittiğini belirtmek için `None` i döndürecektir.
//! Bireysel yineleyiciler yinelemeye devam etmeyi seçebilir ve bu nedenle [`next`] i tekrar çağırmak, sonunda [`Some(Item)`] i bir noktada yeniden döndürmeye başlayabilir veya başlamayabilir (örneğin, bkz. [`TryIter`]).
//!
//!
//! [`Iterator`] 'ın tam tanımı bir dizi başka yöntemi de içerir, ancak bunlar varsayılan yöntemlerdir, [`next`] üzerine inşa edilmiştir ve bu nedenle bunları ücretsiz olarak edinebilirsiniz.
//!
//! Yineleyiciler de bir araya getirilebilir ve daha karmaşık işleme biçimleri yapmak için onları birbirine zincirlemek yaygındır.Daha fazla ayrıntı için aşağıdaki [Adapters](#adapters) bölümüne bakın.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Üç yineleme biçimi
//!
//! Bir koleksiyondan yineleyiciler oluşturabilen üç yaygın yöntem vardır:
//!
//! * `iter()`, `&T` üzerinde yinelenen.
//! * `iter_mut()`, `&mut T` üzerinde yinelenen.
//! * `into_iter()`, `T` üzerinde yinelenen.
//!
//! Standart kitaplıktaki çeşitli şeyler, uygun olduğunda üçünden birini veya daha fazlasını uygulayabilir.
//!
//! # Yineleyici Uygulama
//!
//! Kendi yineleyicinizi oluşturmak iki adımdan oluşur: yineleyicinin durumunu tutmak için bir `struct` oluşturmak ve ardından bu `struct` için [`Iterator`] i uygulamak.
//! Bu modülde bu kadar çok "struct" olmasının nedeni budur: her yineleyici ve yineleyici bağdaştırıcısı için bir tane vardır.
//!
//! `1` ten `5` e kadar sayan `Counter` adlı bir yineleyici yapalım:
//!
//! ```
//! // İlk olarak, yapı:
//!
//! /// Birden beşe kadar sayan bir yineleyici
//! struct Counter {
//!     count: usize,
//! }
//!
//! // sayımımızın birde başlamasını istiyoruz, bu yüzden yardımcı olması için bir new() yöntemi ekleyelim.
//! // Bu kesinlikle gerekli değildir, ancak uygundur.
//! // `count` i sıfırdan başlattığımıza dikkat edin, neden aşağıda `next()`'s uygulamasında göreceğiz.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ardından, `Counter` imiz için `Iterator` i uyguluyoruz:
//!
//! impl Iterator for Counter {
//!     // usize ile sayıyor olacağız
//!     type Item = usize;
//!
//!     // next() gerekli tek yöntem
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Sayımızı artırın.Bu yüzden sıfırdan başladık.
//!         self.count += 1;
//!
//!         // Saymayı bitirip bitirmediğimizi kontrol edin.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ve şimdi onu kullanabiliriz!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`] i bu şekilde aramak tekrarlı hale gelir.Rust, `None` e ulaşana kadar yineleyicinizde [`next`] i çağırabilen bir yapıya sahiptir.Şimdi bunun üzerinden geçelim.
//!
//! Ayrıca, `Iterator` in `next` i dahili olarak çağıran `nth` ve `fold` gibi yöntemlerin varsayılan uygulamasını sağladığını unutmayın.
//! Ancak, bir yineleyici `next` i çağırmadan bunları daha verimli bir şekilde hesaplayabilirse, `nth` ve `fold` gibi yöntemlerin özel bir uygulamasını yazmak da mümkündür.
//!
//! # `for` döngüler ve `IntoIterator`
//!
//! Rust'nin `for` döngü sözdizimi aslında yineleyiciler için şekerdir.İşte temel bir `for` örneği:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Bu, her biri kendi satırında olmak üzere birden beşe kadar olan sayıları yazdıracaktır.Ama burada bir şey fark edeceksiniz: vector'de bir yineleyici üretmek için hiçbir şey çağırmadık.Ne oluyor?
//!
//! Standart kitaplıkta bir şeyi yineleyiciye dönüştürmek için bir trait vardır: [`IntoIterator`].
//! Bu trait, [`IntoIterator`] i uygulayan şeyi bir yineleyiciye dönüştüren [`into_iter`] adlı bir yönteme sahiptir.
//! Bu `for` döngüsüne tekrar bir göz atalım ve derleyicinin onu neye dönüştürdüğüne bakalım:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust bunu şu şekilde çözer:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Öncelikle değer üzerine `into_iter()` diyoruz.Ardından, geri dönen yineleyici üzerinde eşleşir, [`next`] i bir `None` görene kadar defalarca çağırırız.
//! Bu noktada, `break` döngüden çıktık ve yinelemeyi bitirdik.
//!
//! Burada ince bir bit daha var: standart kütüphane [`IntoIterator`] in ilginç bir uygulamasını içerir:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Başka bir deyişle, tüm ["Yineleyici" ler [`IntoIterator`] i yalnızca kendilerini döndürerek uygular.Bu iki anlama gelir:
//!
//! 1. Bir [`Iterator`] yazıyorsanız, onu bir `for` döngüsü ile kullanabilirsiniz.
//! 2. Bir koleksiyon oluşturuyorsanız, bunun için [`IntoIterator`] uygulamak, koleksiyonunuzun `for` döngüsü ile kullanılmasına izin verecektir.
//!
//! # Referans ile yineleme
//!
//! [`into_iter()`], `self` i değere göre aldığından, bir koleksiyon üzerinde yinelemek için bir `for` döngüsü kullanmak bu koleksiyonu tüketir.Genellikle, bir koleksiyonu tüketmeden üzerinde yinelemek isteyebilirsiniz.
//! Birçok koleksiyon, geleneksel olarak sırasıyla `iter()` ve `iter_mut()` olarak adlandırılan referanslar üzerinde yineleyiciler sağlayan yöntemler sunar:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` hala bu işleve aittir.
//! ```
//!
//! Bir koleksiyon türü `C`, `iter()` sağlıyorsa, genellikle yalnızca `iter()` i çağıran bir uygulama ile `&C` için `IntoIterator` i de uygular.
//! Benzer şekilde, `iter_mut()` sağlayan bir `C` koleksiyonu, genellikle `iter_mut()` e delege ederek `&mut C` için `IntoIterator` i uygular.Bu, kullanışlı bir kısaltma sağlar:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` ile aynı
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` ile aynı
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Pek çok koleksiyon `iter()` sunarken, hepsi `iter_mut()` sunmaz.
//! Örneğin, bir [`HashSet<T>`] veya [`HashMap<K, V>`] in anahtarlarını değiştirmek, anahtar karmaları değişirse koleksiyonu tutarsız bir duruma sokabilir, bu nedenle bu koleksiyonlar yalnızca `iter()` sunar.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Bir [`Iterator`] alıp başka bir [`Iterator`] döndüren işlevler, 'adaptörün bir biçimi oldukları için genellikle' yineleyici bağdaştırıcıları 'olarak adlandırılır.
//! pattern'.
//!
//! Yaygın yineleyici adaptörleri arasında [`map`], [`take`] ve [`filter`] bulunur.
//! Daha fazla bilgi için belgelerine bakın.
//!
//! Bir yineleyici bağdaştırıcısı panics ise, yineleyici belirtilmemiş (ancak bellek güvenli) bir durumda olacaktır.
//! Bu durumun Rust sürümlerinde aynı kalması da garanti edilmez, bu nedenle panikleyen bir yineleyici tarafından döndürülen kesin değerlere güvenmekten kaçınmalısınız.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Yineleyiciler (ve yineleyici [adapters](#adapters))*tembeldir*. Bu, yalnızca bir yineleyici oluşturmanın çok fazla _do_ olmadığı anlamına gelir. [`next`] i çağırana kadar gerçekten hiçbir şey olmaz.
//! Bu bazen, yalnızca yan etkileri için bir yineleyici oluştururken bir kafa karışıklığı kaynağıdır.
//! Örneğin, [`map`] yöntemi üzerinde yinelediği her öğe için bir kapatma çağırır:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Kullanmak yerine sadece bir yineleyici oluşturduğumuzdan, bu herhangi bir değeri yazdırmayacaktır.Derleyici bizi bu tür davranışlar hakkında uyaracaktır:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Bir [`map`] i yan etkileri için yazmanın deyimsel yolu, bir `for` döngüsü kullanmak veya [`for_each`] yöntemini çağırmaktır:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Yineleyiciyi değerlendirmenin diğer bir yaygın yolu, yeni bir koleksiyon oluşturmak için [`collect`] yöntemini kullanmaktır.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Yineleyicilerin sonlu olması gerekmez.Örnek olarak, açık uçlu bir aralık sonsuz bir yineleyicidir:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Sonsuz bir yineleyiciyi sonlu bir yineleyiciye dönüştürmek için [`take`] yineleyici adaptörünü kullanmak yaygındır:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Bu, `0` ile `4` arasındaki sayıları her biri kendi satırında yazdıracaktır.
//!
//! Sonsuz yineleyiciler üzerindeki yöntemlerin, sonlu zamanda matematiksel olarak bir sonucu belirlenebilenlerin bile sona ermeyebileceğini unutmayın.
//! Spesifik olarak, genel durumda yineleyicideki her öğenin geçişini gerektiren [`min`] gibi yöntemler, herhangi bir sonsuz yineleyici için başarılı bir şekilde geri dönmeyebilir.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh hayır!Sonsuz bir döngü!
//! // `ones.min()` sonsuz bir döngüye neden olur, bu yüzden bu noktaya ulaşmayacağız!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;