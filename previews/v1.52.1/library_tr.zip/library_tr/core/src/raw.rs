#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Derleyici yerleşik türlerinin düzeni için yapı tanımları içerir.
//!
//! Ham temsilleri doğrudan manipüle etmek için güvenli olmayan koddaki dönüşümlerin hedefi olarak kullanılabilirler.
//!
//!
//! Tanımları her zaman `rustc_middle::ty::layout` te tanımlanan ABI ile eşleşmelidir.
//!

/// `&dyn SomeTrait` gibi bir trait nesnesinin temsili.
///
/// Bu yapı, `&dyn SomeTrait` ve `Box<dyn AnotherTrait>` gibi tiplerle aynı düzene sahiptir.
///
/// `TraitObject` düzenlerle eşleşeceği garantilidir, ancak bu trait nesnelerinin türü değildir (örneğin, alanlara bir `&dyn SomeTrait` te doğrudan erişilemez) veya bu düzeni kontrol etmez (tanımın değiştirilmesi bir `&dyn SomeTrait` in düzenini değiştirmez).
///
/// Yalnızca düşük düzeyli ayrıntıları işlemesi gereken güvenli olmayan kod tarafından kullanılmak üzere tasarlanmıştır.
///
/// Genel olarak tüm trait nesnelerine atıfta bulunmanın bir yolu yoktur, bu nedenle bu türden değerler yaratmanın tek yolu [`std::mem::transmute`][transmute] gibi işlevlerdir.
/// Benzer şekilde, bir `TraitObject` değerinden gerçek bir trait nesnesi oluşturmanın tek yolu `transmute` tir.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Bir trait nesnesini eşleşmeyen türlerle sentezlemek (vtable'ın veri işaretçisinin işaret ettiği değerin türüne karşılık gelmediği bir durum), büyük olasılıkla tanımlanmamış davranışlara yol açar.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // bir örnek trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // derleyicinin bir trait nesnesi yapmasına izin verin
/// let object: &dyn Foo = &value;
///
/// // ham temsile bak
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // veri işaretçisi `value` in adresidir
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object` in `i32` vtable'ını kullanmaya dikkat ederek, farklı bir `i32` i gösteren yeni bir nesne oluşturun
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // doğrudan `other_value` ten bir trait nesnesi oluşturmuşuz gibi çalışmalıdır
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}