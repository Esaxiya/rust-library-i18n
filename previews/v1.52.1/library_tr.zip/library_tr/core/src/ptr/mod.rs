//! Hafızayı ham işaretçiler aracılığıyla manuel olarak yönetin.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Bu modüldeki birçok işlev, ham işaretçileri bağımsız değişken olarak alır ve bunlardan okur veya bunlara yazar.Bunun güvenli olması için bu işaretçiler *geçerli* olmalıdır.
//! Bir göstericinin geçerli olup olmadığı, kullanıldığı işleme (okuma veya yazma) ve erişilen belleğin boyutuna (yani, read/written kaç bayt olduğu) bağlıdır.
//! Çoğu işlev, yalnızca tek bir değere erişmek için `*mut T` ve `* const T` i kullanır, bu durumda dokümantasyon boyutu atlar ve dolaylı olarak `size_of::<T>()` bayt olduğunu varsayar.
//!
//! Geçerlilik için kesin kurallar henüz belirlenmemiştir.Bu noktada sağlanan garantiler çok azdır:
//!
//! * Bir [null] işaretçisi, [size zero][zst] erişimleri için bile *hiçbir zaman* geçerli değildir.
//! * Bir göstericinin geçerli olması için, göstericinin *başvurulabilir* olması gerekir, ancak her zaman yeterli değildir: göstericide başlayan belirli boyuttaki bellek aralığının tümü, tahsis edilen tek bir nesnenin sınırları içinde olmalıdır.
//!
//! Rust'de her (stack-allocated) değişkeninin ayrı bir ayrılmış nesne olarak kabul edildiğini unutmayın.
//! * [size zero][zst] işlemleri için bile, işaretçi serbest bırakılmış belleği göstermemelidir, yani serbest bırakma, işaretçileri sıfır boyutlu işlemler için bile geçersiz kılar.
//! Bununla birlikte, herhangi bir sıfır olmayan tamsayı *değişmez* değerini bir işaretçiye çevirmek, bu adreste bir miktar bellek bulunsa ve serbest bırakılsa bile, sıfır boyutlu erişimler için geçerlidir.
//! Bu, kendi ayırıcınızı yazmaya karşılık gelir: sıfır boyutlu nesneleri tahsis etmek çok zor değildir.
//! Sıfır boyutlu erişimler için geçerli olan bir işaretçi elde etmenin kurallı yolu [`NonNull::dangling`] tir.
//! * Bu modüldeki işlevler tarafından gerçekleştirilen tüm erişimler, iş parçacıkları arasında senkronizasyon için kullanılan [atomic operations] anlamında *atomik değildir*.
//! Bu, her iki erişim de yalnızca bellekten okunmadığı sürece, farklı evrelerden aynı konuma iki eşzamanlı erişim gerçekleştirmenin tanımsız bir davranış olduğu anlamına gelir.
//! Bunun açıkça [`read_volatile`] ve [`write_volatile`] i içerdiğine dikkat edin: Uçucu erişimler iş parçacıkları arası senkronizasyon için kullanılamaz.
//! * Bir işaretçiye bir başvuru atamanın sonucu, temeldeki nesne canlı olduğu ve aynı belleğe erişmek için hiçbir başvuru (yalnızca ham işaretçiler) kullanılmadığı sürece geçerlidir.
//!
//! İşaretçi aritmetiği için [`offset`] in dikkatli kullanımıyla birlikte bu aksiyomlar, güvenli olmayan kodda birçok yararlı şeyi doğru bir şekilde uygulamak için yeterlidir.
//! [aliasing] kuralları belirlendiği için, sonunda daha güçlü garantiler sağlanacaktır.
//! Daha fazla bilgi için, [undefined behavior][ub] e ayrılmış referans bölümünün yanı sıra [book] e bakın.
//!
//! ## Alignment
//!
//! Yukarıda tanımlandığı gibi geçerli ham işaretçilerin doğru şekilde hizalanması gerekmez (burada "proper" hizalaması pointee tipiyle tanımlanır, yani `*const T`, `mem::align_of::<T>()` ile hizalanmalıdır).
//! Bununla birlikte, çoğu işlev, argümanlarının uygun şekilde hizalanmasını gerektirir ve bu gereksinimi belgelerinde açıkça belirtecektir.
//! Bunun dikkate değer istisnaları [`read_unaligned`] ve [`write_unaligned`] tir.
//!
//! Bir işlev uygun hizalama gerektirdiğinde, erişim boyutu 0 olsa bile, yani belleğe gerçekten dokunulmasa bile bunu yapar.Bu gibi durumlarda [`NonNull::dangling`] kullanmayı düşünün.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// İşaret edilen değerin yıkıcısını (varsa) yürütür.
///
/// Bu, anlamsal olarak [`ptr::read`] i çağırmaya ve sonucu atmaya eşdeğerdir, ancak aşağıdaki avantajları vardır:
///
/// * trait nesneleri gibi boyutlandırılmamış türleri bırakmak için `drop_in_place` i kullanmak *gereklidir* çünkü bunlar yığına okunamaz ve normal olarak bırakılamaz.
///
/// * Derleyicinin kopyayı atlamak için sağlam olduğunu kanıtlaması gerekmediğinden, bunu manuel olarak tahsis edilmiş belleği düşürürken (örneğin `Box`/`Rc`/`Vec` uygulamalarında) [`ptr::read`] üzerinden yapmak optimize ediciye daha dostça davranır.
///
///
/// * `T`, `repr(packed)` olmadığında [pinned] verilerini bırakmak için kullanılabilir (sabitlenmiş veriler, bırakılmadan önce taşınmamalıdır).
///
/// Hizalanmamış değerler yerine bırakılamaz, önce [`ptr::read_unaligned`] kullanılarak hizalanmış bir konuma kopyalanmaları gerekir.Paketlenmiş yapılar için bu hareket derleyici tarafından otomatik olarak yapılır.
/// Bu, paketlenmiş yapı alanlarının yerinde bırakılmadığı anlamına gelir.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `to_drop` hem okuma hem de yazma için [valid] olmalıdır.
///
/// * `to_drop` uygun şekilde hizalanmalıdır.
///
/// * `to_drop` in işaret ettiği değer, bırakma için geçerli olmalıdır, bu, ek değişmezleri desteklemesi gerektiği anlamına gelebilir, bu, türe bağlıdır.
///
/// Ek olarak, `T` [`Copy`] değilse, `drop_in_place` çağrıldıktan sonra işaret edilen değerin kullanılması tanımsız davranışa neden olabilir.Değerin tekrar düşmesine neden olacağı için `*to_drop = foo` in bir kullanım olarak sayıldığını unutmayın.
/// [`write()`] düşmesine neden olmadan verilerin üzerine yazmak için kullanılabilir.
///
/// `T` `0` boyutuna sahip olsa bile, işaretçinin NULL olmaması ve doğru şekilde hizalanmış olması gerektiğini unutmayın.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Son öğeyi bir vector'den manuel olarak kaldırın:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // `v` teki son öğeye ham bir işaretçi alın.
///     let ptr = &mut v[1] as *mut _;
///     // Son öğenin düşmesini önlemek için `v` i kısaltın.
///     // `drop_in_place`, panics'nin altındaysa sorunları önlemek için önce bunu yapıyoruz.
///     v.set_len(1);
///     // `drop_in_place` çağrısı olmadan, son öğe asla düşürülemez ve yönettiği bellek sızdırılır.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Son öğenin düştüğünden emin olun.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Derleyicinin bu kopyayı paketlenmiş yapıları bırakırken otomatik olarak gerçekleştirdiğine dikkat edin, yani `drop_in_place` i manuel olarak aramadıkça genellikle bu tür sorunlar için endişelenmenize gerek yoktur.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Buradaki kod önemli değildir, bunun yerine derleyici tarafından gerçek damla yapıştırıcısı kullanılmaktadır.
    //

    // GÜVENLİK: yukarıdaki yoruma bakın
    unsafe { drop_in_place(to_drop) }
}

/// Boş bir ham işaretçi oluşturur.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Boş değiştirilebilir bir ham işaretçi oluşturur.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// `T: Clone` bağını önlemek için manuel uygulama gereklidir.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// `T: Copy` bağını önlemek için manuel uygulama gereklidir.
impl<T> Copy for FatPtr<T> {}

/// İşaretçiden ve uzunluktan ham bir dilim oluşturur.
///
/// `len` argümanı bayt sayısı değil **öğe sayısıdır**.
///
/// Bu işlev güvenlidir, ancak gerçekte dönüş değerini kullanmak güvensizdir.
/// Dilim güvenlik gereksinimleri için [`slice::from_raw_parts`] belgelerine bakın.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // ilk öğeye bir işaretçi ile başlarken bir dilim işaretçisi oluştur
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // GÜVENLİK: `Repr` birleşiminden değere erişmek güvenlidir çünkü * const [T]
        //
        // ve FatPtr aynı bellek düzenlerine sahiptir.Yalnızca std bu garantiyi verebilir.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Ham, değişmez bir dilim yerine ham, değiştirilebilir bir dilim döndürülmesi dışında, [`slice_from_raw_parts`] ile aynı işlevselliği gerçekleştirir.
///
///
/// Daha fazla ayrıntı için [`slice_from_raw_parts`] belgelerine bakın.
///
/// Bu işlev güvenlidir, ancak gerçekte dönüş değerini kullanmak güvensizdir.
/// Dilim güvenlik gereksinimleri için [`slice::from_raw_parts_mut`] belgelerine bakın.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // dilimdeki bir dizine bir değer atayın
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // GÜVENLİK: `Repr` birleşiminden değere erişmek güvenlidir çünkü * mut [T]
        // ve FatPtr aynı bellek düzenlerine sahiptir
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Her ikisini de başlatmadan aynı türdeki iki değiştirilebilir konumdaki değerleri değiştirir.
///
/// Ancak aşağıdaki iki istisna için bu işlev anlamsal olarak [`mem::swap`] e eşdeğerdir:
///
///
/// * Referanslar yerine ham işaretçiler üzerinde çalışır.
/// Referanslar mevcut olduğunda [`mem::swap`] tercih edilmelidir.
///
/// * İki işaretli değer örtüşebilir.
/// Değerler çakışırsa, `x` ten gelen belleğin örtüşen bölgesi kullanılacaktır.
/// Bu, aşağıdaki ikinci örnekte gösterilmiştir.
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * Hem okuma hem de yazma için hem `x` hem de `y` [valid] olmalıdır.
///
/// * Hem `x` hem de `y` düzgün şekilde hizalanmalıdır.
///
/// `T`, `0` boyutuna sahip olsa bile, işaretçilerin BOŞ olmamalı ve düzgün şekilde hizalanmış olması gerektiğini unutmayın.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Örtüşmeyen iki bölgeyi değiştirme:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // bu `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // bu `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Örtüşen iki bölgeyi değiştirmek:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // bu `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // bu `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Dilimin `1..3` endeksleri, `x` ve `y` arasında örtüşüyor.
///     // Onlar için makul sonuçlar `[2, 3]` olacaktır, böylece `0..3` endeksleri `[1, 2, 3]` dir (`swap` ten önceki `y` ile eşleşir);veya `[0, 1]` olmaları için `1..4` indisleri `[0, 1, 2]` olur (`swap` ten önceki `x` ile eşleşir).
/////
///     // Bu uygulama, ikinci seçimi yapmak için tanımlanmıştır.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Kendimize çalışmak için biraz boş alan verin.
    // Düşme konusunda endişelenmemize gerek yok: `MaybeUninit` düştüğünde hiçbir şey yapmıyor.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Değiştirmeyi gerçekleştirin GÜVENLİK: Arayan kişi, `x` ve `y` in yazma işlemleri için geçerli olduğunu ve uygun şekilde hizalandığını garanti etmelidir.
    // `tmp` `x` veya `y` üst üste gelemez çünkü `tmp` yığın üzerinde ayrı bir tahsis edilmiş nesne olarak tahsis edilmiştir.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` ve `y` çakışabilir
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// `x` ve `y` ten başlayan iki bellek bölgesi arasında `count * size_of::<T>()` baytları değiştirir.
/// İki bölge çakışmamalıdır *.
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * Hem `x` hem de `y`, hem okuma hem de yazma için [valid] olmalıdır *
///   boyutu: :<T>() `bayt.
///
/// * Hem `x` hem de `y` düzgün şekilde hizalanmalıdır.
///
/// * `x` ile başlayan bellek bölgesi "count" boyutuyla *
///   boyutu: :<T>() `bayt, aynı boyutta `y` te başlayan bellek bölgesi ile *örtüşmemelidir*.
///
/// Etkili bir şekilde kopyalanan boyut (`count * size_of: :<T>()`) `0`, işaretçiler NULL olmamalı ve doğru şekilde hizalanmalıdır.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // GÜVENLİK: Arayan kişi, `x` ve `y` in
    // yazmalar için geçerlidir ve uygun şekilde hizalanmış.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Aşağıdaki blok optimizasyonundan daha küçük türler için, kod oluşturucunun kötüye gitmesini önlemek için doğrudan değiştirin.
    //
    if mem::size_of::<T>() < 32 {
        // GÜVENLİK: Arayan, `x` ve `y` in geçerli olduğunu garanti etmelidir
        // yazmalar için, düzgün hizalanmış ve çakışmayan.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // GÜVENLİK: Arayan kişi `swap_nonoverlapping` için güvenlik sözleşmesine uymalıdır.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Buradaki yaklaşım, x&y'yi verimli bir şekilde değiştirmek için simd'yi kullanmaktır.
    // Testler, bir seferde 32 bayt veya 64 bayt değiştirmenin Intel Haswell E işlemciler için en verimli olduğunu ortaya koyuyor.
    // Bu yapıyı doğrudan kullanmasak bile, bir yapıya #[repr(simd)] verirsek, LLVM daha iyi optimize edebilir.
    //
    //
    // FIXME repr(simd) emscripten ve redox'ta bozuk
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // X&y üzerinden döngü yapın, bunları bir seferde `Block` kopyalayın Optimizer, çoğu tür için döngüyü tamamen açmalıdır NB
    // `range` impl `mem::swap` i yinelemeli olarak çağırdığı için for döngüsü kullanamayız
    //
    let mut i = 0;
    while i + block_size <= len {
        // Çalışma alanı olarak bazı başlatılmamış bellek oluşturun `t` i burada beyan etmek, bu döngü kullanılmadığında yığının hizalanmasını önler
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // GÜVENLİK: `i < len` olarak ve arayan kişi olarak `x` ve `y` in geçerli olduğunu garanti etmelidir
        // `len` baytları için, `x + i` ve `y + i`, `add` için güvenlik sözleşmesini karşılayan geçerli adresler olmalıdır.
        //
        // Ayrıca, arayan kişi, `copy_nonoverlapping` için güvenlik sözleşmesini yerine getiren `x` ve `y` in yazmalar için geçerli, uygun şekilde hizalanmış ve çakışmayan olduğunu garanti etmelidir.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // T'yi geçici bir arabellek olarak kullanarak x&y bayt bloğunu değiştirin Bu, mümkün olduğunda verimli SIMD işlemlerine optimize edilmelidir.
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Kalan baytları değiştirin
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // GÜVENLİK: önceki güvenlik açıklamasına bakın.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// `src` i sivri `dst` e hareket ettirerek önceki `dst` değerini döndürür.
///
/// Her iki değer de düşürülmez.
///
/// Bu işlev, referanslar yerine ham işaretçiler üzerinde çalışması dışında anlamsal olarak [`mem::replace`] e eşdeğerdir.
/// Referanslar mevcut olduğunda [`mem::replace`] tercih edilmelidir.
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `dst` hem okuma hem de yazma için [valid] olmalıdır.
///
/// * `dst` uygun şekilde hizalanmalıdır.
///
/// * `dst` `T` türünde uygun şekilde başlatılmış bir değere işaret etmelidir.
///
/// `T` `0` boyutuna sahip olsa bile, işaretçinin NULL olmaması ve doğru şekilde hizalanmış olması gerektiğini unutmayın.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` güvenli olmayan blok gerektirmeden aynı etkiye sahip olacaktır.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // GÜVENLİK: Arayan kişi, `dst` in geçerli olduğunu garanti etmelidir.
    // değiştirilebilir bir referansa dönüştürülür (yazmalar için geçerli, hizalanmış, başlatılmış) ve `dst` in ayrı bir tahsis edilmiş nesneyi işaret etmesi gerektiğinden `src` ile çakışamaz.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // örtüşemez
    }
    src
}

/// Değeri `src` ten hareket ettirmeden okur.Bu, `src` teki belleği değiştirmeden bırakır.
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `src` okumalar için [valid] olmalıdır.
///
/// * `src` uygun şekilde hizalanmalıdır.Durum bu değilse [`read_unaligned`] kullanın.
///
/// * `src` `T` türünde uygun şekilde başlatılmış bir değere işaret etmelidir.
///
/// `T` `0` boyutuna sahip olsa bile, işaretçinin NULL olmaması ve doğru şekilde hizalanmış olması gerektiğini unutmayın.
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] i manuel olarak uygulayın:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // `tmp` te `a` te değerin bit düzeyinde bir kopyasını oluşturun.
///         let tmp = ptr::read(a);
///
///         // Bu noktada çıkış (ya açıkça geri dönerek ya da panics olan bir işlevi çağırarak) `tmp` teki değerin `a` tarafından referans alınırken düşürülmesine neden olur.
///         // `T`, `Copy` değilse bu, tanımlanmamış davranışı tetikleyebilir.
/////
/////
///
///         // `a` te `b` te değerin bit düzeyinde bir kopyasını oluşturun.
///         // Bu güvenlidir çünkü değişebilir referanslar diğer adlar olamaz.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Yukarıda olduğu gibi, buradan çıkmak tanımsız davranışı tetikleyebilir çünkü aynı değere `a` ve `b` tarafından başvurulmaktadır.
/////
///
///         // `tmp` i `b` e taşıyın.
///         ptr::write(b, tmp);
///
///         // `tmp` taşınmıştır (`write` ikinci argümanının sahipliğini alır), bu nedenle burada hiçbir şey dolaylı olarak bırakılmaz.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## İade Edilen Değerin Mülkiyeti
///
/// `read` `T` in [`Copy`] olup olmadığına bakılmaksızın, `T` in bitsel bir kopyasını oluşturur.
/// `T`, [`Copy`] değilse, hem döndürülen değeri hem de `*src` teki değeri kullanmak bellek güvenliğini ihlal edebilir.
/// `*src` e atamanın bir kullanım olarak sayıldığını, çünkü değeri `* src` te düşürmeye çalışacağını unutmayın.
///
/// [`write()`] düşmesine neden olmadan verilerin üzerine yazmak için kullanılabilir.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` şimdi `s` ile aynı temel belleğe işaret ediyor.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // `s2` e atama, orijinal değerinin düşmesine neden olur.
///     // Bu noktanın ötesinde, temeldeki bellek serbest bırakıldığı için `s` artık kullanılmamalıdır.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // `s` e atama, eski değerin tekrar düşmesine neden olur ve bu da tanımsız davranışa neden olur.
/////
///     // s= String::from("bar");//HATA
///
///     // `ptr::write` düşürmeden bir değerin üzerine yazmak için kullanılabilir.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // GÜVENLİK: Arayan kişi, `src` in okumalar için geçerli olduğunu garanti etmelidir.
    // `src` `tmp` ile örtüşemez çünkü `tmp` yığın üzerinde ayrı bir tahsis edilmiş nesne olarak tahsis edilmiştir.
    //
    //
    // Ayrıca, `tmp` e az önce geçerli bir değer yazdığımız için, uygun şekilde başlatılması garanti edilir.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Değeri `src` ten hareket ettirmeden okur.Bu, `src` teki belleği değiştirmeden bırakır.
///
/// [`read`] in aksine, `read_unaligned` hizalanmamış işaretçilerle çalışır.
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `src` okumalar için [valid] olmalıdır.
///
/// * `src` `T` türünde uygun şekilde başlatılmış bir değere işaret etmelidir.
///
/// [`read`] gibi, `read_unaligned`, `T` in [`Copy`] olup olmadığına bakılmaksızın, `T` in bitsel bir kopyasını oluşturur.
/// `T`, [`Copy`] değilse, hem döndürülen değeri hem de `*src` teki değeri kullanarak [violate memory safety][read-ownership] olabilir.
///
/// `T`, `0` boyutuna sahip olsa bile, işaretçinin NULL olmaması gerektiğini unutmayın.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## `packed` yapılarında
///
/// Şu anda, paketlenmiş bir yapının hizalanmamış alanlarına ham işaretçiler oluşturmak imkansızdır.
///
/// `&packed.unaligned as *const FieldType` gibi bir ifade ile bir `unaligned` yapı alanına ham bir işaretçi oluşturmaya çalışmak, bunu bir ham işaretçiye dönüştürmeden önce bir ara hizalanmamış referans oluşturur.
///
/// Derleyici her zaman referansların düzgün bir şekilde hizalanmasını beklediğinden, bu referansın geçici ve hemen atılması önemsizdir.
/// Sonuç olarak, `&packed.unaligned as *const FieldType` in kullanılması programınızda anında* tanımsız davranışa * neden olur.
///
/// Neyin yapılmaması gerektiğine ve bunun `read_unaligned` ile nasıl bağlantılı olduğuna dair bir örnek:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Burada hizalı olmayan 32 bitlik bir tamsayının adresini almaya çalışıyoruz.
///     let unaligned =
///         // Burada, referansın kullanılıp kullanılmadığına bakılmaksızın tanımlanmamış davranışla sonuçlanan geçici bir hizalanmamış referans oluşturulur.
/////
///         &packed.unaligned
///         // İşlenmemiş bir işaretçiye çevirmek yardımcı olmaz;hata zaten oldu.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Bununla birlikte, hizalanmamış alanlara doğrudan örneğin `packed.unaligned` ile erişmek güvenlidir.
///
///
///
///
///
///
// FIXME: Belgeleri, RFC #2582 ve arkadaşlarınızın sonucuna göre güncelleyin.
/// # Examples
///
/// Bir bayt arabelleğinden bir kullanım değeri okuyun:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // GÜVENLİK: Arayan kişi, `src` in okumalar için geçerli olduğunu garanti etmelidir.
    // `src` `tmp` ile örtüşemez çünkü `tmp` yığın üzerinde ayrı bir tahsis edilmiş nesne olarak tahsis edilmiştir.
    //
    //
    // Ayrıca, `tmp` e az önce geçerli bir değer yazdığımız için, uygun şekilde başlatılması garanti edilir.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Eski değeri okumadan veya düşürmeden verilen değerle bir bellek konumunun üzerine yazar.
///
/// `write` `dst` içeriğini düşürmez.
/// Bu güvenlidir, ancak tahsisleri veya kaynakları sızdırabilir, bu nedenle, düşürülmesi gereken bir nesnenin üzerine yazılmamasına dikkat edilmelidir.
///
///
/// Ek olarak, `src` i düşürmez.Anlamsal olarak, `src`, `dst` tarafından gösterilen konuma taşınır.
///
/// Bu, başlatılmamış belleği başlatmak veya daha önce [`read`] ten gelen belleğin üzerine yazmak için uygundur.
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `dst` yazmalar için [valid] olmalıdır.
///
/// * `dst` uygun şekilde hizalanmalıdır.Durum bu değilse [`write_unaligned`] kullanın.
///
/// `T` `0` boyutuna sahip olsa bile, işaretçinin NULL olmaması ve doğru şekilde hizalanmış olması gerektiğini unutmayın.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] i manuel olarak uygulayın:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // `tmp` te `a` te değerin bit düzeyinde bir kopyasını oluşturun.
///         let tmp = ptr::read(a);
///
///         // Bu noktada çıkış (ya açıkça geri dönerek ya da panics olan bir işlevi çağırarak) `tmp` teki değerin `a` tarafından referans alınırken düşürülmesine neden olur.
///         // `T`, `Copy` değilse bu, tanımlanmamış davranışı tetikleyebilir.
/////
/////
///
///         // `a` te `b` te değerin bit düzeyinde bir kopyasını oluşturun.
///         // Bu güvenlidir çünkü değişebilir referanslar diğer adlar olamaz.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Yukarıda olduğu gibi, buradan çıkmak tanımsız davranışı tetikleyebilir çünkü aynı değere `a` ve `b` tarafından başvurulmaktadır.
/////
///
///         // `tmp` i `b` e taşıyın.
///         ptr::write(b, tmp);
///
///         // `tmp` taşınmıştır (`write` ikinci argümanının sahipliğini alır), bu nedenle burada hiçbir şey dolaylı olarak bırakılmaz.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // `intrinsics::copy_nonoverlapping` bir sarmalayıcı işlev olduğundan, üretilen kodda işlev çağrılarını önlemek için doğrudan içselleri çağırıyoruz.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // GÜVENLİK: Arayan, `dst` in yazma işlemleri için geçerli olduğunu garanti etmelidir.
    // `dst` `src` üst üste gelemez çünkü arayan kişi `dst` e değiştirilebilir erişime sahipken, `src` bu işleve sahipken.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Eski değeri okumadan veya düşürmeden verilen değerle bir bellek konumunun üzerine yazar.
///
/// [`write()`] in aksine, işaretçi hizasız olabilir.
///
/// `write_unaligned` `dst` içeriğini düşürmez.Bu güvenlidir, ancak tahsisleri veya kaynakları sızdırabilir, bu nedenle, düşürülmesi gereken bir nesnenin üzerine yazılmamasına dikkat edilmelidir.
///
/// Ek olarak, `src` i düşürmez.Anlamsal olarak, `src`, `dst` tarafından gösterilen konuma taşınır.
///
/// Bu, başlatılmamış belleği başlatmak veya daha önce [`read_unaligned`] ile okunan belleğin üzerine yazmak için uygundur.
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `dst` yazmalar için [valid] olmalıdır.
///
/// `T`, `0` boyutuna sahip olsa bile, işaretçinin NULL olmaması gerektiğini unutmayın.
///
/// [valid]: self#safety
///
/// ## `packed` yapılarında
///
/// Şu anda, paketlenmiş bir yapının hizalanmamış alanlarına ham işaretçiler oluşturmak imkansızdır.
///
/// `&packed.unaligned as *const FieldType` gibi bir ifade ile bir `unaligned` yapı alanına ham bir işaretçi oluşturmaya çalışmak, bunu bir ham işaretçiye dönüştürmeden önce bir ara hizalanmamış referans oluşturur.
///
/// Derleyici her zaman referansların düzgün bir şekilde hizalanmasını beklediğinden, bu referansın geçici ve hemen atılması önemsizdir.
/// Sonuç olarak, `&packed.unaligned as *const FieldType` in kullanılması programınızda anında* tanımsız davranışa * neden olur.
///
/// Neyin yapılmaması gerektiğine ve bunun `write_unaligned` ile nasıl bağlantılı olduğuna dair bir örnek:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Burada hizalı olmayan 32 bitlik bir tamsayının adresini almaya çalışıyoruz.
///     let unaligned =
///         // Burada, referansın kullanılıp kullanılmadığına bakılmaksızın tanımlanmamış davranışla sonuçlanan geçici bir hizalanmamış referans oluşturulur.
/////
///         &mut packed.unaligned
///         // İşlenmemiş bir işaretçiye çevirmek yardımcı olmaz;hata zaten oldu.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Bununla birlikte, hizalanmamış alanlara doğrudan örneğin `packed.unaligned` ile erişmek güvenlidir.
///
///
///
///
///
///
///
///
///
// FIXME: Belgeleri, RFC #2582 ve arkadaşlarınızın sonucuna göre güncelleyin.
/// # Examples
///
/// Bir bayt arabelleğine bir kullanım değeri yazın:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // GÜVENLİK: Arayan, `dst` in yazma işlemleri için geçerli olduğunu garanti etmelidir.
    // `dst` `src` üst üste gelemez çünkü arayan kişi `dst` e değiştirilebilir erişime sahipken, `src` bu işleve sahipken.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Oluşturulan kodda işlev çağrılarını önlemek için doğrudan içsel çağrıyı yapıyoruz.
        intrinsics::forget(src);
    }
}

/// `src` ten gelen değeri hareket ettirmeden geçici bir okuma gerçekleştirir.Bu, `src` teki belleği değiştirmeden bırakır.
///
/// Uçucu işlemlerin I/O belleğine göre hareket etmesi amaçlanmıştır ve derleyici tarafından diğer uçucu işlemlerde iptal edilmemesi veya yeniden sıralanmaması garanti edilmektedir.
///
/// # Notes
///
/// Rust şu anda titiz ve resmi olarak tanımlanmış bir bellek modeline sahip değildir, bu nedenle "volatile" in burada ne anlama geldiğinin kesin anlambilimi zamanla değişebilir.
/// Bununla birlikte, anlambilim neredeyse her zaman [C11's definition of volatile][c11] e oldukça benzer olacaktır.
///
/// Derleyici, geçici bellek işlemlerinin göreceli sırasını veya sayısını değiştirmemelidir.
/// Ancak, sıfır boyutlu türlerdeki geçici bellek işlemleri (örneğin, `read_volatile` e sıfır boyutlu bir tür geçirilirse) noops ve göz ardı edilebilir.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `src` okumalar için [valid] olmalıdır.
///
/// * `src` uygun şekilde hizalanmalıdır.
///
/// * `src` `T` türünde uygun şekilde başlatılmış bir değere işaret etmelidir.
///
/// [`read`] gibi, `read_volatile`, `T` in [`Copy`] olup olmadığına bakılmaksızın, `T` in bitsel bir kopyasını oluşturur.
/// `T`, [`Copy`] değilse, hem döndürülen değeri hem de `*src` teki değeri kullanarak [violate memory safety][read-ownership] olabilir.
/// Ancak, geçici bellekte [`Copy`] olmayan türlerin saklanması neredeyse kesinlikle yanlıştır.
///
/// `T` `0` boyutuna sahip olsa bile, işaretçinin NULL olmaması ve doğru şekilde hizalanmış olması gerektiğini unutmayın.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Tıpkı C'de olduğu gibi, bir işlemin uçucu olup olmadığının, birden çok iş parçacığından eşzamanlı erişimi içeren sorularla hiçbir ilgisi yoktur.Uçucu erişimler, bu bakımdan tam olarak atomik olmayan erişimler gibi davranır.
///
/// Özellikle, bir `read_volatile` ile aynı konuma herhangi bir yazma işlemi arasındaki bir yarış, tanımlanmamış bir davranıştır.
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Kod oluşturucu etkisini daha küçük tutmak için panik yapmamak.
        abort();
    }
    // GÜVENLİK: Arayan kişi `volatile_load` için güvenlik sözleşmesine uymalıdır.
    unsafe { intrinsics::volatile_load(src) }
}

/// Eski değeri okumadan veya düşürmeden verilen değerle bir bellek konumuna geçici bir yazma gerçekleştirir.
///
/// Uçucu işlemlerin I/O belleğine göre hareket etmesi amaçlanmıştır ve derleyici tarafından diğer uçucu işlemlerde iptal edilmemesi veya yeniden sıralanmaması garanti edilmektedir.
///
/// `write_volatile` `dst` içeriğini düşürmez.Bu güvenlidir, ancak tahsisleri veya kaynakları sızdırabilir, bu nedenle, düşürülmesi gereken bir nesnenin üzerine yazılmamasına dikkat edilmelidir.
///
/// Ek olarak, `src` i düşürmez.Anlamsal olarak, `src`, `dst` tarafından gösterilen konuma taşınır.
///
/// # Notes
///
/// Rust şu anda titiz ve resmi olarak tanımlanmış bir bellek modeline sahip değildir, bu nedenle "volatile" in burada ne anlama geldiğinin kesin anlambilimi zamanla değişebilir.
/// Bununla birlikte, anlambilim neredeyse her zaman [C11's definition of volatile][c11] e oldukça benzer olacaktır.
///
/// Derleyici, geçici bellek işlemlerinin göreceli sırasını veya sayısını değiştirmemelidir.
/// Ancak, sıfır boyutlu türlerdeki geçici bellek işlemleri (örneğin, `write_volatile` e sıfır boyutlu bir tür geçirilirse) noops ve göz ardı edilebilir.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Aşağıdaki koşullardan herhangi biri ihlal edilirse davranış tanımsızdır:
///
/// * `dst` yazmalar için [valid] olmalıdır.
///
/// * `dst` uygun şekilde hizalanmalıdır.
///
/// `T` `0` boyutuna sahip olsa bile, işaretçinin NULL olmaması ve doğru şekilde hizalanmış olması gerektiğini unutmayın.
///
/// [valid]: self#safety
///
/// Tıpkı C'de olduğu gibi, bir işlemin uçucu olup olmadığının, birden çok iş parçacığından eşzamanlı erişimi içeren sorularla hiçbir ilgisi yoktur.Uçucu erişimler, bu bakımdan tam olarak atomik olmayan erişimler gibi davranır.
///
/// Özellikle, bir `write_volatile` ile aynı konumdaki diğer herhangi bir işlem (okuma veya yazma) arasındaki bir yarış, tanımlanmamış bir davranıştır.
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Kod oluşturucu etkisini daha küçük tutmak için panik yapmamak.
        abort();
    }
    // GÜVENLİK: Arayan kişi `volatile_store` için güvenlik sözleşmesine uymalıdır.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// İşaretçi `p` i hizalayın.
///
/// `p` işaretçisinin `a` ile hizalanması için `p` işaretçisine uygulanması gereken ofseti (`stride` adımın öğeleri cinsinden) hesaplayın.
///
/// Note: Bu uygulama panic için değil dikkatlice uyarlanmıştır.Bunun için panic için UB'dir.
/// Burada yapılabilecek tek gerçek değişiklik, `INV_TABLE_MOD_16` ve ilgili sabitlerin değişmesidir.
///
/// İkinin gücü olmayan `a` ile içsel çağırmayı mümkün kılmaya karar verirsek, bunu bu değişikliğe uyacak şekilde uyarlamaya çalışmaktansa saf bir uygulamaya geçmek muhtemelen daha akıllıca olacaktır.
///
///
/// Sorularınız için@nagisa adresine gidin.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Bu içsel bilgilerin doğrudan kullanımı, kod oluşturucuyu opt-level düzeyinde önemli ölçüde geliştirir <=
    // 1, burada bu işlemlerin yöntem sürümleri satır içi değildir.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// `x` modulo `m` in çarpımsal modüler tersini hesaplayın.
    ///
    /// Bu uygulama `align_offset` için uyarlanmıştır ve aşağıdaki ön koşullara sahiptir:
    ///
    /// * `m` ikinin gücüdür;
    /// * `x < m`; (`x ≥ m` ise, bunun yerine `x % m` i geçirin)
    ///
    /// Bu işlevin uygulanması panic olmayacaktır.Hiç.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Çarpımsal modüler ters tablo modülo 2⁴=16.
        ///
        /// Bu tablonun, tersinin olmadığı yerlerde değerler içermediğine dikkat edin (yani, `0⁻¹ mod 16`, `2⁻¹ mod 16`, vb. İçin)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// `INV_TABLE_MOD_16` in tasarlandığı Modulo.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // GÜVENLİK: `m`, ikinin üssü, dolayısıyla sıfır olmaması gerekir.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // "up" i aşağıdaki formülü kullanarak yineliyoruz:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // 2²ⁿ ≥ m'ye kadar.Daha sonra sonucu `mod m` alarak istediğimiz `m` e indirebiliriz.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Burada sarma işlemlerini bilinçli olarak kullandığımıza dikkat edin-orijinal formülde örneğin çıkarma `mod n` kullanılır.
                // Bunun yerine `mod usize::MAX` yapmak tamamen iyidir, çünkü sonunda `mod n` sonucunu alıyoruz.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // GÜVENLİK: `a` ikinin gücüdür, dolayısıyla sıfır değildir.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` durum `-p (mod a)` aracılığıyla daha basit bir şekilde hesaplanabilir, ancak bunu yapmak LLVM'nin `lea` gibi komutları seçme yeteneğini engeller.Bunun yerine hesaplıyoruz
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // Bu, işlemleri yük taşıyıcı etrafında dağıtır, ancak `and` i LLVM'nin bildiği çeşitli optimizasyonları kullanabilmesi için yeterince zorlaştırır.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Zaten hizalanmış.Yaşasın!
        return 0;
    } else if stride == 0 {
        // İşaretçi hizalı değilse ve öğe sıfır boyutluysa, hiçbir zaman hiçbir öğe işaretçiyi hizalamayacaktır.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // GÜVENLİK: a ikinin gücüdür, dolayısıyla sıfır değildir.stride==0 durumu yukarıda ele alınmıştır.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // GÜVENLİK: gcdpow, bir kullanımdaki en fazla bit sayısı olan bir üst sınıra sahiptir.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // GÜVENLİK: gcd her zaman 1'den büyük veya 1'e eşittir.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Bu branch, aşağıdaki doğrusal uyum denklemini çözer:
        //
        // ` p + so = 0 mod a `
        //
        // `p` burada işaretçi değeri, `s`, `T` adım, `o` ofset "T" ve `a`, istenen hizalama.
        //
        // `g = gcd(a, s)` ile ve `p` in de `g` ile bölünebileceğini iddia eden yukarıdaki koşulla, `a' = a/g`, `s' = s/g`, `p' = p/g` i ifade edebiliriz, sonra bu şuna eşdeğer olur:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // İlk terim "the relative alignment of `p` to `a`" dir (`g` e bölünür), ikinci terim "how does incrementing `p` by `s` bytes change the relative alignment of `p`" tir (yine `g` e bölünür).
        //
        // `g` ile bölme, `a` ve `s` eş asal değilse ters iyi biçimlendirmek için gereklidir.
        //
        // Ayrıca, bu çözümün ürettiği sonuç "minimal" değildir, bu nedenle `o mod lcm(s, a)` sonucunu almak gerekir.`lcm(s, a)` i sadece bir `a'` ile değiştirebiliriz.
        //
        //
        //
        //
        //

        // GÜVENLİK: `gcdpow`, `a` teki sondaki 0 bit sayısından daha büyük olmayan bir üst sınıra sahiptir.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // GÜVENLİK: `a2` sıfır değildir.`a` in `gcdpow` ile kaydırılması, ayarlanan bitlerin hiçbirini kaydıramaz
        // `a` te (bunlardan tam olarak bir tane var).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // GÜVENLİK: `gcdpow`, `a` teki sondaki 0 bit sayısından daha büyük olmayan bir üst sınıra sahiptir.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // GÜVENLİK: `gcdpow`, sondaki 0 bit sayısından daha büyük olmayan bir üst sınıra sahiptir.
        // `a`.
        // Ayrıca, `a2 = a >> gcdpow` her zaman kesinlikle `(p % a) >> gcdpow` ten daha büyük olacağı için çıkarma işlemi aşamaz.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // GÜVENLİK: `a2`, yukarıda kanıtlandığı gibi ikinin gücüdür.`s2` kesinlikle `a2` ten daha küçüktür
        // çünkü `(s % a) >> gcdpow` kesinlikle `a >> gcdpow` ten daha küçüktür.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Hiç hizalanamaz.
    usize::MAX
}

/// Eşitlik için ham işaretçileri karşılaştırır.
///
/// Bu, `==` operatörünü kullanmakla aynıdır, ancak daha az geneldir:
/// bağımsız değişkenler, `PartialEq` i uygulayan hiçbir şey değil, `*const T` ham işaretçiler olmalıdır.
///
/// Bu, işaret ettikleri değerleri karşılaştırmak yerine (`PartialEq for &T` uygulamasının yaptığı şeydir) `&T` referanslarını (`*const T` e dolaylı olarak zorlayan) adresleriyle karşılaştırmak için kullanılabilir.
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Dilimler ayrıca uzunluklarına göre de karşılaştırılır (şişman işaretçiler):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits ayrıca uygulamalarıyla da karşılaştırılır:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // İşaretçilerin adresleri eşittir.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Nesnelerin eşit adresleri vardır, ancak `Trait` in farklı uygulamaları vardır.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Referansın bir `*const u8` e dönüştürülmesi adrese göre karşılaştırılır.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Ham bir işaretçiye hash.
///
/// Bu, işaret ettiği değerden ziyade (`Hash for &T` uygulamasının yaptığı şeydir), bir `&T` referansına (`*const T` e dolaylı olarak zorlar) göre hashing uygulamak için kullanılabilir.
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// İşlev işaretçileri için impls
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR için kullanım boyutunda ara yayın gereklidir
                // böylece kaynak işlev göstericisinin adres alanı son işlev göstericisinde korunur.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR için kullanım boyutunda ara yayın gereklidir
                // böylece kaynak işlev göstericisinin adres alanı son işlev göstericisinde korunur.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // 0 parametre ile değişken fonksiyon yok
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Ara referans oluşturmadan bir yere `const` ham işaretçi oluşturun.
///
/// `&`/`&mut` ile bir referans oluşturmaya yalnızca işaretçi düzgün şekilde hizalanmışsa ve başlatılmış verileri işaret ediyorsa izin verilir.
/// Bu gereksinimlerin geçerli olmadığı durumlarda, bunun yerine ham işaretçiler kullanılmalıdır.
/// Ancak, `&expr as *const _` onu ham bir işaretçiye aktarmadan önce bir referans oluşturur ve bu referans diğer tüm referanslarla aynı kurallara tabidir.
///
/// Bu makro, önce bir referans oluşturmadan * ham bir işaretçi oluşturabilir.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` hizalanmamış bir referans oluşturur ve dolayısıyla Tanımsız Davranış olur!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Ara referans oluşturmadan bir yere `mut` ham işaretçi oluşturun.
///
/// `&`/`&mut` ile bir referans oluşturmaya yalnızca işaretçi düzgün şekilde hizalanmışsa ve başlatılmış verileri işaret ediyorsa izin verilir.
/// Bu gereksinimlerin geçerli olmadığı durumlarda, bunun yerine ham işaretçiler kullanılmalıdır.
/// Ancak, `&mut expr as *mut _` onu ham bir işaretçiye aktarmadan önce bir referans oluşturur ve bu referans diğer tüm referanslarla aynı kurallara tabidir.
///
/// Bu makro, önce bir referans oluşturmadan * ham bir işaretçi oluşturabilir.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` hizalanmamış bir referans oluşturur ve dolayısıyla Tanımsız Davranış olur!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` referans oluşturmak yerine alanı kopyalamaya zorlar.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}