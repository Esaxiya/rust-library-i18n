use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ama sıfır olmayan ve kovaryant.
///
/// Bu, genellikle ham işaretçiler kullanarak veri yapıları oluştururken kullanılması doğru olan şeydir, ancak ek özellikleri nedeniyle sonuçta kullanılması daha tehlikelidir.`NonNull<T>` kullanmanız gerektiğinden emin değilseniz, sadece `*mut T` kullanın!
///
/// `*mut T` ten farklı olarak, işaretçi hiçbir zaman başvuruda bulunulmasa bile, işaretçi her zaman boş olmamalıdır.Bu, numaralandırmaların bu yasak değeri bir ayırıcı olarak kullanabilmeleri içindir-`Option<NonNull<T>>`, `* mut T` ile aynı boyuta sahiptir.
/// Bununla birlikte, işaretçi referans alınmazsa yine de sarkabilir.
///
/// `*mut T` in aksine, `NonNull<T>`, `T` e göre ortak değişken olarak seçildi.Bu, kovaryant türleri oluştururken `NonNull<T>` in kullanılmasını mümkün kılar, ancak aslında eşdeğişken olmaması gereken bir türde kullanılırsa sağlamlık riskini ortaya çıkarır.
/// (Teknik olarak sağlamlığın yalnızca güvenli olmayan işlevleri çağırmaktan kaynaklanabilmesine rağmen, `*mut T` için tam tersi bir seçim yapıldı.)
///
/// Kovaryans, `Box`, `Rc`, `Arc`, `Vec` ve `LinkedList` gibi çoğu güvenli soyutlama için doğrudur.Bu durum, Rust'nin normal paylaşımlı XOR değişken kurallarını izleyen genel bir API sağladıkları için böyledir.
///
/// Türünüz güvenli bir şekilde ortak değişken olamazsa, değişmezlik sağlamak için bazı ek alanlar içerdiğinden emin olmalısınız.Genellikle bu alan, `PhantomData<Cell<T>>` veya `PhantomData<&'a mut T>` gibi bir [`PhantomData`] türü olacaktır.
///
/// `NonNull<T>` in `&T` için bir `From` örneğine sahip olduğuna dikkat edin.Ancak bu, mutasyon bir [`UnsafeCell<T>`] içinde gerçekleşmedikçe, paylaşılan bir referans (a'dan türetilen işaretçi) aracılığıyla mutasyonun tanımlanmamış bir davranış olduğu gerçeğini değiştirmez.Aynı şey, paylaşılan bir referanstan değiştirilebilir bir referans oluşturmak için de geçerlidir.
///
/// Bu `From` örneğini `UnsafeCell<T>` olmadan kullanırken, `as_mut` in hiçbir zaman çağrılmamasını ve `as_ptr` in asla mutasyon için kullanılmamasını sağlamak sizin sorumluluğunuzdadır.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` işaretçiler `Send` değildir çünkü referans verdikleri veriler takma ad olabilir.
// NB, bu uygulama gereksizdir, ancak daha iyi hata mesajları sağlamalıdır.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` işaretçiler `Sync` değildir çünkü referans verdikleri veriler takma ad olabilir.
// NB, bu uygulama gereksizdir, ancak daha iyi hata mesajları sağlamalıdır.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Sarkan ancak iyi hizalanmış yeni bir `NonNull` oluşturur.
    ///
    /// Bu, `Vec::new` in yaptığı gibi, tembel olarak tahsis eden türleri başlatmak için kullanışlıdır.
    ///
    /// İşaretçi değerinin potansiyel olarak bir `T` için geçerli bir göstericiyi temsil edebileceğini unutmayın; bu, bunun bir "not yet initialized" gözlemci değeri olarak kullanılmaması gerektiği anlamına gelir.
    /// Tembel olarak tahsis edilen türler, başlatmayı başka yollarla izlemelidir.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // GÜVENLİK: mem::align_of(), daha sonra dönüştürülen sıfır olmayan bir kullanım boyutu döndürür
        // bir * mut T.
        // Bu nedenle, `ptr` boş değildir ve new_unchecked() i çağırma koşullarına uyulur.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Değere paylaşılan bir başvuru döndürür.[`as_ref`] in aksine, bu, değerin başlatılmasını gerektirmez.
    ///
    /// Değişken muadili için [`as_uninit_mut`] e bakın.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken, aşağıdakilerin hepsinin doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi doğru şekilde hizalanmalıdır.
    ///
    /// * [the module documentation] te tanımlanan anlamda "dereferencable" olmalıdır.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği bellek mutasyona uğramamalıdır (`UnsafeCell` in içi hariç).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // GÜVENLİK: Arayan kişi, `self` in tüm gereksinimleri karşıladığını garanti etmelidir.
        // referans için gereklilikler.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Değere benzersiz bir referans döndürür.[`as_mut`] in aksine, bu, değerin başlatılmasını gerektirmez.
    ///
    /// Paylaşılan meslektaş için [`as_uninit_ref`] e bakınız.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken, aşağıdakilerin hepsinin doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi doğru şekilde hizalanmalıdır.
    ///
    /// * [the module documentation] te tanımlanan anlamda "dereferencable" olmalıdır.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği belleğe başka herhangi bir işaretçi aracılığıyla erişilmemeli (okunmamalı veya yazılmamalıdır).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // GÜVENLİK: Arayan kişi, `self` in tüm gereksinimleri karşıladığını garanti etmelidir.
        // referans için gereklilikler.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Yeni bir `NonNull` oluşturur.
    ///
    /// # Safety
    ///
    /// `ptr` boş olmamalıdır.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // GÜVENLİK: Arayan, `ptr` in boş olmadığını garanti etmelidir.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` boş değilse yeni bir `NonNull` oluşturur.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // GÜVENLİK: İşaretçi zaten kontrol edildi ve boş değil
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Ham `*const` işaretçisinin aksine bir `NonNull` işaretçisinin döndürülmesi dışında [`std::ptr::from_raw_parts`] ile aynı işlevi gerçekleştirir.
    ///
    ///
    /// Daha fazla ayrıntı için [`std::ptr::from_raw_parts`] belgelerine bakın.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // GÜVENLİK: `ptr::from::raw_parts_mut` in sonucu boş değil çünkü `data_address`.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Bir (muhtemelen geniş) göstericiyi adres ve meta veri bileşenlerine ayrıştırın.
    ///
    /// İşaretçi daha sonra [`NonNull::from_raw_parts`] ile yeniden yapılandırılabilir.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Temeldeki `*mut` işaretçisini alır.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Değere paylaşılan bir başvuru döndürür.Değer başlatılmamışsa, bunun yerine [`as_uninit_ref`] kullanılmalıdır.
    ///
    /// Değişken muadili için [`as_mut`] e bakın.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken, aşağıdakilerin hepsinin doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi doğru şekilde hizalanmalıdır.
    ///
    /// * [the module documentation] te tanımlanan anlamda "dereferencable" olmalıdır.
    ///
    /// * İşaretçi, başlatılmış bir `T` örneğini göstermelidir.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği bellek mutasyona uğramamalıdır (`UnsafeCell` in içi hariç).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    /// (Başlatma ile ilgili kısım henüz tam olarak kararlaştırılmamıştır, ancak bu olana kadar, tek güvenli yaklaşım bunların gerçekten başlatıldıklarından emin olmaktır.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // GÜVENLİK: Arayan kişi, `self` in tüm gereksinimleri karşıladığını garanti etmelidir.
        // referans için gereklilikler.
        unsafe { &*self.as_ptr() }
    }

    /// Değere benzersiz bir referans döndürür.Değer başlatılmamışsa, bunun yerine [`as_uninit_mut`] kullanılmalıdır.
    ///
    /// Paylaşılan meslektaş için [`as_ref`] e bakınız.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken, aşağıdakilerin hepsinin doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi doğru şekilde hizalanmalıdır.
    ///
    /// * [the module documentation] te tanımlanan anlamda "dereferencable" olmalıdır.
    ///
    /// * İşaretçi, başlatılmış bir `T` örneğini göstermelidir.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği belleğe başka herhangi bir işaretçi aracılığıyla erişilmemeli (okunmamalı veya yazılmamalıdır).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    /// (Başlatma ile ilgili kısım henüz tam olarak kararlaştırılmamıştır, ancak bu olana kadar, tek güvenli yaklaşım bunların gerçekten başlatıldıklarından emin olmaktır.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // GÜVENLİK: Arayan kişi, `self` in tüm gereksinimleri karşıladığını garanti etmelidir.
        // değişebilir bir referans için gereksinimler.
        unsafe { &mut *self.as_ptr() }
    }

    /// Başka türden bir işaretçiye çevirir.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // GÜVENLİK: `self`, mutlaka boş olmayan bir `NonNull` işaretçisidir
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// İnce bir işaretçi ve uzunluktan boş olmayan bir ham dilim oluşturur.
    ///
    /// `len` argümanı bayt sayısı değil **öğe sayısıdır**.
    ///
    /// Bu işlev güvenlidir, ancak dönüş değerinin referansının kaldırılması güvenli değildir.
    /// Dilim güvenlik gereksinimleri için [`slice::from_raw_parts`] belgelerine bakın.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ilk öğeye bir işaretçi ile başlarken bir dilim işaretçisi oluştur
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Bu örneğin yapay olarak bu yöntemin bir kullanımını gösterdiğine dikkat edin, ancak `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // GÜVENLİK: `data`, mutlaka boş olmayan bir `NonNull` işaretçisidir
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Boş olmayan bir ham dilimin uzunluğunu döndürür.
    ///
    /// Döndürülen değer, bayt sayısı değil **öğe sayısıdır**.
    ///
    /// Bu işlev, işaretçi geçerli bir adrese sahip olmadığından boş olmayan ham dilim bir dilime aktarılamadığında bile güvenlidir.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Dilimin arabelleğine boş olmayan bir işaretçi döndürür.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // GÜVENLİK: `self` in boş olmadığını biliyoruz.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Dilimin arabelleğine ham bir işaretçi döndürür.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Muhtemelen başlatılmamış değerlerin bir dilimine paylaşılan bir başvuru döndürür.[`as_ref`] in aksine, bu, değerin başlatılmasını gerektirmez.
    ///
    /// Değişken muadili için [`as_uninit_slice_mut`] e bakınız.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken, aşağıdakilerin hepsinin doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi, `ptr.len() * mem::size_of::<T>()` için çok bayt okumalar için [valid] olmalı ve uygun şekilde hizalanmalıdır.Bu özellikle şu anlama gelir:
    ///
    ///     * Bu dilimin tüm bellek aralığı, tek bir tahsis edilmiş nesne içinde yer almalıdır!
    ///       Dilimler asla birden fazla tahsis edilmiş nesneye yayılamaz.
    ///
    ///     * İşaretçi, sıfır uzunluklu dilimler için bile hizalanmalıdır.
    ///     Bunun bir nedeni, numaralandırma düzeni optimizasyonlarının hizalanmış olan ve diğer verilerden ayırmak için boş olmayan referanslara (herhangi bir uzunluktaki dilimler dahil) güvenebilmesidir.
    ///
    ///     [`NonNull::dangling()`] kullanarak sıfır uzunluklu dilimler için `data` olarak kullanılabilen bir işaretçi elde edebilirsiniz.
    ///
    /// * Dilimin toplam boyutu `ptr.len() * mem::size_of::<T>()`, `isize::MAX` ten büyük olmamalıdır.
    ///   [`pointer::offset`] in güvenlik belgelerine bakın.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği bellek mutasyona uğramamalıdır (`UnsafeCell` in içi hariç).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    ///
    /// Ayrıca bkz. [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // GÜVENLİK: Arayan kişi `as_uninit_slice` için güvenlik sözleşmesine uymalıdır.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Muhtemelen başlatılmamış değerlerin bir dilimine benzersiz bir başvuru döndürür.[`as_mut`] in aksine, bu, değerin başlatılmasını gerektirmez.
    ///
    /// Paylaşılan meslektaş için [`as_uninit_slice`] e bakınız.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken, aşağıdakilerin hepsinin doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi, `ptr.len() * mem::size_of::<T>()` için birçok bayt okuma ve yazma için [valid] olmalı ve uygun şekilde hizalanmalıdır.Bu özellikle şu anlama gelir:
    ///
    ///     * Bu dilimin tüm bellek aralığı, tek bir tahsis edilmiş nesne içinde yer almalıdır!
    ///       Dilimler asla birden fazla tahsis edilmiş nesneye yayılamaz.
    ///
    ///     * İşaretçi, sıfır uzunluklu dilimler için bile hizalanmalıdır.
    ///     Bunun bir nedeni, numaralandırma düzeni optimizasyonlarının hizalanmış olan ve diğer verilerden ayırmak için boş olmayan referanslara (herhangi bir uzunluktaki dilimler dahil) güvenebilmesidir.
    ///
    ///     [`NonNull::dangling()`] kullanarak sıfır uzunluklu dilimler için `data` olarak kullanılabilen bir işaretçi elde edebilirsiniz.
    ///
    /// * Dilimin toplam boyutu `ptr.len() * mem::size_of::<T>()`, `isize::MAX` ten büyük olmamalıdır.
    ///   [`pointer::offset`] in güvenlik belgelerine bakın.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği belleğe başka herhangi bir işaretçi aracılığıyla erişilmemeli (okunmamalı veya yazılmamalıdır).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    ///
    /// Ayrıca bkz. [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // `memory`, `memory.len()` için birçok bayt okuma ve yazma için geçerli olduğundan bu güvenlidir.
    /// // İçerik başlatılmamış olabileceğinden, burada `memory.as_mut()` i çağırmaya izin verilmediğini unutmayın.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // GÜVENLİK: Arayan kişi `as_uninit_slice_mut` için güvenlik sözleşmesine uymalıdır.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Sınır kontrolü yapmadan bir öğeye veya alt dilime ham bir işaretçi döndürür.
    ///
    /// Sonuçta ortaya çıkan işaretçi kullanılmasa bile, bu yöntemin sınır dışı bir indeksle veya `self` in atanamaz olmadığı durumlarda çağrılması *[tanımsız davranış]* olur.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // GÜVENLİK: Arayan, `self` in ayrılabilir ve `index` in sınırlar içinde olmasını sağlar.
        // Sonuç olarak, ortaya çıkan işaretçi NULL olamaz.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // GÜVENLİK: Benzersiz bir işaretçi boş olamaz, bu nedenle
        // new_unchecked() saygı duyulur.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // GÜVENLİK: Değişebilir bir referans boş olamaz.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // GÜVENLİK: Bir referans boş olamaz, bu nedenle
        // new_unchecked() saygı duyulur.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}