use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// İşaretçi boş ise `true` döndürür.
    ///
    /// Boyutlandırılmamış türlerin birçok olası boş işaretçisi olduğunu unutmayın; uzunlukları, vtable vb. Değil, yalnızca ham veri işaretçisi dikkate alınır.
    /// Bu nedenle, boş olan iki işaretçi yine de birbirine eşit olarak karşılaştırılamayabilir.
    ///
    /// ## Sabit değerlendirme sırasında davranış
    ///
    /// Bu işlev const değerlendirmesi sırasında kullanıldığında, çalışma zamanında boş olduğu ortaya çıkan işaretçiler için `false` döndürebilir.
    /// Spesifik olarak, bir belleğe bir işaretçi, sonuçtaki işaretçi boş olacak şekilde sınırlarının ötesine kaydırıldığında, işlev yine de `false` döndürür.
    ///
    /// CTFE'nin bu belleğin mutlak konumunu bilmesinin bir yolu yoktur, bu nedenle işaretçinin boş olup olmadığını söyleyemeyiz.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Bir cast yoluyla ince bir işaretçiyle karşılaştırın, bu nedenle şişman işaretçiler yalnızca "data" parçalarını boşluğa göre değerlendiriyorlar.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Başka türden bir işaretçiye çevirir.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Bir (muhtemelen geniş) göstericiyi adres ve meta veri bileşenlerine ayrıştırın.
    ///
    /// İşaretçi daha sonra [`from_raw_parts_mut`] ile yeniden yapılandırılabilir.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// İşaretçi boşsa `None` i döndürür, aksi takdirde `Some` e sarılmış değere paylaşılan bir başvuru döndürür.Değer başlatılmamışsa, bunun yerine [`as_uninit_ref`] kullanılmalıdır.
    ///
    /// Değişken muadili için [`as_mut`] e bakın.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken,*ya* göstericinin NULL *ya da* tümünün doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi doğru şekilde hizalanmalıdır.
    ///
    /// * [the module documentation] te tanımlanan anlamda "dereferencable" olmalıdır.
    ///
    /// * İşaretçi, başlatılmış bir `T` örneğini göstermelidir.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği bellek mutasyona uğramamalıdır (`UnsafeCell` in içi hariç).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    /// (Başlatma ile ilgili kısım henüz tam olarak kararlaştırılmamıştır, ancak bu olana kadar, tek güvenli yaklaşım bunların gerçekten başlatıldıklarından emin olmaktır.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null işaretlenmemiş sürüm
    ///
    /// İşaretçinin hiçbir zaman boş olamayacağından eminseniz ve `Option<&T>` yerine `&T` i döndüren bir tür `as_ref_unchecked` arıyorsanız, işaretçiyi doğrudan kaldırabileceğinizi bilin.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // GÜVENLİK: Arayan kişi, `self` in bir süre için geçerli olduğunu garanti etmelidir.
        // boş değilse referans.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// İşaretçi boşsa `None` i döndürür, aksi takdirde `Some` e sarılmış değere paylaşılan bir başvuru döndürür.
    /// [`as_ref`] in aksine, bu, değerin başlatılmasını gerektirmez.
    ///
    /// Değişken muadili için [`as_uninit_mut`] e bakın.
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken,*ya* göstericinin NULL *ya da* tümünün doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi doğru şekilde hizalanmalıdır.
    ///
    /// * [the module documentation] te tanımlanan anlamda "dereferencable" olmalıdır.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği bellek mutasyona uğramamalıdır (`UnsafeCell` in içi hariç).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi, `self` in tüm gereksinimleri karşıladığını garanti etmelidir.
        // referans için gereklilikler.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Bir işaretçiden ofseti hesaplar.
    ///
    /// `count` T birimleri cinsindendir;Örneğin, 3 değerindeki bir `count`, `3 * size_of::<T>()` baytlık bir işaretçi ofsetini temsil eder.
    ///
    /// # Safety
    ///
    /// Aşağıdaki koşullardan herhangi biri ihlal edilirse, sonuç Tanımsız Davranış olur:
    ///
    /// * Hem başlangıç hem de sonuç gösterici sınırlar içinde veya aynı tahsis edilmiş nesnenin sonunu bir bayt geçmelidir.
    /// Rust'de her (stack-allocated) değişkeninin ayrı bir ayrılmış nesne olarak kabul edildiğini unutmayın.
    ///
    /// * Hesaplanan ofset, bayt olarak **, bir `isize` i aşamaz.
    ///
    /// * Ofset sınırlar içinde olan "wrapping around" adres alanına bağlı olamaz.Yani, sonsuz hassasiyetli toplam **bayt olarak** bir kullanım boyutuna uymalıdır.
    ///
    /// Derleyici ve standart kitaplık genellikle ayırmaların hiçbir zaman ofsetin önemli olduğu bir boyuta ulaşmamasını sağlamaya çalışır.
    /// Örneğin, `Vec` ve `Box` hiçbir zaman `isize::MAX` bayttan fazlasını ayırmamalarını sağlar, böylece `vec.as_ptr().add(vec.len())` her zaman güvenlidir.
    ///
    /// Çoğu platform, temelde böyle bir tahsis oluşturamaz.
    /// Örneğin, bilinen hiçbir 64 bit platform, sayfa tablosu sınırlamaları veya adres alanını bölme nedeniyle 2 <sup>63</sup> baytlık bir istek sunamaz.
    /// Bununla birlikte, bazı 32 bit ve 16 bit platformlar, Fiziksel Adres Uzantısı gibi şeylerle `isize::MAX` bayttan fazla isteği başarıyla sunabilir.
    ///
    /// Bu nedenle, doğrudan ayırıcılardan veya bellek eşlemeli dosyalardan *alınan bellek, bu işlevle başa çıkmak için çok büyük olabilir*.
    ///
    /// Bu kısıtlamaların karşılanması zorsa, bunun yerine [`wrapping_offset`] kullanmayı düşünün.
    /// Bu yöntemin tek avantajı, daha agresif derleyici optimizasyonları sağlamasıdır.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `offset` için güvenlik sözleşmesine uymalıdır.
        // Arayan kişinin `self` ile aynı tahsis edilmiş nesneyi işaret ettiğini garanti etmesi gerektiğinden, elde edilen işaretçi yazma işlemleri için geçerlidir.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Kaydırma aritmetiğini kullanarak bir işaretçiden uzaklığı hesaplar.
    /// `count` T birimleri cinsindendir;Örneğin, 3 değerindeki bir `count`, `3 * size_of::<T>()` baytlık bir işaretçi ofsetini temsil eder.
    ///
    /// # Safety
    ///
    /// Bu işlemin kendisi her zaman güvenlidir, ancak sonuçta ortaya çıkan işaretçiyi kullanmak değildir.
    ///
    /// Ortaya çıkan işaretçi, `self` in işaret ettiği aynı tahsis edilmiş nesneye bağlı kalır.
    /// Ayrılmış farklı bir nesneye erişmek için *kullanılamaz*.Rust'de her (stack-allocated) değişkeninin ayrı bir ayrılmış nesne olarak kabul edildiğini unutmayın.
    ///
    /// Başka bir deyişle, `let z = x.wrapping_offset((y as isize) - (x as isize))`, `T` in `1` boyutuna sahip olduğunu ve taşma olmadığını varsaysak bile, `z` i `y` ile aynı *yapmaz* yapmaz: `z`, `x` in bağlı olduğu nesneye bağlıdır ve `x` ve `y` aynı tahsis edilmiş nesneyi işaret eder.
    ///
    /// [`offset`] ile karşılaştırıldığında, bu yöntem temelde aynı tahsis edilmiş nesne içinde kalma gerekliliğini geciktirir: [`offset`], nesne sınırlarını geçerken anında Tanımlanmamış Davranıştır;`wrapping_offset` bir işaretçi üretir, ancak bir işaretçi bağlı olduğu nesnenin sınırları dışındayken referansı kaldırılırsa yine de Tanımsız Davranışa yol açar.
    /// [`offset`] daha iyi optimize edilebilir ve bu nedenle performansa duyarlı kodda tercih edilir.
    ///
    /// Gecikmeli kontrol, nihai sonucun hesaplanması sırasında kullanılan ara değerleri değil, yalnızca referansı kaldırılan işaretçinin değerini dikkate alır.
    /// Örneğin, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` her zaman `x` ile aynıdır.Başka bir deyişle, tahsis edilen nesneyi bırakıp daha sonra yeniden girmeye izin verilir.
    ///
    /// Nesne sınırlarını aşmanız gerekiyorsa, işaretçiyi bir tam sayıya çevirin ve aritmetiği orada yapın.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// // İki öğeli artışlarla ham işaretçi kullanarak yineleme
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // GÜVENLİK: `arith_offset` intrinsic'in çağrılması gereken herhangi bir ön koşulu yoktur.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// İşaretçi boşsa `None` i döndürür, aksi takdirde `Some` e sarılmış değere benzersiz bir başvuru döndürür.Değer başlatılmamışsa, bunun yerine [`as_uninit_mut`] kullanılmalıdır.
    ///
    /// Paylaşılan meslektaş için [`as_ref`] e bakınız.
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken,*ya* göstericinin NULL *ya da* tümünün doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi doğru şekilde hizalanmalıdır.
    ///
    /// * [the module documentation] te tanımlanan anlamda "dereferencable" olmalıdır.
    ///
    /// * İşaretçi, başlatılmış bir `T` örneğini göstermelidir.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği belleğe başka herhangi bir işaretçi aracılığıyla erişilmemeli (okunmamalı veya yazılmamalıdır).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    /// (Başlatma ile ilgili kısım henüz tam olarak kararlaştırılmamıştır, ancak bu olana kadar, tek güvenli yaklaşım bunların gerçekten başlatıldıklarından emin olmaktır.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Yazdırılacak: "[4, 2, 3]".
    /// ```
    ///
    /// # Null işaretlenmemiş sürüm
    ///
    /// İşaretçinin hiçbir zaman boş olamayacağından eminseniz ve `Option<&mut T>` yerine `&mut T` i döndüren bir tür `as_mut_unchecked` arıyorsanız, işaretçiyi doğrudan kaldırabileceğinizi bilin.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Yazdırılacak: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // GÜVENLİK: Arayan kişi, `self` in geçerli olduğunu garanti etmelidir.
        // boş değilse değiştirilebilir bir referans.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// İşaretçi boşsa `None` i döndürür, aksi takdirde `Some` e sarılmış değere benzersiz bir başvuru döndürür.
    /// [`as_mut`] in aksine, bu, değerin başlatılmasını gerektirmez.
    ///
    /// Paylaşılan meslektaş için [`as_uninit_ref`] e bakınız.
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken,*ya* göstericinin NULL *ya da* tümünün doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi doğru şekilde hizalanmalıdır.
    ///
    /// * [the module documentation] te tanımlanan anlamda "dereferencable" olmalıdır.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği belleğe başka herhangi bir işaretçi aracılığıyla erişilmemeli (okunmamalı veya yazılmamalıdır).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi, `self` in tüm gereksinimleri karşıladığını garanti etmelidir.
        // referans için gereklilikler.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// İki işaretleyicinin eşit olmasının garantili olup olmadığını döndürür.
    ///
    /// Çalışma zamanında bu işlev `self == other` gibi davranır.
    /// Bununla birlikte, bazı bağlamlarda (örneğin, derleme zamanı değerlendirmesi), iki işaretleyicinin eşitliğini belirlemek her zaman mümkün değildir, bu nedenle bu işlev, daha sonra gerçekten eşit olduğu ortaya çıkan işaretçiler için `false` i sahte bir şekilde döndürebilir.
    ///
    /// Ancak `true` i döndürdüğünde, işaretçilerin eşit olması garanti edilir.
    ///
    /// Bu işlev [`guaranteed_ne`] in aynasıdır, ancak tersi değildir.Her iki işlevin de `false` döndürdüğü işaretçi karşılaştırmaları vardır.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Dönüş değeri, derleyici sürümüne bağlı olarak değişebilir ve güvenli olmayan kod, sağlamlık için bu işlevin sonucuna bağlı olmayabilir.
    /// Bu işlevin yalnızca, bu işlevin sahte `false` dönüş değerlerinin sonucu etkilemediği, yalnızca performansı etkilediği performans optimizasyonları için kullanılması önerilir.
    /// Çalışma zamanı ve derleme zamanı kodunun farklı davranmasını sağlamak için bu yöntemi kullanmanın sonuçları araştırılmamıştır.
    /// Bu yöntem, bu tür farklılıkları ortaya çıkarmak için kullanılmamalı ve bu konuyu daha iyi anlamadan önce stabilize edilmemelidir.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// İki işaretçinin eşit olmadığının garantili olup olmadığını döndürür.
    ///
    /// Çalışma zamanında bu işlev `self != other` gibi davranır.
    /// Bununla birlikte, bazı bağlamlarda (örneğin, derleme zamanı değerlendirmesi), iki işaretleyicinin eşitsizliğini belirlemek her zaman mümkün değildir, bu nedenle bu işlev, daha sonra gerçekten eşitsiz olduğu ortaya çıkan işaretçiler için `false` i sahte bir şekilde döndürebilir.
    ///
    /// Ancak `true` i döndürdüğünde, işaretçilerin eşit olmadığı garanti edilir.
    ///
    /// Bu işlev [`guaranteed_eq`] in aynasıdır, ancak tersi değildir.Her iki işlevin de `false` döndürdüğü işaretçi karşılaştırmaları vardır.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Dönüş değeri, derleyici sürümüne bağlı olarak değişebilir ve güvenli olmayan kod, sağlamlık için bu işlevin sonucuna bağlı olmayabilir.
    /// Bu işlevin yalnızca, bu işlevin sahte `false` dönüş değerlerinin sonucu etkilemediği, yalnızca performansı etkilediği performans optimizasyonları için kullanılması önerilir.
    /// Çalışma zamanı ve derleme zamanı kodunun farklı davranmasını sağlamak için bu yöntemi kullanmanın sonuçları araştırılmamıştır.
    /// Bu yöntem, bu tür farklılıkları ortaya çıkarmak için kullanılmamalı ve bu konuyu daha iyi anlamadan önce stabilize edilmemelidir.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// İki işaretçi arasındaki mesafeyi hesaplar.Döndürülen değer T birimleri cinsindendir: bayt cinsinden mesafe `mem::size_of::<T>()` e bölünür.
    ///
    /// Bu işlev [`offset`] in tersidir.
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Aşağıdaki koşullardan herhangi biri ihlal edilirse, sonuç Tanımsız Davranış olur:
    ///
    /// * Hem başlangıç hem de diğer gösterici, sınırlar içinde veya aynı tahsis edilmiş nesnenin sonundan bir bayt geçmelidir.
    /// Rust'de her (stack-allocated) değişkeninin ayrı bir ayrılmış nesne olarak kabul edildiğini unutmayın.
    ///
    /// * Her iki işaretçi de aynı nesneye yönelik bir işaretçiden *türetilmelidir*.
    ///   (Örnek için aşağıya bakın.)
    ///
    /// * Bayt cinsinden işaretçiler arasındaki mesafe, `T` boyutunun tam katı olmalıdır.
    ///
    /// * İşaretçiler arasındaki mesafe,**bayt olarak**, bir `isize` i aşamaz.
    ///
    /// * Mesafe sınırlar içinde olan "wrapping around" adres alanına bağlı olamaz.
    ///
    /// Rust türleri hiçbir zaman `isize::MAX` ve Rust tahsislerinden daha büyük değildir, bu nedenle herhangi bir Rust tipi `T` in bir değerindeki iki işaretçi her zaman son iki koşulu karşılayacaktır.
    ///
    /// Standart kütüphane ayrıca genellikle tahsislerin bir ofsetin önemli olduğu bir boyuta asla ulaşmamasını sağlar.
    /// Örneğin, `Vec` ve `Box` hiçbir zaman `isize::MAX` bayttan fazlasını ayırmamalarını sağlar, böylece `ptr_into_vec.offset_from(vec.as_ptr())` her zaman son iki koşulu karşılar.
    ///
    /// Çoğu platform, temelde bu kadar büyük bir tahsis oluşturamaz.
    /// Örneğin, bilinen hiçbir 64 bit platform, sayfa tablosu sınırlamaları veya adres alanını bölme nedeniyle 2 <sup>63</sup> baytlık bir istek sunamaz.
    /// Bununla birlikte, bazı 32 bit ve 16 bit platformlar, Fiziksel Adres Uzantısı gibi şeylerle `isize::MAX` bayttan fazla isteği başarıyla sunabilir.
    /// Bu nedenle, doğrudan ayırıcılardan veya bellek eşlemeli dosyalardan *alınan bellek, bu işlevle başa çıkmak için çok büyük olabilir*.
    /// ([`offset`] ve [`add`] in de benzer bir sınırlamaya sahip olduğunu ve bu nedenle bu kadar büyük tahsislerde kullanılamayacağını unutmayın.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// `T`, Sıfır Ölçekli ("ZST") Tipi ise bu panics işlevi.
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Yanlış* kullanım:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Ptr2_other'ı ptr2 in bir "alias" i yapın, ancak ptr1 ten türetilmiştir.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ptr2_other ve ptr2, işaretçilerden farklı nesnelere türetildiğinden, ofsetlerini hesaplamak, aynı adresi gösterseler bile, tanımsız bir davranıştır!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Tanımsız Davranış
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `offset_from` için güvenlik sözleşmesine uymalıdır.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Bir işaretçiden ofseti hesaplar (`.offset(count as isize)`) için kolaylık.
    ///
    /// `count` T birimleri cinsindendir;Örneğin, 3 değerindeki bir `count`, `3 * size_of::<T>()` baytlık bir işaretçi ofsetini temsil eder.
    ///
    /// # Safety
    ///
    /// Aşağıdaki koşullardan herhangi biri ihlal edilirse, sonuç Tanımsız Davranış olur:
    ///
    /// * Hem başlangıç hem de sonuç gösterici sınırlar içinde veya aynı tahsis edilmiş nesnenin sonunu bir bayt geçmelidir.
    /// Rust'de her (stack-allocated) değişkeninin ayrı bir ayrılmış nesne olarak kabul edildiğini unutmayın.
    ///
    /// * Hesaplanan ofset, bayt olarak **, bir `isize` i aşamaz.
    ///
    /// * Ofset sınırlar içinde olan "wrapping around" adres alanına bağlı olamaz.Yani, sonsuz hassasiyetli toplam bir `usize` e sığmalıdır.
    ///
    /// Derleyici ve standart kitaplık genellikle ayırmaların hiçbir zaman ofsetin önemli olduğu bir boyuta ulaşmamasını sağlamaya çalışır.
    /// Örneğin, `Vec` ve `Box` hiçbir zaman `isize::MAX` bayttan fazlasını ayırmamalarını sağlar, böylece `vec.as_ptr().add(vec.len())` her zaman güvenlidir.
    ///
    /// Çoğu platform, temelde böyle bir tahsis oluşturamaz.
    /// Örneğin, bilinen hiçbir 64 bit platform, sayfa tablosu sınırlamaları veya adres alanını bölme nedeniyle 2 <sup>63</sup> baytlık bir istek sunamaz.
    /// Bununla birlikte, bazı 32 bit ve 16 bit platformlar, Fiziksel Adres Uzantısı gibi şeylerle `isize::MAX` bayttan fazla isteği başarıyla sunabilir.
    ///
    /// Bu nedenle, doğrudan ayırıcılardan veya bellek eşlemeli dosyalardan *alınan bellek, bu işlevle başa çıkmak için çok büyük olabilir*.
    ///
    /// Bu kısıtlamaların karşılanması zorsa, bunun yerine [`wrapping_add`] kullanmayı düşünün.
    /// Bu yöntemin tek avantajı, daha agresif derleyici optimizasyonları sağlamasıdır.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `offset` için güvenlik sözleşmesine uymalıdır.
        unsafe { self.offset(count as isize) }
    }

    /// Bir işaretçiden ofseti hesaplar (".offset için kolaylık ((isize).wrapping_neg())`) olarak sayılır).
    ///
    /// `count` T birimleri cinsindendir;Örneğin, 3 değerindeki bir `count`, `3 * size_of::<T>()` baytlık bir işaretçi ofsetini temsil eder.
    ///
    /// # Safety
    ///
    /// Aşağıdaki koşullardan herhangi biri ihlal edilirse, sonuç Tanımsız Davranış olur:
    ///
    /// * Hem başlangıç hem de sonuç gösterici sınırlar içinde veya aynı tahsis edilmiş nesnenin sonunu bir bayt geçmelidir.
    /// Rust'de her (stack-allocated) değişkeninin ayrı bir ayrılmış nesne olarak kabul edildiğini unutmayın.
    ///
    /// * Hesaplanan ofset `isize::MAX`**bayt**'ı aşamaz.
    ///
    /// * Ofset sınırlar içinde olan "wrapping around" adres alanına bağlı olamaz.Yani, sonsuz hassasiyetli toplam bir kullanım boyutuna uymalıdır.
    ///
    /// Derleyici ve standart kitaplık genellikle ayırmaların hiçbir zaman ofsetin önemli olduğu bir boyuta ulaşmamasını sağlamaya çalışır.
    /// Örneğin, `Vec` ve `Box` hiçbir zaman `isize::MAX` bayttan fazlasını ayırmamalarını sağlar, böylece `vec.as_ptr().add(vec.len()).sub(vec.len())` her zaman güvenlidir.
    ///
    /// Çoğu platform, temelde böyle bir tahsis oluşturamaz.
    /// Örneğin, bilinen hiçbir 64 bit platform, sayfa tablosu sınırlamaları veya adres alanını bölme nedeniyle 2 <sup>63</sup> baytlık bir istek sunamaz.
    /// Bununla birlikte, bazı 32 bit ve 16 bit platformlar, Fiziksel Adres Uzantısı gibi şeylerle `isize::MAX` bayttan fazla isteği başarıyla sunabilir.
    ///
    /// Bu nedenle, doğrudan ayırıcılardan veya bellek eşlemeli dosyalardan *alınan bellek, bu işlevle başa çıkmak için çok büyük olabilir*.
    ///
    /// Bu kısıtlamaların karşılanması zorsa, bunun yerine [`wrapping_sub`] kullanmayı düşünün.
    /// Bu yöntemin tek avantajı, daha agresif derleyici optimizasyonları sağlamasıdır.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `offset` için güvenlik sözleşmesine uymalıdır.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Kaydırma aritmetiğini kullanarak bir işaretçiden uzaklığı hesaplar.
    /// (`.wrapping_offset(count as isize)`) için kolaylık
    ///
    /// `count` T birimleri cinsindendir;Örneğin, 3 değerindeki bir `count`, `3 * size_of::<T>()` baytlık bir işaretçi ofsetini temsil eder.
    ///
    /// # Safety
    ///
    /// Bu işlemin kendisi her zaman güvenlidir, ancak sonuçta ortaya çıkan işaretçiyi kullanmak değildir.
    ///
    /// Ortaya çıkan işaretçi, `self` in işaret ettiği aynı tahsis edilmiş nesneye bağlı kalır.
    /// Ayrılmış farklı bir nesneye erişmek için *kullanılamaz*.Rust'de her (stack-allocated) değişkeninin ayrı bir ayrılmış nesne olarak kabul edildiğini unutmayın.
    ///
    /// Başka bir deyişle, `let z = x.wrapping_add((y as usize) - (x as usize))`, `T` in `1` boyutuna sahip olduğunu ve taşma olmadığını varsaysak bile, `z` i `y` ile aynı *yapmaz* yapmaz: `z`, `x` in bağlı olduğu nesneye bağlıdır ve `x` ve `y` aynı tahsis edilmiş nesneyi işaret eder.
    ///
    /// [`add`] ile karşılaştırıldığında, bu yöntem temelde aynı tahsis edilmiş nesne içinde kalma gerekliliğini geciktirir: [`add`], nesne sınırlarını geçerken anında Tanımlanmamış Davranıştır;`wrapping_add` bir işaretçi üretir, ancak bir işaretçi bağlı olduğu nesnenin sınırları dışındayken referansı kaldırılırsa yine de Tanımsız Davranışa yol açar.
    /// [`add`] daha iyi optimize edilebilir ve bu nedenle performansa duyarlı kodda tercih edilir.
    ///
    /// Gecikmeli kontrol, nihai sonucun hesaplanması sırasında kullanılan ara değerleri değil, yalnızca referansı kaldırılan işaretçinin değerini dikkate alır.
    /// Örneğin, `x.wrapping_add(o).wrapping_sub(o)` her zaman `x` ile aynıdır.Başka bir deyişle, tahsis edilen nesneyi bırakıp daha sonra yeniden girmeye izin verilir.
    ///
    /// Nesne sınırlarını aşmanız gerekiyorsa, işaretçiyi bir tam sayıya çevirin ve aritmetiği orada yapın.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// // İki öğeli artışlarla ham işaretçi kullanarak yineleme
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Bu döngü "1, 3, 5, " yazdırır
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Kaydırma aritmetiğini kullanarak bir işaretçiden uzaklığı hesaplar.
    /// (".wrapping_offset için kolaylık ((isize).wrapping_neg())`) olarak sayılır)
    ///
    /// `count` T birimleri cinsindendir;Örneğin, 3 değerindeki bir `count`, `3 * size_of::<T>()` baytlık bir işaretçi ofsetini temsil eder.
    ///
    /// # Safety
    ///
    /// Bu işlemin kendisi her zaman güvenlidir, ancak sonuçta ortaya çıkan işaretçiyi kullanmak değildir.
    ///
    /// Ortaya çıkan işaretçi, `self` in işaret ettiği aynı tahsis edilmiş nesneye bağlı kalır.
    /// Ayrılmış farklı bir nesneye erişmek için *kullanılamaz*.Rust'de her (stack-allocated) değişkeninin ayrı bir ayrılmış nesne olarak kabul edildiğini unutmayın.
    ///
    /// Başka bir deyişle, `let z = x.wrapping_sub((x as usize) - (y as usize))`, `T` in `1` boyutuna sahip olduğunu ve taşma olmadığını varsaysak bile, `z` i `y` ile aynı *yapmaz* yapmaz: `z`, `x` in bağlı olduğu nesneye bağlıdır ve `x` ve `y` aynı tahsis edilmiş nesneyi işaret eder.
    ///
    /// [`sub`] ile karşılaştırıldığında, bu yöntem temelde aynı tahsis edilmiş nesne içinde kalma gerekliliğini geciktirir: [`sub`], nesne sınırlarını geçerken anında Tanımlanmamış Davranıştır;`wrapping_sub` bir işaretçi üretir, ancak bir işaretçi bağlı olduğu nesnenin sınırları dışındayken referansı kaldırılırsa yine de Tanımsız Davranışa yol açar.
    /// [`sub`] daha iyi optimize edilebilir ve bu nedenle performansa duyarlı kodda tercih edilir.
    ///
    /// Gecikmeli kontrol, nihai sonucun hesaplanması sırasında kullanılan ara değerleri değil, yalnızca referansı kaldırılan işaretçinin değerini dikkate alır.
    /// Örneğin, `x.wrapping_add(o).wrapping_sub(o)` her zaman `x` ile aynıdır.Başka bir deyişle, tahsis edilen nesneyi bırakıp daha sonra yeniden girmeye izin verilir.
    ///
    /// Nesne sınırlarını aşmanız gerekiyorsa, işaretçiyi bir tam sayıya çevirin ve aritmetiği orada yapın.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Temel kullanım:
    ///
    /// ```
    /// // İki öğeli (backwards) artışlarla ham işaretçi kullanarak yineleyin
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Bu döngü "5, 3, 1, " yazdırır
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// İşaretçi değerini `ptr` olarak ayarlar.
    ///
    /// `self` in boyutlandırılmamış tipte bir (fat) işaretçisi olması durumunda, bu işlem yalnızca işaretçi kısmını etkileyecektir, oysa boyutlandırılmış tiplere (thin) işaretçileri için bu, basit bir atama ile aynı etkiye sahiptir.
    ///
    /// Ortaya çıkan işaretçi, `val` in kökenine sahip olacaktır, yani bir şişman işaretçi için, bu işlem anlamsal olarak `val` in veri işaretçisi değeriyle ancak `self` in meta verileriyle yeni bir şişman işaretçi oluşturmakla aynıdır.
    ///
    ///
    /// # Examples
    ///
    /// Bu işlev, öncelikle potansiyel olarak şişman işaretçiler üzerinde bayt bazlı işaretçi aritmetiğine izin vermek için kullanışlıdır:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // "3" yazdıracak
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // GÜVENLİK: İnce bir işaretçi durumunda, bu işlemler aynıdır
        // basit bir göreve.
        // Bir şişman işaretçi durumunda, mevcut yağ işaretçisi düzen uygulamasıyla, böyle bir işaretçinin ilk alanı her zaman aynı şekilde atanan veri işaretleyicisidir.
        //
        unsafe { *thin = val };
        self
    }

    /// Değeri `self` ten hareket ettirmeden okur.
    /// Bu, `self` teki belleği değiştirmeden bırakır.
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::read`] e bakın.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `` için güvenlik sözleşmesine uymalıdır.
        unsafe { read(self) }
    }

    /// `self` ten gelen değeri hareket ettirmeden geçici bir okuma gerçekleştirir.Bu, `self` teki belleği değiştirmeden bırakır.
    ///
    /// Uçucu işlemlerin I/O belleğine göre hareket etmesi amaçlanmıştır ve derleyici tarafından diğer uçucu işlemlerde iptal edilmemesi veya yeniden sıralanmaması garanti edilmektedir.
    ///
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::read_volatile`] e bakın.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `read_volatile` için güvenlik sözleşmesine uymalıdır.
        unsafe { read_volatile(self) }
    }

    /// Değeri `self` ten hareket ettirmeden okur.
    /// Bu, `self` teki belleği değiştirmeden bırakır.
    ///
    /// `read` in aksine, işaretçi hizasız olabilir.
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::read_unaligned`] e bakın.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `read_unaligned` için güvenlik sözleşmesine uymalıdır.
        unsafe { read_unaligned(self) }
    }

    /// `self` ten `dest` e `count * size_of<T>` bayt kopyalar.
    /// Kaynak ve hedef çakışabilir.
    ///
    /// NOTE: bu, [`ptr::copy`] ile *aynı* bağımsız değişken sırasına sahiptir.
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::copy`] e bakın.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `copy` için güvenlik sözleşmesine uymalıdır.
        unsafe { copy(self, dest, count) }
    }

    /// `self` ten `dest` e `count * size_of<T>` bayt kopyalar.
    /// Kaynak ve hedef çakışmayabilir *.
    ///
    /// NOTE: bu, [`ptr::copy_nonoverlapping`] ile *aynı* bağımsız değişken sırasına sahiptir.
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::copy_nonoverlapping`] e bakın.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `copy_nonoverlapping` için güvenlik sözleşmesine uymalıdır.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// `src` ten `self` e `count * size_of<T>` bayt kopyalar.
    /// Kaynak ve hedef çakışabilir.
    ///
    /// NOTE: bu [`ptr::copy`] in *zıt* argüman sırasına sahiptir.
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::copy`] e bakın.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `copy` için güvenlik sözleşmesine uymalıdır.
        unsafe { copy(src, self, count) }
    }

    /// `src` ten `self` e `count * size_of<T>` bayt kopyalar.
    /// Kaynak ve hedef çakışmayabilir *.
    ///
    /// NOTE: bu [`ptr::copy_nonoverlapping`] in *zıt* argüman sırasına sahiptir.
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::copy_nonoverlapping`] e bakın.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `copy_nonoverlapping` için güvenlik sözleşmesine uymalıdır.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// İşaret edilen değerin yıkıcısını (varsa) yürütür.
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::drop_in_place`] e bakın.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // GÜVENLİK: Arayan kişi `drop_in_place` için güvenlik sözleşmesine uymalıdır.
        unsafe { drop_in_place(self) }
    }

    /// Eski değeri okumadan veya düşürmeden verilen değerle bir bellek konumunun üzerine yazar.
    ///
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::write`] e bakın.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `write` için güvenlik sözleşmesine uymalıdır.
        unsafe { write(self, val) }
    }

    /// Belirtilen işaretçide memset'i çağırır ve `self` ten başlayarak `val` e `count * size_of::<T>()` bayt bellek ayarını yapar.
    ///
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::write_bytes`] e bakın.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `write_bytes` için güvenlik sözleşmesine uymalıdır.
        unsafe { write_bytes(self, val, count) }
    }

    /// Eski değeri okumadan veya düşürmeden verilen değerle bir bellek konumuna geçici bir yazma gerçekleştirir.
    ///
    /// Uçucu işlemlerin I/O belleğine göre hareket etmesi amaçlanmıştır ve derleyici tarafından diğer uçucu işlemlerde iptal edilmemesi veya yeniden sıralanmaması garanti edilmektedir.
    ///
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::write_volatile`] e bakın.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `write_volatile` için güvenlik sözleşmesine uymalıdır.
        unsafe { write_volatile(self, val) }
    }

    /// Eski değeri okumadan veya düşürmeden verilen değerle bir bellek konumunun üzerine yazar.
    ///
    ///
    /// `write` in aksine, işaretçi hizasız olabilir.
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::write_unaligned`] e bakın.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `write_unaligned` için güvenlik sözleşmesine uymalıdır.
        unsafe { write_unaligned(self, val) }
    }

    /// `self` teki değeri `src` ile değiştirir, her ikisini de düşürmeden eski değeri döndürür.
    ///
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::replace`] e bakın.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `replace` için güvenlik sözleşmesine uymalıdır.
        unsafe { replace(self, src) }
    }

    /// Her ikisini de başlatmadan aynı türdeki iki değiştirilebilir konumdaki değerleri değiştirir.
    /// Aksi takdirde eşdeğer olan `mem::swap` in aksine, üst üste binebilirler.
    ///
    /// Güvenlik endişeleri ve örnekler için [`ptr::swap`] e bakın.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // GÜVENLİK: Arayan kişi `swap` için güvenlik sözleşmesine uymalıdır.
        unsafe { swap(self, with) }
    }

    /// İşaretçinin `align` ile hizalanması için uygulanması gereken ofseti hesaplar.
    ///
    /// İmleci hizalamak mümkün değilse, uygulama `usize::MAX` i döndürür.
    /// Uygulamanın *her zaman*`usize::MAX` döndürmesine izin verilir.
    /// Yalnızca algoritmanızın performansı, burada kullanılabilir bir ofset elde etmeye bağlı olabilir, doğruluğuna değil.
    ///
    /// Göreli konum, baytlarla değil, `T` öğelerinin sayısıyla ifade edilir.Döndürülen değer `wrapping_add` yöntemi ile kullanılabilir.
    ///
    /// İmleci kaydırmanın, işaretçinin işaret ettiği ayırmanın ötesine geçmeyeceğine veya aşmayacağına dair hiçbir garanti yoktur.
    ///
    /// Döndürülen ofsetin hizalama dışındaki tüm terimlerle doğru olduğundan emin olmak arayan kişiye bağlıdır.
    ///
    /// # Panics
    ///
    /// `align` ikinin gücü değilse panics işlevi.
    ///
    /// # Examples
    ///
    /// Bitişik `u8` e `u16` olarak erişim
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // işaretçi `offset` ile hizalanabilirken, tahsisin dışına işaret eder
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // GÜVENLİK: `align` yukarıda 2'nin gücü olarak kontrol edilmiştir
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// İşlenmemiş bir dilimin uzunluğunu döndürür.
    ///
    /// Döndürülen değer, bayt sayısı değil **öğe sayısıdır**.
    ///
    /// Bu işlev, işaretçi boş veya hizasız olduğu için ham dilim bir dilim referansına dönüştürülemediğinde bile güvenlidir.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // GÜVENLİK: Bu güvenlidir çünkü `*const [T]` ve `FatPtr<T>` aynı düzene sahiptir.
            // Bu garantiyi yalnızca `std` verebilir.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Dilimin arabelleğine ham bir işaretçi döndürür.
    ///
    /// Bu, `self` in `*mut T` e dönüştürülmesine eşdeğerdir, ancak daha çok tür açısından güvenlidir.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Sınır kontrolü yapmadan bir öğeye veya alt dilime ham bir işaretçi döndürür.
    ///
    /// Sonuçta ortaya çıkan işaretçi kullanılmasa bile, bu yöntemin sınır dışı bir indeksle veya `self` in atanamaz olmadığı durumlarda çağrılması *[tanımsız davranış]* olur.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // GÜVENLİK: Arayan, `self` in ayrılabilir ve `index` in sınırlar içinde olmasını sağlar.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// İşaretçi boşsa `None` i döndürür veya `Some` e sarılmış değere paylaşılan bir dilimi döndürür.
    /// [`as_ref`] in aksine, bu, değerin başlatılmasını gerektirmez.
    ///
    /// Değişken muadili için [`as_uninit_slice_mut`] e bakınız.
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken,*ya* göstericinin NULL *ya da* tümünün doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi, `ptr.len() * mem::size_of::<T>()` için çok bayt okumalar için [valid] olmalı ve uygun şekilde hizalanmalıdır.Bu özellikle şu anlama gelir:
    ///
    ///     * Bu dilimin tüm bellek aralığı, tek bir tahsis edilmiş nesne içinde yer almalıdır!
    ///       Dilimler asla birden fazla tahsis edilmiş nesneye yayılamaz.
    ///
    ///     * İşaretçi, sıfır uzunluklu dilimler için bile hizalanmalıdır.
    ///     Bunun bir nedeni, numaralandırma düzeni optimizasyonlarının hizalanmış olan ve diğer verilerden ayırmak için boş olmayan referanslara (herhangi bir uzunluktaki dilimler dahil) güvenebilmesidir.
    ///
    ///     [`NonNull::dangling()`] kullanarak sıfır uzunluklu dilimler için `data` olarak kullanılabilen bir işaretçi elde edebilirsiniz.
    ///
    /// * Dilimin toplam boyutu `ptr.len() * mem::size_of::<T>()`, `isize::MAX` ten büyük olmamalıdır.
    ///   [`pointer::offset`] in güvenlik belgelerine bakın.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği bellek mutasyona uğramamalıdır (`UnsafeCell` in içi hariç).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    ///
    /// Ayrıca bkz. [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // GÜVENLİK: Arayan kişi `as_uninit_slice` için güvenlik sözleşmesine uymalıdır.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// İşaretçi boşsa `None` i döndürür veya `Some` e sarılmış değere benzersiz bir dilim döndürür.
    /// [`as_mut`] in aksine, bu, değerin başlatılmasını gerektirmez.
    ///
    /// Paylaşılan meslektaş için [`as_uninit_slice`] e bakınız.
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Bu yöntemi çağırırken,*ya* göstericinin NULL *ya da* tümünün doğru olduğundan emin olmalısınız:
    ///
    /// * İşaretçi, `ptr.len() * mem::size_of::<T>()` için birçok bayt okuma ve yazma için [valid] olmalı ve uygun şekilde hizalanmalıdır.Bu özellikle şu anlama gelir:
    ///
    ///     * Bu dilimin tüm bellek aralığı, tek bir tahsis edilmiş nesne içinde yer almalıdır!
    ///       Dilimler asla birden fazla tahsis edilmiş nesneye yayılamaz.
    ///
    ///     * İşaretçi, sıfır uzunluklu dilimler için bile hizalanmalıdır.
    ///     Bunun bir nedeni, numaralandırma düzeni optimizasyonlarının hizalanmış olan ve diğer verilerden ayırmak için boş olmayan referanslara (herhangi bir uzunluktaki dilimler dahil) güvenebilmesidir.
    ///
    ///     [`NonNull::dangling()`] kullanarak sıfır uzunluklu dilimler için `data` olarak kullanılabilen bir işaretçi elde edebilirsiniz.
    ///
    /// * Dilimin toplam boyutu `ptr.len() * mem::size_of::<T>()`, `isize::MAX` ten büyük olmamalıdır.
    ///   [`pointer::offset`] in güvenlik belgelerine bakın.
    ///
    /// * Döndürülen yaşam süresi `'a` keyfi olarak seçildiğinden ve verilerin gerçek yaşam süresini yansıtması gerekmediğinden, Rust'nin diğer adlandırma kurallarını uygulamanız gerekir.
    ///   Özellikle, bu yaşam süresi boyunca, işaretçinin işaret ettiği belleğe başka herhangi bir işaretçi aracılığıyla erişilmemeli (okunmamalı veya yazılmamalıdır).
    ///
    /// Bu, bu yöntemin sonucu kullanılmasa bile geçerlidir!
    ///
    /// Ayrıca bkz. [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // GÜVENLİK: Arayan kişi `as_uninit_slice_mut` için güvenlik sözleşmesine uymalıdır.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// İşaretçiler için eşitlik
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}