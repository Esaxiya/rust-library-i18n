#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// İşaretli herhangi bir yazının işaretçi meta veri türünü sağlar.
///
/// # İşaretçi meta verileri
///
/// Rust'deki ham işaretçi türleri ve referans türleri iki bölümden oluşuyor olarak düşünülebilir:
/// değerin bellek adresini ve bazı meta verileri içeren bir veri işaretçisi.
///
/// Statik boyutlu türler (`Sized` traits'yi uygulayan) ve `extern` türleri için işaretçilerin "ince" olduğu söylenir: meta veriler sıfır boyuttadır ve türü `()` tir.
///
///
/// [dynamically-sized types][dst] e yönelik işaretçilerin "geniş" veya "şişman" olduğu söylenir, sıfır boyutta olmayan meta verilere sahiptirler:
///
/// * Son alanı DST olan yapılar için meta veriler, son alanın meta verileridir
/// * `str` türü için meta veriler, `usize` olarak bayt cinsinden uzunluktur
/// * `[T]` gibi dilim türleri için meta veriler, `usize` olarak öğelerdeki uzunluktur
/// * `dyn SomeTrait` gibi trait nesneleri için meta veriler [`DynMetadata<Self>`][DynMetadata] tir (örneğin `DynMetadata<dyn SomeTrait>`)
///
/// future'de, Rust dili, farklı işaretçi meta verilerine sahip yeni türler kazanabilir.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Bu trait'nin noktası, yukarıda açıklandığı gibi `Metadata` ile ilişkili olan `()` veya `usize` veya `DynMetadata<_>` tipidir.
/// Her tür için otomatik olarak uygulanır.
/// Karşılık gelen bir sınır olmasa bile genel bir bağlamda uygulandığı varsayılabilir.
///
/// # Usage
///
/// Ham işaretçiler, [`to_raw_parts`] yöntemleriyle veri adresine ve meta veri bileşenlerine ayrıştırılabilir.
///
/// Alternatif olarak, meta veriler tek başına [`metadata`] işlevi ile çıkarılabilir.
/// [`metadata`] e bir referans aktarılabilir ve dolaylı olarak zorlanabilir.
///
/// Bir (possibly-wide) işaretçisi, adresinden ve meta verilerinden [`from_raw_parts`] veya [`from_raw_parts_mut`] ile bir araya getirilebilir.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// İşaretçilerdeki meta veri türü ve `Self` e başvurular.
    #[lang = "metadata_type"]
    // NOTE: trait bounds'yi `static_assert_expected_bounds_for_metadata` te tutun
    //
    // `library/core/src/ptr/metadata.rs` te buradakilerle senkronize:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Bu trait diğer adını uygulayan türlere işaretçiler "zayıf" tır.
///
/// Bu, statik olarak "Boyutlandırılmış" türleri ve `extern` türlerini içerir.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait takma adları dilde kararlı hale gelmeden önce bunu stabilize etmeyin mi?
pub trait Thin = Pointee<Metadata = ()>;

/// Bir işaretçinin meta veri bileşenini çıkarın.
///
/// `*mut T`, `&T` veya `&mut T` tipi değerler, dolaylı olarak `* const T` e zorladıkları için doğrudan bu işleve geçirilebilir.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // GÜVENLİK: `PtrRepr` birleşiminden değere erişmek güvenlidir çünkü * const T
    // ve PtrComponents<T>aynı hafıza düzenlerine sahip.
    // Yalnızca std bu garantiyi verebilir.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Bir veri adresinden ve meta veriden bir (possibly-wide) ham işaretçi oluşturur.
///
/// Bu işlev güvenlidir, ancak döndürülen göstericinin referansın kaldırılması güvenli değildir.
/// Dilimler için, güvenlik gereksinimleri için [`slice::from_raw_parts`] belgelerine bakın.
/// trait nesneleri için, meta veriler bir işaretçiden aynı temeldeki önceden aranan türe gelmelidir.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // GÜVENLİK: `PtrRepr` birleşiminden değere erişmek güvenlidir çünkü * const T
    // ve PtrComponents<T>aynı hafıza düzenlerine sahip.
    // Yalnızca std bu garantiyi verebilir.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Ham `*const` işaretçisinin aksine, ham bir `* mut` işaretçisinin döndürülmesi dışında [`from_raw_parts`] ile aynı işlevselliği gerçekleştirir.
///
///
/// Daha fazla ayrıntı için [`from_raw_parts`] belgelerine bakın.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // GÜVENLİK: `PtrRepr` birleşiminden değere erişmek güvenlidir çünkü * const T
    // ve PtrComponents<T>aynı hafıza düzenlerine sahip.
    // Yalnızca std bu garantiyi verebilir.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` bağını önlemek için manuel uygulama gereklidir.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` bağını önlemek için manuel uygulama gereklidir.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait nesne türü için meta veriler.
///
/// Bir trait nesnesi içinde depolanan somut türü işlemek için gerekli tüm bilgileri temsil eden bir vtable (sanal çağrı tablosu) için bir göstericidir.
/// Vtable özellikle şunları içerir:
///
/// * tip boyutu
/// * yazım hizalaması
/// * türün `drop_in_place` gösterimine bir işaretçi (düz eski veriler için işlemsiz olabilir)
/// * trait türünün uygulanması için tüm yöntemlere işaret eder
///
/// İlk üçünün özel olduğunu unutmayın çünkü herhangi bir trait nesnesini ayırmak, bırakmak ve serbest bırakmak için gereklidirler.
///
/// Bu yapıya `dyn` trait nesnesi olmayan (örneğin `DynMetadata<u64>`) ancak bu yapının anlamlı bir değerini elde edemeyen bir tür parametresi ile isim vermek mümkündür.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Tüm vtable'ların ortak öneki.Bunu, trait yöntemleri için işlev işaretçileri izler.
///
/// `DynMetadata::size_of` in özel uygulama detayı vb.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Bu vtable ile ilişkili türün boyutunu döndürür.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Bu vtable ile ilişkili türün hizalamasını döndürür.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Boyutu ve hizalamayı `Layout` olarak birlikte döndürür
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // GÜVENLİK: derleyici bu vtable'ı beton bir Rust tipi için yayınladı.
        // geçerli bir düzene sahip olduğu bilinmektedir.`Layout::for_value` ile aynı mantık.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` sınırlarından kaçınmak için manuel uygulamalar gereklidir.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}