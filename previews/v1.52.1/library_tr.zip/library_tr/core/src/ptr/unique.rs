use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Bu paketleyicinin sahibinin referansın sahibi olduğunu gösteren, boş olmayan ham `*mut T` in etrafındaki bir sarmalayıcı.
/// `Box<T>`, `Vec<T>`, `String` ve `HashMap<K, V>` gibi soyutlamalar oluşturmak için kullanışlıdır.
///
/// `*mut T` in aksine, `Unique<T>`, "as if" e davranır, bu bir `T` örneğidir.
/// `T`, `Send`/`Sync` ise `Send`/`Sync` i uygular.
/// Aynı zamanda, bir `T` örneğinin bekleyebileceği türden güçlü örtüşme garantisi anlamına da gelir:
/// İşaretçinin referansı, sahip olduğu Unique'e benzersiz bir yol olmadan değiştirilmemelidir.
///
/// `Unique` i amaçlarınız için kullanmanın doğru olup olmadığından emin değilseniz, daha zayıf anlamlara sahip olan `NonNull` i kullanmayı düşünün.
///
///
/// `*mut T` ten farklı olarak, işaretçi hiçbir zaman başvurulmasa bile, işaretçi her zaman boş olmamalıdır.
/// Bu, numaralandırmaların bu yasak değeri bir ayrımcı olarak kullanabilmeleri içindir-`Option<Unique<T>>`, `Unique<T>` ile aynı boyuta sahiptir.
/// Bununla birlikte, işaretçi referans alınmazsa yine de sarkabilir.
///
/// `*mut T` in aksine, `Unique<T>`, `T` e göre kovaryanttır.
/// Bu, Unique'in takma ad gereksinimlerini destekleyen her tür için her zaman doğru olmalıdır.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: bu işaretleyicinin varyans için bir sonucu yoktur, ancak gereklidir
    // Dropck'in mantıksal olarak bir `T` e sahip olduğumuzu anlaması için.
    //
    // Ayrıntılar için bkz:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` `T` `Send` ise işaretçiler `Send` tir, çünkü referans verdikleri veriler başka değildir.
/// Bu örtüşme değişmezinin tür sistemi tarafından zorlanmadığına dikkat edin;`Unique` kullanan soyutlama bunu zorlamalıdır.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` `T` `Sync` ise işaretçiler `Sync` tir, çünkü referans verdikleri veriler başka değildir.
/// Bu örtüşme değişmezinin tür sistemi tarafından zorlanmadığına dikkat edin;`Unique` kullanan soyutlama bunu zorlamalıdır.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Sarkan ancak iyi hizalanmış yeni bir `Unique` oluşturur.
    ///
    /// Bu, `Vec::new` in yaptığı gibi, tembel olarak tahsis eden türleri başlatmak için kullanışlıdır.
    ///
    /// İşaretçi değerinin potansiyel olarak bir `T` için geçerli bir göstericiyi temsil edebileceğini unutmayın; bu, bunun bir "not yet initialized" gözlemci değeri olarak kullanılmaması gerektiği anlamına gelir.
    /// Tembel olarak tahsis edilen türler, başlatmayı başka yollarla izlemelidir.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // GÜVENLİK: mem::align_of() geçerli, boş olmayan bir işaretçi döndürür.
        // new_unchecked() i arama koşullarına bu nedenle uyulur.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Yeni bir `Unique` oluşturur.
    ///
    /// # Safety
    ///
    /// `ptr` boş olmamalıdır.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // GÜVENLİK: Arayan, `ptr` in boş olmadığını garanti etmelidir.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` boş değilse yeni bir `Unique` oluşturur.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // GÜVENLİK: İşaretçi zaten kontrol edildi ve boş değil.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Temeldeki `*mut` işaretçisini alır.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// İçeriğe başvurur.
    ///
    /// Ortaya çıkan yaşam süresi kendine bağlıdır, bu nedenle bu "as if" gibi davranır, aslında ödünç alınan bir T örneğidir.
    /// Daha uzun bir (unbound) ömrü gerekiyorsa, `&*my_ptr.as_ptr()` kullanın.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // GÜVENLİK: Arayan kişi, `self` in tüm gereksinimleri karşıladığını garanti etmelidir.
        // referans için gereklilikler.
        unsafe { &*self.as_ptr() }
    }

    /// İçeriği mutabık bir şekilde kaldırır.
    ///
    /// Ortaya çıkan yaşam süresi kendine bağlıdır, bu nedenle bu "as if" gibi davranır, aslında ödünç alınan bir T örneğidir.
    /// Daha uzun bir (unbound) ömrü gerekiyorsa, `&mut *my_ptr.as_ptr()` kullanın.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // GÜVENLİK: Arayan kişi, `self` in tüm gereksinimleri karşıladığını garanti etmelidir.
        // değişebilir bir referans için gereksinimler.
        unsafe { &mut *self.as_ptr() }
    }

    /// Başka türden bir işaretçiye çevirir.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // GÜVENLİK: Unique::new_unchecked() yeni bir benzersiz ve ihtiyaçlar yaratır
        // verilen işaretçi boş olmamalıdır.
        // Kendimizi bir işaretçi olarak geçirdiğimiz için boş olamaz.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // GÜVENLİK: Değişebilir bir referans boş olamaz
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}