//! Karakter dönüşümleri.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` i `char` e dönüştürür.
///
/// Tüm [`char`] ların geçerli ["u32`] lerin olduğunu ve bunlardan birine dönüştürülebileceğini unutmayın.
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Ancak, bunun tersi doğru değildir: geçerli ["u32" lerin tümü geçerli ["char"] değildir.
/// `from_u32()` giriş bir [`char`] için geçerli bir değer değilse `None` i döndürecektir.
///
/// Bu kontrolleri göz ardı eden bu işlevin güvenli olmayan bir sürümü için, bkz. [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Giriş geçerli bir [`char`] olmadığında `None` döndürülüyor:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Geçerliliği yok sayarak `u32` i `char` e dönüştürür.
///
/// Tüm [`char`] ların geçerli ["u32`] lerin olduğunu ve bunlardan birine dönüştürülebileceğini unutmayın.
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Ancak, bunun tersi doğru değildir: geçerli ["u32" lerin tümü geçerli ["char"] değildir.
/// `from_u32_unchecked()` bunu göz ardı edecek ve [`char`] e körü körüne atacak, muhtemelen geçersiz bir tane oluşturacaktır.
///
///
/// # Safety
///
/// Bu işlev, geçersiz `char` değerleri oluşturabileceğinden güvenli değildir.
///
/// Bu işlevin güvenli bir sürümü için [`from_u32`] işlevine bakın.
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // GÜVENLİK: Arayan, `i` in geçerli bir karakter değeri olduğunu garanti etmelidir.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] i [`u32`] e dönüştürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] i [`u64`] e dönüştürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Karakter, kod noktasının değerine dönüştürülür, ardından sıfırdan 64 bit'e genişletilir.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] e bakın
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] i [`u128`] e dönüştürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Karakter, kod noktasının değerine dönüştürülür, ardından sıfırdan 128 bit'e genişletilir.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] e bakın
        c as u128
    }
}

/// U + 0000 ..=U + 00FF'de kod noktası aynı değere sahip bir `char` e 0x00 ..=0xFF baytını eşler.
///
/// Unicode, IANA'nın ISO-8859-1 olarak adlandırdığı karakter kodlamasıyla baytların şifresini etkili bir şekilde çözecek şekilde tasarlanmıştır.
/// Bu kodlama ASCII ile uyumludur.
///
/// Bunun ISO/IEC 8859-1 aka'den farklı olduğunu unutmayın.
/// Herhangi bir karaktere atanmamış bazı "blanks" bayt değerlerini bırakan ISO 8859-1 (bir kısa çizgisiz).
/// ISO-8859-1 (IANA biri) bunları C0 ve C1 kontrol kodlarına atar.
///
/// Bunun Windows-1252'den *aynı zamanda* farklı olduğunu unutmayın.
/// kod sayfası 1252, noktalama işaretlerine ve çeşitli Latin karakterlerine bazı (tümü değil!) boşluklar atayan bir üst kümedir.
///
/// İşleri daha da karıştırmak için, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` ve `windows-1252`, kalan boşlukları karşılık gelen C0 ve C1 kontrol kodlarıyla dolduran bir Windows-1252 üst kümesinin takma adlarıdır.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] i [`char`] e dönüştürür.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Bir karakter ayrıştırılırken döndürülebilecek bir hata.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // GÜVENLİK: yasal bir unicode değeri olup olmadığını kontrol etti
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32 ten char'a dönüştürme başarısız olduğunda hata türü döndürüldü.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Verilen tabandaki bir rakamı `char` e dönüştürür.
///
/// Buradaki bir 'radix' bazen 'base' olarak da adlandırılır.
/// İkili bir sayı, bazı ortak değerler vermek için ikili bir sayıyı, onluk bir tabanı, ondalık bir tabanı ve on altılık bir tabanı, onaltılık bir tabloyu gösterir.
///
/// Keyfi radikaller desteklenmektedir.
///
/// `from_digit()` giriş verilen tabanda bir rakam değilse `None` i döndürecektir.
///
/// # Panics
///
/// Panics 36'dan daha büyük bir radix verilirse.
///
/// # Examples
///
/// Temel kullanım:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Ondalık 11, 16 tabanındaki tek rakamdır
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Giriş bir rakam olmadığında `None` in döndürülmesi:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Büyük bir tabanı geçerek bir panic'ye neden olur:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}