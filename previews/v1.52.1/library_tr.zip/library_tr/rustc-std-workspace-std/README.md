# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate belgelerine bakın.