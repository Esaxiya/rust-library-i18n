// All `str` tests live in liballoc/tests
