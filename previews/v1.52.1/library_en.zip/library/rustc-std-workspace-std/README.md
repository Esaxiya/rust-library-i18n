# The `rustc-std-workspace-std` crate

See documentation for the `rustc-std-workspace-core` crate.
