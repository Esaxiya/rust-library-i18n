//! crates.io இல் `gimli` crate ஐப் பயன்படுத்தி குறியீட்டுக்கான ஆதரவு
//!
//! இது Rust க்கான இயல்புநிலை குறியீட்டு செயல்படுத்தலாகும்.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'நிலையான வாழ்நாள் என்பது சுய-குறிப்பு கட்டமைப்புகளுக்கு ஆதரவு இல்லாததை ஹேக் செய்வதற்கான பொய்.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // சின்னங்கள் `map` மற்றும் `stash` ஐ மட்டுமே கடன் வாங்க வேண்டும் என்பதால் அவற்றை 'நிலையான வாழ்நாளாக மாற்றவும், அவற்றை நாங்கள் கீழே பாதுகாக்கிறோம்.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows இல் சொந்த நூலகங்களை ஏற்றுவதற்கு, இங்குள்ள பல்வேறு உத்திகளுக்கு rust-lang/rust#71060 இல் சில விவாதங்களைக் காண்க.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW நூலகங்கள் தற்போது ASLR (rust-lang/rust#16514) ஐ ஆதரிக்கவில்லை, ஆனால் DLL களை இன்னும் முகவரி இடத்தில் இடமாற்றம் செய்யலாம்.
            // பிழைத்திருத்த தகவலில் உள்ள முகவரிகள் அனைத்தும் இந்த நூலகம் அதன் "image base" இல் ஏற்றப்பட்டிருந்தால், அது அதன் COFF கோப்பு தலைப்புகளில் உள்ள ஒரு புலமாகும்.
            // பிழைத்திருத்தம் பட்டியலிடுவது இதுதான் என்பதால், குறியீட்டு அட்டவணை மற்றும் ஸ்டோர் முகவரிகளை அலசுவோம், நூலகம் "image base" இல் ஏற்றப்பட்டதைப் போல.
            //
            // இருப்பினும், நூலகம் "image base" இல் ஏற்றப்படாமல் போகலாம்.
            // (மறைமுகமாக வேறு ஏதேனும் அங்கே ஏற்றப்படலாமா?) இங்குதான் `bias` புலம் செயல்பாட்டுக்கு வருகிறது, மேலும் இங்கே `bias` இன் மதிப்பைக் கண்டுபிடிக்க வேண்டும்.துரதிர்ஷ்டவசமாக ஏற்றப்பட்ட தொகுதியிலிருந்து இதை எவ்வாறு பெறுவது என்பது தெளிவாகத் தெரியவில்லை.
            // எவ்வாறாயினும், நம்மிடம் இருப்பது உண்மையான சுமை முகவரி (`modBaseAddr`) ஆகும்.
            //
            // இப்போது ஒரு காப்-அவுட்டாக, நாங்கள் கோப்பை எம்மாப் செய்கிறோம், கோப்பு தலைப்பு தகவலைப் படித்து, பின்னர் எம்.எம்.பி.இது வீணானது, ஏனென்றால் நாங்கள் பின்னர் எம்மாப்பை மீண்டும் திறப்போம், ஆனால் இது இப்போது போதுமானதாக இருக்கும்.
            //
            // எங்களிடம் `image_base` (விரும்பிய சுமை இருப்பிடம்) மற்றும் `base_addr` (உண்மையான சுமை இருப்பிடம்) கிடைத்தவுடன் நாம் `bias` ஐ நிரப்பலாம் (உண்மையான மற்றும் விரும்பியவற்றுக்கு இடையேயான வேறுபாடு), பின்னர் ஒவ்வொரு பிரிவின் கூறப்பட்ட முகவரி `image_base` ஆகும், ஏனெனில் அது கோப்பு கூறுகிறது.
            //
            //
            // இப்போது ELF/MachO ஐப் போலல்லாமல், ஒரு நூலகத்திற்கு ஒரு பிரிவைச் செய்யலாம், `modBaseSize` ஐ முழு அளவாகப் பயன்படுத்தலாம்.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS மாக்-ஓ கோப்பு வடிவமைப்பைப் பயன்படுத்துகிறது மற்றும் பயன்பாட்டின் ஒரு பகுதியாக இருக்கும் சொந்த நூலகங்களின் பட்டியலை ஏற்ற DYLD-குறிப்பிட்ட API களைப் பயன்படுத்துகிறது.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // இந்த நூலகத்தின் பெயரைப் பெறுங்கள், அதை எங்கு ஏற்ற வேண்டும் என்பதற்கான பாதைக்கு ஒத்திருக்கிறது.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // இந்த நூலகத்தின் படத் தலைப்பை ஏற்றவும் மற்றும் அனைத்து சுமை கட்டளைகளையும் அலசுவதற்கு `object` க்கு பிரதிநிதித்துவம் செய்யவும், எனவே இங்கே சம்பந்தப்பட்ட அனைத்து பிரிவுகளையும் நாம் கண்டுபிடிக்க முடியும்.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // பிரிவுகளைக் கண்டறிந்து, நாம் கண்டறிந்த பகுதிகளுக்கு தெரிந்த பகுதிகளை பதிவுசெய்க.
            // பின்னர் செயலாக்கத்திற்கான தகவல்களைப் பதிவுசெய்தல், கீழே உள்ள கருத்துகளைப் பார்க்கவும்.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // இந்த நூலகத்திற்கான "slide" ஐத் தீர்மானித்தல், இது நினைவகப் பொருள்களில் எங்கு ஏற்றப்படுகிறது என்பதைக் கண்டுபிடிக்க நாம் பயன்படுத்தும் சார்புடையதாக முடிகிறது.
            // இது ஒரு வித்தியாசமான கணக்கீடு என்றாலும், காடுகளில் சில விஷயங்களை முயற்சித்து, என்ன குச்சிகளைப் பார்க்கிறது என்பதன் விளைவாகும்.
            //
            // பொதுவான யோசனை என்னவென்றால், `bias` மற்றும் ஒரு பிரிவின் `stated_virtual_memory_address` என்பது உண்மையான முகவரி இடத்தில் அந்த பிரிவு வசிக்கும் இடமாக இருக்கும்.
            // நாம் நம்பியிருக்கும் மற்றொரு விஷயம் என்னவென்றால், `bias` க்கு ஒரு உண்மையான முகவரி மைனஸ் என்பது குறியீட்டு அட்டவணை மற்றும் பிழைத்திருத்தத்தில் பார்க்க வேண்டிய குறியீடாகும்.
            //
            // இருப்பினும், கணினி ஏற்றப்பட்ட நூலகங்களுக்கு இந்த கணக்கீடுகள் தவறானவை என்று மாறிவிடும்.இருப்பினும், சொந்த இயங்கக்கூடியவர்களுக்கு இது சரியாகத் தெரிகிறது.
            // எல்.எல்.டி.பியின் மூலத்திலிருந்து சில தர்க்கங்களைத் தூக்கினால், கோப்பு ஆஃப்செட் 0 இலிருந்து ஏற்றப்படாத முதல் எக்ஸ் 100 எக்ஸ் பிரிவுக்கு சில சிறப்பு-உறை உள்ளது.
            // இது இருக்கும்போது எந்த காரணத்திற்காகவும் குறியீட்டு அட்டவணை நூலகத்திற்கான vmaddr ஸ்லைடோடு தொடர்புடையது என்று அர்த்தம்.
            // இது *இல்லாவிட்டால்* குறியீட்டு அட்டவணை vmaddr ஸ்லைடு மற்றும் பிரிவின் கூறப்பட்ட முகவரிக்கு தொடர்புடையது.
            //
            // கோப்பு ஆஃப்செட் பூஜ்ஜியத்தில் ஒரு உரை பகுதியை நாம் * கண்டுபிடிக்கவில்லை எனில், இந்த சூழ்நிலையை கையாள, முதல் உரை பிரிவுகளின் கூறப்பட்ட முகவரியால் சார்புகளை அதிகரிக்கிறோம், மேலும் அந்த அளவு மூலம் அனைத்து முகவரிகளையும் குறைக்கிறோம்.
            //
            // அந்த வகையில் குறியீட்டு அட்டவணை எப்போதும் நூலகத்தின் சார்புத் தொகையுடன் தோன்றும்.
            // குறியீட்டு அட்டவணை வழியாக குறியீட்டுக்கு இது சரியான முடிவுகளைக் கொண்டிருப்பதாகத் தெரிகிறது.
            //
            // நேர்மையாக இது சரியானதா அல்லது இதை எப்படி செய்வது என்பதைக் குறிக்கும் வேறு ஏதாவது இருந்தால் எனக்கு முழுமையாகத் தெரியவில்லை.
            // இப்போதைக்கு இது போதுமான அளவு (?) வேலை செய்வதாகத் தோன்றினாலும், தேவைப்பட்டால் காலப்போக்கில் இதை எப்போதும் மாற்றியமைக்க முடியும்.
            //
            // மேலும் சில தகவல்களுக்கு #318 ஐப் பார்க்கவும்
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // பிற Unix (எ.கா.
        // லினக்ஸ்) இயங்குதளங்கள் ELF ஐ ஒரு பொருள் கோப்பு வடிவமாகப் பயன்படுத்துகின்றன மற்றும் பொதுவாக சொந்த நூலகங்களை ஏற்ற `dl_iterate_phdr` எனப்படும் API ஐ செயல்படுத்துகின்றன.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` சரியான சுட்டிகள் இருக்க வேண்டும்.
        // `vec` `std::Vec` க்கு சரியான சுட்டிக்காட்டி இருக்க வேண்டும்.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 பிழைத்திருத்த தகவலை இயல்பாக ஆதரிக்காது, ஆனால் உருவாக்க அமைப்பு `romfs:/debug_info.elf` பாதையில் பிழைத்திருத்த தகவலை வைக்கும்.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // எல்லாவற்றையும் ELF ஐப் பயன்படுத்த வேண்டும், ஆனால் சொந்த நூலகங்களை எவ்வாறு ஏற்றுவது என்று தெரியவில்லை.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// ஏற்றப்பட்ட அனைத்து அறியப்பட்ட பகிரப்பட்ட நூலகங்களும்.
    libraries: Vec<Library>,

    /// பாகுபடுத்தப்பட்ட குள்ள தகவல்களை நாங்கள் வைத்திருக்கும் மேப்பிங் கேச்.
    ///
    /// இந்த பட்டியலில் அதன் முழு ஆயுட்காலம் ஒரு நிலையான திறன் உள்ளது, அது ஒருபோதும் அதிகரிக்காது.
    /// ஒவ்வொரு ஜோடியின் `usize` உறுப்பு `libraries` க்கு மேலே உள்ள ஒரு குறியீடாகும், அங்கு `usize::max_value()` தற்போதைய இயங்கக்கூடியதைக் குறிக்கிறது.
    ///
    /// `Mapping` என்பது பாகுபடுத்தப்பட்ட குள்ள தகவல்.
    ///
    /// இது அடிப்படையில் ஒரு எல்.ஆர்.யூ கேச் என்பதை நினைவில் கொள்க, நாங்கள் முகவரிகளை அடையாளப்படுத்துவதால் விஷயங்களை இங்கு மாற்றுவோம்.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// இந்த நூலகத்தின் பகுதிகள் நினைவகத்தில் ஏற்றப்படுகின்றன, அவை எங்கு ஏற்றப்படுகின்றன.
    segments: Vec<LibrarySegment>,
    /// இந்த நூலகத்தின் "bias", பொதுவாக நினைவகத்தில் ஏற்றப்படும் இடத்தில்.
    /// பிரிவு ஏற்றப்பட்ட உண்மையான மெய்நிகர் நினைவக முகவரியைப் பெற ஒவ்வொரு பிரிவின் கூறப்பட்ட முகவரிக்கும் இந்த மதிப்பு சேர்க்கப்படுகிறது.
    /// கூடுதலாக, இந்த சார்பு உண்மையான மெய்நிகர் நினைவக முகவரிகளிலிருந்து குறியீட்டுக்கு பிழைத்திருத்தம் மற்றும் குறியீட்டு அட்டவணையில் கழிக்கப்படுகிறது.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// பொருள் கோப்பில் இந்த பிரிவின் குறிப்பிடப்பட்ட முகவரி.
    /// இது உண்மையில் பிரிவு ஏற்றப்பட்ட இடமல்ல, மாறாக இந்த முகவரி மற்றும் நூலகத்தின் `bias` ஆகியவற்றைக் கொண்ட இடமாகும்.
    ///
    stated_virtual_memory_address: usize,
    /// நினைவகத்தில் ths பிரிவின் அளவு.
    len: usize,
}

// பாதுகாப்பற்றது ஏனெனில் இது வெளிப்புறமாக ஒத்திசைக்கப்பட வேண்டும்
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // பாதுகாப்பற்றது ஏனெனில் இது வெளிப்புறமாக ஒத்திசைக்கப்பட வேண்டும்
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // பிழைத்திருத்த தகவல் மேப்பிங்கிற்கான மிகச் சிறிய, மிக எளிய எல்.ஆர்.யூ கேச்.
        //
        // பகிர்வு நூலகங்களுக்கு இடையில் வழக்கமான அடுக்கு கடக்காததால், வெற்றி விகிதம் மிக அதிகமாக இருக்க வேண்டும்.
        //
        // `addr2line::Context` கட்டமைப்புகள் உருவாக்க மிகவும் விலை உயர்ந்தவை.
        // அதன் செலவு அடுத்தடுத்த `locate` வினவல்களால் மன்னிப்பு பெறும் என்று எதிர்பார்க்கப்படுகிறது, இது `addr2line: : சூழலை` கட்டமைக்கும்போது கட்டமைக்கப்பட்ட கட்டமைப்புகளை மேம்படுத்துகிறது.
        //
        // எங்களிடம் இந்த கேச் இல்லையென்றால், அந்த கடன்தொகுப்பு ஒருபோதும் நடக்காது, மேலும் பின்னணிகளை அடையாளப்படுத்துவது ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // முதலில், இந்த `lib` இல் `addr` (இடமாற்றத்தைக் கையாளுதல்) கொண்ட ஏதேனும் பிரிவு இருக்கிறதா என்று சோதிக்கவும்.இந்த காசோலை கடந்து சென்றால், நாம் கீழே தொடரலாம் மற்றும் உண்மையில் முகவரியை மொழிபெயர்க்கலாம்.
                //
                // வழிதல் சோதனைகளைத் தவிர்க்க நாங்கள் இங்கே `wrapping_add` ஐப் பயன்படுத்துகிறோம் என்பதை நினைவில் கொள்க.எஸ்.வி.எம்.ஏ + சார்பு கணக்கீடு நிரம்பி வழிகிறது என்பது வனப்பகுதியில் காணப்படுகிறது.
                // இது நடப்பது சற்று வித்தியாசமாகத் தெரிகிறது, ஆனால் அந்த பகுதிகளை புறக்கணிப்பதைத் தவிர வேறு எதையும் நாம் செய்ய முடியாது, ஏனெனில் அவை விண்வெளியில் சுட்டிக்காட்டுகின்றன.
                //
                // இது முதலில் rust-lang/backtrace-rs#329 இல் வந்தது.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // இப்போது `lib` இல் `addr` உள்ளது என்பது எங்களுக்குத் தெரியும், கூறப்பட்ட வைரட்டல் நினைவக முகவரியைக் கண்டுபிடிக்க ஒரு சார்புடன் ஈடுசெய்யலாம்.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // மாறாதது: இந்த நிபந்தனை முன்கூட்டியே திரும்பாமல் முடிந்த பிறகு
        // பிழையில் இருந்து, இந்த பாதைக்கான கேச் நுழைவு குறியீட்டு 0 இல் உள்ளது.

        if let Some(idx) = idx {
            // மேப்பிங் ஏற்கனவே தற்காலிக சேமிப்பில் இருக்கும்போது, அதை முன் நோக்கி நகர்த்தவும்.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // மேப்பிங் தற்காலிக சேமிப்பில் இல்லாதபோது, ஒரு புதிய மேப்பிங்கை உருவாக்கி, அதை தற்காலிக சேமிப்பின் முன் செருகவும், தேவைப்பட்டால் மிகப் பழைய கேச் உள்ளீட்டை வெளியேற்றவும்.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` வாழ்நாளை கசியவிடாதீர்கள், அது நமக்குத்தான் என்பதை உறுதிப்படுத்திக் கொள்ளுங்கள்
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // துரதிர்ஷ்டவசமாக இங்கு தேவைப்படுவதால் `sym` இன் வாழ்நாளை `'static` ஆக நீட்டிக்கவும், ஆனால் இது எப்போதும் ஒரு குறிப்பாக வெளியேறுகிறது, எனவே இது குறித்த எந்த குறிப்பும் இந்த சட்டகத்திற்கு அப்பால் தொடர்ந்து இருக்கக்கூடாது.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // இறுதியாக, தற்காலிக சேமிப்பு வரைபடத்தைப் பெறுங்கள் அல்லது இந்தக் கோப்பிற்கான புதிய மேப்பிங்கை உருவாக்கவும், இந்த முகவரிக்கான file/line/name ஐக் கண்டறிய DWARF தகவலை மதிப்பீடு செய்யவும்.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// இந்த சின்னத்திற்கான பிரேம் தகவல்களை எங்களால் கண்டுபிடிக்க முடிந்தது, மேலும் `addr2line` இன் சட்டகம் உள்நாட்டில் அனைத்து அபாயகரமான விவரங்களையும் கொண்டுள்ளது.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// பிழைத்திருத்த தகவலைக் கண்டுபிடிக்க முடியவில்லை, ஆனால் அதை இயங்கக்கூடிய குறியீட்டு அட்டவணையில் கண்டறிந்தோம்.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}