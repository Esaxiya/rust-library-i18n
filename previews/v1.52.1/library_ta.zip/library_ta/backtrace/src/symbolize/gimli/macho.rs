use super::{Box, Context, Mapping, Path, Stash, Vec};
use core::convert::TryInto;
use object::macho;
use object::read::macho::{MachHeader, Nlist, Section, Segment as _};
use object::{Bytes, NativeEndian};

#[cfg(target_pointer_width = "32")]
type Mach = object::macho::MachHeader32<NativeEndian>;
#[cfg(target_pointer_width = "64")]
type Mach = object::macho::MachHeader64<NativeEndian>;
type MachSegment = <Mach as MachHeader>::Segment;
type MachSection = <Mach as MachHeader>::Section;
type MachNlist = <Mach as MachHeader>::Nlist;

impl Mapping {
    // OSX க்கான ஏற்றுதல் பாதை மிகவும் வித்தியாசமானது, இங்கே செயல்பாட்டை முற்றிலும் வேறுபட்ட செயல்படுத்துகிறோம்.
    // OSX இல் நாம் ஒரு சில கோப்புகளுக்கான கோப்பு முறைமையை ஆராய வேண்டும்.
    //
    pub fn new(path: &Path) -> Option<Mapping> {
        // முதலில் நாம் படிக்கும் கோப்பின் மச்சோ தலைப்பில் `path` இல் குறிப்பிடப்பட்டுள்ள தனித்துவமான UUID ஐ ஏற்ற வேண்டும்.
        //
        let map = super::mmap(path)?;
        let (macho, data) = find_header(Bytes(&map))?;
        let endian = macho.endian().ok()?;
        let uuid = macho.uuid(endian, data).ok()??;

        // அடுத்து நாம் ஒரு `*.dSYM` கோப்பைத் தேட வேண்டும்.இப்போது நாம் கொண்டிருக்கும் கோப்பகத்தை ஆராய்ந்து, `*.dSYM` உடன் பொருந்தக்கூடிய ஒன்றைத் தேடுகிறோம்.
        // அது கிடைத்தவுடன், அதில் உள்ள குள்ள வளங்களை நாம் வேரூன்றி, எங்கள் சொந்த கோப்புகளில் ஒன்றாக பொருந்தக்கூடிய UUID ஐக் கொண்ட ஒரு மச்சோ கோப்பைக் கண்டுபிடிக்க முயற்சிக்கிறோம்.
        //
        // ஒரு பொருத்தத்தை நாங்கள் கண்டால், அது குள்ளக் கோப்பு.
        //
        //
        if let Some(parent) = path.parent() {
            if let Some(mapping) = Mapping::load_dsym(parent, uuid) {
                return Some(mapping);
            }
        }

        // எங்கள் UUID உடன் எதுவும் பொருந்தவில்லை என்று தெரிகிறது, எனவே குறைந்தபட்சம் எங்கள் சொந்த கோப்பை திருப்பித் தருவோம்.
        // குறைந்தது சில குறியீட்டு நோக்கங்களுக்காக இது குறியீட்டு அட்டவணையைக் கொண்டிருக்க வேண்டும்.
        //
        Mapping::mk(map, |data, stash| {
            let (macho, data) = find_header(Bytes(data))?;
            let endian = macho.endian().ok()?;
            let obj = Object::parse(macho, endian, data)?;
            Context::new(stash, obj)
        })
    }

    fn load_dsym(dir: &Path, uuid: [u8; 16]) -> Option<Mapping> {
        for entry in dir.read_dir().ok()? {
            let entry = entry.ok()?;
            let filename = match entry.file_name().into_string() {
                Ok(name) => name,
                Err(_) => continue,
            };
            if !filename.ends_with(".dSYM") {
                continue;
            }
            let candidates = entry.path().join("Contents/Resources/DWARF");
            if let Some(mapping) = Mapping::try_dsym_candidate(&candidates, uuid) {
                return Some(mapping);
            }
        }
        None
    }

    fn try_dsym_candidate(dir: &Path, uuid: [u8; 16]) -> Option<Mapping> {
        // `DWARF` கோப்பகத்தில் உள்ள கோப்புகளைத் தேடுங்கள், அவை அசல் பொருள் கோப்போடு பொருந்தக்கூடிய uuid ஐக் கொண்டுள்ளன.
        // ஒன்றைக் கண்டால் பிழைத்திருத்த தகவலைக் கண்டறிந்தோம்.
        //
        for entry in dir.read_dir().ok()? {
            let entry = entry.ok()?;
            let map = super::mmap(&entry.path())?;
            let candidate = Mapping::mk(map, |data, stash| {
                let (macho, data) = find_header(Bytes(data))?;
                let endian = macho.endian().ok()?;
                let entry_uuid = macho.uuid(endian, data).ok()??;
                if entry_uuid != uuid {
                    return None;
                }
                let obj = Object::parse(macho, endian, data)?;
                Context::new(stash, obj)
            });
            if let Some(candidate) = candidate {
                return Some(candidate);
            }
        }

        None
    }
}

fn find_header(mut data: Bytes<'_>) -> Option<(&'_ Mach, Bytes<'_>)> {
    use object::endian::BigEndian;

    let desired_cpu = || {
        if cfg!(target_arch = "x86") {
            Some(macho::CPU_TYPE_X86)
        } else if cfg!(target_arch = "x86_64") {
            Some(macho::CPU_TYPE_X86_64)
        } else if cfg!(target_arch = "arm") {
            Some(macho::CPU_TYPE_ARM)
        } else if cfg!(target_arch = "aarch64") {
            Some(macho::CPU_TYPE_ARM64)
        } else {
            None
        }
    };

    match data
        .clone()
        .read::<object::endian::U32<NativeEndian>>()
        .ok()?
        .get(NativeEndian)
    {
        macho::MH_MAGIC_64 | macho::MH_CIGAM_64 | macho::MH_MAGIC | macho::MH_CIGAM => {}

        macho::FAT_MAGIC | macho::FAT_CIGAM => {
            let mut header_data = data;
            let endian = BigEndian;
            let header = header_data.read::<macho::FatHeader>().ok()?;
            let nfat = header.nfat_arch.get(endian);
            let arch = (0..nfat)
                .filter_map(|_| header_data.read::<macho::FatArch32>().ok())
                .find(|arch| desired_cpu() == Some(arch.cputype.get(endian)))?;
            let offset = arch.offset.get(endian);
            let size = arch.size.get(endian);
            data = data
                .read_bytes_at(offset.try_into().ok()?, size.try_into().ok()?)
                .ok()?;
        }

        macho::FAT_MAGIC_64 | macho::FAT_CIGAM_64 => {
            let mut header_data = data;
            let endian = BigEndian;
            let header = header_data.read::<macho::FatHeader>().ok()?;
            let nfat = header.nfat_arch.get(endian);
            let arch = (0..nfat)
                .filter_map(|_| header_data.read::<macho::FatArch64>().ok())
                .find(|arch| desired_cpu() == Some(arch.cputype.get(endian)))?;
            let offset = arch.offset.get(endian);
            let size = arch.size.get(endian);
            data = data
                .read_bytes_at(offset.try_into().ok()?, size.try_into().ok()?)
                .ok()?;
        }

        _ => return None,
    }

    Mach::parse(data).ok().map(|h| (h, data))
}

// இது executables/libraries மற்றும் மூல பொருள் கோப்புகளுக்கு பயன்படுத்தப்படுகிறது.
pub struct Object<'a> {
    endian: NativeEndian,
    data: Bytes<'a>,
    dwarf: Option<&'a [MachSection]>,
    syms: Vec<(&'a [u8], u64)>,
    syms_sort_by_name: bool,
    // executables/libraries க்கு மட்டுமே அமைக்கவும், மூல பொருள் கோப்புகள் அல்ல.
    object_map: Option<object::ObjectMap<'a>>,
    // வெளிப்புற விருப்பம் சோம்பேறி ஏற்றுதலுக்கானது, மேலும் உள் விருப்பம் சுமை பிழைகளை தற்காலிகமாக சேமிக்க அனுமதிக்கிறது.
    object_mappings: Box<[Option<Option<Mapping>>]>,
}

impl<'a> Object<'a> {
    fn parse(mach: &'a Mach, endian: NativeEndian, data: Bytes<'a>) -> Option<Object<'a>> {
        let is_object = mach.filetype(endian) == object::macho::MH_OBJECT;
        let mut dwarf = None;
        let mut syms = Vec::new();
        let mut syms_sort_by_name = false;
        let mut commands = mach.load_commands(endian, data).ok()?;
        let mut object_map = None;
        let mut object_mappings = Vec::new();
        while let Ok(Some(command)) = commands.next() {
            if let Some((segment, section_data)) = MachSegment::from_command(command).ok()? {
                // பொருள் கோப்புகளில் பெயரிடப்படாத பிரிவு சுமை கட்டளையில் அனைத்து பிரிவுகளும் இருக்க வேண்டும்.
                if segment.name() == b"__DWARF" || (is_object && segment.name() == b"") {
                    dwarf = segment.sections(endian, section_data).ok();
                }
            } else if let Some(symtab) = command.symtab().ok()? {
                let symbols = symtab.symbols::<Mach>(endian, data).ok()?;
                syms = symbols
                    .iter()
                    .filter_map(|nlist: &MachNlist| {
                        let name = nlist.name(endian, symbols.strings()).ok()?;
                        if name.len() > 0 && nlist.is_definition() {
                            Some((name, u64::from(nlist.n_value(endian))))
                        } else {
                            None
                        }
                    })
                    .collect();
                if is_object {
                    // பொருள் கோப்பு சின்னங்களை நாங்கள் ஒருபோதும் முகவரி மூலம் தேட மாட்டோம்.
                    // அதற்கு பதிலாக, இயங்கக்கூடியவரிடமிருந்து குறியீட்டு பெயரை நாங்கள் ஏற்கனவே அறிவோம், மேலும் பொருளின் கோப்பில் பொருந்தும் சின்னத்தைக் கண்டுபிடிக்க பெயரால் தேட வேண்டும்.
                    //
                    syms.sort_unstable_by_key(|(name, _)| *name);
                    syms_sort_by_name = true;
                } else {
                    syms.sort_unstable_by_key(|(_, addr)| *addr);
                    let map = symbols.object_map(endian);
                    object_mappings.resize_with(map.objects().len(), || None);
                    object_map = Some(map);
                }
            }
        }

        Some(Object {
            endian,
            data,
            dwarf,
            syms,
            syms_sort_by_name,
            object_map,
            object_mappings: object_mappings.into_boxed_slice(),
        })
    }

    pub fn section(&self, _: &Stash, name: &str) -> Option<&'a [u8]> {
        let name = name.as_bytes();
        let dwarf = self.dwarf?;
        let section = dwarf.into_iter().find(|section| {
            let section_name = section.name();
            section_name == name || {
                section_name.starts_with(b"__")
                    && name.starts_with(b".")
                    && &section_name[2..] == &name[1..]
            }
        })?;
        Some(section.data(self.endian, self.data).ok()?.0)
    }

    pub fn search_symtab<'b>(&'b self, addr: u64) -> Option<&'b [u8]> {
        debug_assert!(!self.syms_sort_by_name);
        let i = match self.syms.binary_search_by_key(&addr, |(_, addr)| *addr) {
            Ok(i) => i,
            Err(i) => i.checked_sub(1)?,
        };
        let (sym, _addr) = self.syms.get(i)?;
        Some(sym)
    }

    /// பொருள் கோப்பிற்கான சூழலை ஏற்ற முயற்சிக்கவும்.
    ///
    /// Dsymutil இயங்கவில்லை என்றால், DWARF மூல பொருள் கோப்புகளில் காணப்படலாம்.
    pub(super) fn search_object_map<'b>(&'b mut self, addr: u64) -> Option<(&Context<'b>, u64)> {
        // `object_map` முகவரிகளிலிருந்து சின்னங்கள் மற்றும் பொருள் பாதைகளுக்கு ஒரு வரைபடத்தைக் கொண்டுள்ளது.
        // முகவரியைப் பார்த்து, பொருளுக்கு ஒரு மேப்பிங் கிடைக்கும்.
        let object_map = self.object_map.as_ref()?;
        let symbol = object_map.get(addr)?;
        let object_index = symbol.object_index();
        let mapping = self.object_mappings.get_mut(object_index)?;
        if mapping.is_none() {
            // தற்காலிக சேமிப்பில் இல்லை, எனவே அதை உருவாக்கவும்.
            *mapping = Some(object_mapping(object_map.objects().get(object_index)?));
        }
        let cx: &'b Context<'static> = &mapping.as_ref()?.as_ref()?.cx;
        // `'static` வாழ்நாளை கசியவிடாதீர்கள், அது நமக்குத்தான் என்பதை உறுதிப்படுத்திக் கொள்ளுங்கள்.
        let cx = unsafe { core::mem::transmute::<&'b Context<'static>, &'b Context<'b>>(cx) };

        // பொருள் கோப்பில் உள்ள DWARF இல் அதைப் பார்க்க நாம் முகவரியை மொழிபெயர்க்க வேண்டும்.
        //
        debug_assert!(cx.object.syms.is_empty() || cx.object.syms_sort_by_name);
        let i = cx
            .object
            .syms
            .binary_search_by_key(&symbol.name(), |(name, _)| *name)
            .ok()?;
        let object_symbol = cx.object.syms.get(i)?;
        let object_addr = addr
            .wrapping_sub(symbol.address())
            .wrapping_add(object_symbol.1);
        Some((cx, object_addr))
    }
}

fn object_mapping(path: &[u8]) -> Option<Mapping> {
    use super::mystd::ffi::OsStr;
    use super::mystd::os::unix::prelude::*;

    let map;

    // `N_OSO` குறியீட்டு பெயர்கள் `/path/to/object.o` அல்லது `/path/to/archive.a(object.o)` ஆக இருக்கலாம்.
    let member_name = if let Some((archive_path, member_name)) = split_archive_path(path) {
        map = super::mmap(Path::new(OsStr::from_bytes(archive_path)))?;
        Some(member_name)
    } else {
        map = super::mmap(Path::new(OsStr::from_bytes(path)))?;
        None
    };
    Mapping::mk(map, |data, stash| {
        let data = match member_name {
            Some(member_name) => {
                let archive = object::read::archive::ArchiveFile::parse(data).ok()?;
                let member = archive
                    .members()
                    .filter_map(Result::ok)
                    .find(|m| m.name() == member_name)?;
                Bytes(member.data())
            }
            None => Bytes(data),
        };
        let (macho, data) = find_header(data)?;
        let endian = macho.endian().ok()?;
        let obj = Object::parse(macho, endian, data)?;
        Context::new(stash, obj)
    })
}

fn split_archive_path(path: &[u8]) -> Option<(&[u8], &[u8])> {
    let (last, path) = path.split_last()?;
    if *last != b')' {
        return None;
    }
    let index = path.iter().position(|&x| x == b'(')?;
    let (archive, rest) = path.split_at(index);
    Some((archive, &rest[1..]))
}