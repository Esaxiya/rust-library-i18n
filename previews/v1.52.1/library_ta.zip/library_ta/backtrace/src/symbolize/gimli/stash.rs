// இப்போது Linux இல் மட்டுமே பயன்படுத்தப்படுகிறது, எனவே இறந்த குறியீட்டை வேறு இடத்தில் அனுமதிக்கவும்
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// பைட் இடையகங்களுக்கான எளிய அரங்க ஒதுக்கீடு.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// குறிப்பிட்ட அளவின் இடையகத்தை ஒதுக்குகிறது மற்றும் அதற்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // பாதுகாப்பு: இது எப்போதும் ஒரு மாற்றத்தை உருவாக்கும் ஒரே செயல்பாடு
        // `self.buffers` குறிப்பு.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // பாதுகாப்பு: `self.buffers` இலிருந்து உறுப்புகளை நாங்கள் ஒருபோதும் அகற்ற மாட்டோம், எனவே ஒரு குறிப்பு
        // எந்த இடையகத்திலும் உள்ள தரவு `self` வரை இருக்கும்.
        &mut buffers[i]
    }
}