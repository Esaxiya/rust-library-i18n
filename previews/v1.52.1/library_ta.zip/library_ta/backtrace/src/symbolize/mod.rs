use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// ஒரு குறியீட்டிற்கு ஒரு முகவரியைத் தீர்க்கவும், குறிப்பிட்ட மூடுதலுக்கு சின்னத்தை அனுப்பவும்.
///
/// இந்த செயல்பாடு உள்ளூர் குறியீட்டு அட்டவணை, டைனமிக் குறியீட்டு அட்டவணை அல்லது DWARF பிழைத்திருத்த தகவல் (செயல்படுத்தப்பட்ட செயல்பாட்டைப் பொறுத்து) போன்ற பகுதிகளில் கொடுக்கப்பட்ட முகவரியைக் காண்பிக்கும்.
///
///
/// தெளிவுத்திறனைச் செய்ய முடியாவிட்டால் மூடல் அழைக்கப்படாது, மேலும் சாய்ந்த செயல்பாடுகளின் விஷயத்திலும் இது ஒன்றுக்கு மேற்பட்ட முறை அழைக்கப்படலாம்.
///
/// வழங்கப்பட்ட சின்னங்கள் குறிப்பிட்ட `addr` இல் செயல்படுத்தப்படுவதைக் குறிக்கும், அந்த முகவரிக்கு file/line ஜோடிகளைத் தருகின்றன (கிடைத்தால்).
///
/// உங்களிடம் `Frame` இருந்தால், இதற்கு பதிலாக `resolve_frame` செயல்பாட்டைப் பயன்படுத்த பரிந்துரைக்கப்படுகிறது.
///
/// # தேவையான அம்சங்கள்
///
/// இந்த செயல்பாட்டிற்கு `backtrace` crate இன் `std` அம்சம் இயக்கப்பட வேண்டும், மேலும் `std` அம்சம் இயல்பாக செயல்படுத்தப்படுகிறது.
///
/// # Panics
///
/// இந்த செயல்பாடு ஒருபோதும் panic க்கு பாடுபடாது, ஆனால் `cb` panics ஐ வழங்கினால், சில தளங்கள் இரட்டை panic ஐ செயல்முறையை நிறுத்த கட்டாயப்படுத்தும்.
/// சில இயங்குதளங்கள் ஒரு சி நூலகத்தைப் பயன்படுத்துகின்றன, இது உள்நாட்டில் கால்பேக்குகளைப் பயன்படுத்துகிறது, அவற்றைத் தடுக்க முடியாது, எனவே `cb` இலிருந்து பீதியடைவது ஒரு செயல்முறையைத் தடுக்கக்கூடும்.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // மேல் சட்டகத்தை மட்டும் பாருங்கள்
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// முன்னர் கைப்பற்றப்பட்ட சட்டகத்தை ஒரு குறியீட்டிற்கு தீர்க்கவும், குறிப்பிட்ட மூடுதலுக்கு சின்னத்தை அனுப்பவும்.
///
/// இந்த ஃபங்க்டின் `resolve` இன் அதே செயல்பாட்டை செய்கிறது, தவிர ஒரு முகவரிக்கு பதிலாக ஒரு `Frame` ஐ ஒரு வாதமாக எடுத்துக்கொள்கிறது.
/// இது பின்னிணைப்பின் சில இயங்குதள செயலாக்கங்களை மிகவும் துல்லியமான குறியீட்டு தகவல்களையோ அல்லது இன்லைன் பிரேம்களைப் பற்றிய தகவல்களையோ வழங்க அனுமதிக்கும்.
///
/// உங்களால் முடிந்தால் இதைப் பயன்படுத்த பரிந்துரைக்கப்படுகிறது.
///
/// # தேவையான அம்சங்கள்
///
/// இந்த செயல்பாட்டிற்கு `backtrace` crate இன் `std` அம்சம் இயக்கப்பட வேண்டும், மேலும் `std` அம்சம் இயல்பாக செயல்படுத்தப்படுகிறது.
///
/// # Panics
///
/// இந்த செயல்பாடு ஒருபோதும் panic க்கு பாடுபடாது, ஆனால் `cb` panics ஐ வழங்கினால், சில தளங்கள் இரட்டை panic ஐ செயல்முறையை நிறுத்த கட்டாயப்படுத்தும்.
/// சில இயங்குதளங்கள் ஒரு சி நூலகத்தைப் பயன்படுத்துகின்றன, இது உள்நாட்டில் கால்பேக்குகளைப் பயன்படுத்துகிறது, அவற்றைத் தடுக்க முடியாது, எனவே `cb` இலிருந்து பீதியடைவது ஒரு செயல்முறையைத் தடுக்கக்கூடும்.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // மேல் சட்டகத்தை மட்டும் பாருங்கள்
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// ஸ்டேக் பிரேம்களிலிருந்து ஐபி மதிப்புகள் பொதுவாக எக்ஸ் 00 எக்ஸ் அறிவுறுத்தல் *அழைப்புக்குப் பிறகு* உண்மையான ஸ்டேக் ட்ரேஸ்.
// இதை அடையாளப்படுத்துவதன் மூலம் filename/line எண் ஒன்று முன்னோக்கி இருக்கக்கூடும், மேலும் அது செயல்பாட்டின் முடிவில் இருந்தால் அது வெற்றிடமாக இருக்கும்.
//
// எல்லா தளங்களிலும் இது எப்போதுமே இருக்கும் என்று தோன்றுகிறது, எனவே அறிவுறுத்தலுக்குத் திரும்புவதற்குப் பதிலாக முந்தைய அழைப்பு அறிவுறுத்தலுக்குத் தீர்க்க ஒரு தீர்க்கப்பட்ட ஐபியிலிருந்து ஒன்றை எப்போதும் கழிப்போம்.
//
//
// வெறுமனே நாங்கள் இதை செய்ய மாட்டோம்.
// வெறுமனே இங்கே `resolve` API களின் அழைப்பாளர்கள் -1 ஐ கைமுறையாகச் செய்ய வேண்டும் மற்றும் நடப்பு அல்ல,*முந்தைய* அறிவுறுத்தலுக்கான இருப்பிடத் தகவலை அவர்கள் விரும்புகிறார்கள் என்று கணக்கு வேண்டும்.
// நாம் உண்மையில் அடுத்த அறிவுறுத்தலின் முகவரி அல்லது நடப்பு என்றால் `Frame` ஐயும் அம்பலப்படுத்துவோம்.
//
// இப்போது இது ஒரு அழகான முக்கிய அக்கறை என்றாலும், உள்நாட்டில் எப்போதும் ஒன்றைக் கழிப்போம்.
// நுகர்வோர் தொடர்ந்து வேலை செய்து நல்ல முடிவுகளைப் பெற வேண்டும், எனவே நாம் போதுமானதாக இருக்க வேண்டும்.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` ஐப் போலவே, ஒத்திசைக்கப்படாததால் மட்டுமே பாதுகாப்பற்றது.
///
/// இந்த செயல்பாட்டில் ஒத்திசைவு உத்தரவாதங்கள் இல்லை, ஆனால் இந்த crate இன் `std` அம்சம் தொகுக்கப்படாதபோது கிடைக்கிறது.
/// மேலும் ஆவணங்கள் மற்றும் எடுத்துக்காட்டுகளுக்கு `resolve` செயல்பாட்டைக் காண்க.
///
/// # Panics
///
/// `cb` பீதி குறித்த எச்சரிக்கைகளுக்கு `resolve` பற்றிய தகவலைக் காண்க.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` ஐப் போலவே, ஒத்திசைக்கப்படாததால் மட்டுமே பாதுகாப்பற்றது.
///
/// இந்த செயல்பாட்டில் ஒத்திசைவு உத்தரவாதங்கள் இல்லை, ஆனால் இந்த crate இன் `std` அம்சம் தொகுக்கப்படாதபோது கிடைக்கிறது.
/// மேலும் ஆவணங்கள் மற்றும் எடுத்துக்காட்டுகளுக்கு `resolve_frame` செயல்பாட்டைக் காண்க.
///
/// # Panics
///
/// `cb` பீதி குறித்த எச்சரிக்கைகளுக்கு `resolve_frame` பற்றிய தகவலைக் காண்க.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// ஒரு கோப்பில் ஒரு குறியீட்டின் தீர்மானத்தைக் குறிக்கும் trait.
///
/// இந்த trait ஆனது `backtrace::resolve` செயல்பாட்டிற்கு கொடுக்கப்பட்ட மூடுதலுக்கு trait பொருளாக வழங்கப்படுகிறது, மேலும் இதன் பின்னணியில் எந்த செயல்படுத்தல் உள்ளது என்று தெரியவில்லை என்பதால் இது கிட்டத்தட்ட அனுப்பப்படுகிறது.
///
///
/// ஒரு சின்னம் ஒரு செயல்பாட்டைப் பற்றிய சூழ்நிலை தகவல்களை வழங்க முடியும், எடுத்துக்காட்டாக பெயர், கோப்பு பெயர், வரி எண், துல்லியமான முகவரி போன்றவை.
/// எல்லா தகவல்களும் எப்போதும் ஒரு குறியீட்டில் கிடைக்காது, எனவே எல்லா முறைகளும் ஒரு `Option` ஐத் தருகின்றன.
///
///
pub struct Symbol {
    // TODO: இந்த வாழ்நாள் வரம்பை இறுதியில் `Symbol` வரை தொடர வேண்டும்,
    // ஆனால் அது தற்போது ஒரு முறிவு மாற்றம்.
    // இப்போது இது பாதுகாப்பானது, ஏனெனில் `Symbol` எப்போதுமே குறிப்பால் மட்டுமே வழங்கப்படுகிறது மற்றும் குளோன் செய்ய முடியாது.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// இந்த செயல்பாட்டின் பெயரை வழங்குகிறது.
    ///
    /// குறியீட்டு பெயரைப் பற்றி பல்வேறு பண்புகளை வினவுவதற்கு திரும்பிய கட்டமைப்பைப் பயன்படுத்தலாம்:
    ///
    ///
    /// * `Display` செயல்படுத்தல் செயலிழந்த சின்னத்தை அச்சிடும்.
    /// * சின்னத்தின் மூல `str` மதிப்பை அணுகலாம் (அது செல்லுபடியாகும் utf-8 என்றால்).
    /// * குறியீட்டு பெயருக்கான மூல பைட்டுகளை அணுகலாம்.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// இந்த செயல்பாட்டின் தொடக்க முகவரியை வழங்குகிறது.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// மூல கோப்பு பெயரை ஒரு துண்டாக வழங்குகிறது.
    /// இது முக்கியமாக `no_std` சூழல்களுக்கு பயனுள்ளதாக இருக்கும்.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// இந்த சின்னம் தற்போது இயங்கும் இடத்திற்கு நெடுவரிசை எண்ணை வழங்குகிறது.
    ///
    /// கிம்லி மட்டுமே தற்போது இங்கே ஒரு மதிப்பை வழங்குகிறது, பின்னர் கூட `filename` `Some` ஐ திருப்பி அளித்தால் மட்டுமே, அதனால் அது ஒத்த எச்சரிக்கைகளுக்கு உட்பட்டது.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// இந்த சின்னம் தற்போது இயங்கும் இடத்திற்கு வரி எண்ணை வழங்குகிறது.
    ///
    /// `filename` `Some` ஐ வழங்கினால் இந்த வருவாய் மதிப்பு பொதுவாக `Some` ஆகும், இதன் விளைவாக இதேபோன்ற எச்சரிக்கைகளுக்கு உட்பட்டது.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// இந்த செயல்பாடு வரையறுக்கப்பட்ட கோப்பு பெயரை வழங்குகிறது.
    ///
    /// இது தற்போது libbacktrace அல்லது gimli பயன்படுத்தப்படும்போது மட்டுமே கிடைக்கும் (எ.கா.
    /// unix இயங்குதளங்கள் பிற) மற்றும் ஒரு பைனரி பிழைத்திருத்தத்துடன் தொகுக்கப்படும் போது.
    /// இந்த நிபந்தனைகள் எதுவும் பூர்த்தி செய்யப்படாவிட்டால், இது `None` ஐ வழங்கும்.
    ///
    /// # தேவையான அம்சங்கள்
    ///
    /// இந்த செயல்பாட்டிற்கு `backtrace` crate இன் `std` அம்சம் இயக்கப்பட வேண்டும், மேலும் `std` அம்சம் இயல்பாக செயல்படுத்தப்படுகிறது.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Rust என மாங்கல் செய்யப்பட்ட சின்னத்தை பாகுபடுத்தினால், ஒரு பாகுபடுத்தப்பட்ட C++ சின்னம் இருக்கலாம்.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // இந்த பூஜ்ஜிய அளவை வைத்திருப்பதை உறுதிசெய்து கொள்ளுங்கள், இதனால் `cpp_demangle` அம்சத்தை முடக்கும்போது எந்த செலவும் இருக்காது.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// சிதைக்கப்பட்ட பெயர், மூல பைட்டுகள், மூல சரம் போன்றவற்றுக்கு பணிச்சூழலியல் அணுகல்களை வழங்க ஒரு குறியீட்டு பெயரைச் சுற்றி ஒரு ரேப்பர்.
///
// `cpp_demangle` அம்சம் இயக்கப்படாதபோது இறந்த குறியீட்டை அனுமதிக்கவும்.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// மூல அடிப்படை பைட்டுகளிலிருந்து புதிய குறியீட்டு பெயரை உருவாக்குகிறது.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// சின்னம் செல்லுபடியாகும் utf-8 ஆக இருந்தால், மூல (mangled) குறியீட்டு பெயரை `str` ஆக வழங்குகிறது.
    ///
    /// செயலிழந்த பதிப்பை நீங்கள் விரும்பினால் `Display` செயல்படுத்தலைப் பயன்படுத்தவும்.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// மூல குறியீட்டு பெயரை பைட்டுகளின் பட்டியலாக வழங்குகிறது
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // சிதைக்கப்பட்ட சின்னம் உண்மையில் செல்லுபடியாகாது எனில் இது அச்சிடப்படலாம், எனவே பிழையை வெளிப்புறமாக பிரச்சாரம் செய்யாமல் இங்கே கையாளவும்.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// முகவரிகளை அடையாளப்படுத்த பயன்படும் தற்காலிக சேமிப்பு நினைவகத்தை மீட்டெடுக்கும் முயற்சி.
///
/// இந்த முறை உலகளாவிய ரீதியில் அல்லது தற்காலிகமாக தற்காலிகமாக தற்காலிகமாக தற்காலிகமாக தற்காலிகமாக தற்காலிகமாக தற்காலிகமாக தற்காலிகமாக அல்லது தற்காலிகமாக தற்காலிகமாக தற்காலிகமாக தற்காலிகமாக தற்காலிகமாக தற்காலிகமாக சேமிக்கப்பட்டிருக்கும்.
///
///
/// # Caveats
///
/// இந்த செயல்பாடு எப்போதும் கிடைக்கும்போது, பெரும்பாலான செயலாக்கங்களில் இது உண்மையில் எதையும் செய்யாது.
/// Dbghelp அல்லது libbacktrace போன்ற நூலகங்கள் மாநிலத்தை ஒதுக்குவதற்கும் ஒதுக்கப்பட்ட நினைவகத்தை நிர்வகிப்பதற்கும் வசதிகளை வழங்கவில்லை.
/// இப்போது இந்த crate இன் `gimli-symbolize` அம்சம் இந்த செயல்பாடு எந்த விளைவையும் கொண்ட ஒரே அம்சமாகும்.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}