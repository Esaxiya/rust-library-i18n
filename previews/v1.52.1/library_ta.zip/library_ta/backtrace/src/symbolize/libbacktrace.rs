//! லிப்பேக்ரேஸில் DWARF-பாகுபடுத்தும் குறியீட்டைப் பயன்படுத்தி குறியீட்டு உத்தி.
//!
//! பொதுவாக gcc உடன் விநியோகிக்கப்படும் libbacktrace C நூலகம், ஒரு பின்னணியை உருவாக்குவது மட்டுமல்லாமல் (நாங்கள் உண்மையில் பயன்படுத்தவில்லை) ஆதரிக்கிறது, ஆனால் பின்னிணைப்பை அடையாளப்படுத்துவதோடு, இன்லைன் பிரேம்கள் மற்றும் வாட்நாட் போன்ற விஷயங்களைப் பற்றிய குள்ள பிழைத்திருத்த தகவல்களைக் கையாளுகிறது.
//!
//!
//! இங்கே பல்வேறு கவலைகள் காரணமாக இது மிகவும் சிக்கலானது, ஆனால் அடிப்படை யோசனை:
//!
//! * முதலில் நாம் `backtrace_syminfo` என்று அழைக்கிறோம்.இது நம்மால் முடிந்தால் டைனமிக் சின்ன அட்டவணையில் இருந்து குறியீட்டு தகவலைப் பெறுகிறது.
//! * அடுத்து நாம் `backtrace_pcinfo` என்று அழைக்கிறோம்.இது பிழைத்திருத்த அட்டவணைகள் கிடைத்தால் அவற்றை அலசும் மற்றும் இன்லைன் பிரேம்கள், கோப்பு பெயர்கள், வரி எண்கள் போன்றவற்றைப் பற்றிய தகவல்களை மீட்டெடுக்க அனுமதிக்கும்.
//!
//! குள்ள அட்டவணையை லிப்பேக்ரேஸில் பெறுவது பற்றி நிறைய தந்திரங்கள் உள்ளன, ஆனால் இது உலகின் முடிவு அல்ல, கீழே படிக்கும்போது போதுமான தெளிவு.
//!
//! இது MSVC அல்லாத மற்றும் OSX அல்லாத தளங்களுக்கான இயல்புநிலை குறியீட்டு உத்தி ஆகும்.லிப்ஸ்ட்டில் இது OSX க்கான இயல்புநிலை உத்தி.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // முடிந்தால், பிழைத்திருத்தத்திலிருந்து வரும் `function` பெயரை விரும்பினால், பொதுவாக இன்லைன் பிரேம்களுக்கு இது மிகவும் துல்லியமாக இருக்கும்.
                // அது இல்லாவிட்டால், `symname` இல் குறிப்பிடப்பட்ட குறியீட்டு அட்டவணை பெயருக்குத் திரும்புக.
                //
                // சில நேரங்களில் `function` சற்றே குறைவான துல்லியத்தை உணரக்கூடும் என்பதை நினைவில் கொள்க, எடுத்துக்காட்டாக `try<i32,closure>` `std::panicking::try::do_call` இன் பட்டியலிடப்படவில்லை.
                //
                // ஏன் என்பது உண்மையில் தெளிவாக இல்லை, ஆனால் ஒட்டுமொத்தமாக `function` பெயர் மிகவும் துல்லியமாக தெரிகிறது.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // இப்போது எதுவும் செய்ய வேண்டாம்
}

/// `data` சுட்டிக்காட்டி வகை `syminfo_cb` க்கு அனுப்பப்பட்டது
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // `backtrace_syminfo` இலிருந்து இந்த கால்பேக் செயல்படுத்தப்பட்டவுடன், நாங்கள் தீர்க்கத் தொடங்கும் போது, `backtrace_pcinfo` ஐ அழைக்க மேலும் செல்கிறோம்.
    // `backtrace_pcinfo` செயல்பாடு பிழைத்திருத்த தகவல்களைக் கலந்தாலோசிக்கும் மற்றும் file/line தகவலை மீட்டெடுப்பது மற்றும் இன்லைன் பிரேம்கள் போன்றவற்றைச் செய்ய முயற்சிக்கும்.
    // பிழைத்திருத்த தகவல் இல்லையென்றால் `backtrace_pcinfo` தோல்வியடையும் அல்லது அதிகம் செய்ய முடியாது என்பதை நினைவில் கொள்க, எனவே அது நடந்தால், `syminfo_cb` இலிருந்து குறைந்தபட்சம் ஒரு குறியீட்டையாவது திரும்ப அழைப்பை அழைப்போம்.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` சுட்டிக்காட்டி வகை `pcinfo_cb` க்கு அனுப்பப்பட்டது
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// லிப்பேக்ரேஸ் ஏபிஐ ஒரு மாநிலத்தை உருவாக்குவதை ஆதரிக்கிறது, ஆனால் அது ஒரு மாநிலத்தை அழிப்பதை ஆதரிக்காது.
// நான் தனிப்பட்ட முறையில் இதை எடுத்துக்கொள்வது ஒரு மாநிலத்தை உருவாக்க வேண்டும், பின்னர் என்றென்றும் வாழ வேண்டும் என்பதாகும்.
//
// இந்த நிலையை சுத்தப்படுத்தும் ஒரு at_exit() ஹேண்ட்லரை பதிவு செய்ய நான் விரும்புகிறேன், ஆனால் லிப்பேக்ரேஸ் அவ்வாறு செய்ய எந்த வழியையும் அளிக்காது.
//
// இந்த தடைகளுடன், இந்த செயல்பாடு ஒரு நிலையான தற்காலிக சேமிப்பு நிலையைக் கொண்டுள்ளது, இது முதல் முறையாக கோரப்படும்.
//
// எல்லாவற்றையும் பின்னுக்குத் தள்ளுவது தொடர்ச்சியாக நடக்கிறது என்பதை நினைவில் கொள்ளுங்கள் (ஒரு உலகளாவிய பூட்டு).
//
// இங்கே ஒத்திசைவு இல்லாதது `resolve` வெளிப்புறமாக ஒத்திசைக்கப்பட வேண்டிய தேவை காரணமாக உள்ளது என்பதை நினைவில் கொள்க.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // லிப்பேக்ரேஸின் த்ரெட்ஸேஃப் திறன்களை நாங்கள் எப்போதும் ஒத்திசைக்கப்பட்ட பாணியில் அழைக்கிறோம்.
        //
        0,
        error_cb,
        ptr::null_mut(), // கூடுதல் தரவு இல்லை
    );

    return STATE;

    // லிப்பேக்ரேஸ் இயங்குவதற்கு, தற்போதைய இயங்கக்கூடிய DWARF பிழைத்திருத்த தகவலைக் கண்டுபிடிக்க வேண்டும் என்பதை நினைவில் கொள்க.இது பொதுவாக பல வழிமுறைகள் வழியாக செய்கிறது, ஆனால் இவை மட்டும் அல்ல:
    //
    // * /proc/self/exe ஆதரிக்கப்பட்ட தளங்களில்
    // * நிலையை உருவாக்கும் போது கோப்பு பெயர் வெளிப்படையாக அனுப்பப்படுகிறது
    //
    // லிப்பேக்ரேஸ் நூலகம் சி குறியீட்டின் பெரிய வாட் ஆகும்.இது இயல்பாகவே நினைவக பாதுகாப்பு பாதிப்புகளைக் கொண்டுள்ளது, குறிப்பாக தவறான பிழைத்திருத்தத்தைக் கையாளும் போது.
    // வரலாற்று ரீதியாக இவற்றில் ஏராளமானவற்றை லிப்ஸ்டட் இயக்கியுள்ளது.
    //
    // /proc/self/exe பயன்படுத்தப்பட்டால், லிப்பேக்ரேஸ் "mostly correct" என்று நாம் கருதுவதால் இவற்றை நாம் புறக்கணிக்கலாம், இல்லையெனில் "attempted to be correct" குள்ள பிழைத்திருத்த தகவலுடன் வித்தியாசமான விஷயங்களைச் செய்ய மாட்டோம்.
    //
    //
    // எவ்வாறாயினும், நாங்கள் ஒரு கோப்பு பெயரில் கடந்து சென்றால், சில தளங்களில் (பி.எஸ்.டி போன்றவை) ஒரு தீங்கிழைக்கும் நடிகர் அந்த இடத்தில் ஒரு தன்னிச்சையான கோப்பை வைக்கக்கூடும்.
    // இதன் பொருள் என்னவென்றால், ஒரு கோப்பு பெயரைப் பற்றி நாம் libbacktrace க்குச் சொன்னால், அது ஒரு தன்னிச்சையான கோப்பைப் பயன்படுத்தலாம், இது segfaults ஐ ஏற்படுத்தக்கூடும்.
    // நாங்கள் எதையும் லிபேக் ட்ரேஸிடம் சொல்லவில்லை என்றால், அது /proc/self/exe போன்ற பாதைகளை ஆதரிக்காத தளங்களில் எதுவும் செய்யாது!
    //
    // ஒரு கோப்பு பெயரில் * கடந்து செல்லக்கூடாது என்பதற்காக நாம் முடிந்தவரை கடினமாக முயற்சி செய்கிறோம், ஆனால் /proc/self/exe ஐ ஆதரிக்காத தளங்களில் நாம் இருக்க வேண்டும்.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // நாம் `std::env::current_exe` ஐப் பயன்படுத்த விரும்புகிறோம் என்பதை நினைவில் கொள்க, ஆனால் இங்கே `std` தேவையில்லை.
            //
            // தற்போதைய இயங்கக்கூடிய பாதையை நிலையான பகுதிக்கு ஏற்ற `_NSGetExecutablePath` ஐப் பயன்படுத்தவும் (இது மிகச் சிறியதாக இருந்தால் விட்டுவிடுங்கள்).
            //
            //
            // ஊழல் நிறைவேற்றுபவர்களில் இறக்கக்கூடாது என்பதற்காக நாங்கள் இங்கு லிபாக்ட்ரேஸை தீவிரமாக நம்புகிறோம் என்பதை நினைவில் கொள்க, ஆனால் அது நிச்சயமாக செய்கிறது ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows கோப்புகளைத் திறக்கும் முறை உள்ளது, அது திறந்த பிறகு அதை நீக்க முடியாது.
            // பொதுவாக இங்கே நாம் விரும்புவது என்னவென்றால், நாங்கள் அதை லிபேக் ட்ரேஸிடம் ஒப்படைத்தபின், எங்களது இயங்கக்கூடியது நம்மிடமிருந்து மாறாது என்பதை உறுதிப்படுத்த விரும்புகிறோம், தன்னிச்சையான தரவை லிப்பேக்ரேஸில் அனுப்பும் திறனை வட்டம் தணிக்கும் (இது தவறாக கையாளப்படலாம்).
            //
            //
            // எங்கள் சொந்த படத்தில் ஒரு வகையான பூட்டைப் பெற முயற்சிக்க நாங்கள் இங்கே ஒரு நடனத்தை செய்கிறோம்:
            //
            // * தற்போதைய செயல்முறைக்கு ஒரு கைப்பிடியைப் பெறுங்கள், அதன் கோப்பு பெயரை ஏற்றவும்.
            // * சரியான கோப்புகளுடன் அந்த கோப்பு பெயருக்கு ஒரு கோப்பைத் திறக்கவும்.
            // * தற்போதைய செயல்முறையின் கோப்பு பெயரை மீண்டும் ஏற்றவும், அது ஒன்றே என்பதை உறுதிப்படுத்தவும்
            //
            // கோட்பாட்டில் நாம் கடந்து வந்தால், எங்கள் செயல்முறையின் கோப்பைத் திறந்துவிட்டோம், அது மாறாது என்று எங்களுக்கு உத்தரவாதம்.FWIW இதில் ஒரு கொத்து வரலாற்று ரீதியாக libstd இலிருந்து நகலெடுக்கப்படுகிறது, எனவே இது என்ன நடக்கிறது என்பதற்கான எனது சிறந்த விளக்கம்.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // இது நிலையான நினைவகத்தில் வாழ்கிறது, எனவே அதை திருப்பித் தரலாம் ..
                static mut BUF: [i8; N] = [0; N];
                // ... இது தற்காலிகமானது என்பதால் இது அடுக்கில் வாழ்கிறது
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // வேண்டுமென்றே இங்கே `handle` ஐ கசியுங்கள், ஏனெனில் திறந்த நிலையில் இருப்பது இந்த கோப்பு பெயரில் எங்கள் பூட்டை பாதுகாக்க வேண்டும்.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // நல்-நிறுத்தப்பட்ட ஒரு துண்டை நாங்கள் திருப்பித் தர விரும்புகிறோம், எனவே எல்லாம் நிரப்பப்பட்டு அது மொத்த நீளத்திற்கு சமமாக இருந்தால், அதை தோல்விக்கு சமன் செய்யுங்கள்.
                //
                //
                // இல்லையெனில் வெற்றியைத் தரும்போது, நல் பைட் துண்டில் சேர்க்கப்பட்டுள்ளதா என்பதை உறுதிப்படுத்திக் கொள்ளுங்கள்.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // பேக்ரேஸ் பிழைகள் தற்போது கம்பளத்தின் கீழ் உள்ளன
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API ஐ அழைக்கவும் (குறியீட்டைப் படிப்பதில் இருந்து) `syminfo_cb` ஐ சரியாக ஒரு முறை அழைக்க வேண்டும் (அல்லது பிழையுடன் தோல்வியுற்றால்).
    // நாங்கள் `syminfo_cb` க்குள் அதிகம் கையாளுகிறோம்.
    //
    // பைனரியில் பிழைத்திருத்த தகவல்கள் இல்லாவிட்டாலும் குறியீட்டு பெயர்களைக் கண்டுபிடித்து, `syminfo` குறியீட்டு அட்டவணையை ஆலோசிக்கும் என்பதால் இதை நாங்கள் செய்கிறோம் என்பதை நினைவில் கொள்க.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}