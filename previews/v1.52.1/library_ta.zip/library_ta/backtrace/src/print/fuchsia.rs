use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr ஒரு கால்பேக்கை எடுக்கும், இது ஒவ்வொரு DSO க்கும் ஒரு dl_phdr_info சுட்டிக்காட்டி பெறும்.
    // dl_iterate_phdr டைனமிக் லிங்கர் மறு செய்கையின் தொடக்கத்திலிருந்து முடிவடையும் வரை பூட்டப்பட்டிருப்பதை உறுதி செய்கிறது.
    // திரும்பப்பெறு பூஜ்ஜியமற்ற மதிப்பை அளித்தால், மறு செய்கை ஆரம்பத்தில் நிறுத்தப்படும்.
    // 'data' ஒவ்வொரு அழைப்பிலும் திரும்ப அழைப்பதற்கான மூன்றாவது வாதமாக அனுப்பப்படும்.
    // 'size' dl_phdr_info இன் அளவைக் கொடுக்கிறது.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// பில்ட் ஐடி மற்றும் சில அடிப்படை நிரல் தலைப்புத் தரவை நாம் அலச வேண்டும், அதாவது ELF விவரக்குறிப்பிலிருந்து எங்களுக்கு கொஞ்சம் பொருள் தேவை.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// இப்போது நாம் ஃபுச்ச்சியாவின் தற்போதைய டைனமிக் லிங்கரால் பயன்படுத்தப்படும் dl_phdr_info வகையின் கட்டமைப்பைப் பிரதிபலிக்க வேண்டும்.
// குரோமியத்தில் இந்த ஏபிஐ எல்லை மற்றும் கிராஷ்பேட் உள்ளது.
// இறுதியில், இந்த நிகழ்வுகளை எல்ஃப்-தேடலைப் பயன்படுத்த நாங்கள் விரும்புகிறோம், ஆனால் நாங்கள் அதை SDK இல் வழங்க வேண்டும், அது இன்னும் செய்யப்படவில்லை.
//
// இவ்வாறு நாம் (மற்றும் அவர்கள்) இந்த முறையைப் பயன்படுத்த வேண்டியிருக்கும், இது ஃபுச்ச்சியா லிப்சியுடன் இறுக்கமான இணைப்பை ஏற்படுத்துகிறது.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // E_phoff மற்றும் e_phnum செல்லுபடியாகும் என்பதை சரிபார்க்க எங்களுக்கு எந்த வழியும் இல்லை.
    // libc இதை எங்களுக்கு உறுதி செய்ய வேண்டும், எனவே இங்கே ஒரு துண்டு உருவாக்குவது பாதுகாப்பானது.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr இலக்கு கட்டமைப்பின் முடிவில் 64-பிட் ELF நிரல் தலைப்பைக் குறிக்கிறது.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr செல்லுபடியாகும் ELF நிரல் தலைப்பு மற்றும் அதன் உள்ளடக்கங்களைக் குறிக்கிறது.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // P_addr அல்லது p_memsz செல்லுபடியாகுமா என்று சரிபார்க்க எங்களுக்கு வழி இல்லை.
    // ஃபுச்ச்சியாவின் லிப்சி முதலில் குறிப்புகளை பாகுபடுத்துகிறது, எனவே இங்கே இருப்பதன் மூலம் இந்த தலைப்புகள் செல்லுபடியாகும்.
    //
    // நோட்இட்டருக்கு அடிப்படை தரவு செல்லுபடியாகும் என்று தேவையில்லை, ஆனால் அதற்கு வரம்புகள் செல்லுபடியாகும்.
    // இங்குள்ள எங்களுக்கு இதுதான் என்பதை libc உறுதி செய்துள்ளது என்று நாங்கள் நம்புகிறோம்.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// ஐடிகளை உருவாக்குவதற்கான குறிப்பு வகை.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr இலக்கின் முடிவில் ஒரு ELF குறிப்பு தலைப்பைக் குறிக்கிறது.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// குறிப்பு ஒரு ELF குறிப்பைக் குறிக்கிறது (தலைப்பு + உள்ளடக்கங்கள்).
// இந்த பெயர் ஒரு u8 ஸ்லைஸாக விடப்படுகிறது, ஏனெனில் இது எப்போதும் பூஜ்யமாக நிறுத்தப்படாது, மேலும் rust பைட்டுகள் எப்படியாவது பொருந்துமா என்பதை சரிபார்க்க போதுமானதாகிறது.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// குறிப்பு பிரிவில் பாதுகாப்பாக மீண்டும் இயக்க நோட்இட்டர் உங்களை அனுமதிக்கிறது.
// பிழை ஏற்பட்டவுடன் அது முடிவடைகிறது அல்லது அதிக குறிப்புகள் இல்லை.
// தவறான தரவை நீங்கள் மீண்டும் கூறினால், குறிப்புகள் எதுவும் கிடைக்கவில்லை என அது செயல்படும்.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // கொடுக்கப்பட்ட சுட்டிக்காட்டி மற்றும் அளவு அனைத்தும் படிக்கக்கூடிய சரியான அளவிலான பைட்டுகளைக் குறிக்கிறது என்பது செயல்பாட்டின் மாற்றமாகும்.
    // இந்த பைட்டுகளின் உள்ளடக்கங்கள் எதுவும் இருக்கலாம், ஆனால் இது பாதுகாப்பாக இருக்க வரம்பு செல்லுபடியாகும்.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' ஐ 'to'-பைட் சீரமைப்புக்கு 'to' 2 இன் சக்தி என்று கருதுகிறது.
// இது (x + to, 1)&-to பயன்படுத்தப்படும் C/C ++ ELF பாகுபடுத்தும் குறியீட்டில் ஒரு நிலையான வடிவத்தைப் பின்பற்றுகிறது.
// Rust உங்களை பயன்படுத்த மறுக்க அனுமதிக்காது, எனவே நான் பயன்படுத்துகிறேன்
// அதை மீண்டும் உருவாக்க 2 இன் நிரப்பு மாற்றம்.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 ஸ்லைஸிலிருந்து எண் பைட்டுகளை பயன்படுத்துகிறது (இருந்தால்) மற்றும் இறுதி ஸ்லைஸ் சரியாக சீரமைக்கப்பட்டிருப்பதை உறுதி செய்கிறது.
// கோரப்பட்ட பைட்டுகளின் எண்ணிக்கை மிகப் பெரியதாக இருந்தால் அல்லது போதுமான அளவு மீதமுள்ள பைட்டுகள் இல்லாததால் ஸ்லைஸை மாற்றியமைக்க முடியாவிட்டால், எதுவும் திருப்பித் தரப்படாது மற்றும் ஸ்லைஸ் மாற்றப்படவில்லை.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// இந்த செயல்பாட்டில் உண்மையான மாற்றங்கள் எதுவும் இல்லை, அழைப்பாளர் 'bytes' செயல்திறனுக்காக சீரமைக்கப்பட வேண்டும் (மற்றும் சில கட்டமைப்புகளில் சரியானது) என்பதைத் தவிர.
// Elf_Nhdr புலங்களில் உள்ள மதிப்புகள் முட்டாள்தனமாக இருக்கலாம், ஆனால் இந்த செயல்பாடு அப்படி எதுவும் இல்லை என்பதை உறுதி செய்கிறது.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // போதுமான இடம் இருக்கும் வரை இது பாதுகாப்பானது, மேலே உள்ள அறிக்கையில் இது பாதுகாப்பற்றதாக இருக்கக்கூடாது என்பதை நாங்கள் உறுதிப்படுத்தினோம்.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Sice_of: : என்பதை நினைவில் கொள்க<Elf_Nhdr>() எப்போதும் 4-பைட் சீரமைக்கப்படும்.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // நாங்கள் முடிவை அடைந்திருக்கிறோமா என்று பாருங்கள்.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // நாங்கள் ஒரு nhdr ஐ மாற்றுவோம், ஆனால் இதன் விளைவாக வரும் கட்டமைப்பை நாங்கள் கவனமாகக் கருதுகிறோம்.
        // நாங்கள் நேம்ஸ் அல்லது டெஸ்க்சை நம்பவில்லை, வகையின் அடிப்படையில் பாதுகாப்பற்ற முடிவுகளை எடுக்க மாட்டோம்.
        //
        // எனவே முழுமையான குப்பைகளை வெளியேற்றினாலும் நாம் இன்னும் பாதுகாப்பாக இருக்க வேண்டும்.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// ஒரு பிரிவு இயங்கக்கூடியது என்பதைக் குறிக்கிறது.
const PERM_X: u32 = 0b00000001;
/// ஒரு பிரிவு எழுதக்கூடியது என்பதைக் குறிக்கிறது.
const PERM_W: u32 = 0b00000010;
/// ஒரு பிரிவு படிக்கக்கூடியது என்பதைக் குறிக்கிறது.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// இயக்க நேரத்தில் ELF பிரிவை குறிக்கிறது.
struct Segment {
    /// இந்த பிரிவின் உள்ளடக்கங்களின் இயக்க நேர மெய்நிகர் முகவரியை வழங்குகிறது.
    addr: usize,
    /// இந்த பிரிவின் உள்ளடக்கங்களின் நினைவக அளவை வழங்குகிறது.
    size: usize,
    /// இந்த பிரிவின் தொகுதி மெய்நிகர் முகவரியை ELF கோப்புடன் வழங்குகிறது.
    mod_rel_addr: usize,
    /// ELF கோப்பில் காணப்படும் அனுமதிகளை வழங்குகிறது.
    /// இருப்பினும் இந்த அனுமதிகள் இயக்க நேரத்தில் இருக்கும் அனுமதிகள் அவசியமில்லை.
    flags: Perm,
}

/// ஒரு டி.எஸ்.ஓவிலிருந்து பிரிவுகளில் ஒரு மறு செய்கை அனுமதிக்கிறது.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (டைனமிக் பகிரப்பட்ட பொருள்) ஐ குறிக்கிறது.
/// இந்த வகை அதன் சொந்த நகலை உருவாக்குவதை விட உண்மையான டி.எஸ்.ஓவில் சேமிக்கப்பட்ட தரவைக் குறிக்கிறது.
struct Dso<'a> {
    /// பெயர் காலியாக இருந்தாலும் டைனமிக் லிங்கர் எப்போதும் எங்களுக்கு ஒரு பெயரைக் கொடுக்கும்.
    /// பிரதான இயங்கக்கூடிய விஷயத்தில் இந்த பெயர் காலியாக இருக்கும்.
    /// பகிரப்பட்ட பொருளின் விஷயத்தில் இது சோனேமாக இருக்கும் (DT_SONAME ஐப் பார்க்கவும்).
    name: &'a str,
    /// ஃபுச்ச்சியாவில் கிட்டத்தட்ட அனைத்து பைனரிகளும் ஐடிகளை உருவாக்குகின்றன, ஆனால் இது ஒரு கடுமையான தேவை அல்ல.
    /// பில்ட்_ஐடி இல்லாவிட்டால் டி.எஸ்.ஓ தகவலை உண்மையான ஈ.எல்.எஃப் கோப்போடு பொருத்த எந்த வழியும் இல்லை, எனவே ஒவ்வொரு டி.எஸ்.ஓவும் இங்கே ஒன்றை வைத்திருக்க வேண்டும்.
    ///
    /// பில்ட்_ஐடி இல்லாத DSO கள் புறக்கணிக்கப்படுகின்றன.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// இந்த டி.எஸ்.ஓவில் உள்ள பிரிவுகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// இந்த பிழைகள் ஒவ்வொரு டி.எஸ்.ஓ பற்றிய தகவல்களையும் பாகுபடுத்தும்போது எழும் சிக்கல்களை குறியாக்குகின்றன.
///
enum Error {
    /// NameError என்பது ஒரு சி பாணி சரத்தை rust சரமாக மாற்றும்போது பிழை ஏற்பட்டது.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError என்பது ஒரு பில்ட் ஐடியை நாங்கள் கண்டுபிடிக்கவில்லை என்பதாகும்.
    /// இது டி.எஸ்.ஓவிடம் பில்ட் ஐடி இல்லாததாலோ அல்லது பில்ட் ஐடியைக் கொண்ட பிரிவு தவறாக இருந்ததாலோ இருக்கலாம்.
    ///
    BuildIDError,
}

/// டைனமிக் லிங்கரால் செயல்பாட்டில் இணைக்கப்பட்ட ஒவ்வொரு டி.எஸ்.ஓவிற்கும் எக்ஸ் 00 எக்ஸ் அல்லது எக்ஸ் 01 எக்ஸ் அழைப்புகள்.
///
///
/// # Arguments
///
/// * `visitor` - ஃபோராச் டி.எஸ்.ஓ எனப்படும் உணவு முறைகளில் ஒன்றைக் கொண்டிருக்கும் ஒரு டிஸோபிரிண்டர்.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr info.name சரியான இடத்திற்கு சுட்டிக்காட்டுவதை உறுதி செய்கிறது.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// இந்த செயல்பாடு ஒரு DSO இல் உள்ள அனைத்து தகவல்களுக்கும் ஃபுச்ச்சியா சிம்பலைசர் மார்க்அப்பை அச்சிடுகிறது.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}