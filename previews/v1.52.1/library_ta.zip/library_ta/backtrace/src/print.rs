#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// பின்னிணைப்புகளுக்கான ஒரு வடிவமைப்பாளர்.
///
/// இந்த வகை பின்னிணைப்பு எங்கிருந்து வருகிறது என்பதைப் பொருட்படுத்தாமல் ஒரு பின்னணியை அச்சிடப் பயன்படுத்தலாம்.
/// உங்களிடம் `Backtrace` வகை இருந்தால், அதன் `Debug` செயல்படுத்தல் ஏற்கனவே இந்த அச்சிடும் வடிவமைப்பைப் பயன்படுத்துகிறது.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// நாம் அச்சிடக்கூடிய அச்சிடும் பாணிகள்
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// தொடர்புடைய தகவல்களை மட்டுமே கொண்டிருக்கும் ஒரு டெர்சர் பின்னணியை அச்சிடுகிறது
    Short,
    /// சாத்தியமான எல்லா தகவல்களையும் கொண்ட ஒரு பின்னணியை அச்சிடுகிறது
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// புதிய `BacktraceFmt` ஐ உருவாக்கவும், இது வழங்கப்பட்ட `fmt` க்கு வெளியீட்டை எழுதும்.
    ///
    /// `format` வாதம் பின்னிணைப்பு அச்சிடப்பட்ட பாணியைக் கட்டுப்படுத்தும், மேலும் `print_path` வாதம் கோப்புப் பெயர்களின் `BytesOrWideString` நிகழ்வுகளை அச்சிடப் பயன்படுத்தப்படும்.
    /// இந்த வகை கோப்பு பெயர்களை அச்சிடுவதில்லை, ஆனால் அவ்வாறு செய்ய இந்த அழைப்பு தேவைப்படுகிறது.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// பின்னிணைப்பு அச்சிடப்படவுள்ள ஒரு முன்னுரையை அச்சிடுகிறது.
    ///
    /// பின்னணிகளை பின்னர் முழுமையாக அடையாளப்படுத்த சில தளங்களில் இது தேவைப்படுகிறது, இல்லையெனில் இது ஒரு `BacktraceFmt` ஐ உருவாக்கிய பிறகு நீங்கள் அழைக்கும் முதல் முறையாக இருக்க வேண்டும்.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// பின்னணி வெளியீட்டில் ஒரு சட்டத்தை சேர்க்கிறது.
    ///
    /// இந்த உறுதிப்பாடு ஒரு `BacktraceFrameFmt` இன் RAII உதாரணத்தை வழங்குகிறது, இது உண்மையில் ஒரு சட்டகத்தை அச்சிடப் பயன்படுகிறது, மேலும் அழிவின் போது அது பிரேம் கவுண்டரை அதிகரிக்கும்.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// பேக்ட்ரேஸ் வெளியீட்டை நிறைவு செய்கிறது.
    ///
    /// இது தற்போது எந்தவொரு விருப்பமும் இல்லை, ஆனால் இது பேக்ரேஸ் வடிவங்களுடன் future பொருந்தக்கூடிய தன்மைக்காக சேர்க்கப்பட்டுள்ளது.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // future சேர்த்தல்களை அனுமதிக்க இந்த hook உட்பட தற்போது ஒரு விருப்பமும் இல்லை.
        Ok(())
    }
}

/// ஒரு பின்னணியின் ஒரு சட்டகத்திற்கான வடிவமைப்பாளர்.
///
/// இந்த வகை `BacktraceFmt::frame` செயல்பாட்டால் உருவாக்கப்பட்டது.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// இந்த பிரேம் வடிவமைப்பாளருடன் ஒரு `BacktraceFrame` ஐ அச்சிடுகிறது.
    ///
    /// இது `BacktraceFrame` க்குள் உள்ள அனைத்து `BacktraceSymbol` நிகழ்வுகளையும் மீண்டும் மீண்டும் அச்சிடும்.
    ///
    /// # தேவையான அம்சங்கள்
    ///
    /// இந்த செயல்பாட்டிற்கு `backtrace` crate இன் `std` அம்சம் இயக்கப்பட வேண்டும், மேலும் `std` அம்சம் இயல்பாக செயல்படுத்தப்படுகிறது.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// ஒரு `BacktraceFrame` க்குள் ஒரு `BacktraceSymbol` ஐ அச்சிடுகிறது.
    ///
    /// # தேவையான அம்சங்கள்
    ///
    /// இந்த செயல்பாட்டிற்கு `backtrace` crate இன் `std` அம்சம் இயக்கப்பட வேண்டும், மேலும் `std` அம்சம் இயல்பாக செயல்படுத்தப்படுகிறது.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: நாங்கள் எதையும் அச்சிடுவதை முடிக்காதது இது பெரியதல்ல
            // utf8 அல்லாத கோப்பு பெயர்களுடன்.
            // அதிர்ஷ்டவசமாக கிட்டத்தட்ட எல்லாம் utf8 எனவே இது மிகவும் மோசமாக இருக்கக்கூடாது.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// இந்த crate இன் மூல கால்பேக்குகளுக்குள் இருந்து, மூல கண்டுபிடிக்கப்பட்ட `Frame` மற்றும் `Symbol` ஐ அச்சிடுகிறது.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// பின்னணி வெளியீட்டில் மூல சட்டத்தை சேர்க்கிறது.
    ///
    /// இந்த முறை, முந்தையதைப் போலல்லாமல், வெவ்வேறு இடங்களிலிருந்து மூலமாக இருந்தால் மூல வாதங்களை எடுக்கும்.
    /// இது ஒரு சட்டத்திற்கு பல முறை அழைக்கப்படலாம் என்பதை நினைவில் கொள்க.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// நெடுவரிசை தகவல் உட்பட, பின்னிணைப்பு வெளியீட்டில் மூல சட்டத்தை சேர்க்கிறது.
    ///
    /// இந்த முறை, முந்தையதைப் போலவே, வெவ்வேறு இடங்களிலிருந்து மூலமாக இருந்தால் மூல வாதங்களை எடுக்கும்.
    /// இது ஒரு சட்டத்திற்கு பல முறை அழைக்கப்படலாம் என்பதை நினைவில் கொள்க.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ஒரு செயல்முறைக்குள் ஃபுச்ச்சியாவால் குறியிட முடியவில்லை, எனவே இது ஒரு சிறப்பு வடிவமைப்பைக் கொண்டுள்ளது, இது பின்னர் குறியீடாகப் பயன்படுத்தப்படலாம்.
        // முகவரிகளை எங்கள் சொந்த வடிவத்தில் அச்சிடுவதற்கு பதிலாக இங்கே அச்சிடுக.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" பிரேம்களை அச்சிட வேண்டிய அவசியமில்லை, இதன் பொருள் என்னவென்றால், கணினி பின்னணி சூப்பர் தொலைவில் இருப்பதைக் கண்டுபிடிக்க சற்று ஆர்வமாக இருந்தது.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // எஸ்ஜிஎக்ஸ் என்க்ளேவில் டிசிபி அளவைக் குறைக்க, குறியீட்டு தெளிவுத்திறன் செயல்பாட்டை செயல்படுத்த நாங்கள் விரும்பவில்லை.
        // மாறாக, முகவரியின் ஆஃப்செட்டை இங்கே அச்சிடலாம், பின்னர் அவை சரியான செயல்பாட்டை மாற்றலாம்.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // சட்டத்தின் குறியீட்டையும், சட்டத்தின் விருப்ப வழிமுறை சுட்டிக்காட்டி அச்சிடவும்.
        // இந்த சட்டகத்தின் முதல் சின்னத்திற்கு அப்பால் நாங்கள் பொருத்தமான இடைவெளியை அச்சிடுகிறோம்.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // அடுத்ததாக குறியீட்டு பெயரை எழுதுங்கள், நாங்கள் முழு பின்னணியாக இருந்தால் கூடுதல் தகவலுக்கு மாற்று வடிவமைப்பைப் பயன்படுத்துங்கள்.
        // பெயர் இல்லாத சின்னங்களையும் இங்கே கையாளுகிறோம்,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // கடைசியாக, filename/line எண்ணைக் கிடைத்தால் அச்சிடுக.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line குறியீட்டு பெயரில் வரிகளில் அச்சிடப்படுகின்றன, எனவே நம்மை சரியான முறையில் வரிசைப்படுத்த சில பொருத்தமான இடைவெளிகளை அச்சிடுங்கள்.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // கோப்பு பெயரை அச்சிட எங்கள் உள் அழைப்பிற்கு பிரதிநிதித்துவம் செய்து பின்னர் வரி எண்ணை அச்சிடுக.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // கிடைத்தால் நெடுவரிசை எண்ணைச் சேர்க்கவும்.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // ஒரு சட்டத்தின் முதல் சின்னத்தை மட்டுமே நாங்கள் கவனிக்கிறோம்
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}