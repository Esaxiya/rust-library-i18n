//! மேடை சார்ந்த வகைகள்.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// ஒரு சரத்தின் மேடை சுயாதீன பிரதிநிதித்துவம்.
/// `std` இயக்கப்பட்டவுடன் பணிபுரியும் போது, `std` வகைகளுக்கு மாற்றங்களை வழங்குவதற்கான வசதி முறைகளுக்கு பரிந்துரைக்கப்படுகிறது.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// ஒரு துண்டு, பொதுவாக Unix இயங்குதளங்களில் வழங்கப்படுகிறது.
    Bytes(&'a [u8]),
    /// Windows இலிருந்து பொதுவாக பரந்த சரங்கள்.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// இழப்பு ஒரு `Cow<str>` ஆக மாறுகிறது, `Bytes` செல்லுபடியாகாத UTF-8 அல்லது `BytesOrWideString` `Wide` ஆக இருந்தால் ஒதுக்கப்படும்.
    ///
    /// # தேவையான அம்சங்கள்
    ///
    /// இந்த செயல்பாட்டிற்கு `backtrace` crate இன் `std` அம்சம் இயக்கப்பட வேண்டும், மேலும் `std` அம்சம் இயல்பாக செயல்படுத்தப்படுகிறது.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// `BytesOrWideString` இன் `Path` பிரதிநிதித்துவத்தை வழங்குகிறது.
    ///
    /// # தேவையான அம்சங்கள்
    ///
    /// இந்த செயல்பாட்டிற்கு `backtrace` crate இன் `std` அம்சம் இயக்கப்பட வேண்டும், மேலும் `std` அம்சம் இயல்பாக செயல்படுத்தப்படுகிறது.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}