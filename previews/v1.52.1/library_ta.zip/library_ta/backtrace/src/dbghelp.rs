//! Windows இல் dbghelp பிணைப்புகளை நிர்வகிக்க உதவும் ஒரு தொகுதி
//!
//! Windows இல் உள்ள பின்னணிகள் (குறைந்தபட்சம் MSVC க்கு) பெரும்பாலும் `dbghelp.dll` மற்றும் அதில் உள்ள பல்வேறு செயல்பாடுகளின் மூலம் இயக்கப்படுகின்றன.
//! இந்த செயல்பாடுகள் தற்போது `dbghelp.dll` உடன் நிலையானதாக இணைப்பதை விட *மாறும்* ஏற்றப்படுகின்றன.
//! இது தற்போது நிலையான நூலகத்தால் செய்யப்படுகிறது (இது கோட்பாட்டில் தேவைப்படுகிறது), ஆனால் ஒரு நூலகத்தின் நிலையான dll சார்புகளை குறைக்க உதவும் ஒரு முயற்சியாகும், ஏனெனில் பின்னணிகள் பொதுவாக மிகவும் விருப்பமானவை.
//!
//! சொல்லப்பட்டால், `dbghelp.dll` எப்போதும் வெற்றிகரமாக Windows இல் ஏற்றப்படும்.
//!
//! இந்த ஆதரவை நாங்கள் மாறும் வகையில் ஏற்றுவதால், `winapi` இல் மூல வரையறைகளை உண்மையில் பயன்படுத்த முடியாது என்பதை நினைவில் கொள்க, மாறாக செயல்பாட்டு சுட்டிக்காட்டி வகைகளை நாமே வரையறுத்து அதைப் பயன்படுத்த வேண்டும்.
//! வினாபியை நகலெடுக்கும் வணிகத்தில் நாங்கள் உண்மையில் இருக்க விரும்பவில்லை, எனவே எங்களிடம் Cargo அம்சம் `verify-winapi` உள்ளது, இது அனைத்து பிணைப்புகளும் வினாபியில் உள்ளவற்றுடன் பொருந்துகின்றன என்றும் இந்த அம்சம் CI இல் இயக்கப்பட்டிருப்பதாகவும் வலியுறுத்துகிறது.
//!
//! இறுதியாக, `dbghelp.dll` க்கான dll ஒருபோதும் இறக்கப்படாது என்பதை நீங்கள் இங்கே கவனிக்க வேண்டும், அது தற்போது வேண்டுமென்றே.
//! சிந்தனை என்னவென்றால், நாம் அதை உலகளவில் கேச் செய்து, API க்கான அழைப்புகளுக்கு இடையில் பயன்படுத்தலாம், விலையுயர்ந்த loads/unloads ஐத் தவிர்க்கலாம்.
//! இது கசிவு கண்டுபிடிப்பாளர்களுக்கு ஒரு பிரச்சனையாக இருந்தால் அல்லது அதுபோன்ற ஏதாவது இருந்தால், நாங்கள் அங்கு செல்லும்போது பாலத்தை கடக்க முடியும்.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// `SymGetOptions` மற்றும் `SymSetOptions` ஐ வினாபியில் இல்லாததால் வேலை செய்யுங்கள்.
// இல்லையெனில் இது வினாபிக்கு எதிராக இருமுறை சரிபார்க்கும் போது மட்டுமே பயன்படுத்தப்படுகிறது.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // வினாபியில் இன்னும் வரையறுக்கப்படவில்லை
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // இது வினாபியில் வரையறுக்கப்பட்டுள்ளது, ஆனால் அது தவறானது (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // வினாபியில் இன்னும் வரையறுக்கப்படவில்லை
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// இந்த மேக்ரோ ஒரு `Dbghelp` கட்டமைப்பை வரையறுக்கப் பயன்படுகிறது, இது நாம் ஏற்றக்கூடிய அனைத்து செயல்பாட்டு சுட்டிகளையும் உள்நாட்டில் கொண்டுள்ளது.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` க்கு ஏற்றப்பட்ட டி.எல்.எல்
            dll: HMODULE,

            // நாம் பயன்படுத்தக்கூடிய ஒவ்வொரு செயல்பாட்டிற்கும் ஒவ்வொரு செயல்பாட்டு சுட்டிக்காட்டி
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // ஆரம்பத்தில் நாங்கள் டி.எல்.எல் ஏற்றவில்லை
            dll: 0 as *mut _,
            // தொடக்கத்தில் அனைத்து செயல்பாடுகளும் பூஜ்ஜியமாக அமைக்கப்பட்டன, அவை மாறும் வகையில் ஏற்றப்பட வேண்டும் என்று கூறுகின்றன.
            //
            $($name: 0,)*
        };

        // ஒவ்வொரு செயல்பாட்டு வகைக்கும் வசதியான தட்டச்சு.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` ஐ திறக்க முயற்சிக்கிறது.
            /// இது இயங்கினால் வெற்றியைத் தருகிறது அல்லது `LoadLibraryW` தோல்வியுற்றால் பிழை.
            ///
            /// நூலகம் ஏற்கனவே ஏற்றப்பட்டிருந்தால் Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // நாம் பயன்படுத்த விரும்பும் ஒவ்வொரு முறைக்கும் செயல்பாடு.
            // அழைக்கப்படும் போது அது தற்காலிக சேமிப்பில் உள்ள செயல்பாட்டு சுட்டிக்காட்டி படிக்கும் அல்லது ஏற்றப்படும் மற்றும் ஏற்றப்பட்ட மதிப்பை வழங்கும்.
            // சுமைகள் வெற்றிபெற வலியுறுத்தப்படுகின்றன.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp செயல்பாடுகளைக் குறிக்க துப்புரவு பூட்டுகளைப் பயன்படுத்த வசதியான ப்ராக்ஸி.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// இந்த crate இலிருந்து `dbghelp` API செயல்பாடுகளை அணுக தேவையான அனைத்து ஆதரவையும் தொடங்கவும்.
///
///
/// இந்த செயல்பாடு **பாதுகாப்பானது** என்பதை நினைவில் கொள்க, இது உள்நாட்டில் அதன் சொந்த ஒத்திசைவைக் கொண்டுள்ளது.
/// இந்த செயல்பாட்டை பல முறை மீண்டும் மீண்டும் அழைப்பது பாதுகாப்பானது என்பதையும் நினைவில் கொள்க.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // இந்தச் செயல்பாட்டை ஒத்திசைப்பதே நாம் முதலில் செய்ய வேண்டியது.இதை மற்ற நூல்களிலிருந்து ஒரே நேரத்தில் அல்லது ஒரு நூலுக்குள் மீண்டும் மீண்டும் அழைக்கலாம்.
        // இதை விட தந்திரமானது என்பதை நினைவில் கொள்க, ஏனென்றால் நாம் இங்கே பயன்படுத்துவது, `dbghelp`,*மேலும்* இந்த செயல்பாட்டில் மற்ற எல்லா அழைப்பாளர்களுடனும் `dbghelp` உடன் ஒத்திசைக்கப்பட வேண்டும்.
        //
        // பொதுவாக ஒரே செயல்பாட்டில் `dbghelp` க்கு பல அழைப்புகள் இல்லை, நாங்கள் அதை மட்டுமே அணுகுவோம் என்று பாதுகாப்பாக கருதலாம்.
        // எவ்வாறாயினும், ஒரு முதன்மை மற்ற பயனர் இருக்கிறார், இது நம்மைப் பற்றி கவலைப்பட வேண்டியது, ஆனால் நிலையான நூலகத்தில்.
        // Rust நிலையான நூலகம் இந்த crate ஐ பின்னணி ஆதரவுக்காக சார்ந்துள்ளது, மேலும் இந்த crate crates.io இல் உள்ளது.
        // இதன் பொருள் என்னவென்றால், நிலையான நூலகம் ஒரு panic பின்னணியை அச்சிடுகிறதென்றால், இது crates.io இலிருந்து வரும் இந்த crate உடன் போட்டியிடலாம், இதனால் segfaults ஏற்படும்.
        //
        // இந்த ஒத்திசைவு சிக்கலைத் தீர்க்க உதவ, நாங்கள் இங்கே ஒரு விண்டோஸ்-குறிப்பிட்ட தந்திரத்தைப் பயன்படுத்துகிறோம் (இது, ஒத்திசைவு பற்றிய விண்டோஸ்-குறிப்பிட்ட கட்டுப்பாடு).
        // இந்த அழைப்பைப் பாதுகாக்க *அமர்வு-உள்ளூர்* மியூடெக்ஸ் என்ற பெயரை உருவாக்குகிறோம்.
        // இங்கே நோக்கம் என்னவென்றால், நிலையான நூலகம் மற்றும் இந்த crate இங்கே ஒத்திசைக்க Rust-நிலை API களைப் பகிர வேண்டியதில்லை, ஆனால் அவை ஒருவருக்கொருவர் ஒத்திசைக்கப்படுகின்றன என்பதை உறுதிப்படுத்த திரைக்குப் பின்னால் வேலை செய்யலாம்.
        //
        // இந்த செயல்பாடு நிலையான நூலகத்தின் மூலமாகவோ அல்லது crates.io மூலமாகவோ அழைக்கப்படும் போது, அதே மியூடெக்ஸ் பெறப்படுகிறது என்பதை நாம் உறுதியாக நம்பலாம்.
        //
        // எனவே இவை அனைத்தும் நாம் இங்கே செய்யும் முதல் விஷயம், நாம் `HANDLE` ஐ அணு ரீதியாக உருவாக்குகிறோம், இது Windows இல் பெயரிடப்பட்ட மியூடெக்ஸ் ஆகும்.
        // இந்த செயல்பாட்டை குறிப்பாகப் பகிரும் பிற நூல்களுடன் நாங்கள் சிறிது ஒத்திசைக்கிறோம், மேலும் இந்த செயல்பாட்டின் ஒரு நிகழ்வுக்கு ஒரு கைப்பிடி மட்டுமே உருவாக்கப்படுவதை உறுதிசெய்கிறோம்.
        // கைப்பிடி உலகில் சேமிக்கப்பட்டவுடன் அது ஒருபோதும் மூடப்படாது என்பதை நினைவில் கொள்க.
        //
        // நாங்கள் உண்மையில் பூட்டுக்குச் சென்ற பிறகு அதை வெறுமனே பெறுகிறோம், எங்கள் `Init` கைப்பிடி அதை நாங்கள் கைவிடுவதற்கு பொறுப்பாகும்.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // சரி, அடடா!இப்போது நாம் அனைவரும் பாதுகாப்பாக ஒத்திசைக்கப்பட்டுள்ளோம், உண்மையில் எல்லாவற்றையும் செயலாக்கத் தொடங்குவோம்.
        // முதலில் இந்த செயல்பாட்டில் `dbghelp.dll` ஏற்றப்பட்டிருப்பதை உறுதி செய்ய வேண்டும்.
        // நிலையான சார்புநிலையைத் தவிர்க்க இதை நாங்கள் மாறும்.
        // இது வரலாற்று ரீதியாக வித்தியாசமான இணைக்கும் சிக்கல்களைச் சுற்றியே செய்யப்படுகிறது, மேலும் இது பைனரிகளை இன்னும் கொஞ்சம் சிறியதாக மாற்றுவதை நோக்கமாகக் கொண்டுள்ளது, ஏனெனில் இது பெரும்பாலும் பிழைத்திருத்த பயன்பாடாகும்.
        //
        //
        // நாங்கள் `dbghelp.dll` ஐ திறந்தவுடன், அதில் சில துவக்க செயல்பாடுகளை அழைக்க வேண்டும், அது கீழே விரிவாக உள்ளது.
        // நாங்கள் இதை ஒரு முறை மட்டுமே செய்கிறோம், ஆகவே, நாங்கள் இன்னும் முடித்துவிட்டோமா இல்லையா என்பதைக் குறிக்கும் உலகளாவிய பூலியன் கிடைத்துள்ளது.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` கொடி அமைக்கப்பட்டிருப்பதை உறுதிசெய்க, ஏனென்றால் இதைப் பற்றிய MSVC இன் சொந்த ஆவணங்களின்படி: "This is the fastest, most efficient way to use the symbol handler.", எனவே அதைச் செய்வோம்!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // MSVC உடன் சின்னங்களை உண்மையில் துவக்கவும்.இது தோல்வியடையும் என்பதை நினைவில் கொள்க, ஆனால் நாங்கள் அதை புறக்கணிக்கிறோம்.
        // இதற்கு ஒரு டன் முன் கலை இல்லை, ஆனால் எல்.எல்.வி.எம் உள்நாட்டில் வருவாய் மதிப்பை புறக்கணிப்பதாகத் தெரிகிறது மற்றும் எல்.எல்.வி.எம்மில் உள்ள சானிட்டைசர் நூலகங்களில் ஒன்று இது தோல்வியுற்றால் பயமுறுத்தும் எச்சரிக்கையை அச்சிடுகிறது, ஆனால் நீண்ட காலமாக அதை புறக்கணிக்கிறது.
        //
        //
        // Rust க்கு இது நிறைய வரும் ஒரு வழக்கு என்னவென்றால், நிலையான நூலகம் மற்றும் crates.io இல் உள்ள இந்த crate இரண்டும் `SymInitializeW` க்கு போட்டியிட விரும்புகின்றன.
        // நிலையான நூலகம் வரலாற்று ரீதியாக பெரும்பாலான நேரங்களில் தூய்மைப்படுத்தலைத் தொடங்க விரும்பியது, ஆனால் இப்போது இந்த crate ஐப் பயன்படுத்துவதால், யாரோ ஒருவர் முதலில் துவக்கத்தைப் பெறுவார்கள், மற்றவர் அந்த துவக்கத்தை எடுப்பார்.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}