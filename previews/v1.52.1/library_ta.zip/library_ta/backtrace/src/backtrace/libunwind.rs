//! libunwind/gcc_s/etc API களைப் பயன்படுத்தி பேக்ரேஸ் ஆதரவு.
//!
//! இந்த தொகுதிக்கூறு லிபன்விண்ட்-ஸ்டைல் API களைப் பயன்படுத்தி ஸ்டேக்கை பிரிக்கும் திறனைக் கொண்டுள்ளது.
//! லிபன்விண்ட் போன்ற ஏபிஐ செயல்படுத்தல் முழுவதுமாக உள்ளது என்பதை நினைவில் கொள்க, மேலும் இது எல்லாவற்றையும் தேர்ந்தெடுப்பதற்கு பதிலாக ஒரே நேரத்தில் இணக்கமாக இருக்க முயற்சிக்கிறது.
//!
//!
//! லிபன்விண்ட் ஏபிஐ `_Unwind_Backtrace` ஆல் இயக்கப்படுகிறது மற்றும் நடைமுறையில் ஒரு பின்னடைவை உருவாக்குவதில் மிகவும் நம்பகமானது.
//! இது எவ்வாறு செயல்படுகிறது என்பது முற்றிலும் தெளிவாகத் தெரியவில்லை (பிரேம் சுட்டிகள்? Eh_frame தகவல்? இரண்டும்?) ஆனால் அது செயல்படுவதாகத் தெரிகிறது!
//!
//! இந்த தொகுதியின் சிக்கலானது லிபன்விண்ட் செயலாக்கங்களில் பல்வேறு தள வேறுபாடுகளைக் கையாளுகிறது.
//! இல்லையெனில் இது லிபன்விண்ட் ஏபிஐகளுடன் பிணைக்கும் அழகான நேரடியான Rust ஆகும்.
//!
//! இது தற்போது அனைத்து விண்டோஸ் அல்லாத இயங்குதளங்களுக்கான இயல்புநிலை பிரிக்கப்படாத API ஆகும்.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// ஒரு மூல லிபன்விண்ட் சுட்டிக்காட்டி மூலம் இது எப்போதுமே படிக்கக்கூடிய த்ரெட் சேஃப் பாணியில் மட்டுமே அணுகப்பட வேண்டும், எனவே இது `Sync` ஆகும்.
// `Clone` வழியாக பிற நூல்களுக்கு அனுப்பும்போது, உள்துறை சுட்டிகளைத் தக்கவைக்காத பதிப்பிற்கு நாங்கள் எப்போதும் மாறுகிறோம், எனவே நாம் `Send` ஆகவும் இருக்க வேண்டும்.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // OSX `_Unwind_FindEnclosingFunction` இல் ஒரு சுட்டிக்காட்டிக்குத் திரும்புகிறது ... தெளிவற்ற ஒன்று.
        // எந்தவொரு காரணத்திற்காகவும் இது எப்போதும் இணைக்கும் செயல்பாடு அல்ல.
        // இங்கே என்ன நடக்கிறது என்பது எனக்கு முற்றிலும் தெளிவாகத் தெரியவில்லை, எனவே இதை இப்போதே அவநம்பிக்கை செய்து எப்போதும் ஐபியைத் திருப்பி விடுங்கள்.
        //
        // இந்த உட்பிரிவின் காரணமாக OS00 இல் `skip_inner_frames.rs` சோதனை தவிர்க்கப்பட்டது என்பதை நினைவில் கொள்க, இது சரி செய்யப்பட்டால் கோட்பாட்டில் சோதனை OSX இல் இயக்கப்படலாம்!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// பின்னிணைப்புகளுக்குப் பயன்படுத்தப்படும் நூலக இடைமுகத்தைத் துண்டிக்கவும்
///
/// இறந்த குறியீடு இங்கே பிணைக்கப்படுவதால் அனுமதிக்கப்படுகிறது என்பதை நினைவில் கொள்க, iOS அவை அனைத்தையும் பயன்படுத்தாது, ஆனால் மேடையில் குறிப்பிட்ட கட்டங்களை சேர்ப்பது குறியீட்டை அதிகமாக மாசுபடுத்துகிறது
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // ARM EABI ஆல் மட்டுமே பயன்படுத்தப்படுகிறது
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // IOS இல் சொந்த _Unwind_Backtrace இல்லை
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0 முதல் கிடைக்கும், எங்கள் நோக்கத்திற்காக நன்றாக இருக்க வேண்டும்
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // இந்த செயல்பாடு ஒரு தவறான பெயர்: இந்த சட்டத்தின் நியமன சட்ட முகவரியை (அழைப்பாளர் சட்டகத்தின் எஸ்பி) பெறுவதை விட, இது இந்த சட்டத்தின் எஸ்பியை வழங்குகிறது.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x ஒரு சார்புடைய CFA மதிப்பைப் பயன்படுத்துகிறது, எனவே _Unwind_GetCFA ஐ நம்புவதற்கு பதிலாக ஸ்டாக் சுட்டிக்காட்டி பதிவேட்டை (%r15) ஐப் பெற _Unwind_GetGR ஐப் பயன்படுத்த வேண்டும்.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android மற்றும் கைகளில், `_Unwind_GetIP` செயல்பாடு மற்றும் பிறவற்றின் ஒரு தொகுதி மேக்ரோக்கள், எனவே மேக்ரோக்களின் விரிவாக்கத்தைக் கொண்ட செயல்பாடுகளை வரையறுக்கிறோம்.
    //
    //
    // TODO: இந்த மேக்ரோக்களை வரையறுக்கும் தலைப்பு கோப்பிற்கான இணைப்பு, அதை நீங்கள் கண்டுபிடிக்க முடிந்தால்.
    // (இந்த மேக்ரோ விரிவாக்கங்களில் சில முதலில் கடன் வாங்கிய தலைப்பு கோப்பை என்னால், ஃபிட்ஜென் கண்டுபிடிக்க முடியவில்லை.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 கையில் ஸ்டாக் சுட்டிக்காட்டி.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // இந்த செயல்பாடு Android அல்லது ARM/Linux இல் இல்லை, எனவே இதை ஒரு விருப்பமாக மாற்றவும்.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}