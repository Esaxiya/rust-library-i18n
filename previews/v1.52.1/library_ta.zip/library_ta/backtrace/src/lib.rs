//! இயக்க நேரத்தில் ஒரு பின்னணியைப் பெறுவதற்கான நூலகம்
//!
//! இந்த நூலகம் நிலையான நூலகத்தின் `RUST_BACKTRACE=1` ஆதரவை துணைபுரியும் வகையில் இயக்க நேரத்தில் ஒரு பின்னொளியைப் பெற அனுமதிக்கிறது.
//! இந்த நூலகத்தால் உருவாக்கப்பட்ட பின்னணிகளை பாகுபடுத்த வேண்டிய அவசியமில்லை, எடுத்துக்காட்டாக, பல பின்தளத்தில் செயலாக்கங்களின் செயல்பாட்டை அம்பலப்படுத்துகிறது.
//!
//! # Usage
//!
//! முதலில், இதை உங்கள் Cargo.toml இல் சேர்க்கவும்
//!
//! ```toml
//! [dependencies]
//! backtrace = "0.3"
//! ```
//!
//! Next:
//!
//! ```
//! fn main() {
//! # // இங்கே பாதுகாப்பற்றது, எனவே சோதனை no_std இல் கடந்து செல்கிறது.
//! # #[cfg(feature = "std")] {
//!     backtrace::trace(|frame| {
//!         let ip = frame.ip();
//!         let symbol_address = frame.symbol_address();
//!
//!         // இந்த வழிமுறை சுட்டிக்காட்டி ஒரு குறியீட்டு பெயருக்கு தீர்க்கவும்
//!         backtrace::resolve_frame(frame, |symbol| {
//!             if let Some(name) = symbol.name() {
//!                 // ...
//!             }
//!             if let Some(filename) = symbol.filename() {
//!                 // ...
//!             }
//!         });
//!
//!         true // அடுத்த சட்டகத்திற்குச் செல்லுங்கள்
//!     });
//! }
//! # }
//! ```
//!
//!
//!

#![doc(html_root_url = "https://docs.rs/backtrace")]
#![deny(missing_docs)]
#![no_std]
#![cfg_attr(
    all(feature = "std", target_env = "sgx", target_vendor = "fortanix"),
    feature(sgx_platform)
)]
#![warn(rust_2018_idioms)]
// நாங்கள் libstd இன் ஒரு பகுதியாக கட்டமைக்கும்போது, இந்த crate மரத்திற்கு வெளியே உருவாக்கப்பட்டுள்ளதால் அனைத்து எச்சரிக்கைகளும் பொருத்தமற்றவை என்பதால் அவற்றை அமைதிப்படுத்தவும்.
//
#![cfg_attr(backtrace_in_libstd, allow(warnings))]
#![cfg_attr(not(feature = "std"), allow(dead_code))]

#[cfg(feature = "std")]
#[macro_use]
extern crate std;

// இது இப்போது கிம்லிக்கு மட்டுமே பயன்படுத்தப்படுகிறது, இது சில தளங்களில் மட்டுமே பயன்படுத்தப்படுகிறது, எனவே இது மற்ற உள்ளமைவுகளில் பயன்படுத்தப்படாவிட்டால் கவலைப்பட வேண்டாம்.
//
#[allow(unused_extern_crates)]
extern crate alloc;

pub use self::backtrace::{trace_unsynchronized, Frame};
mod backtrace;

pub use self::symbolize::resolve_frame_unsynchronized;
pub use self::symbolize::{resolve_unsynchronized, Symbol, SymbolName};
mod symbolize;

pub use self::types::BytesOrWideString;
mod types;

#[cfg(feature = "std")]
pub use self::symbolize::clear_symbol_cache;

mod print;
pub use print::{BacktraceFmt, BacktraceFrameFmt, PrintFmt};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        pub use self::backtrace::trace;
        pub use self::symbolize::{resolve, resolve_frame};
        pub use self::capture::{Backtrace, BacktraceFrame, BacktraceSymbol};
        mod capture;
    }
}

#[allow(dead_code)]
struct Bomb {
    enabled: bool,
}

#[allow(dead_code)]
impl Drop for Bomb {
    fn drop(&mut self) {
        if self.enabled {
            panic!("cannot panic during the backtrace function");
        }
    }
}

#[allow(dead_code)]
#[cfg(feature = "std")]
mod lock {
    use std::boxed::Box;
    use std::cell::Cell;
    use std::sync::{Mutex, MutexGuard, Once};

    pub struct LockGuard(Option<MutexGuard<'static, ()>>);

    static mut LOCK: *mut Mutex<()> = 0 as *mut _;
    static INIT: Once = Once::new();
    thread_local!(static LOCK_HELD: Cell<bool> = Cell::new(false));

    impl Drop for LockGuard {
        fn drop(&mut self) {
            if self.0.is_some() {
                LOCK_HELD.with(|slot| {
                    assert!(slot.get());
                    slot.set(false);
                });
            }
        }
    }

    pub fn lock() -> LockGuard {
        if LOCK_HELD.with(|l| l.get()) {
            return LockGuard(None);
        }
        LOCK_HELD.with(|s| s.set(true));
        unsafe {
            INIT.call_once(|| {
                LOCK = Box::into_raw(Box::new(Mutex::new(())));
            });
            LockGuard(Some((*LOCK).lock().unwrap()))
        }
    }
}

#[cfg(all(windows, not(target_vendor = "uwp")))]
mod dbghelp;
#[cfg(windows)]
mod windows;