# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust க்கான இயக்க நேரத்தில் பின்னணிகளைப் பெறுவதற்கான நூலகம்.
இந்த நூலகம் பணிபுரிய ஒரு நிரல் இடைமுகத்தை வழங்குவதன் மூலம் நிலையான நூலகத்தின் ஆதரவை மேம்படுத்துவதை நோக்கமாகக் கொண்டுள்ளது, ஆனால் இது libstd இன் panics போன்ற தற்போதைய பின்னணியை எளிதில் அச்சிடுவதையும் ஆதரிக்கிறது.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

வெறுமனே ஒரு பின்னணியைப் பிடிக்கவும், பின்னர் அதைக் கையாள்வதைத் தள்ளிவைக்கவும், நீங்கள் உயர்மட்ட `Backtrace` வகையைப் பயன்படுத்தலாம்.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

எவ்வாறாயினும், உண்மையான தடமறிதல் செயல்பாட்டிற்கு அதிக மூல அணுகலை நீங்கள் விரும்பினால், நீங்கள் நேரடியாக `trace` மற்றும் `resolve` செயல்பாடுகளைப் பயன்படுத்தலாம்.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // இந்த வழிமுறை சுட்டிக்காட்டி ஒரு குறியீட்டு பெயருக்கு தீர்க்கவும்
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // அடுத்த சட்டகத்திற்குச் செல்லுங்கள்
    });
}
```

# License

இந்த திட்டம் இரண்டின் கீழ் உரிமம் பெற்றது

 * Apache உரிமம், பதிப்பு 2.0, ([LICENSE-APACHE](LICENSE-APACHE) அல்லது http://www.apache.org/licenses/LICENSE-2.0)
 * MIT உரிமம் ([LICENSE-MIT](LICENSE-MIT) அல்லது http://opensource.org/licenses/MIT)

உங்கள் விருப்பப்படி.

### Contribution

நீங்கள் வேறுவிதமாக வெளிப்படையாகக் கூறாவிட்டால், Apache-2.0 உரிமத்தில் வரையறுக்கப்பட்டுள்ளபடி, உங்களால் பேக்ரேஸ்-ஆர்எஸ்ஸில் சேர்க்க வேண்டுமென்றே சமர்ப்பிக்கப்பட்ட எந்தவொரு பங்களிப்பும் கூடுதல் விதிமுறைகள் அல்லது நிபந்தனைகள் இல்லாமல் மேலே குறிப்பிட்டபடி இரட்டை உரிமம் பெறும்.







