mod auxiliary;

macro_rules! pos {
    () => {
        (file!(), line!())
    };
}

macro_rules! check {
    ($($pos:expr),*) => ({
        verify(&[$($pos,)* pos!()]);
    })
}

type Pos = (&'static str, u32);

#[test]
fn doit() {
    if
    // முன்னிருப்பாக நிலையான இணைக்கப்பட்ட மற்றும் மாறும் நூலகங்களை ஆதரிக்காத மஸ்லைத் தவிர்.
    //
    !cfg!(target_env = "musl")
    // டி.எல்.எல் க்களுக்கான ஆதரவு இல்லாத லிப்பேக்ரேஸில் MinGW ஐத் தவிர்க்கவும்.
    && !(cfg!(windows) && cfg!(target_env = "gnu") && cfg!(feature = "libbacktrace"))
    // மிரியைத் தவிர், ஏனெனில் இது டைனமிக் நூலகங்களை ஆதரிக்காது.
    && !cfg!(miri)
    {
        // TODO(#238) இந்த செயல்பாட்டில் இது முதலில் நடக்கக்கூடாது, ஆனால் தற்போது அது நிகழ்கிறது.
        //
        let mut dir = std::env::current_exe().unwrap();
        dir.pop();
        if cfg!(windows) {
            dir.push("dylib_dep.dll");
        } else if cfg!(target_os = "macos") {
            dir.push("libdylib_dep.dylib");
        } else {
            dir.push("libdylib_dep.so");
        }
        let lib = libloading::Library::new(&dir).unwrap();
        let api = unsafe { lib.get::<extern "C" fn(Pos, fn(Pos, Pos))>(b"foo").unwrap() };
        api(pos!(), |a, b| {
            check!(a, b);
        });
    }

    outer(pos!());
}

#[inline(never)]
fn outer(main_pos: Pos) {
    inner(main_pos, pos!());
    inner_inlined(main_pos, pos!());
}

#[inline(never)]
#[rustfmt::skip]
fn inner(main_pos: Pos, outer_pos: Pos) {
    check!(main_pos, outer_pos);
    check!(main_pos, outer_pos);
    let inner_pos = pos!(); auxiliary::callback(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });
    let inner_pos = pos!(); auxiliary::callback_inlined(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });
}

#[inline(always)]
#[rustfmt::skip]
fn inner_inlined(main_pos: Pos, outer_pos: Pos) {
    check!(main_pos, outer_pos);
    check!(main_pos, outer_pos);

    #[inline(always)]
    fn inner_further_inlined(main_pos: Pos, outer_pos: Pos, inner_pos: Pos) {
        check!(main_pos, outer_pos, inner_pos);
    }
    inner_further_inlined(main_pos, outer_pos, pos!());

    let inner_pos = pos!(); auxiliary::callback(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });
    let inner_pos = pos!(); auxiliary::callback_inlined(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });

    // இது இன்லைன் செயல்பாட்டிற்கான இரண்டு சுயாதீன அழைப்புகளுக்கு இடையிலான வேறுபாட்டை சோதிக்கிறது.
    // (ஐ.நா) அதிர்ஷ்டவசமாக, எல்.எல்.வி.எம் எப்படியாவது தொடர்ச்சியாக இதுபோன்ற இரண்டு அழைப்புகளை ஒரு முனையில் இணைக்கிறது.
    inner_further_inlined(main_pos, outer_pos, pos!());
}

fn verify(filelines: &[Pos]) {
    let trace = backtrace::Backtrace::new();
    println!("-----------------------------------");
    println!("looking for:");
    for (file, line) in filelines.iter().rev() {
        println!("\t{}:{}", file, line);
    }
    println!("found:\n{:?}", trace);
    let mut symbols = trace.frames().iter().flat_map(|frame| frame.symbols());
    let mut iter = filelines.iter().rev();
    while let Some((file, line)) = iter.next() {
        loop {
            let sym = match symbols.next() {
                Some(sym) => sym,
                None => panic!("failed to find {}:{}", file, line),
            };
            if let Some(filename) = sym.filename() {
                if let Some(lineno) = sym.lineno() {
                    if filename.ends_with(file) && lineno == *line {
                        break;
                    }
                }
            }
        }
    }
}