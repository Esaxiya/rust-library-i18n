use backtrace::Backtrace;

// இந்த சோதனை ஒரு குறியீட்டின் தொடக்க முகவரியைப் புகாரளிக்கும் பிரேம்களுக்கான `symbol_address` செயல்பாட்டைக் கொண்ட தளங்களில் மட்டுமே இயங்குகிறது.
// இதன் விளைவாக இது ஒரு சில தளங்களில் மட்டுமே இயக்கப்பட்டது.
//
const ENABLED: bool = cfg!(all(
    // Windows உண்மையில் சோதிக்கப்படவில்லை, மேலும் ஒரு இணைக்கும் சட்டகத்தைக் கண்டுபிடிப்பதை OSX ஆதரிக்கவில்லை, எனவே இதை முடக்கவும்
    //
    target_os = "linux",
    // ARM இல் இணைக்கும் செயல்பாட்டைக் கண்டுபிடிப்பது வெறுமனே ஐபியைத் திருப்பித் தருகிறது.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}