#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// `char` மற்றும் `str` முறைகளின் யூனிகோட் பாகங்கள் அடிப்படையாகக் கொண்ட [Unicode](http://www.unicode.org/) இன் பதிப்பு.
///
/// யூனிகோடின் புதிய பதிப்புகள் தவறாமல் வெளியிடப்படுகின்றன, பின்னர் யூனிகோடைப் பொறுத்து நிலையான நூலகத்தில் உள்ள அனைத்து முறைகளும் புதுப்பிக்கப்படும்.
/// எனவே சில `char` மற்றும் `str` முறைகளின் நடத்தை மற்றும் காலப்போக்கில் இந்த நிலையான மாற்றங்களின் மதிப்பு.
/// இது * ஒரு முறிவு மாற்றமாக கருதப்படவில்லை.
///
/// பதிப்பு எண் திட்டம் [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) இல் விளக்கப்பட்டுள்ளது.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Liballoc இல் பயன்படுத்த, libstd இல் மீண்டும் ஏற்றுமதி செய்யப்படவில்லை.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;