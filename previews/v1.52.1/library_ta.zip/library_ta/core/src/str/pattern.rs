//! சரம் வடிவ API.
//!
//! பேட்டர்ன் ஏபிஐ ஒரு சரம் மூலம் தேடும்போது வெவ்வேறு மாதிரி வகைகளைப் பயன்படுத்துவதற்கான பொதுவான பொறிமுறையை வழங்குகிறது.
//!
//! மேலும் விவரங்களுக்கு, traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] மற்றும் [`DoubleEndedSearcher`] ஐப் பார்க்கவும்.
//!
//! இந்த API நிலையற்றது என்றாலும், இது [`str`] வகையின் நிலையான API கள் வழியாக வெளிப்படும்.
//!
//! # Examples
//!
//! [`Pattern`] [`&str`][`str`], [`char`], [`char`] இன் துண்டுகள் மற்றும் `FnMut(char) -> bool` ஐ செயல்படுத்தும் செயல்பாடுகள் மற்றும் மூடல்களுக்கான நிலையான API இல் [implemented][pattern-impls] ஆகும்.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // கரி முறை
//! assert_eq!(s.find('n'), Some(2));
//! // எழுத்துகள் துண்டு
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // மூடல் முறை
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// ஒரு சரம் முறை.
///
/// ஒரு [`&'a str`][str] இல் தேடுவதற்கு செயல்படுத்தும் வகையை ஒரு சரம் வடிவமாகப் பயன்படுத்தலாம் என்று ஒரு `Pattern<'a>` வெளிப்படுத்துகிறது.
///
/// எடுத்துக்காட்டாக, `'a'` மற்றும் `"aa"` இரண்டும் `"baaaab"` சரத்தில் குறியீட்டு `1` இல் பொருந்தக்கூடிய வடிவங்கள்.
///
/// trait ஆனது தொடர்புடைய [`Searcher`] வகைக்கான பில்டராக செயல்படுகிறது, இது ஒரு சரத்தில் வடிவத்தின் நிகழ்வுகளைக் கண்டறியும் உண்மையான வேலையைச் செய்கிறது.
///
///
/// வடிவத்தின் வகையைப் பொறுத்து, [`str::find`] மற்றும் [`str::contains`] போன்ற முறைகளின் நடத்தை மாறலாம்.
/// கீழேயுள்ள அட்டவணை அந்த நடத்தைகளில் சிலவற்றை விவரிக்கிறது.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// இந்த முறைக்கு தொடர்புடைய தேடுபவர்
    type Searcher: Searcher<'a>;

    /// தேட தேடலுடன் தொடர்புடைய தேடலை `self` மற்றும் `haystack` இலிருந்து உருவாக்குகிறது.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// முறை வைக்கோலில் எங்கும் பொருந்துமா என்பதை சரிபார்க்கிறது
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// வைக்கோலின் முன்புறத்தில் முறை பொருந்துமா என்பதை சரிபார்க்கிறது
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// வைக்கோலின் பின்புறத்தில் முறை பொருந்துமா என்பதை சரிபார்க்கிறது
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// பொருந்தினால், வைக்கோலின் முன்னால் இருந்து அமைப்பை நீக்குகிறது.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // பாதுகாப்பு: `Searcher` செல்லுபடியாகும் குறியீடுகளை வழங்குவதாக அறியப்படுகிறது.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// பொருந்தினால், வைக்கோலின் பின்புறத்திலிருந்து அமைப்பை நீக்குகிறது.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // பாதுகாப்பு: `Searcher` செல்லுபடியாகும் குறியீடுகளை வழங்குவதாக அறியப்படுகிறது.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] அல்லது [`ReverseSearcher::next_back()`] ஐ அழைப்பதன் முடிவு.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// `haystack[a..b]` இல் வடிவத்தின் பொருத்தம் கண்டறியப்பட்டுள்ளது என்பதை வெளிப்படுத்துகிறது.
    ///
    Match(usize, usize),
    /// `haystack[a..b]` வடிவத்தின் சாத்தியமான பொருத்தமாக நிராகரிக்கப்பட்டுள்ளது என்பதை வெளிப்படுத்துகிறது.
    ///
    /// இரண்டு `பொருத்தங்களுக்கு 'இடையில் ஒன்றுக்கு மேற்பட்ட `Reject` இருக்கலாம் என்பதை நினைவில் கொள்க, அவை ஒன்றில் ஒன்றிணைக்கப்பட வேண்டிய அவசியமில்லை.
    ///
    ///
    Reject(usize, usize),
    /// வைக்கோலின் ஒவ்வொரு பைட்டையும் பார்வையிட்டதாக வெளிப்படுத்துகிறது, மறு செய்கை முடிவடைகிறது.
    ///
    Done,
}

/// சரம் வடிவத்திற்கான தேடுபவர்.
///
/// இந்த trait ஒரு சரத்தின் முன் (left) இலிருந்து தொடங்கி ஒரு வடிவத்தின் ஒன்றுடன் ஒன்று பொருந்தாத தேடல்களைத் தேடுவதற்கான முறைகளை வழங்குகிறது.
///
/// இது [`Pattern`] trait இன் தொடர்புடைய `Searcher` வகைகளால் செயல்படுத்தப்படும்.
///
/// trait பாதுகாப்பற்றது எனக் குறிக்கப்பட்டுள்ளது, ஏனெனில் [`next()`][Searcher::next] முறைகள் மூலம் திரும்பிய குறியீடுகள் வைக்கோலில் செல்லுபடியாகும் utf8 எல்லைகளில் இருக்க வேண்டும்.
/// இந்த trait இன் நுகர்வோருக்கு கூடுதல் இயக்க நேர சோதனைகள் இல்லாமல் வைக்கோலை வெட்ட உதவுகிறது.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// தேட வேண்டிய அடிப்படை சரத்திற்கு Getter
    ///
    /// எப்போதும் அதே [`&str`][str] ஐ வழங்கும்.
    fn haystack(&self) -> &'a str;

    /// முன் இருந்து தொடங்கி அடுத்த தேடல் படி செய்கிறது.
    ///
    /// - `haystack[a..b]` வடிவத்துடன் பொருந்தினால் [`Match(a, b)`][SearchStep::Match] ஐ வழங்குகிறது.
    /// - `haystack[a..b]` ஆனது பகுதியுடன் கூட பொருந்தவில்லை என்றால் [`Reject(a, b)`][SearchStep::Reject] ஐ வழங்குகிறது.
    /// - வைக்கோலின் ஒவ்வொரு பைட்டையும் பார்வையிட்டிருந்தால் [`Done`][SearchStep::Done] ஐ வழங்குகிறது.
    ///
    /// ஒரு [`Done`][SearchStep::Done] வரையிலான [`Match`][SearchStep::Match] மற்றும் [`Reject`][SearchStep::Reject] மதிப்புகளின் ஸ்ட்ரீம் அருகிலுள்ள குறியீட்டு வரம்புகளைக் கொண்டிருக்கும், ஒன்றுடன் ஒன்று இல்லாதது, முழு வைக்கோலை உள்ளடக்கியது மற்றும் utf8 எல்லைகளில் இடுவது.
    ///
    ///
    /// ஒரு [`Match`][SearchStep::Match] முடிவு முழு பொருந்திய வடிவத்தைக் கொண்டிருக்க வேண்டும், இருப்பினும் [`Reject`][SearchStep::Reject] முடிவுகள் தன்னிச்சையாக பல அருகிலுள்ள துண்டுகளாகப் பிரிக்கப்படலாம்.இரண்டு வரம்புகளும் பூஜ்ஜிய நீளத்தைக் கொண்டிருக்கலாம்.
    ///
    /// உதாரணமாக, `"aaa"` முறை மற்றும் வைக்கோல் `"cbaaaaab"` ஆகியவை ஸ்ட்ரீமை உருவாக்கக்கூடும்
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// அடுத்த [`Match`][SearchStep::Match] முடிவைக் காண்கிறது.[`next()`][Searcher::next] ஐப் பார்க்கவும்.
    ///
    /// [`next()`][Searcher::next] போலல்லாமல், இது மற்றும் [`next_reject`][Searcher::next_reject] இன் திரும்பிய வரம்புகள் ஒன்றுடன் ஒன்று இருக்கும் என்பதற்கு எந்த உத்தரவாதமும் இல்லை.
    /// இது `(start_match, end_match)` ஐத் தரும், அங்கு ஸ்டார்ட்_மாட்ச் என்பது போட்டி தொடங்கும் இடத்தின் குறியீடாகும், மற்றும் எண்ட்_மாட்ச் என்பது போட்டியின் முடிவிற்குப் பிறகு குறியீடாகும்.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// அடுத்த [`Reject`][SearchStep::Reject] முடிவைக் காண்கிறது.[`next()`][Searcher::next] மற்றும் [`next_match()`][Searcher::next_match] ஐப் பார்க்கவும்.
    ///
    /// [`next()`][Searcher::next] போலல்லாமல், இது மற்றும் [`next_match`][Searcher::next_match] இன் திரும்பிய வரம்புகள் ஒன்றுடன் ஒன்று இருக்கும் என்பதற்கு எந்த உத்தரவாதமும் இல்லை.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// சரம் வடிவத்திற்கான தலைகீழ் தேடுபவர்.
///
/// இந்த trait ஒரு சரத்தின் பின்புற (right) இலிருந்து தொடங்கி ஒரு வடிவத்தின் ஒன்றுடன் ஒன்று பொருந்தாத தேடல்களைத் தேடுவதற்கான முறைகளை வழங்குகிறது.
///
/// பின்புறம் அதைத் தேடுவதை முறை ஆதரித்தால், இது [`Pattern`] trait இன் தொடர்புடைய [`Searcher`] வகைகளால் செயல்படுத்தப்படும்.
///
///
/// இந்த trait ஆல் வழங்கப்பட்ட குறியீட்டு வரம்புகள் முன்னோக்கி தேடலின் தலைகீழாக சரியாக பொருந்த தேவையில்லை.
///
/// இந்த trait பாதுகாப்பற்றது எனக் குறிக்கப்படுவதற்கான காரணத்திற்காக, பெற்றோர் trait [`Searcher`] ஐப் பார்க்கவும்.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// பின்புறத்திலிருந்து தொடங்கி அடுத்த தேடல் படி செய்கிறது.
    ///
    /// - `haystack[a..b]` வடிவத்துடன் பொருந்தினால் [`Match(a, b)`][SearchStep::Match] ஐ வழங்குகிறது.
    /// - `haystack[a..b]` ஆனது பகுதியுடன் கூட பொருந்தவில்லை என்றால் [`Reject(a, b)`][SearchStep::Reject] ஐ வழங்குகிறது.
    /// - வைக்கோலின் ஒவ்வொரு பைட்டையும் பார்வையிட்டிருந்தால் [`Done`][SearchStep::Done] ஐ வழங்குகிறது
    ///
    /// ஒரு [`Done`][SearchStep::Done] வரையிலான [`Match`][SearchStep::Match] மற்றும் [`Reject`][SearchStep::Reject] மதிப்புகளின் ஸ்ட்ரீம் அருகிலுள்ள குறியீட்டு வரம்புகளைக் கொண்டிருக்கும், ஒன்றுடன் ஒன்று இல்லாதது, முழு வைக்கோலை உள்ளடக்கியது மற்றும் utf8 எல்லைகளில் இடுவது.
    ///
    ///
    /// ஒரு [`Match`][SearchStep::Match] முடிவு முழு பொருந்திய வடிவத்தைக் கொண்டிருக்க வேண்டும், இருப்பினும் [`Reject`][SearchStep::Reject] முடிவுகள் தன்னிச்சையாக பல அருகிலுள்ள துண்டுகளாகப் பிரிக்கப்படலாம்.இரண்டு வரம்புகளும் பூஜ்ஜிய நீளத்தைக் கொண்டிருக்கலாம்.
    ///
    /// உதாரணமாக, `"aaa"` மற்றும் வைக்கோல் `"cbaaaaab"` முறை `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// அடுத்த [`Match`][SearchStep::Match] முடிவைக் காண்கிறது.
    /// [`next_back()`][ReverseSearcher::next_back] ஐப் பார்க்கவும்.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// அடுத்த [`Reject`][SearchStep::Reject] முடிவைக் காண்கிறது.
    /// [`next_back()`][ReverseSearcher::next_back] ஐப் பார்க்கவும்.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// ஒரு [`ReverseSearcher`] ஒரு [`DoubleEndedIterator`] செயல்படுத்தலுக்கு பயன்படுத்தப்படலாம் என்பதை வெளிப்படுத்த trait என்ற மார்க்கர்.
///
/// இதற்காக, [`Searcher`] மற்றும் [`ReverseSearcher`] இன் impl இந்த நிபந்தனைகளைப் பின்பற்ற வேண்டும்:
///
/// - `next()` இன் அனைத்து முடிவுகளும் தலைகீழ் வரிசையில் `next_back()` இன் முடிவுகளுக்கு ஒத்ததாக இருக்க வேண்டும்.
/// - `next()` மற்றும் `next_back()` மதிப்புகளின் வரம்பின் இரண்டு முனைகளாக நடந்து கொள்ள வேண்டும், அதாவது அவை "walk past each other" முடியாது.
///
/// # Examples
///
/// `char::Searcher` ஒரு `DoubleEndedSearcher` ஆகும், ஏனெனில் ஒரு [`char`] ஐத் தேடுவதற்கு ஒரு நேரத்தில் ஒன்றை மட்டுமே பார்க்க வேண்டும், இது இரு முனைகளிலிருந்தும் ஒரே மாதிரியாக செயல்படுகிறது.
///
/// `(&str)::Searcher` இது ஒரு `DoubleEndedSearcher` அல்ல, ஏனென்றால் வைக்கோல் `"aaa"` இல் உள்ள `"aa"` முறை `"[aa]a"` அல்லது `"a[aa]"` உடன் பொருந்துகிறது, இது எந்தப் பக்கத்திலிருந்து தேடப்படுகிறது என்பதைப் பொறுத்து.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// கரிக்கான Impl
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` க்கான தொடர்புடைய வகை.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // பாதுகாப்பு மாறுபாடு: `finger`/`finger_back` என்பது `haystack` இன் செல்லுபடியாகும் utf8 பைட் குறியீடாக இருக்க வேண்டும். இந்த மாற்றத்தை * அடுத்த_மாட்ச் மற்றும் அடுத்த_மாட்ச்_பேக்கிற்குள் உடைக்க முடியும், இருப்பினும் அவை சரியான குறியீடு புள்ளி எல்லைகளில் விரல்களால் வெளியேற வேண்டும்.
    //
    //
    /// `finger` முன்னோக்கி தேடலின் தற்போதைய பைட் குறியீடாகும்.
    /// அதன் குறியீட்டில் பைட்டுக்கு முன் அது இருக்கிறது என்று கற்பனை செய்து பாருங்கள், அதாவது
    /// `haystack[finger]` முன்னோக்கி தேடலின் போது நாம் ஆய்வு செய்ய வேண்டிய துண்டுகளின் முதல் பைட் ஆகும்
    ///
    finger: usize,
    /// `finger_back` தலைகீழ் தேடலின் தற்போதைய பைட் குறியீடாகும்.
    /// அதன் குறியீட்டில் பைட்டுக்குப் பிறகு அது இருக்கிறது என்று கற்பனை செய்து பாருங்கள், அதாவது
    /// வைக்கோல் [ஃபிங்கர்_பேக், 1] என்பது ஸ்லைஸின் கடைசி பைட் ஆகும், இது முன்னோக்கி தேடலின் போது நாம் ஆய்வு செய்ய வேண்டும் (இதனால் next_back()) ஐ அழைக்கும் போது ஆய்வு செய்யப்படும் முதல் பைட்.
    ///
    finger_back: usize,
    /// தேடப்படும் பாத்திரம்
    needle: char,

    // பாதுகாப்பு மாறுபாடு: `utf8_size` 5 க்கும் குறைவாக இருக்க வேண்டும்
    /// utf8 இல் குறியாக்கம் செய்யப்படும்போது `needle` பைட்டுகளின் எண்ணிக்கை எடுக்கும்.
    utf8_size: usize,
    /// `needle` இன் utf8 குறியிடப்பட்ட நகல்
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // பாதுகாப்பு: `get_unchecked` இன் 1-4 உத்தரவாத பாதுகாப்பு
        // 1. `self.finger` மற்றும் `self.finger_back` யூனிகோட் எல்லைகளில் வைக்கப்படுகின்றன (இது மாறாதது)
        // 2. `self.finger >= 0` இது 0 இல் தொடங்கி அதிகரிக்கிறது என்பதால்
        // 3. `self.finger < self.finger_back` ஏனெனில் இல்லையெனில் கரி `iter` `SearchStep::Done` ஐ வழங்கும்
        // 4.
        // `self.finger` `self.finger_back` இறுதியில் தொடங்கி மட்டுமே குறைகிறது என்பதால் வைக்கோலின் முடிவிற்கு முன் வருகிறது
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 என மறு குறியாக்கம் செய்யாமல் தற்போதைய எழுத்தின் பைட் ஆஃப்செட்டைச் சேர்க்கவும்
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // கடைசி எழுத்துக்குறி கிடைத்த பிறகு வைக்கோலைப் பெறுங்கள்
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 குறியாக்கப்பட்ட ஊசியின் கடைசி பைட் பாதுகாப்பானது: எங்களிடம் `utf8_size < 5` என்று ஒரு மாற்றம் உள்ளது
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // புதிய விரல் என்பது நாம் கண்டறிந்த பைட்டின் குறியீடாகும், மேலும் ஒன்று, பாத்திரத்தின் கடைசி பைட்டுக்கு நாங்கள் நினைவில் வைத்திருக்கிறோம்.
                //
                // இது எப்போதும் UTF8 எல்லையில் ஒரு விரலைக் கொடுக்காது என்பதை நினைவில் கொள்க.
                // எங்கள் எழுத்தை * கண்டுபிடிக்கவில்லை எனில், 3 பைட் அல்லது 4-பைட் எழுத்தின் கடைசி அல்லாத பைட்டுக்கு நாம் குறியிடப்பட்டிருக்கலாம்.
                // Valid (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` போன்ற ஒரு எழுத்து மூன்றாவது தேடும்போது எப்போதும் இரண்டாவது பைட்டைக் கண்டுபிடிக்கும் என்பதால் அடுத்த செல்லுபடியாகும் தொடக்க பைட்டுக்கு நாம் தவிர்க்க முடியாது.
                //
                //
                // இருப்பினும், இது முற்றிலும் பரவாயில்லை.
                // self.finger ஒரு UTF8 எல்லையில் உள்ளது என்ற மாற்றத்தை நம்மிடம் கொண்டிருக்கும்போது, இந்த முறை இந்த முறைக்குள் நம்பப்படவில்லை (இது CharSearcher::next()) இல் நம்பப்படுகிறது.
                //
                // நாம் சரத்தின் முடிவை எட்டும்போது அல்லது ஏதாவது ஒன்றைக் கண்டால் மட்டுமே இந்த முறையிலிருந்து வெளியேறுகிறோம்.எதையாவது கண்டுபிடிக்கும்போது `finger` ஒரு UTF8 எல்லைக்கு அமைக்கப்படும்.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // எதுவும் கிடைக்கவில்லை, வெளியேறு
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // தேடுபவர் trait இலிருந்து இயல்புநிலை செயலாக்கத்தைப் பயன்படுத்த அடுத்த_அறிவிப்போம்
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // பாதுகாப்பு: மேலே உள்ள next() க்கான கருத்தைப் பார்க்கவும்
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // utf-8 என மறு குறியாக்கம் செய்யாமல் தற்போதைய எழுத்தின் பைட் ஆஃப்செட்டைக் கழிக்கவும்
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // தேடப்பட்ட கடைசி எழுத்தை உள்ளடக்கியது அல்ல, ஆனால் வைக்கோலைப் பெறுங்கள்
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 குறியாக்கப்பட்ட ஊசியின் கடைசி பைட் பாதுகாப்பானது: எங்களிடம் `utf8_size < 5` என்று ஒரு மாற்றம் உள்ளது
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // self.finger ஆல் ஈடுசெய்யப்பட்ட ஒரு துண்டைத் தேடினோம், அசல் குறியீட்டை மீட்டெடுக்க self.finger ஐச் சேர்க்கவும்
                //
                let index = self.finger + index;
                // நாம் கண்டுபிடிக்க விரும்பும் பைட்டின் குறியீட்டை memrchr வழங்கும்.
                // ஒரு ஆஸ்கி கதாபாத்திரத்தைப் பொறுத்தவரை, இது எங்கள் புதிய விரலாக இருக்க வேண்டும் என்று நாங்கள் விரும்புகிறோம் (தலைகீழ் மறு செய்கையின் முன்னுதாரணத்தில் "after" காணப்படும் கரி).
                //
                // மல்டிபைட் எழுத்துகளுக்கு, ASCII ஐ விட அதிகமான பைட்டுகளின் எண்ணிக்கையை நாம் தவிர்க்க வேண்டும்
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // எழுத்து கண்டுபிடிக்கும் முன் விரலை நகர்த்தவும் (அதாவது, அதன் தொடக்க குறியீட்டில்)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // நாம் இங்கே விரல்_பேக்=குறியீட்டு, அளவு + 1 ஐப் பயன்படுத்த முடியாது.
                // வேறொரு அளவிலான கதாபாத்திரத்தின் கடைசி எரிப்பைக் கண்டறிந்தால் (அல்லது வேறு எழுத்தின் நடுத்தர பைட்) நாம் விரல்_பக்கத்தை `index` க்கு கீழே தள்ள வேண்டும்.
                // இது இதேபோல் `finger_back` இனி ஒரு எல்லையில் இருக்க வாய்ப்பில்லை, ஆனால் இந்த செயல்பாட்டை ஒரு எல்லையில் மட்டுமே நாங்கள் வெளியேறுவதால் அல்லது வைக்கோல் முழுமையாக தேடப்படும் போது இது சரி.
                //
                //
                // அடுத்த_மாட்சைப் போலல்லாமல், இது utf-8 இல் மீண்டும் மீண்டும் பைட்டுகளின் சிக்கலைக் கொண்டிருக்கவில்லை, ஏனெனில் நாங்கள் கடைசி பைட்டைத் தேடுகிறோம், தலைகீழாகத் தேடும்போது மட்டுமே கடைசி பைட்டைக் கண்டுபிடித்திருக்க முடியும்.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // எதுவும் கிடைக்கவில்லை, வெளியேறு
                return None;
            }
        }
    }

    // தேடுபவர் trait இலிருந்து இயல்புநிலை செயலாக்கத்தைப் பயன்படுத்த அடுத்த_அறிவிப்பு_பேக்கை அனுமதிக்கவும்
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// கொடுக்கப்பட்ட [`char`] க்கு சமமான எழுத்துகளுக்கான தேடல்கள்.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// மல்டிகார்எக் ரேப்பருக்கான Impl
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // தற்போதைய கரியின் நீளத்தைக் கண்டறிய உள் பைட் ஸ்லைஸ் ஐரேட்டரின் நீளங்களை ஒப்பிடுக
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // தற்போதைய கரியின் நீளத்தைக் கண்டறிய உள் பைட் ஸ்லைஸ் ஐரேட்டரின் நீளங்களை ஒப்பிடுக
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// &[கரி]
/////////////////////////////////////////////////////////////////////////////

// Todo: அர்த்தத்தில் தெளிவின்மை காரணமாக மாற்றவும்/அகற்று.

/// `<&[char] as Pattern<'a>>::Searcher` க்கான தொடர்புடைய வகை.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// ஸ்லைஸில் உள்ள எந்த [`கரி`] களுக்கும் சமமான எழுத்துகளுக்கான தேடல்கள்.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// F: FnMut(char)-> bool க்கான Impl
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` க்கான தொடர்புடைய வகை.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// கொடுக்கப்பட்ட முன்கணிப்புடன் பொருந்தக்கூடிய [`கரி`] க்கான தேடல்கள்.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&str க்கான Impl
/////////////////////////////////////////////////////////////////////////////

/// `&str` impl க்கு பிரதிநிதிகள்.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str க்கான Impl
/////////////////////////////////////////////////////////////////////////////

/// ஒதுக்காத மூலக்கூறு தேடல்.
///
/// ஒவ்வொரு எழுத்துக்குறி எல்லையிலும் வெற்று போட்டிகளைத் திருப்புவது போல் `""` வடிவத்தைக் கையாளும்.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// வைக்கோலின் முன்புறத்தில் முறை பொருந்துமா என்பதை சரிபார்க்கிறது.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// பொருந்தினால், வைக்கோலின் முன்னால் இருந்து அமைப்பை நீக்குகிறது.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // பாதுகாப்பு: முன்னொட்டு இருப்பதை சரிபார்க்கப்பட்டது.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// வைக்கோலின் பின்புறத்தில் முறை பொருந்துமா என்பதை சரிபார்க்கிறது.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// பொருந்தினால், வைக்கோலின் பின்புறத்திலிருந்து அமைப்பை நீக்குகிறது.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // பாதுகாப்பு: பின்னொட்டு இருப்பதை சரிபார்க்கப்பட்டது.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// டூ வே சப்ஸ்ட்ரிங் தேடுபவர்
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` க்கான தொடர்புடைய வகை.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // வெற்று ஊசி ஒவ்வொரு எரிப்பையும் நிராகரிக்கிறது மற்றும் அவற்றுக்கிடையேயான ஒவ்வொரு வெற்று சரத்திற்கும் பொருந்துகிறது
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher சரியான பொருத்தம் இருக்கும் வரை கரி எல்லைகளில் பிரிக்கும் செல்லுபடியாகும் *போட்டி* குறியீடுகளை உருவாக்குகிறது மற்றும் வைக்கோல் மற்றும் ஊசி செல்லுபடியாகும் UTF-8 * வழிமுறையிலிருந்து எந்த நிராகரிப்பும் எந்த குறியீடுகளிலும் விழக்கூடும், ஆனால் அவற்றை அடுத்த எழுத்துக்குறி எல்லைக்கு கைமுறையாக நடத்துவோம், அதனால் அவை utf-8 பாதுகாப்பானவை.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // அடுத்த கரி எல்லைக்குச் செல்லவும்
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // இரண்டு நிகழ்வுகளையும் தனித்தனியாக நிபுணத்துவம் செய்ய தொகுப்பாளரை ஊக்குவிக்க `true` மற்றும் `false` வழக்குகளை எழுதுங்கள்.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // அடுத்த கரி எல்லைக்குச் செல்லவும்
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `next_match` போன்ற `true` மற்றும் `false` ஐ எழுதுங்கள்
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// இரு வழி மூலக்கூறு தேடல் வழிமுறையின் உள் நிலை.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// முக்கியமான காரணிமயமாக்கல் அட்டவணை
    crit_pos: usize,
    /// தலைகீழ் ஊசிக்கான முக்கியமான காரணிமயமாக்கல் குறியீடு
    crit_pos_back: usize,
    period: usize,
    /// `byteset` ஒரு நீட்டிப்பு (இரு வழி வழிமுறையின் ஒரு பகுதி அல்ல);
    /// இது ஒரு 64-பிட் "fingerprint" ஆகும், அங்கு ஒவ்வொரு செட் பிட் `j` ஒரு (பைட்&63)==j ஊசியில் இருக்கும்.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// நாம் ஏற்கனவே பொருந்திய ஊசிக்குள் குறியீட்டு
    memory: usize,
    /// நாம் ஏற்கனவே பொருந்திய ஊசிக்குள் குறியீட்டு
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // இங்கே என்ன நடக்கிறது என்பதற்கான குறிப்பாக படிக்கக்கூடிய விளக்கத்தை குரோச்மோர் மற்றும் ரைட்டரின் புத்தகம் "Text Algorithms", ch 13 இல் காணலாம்.
        // ப. இல் "Algorithm CP" க்கான குறியீட்டைக் காண்க.
        // 323.
        //
        // என்ன நடக்கிறது என்பது நமக்கு ஊசியின் சில முக்கியமான காரணி (u, v) உள்ளது, மேலும் u&v [.. period] இன் பின்னொட்டு என்பதை நாங்கள் தீர்மானிக்க விரும்புகிறோம்.
        // அது இருந்தால், நாங்கள் "Algorithm CP1" ஐப் பயன்படுத்துகிறோம்.
        // இல்லையெனில் நாம் "Algorithm CP2" ஐப் பயன்படுத்துகிறோம், இது ஊசியின் காலம் பெரிதாக இருக்கும்போது உகந்ததாக இருக்கும்.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // குறுகிய கால வழக்கு-காலம் என்பது தலைகீழ் ஊசிக்கு ஒரு தனி முக்கியமான காரணிமயமாக்கலை கணக்கிடுவது x=u 'v' எங்கே | v '|<period(x).
            //
            // இது ஏற்கனவே அறியப்பட்ட காலத்தால் துரிதப்படுத்தப்படுகிறது.
            // X= "acba" போன்ற ஒரு வழக்கு தலைகீழாக (விமர்சன_போஸ்=2, காலம்=2) தோராயமான காலத்துடன் காரணியாக இருக்கும்போது சரியாக முன்னோக்கி (விமர்சன_போஸ்=1, காலம்=3) காரணியாக இருக்கலாம் என்பதை நினைவில் கொள்க.
            // கொடுக்கப்பட்ட தலைகீழ் காரணிமயமாக்கலை நாங்கள் பயன்படுத்துகிறோம், ஆனால் சரியான காலத்தை வைத்திருக்கிறோம்.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // நீண்ட கால வழக்கு-உண்மையான காலத்திற்கு ஒரு தோராயத்தைக் கொண்டிருக்கிறோம், மேலும் மனப்பாடம் செய்ய வேண்டாம்.
            //
            //
            // குறைந்த வரம்புக்குட்பட்ட max(|u|, |v|) + 1 மூலம் காலத்தை தோராயமாக மதிப்பிடுங்கள்.
            // முன்னோக்கி மற்றும் தலைகீழ் தேடலுக்குப் பயன்படுத்த முக்கியமான காரணிமயமாக்கல் திறமையானது.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // காலம் நீளமானது என்பதைக் குறிக்க போலி மதிப்பு
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // டூ-வேவின் முக்கிய யோசனைகளில் ஒன்று, நாம் ஊசியை இரண்டு பகுதிகளாக (u, v) காரணியாகக் கொண்டு, இடமிருந்து வலமாக ஸ்கேன் செய்வதன் மூலம் வைக்கோலில் v ஐக் கண்டுபிடிக்க முயற்சிக்கிறோம்.
    // V பொருந்தினால், வலமிருந்து இடமாக ஸ்கேன் செய்வதன் மூலம் u ஐ பொருத்த முயற்சிக்கிறோம்.
    // ஒரு பொருத்தமின்மையை எதிர்கொள்ளும்போது நாம் எவ்வளவு தூரம் செல்ல முடியும் (u, v) என்பது ஊசிக்கு ஒரு முக்கியமான காரணியாகும்.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` ஐ அதன் கர்சராகப் பயன்படுத்துகிறது
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // நிலையில் தேட எங்களுக்கு இடம் இருக்கிறதா என்று சரிபார்க்கவும் + துண்டுகள் ஐசைஸின் வரம்பால் கட்டுப்படுத்தப்படுகின்றன என்று கருதினால் ஊசி_லாஸ்ட் நிரம்பி வழிய முடியாது.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // எங்கள் மூலக்கூறுடன் தொடர்பில்லாத பெரிய பகுதிகளை விரைவாகத் தவிர்க்கவும்
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // ஊசியின் வலது பகுதி பொருந்துமா என்று பாருங்கள்
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // ஊசியின் இடது பகுதி பொருந்துமா என்று பாருங்கள்
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // ஒரு போட்டியைக் கண்டுபிடித்தோம்!
            let match_pos = self.position;

            // Note: ஒன்றுடன் ஒன்று பொருத்தங்களைக் கொண்டிருக்க needle.len() க்கு பதிலாக self.period ஐச் சேர்க்கவும்
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // ஒன்றுடன் ஒன்று போட்டிகளுக்கு needle.len(), self.period என அமைக்கவும்
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()` இல் உள்ள யோசனைகளைப் பின்பற்றுகிறது.
    //
    // வரையறைகள் சமச்சீர், period(x) = period(reverse(x)) மற்றும் local_period(u, v) = local_period(reverse(v), reverse(u)), எனவே (u, v) ஒரு முக்கியமான காரணியாக இருந்தால், (reverse(v), reverse(u)).
    //
    //
    // தலைகீழ் வழக்குக்கு x=u 'v' (புலம் `crit_pos_back`) ஒரு முக்கியமான காரணிமயமாக்கலை கணக்கிட்டுள்ளோம்.எங்களுக்கு வேண்டும் | u |முன்னோக்கி வழக்குக்கு <period(x) மற்றும் இதனால் | v '|தலைகீழ் <period(x).
    //
    // வைக்கோல் வழியாக தலைகீழாக தேட, தலைகீழ் ஊசி மூலம் தலைகீழ் வைக்கோல் மூலம் முன்னோக்கி தேடுகிறோம், முதலில் u 'மற்றும் பின்னர் v' உடன் பொருந்தும்.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` ஐ அதன் கர்சராகப் பயன்படுத்துகிறது-இதனால் `next()` மற்றும் `next_back()` ஆகியவை சுயாதீனமாக இருக்கும்.
        //
        let old_end = self.end;
        'search: loop {
            // முடிவில் தேட எங்களுக்கு இடம் இருக்கிறதா என்று சரிபார்க்கவும், அதிக இடம் இல்லாதபோது needle.len() சுற்றிக் கொள்ளும், ஆனால் ஸ்லைஸ் நீள வரம்புகள் காரணமாக அது ஒருபோதும் வைக்கோலின் நீளத்திற்கு மடிக்க முடியாது.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // எங்கள் மூலக்கூறுடன் தொடர்பில்லாத பெரிய பகுதிகளை விரைவாகத் தவிர்க்கவும்
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // ஊசியின் இடது பகுதி பொருந்துமா என்று பாருங்கள்
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // ஊசியின் வலது பகுதி பொருந்துமா என்று பாருங்கள்
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // ஒரு போட்டியைக் கண்டுபிடித்தோம்!
            let match_pos = self.end - needle.len();
            // Note: ஒன்றுடன் ஒன்று பொருந்தக்கூடிய needle.len() க்கு பதிலாக துணை self.period
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` இன் அதிகபட்ச பின்னொட்டைக் கணக்கிடுங்கள்.
    //
    // அதிகபட்ச பின்னொட்டு என்பது `arr` இன் சாத்தியமான முக்கியமான காரணிமயமாக்கல் (u, v) ஆகும்.
    //
    // ரிட்டர்ன்ஸ் (`i`, `p`), அங்கு `i` என்பது v இன் தொடக்க குறியீடாகும் மற்றும் `p` என்பது v இன் காலம்.
    //
    // `order_greater` லெக்சிகல் ஆர்டர் `<` அல்லது `>` என்பதை தீர்மானிக்கிறது.
    // இரண்டு ஆர்டர்களும் கணக்கிடப்பட வேண்டும்-மிகப்பெரிய `i` உடன் வரிசைப்படுத்துவது ஒரு முக்கியமான காரணியாக்கத்தை அளிக்கிறது.
    //
    //
    // நீண்ட கால நிகழ்வுகளுக்கு, இதன் விளைவாக காலம் சரியாக இல்லை (இது மிகக் குறைவு).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // காகிதத்தில் நான் தொடர்புடையது
        let mut right = 1; // காகிதத்தில் j உடன் ஒத்துள்ளது
        let mut offset = 0; // காகிதத்தில் k உடன் ஒத்துள்ளது, ஆனால் 0 இல் தொடங்குகிறது
        // 0 அடிப்படையிலான குறியீட்டுடன் பொருந்த.
        let mut period = 1; // காகிதத்தில் p உடன் ஒத்துள்ளது

        while let Some(&a) = arr.get(right + offset) {
            // `left` `right` இருக்கும்போது உள்வரும்.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // பின்னொட்டு சிறியது, காலம் இதுவரை முழு முன்னொட்டு.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // தற்போதைய காலத்தை மீண்டும் செய்வதன் மூலம் முன்னேற்றம்.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // பின்னொட்டு பெரியது, தற்போதைய இடத்திலிருந்து தொடங்கவும்.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` இன் தலைகீழ் அதிகபட்ச பின்னொட்டைக் கணக்கிடுங்கள்.
    //
    // அதிகபட்ச பின்னொட்டு என்பது `arr` இன் சாத்தியமான முக்கியமான காரணிமயமாக்கல் (u ', v') ஆகும்.
    //
    // `i` ஐ வழங்குகிறது, அங்கு `i` என்பது வி 'இன் தொடக்க குறியீடாகும், பின்னால் இருந்து;
    // `known_period` காலத்தை எட்டியவுடன் உடனடியாக திரும்பும்.
    //
    // `order_greater` லெக்சிகல் ஆர்டர் `<` அல்லது `>` என்பதை தீர்மானிக்கிறது.
    // இரண்டு ஆர்டர்களும் கணக்கிடப்பட வேண்டும்-மிகப்பெரிய `i` உடன் வரிசைப்படுத்துவது ஒரு முக்கியமான காரணியாக்கத்தை அளிக்கிறது.
    //
    //
    // நீண்ட கால நிகழ்வுகளுக்கு, இதன் விளைவாக காலம் சரியாக இல்லை (இது மிகக் குறைவு).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // காகிதத்தில் நான் தொடர்புடையது
        let mut right = 1; // காகிதத்தில் j உடன் ஒத்துள்ளது
        let mut offset = 0; // காகிதத்தில் k உடன் ஒத்துள்ளது, ஆனால் 0 இல் தொடங்குகிறது
        // 0 அடிப்படையிலான குறியீட்டுடன் பொருந்த.
        let mut period = 1; // காகிதத்தில் p உடன் ஒத்துள்ளது
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // பின்னொட்டு சிறியது, காலம் இதுவரை முழு முன்னொட்டு.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // தற்போதைய காலத்தை மீண்டும் செய்வதன் மூலம் முன்னேற்றம்.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // பின்னொட்டு பெரியது, தற்போதைய இடத்திலிருந்து தொடங்கவும்.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy ஆனது வழிமுறைகளை சீக்கிரம் பொருத்தமற்றதைத் தவிர்க்க அல்லது ஒப்பீட்டளவில் விரைவாக நிராகரிப்பை வெளியிடும் பயன்முறையில் வேலை செய்ய அனுமதிக்கிறது.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// இடைவெளிகளை விரைவில் பொருத்த தவிர்க்கவும்
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// தவறாமல் நிராகரிக்கிறது
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}