//! சரம் கையாளுதல்.
//!
//! மேலும் விவரங்களுக்கு, [`std::str`] தொகுதியைப் பார்க்கவும்.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. எல்லைக்கு வெளியே
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. தொடங்கு <=முடிவு
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. எழுத்து எல்லை
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // பாத்திரத்தைக் கண்டுபிடி
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` லென் மற்றும் கரி எல்லையை விட குறைவாக இருக்க வேண்டும்
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` இன் நீளத்தை வழங்குகிறது.
    ///
    /// இந்த நீளம் பைட்டுகளில் உள்ளது, [`கரி`] அல்லது கிராபீம்கள் அல்ல.
    /// வேறு வார்த்தைகளில் கூறுவதானால், சரத்தின் நீளத்தை ஒரு மனிதன் கருதுவது இதுவல்ல.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // ஆடம்பரமான எஃப்!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `self` பூஜ்ஜிய பைட்டுகளின் நீளம் இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// `இன்டெக்ஸ்`-வது பைட் என்பது UTF-8 குறியீடு புள்ளி வரிசையில் அல்லது சரத்தின் முடிவில் முதல் பைட் என்பதை சரிபார்க்கிறது.
    ///
    ///
    /// சரத்தின் தொடக்கமும் முடிவும் (`குறியீட்டு== self.len()`) எல்லைகளாகக் கருதப்படும் போது.
    ///
    /// `index` `self.len()` ஐ விட அதிகமாக இருந்தால் `false` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` இன் தொடக்க
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` இன் இரண்டாவது பைட்
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` இன் மூன்றாவது பைட்
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 மற்றும் லென் எப்போதும் சரி.
        // 0 ஐ வெளிப்படையாக சோதிக்கவும், இதனால் காசோலையை எளிதில் மேம்படுத்தலாம் மற்றும் அந்த வழக்கிற்கான சரம் தரவைப் படிப்பதைத் தவிர்க்கலாம்.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // இது பிட் மேஜிக் சமம்: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// ஒரு சரம் துண்டுகளை பைட் துண்டுக்கு மாற்றுகிறது.
    /// பைட் துண்டுகளை மீண்டும் சரம் துண்டுகளாக மாற்ற, [`from_utf8`] செயல்பாட்டைப் பயன்படுத்தவும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // பாதுகாப்பு: ஒரே மாதிரியான அமைப்பைக் கொண்டு இரண்டு வகைகளை மாற்றுவதால், ஒலி ஒலி
        unsafe { mem::transmute(self) }
    }

    /// மாற்றக்கூடிய சரம் துண்டுகளை மாற்றக்கூடிய பைட் துண்டுக்கு மாற்றுகிறது.
    ///
    /// # Safety
    ///
    /// கடன் முடிவடைவதற்கு முன்னர், துண்டின் உள்ளடக்கம் செல்லுபடியாகும் UTF-8 என்பதை அழைப்பாளர் உறுதிப்படுத்த வேண்டும் மற்றும் அடிப்படை `str` பயன்படுத்தப்படுகிறது.
    ///
    ///
    /// `str` இன் உள்ளடக்கங்கள் செல்லுபடியாகாத UTF-8 இன் பயன்பாடு வரையறுக்கப்படாத நடத்தை.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // பாதுகாப்பு: `str` முதல் `&str` முதல் `&[u8]` வரையிலான நடிகர்கள் பாதுகாப்பாக உள்ளனர்
        // `&[u8]` போன்ற அமைப்பைக் கொண்டுள்ளது (libstd மட்டுமே இந்த உத்தரவாதத்தை அளிக்க முடியும்).
        // சுட்டிக்காட்டி விலகல் பாதுகாப்பானது, ஏனெனில் இது ஒரு மாற்றத்தக்க குறிப்பிலிருந்து வருகிறது, இது எழுத்துக்களுக்கு செல்லுபடியாகும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// ஒரு சரம் துண்டுகளை மூல சுட்டிக்காட்டிக்கு மாற்றுகிறது.
    ///
    /// சரம் துண்டுகள் பைட்டுகளின் துண்டு என்பதால், மூல சுட்டிக்காட்டி ஒரு [`u8`] ஐ சுட்டிக்காட்டுகிறது.
    /// இந்த சுட்டிக்காட்டி சரம் துண்டின் முதல் பைட்டை சுட்டிக்காட்டும்.
    ///
    /// திரும்பிய சுட்டிக்காட்டி ஒருபோதும் எழுதப்படவில்லை என்பதை அழைப்பாளர் உறுதிப்படுத்த வேண்டும்.
    /// நீங்கள் சரம் துண்டுகளின் உள்ளடக்கங்களை மாற்ற வேண்டும் என்றால், [`as_mut_ptr`] ஐப் பயன்படுத்தவும்.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// மாற்றக்கூடிய சரம் துண்டுகளை மூல சுட்டிக்காட்டிக்கு மாற்றுகிறது.
    ///
    /// சரம் துண்டுகள் பைட்டுகளின் துண்டு என்பதால், மூல சுட்டிக்காட்டி ஒரு [`u8`] ஐ சுட்டிக்காட்டுகிறது.
    /// இந்த சுட்டிக்காட்டி சரம் துண்டின் முதல் பைட்டை சுட்டிக்காட்டும்.
    ///
    /// சரம் துண்டு செல்லுபடியாகும் UTF-8 ஆக இருக்கும் வகையில் மட்டுமே மாற்றியமைக்கப்படுவதை உறுதி செய்வது உங்கள் பொறுப்பு.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` இன் சந்தாவை வழங்குகிறது.
    ///
    /// இது `str` ஐ அட்டவணையிடுவதற்கு பீதியற்ற மாற்றாகும்.
    /// சமமான அட்டவணைப்படுத்தல் செயல்பாடு panic ஆக இருக்கும்போதெல்லாம் [`None`] ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // குறியீடுகள் UTF-8 வரிசை எல்லைகளில் இல்லை
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // எல்லைக்கு வெளியே
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` இன் மாற்றக்கூடிய சந்தாவை வழங்குகிறது.
    ///
    /// இது `str` ஐ அட்டவணையிடுவதற்கு பீதியற்ற மாற்றாகும்.
    /// சமமான அட்டவணைப்படுத்தல் செயல்பாடு panic ஆக இருக்கும்போதெல்லாம் [`None`] ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // சரியான நீளம்
    /// assert!(v.get_mut(0..5).is_some());
    /// // எல்லைக்கு வெளியே
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` இன் தேர்வு செய்யப்படாத சந்தாவை வழங்குகிறது.
    ///
    /// இது `str` ஐ அட்டவணைப்படுத்துவதற்கான தேர்வு செய்யப்படாத மாற்றாகும்.
    ///
    /// # Safety
    ///
    /// இந்த முன் நிபந்தனைகள் திருப்தி அடைவதற்கு இந்த செயல்பாட்டின் அழைப்பாளர்கள் பொறுப்பு:
    ///
    /// * தொடக்கக் குறியீடு முடிவடையும் குறியீட்டை விட அதிகமாக இருக்கக்கூடாது;
    /// * குறியீடுகள் அசல் துண்டின் எல்லைக்குள் இருக்க வேண்டும்;
    /// * குறியீடுகள் UTF-8 வரிசை எல்லைகளில் இருக்க வேண்டும்.
    ///
    /// தோல்வியுற்றால், திரும்பிய சரம் துண்டு தவறான நினைவகத்தைக் குறிக்கலாம் அல்லது `str` வகையால் தொடர்பு கொள்ளப்பட்ட மாற்றங்களை மீறும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // பாதுகாப்பு: அழைப்பாளர் `get_unchecked` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்;
        // `self` ஒரு பாதுகாப்பான குறிப்பு என்பதால், துண்டு துண்டிக்க முடியாதது.
        // திரும்பிய சுட்டிக்காட்டி பாதுகாப்பானது, ஏனெனில் `SliceIndex` இன் impls அது என்று உத்தரவாதம் அளிக்க வேண்டும்.
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` இன் மாற்றக்கூடிய, தேர்வு செய்யப்படாத சந்தாவை வழங்குகிறது.
    ///
    /// இது `str` ஐ அட்டவணைப்படுத்துவதற்கான தேர்வு செய்யப்படாத மாற்றாகும்.
    ///
    /// # Safety
    ///
    /// இந்த முன் நிபந்தனைகள் திருப்தி அடைவதற்கு இந்த செயல்பாட்டின் அழைப்பாளர்கள் பொறுப்பு:
    ///
    /// * தொடக்கக் குறியீடு முடிவடையும் குறியீட்டை விட அதிகமாக இருக்கக்கூடாது;
    /// * குறியீடுகள் அசல் துண்டின் எல்லைக்குள் இருக்க வேண்டும்;
    /// * குறியீடுகள் UTF-8 வரிசை எல்லைகளில் இருக்க வேண்டும்.
    ///
    /// தோல்வியுற்றால், திரும்பிய சரம் துண்டு தவறான நினைவகத்தைக் குறிக்கலாம் அல்லது `str` வகையால் தொடர்பு கொள்ளப்பட்ட மாற்றங்களை மீறும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // பாதுகாப்பு: அழைப்பாளர் `get_unchecked_mut` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்;
        // `self` ஒரு பாதுகாப்பான குறிப்பு என்பதால், துண்டு துண்டிக்க முடியாதது.
        // திரும்பிய சுட்டிக்காட்டி பாதுகாப்பானது, ஏனெனில் `SliceIndex` இன் impls அது என்று உத்தரவாதம் அளிக்க வேண்டும்.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// பாதுகாப்பு சோதனைகளைத் தவிர்த்து, மற்றொரு சரம் துண்டுகளிலிருந்து ஒரு சரம் துண்டுகளை உருவாக்குகிறது.
    ///
    /// இது பொதுவாக பரிந்துரைக்கப்படவில்லை, எச்சரிக்கையுடன் பயன்படுத்தவும்!பாதுகாப்பான மாற்றாக [`str`] மற்றும் [`Index`] ஐப் பார்க்கவும்.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// இந்த புதிய துண்டு `begin` முதல் `end` வரை செல்கிறது, இதில் `begin` உட்பட `end` தவிர.
    ///
    /// அதற்கு பதிலாக மாற்றக்கூடிய சரம் துண்டுகளைப் பெற, [`slice_mut_unchecked`] முறையைப் பார்க்கவும்.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// இந்த செயல்பாட்டின் அழைப்பாளர்கள் மூன்று முன் நிபந்தனைகள் திருப்தி அடைவதற்கு பொறுப்பு:
    ///
    /// * `begin` `end` ஐ விட அதிகமாக இருக்கக்கூடாது.
    /// * `begin` மற்றும் `end` சரம் துண்டுக்குள் பைட் நிலைகளாக இருக்க வேண்டும்.
    /// * `begin` மற்றும் `end` UTF-8 வரிசை எல்லைகளில் இருக்க வேண்டும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // பாதுகாப்பு: அழைப்பாளர் `get_unchecked` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்;
        // `self` ஒரு பாதுகாப்பான குறிப்பு என்பதால், துண்டு துண்டிக்க முடியாதது.
        // திரும்பிய சுட்டிக்காட்டி பாதுகாப்பானது, ஏனெனில் `SliceIndex` இன் impls அது என்று உத்தரவாதம் அளிக்க வேண்டும்.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// பாதுகாப்பு சோதனைகளைத் தவிர்த்து, மற்றொரு சரம் துண்டுகளிலிருந்து ஒரு சரம் துண்டுகளை உருவாக்குகிறது.
    /// இது பொதுவாக பரிந்துரைக்கப்படவில்லை, எச்சரிக்கையுடன் பயன்படுத்தவும்!பாதுகாப்பான மாற்றாக [`str`] மற்றும் [`IndexMut`] ஐப் பார்க்கவும்.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// இந்த புதிய துண்டு `begin` முதல் `end` வரை செல்கிறது, இதில் `begin` உட்பட `end` தவிர.
    ///
    /// அதற்கு பதிலாக மாறாத சரம் துண்டுகளைப் பெற, [`slice_unchecked`] முறையைப் பார்க்கவும்.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// இந்த செயல்பாட்டின் அழைப்பாளர்கள் மூன்று முன் நிபந்தனைகள் திருப்தி அடைவதற்கு பொறுப்பு:
    ///
    /// * `begin` `end` ஐ விட அதிகமாக இருக்கக்கூடாது.
    /// * `begin` மற்றும் `end` சரம் துண்டுக்குள் பைட் நிலைகளாக இருக்க வேண்டும்.
    /// * `begin` மற்றும் `end` UTF-8 வரிசை எல்லைகளில் இருக்க வேண்டும்.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // பாதுகாப்பு: அழைப்பாளர் `get_unchecked_mut` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்;
        // `self` ஒரு பாதுகாப்பான குறிப்பு என்பதால், துண்டு துண்டிக்க முடியாதது.
        // திரும்பிய சுட்டிக்காட்டி பாதுகாப்பானது, ஏனெனில் `SliceIndex` இன் impls அது என்று உத்தரவாதம் அளிக்க வேண்டும்.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// ஒரு குறியீட்டில் ஒரு சரம் துண்டுகளை இரண்டாக பிரிக்கவும்.
    ///
    /// `mid` என்ற வாதம் சரத்தின் தொடக்கத்திலிருந்து ஒரு பைட் ஆஃப்செட்டாக இருக்க வேண்டும்.
    /// இது ஒரு UTF-8 குறியீடு புள்ளியின் எல்லையிலும் இருக்க வேண்டும்.
    ///
    /// திரும்பிய இரண்டு துண்டுகள் சரம் துண்டின் தொடக்கத்திலிருந்து `mid` வரையிலும், `mid` இலிருந்து சரம் துண்டுகளின் முடிவிலும் செல்கின்றன.
    ///
    /// அதற்கு பதிலாக மாற்றக்கூடிய சரம் துண்டுகளைப் பெற, [`split_at_mut`] முறையைப் பார்க்கவும்.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// `mid` ஒரு UTF-8 குறியீடு புள்ளி எல்லையில் இல்லாவிட்டால், அல்லது அது சரம் துண்டின் கடைசி குறியீடு புள்ளியின் முடிவைக் கடந்தால் Panics.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // குறியீட்டு எண் [0, இல் உள்ளதா என்று is_char_boundary சரிபார்க்கிறது .len()]
        if self.is_char_boundary(mid) {
            // பாதுகாப்பு: `mid` ஒரு கரி எல்லையில் இருக்கிறதா என்று சோதித்தேன்.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ஒரு குறியீட்டு இடத்தில் ஒரு மாற்றக்கூடிய சரம் துண்டுகளை இரண்டாக பிரிக்கவும்.
    ///
    /// `mid` என்ற வாதம் சரத்தின் தொடக்கத்திலிருந்து ஒரு பைட் ஆஃப்செட்டாக இருக்க வேண்டும்.
    /// இது ஒரு UTF-8 குறியீடு புள்ளியின் எல்லையிலும் இருக்க வேண்டும்.
    ///
    /// திரும்பிய இரண்டு துண்டுகள் சரம் துண்டின் தொடக்கத்திலிருந்து `mid` வரையிலும், `mid` இலிருந்து சரம் துண்டுகளின் முடிவிலும் செல்கின்றன.
    ///
    /// அதற்கு பதிலாக மாறாத சரம் துண்டுகளைப் பெற, [`split_at`] முறையைப் பார்க்கவும்.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// `mid` ஒரு UTF-8 குறியீடு புள்ளி எல்லையில் இல்லாவிட்டால், அல்லது அது சரம் துண்டின் கடைசி குறியீடு புள்ளியின் முடிவைக் கடந்தால் Panics.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // குறியீட்டு எண் [0, இல் உள்ளதா என்று is_char_boundary சரிபார்க்கிறது .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // பாதுகாப்பு: `mid` ஒரு கரி எல்லையில் இருக்கிறதா என்று சோதித்தேன்.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ஒரு சரம் துண்டின் [`கரி`] கள் மீது ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// ஒரு சரம் துண்டு செல்லுபடியாகும் UTF-8 ஐக் கொண்டிருப்பதால், [`char`] ஆல் ஒரு சரம் துண்டு வழியாக மீண்டும் இயக்கலாம்.
    /// இந்த முறை அத்தகைய ஒரு செயலியை வழங்குகிறது.
    ///
    /// [`char`] ஒரு யூனிகோட் அளவிடல் மதிப்பைக் குறிக்கிறது என்பதை நினைவில் கொள்வது முக்கியம், மேலும் 'character' என்றால் என்ன என்பது குறித்த உங்கள் எண்ணத்துடன் பொருந்தாது.
    ///
    /// கிராஃபீம் கிளஸ்டர்கள் மீது நீங்கள் உண்மையில் விரும்புவது இருக்கலாம்.
    /// இந்த செயல்பாடு Rust இன் நிலையான நூலகத்தால் வழங்கப்படவில்லை, அதற்கு பதிலாக crates.io ஐ சரிபார்க்கவும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// நினைவில் கொள்ளுங்கள், [`char`] கள் எழுத்துக்கள் குறித்த உங்கள் உள்ளுணர்வுடன் பொருந்தாது:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' அல்ல
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// ஒரு சரம் துண்டின் [`கரி`] கள் மற்றும் அவற்றின் நிலைகள் மீது ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// ஒரு சரம் துண்டு செல்லுபடியாகும் UTF-8 ஐக் கொண்டிருப்பதால், [`char`] ஆல் ஒரு சரம் துண்டு வழியாக மீண்டும் இயக்கலாம்.
    /// இந்த முறை இந்த [`கரி`] கள் மற்றும் அவற்றின் பைட் நிலைகளின் மறுசெயலாளரை வழங்குகிறது.
    ///
    /// ஈரேட்டர் டூப்பிள்களை அளிக்கிறது.நிலை முதலில், [`char`] இரண்டாவது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// நினைவில் கொள்ளுங்கள், [`char`] கள் எழுத்துக்கள் குறித்த உங்கள் உள்ளுணர்வுடன் பொருந்தாது:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // இல்லை (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // இங்கே 3 ஐக் கவனியுங்கள், கடைசி எழுத்து இரண்டு பைட்டுகளை எடுத்தது
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// ஒரு சரம் துண்டுகளின் பைட்டுகளுக்கு மேல் ஒரு ஈரேட்டர்.
    ///
    /// ஒரு சரம் துண்டு பைட்டுகளின் வரிசையைக் கொண்டிருப்பதால், ஒரு சரம் துண்டு வழியாக பைட் மூலம் மீண்டும் இயக்கலாம்.
    /// இந்த முறை அத்தகைய ஒரு செயலியை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// இடைவெளியால் ஒரு சரம் துண்டுகளை பிரிக்கிறது.
    ///
    /// திரும்பிய ஈரேட்டர் அசல் சரம் துண்டுகளின் துணை துண்டுகளாக இருக்கும் சரம் துண்டுகளை திருப்பித் தரும், இது எந்த அளவு இடைவெளியால் பிரிக்கப்படுகிறது.
    ///
    ///
    /// 'Whitespace' யூனிகோட் பெறப்பட்ட கோர் சொத்து `White_Space` இன் விதிமுறைகளின்படி வரையறுக்கப்படுகிறது.
    /// அதற்கு பதிலாக ASCII இடைவெளியில் மட்டுமே நீங்கள் பிரிக்க விரும்பினால், [`split_ascii_whitespace`] ஐப் பயன்படுத்தவும்.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// அனைத்து வகையான இடைவெளிகளும் கருதப்படுகின்றன:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ASCII இடைவெளியால் ஒரு சரம் துண்டுகளை பிரிக்கிறது.
    ///
    /// திரும்பிய ஈரேட்டர் அசல் சரம் துண்டுகளின் துணை துண்டுகளாக இருக்கும் சரம் துண்டுகளை திருப்பித் தரும், இது ASCII இடைவெளியின் எந்த அளவிலும் பிரிக்கப்படுகிறது.
    ///
    ///
    /// அதற்கு பதிலாக யூனிகோட் `Whitespace` ஆல் பிரிக்க, [`split_whitespace`] ஐப் பயன்படுத்தவும்.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// அனைத்து வகையான ASCII இடைவெளிகளும் கருதப்படுகின்றன:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// ஒரு சரத்தின் கோடுகளுக்கு மேல், சரம் துண்டுகளாக ஒரு ஈரேட்டர்.
    ///
    /// கோடுகள் ஒரு புதிய லைன் (`\n`) அல்லது ஒரு வரி ஊட்டத்துடன் (`\r\n`) உடன் வண்டி திரும்பும்.
    ///
    /// இறுதி வரி முடிவு விருப்பமானது.
    /// இறுதி வரி முடிவோடு முடிவடையும் ஒரு சரம், இறுதி வரி முடிவின்றி அதே வரிகளை இல்லையெனில் ஒரே மாதிரியான சரம் தரும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// இறுதி வரி முடிவு தேவையில்லை:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// ஒரு சரத்தின் வரிகளுக்கு மேல் ஒரு ஈரேட்டர்.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 என குறியிடப்பட்ட சரத்தின் மீது `u16` இன் ஐரேட்டரை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// கொடுக்கப்பட்ட முறை இந்த சரம் துண்டின் துணை-துண்டுடன் பொருந்தினால் `true` ஐ வழங்குகிறது.
    ///
    /// இல்லையென்றால் `false` ஐ வழங்குகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// கொடுக்கப்பட்ட முறை இந்த சரம் துண்டின் முன்னொட்டுடன் பொருந்தினால் `true` ஐ வழங்குகிறது.
    ///
    /// இல்லையென்றால் `false` ஐ வழங்குகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// கொடுக்கப்பட்ட முறை இந்த சரம் துண்டின் பின்னொட்டுடன் பொருந்தினால் `true` ஐ வழங்குகிறது.
    ///
    /// இல்லையென்றால் `false` ஐ வழங்குகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// வடிவத்துடன் பொருந்தக்கூடிய இந்த சரம் துண்டின் முதல் எழுத்தின் பைட் குறியீட்டை வழங்குகிறது.
    ///
    /// முறை பொருந்தவில்லை என்றால் [`None`] ஐ வழங்குகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// எளிய வடிவங்கள்:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// புள்ளி இல்லாத பாணி மற்றும் மூடுதல்களைப் பயன்படுத்தி மிகவும் சிக்கலான வடிவங்கள்:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// வடிவத்தைக் கண்டுபிடிக்கவில்லை:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// இந்த சரம் துண்டில் உள்ள வடிவத்தின் வலதுபுற பொருத்தத்தின் முதல் எழுத்துக்கு பைட் குறியீட்டை வழங்குகிறது.
    ///
    /// முறை பொருந்தவில்லை என்றால் [`None`] ஐ வழங்குகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// எளிய வடிவங்கள்:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// மூடல்களுடன் மிகவும் சிக்கலான வடிவங்கள்:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// வடிவத்தைக் கண்டுபிடிக்கவில்லை:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// இந்த சரம் துண்டுகளின் அடி மூலக்கூறுகளின் மீது ஒரு ஈரேட்டர், ஒரு வடிவத்துடன் பொருந்தக்கூடிய எழுத்துக்களால் பிரிக்கப்படுகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ஈட்டரேட்டர் நடத்தை
    ///
    /// முறை ஒரு தலைகீழ் தேடலை அனுமதித்தால், திரும்பிய மறு செய்கை [`DoubleEndedIterator`] ஆக இருக்கும், மேலும் forward/reverse தேடல் அதே கூறுகளை அளிக்கிறது.
    /// இது உண்மை, எ.கா., [`char`], ஆனால் `&str` க்கு அல்ல.
    ///
    /// முறை ஒரு தலைகீழ் தேடலை அனுமதித்தால், ஆனால் அதன் முடிவுகள் முன்னோக்கி தேடலில் இருந்து வேறுபடலாம் என்றால், [`rsplit`] முறையைப் பயன்படுத்தலாம்.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// எளிய வடிவங்கள்:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// முறை எழுத்துகளின் ஒரு துண்டு என்றால், எந்தவொரு கதாபாத்திரத்தின் ஒவ்வொரு நிகழ்விலும் பிரிக்கவும்:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// மூடுதலைப் பயன்படுத்தி மிகவும் சிக்கலான முறை:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// ஒரு சரம் பல தொடர்ச்சியான பிரிப்பான்களைக் கொண்டிருந்தால், வெளியீட்டில் வெற்று சரங்களுடன் முடிவடையும்:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// தொடர்ச்சியான பிரிப்பான்கள் வெற்று சரம் மூலம் பிரிக்கப்படுகின்றன.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// ஒரு சரத்தின் தொடக்கத்திலோ அல்லது முடிவிலோ உள்ள பிரிப்பான்கள் வெற்று சரங்களால் அண்டை நாடுகளாகும்.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// வெற்று சரம் ஒரு பிரிப்பானாகப் பயன்படுத்தப்படும்போது, அது சரத்தின் ஒவ்வொரு எழுத்தையும், சரத்தின் தொடக்கத்தையும் முடிவையும் பிரிக்கிறது.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// இடைவெளியைப் பிரிப்பானாகப் பயன்படுத்தும்போது தொடர்ச்சியான பிரிப்பான்கள் ஆச்சரியமான நடத்தைக்கு வழிவகுக்கும்.இந்த குறியீடு சரியானது:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// இது _not_ உங்களுக்கு தருகிறது:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// இந்த நடத்தைக்கு [`split_whitespace`] ஐப் பயன்படுத்தவும்.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// இந்த சரம் துண்டுகளின் அடி மூலக்கூறுகளின் மீது ஒரு ஈரேட்டர், ஒரு வடிவத்துடன் பொருந்தக்கூடிய எழுத்துக்களால் பிரிக்கப்படுகிறது.
    /// அந்த `split_inclusive` இல் `split` ஆல் தயாரிக்கப்பட்ட ஈரேட்டரிலிருந்து வேறுபடுகிறது, பொருந்திய பகுதியை அடி மூலக்கூறின் டெர்மினேட்டராக விட்டுவிடுகிறது.
    ///
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// சரத்தின் கடைசி உறுப்பு பொருந்தினால், அந்த உறுப்பு முந்தைய அடி மூலக்கூறின் முனையமாகக் கருதப்படும்.
    /// அந்த மூலக்கூறு ஈரேட்டரால் வழங்கப்பட்ட கடைசி உருப்படியாக இருக்கும்.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// கொடுக்கப்பட்ட சரம் துண்டுகளின் அடி மூலக்கூறுகளின் மீது ஒரு ஈரேட்டர், ஒரு வடிவத்தால் பொருந்தக்கூடிய எழுத்துக்களால் பிரிக்கப்பட்டு தலைகீழ் வரிசையில் வழங்கப்படுகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ஈட்டரேட்டர் நடத்தை
    ///
    /// திரும்பிய ஈரேட்டருக்கு ஒரு தலைகீழ் தேடலை ஆதரிக்க வேண்டும், மேலும் ஒரு forward/reverse தேடல் அதே கூறுகளை அளித்தால் அது [`DoubleEndedIterator`] ஆக இருக்கும்.
    ///
    ///
    /// முன்பக்கத்திலிருந்து மீண்டும் வருவதற்கு, [`split`] முறையைப் பயன்படுத்தலாம்.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// எளிய வடிவங்கள்:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// மூடுதலைப் பயன்படுத்தி மிகவும் சிக்கலான முறை:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// கொடுக்கப்பட்ட சரம் துண்டுகளின் அடி மூலக்கூறுகளின் மீது ஒரு ஈரேட்டர், ஒரு வடிவத்துடன் பொருந்தக்கூடிய எழுத்துக்களால் பிரிக்கப்படுகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] க்கு சமம், காலியாக இருந்தால் பின்செல்லும் அடி மூலக்கூறு தவிர்க்கப்படுகிறது.
    ///
    /// [`split`]: str::split
    ///
    /// இந்த முறையானது ஒரு வடிவத்தால் _separated_ ஐ விட _terminated_ என்ற சரம் தரவுக்கு பயன்படுத்தப்படலாம்.
    ///
    /// # ஈட்டரேட்டர் நடத்தை
    ///
    /// முறை ஒரு தலைகீழ் தேடலை அனுமதித்தால், திரும்பிய மறு செய்கை [`DoubleEndedIterator`] ஆக இருக்கும், மேலும் forward/reverse தேடல் அதே கூறுகளை அளிக்கிறது.
    /// இது உண்மை, எ.கா., [`char`], ஆனால் `&str` க்கு அல்ல.
    ///
    /// முறை ஒரு தலைகீழ் தேடலை அனுமதித்தால், ஆனால் அதன் முடிவுகள் முன்னோக்கி தேடலில் இருந்து வேறுபடலாம் என்றால், [`rsplit_terminator`] முறையைப் பயன்படுத்தலாம்.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` இன் அடி மூலக்கூறுகளின் மீது ஒரு ஈரேட்டர், ஒரு வடிவத்தால் பொருந்தக்கூடிய எழுத்துக்களால் பிரிக்கப்பட்டு தலைகீழ் வரிசையில் வழங்கப்படுகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] க்கு சமம், காலியாக இருந்தால் பின்செல்லும் அடி மூலக்கூறு தவிர்க்கப்படுகிறது.
    ///
    /// [`split`]: str::split
    ///
    /// இந்த முறையானது ஒரு வடிவத்தால் _separated_ ஐ விட _terminated_ என்ற சரம் தரவுக்கு பயன்படுத்தப்படலாம்.
    ///
    /// # ஈட்டரேட்டர் நடத்தை
    ///
    /// திரும்பிய ஈரேட்டருக்கு ஒரு தலைகீழ் தேடலை ஆதரிக்க வேண்டும், மேலும் ஒரு forward/reverse தேடல் அதே கூறுகளை அளித்தால் அது இரட்டை முடிவடையும்.
    ///
    ///
    /// முன்பக்கத்திலிருந்து மீண்டும் வருவதற்கு, [`split_terminator`] முறையைப் பயன்படுத்தலாம்.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// கொடுக்கப்பட்ட சரம் துண்டுகளின் அடி மூலக்கூறுகளின் மீது ஒரு ஈரேட்டர், ஒரு வடிவத்தால் பிரிக்கப்பட்டு, பெரும்பாலான `n` உருப்படிகளுக்குத் திரும்ப தடைசெய்யப்பட்டுள்ளது.
    ///
    /// `n` அடி மூலக்கூறுகள் திருப்பி அனுப்பப்பட்டால், கடைசி அடி மூலக்கூறு (`n` வது அடி மூலக்கூறு) சரத்தின் எஞ்சியிருக்கும்.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ஈட்டரேட்டர் நடத்தை
    ///
    /// திரும்பப் பெறும் செயலி இரட்டை முடிவாக இருக்காது, ஏனெனில் இது ஆதரிக்க திறமையாக இல்லை.
    ///
    /// முறை தலைகீழ் தேடலை அனுமதித்தால், [`rsplitn`] முறையைப் பயன்படுத்தலாம்.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// எளிய வடிவங்கள்:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// மூடுதலைப் பயன்படுத்தி மிகவும் சிக்கலான முறை:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// இந்த சரம் துண்டுகளின் அடி மூலக்கூறுகளின் மீது ஒரு ஈரேட்டர், ஒரு வடிவத்தால் பிரிக்கப்பட்டு, சரத்தின் முடிவிலிருந்து தொடங்கி, பெரும்பாலான `n` உருப்படிகளுக்குத் திரும்புவதற்கு தடைசெய்யப்பட்டுள்ளது.
    ///
    ///
    /// `n` அடி மூலக்கூறுகள் திருப்பி அனுப்பப்பட்டால், கடைசி அடி மூலக்கூறு (`n` வது அடி மூலக்கூறு) சரத்தின் எஞ்சியிருக்கும்.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ஈட்டரேட்டர் நடத்தை
    ///
    /// திரும்பப் பெறும் செயலி இரட்டை முடிவாக இருக்காது, ஏனெனில் இது ஆதரிக்க திறமையாக இல்லை.
    ///
    /// முன்பக்கத்திலிருந்து பிரிக்க, [`splitn`] முறையைப் பயன்படுத்தலாம்.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// எளிய வடிவங்கள்:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// மூடுதலைப் பயன்படுத்தி மிகவும் சிக்கலான முறை:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// குறிப்பிட்ட டிலிமிட்டரின் முதல் நிகழ்வில் சரத்தை பிரித்து, டிலிமிட்டருக்கு முன் முன்னொட்டையும், டிலிமிட்டருக்குப் பின் பின்னொட்டையும் தருகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// குறிப்பிட்ட டிலிமிட்டரின் கடைசி நிகழ்வில் சரத்தை பிரித்து, டிலிமிட்டருக்கு முன் முன்னொட்டையும், டிலிமிட்டருக்குப் பின் பின்னொட்டையும் தருகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// கொடுக்கப்பட்ட சரம் துண்டுக்குள் ஒரு வடிவத்தின் ஒத்திசைவு பொருத்தங்கள் மீது ஒரு ஈரேட்டர்.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ஈட்டரேட்டர் நடத்தை
    ///
    /// முறை ஒரு தலைகீழ் தேடலை அனுமதித்தால், திரும்பிய மறு செய்கை [`DoubleEndedIterator`] ஆக இருக்கும், மேலும் forward/reverse தேடல் அதே கூறுகளை அளிக்கிறது.
    /// இது உண்மை, எ.கா., [`char`], ஆனால் `&str` க்கு அல்ல.
    ///
    /// முறை ஒரு தலைகீழ் தேடலை அனுமதித்தால், ஆனால் அதன் முடிவுகள் முன்னோக்கி தேடலில் இருந்து வேறுபடலாம் என்றால், [`rmatches`] முறையைப் பயன்படுத்தலாம்.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// இந்த சரம் துண்டுக்குள் ஒரு வடிவத்தின் ஒத்திசைவு பொருத்தங்களின் மீது ஒரு ஈரேட்டர், தலைகீழ் வரிசையில் வழங்கப்படுகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ஈட்டரேட்டர் நடத்தை
    ///
    /// திரும்பிய ஈரேட்டருக்கு ஒரு தலைகீழ் தேடலை ஆதரிக்க வேண்டும், மேலும் ஒரு forward/reverse தேடல் அதே கூறுகளை அளித்தால் அது [`DoubleEndedIterator`] ஆக இருக்கும்.
    ///
    ///
    /// முன்பக்கத்திலிருந்து மீண்டும் வருவதற்கு, [`matches`] முறையைப் பயன்படுத்தலாம்.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// இந்த சரம் துண்டுக்குள் ஒரு வடிவத்தின் ஒத்திசைவு பொருத்தங்கள் மற்றும் போட்டி தொடங்கும் குறியீட்டைப் பற்றிய ஒரு ஈரேட்டர்.
    ///
    /// ஒன்றுடன் ஒன்று `self` க்குள் `pat` இன் போட்டிகளுக்கு, முதல் போட்டியுடன் தொடர்புடைய குறியீடுகள் மட்டுமே திரும்பப் பெறப்படுகின்றன.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ஈட்டரேட்டர் நடத்தை
    ///
    /// முறை ஒரு தலைகீழ் தேடலை அனுமதித்தால், திரும்பிய மறு செய்கை [`DoubleEndedIterator`] ஆக இருக்கும், மேலும் forward/reverse தேடல் அதே கூறுகளை அளிக்கிறது.
    /// இது உண்மை, எ.கா., [`char`], ஆனால் `&str` க்கு அல்ல.
    ///
    /// முறை ஒரு தலைகீழ் தேடலை அனுமதித்தால், ஆனால் அதன் முடிவுகள் முன்னோக்கி தேடலில் இருந்து வேறுபடலாம் என்றால், [`rmatch_indices`] முறையைப் பயன்படுத்தலாம்.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // முதல் `aba` மட்டுமே
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` க்குள் ஒரு வடிவத்தின் ஒத்திசைவு போட்டிகளில் ஒரு மறு செய்கை, போட்டியின் குறியீட்டுடன் தலைகீழ் வரிசையில் வழங்கப்படுகிறது.
    ///
    /// ஒன்றுடன் ஒன்று `self` க்குள் `pat` இன் போட்டிகளுக்கு, கடைசி போட்டியுடன் தொடர்புடைய குறியீடுகள் மட்டுமே திரும்பப் பெறப்படுகின்றன.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ஈட்டரேட்டர் நடத்தை
    ///
    /// திரும்பிய ஈரேட்டருக்கு ஒரு தலைகீழ் தேடலை ஆதரிக்க வேண்டும், மேலும் ஒரு forward/reverse தேடல் அதே கூறுகளை அளித்தால் அது [`DoubleEndedIterator`] ஆக இருக்கும்.
    ///
    ///
    /// முன்பக்கத்திலிருந்து மீண்டும் வருவதற்கு, [`match_indices`] முறையைப் பயன்படுத்தலாம்.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // கடைசி `aba` மட்டுமே
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// முன்னணி மற்றும் பின்தங்கிய இடைவெளியுடன் ஒரு சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// 'Whitespace' யூனிகோட் பெறப்பட்ட கோர் சொத்து `White_Space` இன் விதிமுறைகளின்படி வரையறுக்கப்படுகிறது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// முன்னணி இடைவெளியுடன் அகற்றப்பட்ட சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// 'Whitespace' யூனிகோட் பெறப்பட்ட கோர் சொத்து `White_Space` இன் விதிமுறைகளின்படி வரையறுக்கப்படுகிறது.
    ///
    /// # உரை திசை
    ///
    /// ஒரு சரம் பைட்டுகளின் வரிசை.
    /// `start` இந்த சூழலில் அந்த பைட் சரத்தின் முதல் நிலை என்று பொருள்;ஆங்கிலம் அல்லது ரஷ்யன் போன்ற இடமிருந்து வலமாக, இது இடது பக்கமாகவும், அரபு அல்லது ஹீப்ரு போன்ற வலமிருந்து இடமாகவும் இருக்கும், இது வலது பக்கமாக இருக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// நீக்கப்பட்ட இடைவெளியுடன் ஒரு சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// 'Whitespace' யூனிகோட் பெறப்பட்ட கோர் சொத்து `White_Space` இன் விதிமுறைகளின்படி வரையறுக்கப்படுகிறது.
    ///
    /// # உரை திசை
    ///
    /// ஒரு சரம் பைட்டுகளின் வரிசை.
    /// `end` இந்த சூழலில் அந்த பைட் சரத்தின் கடைசி நிலை என்று பொருள்;ஆங்கிலம் அல்லது ரஷ்யன் போன்ற இடமிருந்து வலமாக, இது வலது பக்கமாக இருக்கும், அரபு அல்லது ஹீப்ரு போன்ற வலமிருந்து இடமாக இது இடது பக்கமாக இருக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// முன்னணி இடைவெளியுடன் அகற்றப்பட்ட சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// 'Whitespace' யூனிகோட் பெறப்பட்ட கோர் சொத்து `White_Space` இன் விதிமுறைகளின்படி வரையறுக்கப்படுகிறது.
    ///
    /// # உரை திசை
    ///
    /// ஒரு சரம் பைட்டுகளின் வரிசை.
    /// 'Left' இந்த சூழலில் அந்த பைட் சரத்தின் முதல் நிலை என்று பொருள்;அரபு அல்லது ஹீப்ரு போன்ற மொழிக்கு 'இடமிருந்து வலமாக' இருப்பதை விட 'வலமிருந்து இடமாக' இருக்கும், இது _right_ பக்கமாக இருக்கும், இடதுபுறம் அல்ல.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// நீக்கப்பட்ட இடைவெளியுடன் ஒரு சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// 'Whitespace' யூனிகோட் பெறப்பட்ட கோர் சொத்து `White_Space` இன் விதிமுறைகளின்படி வரையறுக்கப்படுகிறது.
    ///
    /// # உரை திசை
    ///
    /// ஒரு சரம் பைட்டுகளின் வரிசை.
    /// 'Right' இந்த சூழலில் அந்த பைட் சரத்தின் கடைசி நிலை என்று பொருள்;அரபு அல்லது ஹீப்ரு போன்ற மொழிக்கு 'இடமிருந்து வலமாக' இருப்பதை விட 'வலமிருந்து இடமாக' இருக்கும், இது _left_ பக்கமாக இருக்கும், வலதுபுறம் அல்ல.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// மீண்டும் மீண்டும் அகற்றப்பட்ட வடிவத்துடன் பொருந்தக்கூடிய அனைத்து முன்னொட்டுகள் மற்றும் பின்னொட்டுகளுடன் ஒரு சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// [pattern] ஒரு [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் செயல்பாடு அல்லது மூடல்.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// எளிய வடிவங்கள்:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// மூடுதலைப் பயன்படுத்தி மிகவும் சிக்கலான முறை:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // ஆரம்பத்தில் தெரிந்த போட்டியை நினைவில் வைத்துக் கொள்ளுங்கள், கீழே இருந்தால் சரி செய்யுங்கள்
            // கடைசி போட்டி வேறு
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // பாதுகாப்பு: `Searcher` செல்லுபடியாகும் குறியீடுகளை வழங்குவதாக அறியப்படுகிறது.
        unsafe { self.get_unchecked(i..j) }
    }

    /// மீண்டும் மீண்டும் அகற்றப்பட்ட வடிவத்துடன் பொருந்தக்கூடிய அனைத்து முன்னொட்டுகளுடன் ஒரு சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # உரை திசை
    ///
    /// ஒரு சரம் பைட்டுகளின் வரிசை.
    /// `start` இந்த சூழலில் அந்த பைட் சரத்தின் முதல் நிலை என்று பொருள்;ஆங்கிலம் அல்லது ரஷ்யன் போன்ற இடமிருந்து வலமாக, இது இடது பக்கமாகவும், அரபு அல்லது ஹீப்ரு போன்ற வலமிருந்து இடமாகவும் இருக்கும், இது வலது பக்கமாக இருக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // பாதுகாப்பு: `Searcher` செல்லுபடியாகும் குறியீடுகளை வழங்குவதாக அறியப்படுகிறது.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// அகற்றப்பட்ட முன்னொட்டுடன் ஒரு சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// சரம் `prefix` வடிவத்துடன் தொடங்கினால், முன்னொட்டுக்குப் பிறகு `Some` இல் மூடப்பட்டிருக்கும்.
    /// `trim_start_matches` போலல்லாமல், இந்த முறை முன்னொட்டை சரியாக ஒரு முறை நீக்குகிறது.
    ///
    /// சரம் `prefix` உடன் தொடங்கவில்லை என்றால், `None` ஐ வழங்குகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// நீக்கப்பட்ட பின்னொட்டுடன் ஒரு சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// சரம் `suffix` வடிவத்துடன் முடிவடைந்தால், `Some` இல் மூடப்பட்ட பின்னொட்டுக்கு முன் மூலக்கூறு கொடுக்கிறது.
    /// `trim_end_matches` போலல்லாமல், இந்த முறை பின்னொட்டை சரியாக ஒரு முறை நீக்குகிறது.
    ///
    /// சரம் `suffix` உடன் முடிவடையவில்லை என்றால், `None` ஐ வழங்குகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// மீண்டும் மீண்டும் அகற்றப்பட்ட வடிவத்துடன் பொருந்தக்கூடிய அனைத்து பின்னொட்டுகளுடன் ஒரு சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # உரை திசை
    ///
    /// ஒரு சரம் பைட்டுகளின் வரிசை.
    /// `end` இந்த சூழலில் அந்த பைட் சரத்தின் கடைசி நிலை என்று பொருள்;ஆங்கிலம் அல்லது ரஷ்யன் போன்ற இடமிருந்து வலமாக, இது வலது பக்கமாக இருக்கும், அரபு அல்லது ஹீப்ரு போன்ற வலமிருந்து இடமாக இது இடது பக்கமாக இருக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// எளிய வடிவங்கள்:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// மூடுதலைப் பயன்படுத்தி மிகவும் சிக்கலான முறை:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // பாதுகாப்பு: `Searcher` செல்லுபடியாகும் குறியீடுகளை வழங்குவதாக அறியப்படுகிறது.
        unsafe { self.get_unchecked(0..j) }
    }

    /// மீண்டும் மீண்டும் அகற்றப்பட்ட வடிவத்துடன் பொருந்தக்கூடிய அனைத்து முன்னொட்டுகளுடன் ஒரு சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # உரை திசை
    ///
    /// ஒரு சரம் பைட்டுகளின் வரிசை.
    /// 'Left' இந்த சூழலில் அந்த பைட் சரத்தின் முதல் நிலை என்று பொருள்;அரபு அல்லது ஹீப்ரு போன்ற மொழிக்கு 'இடமிருந்து வலமாக' இருப்பதை விட 'வலமிருந்து இடமாக' இருக்கும், இது _right_ பக்கமாக இருக்கும், இடதுபுறம் அல்ல.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// மீண்டும் மீண்டும் அகற்றப்பட்ட வடிவத்துடன் பொருந்தக்கூடிய அனைத்து பின்னொட்டுகளுடன் ஒரு சரம் துண்டுகளை வழங்குகிறது.
    ///
    /// [pattern] ஒரு `&str`, [`char`], [`char`] களின் துண்டு அல்லது ஒரு எழுத்து பொருந்துமா என்பதை தீர்மானிக்கும் ஒரு செயல்பாடு அல்லது மூடல்.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # உரை திசை
    ///
    /// ஒரு சரம் பைட்டுகளின் வரிசை.
    /// 'Right' இந்த சூழலில் அந்த பைட் சரத்தின் கடைசி நிலை என்று பொருள்;அரபு அல்லது ஹீப்ரு போன்ற மொழிக்கு 'இடமிருந்து வலமாக' இருப்பதை விட 'வலமிருந்து இடமாக' இருக்கும், இது _left_ பக்கமாக இருக்கும், வலதுபுறம் அல்ல.
    ///
    ///
    /// # Examples
    ///
    /// எளிய வடிவங்கள்:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// மூடுதலைப் பயன்படுத்தி மிகவும் சிக்கலான முறை:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// இந்த சரம் துண்டுகளை மற்றொரு வகையாக பாகுபடுத்துகிறது.
    ///
    /// `parse` மிகவும் பொதுவானது என்பதால், இது வகை அனுமானத்தில் சிக்கல்களை ஏற்படுத்தும்.
    /// எனவே, X001 என அழைக்கப்படும் தொடரியல் நீங்கள் பார்க்கும் சில நேரங்களில் `parse` ஒன்றாகும்: `::<>`.
    ///
    /// நீங்கள் எந்த வகையை அலச முயற்சிக்கிறீர்கள் என்பதை குறிப்பாக புரிந்துகொள்ள வழிமுறை உதவுகிறது.
    ///
    /// `parse` [`FromStr`] trait ஐ செயல்படுத்தும் எந்த வகையிலும் அலசலாம்.
    ///

    /// # Errors
    ///
    /// இந்த சரம் துண்டுகளை விரும்பிய வகைக்கு அலச முடியாவிட்டால் [`Err`] ஐ வழங்கும்.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` ஐ குறிப்பதற்கு பதிலாக 'turbofish' ஐப் பயன்படுத்துதல்:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// பாகுபடுத்துவதில் தோல்வி:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// இந்த சரத்தின் அனைத்து எழுத்துகளும் ASCII வரம்பிற்குள் இருக்கிறதா என்று சரிபார்க்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // ஒவ்வொரு பைட்டையும் நாம் இங்கே எழுத்துக்குறியாகக் கருதலாம்: அனைத்து மல்டிபைட் எழுத்துக்களும் ஆஸ்கி வரம்பில் இல்லாத ஒரு பைட்டிலிருந்து தொடங்குகின்றன, எனவே நாங்கள் ஏற்கனவே அங்கேயே நிறுத்தப்படுவோம்.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// இரண்டு சரங்கள் ஒரு ஆஸ்கி வழக்கு-உணர்வற்ற பொருத்தம் என்பதை சரிபார்க்கிறது.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` போலவே, ஆனால் தற்காலிகங்களை ஒதுக்காமல் மற்றும் நகலெடுக்காமல்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// இந்த சரத்தை அதன் ASCII மேல் வழக்குக்கு சமமான இடத்தில் மாற்றுகிறது.
    ///
    /// ASCII எழுத்துக்கள் 'a' முதல் 'z' வரை 'A' முதல் 'Z' வரை மாற்றப்படுகின்றன, ஆனால் ASCII அல்லாத எழுத்துக்கள் மாறாமல் உள்ளன.
    ///
    /// ஏற்கனவே உள்ள ஒன்றை மாற்றாமல் புதிய பெரிய மதிப்பைத் தர, [`to_ascii_uppercase()`] ஐப் பயன்படுத்தவும்.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // பாதுகாப்பு: பாதுகாப்பானது, ஏனெனில் நாங்கள் ஒரே மாதிரியுடன் இரண்டு வகைகளை மாற்றுகிறோம்.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// இந்த சரத்தை அதன் ASCII லோயர் கேஸ் சமமான இடத்தில் மாற்றுகிறது.
    ///
    /// ASCII எழுத்துக்கள் 'A' முதல் 'Z' வரை 'a' முதல் 'z' வரை மாற்றப்படுகின்றன, ஆனால் ASCII அல்லாத எழுத்துக்கள் மாறாமல் உள்ளன.
    ///
    /// ஏற்கனவே உள்ள ஒன்றை மாற்றாமல் புதிய சிறிய மதிப்பைத் தர, [`to_ascii_lowercase()`] ஐப் பயன்படுத்தவும்.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // பாதுகாப்பு: பாதுகாப்பானது, ஏனெனில் நாங்கள் ஒரே மாதிரியுடன் இரண்டு வகைகளை மாற்றுகிறோம்.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// `self` இல் [`char::escape_debug`] உடன் ஒவ்வொரு எரிப்பிலிருந்து தப்பிக்கும் ஒரு ஐரேட்டரைத் திரும்புக.
    ///
    ///
    /// Note: சரத்தைத் தொடங்கும் நீட்டிக்கப்பட்ட கிராஃபீம் குறியீட்டு புள்ளிகள் மட்டுமே தப்பிக்கப்படும்.
    ///
    /// # Examples
    ///
    /// ஒரு செயலாளராக:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ஐ நேரடியாகப் பயன்படுத்துதல்:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// இரண்டும் இதற்கு சமம்:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` ஐப் பயன்படுத்துதல்:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// `self` இல் [`char::escape_default`] உடன் ஒவ்வொரு எரிப்பிலிருந்து தப்பிக்கும் ஒரு ஐரேட்டரைத் திரும்புக.
    ///
    ///
    /// # Examples
    ///
    /// ஒரு செயலாளராக:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ஐ நேரடியாகப் பயன்படுத்துதல்:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// இரண்டும் இதற்கு சமம்:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` ஐப் பயன்படுத்துதல்:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// `self` இல் [`char::escape_unicode`] உடன் ஒவ்வொரு எரிப்பிலிருந்து தப்பிக்கும் ஒரு ஐரேட்டரைத் திரும்புக.
    ///
    ///
    /// # Examples
    ///
    /// ஒரு செயலாளராக:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ஐ நேரடியாகப் பயன்படுத்துதல்:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// இரண்டும் இதற்கு சமம்:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` ஐப் பயன்படுத்துதல்:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// வெற்று str ஐ உருவாக்குகிறது
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// வெற்று மாற்றக்கூடிய str ஐ உருவாக்குகிறது
    #[inline]
    fn default() -> Self {
        // பாதுகாப்பு: வெற்று சரம் செல்லுபடியாகும் UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// பெயரிடக்கூடிய, குளோனபிள் எஃப்என் வகை
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // பாதுகாப்பு: பாதுகாப்பாக இல்லை
        unsafe { from_utf8_unchecked(bytes) }
    };
}