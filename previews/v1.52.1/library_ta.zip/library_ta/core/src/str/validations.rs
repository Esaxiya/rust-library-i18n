//! UTF-8 சரிபார்ப்பு தொடர்பான செயல்பாடுகள்.

use crate::mem;

use super::Utf8Error;

/// முதல் பைட்டுக்கான ஆரம்ப குறியீட்டு புள்ளி திரட்டியை வழங்குகிறது.
/// முதல் பைட் சிறப்பு, அகலம் 2 க்கு கீழே 5 பிட்கள், அகலம் 3 க்கு 4 பிட்கள் மற்றும் அகலம் 4 க்கு 3 பிட்கள் மட்டுமே வேண்டும்.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// தொடர்ச்சியான பைட் `byte` உடன் புதுப்பிக்கப்பட்ட `ch` இன் மதிப்பை வழங்குகிறது.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// பைட் ஒரு UTF-8 தொடர்ச்சியான பைட் என்பதை சரிபார்க்கிறது (அதாவது, பிட்கள் `10` உடன் தொடங்குகிறது).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// பைட் ஐரேட்டரின் அடுத்த குறியீடு புள்ளியைப் படிக்கிறது (யுடிஎஃப்-8 போன்ற குறியாக்கத்தைக் கருதி).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // டிகோட் UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // மல்டிபைட் வழக்கு ஒரு பைட் கலவையிலிருந்து டிகோடை பின்வருமாறு: [[[x y] z] w]
    //
    // NOTE: செயல்திறன் இங்கே சரியான சூத்திரத்திற்கு உணர்திறன்
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] வழக்கு
        // 0xE0 இல் 5 வது பிட் .. 0xEF எப்போதும் தெளிவாக உள்ளது, எனவே `init` இன்னும் செல்லுபடியாகும்
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] வழக்கு `init` இன் குறைந்த 3 பிட்களை மட்டுமே பயன்படுத்துகிறது
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// பைட் ஐரேட்டரின் கடைசி குறியீடு புள்ளியைப் படிக்கிறது (யுடிஎஃப்-8 போன்ற குறியாக்கத்தைக் கருதி).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // டிகோட் UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // மல்டிபைட் வழக்கு ஒரு பைட் கலவையிலிருந்து டிகோடை பின்வருமாறு: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// u64 ஐப் பயன்படுத்துவதற்கு துண்டிக்கப்படுவதைப் பயன்படுத்தவும்
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `x` என்ற வார்த்தையில் ஏதேனும் பைட் nonascii (>=128) எனில் `true` ஐ வழங்குகிறது.
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// இது செல்லுபடியாகும் UTF-8 வரிசை என்பதை `v` சரிபார்த்து, அந்த வழக்கில் `Ok(())` ஐ திருப்பி அளிக்கிறது, அல்லது அது தவறானது என்றால், `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // எங்களுக்கு தரவு தேவை, ஆனால் எதுவும் இல்லை: பிழை!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2-பைட் குறியாக்கம் குறியீட்டு புள்ளிகளுக்கானது\u {0080} முதல்\u {07ff} முதல் C2 80 கடைசி DF BF
            // 3-பைட் குறியாக்கம் குறியீட்டு புள்ளிகளுக்கானது\u {0800} முதல்\u {ffff} முதல் E0 A0 80 கடைசி EF BF BF வாகை குறியீட்டு புள்ளிகளைத் தவிர\u {d800} முதல்\u {dfff} ED A0 80 முதல் ED BF BF வரை
            // 4-பைட் குறியாக்கம் குறியீட்டு புள்ளிகளுக்கானது\u {1000} 0 முதல்\u {10ff} ff முதல் F0 90 80 80 கடைசி F4 8F BF BF
            //
            // RFC இலிருந்து UTF-8 தொடரியல் பயன்படுத்தவும்
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-வால் UTF8-3= %xE0% xA0-BF UTF8-வால்/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-வால்/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii வழக்கு, விரைவாக முன்னோக்கி தவிர்க்க முயற்சிக்கவும்.
            // சுட்டிக்காட்டி சீரமைக்கப்படும்போது, ஆஸ்கி அல்லாத பைட்டைக் கொண்ட ஒரு வார்த்தையைக் கண்டுபிடிக்கும் வரை மறு செய்கைக்கு 2 சொற்களின் தரவைப் படியுங்கள்.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // பாதுகாப்பு: `align - index` மற்றும் `ascii_block_size` என்பதால்
                    // `usize_bytes`, `block = ptr.add(index)` இன் மடங்குகள் எப்போதும் ஒரு `usize` உடன் சீரமைக்கப்படுகின்றன, எனவே `block` மற்றும் `block.offset(1)` இரண்டையும் மதிப்பிடுவது பாதுகாப்பானது.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // ஒரு nonascii பைட் இருந்தால் உடைக்க
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // சொற்பொழிவு வளையம் நிறுத்தப்பட்ட இடத்திலிருந்து படி
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// முதல் பைட் கொடுக்கப்பட்டால், இந்த UTF-8 எழுத்தில் எத்தனை பைட்டுகள் உள்ளன என்பதை தீர்மானிக்கிறது.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// தொடர்ச்சியான பைட்டின் மதிப்பு பிட்களின் மாஸ்க்.
const CONT_MASK: u8 = 0b0011_1111;
/// தொடர்ச்சியான பைட்டின் குறிச்சொல் பிட்களின் மதிப்பு (டேக் மாஸ்க் !CONT_MASK).
const TAG_CONT_U8: u8 = 0b1000_0000;

// `&str` ஐ நீளமாகக் குறைக்க, அது `max` க்கு சமமானதாக இருந்தால், அது வெட்டப்பட்டால் `true` திரும்பவும், புதிய str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}