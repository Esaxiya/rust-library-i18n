//! `str` க்கான Trait செயலாக்கங்கள்.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// சரங்களை வரிசைப்படுத்துவதை செயல்படுத்துகிறது.
///
/// சரங்களை அவற்றின் பைட் மதிப்புகள் மூலம் [lexicographically](Ord#lexicographical-comparison) ஆர்டர் செய்யப்படுகின்றன.
/// இது குறியீட்டு அட்டவணையில் உள்ள நிலைகளின் அடிப்படையில் யூனிகோட் குறியீடு புள்ளிகளை ஆர்டர் செய்கிறது.
/// இது "alphabetical" வரிசையைப் போலவே இருக்க வேண்டிய அவசியமில்லை, இது மொழி மற்றும் இருப்பிடத்தின் அடிப்படையில் மாறுபடும்.
/// கலாச்சார ரீதியாக ஏற்றுக்கொள்ளப்பட்ட தரநிலைகளின்படி சரங்களை வரிசைப்படுத்துவதற்கு `str` வகையின் எல்லைக்கு வெளியே உள்ள இருப்பிட-குறிப்பிட்ட தரவு தேவைப்படுகிறது.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// சரங்களில் ஒப்பீட்டு செயல்பாடுகளை செயல்படுத்துகிறது.
///
/// சரங்களை அவற்றின் பைட் மதிப்புகள் மூலம் [lexicographically](Ord#lexicographical-comparison) உடன் ஒப்பிடுகின்றன.
/// இது குறியீட்டு அட்டவணையில் உள்ள நிலைகளின் அடிப்படையில் யூனிகோட் குறியீடு புள்ளிகளை ஒப்பிடுகிறது.
/// இது "alphabetical" வரிசையைப் போலவே இருக்க வேண்டிய அவசியமில்லை, இது மொழி மற்றும் இருப்பிடத்தின் அடிப்படையில் மாறுபடும்.
/// கலாச்சார ரீதியாக ஏற்றுக்கொள்ளப்பட்ட தரநிலைகளின்படி சரங்களை ஒப்பிடுவதற்கு `str` வகையின் எல்லைக்கு வெளியே உள்ள இருப்பிட-குறிப்பிட்ட தரவு தேவைப்படுகிறது.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// தொடரியல் `&self[..]` அல்லது `&mut self[..]` உடன் அடி மூலக்கூறு துண்டுகளை செயல்படுத்துகிறது.
///
/// முழு சரத்தின் ஒரு துண்டை வழங்குகிறது, அதாவது, `&self` அல்லது `&mut self` ஐ வழங்குகிறது.`&சுயத்திற்கு சமம் [0 ..
/// len] `அல்லது`&mut self [0 ..
/// len]`.
/// பிற அட்டவணைப்படுத்தல் செயல்பாடுகளைப் போலன்றி, இது ஒருபோதும் panic ஆக இருக்க முடியாது.
///
/// இந்த செயல்பாடு *O*(1).
///
/// 1.20.0 க்கு முன்னர், இந்த அட்டவணைப்படுத்தல் செயல்பாடுகள் `Index` மற்றும் `IndexMut` ஐ நேரடியாக செயல்படுத்துவதன் மூலம் ஆதரிக்கப்படுகின்றன.
///
/// `&self[0 .. len]` அல்லது `&mut self[0 .. len]` க்கு சமம்.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// தொடரியல் `&self[begin .. end]` அல்லது `&mut self[begin .. end]` உடன் அடி மூலக்கூறு துண்டுகளை செயல்படுத்துகிறது.
///
/// பைட் வரம்பிலிருந்து கொடுக்கப்பட்ட சரத்தின் ஒரு பகுதியை வழங்குகிறது [`தொடங்கு`, `end`).
///
/// இந்த செயல்பாடு *O*(1).
///
/// 1.20.0 க்கு முன்னர், இந்த அட்டவணைப்படுத்தல் செயல்பாடுகள் `Index` மற்றும் `IndexMut` ஐ நேரடியாக செயல்படுத்துவதன் மூலம் ஆதரிக்கப்படுகின்றன.
///
/// # Panics
///
/// `begin` அல்லது `end` ஒரு எழுத்தின் தொடக்க பைட் ஆஃப்செட்டை சுட்டிக்காட்டவில்லை என்றால் (`is_char_boundary` ஆல் வரையறுக்கப்பட்டுள்ளது), `begin > end` என்றால், அல்லது `end > len` என்றால் Panics.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // இவை panic:
/// // பைட் 2 `ö` க்குள் உள்ளது:
/// // &கள் [2 ..3];
///
/// // பைட் 8 `老`&s க்குள் உள்ளது [1 ..
/// // 8];
///
/// // பைட் 100 சரம்&கள் [3 .. க்கு வெளியே உள்ளது.
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // பாதுகாப்பு: `start` மற்றும் `end` ஆகியவை கரி எல்லையில் உள்ளனவா என்று சோதித்தோம்,
            // நாங்கள் பாதுகாப்பான குறிப்பில் செல்கிறோம், எனவே வருவாய் மதிப்பும் ஒன்றாக இருக்கும்.
            // நாங்கள் கரி எல்லைகளையும் சரிபார்த்தோம், எனவே இது செல்லுபடியாகும் UTF-8 ஆகும்.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // பாதுகாப்பு: `start` மற்றும் `end` ஆகியவை கரி எல்லையில் உள்ளனவா என்று சோதித்தேன்.
            // `slice` இலிருந்து கிடைத்ததால் சுட்டிக்காட்டி தனித்துவமானது என்று எங்களுக்குத் தெரியும்.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // பாதுகாப்பு: `self` `slice` இன் எல்லைக்குள் இருப்பதாக அழைப்பாளர் உத்தரவாதம் அளிக்கிறார்
        // இது `add` க்கான அனைத்து நிபந்தனைகளையும் பூர்த்தி செய்கிறது.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // பாதுகாப்பு: `get_unchecked` க்கான கருத்துகளைப் பார்க்கவும்.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // குறியீட்டு எண் [0 இல் உள்ளதா என்று is_char_boundary சரிபார்க்கிறது, NLL சிக்கல் காரணமாக .len()] `get` ஐ மேலே பயன்படுத்த முடியாது.
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // பாதுகாப்பு: `start` மற்றும் `end` ஆகியவை கரி எல்லையில் உள்ளனவா என்று சோதித்தோம்,
            // நாங்கள் பாதுகாப்பான குறிப்பில் செல்கிறோம், எனவே வருவாய் மதிப்பும் ஒன்றாக இருக்கும்.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// தொடரியல் `&self[.. end]` அல்லது `&mut self[.. end]` உடன் அடி மூலக்கூறு துண்டுகளை செயல்படுத்துகிறது.
///
/// பைட் வரம்பிலிருந்து [`0`, `end`) கொடுக்கப்பட்ட சரத்தின் ஒரு பகுதியை வழங்குகிறது.
/// `&self[0 .. end]` அல்லது `&mut self[0 .. end]` க்கு சமம்.
///
/// இந்த செயல்பாடு *O*(1).
///
/// 1.20.0 க்கு முன்னர், இந்த அட்டவணைப்படுத்தல் செயல்பாடுகள் `Index` மற்றும் `IndexMut` ஐ நேரடியாக செயல்படுத்துவதன் மூலம் ஆதரிக்கப்படுகின்றன.
///
/// # Panics
///
/// `end` ஒரு எழுத்தின் தொடக்க பைட் ஆஃப்செட்டை சுட்டிக்காட்டவில்லை என்றால் (`is_char_boundary` ஆல் வரையறுக்கப்பட்டுள்ளது), அல்லது `end > len` என்றால் Panics.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // பாதுகாப்பு: `end` ஒரு கரி எல்லையில் இருக்கிறதா என்று சோதித்தேன்,
            // நாங்கள் பாதுகாப்பான குறிப்பில் செல்கிறோம், எனவே வருவாய் மதிப்பும் ஒன்றாக இருக்கும்.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // பாதுகாப்பு: `end` ஒரு கரி எல்லையில் இருக்கிறதா என்று சோதித்தேன்,
            // நாங்கள் பாதுகாப்பான குறிப்பில் செல்கிறோம், எனவே வருவாய் மதிப்பும் ஒன்றாக இருக்கும்.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // பாதுகாப்பு: `end` ஒரு கரி எல்லையில் இருக்கிறதா என்று சோதித்தேன்,
            // நாங்கள் பாதுகாப்பான குறிப்பில் செல்கிறோம், எனவே வருவாய் மதிப்பும் ஒன்றாக இருக்கும்.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// தொடரியல் `&self[begin ..]` அல்லது `&mut self[begin ..]` உடன் அடி மூலக்கூறு துண்டுகளை செயல்படுத்துகிறது.
///
/// பைட் வரம்பிலிருந்து கொடுக்கப்பட்ட சரத்தின் ஒரு பகுதியை வழங்குகிறது [`தொடங்கு`, `len`).`&சுயத்திற்கு சமம் [தொடக்கம் ..
/// len] `அல்லது`&mut self [begin ..
/// len]`.
///
/// இந்த செயல்பாடு *O*(1).
///
/// 1.20.0 க்கு முன்னர், இந்த அட்டவணைப்படுத்தல் செயல்பாடுகள் `Index` மற்றும் `IndexMut` ஐ நேரடியாக செயல்படுத்துவதன் மூலம் ஆதரிக்கப்படுகின்றன.
///
/// # Panics
///
/// `begin` ஒரு எழுத்தின் தொடக்க பைட் ஆஃப்செட்டை சுட்டிக்காட்டவில்லை என்றால் (`is_char_boundary` ஆல் வரையறுக்கப்பட்டுள்ளது), அல்லது `begin > len` என்றால் Panics.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // பாதுகாப்பு: `start` ஒரு கரி எல்லையில் இருக்கிறதா என்று சோதித்தேன்,
            // நாங்கள் பாதுகாப்பான குறிப்பில் செல்கிறோம், எனவே வருவாய் மதிப்பும் ஒன்றாக இருக்கும்.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // பாதுகாப்பு: `start` ஒரு கரி எல்லையில் இருக்கிறதா என்று சோதித்தேன்,
            // நாங்கள் பாதுகாப்பான குறிப்பில் செல்கிறோம், எனவே வருவாய் மதிப்பும் ஒன்றாக இருக்கும்.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // பாதுகாப்பு: `self` `slice` இன் எல்லைக்குள் இருப்பதாக அழைப்பாளர் உத்தரவாதம் அளிக்கிறார்
        // இது `add` க்கான அனைத்து நிபந்தனைகளையும் பூர்த்தி செய்கிறது.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // பாதுகாப்பு: `get_unchecked` க்கு ஒத்ததாகும்.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // பாதுகாப்பு: `start` ஒரு கரி எல்லையில் இருக்கிறதா என்று சோதித்தேன்,
            // நாங்கள் பாதுகாப்பான குறிப்பில் செல்கிறோம், எனவே வருவாய் மதிப்பும் ஒன்றாக இருக்கும்.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// தொடரியல் `&self[begin ..= end]` அல்லது `&mut self[begin ..= end]` உடன் அடி மூலக்கூறு துண்டுகளை செயல்படுத்துகிறது.
///
/// பைட் வரம்பு [`begin`, `end`] இலிருந்து கொடுக்கப்பட்ட சரத்தின் ஒரு பகுதியை வழங்குகிறது.`&self [begin .. end + 1]` அல்லது `&mut self[begin .. end + 1]` க்கு சமம், `end` க்கு `usize` க்கு அதிகபட்ச மதிப்பு இருந்தால் தவிர.
///
/// இந்த செயல்பாடு *O*(1).
///
/// # Panics
///
/// `begin` ஒரு எழுத்தின் தொடக்க பைட் ஆஃப்செட்டை சுட்டிக்காட்டவில்லை என்றால் (`is_char_boundary` ஆல் வரையறுக்கப்பட்டுள்ளது), `end` ஒரு எழுத்தின் முடிவுக்கு வரும் பைட் ஆஃப்செட்டை சுட்டிக்காட்டவில்லை என்றால் (`end + 1` என்பது ஒரு தொடக்க பைட் ஆஃப்செட் அல்லது `len` க்கு சமம்), `begin > end` என்றால், அல்லது `end >= len` என்றால்.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // பாதுகாப்பு: அழைப்பாளர் `get_unchecked` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // பாதுகாப்பு: அழைப்பாளர் `get_unchecked_mut` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// தொடரியல் `&self[..= end]` அல்லது `&mut self[..= end]` உடன் அடி மூலக்கூறு துண்டுகளை செயல்படுத்துகிறது.
///
/// பைட் வரம்பு [0, `end`] இலிருந்து கொடுக்கப்பட்ட சரத்தின் ஒரு துண்டை வழங்குகிறது.
/// `&self [0 .. end + 1]` க்கு சமமானதாகும், `end` க்கு `usize` க்கு அதிகபட்ச மதிப்பு இருந்தால் தவிர.
///
/// இந்த செயல்பாடு *O*(1).
///
/// # Panics
///
/// `end` ஒரு எழுத்தின் முடிவுக்கு வரும் பைட் ஆஃப்செட்டை சுட்டிக்காட்டவில்லை என்றால் Panics (`end + 1` என்பது `is_char_boundary` ஆல் வரையறுக்கப்பட்ட ஒரு தொடக்க பைட் ஆஃப்செட் அல்லது `len` க்கு சமம்), அல்லது `end >= len` என்றால்.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // பாதுகாப்பு: அழைப்பாளர் `get_unchecked` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // பாதுகாப்பு: அழைப்பாளர் `get_unchecked_mut` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// ஒரு சரத்திலிருந்து மதிப்பை அலசவும்
///
/// `FromStr` இன் [`from_str`] முறை பெரும்பாலும் [`str`] இன் [`parse`] முறை மூலம் மறைமுகமாக பயன்படுத்தப்படுகிறது.
/// எடுத்துக்காட்டுகளுக்கு [`பாகுபடுத்தி]] ஆவணங்களைக் காண்க.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` வாழ்நாள் அளவுரு இல்லை, எனவே நீங்கள் ஒரு வாழ்நாள் அளவுருவைக் கொண்டிருக்காத வகைகளை மட்டுமே அலச முடியும்.
///
/// வேறு வார்த்தைகளில் கூறுவதானால், நீங்கள் ஒரு `i32` ஐ `FromStr` உடன் அலசலாம், ஆனால் ஒரு `&i32` அல்ல.
/// நீங்கள் `i32` ஐக் கொண்ட ஒரு கட்டமைப்பை அலசலாம், ஆனால் `&i32` ஐக் கொண்ட ஒன்றல்ல.
///
/// # Examples
///
/// ஒரு எடுத்துக்காட்டில் `FromStr` இன் அடிப்படை செயல்படுத்தல் `Point` வகை:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// பாகுபடுத்தலில் இருந்து திரும்பப் பெறக்கூடிய தொடர்புடைய பிழை.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// இந்த வகையின் மதிப்பை வழங்க `s` சரம் பாகுபடுத்துகிறது.
    ///
    /// பாகுபடுத்தல் வெற்றிபெற்றால், [`Ok`] க்குள் மதிப்பைத் திருப்பி விடுங்கள், இல்லையெனில் சரம் தவறாக வடிவமைக்கப்பட்டிருக்கும்போது [`Err`] க்குள் குறிப்பிட்ட பிழையைத் தரும்.
    /// பிழை வகை trait ஐ செயல்படுத்துவதற்கு குறிப்பிட்டது.
    ///
    /// # Examples
    ///
    /// [`i32`] உடன் அடிப்படை பயன்பாடு, `FromStr` ஐ செயல்படுத்தும் ஒரு வகை:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// ஒரு சரத்திலிருந்து ஒரு `bool` ஐ அலசவும்.
    ///
    /// ஒரு `Result<bool, ParseBoolError>` ஐ அளிக்கிறது, ஏனெனில் `s` உண்மையில் பாகுபடுத்தப்படாமல் இருக்கலாம்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// குறிப்பு, பல சந்தர்ப்பங்களில், `str` இல் உள்ள `.parse()` முறை மிகவும் சரியானது.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}