//! utf8 பிழை வகையை வரையறுக்கிறது.

use crate::fmt;

/// [`u8`] இன் வரிசையை ஒரு சரமாக விளக்குவதற்கு முயற்சிக்கும்போது ஏற்படும் பிழைகள்.
///
/// எனவே, [`சரம்`] மற்றும் [`&str`] ஆகிய இரண்டிற்குமான செயல்பாடுகள் மற்றும் முறைகளின் `from_utf8` குடும்பம் இந்த பிழையைப் பயன்படுத்துகிறது, எடுத்துக்காட்டாக.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// குவியல் நினைவகத்தை ஒதுக்காமல் `String::from_utf8_lossy` க்கு ஒத்த செயல்பாட்டை உருவாக்க இந்த பிழை வகையின் முறைகள் பயன்படுத்தப்படலாம்:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// செல்லுபடியாகும் UTF-8 சரிபார்க்கப்பட்ட கொடுக்கப்பட்ட சரத்தில் குறியீட்டை வழங்குகிறது.
    ///
    /// இது `from_utf8(&input[..index])` `Ok(_)` ஐ வழங்கும் அதிகபட்ச குறியீடாகும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector இல் சில தவறான பைட்டுகள்
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 ஒரு Utf8Error ஐ வழங்குகிறது
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // இரண்டாவது பைட் இங்கே தவறானது
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// தோல்வி பற்றிய கூடுதல் தகவலை வழங்குகிறது:
    ///
    /// * `None`: உள்ளீட்டின் முடிவு எதிர்பாராத விதமாக எட்டப்பட்டது.
    ///   `self.valid_up_to()` உள்ளீட்டின் முடிவில் இருந்து 1 முதல் 3 பைட்டுகள் ஆகும்.
    ///   ஒரு பைட் ஸ்ட்ரீம் (ஒரு கோப்பு அல்லது நெட்வொர்க் சாக்கெட் போன்றவை) அதிக அளவில் டிகோட் செய்யப்படுமானால், இது செல்லுபடியாகும் `char` ஆக இருக்கலாம், அதன் UTF-8 பைட் வரிசை பல பகுதிகளாக பரவியுள்ளது.
    ///
    ///
    /// * `Some(len)`: எதிர்பாராத பைட் ஏற்பட்டது.
    ///   வழங்கப்பட்ட நீளம் `valid_up_to()` வழங்கிய குறியீட்டில் தொடங்கும் தவறான பைட் வரிசை.
    ///   இழப்பு டிகோடிங்கின் போது டிகோடிங் அந்த வரிசைக்குப் பிறகு (ஒரு [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] செருகப்பட்ட பிறகு) மீண்டும் தொடங்க வேண்டும்.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] ஐப் பயன்படுத்தி `bool` ஐ பாகுபடுத்தும்போது பிழை தோல்வியடைந்தது
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}