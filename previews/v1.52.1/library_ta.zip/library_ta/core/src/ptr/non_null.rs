use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ஆனால் பூஜ்ஜியமற்ற மற்றும் கோவாரியண்ட்.
///
/// மூல சுட்டிகளைப் பயன்படுத்தி தரவு கட்டமைப்புகளை உருவாக்கும்போது இது பெரும்பாலும் சரியான விஷயம், ஆனால் அதன் கூடுதல் பண்புகள் காரணமாக இறுதியில் பயன்படுத்த மிகவும் ஆபத்தானது.நீங்கள் `NonNull<T>` ஐப் பயன்படுத்த வேண்டுமா என்று உங்களுக்குத் தெரியாவிட்டால், `*mut T` ஐப் பயன்படுத்தவும்!
///
/// `*mut T` ஐப் போலன்றி, சுட்டிக்காட்டி ஒருபோதும் அழிக்கப்படாவிட்டாலும், சுட்டிக்காட்டி எப்போதும் பூஜ்யமாக இருக்கக்கூடாது.இது தடைசெய்யப்பட்ட மதிப்பை ஒரு பாகுபாடாக enums பயன்படுத்தக்கூடும்-`Option<NonNull<T>>` ஆனது `* mut T` ஐப் போன்ற அளவைக் கொண்டுள்ளது.
/// இருப்பினும், சுட்டிக்காட்டி அது குறிப்பிடப்படாவிட்டால் இன்னும் தொங்கக்கூடும்.
///
/// `*mut T` ஐப் போலன்றி, `NonNull<T>` ஆனது `T` ஐ விட ஒத்திசைவாக தேர்வு செய்யப்பட்டது.இது கோவாரியண்ட் வகைகளை உருவாக்கும்போது `NonNull<T>` ஐப் பயன்படுத்துவதை சாத்தியமாக்குகிறது, ஆனால் உண்மையில் கோவாரியனாக இருக்கக் கூடாத ஒரு வகையைப் பயன்படுத்தினால், ஆதாரமற்ற தன்மையை அறிமுகப்படுத்துகிறது.
/// (பாதுகாப்பற்ற செயல்பாடுகளை அழைப்பதன் மூலம் மட்டுமே தொழில்நுட்ப ரீதியாக குறைபாடு ஏற்படக்கூடும் என்றாலும், `*mut T` க்கு எதிர் தேர்வு செய்யப்பட்டது.)
///
/// `Box`, `Rc`, `Arc`, `Vec` மற்றும் `LinkedList` போன்ற மிகவும் பாதுகாப்பான சுருக்கங்களுக்கு கோவாரன்ஸ் சரியானது.Rust இன் சாதாரண பகிரப்பட்ட XOR மாற்றக்கூடிய விதிகளைப் பின்பற்றும் பொது API ஐ அவை வழங்குவதால் இதுதான்.
///
/// உங்கள் வகை பாதுகாப்பாக ஒத்துழைக்க முடியாவிட்டால், மாற்றத்தை வழங்க சில கூடுதல் புலம் இருப்பதை உறுதிப்படுத்த வேண்டும்.பெரும்பாலும் இந்த புலம் `PhantomData<Cell<T>>` அல்லது `PhantomData<&'a mut T>` போன்ற [`PhantomData`] வகையாக இருக்கும்.
///
/// X002 க்கு `NonNull<T>` ஒரு `From` உதாரணத்தைக் கொண்டுள்ளது என்பதைக் கவனியுங்கள்.எவ்வாறாயினும், ஒரு [`UnsafeCell<T>`] க்குள் பிறழ்வு நிகழும் வரை, ஒரு (ஒரு சுட்டிக்காட்டி இருந்து பெறப்பட்ட) பகிர்வு குறிப்பு மூலம் பிறழ்வு என்பது வரையறுக்கப்படாத நடத்தை என்ற உண்மையை இது மாற்றாது.பகிரப்பட்ட குறிப்பிலிருந்து மாற்றக்கூடிய குறிப்பை உருவாக்குவதற்கும் இதுவே செல்கிறது.
///
/// `UnsafeCell<T>` இல்லாமல் இந்த `From` நிகழ்வைப் பயன்படுத்தும் போது, `as_mut` ஒருபோதும் அழைக்கப்படுவதில்லை என்பதை உறுதிப்படுத்துவது உங்கள் பொறுப்பாகும், மேலும் `as_ptr` ஒருபோதும் பிறழ்வுக்குப் பயன்படுத்தப்படாது.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` சுட்டிகள் `Send` அல்ல, ஏனெனில் அவை குறிப்பிடும் தரவு மாற்றுப்பெயராக இருக்கலாம்.
// NB, இந்த impl தேவையற்றது, ஆனால் சிறந்த பிழை செய்திகளை வழங்க வேண்டும்.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` சுட்டிகள் `Sync` அல்ல, ஏனெனில் அவை குறிப்பிடும் தரவு மாற்றுப்பெயராக இருக்கலாம்.
// NB, இந்த impl தேவையற்றது, ஆனால் சிறந்த பிழை செய்திகளை வழங்க வேண்டும்.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// புதிய `NonNull` ஐ உருவாக்குகிறது, அது தொங்கும், ஆனால் நன்கு சீரமைக்கப்பட்டது.
    ///
    /// `Vec::new` போலவே சோம்பலாக ஒதுக்கக்கூடிய வகைகளைத் தொடங்க இது பயனுள்ளதாக இருக்கும்.
    ///
    /// சுட்டிக்காட்டி மதிப்பு ஒரு `T` க்கு செல்லுபடியாகும் சுட்டிக்காட்டியைக் குறிக்கக்கூடும் என்பதை நினைவில் கொள்க, அதாவது இது "not yet initialized" சென்டினல் மதிப்பாக பயன்படுத்தப்படக்கூடாது.
    /// சோம்பேறியாக ஒதுக்கும் வகைகள் வேறு சில வழிகளில் துவக்கத்தைக் கண்காணிக்க வேண்டும்.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // பாதுகாப்பு: mem::align_of() பூஜ்ஜியமற்ற பயன்பாட்டைத் தருகிறது, பின்னர் அது காஸ்ட் செய்யப்படுகிறது
        // to a * mut T.
        // எனவே, `ptr` பூஜ்யமானது அல்ல, மேலும் new_unchecked() ஐ அழைப்பதற்கான நிபந்தனைகள் மதிக்கப்படுகின்றன.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// மதிப்புக்கு பகிரப்பட்ட குறிப்புகளை வழங்குகிறது.[`as_ref`] க்கு மாறாக, மதிப்பை துவக்க வேண்டும் என்று இது தேவையில்லை.
    ///
    /// மாற்றக்கூடிய எண்ணுக்கு [`as_uninit_mut`] ஐப் பார்க்கவும்.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// இந்த முறையை அழைக்கும்போது, பின்வருபவை அனைத்தும் உண்மை என்பதை உறுதிப்படுத்த வேண்டும்:
    ///
    /// * சுட்டிக்காட்டி சரியாக சீரமைக்கப்பட வேண்டும்.
    ///
    /// * இது [the module documentation] இல் வரையறுக்கப்பட்ட அர்த்தத்தில் "dereferencable" ஆக இருக்க வேண்டும்.
    ///
    /// * நீங்கள் திரும்பிய வாழ்நாள் `'a` தன்னிச்சையாக தேர்ந்தெடுக்கப்பட்டிருப்பதால், தரவின் உண்மையான வாழ்நாளை பிரதிபலிக்காததால், நீங்கள் Rust இன் மாற்று விதிமுறைகளை செயல்படுத்த வேண்டும்.
    ///
    ///   குறிப்பாக, இந்த வாழ்நாளின் காலத்திற்கு, சுட்டிக்காட்டி சுட்டிக்காட்டும் நினைவகம் மாற்றமடையக்கூடாது (`UnsafeCell` க்குள் தவிர).
    ///
    /// இந்த முறையின் முடிவு பயன்படுத்தப்படாவிட்டாலும் இது பொருந்தும்!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // பாதுகாப்பு: அழைப்பாளர் `self` அனைத்தையும் சந்திப்பதாக உத்தரவாதம் அளிக்க வேண்டும்
        // குறிப்புக்கான தேவைகள்.
        unsafe { &*self.cast().as_ptr() }
    }

    /// மதிப்புக்கு தனிப்பட்ட குறிப்புகளை வழங்குகிறது.[`as_mut`] க்கு மாறாக, மதிப்பை துவக்க வேண்டும் என்று இது தேவையில்லை.
    ///
    /// பகிரப்பட்ட எண்ணுக்கு [`as_uninit_ref`] ஐப் பார்க்கவும்.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// இந்த முறையை அழைக்கும்போது, பின்வருபவை அனைத்தும் உண்மை என்பதை உறுதிப்படுத்த வேண்டும்:
    ///
    /// * சுட்டிக்காட்டி சரியாக சீரமைக்கப்பட வேண்டும்.
    ///
    /// * இது [the module documentation] இல் வரையறுக்கப்பட்ட அர்த்தத்தில் "dereferencable" ஆக இருக்க வேண்டும்.
    ///
    /// * நீங்கள் திரும்பிய வாழ்நாள் `'a` தன்னிச்சையாக தேர்ந்தெடுக்கப்பட்டிருப்பதால், தரவின் உண்மையான வாழ்நாளை பிரதிபலிக்காததால், நீங்கள் Rust இன் மாற்று விதிமுறைகளை செயல்படுத்த வேண்டும்.
    ///
    ///   குறிப்பாக, இந்த வாழ்நாளின் காலத்திற்கு, சுட்டிக்காட்டி சுட்டிக்காட்டும் நினைவகம் வேறு எந்த சுட்டிக்காட்டி மூலமாகவும் அணுகப்படக்கூடாது (படிக்க அல்லது எழுதப்படக்கூடாது).
    ///
    /// இந்த முறையின் முடிவு பயன்படுத்தப்படாவிட்டாலும் இது பொருந்தும்!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // பாதுகாப்பு: அழைப்பாளர் `self` அனைத்தையும் சந்திப்பதாக உத்தரவாதம் அளிக்க வேண்டும்
        // குறிப்புக்கான தேவைகள்.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// புதிய `NonNull` ஐ உருவாக்குகிறது.
    ///
    /// # Safety
    ///
    /// `ptr` பூஜ்யமாக இருக்க வேண்டும்.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // பாதுகாப்பு: அழைப்பாளர் `ptr` பூஜ்யமற்றது என்று உத்தரவாதம் அளிக்க வேண்டும்.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` பூஜ்யமாக இல்லாவிட்டால் புதிய `NonNull` ஐ உருவாக்குகிறது.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // பாதுகாப்பு: சுட்டிக்காட்டி ஏற்கனவே சரிபார்க்கப்பட்டது மற்றும் பூஜ்யமாக இல்லை
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// மூல `*const` சுட்டிக்காட்டிக்கு மாறாக, `NonNull` சுட்டிக்காட்டி திருப்பித் தரப்படுவதைத் தவிர, [`std::ptr::from_raw_parts`] இன் அதே செயல்பாட்டைச் செய்கிறது.
    ///
    ///
    /// மேலும் விவரங்களுக்கு [`std::ptr::from_raw_parts`] இன் ஆவணங்களைப் பார்க்கவும்.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // பாதுகாப்பு: `ptr::from::raw_parts_mut` இன் முடிவு பூஜ்யமானது அல்ல, ஏனெனில் `data_address`.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// முகவரி மற்றும் மெட்டாடேட்டா கூறுகள் ஒரு (சாத்தியமான பரந்த) சுட்டிக்காட்டி சிதைக்க.
    ///
    /// சுட்டிக்காட்டி பின்னர் [`NonNull::from_raw_parts`] உடன் புனரமைக்கப்படலாம்.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// அடிப்படை `*mut` சுட்டிக்காட்டி பெறுகிறது.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// மதிப்புக்கு பகிரப்பட்ட குறிப்பை வழங்குகிறது.மதிப்பு ஆரம்பிக்கப்படாவிட்டால், அதற்கு பதிலாக [`as_uninit_ref`] பயன்படுத்தப்பட வேண்டும்.
    ///
    /// மாற்றக்கூடிய எண்ணுக்கு [`as_mut`] ஐப் பார்க்கவும்.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// இந்த முறையை அழைக்கும்போது, பின்வருபவை அனைத்தும் உண்மை என்பதை உறுதிப்படுத்த வேண்டும்:
    ///
    /// * சுட்டிக்காட்டி சரியாக சீரமைக்கப்பட வேண்டும்.
    ///
    /// * இது [the module documentation] இல் வரையறுக்கப்பட்ட அர்த்தத்தில் "dereferencable" ஆக இருக்க வேண்டும்.
    ///
    /// * சுட்டிக்காட்டி `T` இன் துவக்கப்பட்ட நிகழ்வை சுட்டிக்காட்ட வேண்டும்.
    ///
    /// * நீங்கள் திரும்பிய வாழ்நாள் `'a` தன்னிச்சையாக தேர்ந்தெடுக்கப்பட்டிருப்பதால், தரவின் உண்மையான வாழ்நாளை பிரதிபலிக்காததால், நீங்கள் Rust இன் மாற்று விதிமுறைகளை செயல்படுத்த வேண்டும்.
    ///
    ///   குறிப்பாக, இந்த வாழ்நாளின் காலத்திற்கு, சுட்டிக்காட்டி சுட்டிக்காட்டும் நினைவகம் மாற்றமடையக்கூடாது (`UnsafeCell` க்குள் தவிர).
    ///
    /// இந்த முறையின் முடிவு பயன்படுத்தப்படாவிட்டாலும் இது பொருந்தும்!
    /// (துவக்கப்படுவது குறித்த பகுதி இன்னும் முழுமையாக முடிவு செய்யப்படவில்லை, ஆனால் அது இருக்கும் வரை, அவை உண்மையில் துவக்கப்படுவதை உறுதி செய்வதே ஒரே பாதுகாப்பான அணுகுமுறை.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // பாதுகாப்பு: அழைப்பாளர் `self` அனைத்தையும் சந்திப்பதாக உத்தரவாதம் அளிக்க வேண்டும்
        // குறிப்புக்கான தேவைகள்.
        unsafe { &*self.as_ptr() }
    }

    /// மதிப்புக்கு ஒரு தனிப்பட்ட குறிப்பை வழங்குகிறது.மதிப்பு ஆரம்பிக்கப்படாவிட்டால், அதற்கு பதிலாக [`as_uninit_mut`] பயன்படுத்தப்பட வேண்டும்.
    ///
    /// பகிரப்பட்ட எண்ணுக்கு [`as_ref`] ஐப் பார்க்கவும்.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// இந்த முறையை அழைக்கும்போது, பின்வருபவை அனைத்தும் உண்மை என்பதை உறுதிப்படுத்த வேண்டும்:
    ///
    /// * சுட்டிக்காட்டி சரியாக சீரமைக்கப்பட வேண்டும்.
    ///
    /// * இது [the module documentation] இல் வரையறுக்கப்பட்ட அர்த்தத்தில் "dereferencable" ஆக இருக்க வேண்டும்.
    ///
    /// * சுட்டிக்காட்டி `T` இன் துவக்கப்பட்ட நிகழ்வை சுட்டிக்காட்ட வேண்டும்.
    ///
    /// * நீங்கள் திரும்பிய வாழ்நாள் `'a` தன்னிச்சையாக தேர்ந்தெடுக்கப்பட்டிருப்பதால், தரவின் உண்மையான வாழ்நாளை பிரதிபலிக்காததால், நீங்கள் Rust இன் மாற்று விதிமுறைகளை செயல்படுத்த வேண்டும்.
    ///
    ///   குறிப்பாக, இந்த வாழ்நாளின் காலத்திற்கு, சுட்டிக்காட்டி சுட்டிக்காட்டும் நினைவகம் வேறு எந்த சுட்டிக்காட்டி மூலமாகவும் அணுகப்படக்கூடாது (படிக்க அல்லது எழுதப்படக்கூடாது).
    ///
    /// இந்த முறையின் முடிவு பயன்படுத்தப்படாவிட்டாலும் இது பொருந்தும்!
    /// (துவக்கப்படுவது குறித்த பகுதி இன்னும் முழுமையாக முடிவு செய்யப்படவில்லை, ஆனால் அது இருக்கும் வரை, அவை உண்மையில் துவக்கப்படுவதை உறுதி செய்வதே ஒரே பாதுகாப்பான அணுகுமுறை.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // பாதுகாப்பு: அழைப்பாளர் `self` அனைத்தையும் சந்திப்பதாக உத்தரவாதம் அளிக்க வேண்டும்
        // மாற்றக்கூடிய குறிப்புக்கான தேவைகள்.
        unsafe { &mut *self.as_ptr() }
    }

    /// மற்றொரு வகையின் சுட்டிக்காட்டிக்கு அனுப்புகிறது.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // பாதுகாப்பு: `self` என்பது ஒரு `NonNull` சுட்டிக்காட்டி, இது பூஜ்யமற்றது
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// ஒரு மெல்லிய சுட்டிக்காட்டி மற்றும் நீளத்திலிருந்து பூஜ்யமற்ற மூல துண்டுகளை உருவாக்குகிறது.
    ///
    /// `len` வாதம் **உறுப்புகளின் எண்ணிக்கை**, பைட்டுகளின் எண்ணிக்கை அல்ல.
    ///
    /// இந்த செயல்பாடு பாதுகாப்பானது, ஆனால் வருவாய் மதிப்பைக் குறிப்பது பாதுகாப்பற்றது.
    /// துண்டு பாதுகாப்பு தேவைகளுக்கு [`slice::from_raw_parts`] இன் ஆவணங்களைக் காண்க.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // முதல் உறுப்புக்கு ஒரு சுட்டிக்காட்டி தொடங்கும் போது ஒரு துண்டு சுட்டிக்காட்டி உருவாக்கவும்
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (இந்த எடுத்துக்காட்டு இந்த முறையின் பயன்பாட்டை செயற்கையாக நிரூபிக்கிறது என்பதை நினைவில் கொள்க, ஆனால் `துண்டு= NonNull::from(&x[..]);` would be a better way to write code like this.) ஐ விடுங்கள்
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // பாதுகாப்பு: `data` என்பது ஒரு `NonNull` சுட்டிக்காட்டி, இது பூஜ்யமற்றது
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// பூஜ்யமற்ற மூல துண்டுகளின் நீளத்தை வழங்குகிறது.
    ///
    /// திரும்பிய மதிப்பு **உறுப்புகளின் எண்ணிக்கை**, பைட்டுகளின் எண்ணிக்கை அல்ல.
    ///
    /// சுட்டிக்காட்டிக்கு சரியான முகவரி இல்லாததால், பூஜ்யமற்ற மூல துண்டுகளை ஒரு துண்டாகக் குறிப்பிட முடியாது என்றாலும் கூட, இந்த செயல்பாடு பாதுகாப்பானது.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// ஸ்லைஸின் இடையகத்திற்கு பூஜ்யமற்ற சுட்டிக்காட்டி வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // பாதுகாப்பு: `self` பூஜ்யமற்றது என்று எங்களுக்குத் தெரியும்.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// ஸ்லைஸின் இடையகத்திற்கு மூல சுட்டிக்காட்டி வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ஆரம்பிக்கப்படாத மதிப்புகளின் ஒரு பகுதிக்கு பகிரப்பட்ட குறிப்பை வழங்குகிறது.[`as_ref`] க்கு மாறாக, மதிப்பை துவக்க வேண்டும் என்று இது தேவையில்லை.
    ///
    /// மாற்றக்கூடிய எண்ணுக்கு [`as_uninit_slice_mut`] ஐப் பார்க்கவும்.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// இந்த முறையை அழைக்கும்போது, பின்வருபவை அனைத்தும் உண்மை என்பதை உறுதிப்படுத்த வேண்டும்:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` பல பைட்டுகளுக்கான வாசிப்புகளுக்கு சுட்டிக்காட்டி [valid] ஆக இருக்க வேண்டும், மேலும் அது சரியாக சீரமைக்கப்பட வேண்டும்.இதன் பொருள் குறிப்பாக:
    ///
    ///     * இந்த துண்டின் முழு நினைவக வரம்பும் ஒரு ஒதுக்கப்பட்ட பொருளுக்குள் இருக்க வேண்டும்!
    ///       ஒதுக்கப்பட்ட பல பொருள்களில் துண்டுகள் ஒருபோதும் பரவ முடியாது.
    ///
    ///     * சுட்டிக்காட்டி பூஜ்ஜிய நீள துண்டுகளுக்கு கூட சீரமைக்கப்பட வேண்டும்.
    ///     இதற்கு ஒரு காரணம் என்னவென்றால், enum தளவமைப்பு மேம்படுத்தல்கள் மற்ற தரவுகளிலிருந்து வேறுபடுவதற்கு குறிப்புகள் (எந்த நீளத்தின் துண்டுகள் உட்பட) சீரமைக்கப்பட்டன மற்றும் பூஜ்யமற்றவை.
    ///
    ///     [`NonNull::dangling()`] ஐப் பயன்படுத்தி பூஜ்ஜிய நீள துண்டுகளுக்கு `data` ஆகப் பயன்படுத்தக்கூடிய ஒரு சுட்டிக்காட்டி பெறலாம்.
    ///
    /// * ஸ்லைஸின் மொத்த அளவு `ptr.len() * mem::size_of::<T>()` `isize::MAX` ஐ விட பெரியதாக இருக்கக்கூடாது.
    ///   [`pointer::offset`] இன் பாதுகாப்பு ஆவணங்களைக் காண்க.
    ///
    /// * நீங்கள் திரும்பிய வாழ்நாள் `'a` தன்னிச்சையாக தேர்ந்தெடுக்கப்பட்டிருப்பதால், தரவின் உண்மையான வாழ்நாளை பிரதிபலிக்காததால், நீங்கள் Rust இன் மாற்று விதிமுறைகளை செயல்படுத்த வேண்டும்.
    ///   குறிப்பாக, இந்த வாழ்நாளின் காலத்திற்கு, சுட்டிக்காட்டி சுட்டிக்காட்டும் நினைவகம் மாற்றமடையக்கூடாது (`UnsafeCell` க்குள் தவிர).
    ///
    /// இந்த முறையின் முடிவு பயன்படுத்தப்படாவிட்டாலும் இது பொருந்தும்!
    ///
    /// [`slice::from_raw_parts`] ஐயும் காண்க.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // பாதுகாப்பு: அழைப்பாளர் `as_uninit_slice` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ஆரம்பிக்கப்படாத மதிப்புகளின் ஒரு துண்டுக்கு ஒரு தனிப்பட்ட குறிப்பை வழங்குகிறது.[`as_mut`] க்கு மாறாக, மதிப்பை துவக்க வேண்டும் என்று இது தேவையில்லை.
    ///
    /// பகிரப்பட்ட எண்ணுக்கு [`as_uninit_slice`] ஐப் பார்க்கவும்.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// இந்த முறையை அழைக்கும்போது, பின்வருபவை அனைத்தும் உண்மை என்பதை உறுதிப்படுத்த வேண்டும்:
    ///
    /// * சுட்டிக்காட்டி `ptr.len() * mem::size_of::<T>()` பல பைட்டுகளுக்கு வாசிப்பதற்கும் எழுதுவதற்கும் [valid] ஆக இருக்க வேண்டும், மேலும் அது சரியாக சீரமைக்கப்பட வேண்டும்.இதன் பொருள் குறிப்பாக:
    ///
    ///     * இந்த துண்டின் முழு நினைவக வரம்பும் ஒரு ஒதுக்கப்பட்ட பொருளுக்குள் இருக்க வேண்டும்!
    ///       ஒதுக்கப்பட்ட பல பொருள்களில் துண்டுகள் ஒருபோதும் பரவ முடியாது.
    ///
    ///     * சுட்டிக்காட்டி பூஜ்ஜிய நீள துண்டுகளுக்கு கூட சீரமைக்கப்பட வேண்டும்.
    ///     இதற்கு ஒரு காரணம் என்னவென்றால், enum தளவமைப்பு மேம்படுத்தல்கள் மற்ற தரவுகளிலிருந்து வேறுபடுவதற்கு குறிப்புகள் (எந்த நீளத்தின் துண்டுகள் உட்பட) சீரமைக்கப்பட்டன மற்றும் பூஜ்யமற்றவை.
    ///
    ///     [`NonNull::dangling()`] ஐப் பயன்படுத்தி பூஜ்ஜிய நீள துண்டுகளுக்கு `data` ஆகப் பயன்படுத்தக்கூடிய ஒரு சுட்டிக்காட்டி பெறலாம்.
    ///
    /// * ஸ்லைஸின் மொத்த அளவு `ptr.len() * mem::size_of::<T>()` `isize::MAX` ஐ விட பெரியதாக இருக்கக்கூடாது.
    ///   [`pointer::offset`] இன் பாதுகாப்பு ஆவணங்களைக் காண்க.
    ///
    /// * நீங்கள் திரும்பிய வாழ்நாள் `'a` தன்னிச்சையாக தேர்ந்தெடுக்கப்பட்டிருப்பதால், தரவின் உண்மையான வாழ்நாளை பிரதிபலிக்காததால், நீங்கள் Rust இன் மாற்று விதிமுறைகளை செயல்படுத்த வேண்டும்.
    ///   குறிப்பாக, இந்த வாழ்நாளின் காலத்திற்கு, சுட்டிக்காட்டி சுட்டிக்காட்டும் நினைவகம் வேறு எந்த சுட்டிக்காட்டி மூலமாகவும் அணுகப்படக்கூடாது (படிக்க அல்லது எழுதப்படக்கூடாது).
    ///
    /// இந்த முறையின் முடிவு பயன்படுத்தப்படாவிட்டாலும் இது பொருந்தும்!
    ///
    /// [`slice::from_raw_parts_mut`] ஐயும் காண்க.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // `memory` பல பைட்டுகளுக்கு படிக்க மற்றும் எழுதுவதற்கு `memory` செல்லுபடியாகும் என்பதால் இது பாதுகாப்பானது.
    /// // உள்ளடக்கம் ஆரம்பிக்கப்படாததால் `memory.as_mut()` ஐ அழைப்பது இங்கு அனுமதிக்கப்படாது என்பதை நினைவில் கொள்க.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // பாதுகாப்பு: அழைப்பாளர் `as_uninit_slice_mut` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// வரம்புகளைச் சரிபார்க்காமல், ஒரு மூல சுட்டிக்காட்டி ஒரு உறுப்பு அல்லது துணைக்குத் தருகிறது.
    ///
    /// இந்த முறையை எல்லைக்கு அப்பாற்பட்ட குறியீட்டுடன் அழைப்பது அல்லது `self` குறைக்க முடியாதபோது *[வரையறுக்கப்படாத நடத்தை]* இதன் விளைவாக சுட்டிக்காட்டி பயன்படுத்தப்படாவிட்டாலும் கூட.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // பாதுகாப்பு: அழைப்பாளர் `self` குறைக்க முடியாதது மற்றும் `index` எல்லைக்குட்பட்டது என்பதை உறுதி செய்கிறது.
        // இதன் விளைவாக, விளைந்த சுட்டிக்காட்டி NULL ஆக இருக்க முடியாது.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // பாதுகாப்பு: ஒரு தனித்துவமான சுட்டிக்காட்டி பூஜ்யமாக இருக்க முடியாது, எனவே அதற்கான நிபந்தனைகள்
        // new_unchecked() மதிக்கப்படுகிறார்கள்.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // பாதுகாப்பு: மாற்றக்கூடிய குறிப்பு பூஜ்யமாக இருக்க முடியாது.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // பாதுகாப்பு: ஒரு குறிப்பு பூஜ்யமாக இருக்க முடியாது, எனவே அதற்கான நிபந்தனைகள்
        // new_unchecked() மதிக்கப்படுகிறார்கள்.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}