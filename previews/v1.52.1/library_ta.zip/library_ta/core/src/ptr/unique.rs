use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// ஒரு மூல அல்லாத பூஜ்யம் அல்லாத `*mut T` ஐச் சுற்றி ஒரு ரேப்பர், இந்த ரேப்பரை வைத்திருப்பவர் குறிப்புக்கு சொந்தமானவர் என்பதைக் குறிக்கிறது.
/// `Box<T>`, `Vec<T>`, `String` மற்றும் `HashMap<K, V>` போன்ற சுருக்கங்களை உருவாக்க பயனுள்ளதாக இருக்கும்.
///
/// `*mut T` போலல்லாமல், `Unique<T>` "as if" ஆக செயல்படுகிறது, இது `T` இன் ஒரு எடுத்துக்காட்டு.
/// `T` `Send`/`Sync` ஆக இருந்தால் இது `Send`/`Sync` ஐ செயல்படுத்துகிறது.
/// `T` இன் ஒரு நிகழ்வு எதிர்பார்க்கக்கூடிய வலுவான மாற்றுப்பெயர்ச்சி உத்தரவாதங்களையும் இது குறிக்கிறது:
/// சுட்டிக்காட்டி அதன் சொந்த தனித்துவமான ஒரு தனித்துவமான பாதை இல்லாமல் மாற்றியமைக்கப்படக்கூடாது.
///
/// உங்கள் நோக்கங்களுக்காக `Unique` ஐப் பயன்படுத்துவது சரியானதா என்று உங்களுக்குத் தெரியாவிட்டால், பலவீனமான சொற்பொருளைக் கொண்ட `NonNull` ஐப் பயன்படுத்துங்கள்.
///
///
/// `*mut T` ஐப் போலன்றி, சுட்டிக்காட்டி ஒருபோதும் அழிக்கப்படாவிட்டாலும், சுட்டிக்காட்டி எப்போதும் பூஜ்யமாக இருக்கக்கூடாது.
/// இது தடைசெய்யப்பட்ட மதிப்பை ஒரு பாகுபாடாக enums பயன்படுத்தக்கூடும்-`Option<Unique<T>>` ஆனது `Unique<T>` ஐப் போன்ற அளவைக் கொண்டுள்ளது.
/// இருப்பினும், சுட்டிக்காட்டி அது குறிப்பிடப்படாவிட்டால் இன்னும் தொங்கக்கூடும்.
///
/// `*mut T` போலல்லாமல், `Unique<T>` என்பது `T` ஐ விட கோவாரியண்ட் ஆகும்.
/// யுனிக் இன் மாற்றுப்பெயர்ச்சி தேவைகளை ஆதரிக்கும் எந்த வகையிலும் இது எப்போதும் சரியாக இருக்க வேண்டும்.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: இந்த மார்க்கருக்கு மாறுபாட்டிற்கு எந்த விளைவுகளும் இல்லை, ஆனால் அவசியம்
    // தர்க்கரீதியாக நாங்கள் ஒரு `T` ஐ வைத்திருக்கிறோம் என்பதை டிராப் புரிந்துகொள்ள.
    //
    // விவரங்களுக்கு, காண்க:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` சுட்டிகள் `Send` என்றால் `T` `Send` ஆக இருப்பதால் அவை குறிப்பிடும் தரவு நம்பத்தகாதது.
/// இந்த மாற்றுப்பெயர்ச்சி மாறுபாடு வகை அமைப்பால் செயல்படுத்தப்படவில்லை என்பதை நினைவில் கொள்க;`Unique` ஐப் பயன்படுத்தி சுருக்கம் அதைச் செயல்படுத்த வேண்டும்.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` சுட்டிகள் `Sync` என்றால் `T` `Sync` ஆக இருப்பதால் அவை குறிப்பிடும் தரவு நம்பத்தகாதது.
/// இந்த மாற்றுப்பெயர்ச்சி மாறுபாடு வகை அமைப்பால் செயல்படுத்தப்படவில்லை என்பதை நினைவில் கொள்க;`Unique` ஐப் பயன்படுத்தி சுருக்கம் அதைச் செயல்படுத்த வேண்டும்.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// புதிய `Unique` ஐ உருவாக்குகிறது, அது தொங்கும், ஆனால் நன்கு சீரமைக்கப்பட்டது.
    ///
    /// `Vec::new` போலவே சோம்பலாக ஒதுக்கக்கூடிய வகைகளைத் தொடங்க இது பயனுள்ளதாக இருக்கும்.
    ///
    /// சுட்டிக்காட்டி மதிப்பு ஒரு `T` க்கு செல்லுபடியாகும் சுட்டிக்காட்டியைக் குறிக்கக்கூடும் என்பதை நினைவில் கொள்க, அதாவது இது "not yet initialized" சென்டினல் மதிப்பாக பயன்படுத்தப்படக்கூடாது.
    /// சோம்பேறியாக ஒதுக்கும் வகைகள் வேறு சில வழிகளில் துவக்கத்தைக் கண்காணிக்க வேண்டும்.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // பாதுகாப்பு: mem::align_of() செல்லுபடியாகும், பூஜ்யமற்ற சுட்டிக்காட்டி வழங்குகிறது.தி
        // new_unchecked() ஐ அழைப்பதற்கான நிபந்தனைகள் இவ்வாறு மதிக்கப்படுகின்றன.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// புதிய `Unique` ஐ உருவாக்குகிறது.
    ///
    /// # Safety
    ///
    /// `ptr` பூஜ்யமாக இருக்க வேண்டும்.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // பாதுகாப்பு: அழைப்பாளர் `ptr` பூஜ்யமற்றது என்று உத்தரவாதம் அளிக்க வேண்டும்.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` பூஜ்யமாக இல்லாவிட்டால் புதிய `Unique` ஐ உருவாக்குகிறது.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // பாதுகாப்பு: சுட்டிக்காட்டி ஏற்கனவே சரிபார்க்கப்பட்டது மற்றும் பூஜ்யமாக இல்லை.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// அடிப்படை `*mut` சுட்டிக்காட்டி பெறுகிறது.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// உள்ளடக்கத்தை விலக்குகிறது.
    ///
    /// இதன் விளைவாக வரும் வாழ்நாள் சுயத்துடன் பிணைக்கப்பட்டுள்ளது, எனவே இது "as if" ஆக செயல்படுகிறது, இது உண்மையில் T இன் ஒரு எடுத்துக்காட்டு.
    /// நீண்ட (unbound) வாழ்நாள் தேவைப்பட்டால், `&*my_ptr.as_ptr()` ஐப் பயன்படுத்தவும்.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // பாதுகாப்பு: அழைப்பாளர் `self` அனைத்தையும் சந்திப்பதாக உத்தரவாதம் அளிக்க வேண்டும்
        // குறிப்புக்கான தேவைகள்.
        unsafe { &*self.as_ptr() }
    }

    /// உள்ளடக்கத்தை மாற்றியமைக்கிறது.
    ///
    /// இதன் விளைவாக வரும் வாழ்நாள் சுயத்துடன் பிணைக்கப்பட்டுள்ளது, எனவே இது "as if" ஆக செயல்படுகிறது, இது உண்மையில் T இன் ஒரு எடுத்துக்காட்டு.
    /// நீண்ட (unbound) வாழ்நாள் தேவைப்பட்டால், `&mut *my_ptr.as_ptr()` ஐப் பயன்படுத்தவும்.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // பாதுகாப்பு: அழைப்பாளர் `self` அனைத்தையும் சந்திப்பதாக உத்தரவாதம் அளிக்க வேண்டும்
        // மாற்றக்கூடிய குறிப்புக்கான தேவைகள்.
        unsafe { &mut *self.as_ptr() }
    }

    /// மற்றொரு வகையின் சுட்டிக்காட்டிக்கு அனுப்புகிறது.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // பாதுகாப்பு: Unique::new_unchecked() ஒரு புதிய தனித்துவமான மற்றும் தேவைகளை உருவாக்குகிறது
        // கொடுக்கப்பட்ட சுட்டிக்காட்டி பூஜ்யமாக இருக்கக்கூடாது.
        // நாம் ஒரு சுட்டிக்காட்டி என சுயமாக கடந்து செல்வதால், அது பூஜ்யமாக இருக்க முடியாது.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // பாதுகாப்பு: மாற்றக்கூடிய குறிப்பு பூஜ்யமாக இருக்க முடியாது
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}