//! 'மறைமுகமாக நகலெடுக்க முடியாத' வகைகளுக்கான `Clone` trait.
//!
//! Rust இல், சில எளிய வகைகள் "implicitly copyable" மற்றும் நீங்கள் அவற்றை ஒதுக்கும்போது அல்லது அவற்றை வாதங்களாக அனுப்பும்போது, பெறுநருக்கு ஒரு நகல் கிடைக்கும், அசல் மதிப்பை அந்த இடத்தில் விட்டுவிடும்.
//! இந்த வகைகளுக்கு நகலெடுப்பதற்கான ஒதுக்கீடு தேவையில்லை மற்றும் இறுதிப் பொருள்கள் இல்லை (அதாவது, அவை சொந்தமான பெட்டிகளைக் கொண்டிருக்கவில்லை அல்லது [`Drop`] ஐ செயல்படுத்துகின்றன), எனவே தொகுப்பி அவற்றை மலிவானதாகவும் நகலெடுக்க பாதுகாப்பாகவும் கருதுகிறது.
//!
//! [`Clone`] trait ஐ செயல்படுத்துவதன் மூலமும், [`clone`] முறையை அழைப்பதன் மூலமும், பிற வகைகளுக்கு பிரதிகள் வெளிப்படையாக செய்யப்பட வேண்டும்.
//!
//! [`clone`]: Clone::clone
//!
//! அடிப்படை பயன்பாட்டு எடுத்துக்காட்டு:
//!
//! ```
//! let s = String::new(); // சரம் வகை குளோனை செயல்படுத்துகிறது
//! let copy = s.clone(); // எனவே நாம் அதை குளோன் செய்யலாம்
//! ```
//!
//! trait குளோனை எளிதில் செயல்படுத்த, நீங்கள் `#[derive(Clone)]` ஐயும் பயன்படுத்தலாம்.உதாரணமாக:
//!
//! ```
//! #[derive(Clone)] // trait குளோனை மார்பியஸ் கட்டமைப்பில் சேர்க்கிறோம்
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // இப்போது நாம் அதை குளோன் செய்யலாம்!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// ஒரு பொருளை வெளிப்படையாக நகலெடுக்கும் திறனுக்கான பொதுவான trait.
///
/// அந்த [`Copy`] இல் [`Copy`] இலிருந்து வேறுபாடுகள் மறைமுகமானவை மற்றும் மிகவும் மலிவானவை, அதே நேரத்தில் `Clone` எப்போதும் வெளிப்படையானது மற்றும் விலை உயர்ந்ததாக இருக்கலாம் அல்லது இல்லாமல் இருக்கலாம்.
/// இந்த குணாதிசயங்களைச் செயல்படுத்த, 0Rust உங்களை [`Copy`] ஐ மறுசீரமைக்க அனுமதிக்காது, ஆனால் நீங்கள் `Clone` ஐ மறுசீரமைத்து தன்னிச்சையான குறியீட்டை இயக்கலாம்.
///
/// [`Copy`] ஐ விட `Clone` மிகவும் பொதுவானது என்பதால், நீங்கள் தானாகவே [`Copy`] ஐ `Clone` ஆகவும் செய்யலாம்.
///
/// ## Derivable
///
/// எல்லா புலங்களும் `Clone` ஆக இருந்தால் இந்த trait ஐ `#[derive]` உடன் பயன்படுத்தலாம்.[`Clone`] இன் `டெரிவ்` டி செயல்படுத்தல் ஒவ்வொரு துறையிலும் [`clone`] ஐ அழைக்கிறது.
///
/// [`clone`]: Clone::clone
///
/// பொதுவான கட்டமைப்பிற்கு, பொதுவான அளவுருக்களில் பிணைக்கப்பட்ட `Clone` ஐ சேர்ப்பதன் மூலம் `#[derive]` `Clone` ஐ நிபந்தனையுடன் செயல்படுத்துகிறது.
///
/// ```
/// // `derive` வாசிப்பதற்கான குளோனை செயல்படுத்துகிறது<T>டி குளோன் போது.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## `Clone` ஐ எவ்வாறு செயல்படுத்தலாம்?
///
/// [`Copy`] எனப்படும் வகைகள் `Clone` இன் அற்பமான செயல்பாட்டைக் கொண்டிருக்க வேண்டும்.மேலும் முறையாக:
/// `T: Copy`, `x: T` மற்றும் `y: &T` எனில், `let x = y.clone();` என்பது `let x = *y;` க்கு சமம்.
/// கையேடு செயலாக்கங்கள் இந்த மாற்றத்தை நிலைநிறுத்த கவனமாக இருக்க வேண்டும்;இருப்பினும், நினைவக பாதுகாப்பை உறுதிப்படுத்த பாதுகாப்பற்ற குறியீடு அதை நம்பக்கூடாது.
///
/// ஒரு செயல்பாடு சுட்டிக்காட்டி வைத்திருக்கும் பொதுவான கட்டமைப்பு ஒரு எடுத்துக்காட்டு.இந்த வழக்கில், `Clone` இன் செயல்பாட்டை `பெற முடியாது ', ஆனால் இதை செயல்படுத்தலாம்:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## கூடுதல் செயல்படுத்துபவர்கள்
///
/// [implementors listed below][impls] ஐத் தவிர, பின்வரும் வகைகளும் `Clone` ஐ செயல்படுத்துகின்றன:
///
/// * செயல்பாட்டு உருப்படி வகைகள் (அதாவது, ஒவ்வொரு செயல்பாட்டிற்கும் வரையறுக்கப்பட்ட தனித்துவமான வகைகள்)
/// * செயல்பாட்டு சுட்டிக்காட்டி வகைகள் (எ.கா., `fn() -> i32`)
/// * உருப்படி வகை `Clone` ஐ (எ.கா., `[i32; 123456]`) செயல்படுத்தினால், அனைத்து அளவுகளுக்கும் வரிசை வகைகள்
/// * ஒவ்வொரு கூறுகளும் `Clone` ஐ (எ.கா., `()`, `(i32, bool)`) செயல்படுத்தினால், இரட்டை வகைகள்
/// * மூடல் வகைகள், அவை சூழலில் இருந்து எந்த மதிப்பையும் கைப்பற்றவில்லை என்றால் அல்லது அத்தகைய கைப்பற்றப்பட்ட மதிப்புகள் அனைத்தும் `Clone` ஐ செயல்படுத்தினால்.
///   பகிரப்பட்ட குறிப்பால் கைப்பற்றப்பட்ட மாறிகள் எப்போதும் `Clone` ஐ செயல்படுத்துகின்றன (குறிப்பு இல்லாவிட்டாலும் கூட), அதே சமயம் மாற்றக்கூடிய குறிப்பால் கைப்பற்றப்பட்ட மாறிகள் `Clone` ஐ ஒருபோதும் செயல்படுத்தாது.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// மதிப்பின் நகலை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str குளோன் செயல்படுத்துகிறது
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` இலிருந்து நகல்-ஒதுக்கீட்டைச் செய்கிறது.
    ///
    /// `a.clone_from(&b)` செயல்பாட்டில் `a = b.clone()` க்கு சமம், ஆனால் தேவையற்ற ஒதுக்கீடுகளைத் தவிர்க்க `a` இன் வளங்களை மீண்டும் பயன்படுத்த மீறலாம்.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` இன் ஒரு impl ஐ உருவாக்கும் மேக்ரோ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ஒரு வகையின் ஒவ்வொரு கூறுகளும் குளோன் அல்லது நகலை செயல்படுத்துகின்றன என்பதை உறுதிப்படுத்த இந்த கட்டமைப்புகள்#[பெறுகின்றன] மட்டுமே பயன்படுத்தப்படுகின்றன.
//
//
// இந்த கட்டமைப்புகள் ஒருபோதும் பயனர் குறியீட்டில் தோன்றக்கூடாது.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// பழமையான வகைகளுக்கு `Clone` இன் செயல்பாடுகள்.
///
/// Rust இல் விவரிக்க முடியாத செயல்படுத்தல்கள் `rustc_trait_selection` இல் `traits::SelectionContext::copy_clone_conditions()` இல் செயல்படுத்தப்படுகின்றன.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// பகிரப்பட்ட குறிப்புகளை குளோன் செய்யலாம், ஆனால் மாற்றக்கூடிய குறிப்புகள் *முடியாது*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// பகிரப்பட்ட குறிப்புகளை குளோன் செய்யலாம், ஆனால் மாற்றக்கூடிய குறிப்புகள் *முடியாது*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}