#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // அழைப்பாளரின் பதிப்பைப் பொறுத்து `$crate::panic::panic_2015` அல்லது `$crate::panic::panic_2021` க்கு விரிவடைகிறது.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// இரண்டு வெளிப்பாடுகள் ஒருவருக்கொருவர் சமம் என்று கூறுகிறது ([`PartialEq`] ஐப் பயன்படுத்தி).
///
/// panic இல், இந்த மேக்ரோ வெளிப்பாடுகளின் மதிப்புகளை அவற்றின் பிழைத்திருத்த பிரதிநிதித்துவங்களுடன் அச்சிடும்.
///
///
/// [`assert!`] ஐப் போலவே, இந்த மேக்ரோவும் இரண்டாவது வடிவத்தைக் கொண்டுள்ளது, அங்கு தனிப்பயன் panic செய்தியை வழங்க முடியும்.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // கீழே உள்ள மறுபிரதிகள் வேண்டுமென்றே.
                    // அவை இல்லாமல், மதிப்புகள் ஒப்பிடுவதற்கு முன்பே கடன் பெறுவதற்கான ஸ்டாக் ஸ்லாட் துவக்கப்படுகிறது, இது குறிப்பிடத்தக்க மெதுவாக்கத்திற்கு வழிவகுக்கிறது.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // கீழே உள்ள மறுபிரதிகள் வேண்டுமென்றே.
                    // அவை இல்லாமல், மதிப்புகள் ஒப்பிடுவதற்கு முன்பே கடன் பெறுவதற்கான ஸ்டாக் ஸ்லாட் துவக்கப்படுகிறது, இது குறிப்பிடத்தக்க மெதுவாக்கத்திற்கு வழிவகுக்கிறது.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// இரண்டு வெளிப்பாடுகள் ஒருவருக்கொருவர் சமமாக இல்லை என்று கூறுகிறது ([`PartialEq`] ஐப் பயன்படுத்துதல்).
///
/// panic இல், இந்த மேக்ரோ வெளிப்பாடுகளின் மதிப்புகளை அவற்றின் பிழைத்திருத்த பிரதிநிதித்துவங்களுடன் அச்சிடும்.
///
///
/// [`assert!`] ஐப் போலவே, இந்த மேக்ரோவும் இரண்டாவது வடிவத்தைக் கொண்டுள்ளது, அங்கு தனிப்பயன் panic செய்தியை வழங்க முடியும்.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // கீழே உள்ள மறுபிரதிகள் வேண்டுமென்றே.
                    // அவை இல்லாமல், மதிப்புகள் ஒப்பிடுவதற்கு முன்பே கடன் பெறுவதற்கான ஸ்டாக் ஸ்லாட் துவக்கப்படுகிறது, இது குறிப்பிடத்தக்க மெதுவாக்கத்திற்கு வழிவகுக்கிறது.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // கீழே உள்ள மறுபிரதிகள் வேண்டுமென்றே.
                    // அவை இல்லாமல், மதிப்புகள் ஒப்பிடுவதற்கு முன்பே கடன் பெறுவதற்கான ஸ்டாக் ஸ்லாட் துவக்கப்படுகிறது, இது குறிப்பிடத்தக்க மெதுவாக்கத்திற்கு வழிவகுக்கிறது.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// இயக்க நேரத்தில் ஒரு பூலியன் வெளிப்பாடு `true` என்று கூறுகிறது.
///
/// வழங்கப்பட்ட வெளிப்பாட்டை இயக்க நேரத்தில் `true` க்கு மதிப்பீடு செய்ய முடியாவிட்டால் இது [`panic!`] மேக்ரோவை செயல்படுத்தும்.
///
/// [`assert!`] ஐப் போலவே, இந்த மேக்ரோவும் இரண்டாவது பதிப்பைக் கொண்டுள்ளது, அங்கு தனிப்பயன் panic செய்தியை வழங்க முடியும்.
///
/// # Uses
///
/// [`assert!`] போலல்லாமல், `debug_assert!` அறிக்கைகள் இயல்பாகவே உகந்ததாக இல்லாத கட்டடங்களில் மட்டுமே இயக்கப்பட்டன.
/// `-C debug-assertions` கம்பைலருக்கு அனுப்பப்படாவிட்டால் உகந்த கட்டமைப்பானது `debug_assert!` அறிக்கைகளை இயக்காது.
/// இது வெளியீட்டு கட்டமைப்பில் இருப்பதற்கு மிகவும் விலை உயர்ந்த காசோலைகளுக்கு `debug_assert!` பயனுள்ளதாக இருக்கும், ஆனால் வளர்ச்சியின் போது உதவியாக இருக்கும்.
/// `debug_assert!` ஐ விரிவாக்குவதன் விளைவாக எப்போதும் வகை சரிபார்க்கப்படுகிறது.
///
/// சரிபார்க்கப்படாத ஒரு கூற்று ஒரு சீரற்ற நிலையில் ஒரு நிரலை இயங்க அனுமதிக்கிறது, இது எதிர்பாராத விளைவுகளை ஏற்படுத்தக்கூடும், ஆனால் இது பாதுகாப்பான குறியீட்டில் மட்டுமே நிகழும் வரை பாதுகாப்பற்ற தன்மையை அறிமுகப்படுத்தாது.
///
/// இருப்பினும், வலியுறுத்தல்களின் செயல்திறன் செலவு பொதுவாக அளவிட முடியாது.
/// [`assert!`] ஐ `debug_assert!` உடன் மாற்றுவது முழுமையான விவரக்குறிப்புக்குப் பிறகு மட்டுமே ஊக்குவிக்கப்படுகிறது, மேலும் முக்கியமாக, பாதுகாப்பான குறியீட்டில் மட்டுமே!
///
/// # Examples
///
/// ```
/// // இந்த கூற்றுக்களுக்கான panic செய்தி கொடுக்கப்பட்ட வெளிப்பாட்டின் கடுமையான மதிப்பு.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // மிகவும் எளிமையான செயல்பாடு
/// debug_assert!(some_expensive_computation());
///
/// // தனிப்பயன் செய்தியுடன் வலியுறுத்தவும்
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// இரண்டு வெளிப்பாடுகள் ஒருவருக்கொருவர் சமம் என்று கூறுகிறது.
///
/// panic இல், இந்த மேக்ரோ வெளிப்பாடுகளின் மதிப்புகளை அவற்றின் பிழைத்திருத்த பிரதிநிதித்துவங்களுடன் அச்சிடும்.
///
/// [`assert_eq!`] போலல்லாமல், `debug_assert_eq!` அறிக்கைகள் இயல்பாகவே உகந்ததாக இல்லாத கட்டடங்களில் மட்டுமே இயக்கப்பட்டன.
/// `-C debug-assertions` கம்பைலருக்கு அனுப்பப்படாவிட்டால் உகந்த கட்டமைப்பானது `debug_assert_eq!` அறிக்கைகளை இயக்காது.
/// வெளியீட்டு கட்டமைப்பில் இருப்பதற்கு மிகவும் விலை உயர்ந்த காசோலைகளுக்கு இது `debug_assert_eq!` பயனுள்ளதாக இருக்கும், ஆனால் வளர்ச்சியின் போது உதவியாக இருக்கும்.
///
/// `debug_assert_eq!` ஐ விரிவாக்குவதன் விளைவாக எப்போதும் வகை சரிபார்க்கப்படுகிறது.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// இரண்டு வெளிப்பாடுகள் ஒருவருக்கொருவர் சமமாக இல்லை என்று கூறுகிறது.
///
/// panic இல், இந்த மேக்ரோ வெளிப்பாடுகளின் மதிப்புகளை அவற்றின் பிழைத்திருத்த பிரதிநிதித்துவங்களுடன் அச்சிடும்.
///
/// [`assert_ne!`] போலல்லாமல், `debug_assert_ne!` அறிக்கைகள் இயல்பாகவே உகந்ததாக இல்லாத கட்டடங்களில் மட்டுமே இயக்கப்பட்டன.
/// `-C debug-assertions` கம்பைலருக்கு அனுப்பப்படாவிட்டால் உகந்த கட்டமைப்பானது `debug_assert_ne!` அறிக்கைகளை இயக்காது.
/// இது வெளியீட்டு கட்டமைப்பில் இருப்பதற்கு மிகவும் விலை உயர்ந்த காசோலைகளுக்கு `debug_assert_ne!` பயனுள்ளதாக இருக்கும், ஆனால் வளர்ச்சியின் போது உதவியாக இருக்கும்.
///
/// `debug_assert_ne!` ஐ விரிவாக்குவதன் விளைவாக எப்போதும் வகை சரிபார்க்கப்படுகிறது.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// கொடுக்கப்பட்ட வெளிப்பாடு கொடுக்கப்பட்ட எந்த வடிவங்களுடனும் பொருந்துமா என்பதை வழங்குகிறது.
///
/// ஒரு `match` வெளிப்பாட்டைப் போலவே, அமைப்பையும் விருப்பமாக `if` மற்றும் ஒரு பாதுகாப்பு வெளிப்பாடு ஆகியவற்றைப் பின்பற்றலாம், இது வடிவத்தால் பிணைக்கப்பட்ட பெயர்களுக்கான அணுகலைக் கொண்டுள்ளது.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// ஒரு முடிவை அவிழ்த்து விடுகிறது அல்லது அதன் பிழையை பரப்புகிறது.
///
/// `try!` ஐ மாற்ற `?` ஆபரேட்டர் சேர்க்கப்பட்டது, அதற்கு பதிலாக பயன்படுத்தப்பட வேண்டும்.
/// மேலும், `try` என்பது Rust 2018 இல் ஒதுக்கப்பட்ட சொல், எனவே நீங்கள் இதைப் பயன்படுத்த வேண்டும் என்றால், நீங்கள் [raw-identifier syntax][ris] ஐப் பயன்படுத்த வேண்டும்: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` கொடுக்கப்பட்ட [`Result`] உடன் பொருந்துகிறது.`Ok` மாறுபாட்டின் விஷயத்தில், வெளிப்பாடு மூடப்பட்ட மதிப்பின் மதிப்பைக் கொண்டுள்ளது.
///
/// `Err` மாறுபாட்டின் விஷயத்தில், அது உள் பிழையை மீட்டெடுக்கிறது.`try!` பின்னர் `From` ஐப் பயன்படுத்தி மாற்றத்தை செய்கிறது.
/// இது சிறப்பு பிழைகள் மற்றும் பொதுவானவற்றுக்கு இடையே தானியங்கி மாற்றத்தை வழங்குகிறது.
/// இதன் விளைவாக ஏற்பட்ட பிழை உடனடியாக திரும்பும்.
///
/// ஆரம்ப வருவாய் காரணமாக, X001 ஐ [`Result`] ஐ வழங்கும் செயல்பாடுகளில் மட்டுமே பயன்படுத்த முடியும்.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // விரைவாக திரும்பும் பிழைகளின் விருப்பமான முறை
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // விரைவாக திரும்பும் பிழைகளின் முந்தைய முறை
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // இது இதற்கு சமம்:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// வடிவமைக்கப்பட்ட தரவை ஒரு இடையகத்தில் எழுதுகிறது.
///
/// இந்த மேக்ரோ ஒரு 'writer', ஒரு வடிவமைப்பு சரம் மற்றும் வாதங்களின் பட்டியலை ஏற்றுக்கொள்கிறது.
/// குறிப்பிட்ட வடிவமைப்பு சரத்தின் படி வாதங்கள் வடிவமைக்கப்படும், இதன் விளைவாக எழுத்தாளருக்கு அனுப்பப்படும்.
/// எழுத்தாளர் ஒரு `write_fmt` முறையுடன் எந்த மதிப்பும் இருக்கலாம்;பொதுவாக இது [`fmt::Write`] அல்லது [`io::Write`] trait இன் செயல்பாட்டிலிருந்து வருகிறது.
/// `write_fmt` முறை திரும்பியதை மேக்ரோ வழங்குகிறது;பொதுவாக ஒரு [`fmt::Result`], அல்லது ஒரு [`io::Result`].
///
/// வடிவமைப்பு சரம் தொடரியல் பற்றிய கூடுதல் தகவலுக்கு [`std::fmt`] ஐப் பார்க்கவும்.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// ஒரு தொகுதி `std::fmt::Write` மற்றும் `std::io::Write` இரண்டையும் இறக்குமதி செய்யலாம் மற்றும் செயல்படுத்தும் பொருள்களில் `write!` ஐ அழைக்கலாம், ஏனெனில் பொருள்கள் பொதுவாக இரண்டையும் செயல்படுத்தாது.
///
/// இருப்பினும், தொகுதி traits தகுதிவாய்ந்தவற்றை இறக்குமதி செய்ய வேண்டும், எனவே அவற்றின் பெயர்கள் முரண்படாது:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ஐப் பயன்படுத்துகிறது
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ஐப் பயன்படுத்துகிறது
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: இந்த மேக்ரோவை `no_std` அமைப்புகளிலும் பயன்படுத்தலாம்.
/// ஒரு `no_std` அமைப்பில், கூறுகளின் செயல்பாட்டு விவரங்களுக்கு நீங்கள் பொறுப்பு.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// வடிவமைக்கப்பட்ட தரவை ஒரு பஃப்பரில் எழுதுங்கள், புதிய வரி சேர்க்கப்பட்டுள்ளது.
///
/// எல்லா தளங்களிலும், புதிய வரி LINE FEED எழுத்து (`\n`/`U+000A`) மட்டும் (கூடுதல் CARRIAGE RETURN (`\r`/`U+000D`) இல்லை.
///
/// மேலும் தகவலுக்கு, [`write!`] ஐப் பார்க்கவும்.வடிவமைப்பு சரம் தொடரியல் பற்றிய தகவலுக்கு, [`std::fmt`] ஐப் பார்க்கவும்.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// ஒரு தொகுதி `std::fmt::Write` மற்றும் `std::io::Write` இரண்டையும் இறக்குமதி செய்யலாம் மற்றும் செயல்படுத்தும் பொருள்களில் `write!` ஐ அழைக்கலாம், ஏனெனில் பொருள்கள் பொதுவாக இரண்டையும் செயல்படுத்தாது.
/// இருப்பினும், தொகுதி traits தகுதிவாய்ந்தவற்றை இறக்குமதி செய்ய வேண்டும், எனவே அவற்றின் பெயர்கள் முரண்படாது:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ஐப் பயன்படுத்துகிறது
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ஐப் பயன்படுத்துகிறது
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// அணுக முடியாத குறியீட்டைக் குறிக்கிறது.
///
/// சில குறியீடுகளை அணுக முடியாதது என்பதை தொகுப்பால் தீர்மானிக்க முடியாத எந்த நேரத்திலும் இது பயனுள்ளதாக இருக்கும்.உதாரணத்திற்கு:
///
/// * பாதுகாப்பு நிலைமைகளுடன் ஆயுதங்களை பொருத்துங்கள்.
/// * மாறும் முடிவுக்கு வரும் சுழல்கள்.
/// * மாறும் முடிவுக்கு வரும் ஈட்டரேட்டர்கள்.
///
/// குறியீட்டை அடையமுடியாது என்ற உறுதியானது தவறானது என நிரூபிக்கப்பட்டால், நிரல் உடனடியாக ஒரு [`panic!`] உடன் நிறுத்தப்படும்.
///
/// இந்த மேக்ரோவின் பாதுகாப்பற்ற எதிர்முனை [`unreachable_unchecked`] செயல்பாடு ஆகும், இது குறியீட்டை அடைந்தால் வரையறுக்கப்படாத நடத்தை ஏற்படுத்தும்.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// இது எப்போதும் [`panic!`] ஆக இருக்கும்.
///
/// # Examples
///
/// ஆயுதங்களை பொருத்து:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // கருத்து தெரிவித்தால் தொகுத்தல் பிழை
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 இன் ஏழ்மையான செயலாக்கங்களில் ஒன்று
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" இன் செய்தியைக் கண்டு பீதியடைவதன் மூலம் செயல்படுத்தப்படாத குறியீட்டைக் குறிக்கிறது.
///
/// இது உங்கள் குறியீட்டை தட்டச்சு செய்ய அனுமதிக்கிறது, நீங்கள் ஒரு trait ஐ முன்மாதிரி செய்கிறீர்களோ அல்லது செயல்படுத்துகிறீர்களோ அது பயனுள்ளதாக இருக்கும், அவை அனைத்தையும் பயன்படுத்த நீங்கள் திட்டமிடாத பல முறைகள் தேவைப்படுகின்றன.
///
/// `unimplemented!` மற்றும் [`todo!`] க்கு இடையிலான வேறுபாடு என்னவென்றால், `todo!` பின்னர் செயல்பாட்டை செயல்படுத்தும் நோக்கத்தை வெளிப்படுத்துகிறது மற்றும் செய்தி "not yet implemented" ஆகும், `unimplemented!` அத்தகைய கூற்றுக்கள் எதுவும் இல்லை.
/// இதன் செய்தி "not implemented".
/// சில ஐடிஇக்கள் `டோடோ! 'கள் குறிக்கும்.
///
/// # Panics
///
/// இது எப்போதும் [`panic!`] ஆக இருக்கும், ஏனெனில் `unimplemented!` என்பது ஒரு நிலையான, குறிப்பிட்ட செய்தியுடன் `panic!` க்கான சுருக்கெழுத்து மட்டுமே.
///
/// `panic!` ஐப் போலவே, இந்த மேக்ரோ தனிப்பயன் மதிப்புகளைக் காண்பிப்பதற்கான இரண்டாவது வடிவத்தைக் கொண்டுள்ளது.
///
/// # Examples
///
/// எங்களிடம் trait `Foo` உள்ளது என்று கூறுங்கள்:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// 'MyStruct' க்கு `Foo` ஐ செயல்படுத்த விரும்புகிறோம், ஆனால் சில காரணங்களால் இது `bar()` செயல்பாட்டை செயல்படுத்த மட்டுமே அர்த்தமுள்ளதாக இருக்கிறது.
/// `baz()` எங்கள் `Foo` ஐ செயல்படுத்துவதில் `qux()` இன்னும் வரையறுக்கப்பட வேண்டும், ஆனால் எங்கள் குறியீட்டை தொகுக்க அனுமதிக்க `unimplemented!` ஐ அவற்றின் வரையறைகளில் பயன்படுத்தலாம்.
///
/// செயல்படுத்தப்படாத முறைகள் எட்டப்பட்டால், எங்கள் நிரல் இயங்குவதை நிறுத்த விரும்புகிறோம்.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // இது `baz` ஒரு `MyStruct` க்கு எந்த அர்த்தமும் இல்லை, எனவே எங்களிடம் எந்த தர்க்கமும் இல்லை.
/////
///         // இது "thread 'main' panicked at 'not implemented'" ஐக் காண்பிக்கும்.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // எங்களிடம் சில தர்க்கங்கள் உள்ளன, செயல்படுத்தப்படாதவர்களுக்கு ஒரு செய்தியைச் சேர்க்கலாம்!எங்கள் புறக்கணிப்பைக் காண்பிக்க.
///         // இது காண்பிக்கப்படும்: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// முடிக்கப்படாத குறியீட்டைக் குறிக்கிறது.
///
/// நீங்கள் முன்மாதிரி மற்றும் உங்கள் குறியீடு தட்டச்சு சரிபார்ப்பைப் பார்க்க விரும்பினால் இது பயனுள்ளதாக இருக்கும்.
///
/// [`unimplemented!`] மற்றும் `todo!` க்கு இடையிலான வேறுபாடு என்னவென்றால், `todo!` பின்னர் செயல்பாட்டை செயல்படுத்தும் நோக்கத்தை வெளிப்படுத்துகிறது மற்றும் செய்தி "not yet implemented" ஆகும், `unimplemented!` அத்தகைய கூற்றுக்கள் எதுவும் இல்லை.
/// இதன் செய்தி "not implemented".
/// சில ஐடிஇக்கள் `டோடோ! 'கள் குறிக்கும்.
///
/// # Panics
///
/// இது எப்போதும் [`panic!`] ஆக இருக்கும்.
///
/// # Examples
///
/// சில முன்னேற்றக் குறியீட்டின் எடுத்துக்காட்டு இங்கே.எங்களிடம் trait `Foo` உள்ளது:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// எங்கள் வகைகளில் ஒன்றில் `Foo` ஐ செயல்படுத்த விரும்புகிறோம், ஆனால் முதலில் `bar()` இல் வேலை செய்ய விரும்புகிறோம்.எங்கள் குறியீடு தொகுக்க, நாம் `baz()` ஐ செயல்படுத்த வேண்டும், எனவே நாம் `todo!` ஐப் பயன்படுத்தலாம்:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // செயல்படுத்தல் இங்கே செல்கிறது
///     }
///
///     fn baz(&self) {
///         // இப்போது baz() ஐ செயல்படுத்துவது பற்றி கவலைப்பட வேண்டாம்
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // நாங்கள் baz() ஐ கூட பயன்படுத்தவில்லை, எனவே இது நல்லது.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// உள்ளமைக்கப்பட்ட மேக்ரோக்களின் வரையறைகள்.
///
/// மேக்ரோ பண்புகளை (ஸ்திரத்தன்மை, தெரிவுநிலை போன்றவை) இங்குள்ள மூலக் குறியீட்டிலிருந்து எடுக்கப்படுகின்றன, விரிவாக்க செயல்பாடுகளைத் தவிர்த்து மேக்ரோ உள்ளீடுகளை வெளியீடுகளாக மாற்றுகின்றன, அந்த செயல்பாடுகள் தொகுப்பால் வழங்கப்படுகின்றன.
///
///
pub(crate) mod builtin {

    /// சந்திக்கும் போது கொடுக்கப்பட்ட பிழை செய்தியுடன் தொகுப்பு தோல்வியடையும்.
    ///
    /// தவறான நிலைமைகளுக்கு சிறந்த பிழை செய்திகளை வழங்க crate ஒரு நிபந்தனை தொகுப்பு மூலோபாயத்தைப் பயன்படுத்தும் போது இந்த மேக்ரோ பயன்படுத்தப்பட வேண்டும்.
    ///
    /// இது [`panic!`] இன் கம்பைலர்-நிலை வடிவம், ஆனால் *இயக்க நேரத்தில்* என்பதை விட * தொகுப்பின் போது பிழையை வெளியிடுகிறது.
    ///
    /// # Examples
    ///
    /// அத்தகைய இரண்டு எடுத்துக்காட்டுகள் மேக்ரோக்கள் மற்றும் எக்ஸ் 100 எக்ஸ் சூழல்கள்.
    ///
    /// ஒரு மேக்ரோ தவறான மதிப்புகளை அனுப்பினால் சிறந்த கம்பைலர் பிழையை வெளியிடுங்கள்.
    /// இறுதி branch இல்லாமல், கம்பைலர் இன்னும் ஒரு பிழையை வெளியிடும், ஆனால் பிழையின் செய்தி இரண்டு செல்லுபடியாகும் மதிப்புகளைக் குறிப்பிடாது.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// பல அம்சங்களில் ஒன்று கிடைக்கவில்லை என்றால் கம்பைலர் பிழையை வெளியிடுங்கள்.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// பிற சரம் வடிவமைக்கும் மேக்ரோக்களுக்கான அளவுருக்களை உருவாக்குகிறது.
    ///
    /// கடந்து வந்த ஒவ்வொரு கூடுதல் வாதத்திற்கும் `{}` அடங்கிய ஒரு வடிவமைப்பு சரம் எடுத்துக்கொள்வதன் மூலம் இந்த மேக்ரோ செயல்படுகிறது.
    /// `format_args!` வெளியீட்டை ஒரு சரமாக விளக்க முடியும் என்பதை உறுதிப்படுத்த கூடுதல் அளவுருக்களைத் தயாரிக்கிறது மற்றும் வாதங்களை ஒற்றை வகையாக நியமனம் செய்கிறது.
    /// [`Display`] trait ஐ செயல்படுத்தும் எந்த மதிப்பும் `format_args!` க்கு அனுப்பப்படலாம், அதேபோல் எந்த [`Debug`] செயல்படுத்தலும் வடிவமைப்பு சரத்திற்குள் `{:?}` க்கு அனுப்பப்படலாம்.
    ///
    ///
    /// இந்த மேக்ரோ வகை [`fmt::Arguments`] இன் மதிப்பை உருவாக்குகிறது.பயனுள்ள திசைதிருப்பலைச் செய்வதற்கு இந்த மதிப்பை [`std::fmt`] க்குள் உள்ள மேக்ரோக்களுக்கு அனுப்பலாம்.
    /// மற்ற அனைத்து வடிவமைப்பு மேக்ரோக்களும் ([`வடிவம்!`], [`write!`], [`println!`], போன்றவை) இதன் மூலம் அருகாமையில் உள்ளன.
    /// `format_args!`, அதன் பெறப்பட்ட மேக்ரோக்களைப் போலன்றி, குவியல் ஒதுக்கீட்டைத் தவிர்க்கிறது.
    ///
    /// `format_args!` `Debug` மற்றும் `Display` சூழல்களில் தரும் [`fmt::Arguments`] மதிப்பை கீழே காணலாம்.
    /// எடுத்துக்காட்டு `Debug` மற்றும் `Display` வடிவமைப்பை ஒரே விஷயமாகக் காட்டுகிறது: `format_args!` இல் உள்ள இடைக்கணிப்பு வடிவமைப்பு சரம்.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// மேலும் தகவலுக்கு, [`std::fmt`] இல் உள்ள ஆவணங்களைப் பார்க்கவும்.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` ஐப் போன்றது, ஆனால் இறுதியில் ஒரு புதிய வரியைச் சேர்க்கிறது.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// தொகுக்கும் நேரத்தில் சூழல் மாறியை ஆய்வு செய்கிறது.
    ///
    /// இந்த மேக்ரோ தொகுக்கப்பட்ட நேரத்தில் பெயரிடப்பட்ட சூழல் மாறியின் மதிப்புக்கு விரிவடையும், இது `&'static str` வகை வெளிப்பாட்டைக் கொடுக்கும்.
    ///
    ///
    /// சூழல் மாறி வரையறுக்கப்படவில்லை என்றால், ஒரு தொகுப்பு பிழை உமிழப்படும்.
    /// தொகுத்தல் பிழையை வெளியிடாமல், அதற்கு பதிலாக [`option_env!`] மேக்ரோவைப் பயன்படுத்தவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// இரண்டாவது அளவுருவாக ஒரு சரத்தை அனுப்புவதன் மூலம் பிழை செய்தியை நீங்கள் தனிப்பயனாக்கலாம்:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// `documentation` சூழல் மாறி வரையறுக்கப்படவில்லை என்றால், நீங்கள் பின்வரும் பிழையைப் பெறுவீர்கள்:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// தொகுக்கும் நேரத்தில் சூழல் மாறியை விருப்பமாக ஆய்வு செய்கிறது.
    ///
    /// தொகுக்கப்பட்ட நேரத்தில் பெயரிடப்பட்ட சூழல் மாறி இருந்தால், இது `Option<&'static str>` வகை வெளிப்பாடாக விரிவடையும், அதன் மதிப்பு சுற்றுச்சூழல் மாறியின் மதிப்பின் `Some` ஆகும்.
    /// சூழல் மாறி இல்லை என்றால், இது `None` க்கு விரிவடையும்.
    /// இந்த வகை பற்றிய கூடுதல் தகவலுக்கு [`Option<T>`][Option] ஐப் பார்க்கவும்.
    ///
    /// சுற்றுச்சூழல் மாறி இருக்கிறதா இல்லையா என்பதைப் பொருட்படுத்தாமல் இந்த மேக்ரோவைப் பயன்படுத்தும் போது ஒரு தொகுக்கும் நேர பிழை ஒருபோதும் வெளியேற்றப்படாது.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// அடையாளங்காட்டிகளை ஒரு அடையாளங்காட்டியாக இணைக்கிறது.
    ///
    /// இந்த மேக்ரோ எந்தவொரு கமாவால் பிரிக்கப்பட்ட அடையாளங்காட்டிகளையும் எடுத்து, அனைத்தையும் ஒன்றிணைக்கிறது, இது ஒரு புதிய அடையாளங்காட்டியாக இருக்கும் ஒரு வெளிப்பாட்டைக் கொடுக்கும்.
    /// இந்த மேக்ரோ உள்ளூர் மாறிகளைப் பிடிக்க முடியாத வகையில் சுகாதாரம் அதை உருவாக்குகிறது என்பதை நினைவில் கொள்க.
    /// மேலும், ஒரு பொது விதியாக, உருப்படி, அறிக்கை அல்லது வெளிப்பாடு நிலையில் மட்டுமே மேக்ரோக்கள் அனுமதிக்கப்படுகின்றன.
    /// அதாவது, இருக்கும் மாறிகள், செயல்பாடுகள் அல்லது தொகுதிகள் போன்றவற்றைக் குறிக்க இந்த மேக்ரோவைப் பயன்படுத்தும்போது, அதனுடன் புதிய ஒன்றை நீங்கள் வரையறுக்க முடியாது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (புதிய, வேடிக்கை, பெயர்) { }//இந்த வழியில் பயன்படுத்த முடியாது!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// எழுத்தாளர்களை ஒரு நிலையான சரம் துண்டுகளாக இணைக்கிறது.
    ///
    /// இந்த மேக்ரோ காற்புள்ளியால் பிரிக்கப்பட்ட எத்தனை எழுத்தாளர்களை எடுத்துக்கொள்கிறது, இது `&'static str` வகை வெளிப்பாட்டை அளிக்கிறது, இது இடமிருந்து வலமாக ஒன்றிணைந்த அனைத்து எழுத்தாளர்களையும் குறிக்கிறது.
    ///
    ///
    /// ஒருங்கிணைந்த மற்றும் மிதக்கும் புள்ளி எழுத்தர்கள் ஒன்றிணைக்கப்படுவதற்கு சரம் கட்டப்பட்டுள்ளன.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// அது செயல்படுத்தப்பட்ட வரி எண்ணுக்கு விரிவடைகிறது.
    ///
    /// [`column!`] மற்றும் [`file!`] உடன், இந்த மேக்ரோக்கள் டெவலப்பர்களுக்கு மூலத்தில் உள்ள இருப்பிடம் குறித்த பிழைத்திருத்த தகவல்களை வழங்குகின்றன.
    ///
    /// விரிவாக்கப்பட்ட வெளிப்பாடு `u32` வகை மற்றும் 1 அடிப்படையிலானது, எனவே ஒவ்வொரு கோப்பிலும் முதல் வரி 1 ஆகவும், இரண்டாவது 2 முதல் 2 ஆகவும் மதிப்பிடுகிறது.
    /// இது பொதுவான தொகுப்பாளர்கள் அல்லது பிரபலமான எடிட்டர்களின் பிழை செய்திகளுடன் ஒத்துப்போகிறது.
    /// திரும்பிய வரி `line!` அழைப்பின் வரி *அவசியமில்லை*, மாறாக `line!` மேக்ரோவின் அழைப்பிற்கு வழிவகுக்கும் முதல் மேக்ரோ அழைப்பு.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// அது பயன்படுத்தப்பட்ட நெடுவரிசை எண்ணுக்கு விரிவடைகிறது.
    ///
    /// [`line!`] மற்றும் [`file!`] உடன், இந்த மேக்ரோக்கள் டெவலப்பர்களுக்கு மூலத்தில் உள்ள இருப்பிடம் குறித்த பிழைத்திருத்த தகவல்களை வழங்குகின்றன.
    ///
    /// விரிவாக்கப்பட்ட வெளிப்பாடு `u32` வகை மற்றும் 1 அடிப்படையிலானது, எனவே ஒவ்வொரு வரியிலும் முதல் நெடுவரிசை 1 ஆகவும், இரண்டாவது 2 முதல் 2 ஆகவும் மதிப்பிடுகிறது.
    /// இது பொதுவான தொகுப்பாளர்கள் அல்லது பிரபலமான எடிட்டர்களின் பிழை செய்திகளுடன் ஒத்துப்போகிறது.
    /// திரும்பிய நெடுவரிசை `column!` அழைப்பின் வரி *அவசியமில்லை*, மாறாக `column!` மேக்ரோவின் அழைப்பிற்கு வழிவகுக்கும் முதல் மேக்ரோ அழைப்பிதழ்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// அது பயன்படுத்தப்பட்ட கோப்பு பெயருக்கு விரிவடைகிறது.
    ///
    /// [`line!`] மற்றும் [`column!`] உடன், இந்த மேக்ரோக்கள் டெவலப்பர்களுக்கு மூலத்தில் உள்ள இருப்பிடம் குறித்த பிழைத்திருத்த தகவல்களை வழங்குகின்றன.
    ///
    /// விரிவாக்கப்பட்ட வெளிப்பாடு வகை `&'static str` ஐக் கொண்டுள்ளது, மேலும் திரும்பிய கோப்பு `file!` மேக்ரோவின் அழைப்பல்ல, மாறாக `file!` மேக்ரோவின் அழைப்பிற்கு வழிவகுக்கும் முதல் மேக்ரோ அழைப்பாகும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// அதன் வாதங்களை உறுதிப்படுத்துகிறது.
    ///
    /// இந்த மேக்ரோ வகை `&'static str` இன் வெளிப்பாட்டைக் கொடுக்கும், இது மேக்ரோவுக்கு அனுப்பப்பட்ட அனைத்து tokens இன் சரம் ஆகும்.
    /// மேக்ரோ அழைப்பின் தொடரியல் மீது எந்த கட்டுப்பாடுகளும் வைக்கப்படவில்லை.
    ///
    /// tokens உள்ளீட்டின் விரிவாக்கப்பட்ட முடிவுகள் future இல் மாறக்கூடும் என்பதை நினைவில் கொள்க.நீங்கள் வெளியீட்டை நம்பினால் கவனமாக இருக்க வேண்டும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ஒரு சரமாக UTF-8 குறியிடப்பட்ட கோப்பு அடங்கும்.
    ///
    /// கோப்பு தற்போதைய கோப்போடு தொடர்புடையது (தொகுதிகள் எவ்வாறு காணப்படுகின்றன என்பது போலவே).
    /// வழங்கப்பட்ட பாதை தொகுக்கும் நேரத்தில் ஒரு தளம் சார்ந்த வழியில் விளக்கப்படுகிறது.
    /// எனவே, உதாரணமாக, `\` பேக்ஸ்லேஷ்கள் கொண்ட Windows பாதையுடன் கூடிய ஒரு அழைப்பு Unix இல் சரியாக தொகுக்கப்படாது.
    ///
    ///
    /// இந்த மேக்ரோ கோப்பின் உள்ளடக்கங்களான `&'static str` வகை வெளிப்பாட்டைக் கொடுக்கும்.
    ///
    /// # Examples
    ///
    /// பின்வரும் கோப்பகங்களுடன் ஒரே கோப்பகத்தில் இரண்டு கோப்புகள் உள்ளன என்று வைத்துக் கொள்ளுங்கள்:
    ///
    /// கோப்பு 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// கோப்பு 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' ஐ தொகுத்து, அதன் விளைவாக வரும் பைனரியை இயக்குவது "adiós" ஐ அச்சிடும்.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// பைட் வரிசைக்கான குறிப்பாக ஒரு கோப்பை உள்ளடக்கியது.
    ///
    /// கோப்பு தற்போதைய கோப்போடு தொடர்புடையது (தொகுதிகள் எவ்வாறு காணப்படுகின்றன என்பது போலவே).
    /// வழங்கப்பட்ட பாதை தொகுக்கும் நேரத்தில் ஒரு தளம் சார்ந்த வழியில் விளக்கப்படுகிறது.
    /// எனவே, உதாரணமாக, `\` பேக்ஸ்லேஷ்கள் கொண்ட Windows பாதையுடன் கூடிய ஒரு அழைப்பு Unix இல் சரியாக தொகுக்கப்படாது.
    ///
    ///
    /// இந்த மேக்ரோ கோப்பின் உள்ளடக்கங்களான `&'static [u8; N]` வகை வெளிப்பாட்டைக் கொடுக்கும்.
    ///
    /// # Examples
    ///
    /// பின்வரும் கோப்பகங்களுடன் ஒரே கோப்பகத்தில் இரண்டு கோப்புகள் உள்ளன என்று வைத்துக் கொள்ளுங்கள்:
    ///
    /// கோப்பு 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// கோப்பு 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' ஐ தொகுத்து, அதன் விளைவாக வரும் பைனரியை இயக்குவது "adiós" ஐ அச்சிடும்.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// தற்போதைய தொகுதி பாதையை குறிக்கும் ஒரு சரத்திற்கு விரிவடைகிறது.
    ///
    /// தற்போதைய தொகுதி பாதை crate root வரை செல்லும் தொகுதிகளின் வரிசைமுறை என்று கருதலாம்.
    /// திரும்பிய பாதையின் முதல் கூறு தற்போது தொகுக்கப்பட்டுள்ள crate இன் பெயர்.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// தொகுக்கும் நேரத்தில் உள்ளமைவு கொடிகளின் பூலியன் சேர்க்கைகளை மதிப்பீடு செய்கிறது.
    ///
    /// `#[cfg]` பண்புக்கூறுக்கு கூடுதலாக, உள்ளமைவு கொடிகளின் பூலியன் வெளிப்பாடு மதிப்பீட்டை அனுமதிக்க இந்த மேக்ரோ வழங்கப்படுகிறது.
    /// இது அடிக்கடி குறைவான நகல் குறியீட்டிற்கு வழிவகுக்கிறது.
    ///
    /// இந்த மேக்ரோவுக்கு வழங்கப்பட்ட தொடரியல் [`cfg`] பண்புக்கூறு போலவே உள்ளது.
    ///
    /// `cfg!`, `#[cfg]` போலல்லாமல், எந்த குறியீட்டையும் அகற்றாது, உண்மை அல்லது பொய் என்று மட்டுமே மதிப்பிடுகிறது.
    /// எடுத்துக்காட்டாக, `cfg!` எதை மதிப்பிடுகிறது என்பதைப் பொருட்படுத்தாமல், X001 வெளிப்பாட்டின் அனைத்து தொகுதிகளும் `cfg!` நிபந்தனைக்கு பயன்படுத்தப்படும்போது செல்லுபடியாகும்.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ஒரு கோப்பை ஒரு வெளிப்பாடாக அல்லது சூழலுக்கு ஏற்ப ஒரு பொருளாக பாகுபடுத்துகிறது.
    ///
    /// கோப்பு தற்போதைய கோப்போடு தொடர்புடையது (தொகுதிகள் எவ்வாறு காணப்படுகின்றன என்பது போலவே).வழங்கப்பட்ட பாதை தொகுக்கும் நேரத்தில் ஒரு தளம் சார்ந்த வழியில் விளக்கப்படுகிறது.
    /// எனவே, உதாரணமாக, `\` பேக்ஸ்லேஷ்கள் கொண்ட Windows பாதையுடன் கூடிய ஒரு அழைப்பு Unix இல் சரியாக தொகுக்கப்படாது.
    ///
    /// இந்த மேக்ரோவைப் பயன்படுத்துவது பெரும்பாலும் ஒரு மோசமான யோசனையாகும், ஏனென்றால் கோப்பு ஒரு வெளிப்பாடாக பாகுபடுத்தப்பட்டால், அது சுற்றியுள்ள குறியீட்டில் சுகாதாரமற்ற முறையில் வைக்கப்படும்.
    /// தற்போதைய கோப்பில் ஒரே பெயரைக் கொண்ட மாறிகள் அல்லது செயல்பாடுகள் இருந்தால் கோப்பு எதிர்பார்த்ததைவிட மாறிகள் அல்லது செயல்பாடுகள் மாறுபடும்.
    ///
    ///
    /// # Examples
    ///
    /// பின்வரும் கோப்பகங்களுடன் ஒரே கோப்பகத்தில் இரண்டு கோப்புகள் உள்ளன என்று வைத்துக் கொள்ளுங்கள்:
    ///
    /// கோப்பு 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// கோப்பு 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' ஐ தொகுத்து, அதன் விளைவாக வரும் பைனரியை இயக்குவது "🙈🙊🙉🙈🙊🙉" ஐ அச்சிடும்.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// இயக்க நேரத்தில் ஒரு பூலியன் வெளிப்பாடு `true` என்று கூறுகிறது.
    ///
    /// வழங்கப்பட்ட வெளிப்பாட்டை இயக்க நேரத்தில் `true` க்கு மதிப்பீடு செய்ய முடியாவிட்டால் இது [`panic!`] மேக்ரோவை செயல்படுத்தும்.
    ///
    /// # Uses
    ///
    /// பிழைத்திருத்தம் மற்றும் வெளியீட்டு கட்டமைப்புகள் இரண்டிலும் கூற்றுக்கள் எப்போதும் சரிபார்க்கப்படுகின்றன, அவற்றை முடக்க முடியாது.
    /// இயல்புநிலையாக வெளியீட்டு கட்டமைப்பில் செயல்படுத்தப்படாத கூற்றுகளுக்கு [`debug_assert!`] ஐப் பார்க்கவும்.
    ///
    /// பாதுகாப்பற்ற குறியீடு `assert!` ஐ இயக்க நேர மாற்றங்களை செயல்படுத்த நம்பலாம், அவை மீறப்பட்டால் பாதுகாப்பற்ற தன்மைக்கு வழிவகுக்கும்.
    ///
    /// `assert!` இன் பிற பயன்பாட்டு நிகழ்வுகளில் பாதுகாப்பான குறியீட்டில் ரன்-டைம் மாற்றங்களை சோதித்தல் மற்றும் செயல்படுத்துதல் ஆகியவை அடங்கும் (அவற்றின் மீறல் பாதுகாப்பற்ற தன்மையை ஏற்படுத்தாது).
    ///
    ///
    /// # தனிப்பயன் செய்திகள்
    ///
    /// இந்த மேக்ரோ இரண்டாவது வடிவத்தைக் கொண்டுள்ளது, அங்கு தனிப்பயன் panic செய்தியை வடிவமைப்பதற்கான வாதங்களுடன் அல்லது இல்லாமல் வழங்க முடியும்.
    /// இந்த படிவத்திற்கான தொடரியல் [`std::fmt`] ஐப் பார்க்கவும்.
    /// வலியுறுத்தல் தோல்வியுற்றால் மட்டுமே வடிவமைப்பு வாதங்களாகப் பயன்படுத்தப்படும் வெளிப்பாடுகள் மதிப்பீடு செய்யப்படும்.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // இந்த கூற்றுக்களுக்கான panic செய்தி கொடுக்கப்பட்ட வெளிப்பாட்டின் கடுமையான மதிப்பு.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // மிகவும் எளிமையான செயல்பாடு
    ///
    /// assert!(some_computation());
    ///
    /// // தனிப்பயன் செய்தியுடன் வலியுறுத்தவும்
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// இன்லைன் சட்டசபை.
    ///
    /// பயன்பாட்டிற்கு [unstable book] ஐப் படிக்கவும்.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// எல்.எல்.வி.எம்-பாணி இன்லைன் சட்டசபை.
    ///
    /// பயன்பாட்டிற்கு [unstable book] ஐப் படிக்கவும்.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// தொகுதி-நிலை இன்லைன் சட்டசபை.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// அச்சிட்டுகள் நிலையான வெளியீட்டில் tokens ஐ அனுப்பின.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// பிற மேக்ரோக்களை பிழைதிருத்தம் செய்வதற்குப் பயன்படுத்தப்படும் தடமறிதல் செயல்பாட்டை இயக்குகிறது அல்லது முடக்குகிறது.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// மேக்ரோக்களைப் பயன்படுத்துவதற்குப் பயன்படுத்தப்படும் பண்புக்கூறு மேக்ரோ.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ஒரு செயல்பாட்டை அலகு சோதனையாக மாற்ற பண்புக்கூறு மேக்ரோ பயன்படுத்தப்பட்டது.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// ஒரு செயல்பாட்டை ஒரு பெஞ்ச்மார்க் சோதனையாக மாற்ற பண்புக்கூறு மேக்ரோ பயன்படுத்தப்பட்டது.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` மற்றும் `#[bench]` மேக்ரோக்களின் செயல்படுத்தல் விவரம்.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// உலகளாவிய ஒதுக்கீட்டாளராக பதிவுசெய்ய ஒரு நிலையான பண்புக்கூறு மேக்ரோ பயன்படுத்தப்பட்டது.
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) ஐயும் காண்க.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// கடந்து வந்த பாதையை அணுக முடிந்தால் அது பயன்படுத்தப்படும் உருப்படியை வைத்திருக்கிறது, இல்லையெனில் அதை நீக்குகிறது.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// இது பயன்படுத்தப்படும் குறியீடு துண்டில் உள்ள அனைத்து `#[cfg]` மற்றும் `#[cfg_attr]` பண்புகளையும் விரிவுபடுத்துகிறது.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` தொகுப்பியின் நிலையற்ற செயல்படுத்தல் விவரம், பயன்படுத்த வேண்டாம்.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` தொகுப்பியின் நிலையற்ற செயல்படுத்தல் விவரம், பயன்படுத்த வேண்டாம்.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}