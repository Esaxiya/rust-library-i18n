#![stable(feature = "futures_api", since = "1.36.0")]

//! ஒத்திசைவற்ற பணிகளுடன் பணியாற்றுவதற்கான வகைகள் மற்றும் Traits.

mod poll;
#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::poll::Poll;

mod wake;
#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::wake::{Context, RawWaker, RawWakerVTable, Waker};

mod ready;
#[unstable(feature = "ready_macro", issue = "70922")]
pub use ready::ready;