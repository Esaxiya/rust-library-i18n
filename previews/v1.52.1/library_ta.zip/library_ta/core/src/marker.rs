//! பழமையான traits மற்றும் வகைகளின் அடிப்படை பண்புகளைக் குறிக்கும் வகைகள்.
//!
//! Rust வகைகளை அவற்றின் உள்ளார்ந்த பண்புகளுக்கு ஏற்ப பல்வேறு பயனுள்ள வழிகளில் வகைப்படுத்தலாம்.
//! இந்த வகைப்பாடுகள் traits என குறிப்பிடப்படுகின்றன.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// நூல் எல்லைகளில் மாற்றக்கூடிய வகைகள்.
///
/// இந்த trait தானாகவே கம்பைலர் பொருத்தமானது என்று தீர்மானிக்கும்போது செயல்படுத்தப்படும்.
///
/// `அனுப்பாத` வகையின் எடுத்துக்காட்டு குறிப்பு-எண்ணும் சுட்டிக்காட்டி [`rc::Rc`][`Rc`] ஆகும்.
/// இரண்டு குறிப்புக்கள் ஒரே குறிப்பு-எண்ணப்பட்ட மதிப்பைக் குறிக்கும் [`Rc`] களை குளோன் செய்ய முயற்சித்தால், அவை ஒரே நேரத்தில் குறிப்பு எண்ணிக்கையை புதுப்பிக்க முயற்சி செய்யலாம், இது [undefined behavior][ub] ஆகும், ஏனெனில் [`Rc`] அணு செயல்பாடுகளைப் பயன்படுத்தாது.
///
/// அதன் உறவினர் [`sync::Arc`][arc] அணு செயல்பாடுகளைப் பயன்படுத்துகிறது (சில மேல்நிலைகளுக்கு உட்பட்டது) இதனால் `Send` ஆகும்.
///
/// மேலும் விவரங்களுக்கு [the Nomicon](../../nomicon/send-and-sync.html) ஐப் பார்க்கவும்.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// தொகுக்கும் நேரத்தில் அறியப்பட்ட நிலையான அளவு கொண்ட வகைகள்.
///
/// எல்லா வகை அளவுருக்களும் `Sized` இன் மறைமுகமான பிணைப்பைக் கொண்டுள்ளன.இது பொருத்தமற்றது எனில், இந்த வரம்பை அகற்ற சிறப்பு தொடரியல் `?Sized` ஐப் பயன்படுத்தலாம்.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//பிழை: [i32] க்கு அளவு செயல்படுத்தப்படவில்லை
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// ஒரு விதிவிலக்கு ஒரு trait இன் மறைமுகமான `Self` வகை.
/// [trait பொருள்] உடன் பொருந்தாததால், trait க்கு ஒரு மறைமுகமான `Sized` இல்லை, வரையறையின்படி, trait சாத்தியமான அனைத்து செயல்படுத்துபவர்களுடனும் வேலை செய்ய வேண்டும், இதனால் எந்த அளவும் இருக்கலாம்.
///
///
/// Rust உங்களை `Sized` ஐ trait உடன் பிணைக்க அனுமதிக்கும் என்றாலும், பின்னர் நீங்கள் அதை trait பொருளை உருவாக்க பயன்படுத்த முடியாது:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y: &dyn Bar= &Impl;//பிழை: trait `Bar` ஐ ஒரு பொருளாக மாற்ற முடியாது
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // இயல்புநிலைக்கு, எடுத்துக்காட்டாக, `[T]: !Default` மதிப்பீடு செய்யப்பட வேண்டும்
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// மாறும் அளவிலான வகைக்கு "unsized" ஆக இருக்கும் வகைகள்.
///
/// எடுத்துக்காட்டாக, அளவிலான வரிசை வகை `[i8; 2]` `Unsize<[i8]>` மற்றும் `Unsize<dyn fmt::Debug>` ஐ செயல்படுத்துகிறது.
///
/// `Unsize` இன் அனைத்து செயலாக்கங்களும் தொகுப்பால் தானாக வழங்கப்படுகின்றன.
///
/// `Unsize` இதற்காக செயல்படுத்தப்படுகிறது:
///
/// - `[T; N]` `Unsize<[T]>` ஆகும்
/// - `T` `T: Trait` போது `Unsize<dyn Trait>` ஆகும்
/// - `Foo<..., T, ...>` என்றால் `Unsize<Foo<..., U, ...>>`:
///   - `T: Unsize<U>`
///   - Foo ஒரு struct
///   - `Foo` இன் கடைசி புலத்தில் மட்டுமே `T` சம்பந்தப்பட்ட வகை உள்ளது
///   - `T` வேறு எந்த துறைகளின் வகையின் பகுதியாக இல்லை
///   - `Bar<T>: Unsize<Bar<U>>`, `Foo` இன் கடைசி புலத்தில் `Bar<T>` வகை இருந்தால்
///
/// `Unsize` [`Rc`] போன்ற "user-defined" கொள்கலன்களை மாறும் அளவிலான வகைகளைக் கொண்டிருக்க அனுமதிக்க [`ops::CoerceUnsized`] உடன் பயன்படுத்தப்படுகிறது.
/// மேலும் விவரங்களுக்கு [DST coercion RFC][RFC982] மற்றும் [the nomicon entry on coercion][nomicon-coerce] ஐப் பார்க்கவும்.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// மாதிரி போட்டிகளில் பயன்படுத்தப்படும் மாறிலிகளுக்கு trait தேவை.
///
/// `PartialEq` ஐப் பெறும் எந்த வகையும் இந்த trait ஐ தானாகவே செயல்படுத்துகிறது, அதன் வகை-அளவுருக்கள் `Eq` ஐ செயல்படுத்துகிறதா என்பதைப் பொருட்படுத்தாமல் *.
///
/// ஒரு `const` உருப்படி இந்த trait ஐ செயல்படுத்தாத சில வகைகளைக் கொண்டிருந்தால், அந்த வகை (1.) `PartialEq` ஐ செயல்படுத்தாது (அதாவது நிலையானது அந்த ஒப்பீட்டு முறையை வழங்காது, எந்த குறியீடு உருவாக்கம் கிடைக்கிறது என்று கருதுகிறது), அல்லது (2.) அது செயல்படுத்துகிறது * அதன் சொந்த `PartialEq` இன் பதிப்பு (இது ஒரு கட்டமைப்பு-சமத்துவ ஒப்பீட்டுடன் ஒத்துப்போகவில்லை என்று நாங்கள் கருதுகிறோம்).
///
///
/// மேலே உள்ள இரண்டு காட்சிகளில், ஒரு மாதிரி பொருத்தத்தில் அத்தகைய மாறிலியின் பயன்பாட்டை நாங்கள் நிராகரிக்கிறோம்.
///
/// [structural match RFC][RFC1445] மற்றும் [issue 63438] ஐயும் காண்க, இது பண்பு அடிப்படையிலான வடிவமைப்பிலிருந்து இந்த trait க்கு இடம்பெயர ஊக்கமளித்தது.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// மாதிரி போட்டிகளில் பயன்படுத்தப்படும் மாறிலிகளுக்கு trait தேவை.
///
/// `Eq` ஐப் பெறும் எந்த வகையும் இந்த trait ஐ தானாகவே செயல்படுத்துகிறது, அதன் வகை அளவுருக்கள் `Eq` ஐ செயல்படுத்துகிறதா என்பதைப் பொருட்படுத்தாமல் *.
///
/// எங்கள் வகை அமைப்பில் ஒரு வரம்பைச் சுற்றி வேலை செய்வதற்கான ஹேக் இது.
///
/// # Background
///
/// மாதிரி போட்டிகளில் பயன்படுத்தப்படும் வகையான கான்ஸ்ட்கள் `#[derive(PartialEq, Eq)]` பண்புக்கூறுகளைக் கொண்டிருக்க வேண்டும் என்று நாங்கள் விரும்புகிறோம்.
///
/// மிகவும் சிறந்த உலகில், கொடுக்கப்பட்ட வகை `StructuralPartialEq` trait *மற்றும்*`Eq` trait இரண்டையும் செயல்படுத்துகிறதா என்பதைச் சரிபார்த்து அந்தத் தேவையை நாம் சரிபார்க்க முடியும்.
/// இருப்பினும், * `derive(PartialEq, Eq)` ஐச் செய்யும் ADT களை நீங்கள் வைத்திருக்கலாம், மேலும் கம்பைலர் ஏற்றுக்கொள்ள வேண்டும் என்று நாங்கள் விரும்புகிறோம், ஆனால் நிலையான வகை `Eq` ஐ செயல்படுத்தத் தவறிவிட்டது.
///
/// அதாவது, இது போன்ற ஒரு வழக்கு:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (மேலே உள்ள குறியீட்டில் உள்ள சிக்கல் என்னவென்றால், `Wrap<fn(&())>` `PartialEq` அல்லது `Eq` ஐ செயல்படுத்தாது, ஏனெனில் `க்கு <'a> fn(&'a _)` does not implement those traits.)
///
/// எனவே, `StructuralPartialEq` மற்றும் வெறும் `Eq` க்கான அப்பாவி காசோலையை நாம் நம்ப முடியாது.
///
/// இதைச் செய்வதற்கு ஒரு ஹேக் என, ஒவ்வொன்றும் (`#[derive(PartialEq)]` மற்றும் `#[derive(Eq)]`) ஆகியவற்றிலிருந்து பெறப்பட்ட இரண்டு தனித்தனி traits ஐப் பயன்படுத்துகிறோம், மேலும் அவை இரண்டும் கட்டமைப்பு-போட்டி சரிபார்ப்பின் ஒரு பகுதியாக இருக்கிறதா என்று சரிபார்க்கிறோம்.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// பிட்களை நகலெடுப்பதன் மூலம் அதன் மதிப்புகளை நகலெடுக்கக்கூடிய வகைகள்.
///
/// இயல்பாக, மாறி பிணைப்புகள் 'நகரும் சொற்பொருளைக் கொண்டுள்ளன.'வேறு வார்த்தைகளில் கூறுவதானால்:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` க்கு நகர்த்தப்பட்டது, எனவே பயன்படுத்த முடியாது
///
/// // println! ("{: ?}", x);//பிழை: நகர்த்தப்பட்ட மதிப்பின் பயன்பாடு
/// ```
///
/// இருப்பினும், ஒரு வகை `Copy` ஐ செயல்படுத்தினால், அதற்கு பதிலாக 'நகல் சொற்பொருள்' உள்ளது:
///
/// ```
/// // நாம் ஒரு `Copy` செயல்படுத்தலைப் பெறலாம்.
/// // `Clone` இது `Copy` இன் சூப்பர் ட்ரெய்ட் என்பதால் இது தேவைப்படுகிறது.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` இன் நகல்
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// இந்த இரண்டு எடுத்துக்காட்டுகளில், ஒரே ஒரு வித்தியாசம் என்னவென்றால், ஒதுக்கீட்டிற்குப் பிறகு நீங்கள் `x` ஐ அணுக அனுமதிக்கப்படுகிறீர்களா என்பதுதான்.
/// பேட்டை கீழ், ஒரு நகல் மற்றும் ஒரு நகர்வு இரண்டும் பிட்களில் நினைவகத்தில் நகலெடுக்கப்படலாம், இருப்பினும் இது சில நேரங்களில் உகந்ததாக இருக்கும்.
///
/// ## `Copy` ஐ எவ்வாறு செயல்படுத்தலாம்?
///
/// உங்கள் வகையில் `Copy` ஐ செயல்படுத்த இரண்டு வழிகள் உள்ளன.`derive` ஐப் பயன்படுத்துவது எளிது:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// நீங்கள் `Copy` மற்றும் `Clone` ஐ கைமுறையாக செயல்படுத்தலாம்:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// இரண்டிற்கும் இடையே ஒரு சிறிய வித்தியாசம் உள்ளது: `derive` மூலோபாயம் ஒரு `Copy` வகை அளவுருக்களில் பிணைக்கப்படும், இது எப்போதும் விரும்பாது.
///
/// ## `Copy` க்கும் `Clone` க்கும் என்ன வித்தியாசம்?
///
/// பிரதிகள் மறைமுகமாக நிகழ்கின்றன, எடுத்துக்காட்டாக ஒரு வேலையின் `y = x` இன் ஒரு பகுதியாக.`Copy` இன் நடத்தை அதிக சுமை அல்ல;இது எப்போதும் ஒரு எளிய பிட் வாரியான நகலாகும்.
///
/// குளோனிங் என்பது ஒரு வெளிப்படையான செயல், `x.clone()`.[`Clone`] இன் செயலாக்கம் மதிப்புகளை பாதுகாப்பாக நகலெடுக்க தேவையான எந்த வகை-குறிப்பிட்ட நடத்தையையும் வழங்க முடியும்.
/// எடுத்துக்காட்டாக, [`String`] க்கான [`Clone`] ஐ செயல்படுத்துவதற்கு குவியலில் சுட்டிக்காட்டப்பட்ட-சரம் இடையகத்தை நகலெடுக்க வேண்டும்.
/// [`String`] மதிப்புகளின் எளிமையான பிட்வைஸ் நகல் சுட்டிக்காட்டிக்கு நகலெடுக்கும், இது வரிசையில் இலவசமாக இலவசமாக வழிவகுக்கும்.
/// இந்த காரணத்திற்காக, [`String`] என்பது [`Clone`] ஆனால் `Copy` அல்ல.
///
/// [`Clone`] `Copy` இன் சூப்பர் ட்ரெயிட், எனவே `Copy` ஆன அனைத்தும் [`Clone`] ஐ செயல்படுத்த வேண்டும்.
/// ஒரு வகை `Copy` ஆக இருந்தால், அதன் [`Clone`] செயல்படுத்தலுக்கு `*self` ஐ மட்டுமே கொடுக்க வேண்டும் (மேலே உள்ள உதாரணத்தைக் காண்க).
///
/// ## எனது வகை எப்போது `Copy` ஆக இருக்க முடியும்?
///
/// ஒரு வகை அதன் அனைத்து கூறுகளும் `Copy` ஐ செயல்படுத்தினால் `Copy` ஐ செயல்படுத்த முடியும்.எடுத்துக்காட்டாக, இந்த கட்டமைப்பு `Copy` ஆக இருக்கலாம்:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// ஒரு கட்டமைப்பு `Copy` ஆகவும், [`i32`] `Copy` ஆகவும் இருக்கும், எனவே `Point` `Copy` ஆக தகுதி பெறுகிறது.
/// இதற்கு மாறாக, கவனியுங்கள்
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `Copy` ஆனது `Copy` ஐ செயல்படுத்த முடியாது, ஏனெனில் [`Vec<T>`] `Copy` அல்ல.நாங்கள் `Copy` செயல்படுத்தலைப் பெற முயற்சித்தால், எங்களுக்கு ஒரு பிழை கிடைக்கும்:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// பகிரப்பட்ட குறிப்புகள் (`&T`) என்பதும் `Copy` ஆகும், எனவே ஒரு வகை `Copy` ஆக இருக்கலாம், இது `T` வகைகளின் பகிரப்பட்ட குறிப்புகளை வைத்திருந்தாலும் கூட *X* X * அல்ல.
/// `Copy` ஐ செயல்படுத்தக்கூடிய பின்வரும் கட்டமைப்பைக் கவனியுங்கள், ஏனென்றால் இது மேலே இருந்து எங்கள் `காப்பி 'வகை `PointList` க்கு * பகிரப்பட்ட குறிப்பை மட்டுமே வைத்திருக்கிறது:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## எப்போது *முடியாது* என் வகை `Copy` ஆக இருக்க முடியும்?
///
/// சில வகைகளை பாதுகாப்பாக நகலெடுக்க முடியாது.எடுத்துக்காட்டாக, `&mut T` ஐ நகலெடுப்பது ஒரு மாற்று மாற்றக்கூடிய குறிப்பை உருவாக்கும்.
/// [`String`] ஐ நகலெடுப்பது [`சரம்`] இன் இடையகத்தை நிர்வகிப்பதற்கான பொறுப்பை நகலெடுக்கும், இது இரட்டை இலவசத்திற்கு வழிவகுக்கும்.
///
/// பிந்தைய வழக்கைப் பொதுமைப்படுத்துவதன் மூலம், [`Drop`] ஐ செயல்படுத்தும் எந்த வகையும் `Copy` ஆக இருக்க முடியாது, ஏனெனில் இது அதன் சொந்த [`size_of::<T>`] பைட்டுகளைத் தவிர சில வளங்களை நிர்வகிக்கிறது.
///
/// `காப்பி` அல்லாத தரவைக் கொண்ட ஒரு struct அல்லது enum இல் `Copy` ஐ செயல்படுத்த முயற்சித்தால், நீங்கள் [E0204] பிழையைப் பெறுவீர்கள்.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## எப்போது * என் வகை `Copy` ஆக இருக்க வேண்டும்?
///
/// பொதுவாக, உங்கள் வகை _can_ `Copy` ஐ செயல்படுத்தினால், அது வேண்டும்.
/// இருப்பினும், `Copy` ஐ செயல்படுத்துவது உங்கள் வகையின் பொது API இன் ஒரு பகுதியாகும் என்பதை நினைவில் கொள்ளுங்கள்.
/// future இல் வகை 'காப்பி' அல்லாததாக மாறினால், உடைக்கும் ஏபிஐ மாற்றத்தைத் தவிர்க்க, இப்போது `Copy` செயல்பாட்டைத் தவிர்ப்பது விவேகமானதாக இருக்கலாம்.
///
/// ## கூடுதல் செயல்படுத்துபவர்கள்
///
/// [implementors listed below][impls] ஐத் தவிர, பின்வரும் வகைகளும் `Copy` ஐ செயல்படுத்துகின்றன:
///
/// * செயல்பாட்டு உருப்படி வகைகள் (அதாவது, ஒவ்வொரு செயல்பாட்டிற்கும் வரையறுக்கப்பட்ட தனித்துவமான வகைகள்)
/// * செயல்பாட்டு சுட்டிக்காட்டி வகைகள் (எ.கா., `fn() -> i32`)
/// * உருப்படி வகை `Copy` ஐ (எ.கா., `[i32; 123456]`) செயல்படுத்தினால், அனைத்து அளவுகளுக்கும் வரிசை வகைகள்
/// * ஒவ்வொரு கூறுகளும் `Copy` ஐ (எ.கா., `()`, `(i32, bool)`) செயல்படுத்தினால், இரட்டை வகைகள்
/// * மூடல் வகைகள், அவை சூழலில் இருந்து எந்த மதிப்பையும் கைப்பற்றவில்லை என்றால் அல்லது அத்தகைய கைப்பற்றப்பட்ட மதிப்புகள் அனைத்தும் `Copy` ஐ செயல்படுத்தினால்.
///   பகிரப்பட்ட குறிப்பால் கைப்பற்றப்பட்ட மாறிகள் எப்போதும் `Copy` ஐ செயல்படுத்துகின்றன (குறிப்பு இல்லாவிட்டாலும் கூட), அதே சமயம் மாற்றக்கூடிய குறிப்பால் கைப்பற்றப்பட்ட மாறிகள் `Copy` ஐ ஒருபோதும் செயல்படுத்தாது.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) திருப்தியடையாத வாழ்நாள் வரம்புகள் காரணமாக `Copy` ஐ செயல்படுத்தாத வகையை நகலெடுக்க இது அனுமதிக்கிறது (`A<'static>: Copy` மற்றும் `A<'_>: Clone` மட்டுமே இருக்கும்போது `A<'_>` ஐ நகலெடுக்கிறது).
// இப்போது இந்த பண்புக்கூறு எங்களிடம் உள்ளது, ஏனெனில் `Copy` இல் ஏற்கனவே உள்ள சில சிறப்புகள் நிலையான நூலகத்தில் உள்ளன, மேலும் இந்த நடத்தை இப்போது பாதுகாப்பாக இருக்க வழி இல்லை.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` இன் ஒரு impl ஐ உருவாக்கும் மேக்ரோ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// நூல்களுக்கு இடையில் குறிப்புகளைப் பகிர்வது பாதுகாப்பான வகைகள்.
///
/// இந்த trait தானாகவே கம்பைலர் பொருத்தமானது என்று தீர்மானிக்கும்போது செயல்படுத்தப்படும்.
///
/// துல்லியமான வரையறை: ஒரு வகை `T` என்பது [`Sync`] என்றால், `&T` [`Send`] ஆக இருந்தால் மட்டுமே.
/// வேறு வார்த்தைகளில் கூறுவதானால், நூல்களுக்கு இடையில் `&T` குறிப்புகளைக் கடக்கும்போது [undefined behavior][ub] (தரவு பந்தயங்கள் உட்பட) சாத்தியமில்லை என்றால்.
///
/// ஒருவர் எதிர்பார்ப்பது போல, [`u8`] மற்றும் [`f64`] போன்ற பழமையான வகைகள் அனைத்தும் [`Sync`] ஆகும், எனவே அவற்றைக் கொண்ட எளிய மொத்த வகைகளான டுபில்ஸ், ஸ்ட்ரெக்ட்ஸ் மற்றும் என்யூம்கள் போன்றவை.
/// அடிப்படை [`Sync`] வகைகளின் கூடுதல் எடுத்துக்காட்டுகள் `&T` போன்ற "immutable" வகைகள் மற்றும் [`Box<T>`][box], [`Vec<T>`][vec] மற்றும் பிற சேகரிப்பு வகைகள் போன்ற எளிய மரபுசார்ந்த பிறழ்வைக் கொண்டவை.
///
/// (பொதுவான அளவுருக்கள் அவற்றின் கொள்கலன் [`ஒத்திசைவு] ஆக இருக்க [`Sync`] ஆக இருக்க வேண்டும்.)
///
/// வரையறையின் சற்றே ஆச்சரியமான விளைவு என்னவென்றால், `&mut T` என்பது `Sync` (`T` என்பது `Sync` என்றால்) ஒத்திசைக்கப்படாத பிறழ்வை வழங்கக்கூடும் என்று தோன்றினாலும்.
/// தந்திரம் என்னவென்றால், பகிரப்பட்ட குறிப்புக்கு பின்னால் (அதாவது, `& &mut T`) ஒரு மாற்றக்கூடிய குறிப்பு, இது ஒரு `& &T` போல, படிக்க மட்டுமே.
/// எனவே தரவு பந்தயத்திற்கு எந்த ஆபத்தும் இல்லை.
///
/// `Sync` இல்லாத வகைகள் "interior mutability" மற்றும் நூல் அல்லாத பாதுகாப்பான வடிவத்தில் [`Cell`][cell] மற்றும் [`RefCell`][refcell] போன்றவை.
/// இந்த வகைகள் அவற்றின் உள்ளடக்கங்களை மாற்றமுடியாத, பகிரப்பட்ட குறிப்பு மூலம் கூட மாற்ற அனுமதிக்கின்றன.
/// எடுத்துக்காட்டாக, [`Cell<T>`][cell] இல் உள்ள `set` முறை `&self` ஐ எடுக்கும், எனவே இதற்கு பகிரப்பட்ட குறிப்பு [`&Cell<T>`][cell] மட்டுமே தேவைப்படுகிறது.
/// முறை ஒத்திசைவைச் செய்யாது, இதனால் [`Cell`][cell] `Sync` ஆக இருக்க முடியாது.
///
/// `ஒத்திசைவு 'அல்லாத வகையின் மற்றொரு எடுத்துக்காட்டு குறிப்பு-எண்ணும் சுட்டிக்காட்டி [`Rc`][rc] ஆகும்.
/// எந்தவொரு குறிப்பு [`&Rc<T>`][rc] ஐயும் கொடுத்தால், நீங்கள் ஒரு புதிய [`Rc<T>`][rc] ஐ குளோன் செய்யலாம், குறிப்பு எண்ணிக்கையை அணு அல்லாத முறையில் மாற்றியமைக்கலாம்.
///
/// ஒருவருக்கு நூல்-பாதுகாப்பான உள்துறை பிறழ்வு தேவைப்படும்போது, Rust [atomic data types] ஐ வழங்குகிறது, அத்துடன் [`sync::Mutex`][mutex] மற்றும் [`sync::RwLock`][rwlock] வழியாக வெளிப்படையான பூட்டுதலையும் வழங்குகிறது.
/// எந்தவொரு பிறழ்வும் தரவு பந்தயங்களை ஏற்படுத்தாது என்பதை இந்த வகைகள் உறுதி செய்கின்றன, எனவே வகைகள் `Sync` ஆகும்.
/// அதேபோல், [`sync::Arc`][arc] [`Rc`][rc] இன் நூல்-பாதுகாப்பான அனலாக் வழங்குகிறது.
///
/// உள்துறை மாற்றக்கூடிய எந்த வகைகளும் value(s) ஐச் சுற்றியுள்ள [`cell::UnsafeCell`][unsafecell] ரேப்பரைப் பயன்படுத்த வேண்டும், அவை பகிரப்பட்ட குறிப்பு மூலம் மாற்றப்படலாம்.
/// இதைச் செய்வதில் தோல்வி [undefined behavior][ub] ஆகும்.
/// எடுத்துக்காட்டாக, `&T` இலிருந்து `&mut T` க்கு [`உருமாற்றம்]][உருமாற்றம்] தவறானது.
///
/// `Sync` பற்றிய கூடுதல் விவரங்களுக்கு [the Nomicon][nomicon-send-and-sync] ஐப் பார்க்கவும்.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): பீட்டாவில் உள்ள `rustc_on_unimplemented` நிலங்களில் குறிப்புகளைச் சேர்க்க ஒருமுறை ஆதரவு, மற்றும் தேவைச் சங்கிலியில் எங்கும் மூடப்பட்டிருக்கிறதா என்று சோதிக்க இது நீட்டிக்கப்பட்டுள்ளது, அதை (#48534) என நீட்டிக்கவும்:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// "act like" அவர்கள் ஒரு `T` வைத்திருக்கும் விஷயங்களைக் குறிக்கப் பயன்படுத்தப்படும் பூஜ்ஜிய அளவிலான வகை.
///
/// உங்கள் வகைக்கு ஒரு `PhantomData<T>` புலத்தைச் சேர்ப்பது, உங்கள் வகை `T` வகை மதிப்பை சேமித்து வைத்தாலும், அது உண்மையில் இல்லை என்றாலும் செயல்படும் என்று தொகுப்பாளரிடம் கூறுகிறது.
/// சில பாதுகாப்பு பண்புகளை கணக்கிடும்போது இந்த தகவல் பயன்படுத்தப்படுகிறது.
///
/// `PhantomData<T>` ஐ எவ்வாறு பயன்படுத்துவது என்பது பற்றிய ஆழமான விளக்கத்திற்கு, தயவுசெய்து [the Nomicon](../../nomicon/phantom-data.html) ஐப் பார்க்கவும்.
///
/// # ஒரு பயங்கரமான குறிப்பு
///
/// அவர்கள் இருவருக்கும் பயங்கரமான பெயர்கள் இருந்தாலும், `PhantomData` மற்றும் 'பாண்டம் வகைகள்' தொடர்புடையவை, ஆனால் ஒரே மாதிரியானவை அல்ல.ஒரு பாண்டம் வகை அளவுரு என்பது ஒரு வகை அளவுருவாகும், இது ஒருபோதும் பயன்படுத்தப்படாது.
/// Rust இல், இது பெரும்பாலும் கம்பைலர் புகார் செய்ய காரணமாகிறது, மேலும் தீர்வு `PhantomData` வழியாக "dummy" பயன்பாட்டைச் சேர்ப்பதாகும்.
///
/// # Examples
///
/// ## பயன்படுத்தப்படாத வாழ்நாள் அளவுருக்கள்
///
/// `PhantomData` க்கான மிகவும் பொதுவான பயன்பாட்டு வழக்கு பயன்படுத்தப்படாத வாழ்நாள் அளவுருவைக் கொண்ட ஒரு கட்டமைப்பு ஆகும், பொதுவாக சில பாதுகாப்பற்ற குறியீட்டின் ஒரு பகுதியாக.
/// எடுத்துக்காட்டாக, `*const T` வகை இரண்டு சுட்டிகள் கொண்ட ஒரு struct `Slice` இங்கே உள்ளது, இது எங்காவது ஒரு வரிசையில் சுட்டிக்காட்டப்படுகிறது:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// இதன் நோக்கம் என்னவென்றால், அடிப்படை தரவு வாழ்நாள் `'a` க்கு மட்டுமே செல்லுபடியாகும், எனவே `Slice` `'a` ஐ விட அதிகமாக இருக்கக்கூடாது.
/// இருப்பினும், இந்த நோக்கம் குறியீட்டில் வெளிப்படுத்தப்படவில்லை, ஏனெனில் வாழ்நாள் `'a` இன் பயன்கள் எதுவும் இல்லை, எனவே இது எந்த தரவுக்கு பொருந்தும் என்பது தெளிவாக இல்லை.
/// *`Slice` struct ஒரு குறிப்பு `&'a T` ஐக் கொண்டிருப்பதைப் போல* கம்பைலரைச் செயல்படச் சொல்வதன் மூலம் இதை சரிசெய்யலாம்:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// இதற்கும் `T: 'a` என்ற சிறுகுறிப்பு தேவைப்படுகிறது, இது `T` இல் உள்ள எந்த குறிப்புகளும் வாழ்நாள் `'a` இல் செல்லுபடியாகும் என்பதைக் குறிக்கிறது.
///
/// ஒரு `Slice` ஐ துவக்கும்போது, `phantom` புலத்திற்கான `PhantomData` மதிப்பை வழங்குகிறீர்கள்:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## பயன்படுத்தப்படாத வகை அளவுருக்கள்
///
/// சில நேரங்களில் உங்களிடம் பயன்படுத்தப்படாத வகை அளவுருக்கள் உள்ளன, இது ஒரு கட்டமைப்பு "tied" க்கு எந்த வகையான தரவை குறிக்கிறது என்பதைக் குறிக்கிறது, அந்த தரவு உண்மையில் கட்டமைப்பிலேயே காணப்படவில்லை என்றாலும்.
/// இது [FFI] உடன் எழும் ஒரு எடுத்துக்காட்டு.
/// வெவ்வேறு வகையான Rust மதிப்புகளைக் குறிக்க வெளிநாட்டு இடைமுகம் `*mut ()` வகை கைப்பிடிகளைப் பயன்படுத்துகிறது.
/// ஒரு கைப்பிடியை மடிக்கும் struct `ExternalResource` இல் ஒரு பாண்டம் வகை அளவுருவைப் பயன்படுத்தி Rust வகையை நாங்கள் கண்காணிக்கிறோம்.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## உரிமையாளர் மற்றும் துளி காசோலை
///
/// `PhantomData<T>` வகை ஒரு புலத்தைச் சேர்ப்பது, உங்கள் வகை `T` வகையின் தரவைக் கொண்டுள்ளது என்பதைக் குறிக்கிறது.இது உங்கள் வகை கைவிடப்படும்போது, அது `T` வகையின் ஒன்று அல்லது அதற்கு மேற்பட்ட நிகழ்வுகளை கைவிடக்கூடும் என்பதை இது குறிக்கிறது.
/// இது Rust கம்பைலரின் [drop check] பகுப்பாய்வைக் கொண்டுள்ளது.
///
/// உங்கள் கட்டமைப்பு உண்மையில் `T` வகையின் தரவை *சொந்தமாகக் கொண்டிருக்கவில்லை என்றால், உரிமையைக் குறிக்காதபடி, `PhantomData<&'a T>` (ideally) அல்லது `PhantomData<* const T>` போன்ற ஒரு குறிப்பு வகையைப் பயன்படுத்துவது நல்லது (வாழ்நாள் முழுவதும் பொருந்தவில்லை என்றால்).
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// என்யூம் பாகுபாடுகளின் வகையைக் குறிக்க கம்பைலர்-உள் trait பயன்படுத்தப்படுகிறது.
///
/// இந்த trait ஒவ்வொரு வகைக்கும் தானாகவே செயல்படுத்தப்படுகிறது மற்றும் [`mem::Discriminant`] க்கு எந்த உத்தரவாதத்தையும் சேர்க்காது.
/// `DiscriminantKind::Discriminant` மற்றும் `mem::Discriminant` க்கு இடையில் மாற்றுவது **வரையறுக்கப்படாத நடத்தை**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// பாகுபாட்டின் வகை, இது `mem::Discriminant` க்குத் தேவையான trait bounds ஐ பூர்த்தி செய்ய வேண்டும்.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// கம்பைலர்-உள் trait ஒரு வகை உள்நாட்டில் ஏதேனும் `UnsafeCell` ஐக் கொண்டிருக்கிறதா என்பதைத் தீர்மானிக்கப் பயன்படுகிறது, ஆனால் ஒரு திசைதிருப்பலின் மூலம் அல்ல.
///
/// எடுத்துக்காட்டாக, அந்த வகையின் `static` படிக்க மட்டும் நிலையான நினைவகத்தில் அல்லது எழுதக்கூடிய நிலையான நினைவகத்தில் வைக்கப்பட்டுள்ளதா என்பதை இது பாதிக்கிறது.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// பின் செய்யப்பட்ட பின் பாதுகாப்பாக நகர்த்தக்கூடிய வகைகள்.
///
/// Rust க்கு அசையாத வகைகள் பற்றிய எந்த கருத்தும் இல்லை, மேலும் நகர்வுகளை (எ.கா., அசைன்மென்ட் அல்லது [`mem::replace`] மூலம்) எப்போதும் பாதுகாப்பாக கருதுகிறது.
///
/// வகை அமைப்பு வழியாக நகர்வுகளைத் தடுக்க [`Pin`][Pin] வகை பயன்படுத்தப்படுகிறது.[`Pin<P<T>>`][Pin] ரேப்பரில் மூடப்பட்ட சுட்டிகள் `P<T>` ஐ வெளியே நகர்த்த முடியாது.
/// பின்னிங் குறித்த கூடுதல் தகவலுக்கு [`pin` module] ஆவணங்களைப் பார்க்கவும்.
///
/// `T` க்காக `Unpin` trait ஐ செயல்படுத்துவது வகையை பின்னிங் செய்வதற்கான கட்டுப்பாடுகளை நீக்குகிறது, பின்னர் `T` ஐ [`Pin<P<T>>`][Pin] இலிருந்து [`mem::replace`] போன்ற செயல்பாடுகளுடன் நகர்த்த அனுமதிக்கிறது.
///
///
/// `Unpin` பின் செய்யப்படாத தரவுகளுக்கு எந்த விளைவுகளும் இல்லை.
/// குறிப்பாக, [`mem::replace`] மகிழ்ச்சியுடன் `!Unpin` தரவை நகர்த்துகிறது (இது எந்த `&mut T` க்கும் வேலை செய்கிறது, `T: Unpin` போது மட்டுமல்ல).
/// இருப்பினும், நீங்கள் ஒரு [`Pin<P<T>>`][Pin] க்குள் மூடப்பட்ட தரவுகளில் [`mem::replace`] ஐப் பயன்படுத்த முடியாது, ஏனென்றால் அதற்குத் தேவையான `&mut T` ஐ நீங்கள் பெற முடியாது, மேலும் * அதுதான் இந்த அமைப்பைச் செயல்படுத்துகிறது.
///
/// எனவே, இது, `Unpin` ஐ செயல்படுத்தும் வகைகளில் மட்டுமே செய்ய முடியும்:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` ஐ அழைக்க எங்களுக்கு ஒரு மாற்றத்தக்க குறிப்பு தேவை.
/// // `Pin::deref_mut` ஐ `Pin::deref_mut` ஐத் தூண்டுவதன் மூலம் அத்தகைய குறிப்பை நாம் பெறலாம், ஆனால் `String` `Unpin` ஐ செயல்படுத்துவதால் மட்டுமே இது சாத்தியமாகும்.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// இந்த trait கிட்டத்தட்ட ஒவ்வொரு வகைக்கும் தானாகவே செயல்படுத்தப்படுகிறது.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` ஐ செயல்படுத்தாத மார்க்கர் வகை.
///
/// ஒரு வகை `PhantomPinned` ஐக் கொண்டிருந்தால், அது இயல்பாக `Unpin` ஐ செயல்படுத்தாது.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// பழமையான வகைகளுக்கு `Copy` இன் செயல்பாடுகள்.
///
/// Rust இல் விவரிக்க முடியாத செயல்படுத்தல்கள் `rustc_trait_selection` இல் `traits::SelectionContext::copy_clone_conditions()` இல் செயல்படுத்தப்படுகின்றன.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// பகிரப்பட்ட குறிப்புகளை நகலெடுக்க முடியும், ஆனால் மாற்றக்கூடிய குறிப்புகள் *முடியாது*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}