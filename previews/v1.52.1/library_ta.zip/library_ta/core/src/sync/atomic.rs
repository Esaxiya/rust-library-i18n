//! அணு வகைகள்
//!
//! அணு வகைகள் நூல்களுக்கு இடையில் பழமையான பகிர்வு-நினைவக தகவல்தொடர்புகளை வழங்குகின்றன, மேலும் அவை பிற ஒரே நேரத்தில் உருவாக்கப்படும் தொகுதிகள்.
//!
//! இந்த தொகுதி [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], உள்ளிட்ட பல பழமையான வகைகளின் அணு பதிப்புகளை வரையறுக்கிறது.
//! அணு வகைகள் செயல்பாடுகளை வழங்குகின்றன, அவை சரியாகப் பயன்படுத்தப்படும்போது, நூல்களுக்கு இடையில் புதுப்பிப்புகளை ஒத்திசைக்கின்றன.
//!
//! ஒவ்வொரு முறையும் ஒரு [`Ordering`] ஐ எடுக்கும், இது அந்த செயல்பாட்டிற்கான நினைவக தடையின் வலிமையைக் குறிக்கிறது.இந்த ஆர்டர்கள் [C++20 atomic orderings][1] ஐப் போன்றவை.மேலும் தகவலுக்கு [nomicon][2] ஐப் பார்க்கவும்.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! அணு மாறிகள் நூல்களுக்கு இடையில் பகிர்வது பாதுகாப்பானது (அவை [`Sync`] ஐ செயல்படுத்துகின்றன) ஆனால் அவை பகிர்வதற்கான வழிமுறையை வழங்குவதில்லை மற்றும் Rust இன் [threading model](../../../std/thread/index.html#the-threading-model) ஐப் பின்பற்றுகின்றன.
//!
//! ஒரு அணு மாறியைப் பகிர்ந்து கொள்வதற்கான பொதுவான வழி, அதை ஒரு [`Arc`][arc] இல் வைப்பது (ஒரு அணு-குறிப்பு-எண்ணப்பட்ட பகிரப்பட்ட சுட்டிக்காட்டி).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! அணு வகைகள் நிலையான மாறிகளில் சேமிக்கப்படலாம், [`AtomicBool::new`] போன்ற நிலையான துவக்கிகளைப் பயன்படுத்தி துவக்கப்படும்.சோம்பேறி உலகளாவிய துவக்கத்திற்கு அணு புள்ளிவிவரங்கள் பெரும்பாலும் பயன்படுத்தப்படுகின்றன.
//!
//! # Portability
//!
//! இந்த தொகுதியில் உள்ள அனைத்து அணு வகைகளும் கிடைத்தால் அவை [lock-free] ஆக உத்தரவாதம் அளிக்கப்படுகின்றன.இதன் பொருள் அவர்கள் உலகளாவிய மியூடெக்ஸை உள்நாட்டில் பெறவில்லை.அணு வகைகள் மற்றும் செயல்பாடுகள் காத்திருப்பு இல்லாததாக உத்தரவாதம் அளிக்கப்படவில்லை.
//! இதன் பொருள் `fetch_or` போன்ற செயல்பாடுகள் ஒப்பீட்டு மற்றும் இடமாற்று வளையத்துடன் செயல்படுத்தப்படலாம்.
//!
//! அணுசக்தி செயல்பாடுகள் பெரிய அளவிலான அணுக்களுடன் அறிவுறுத்தல் அடுக்கில் செயல்படுத்தப்படலாம்.எடுத்துக்காட்டாக, சில தளங்கள் `AtomicI8` ஐ செயல்படுத்த 4-பைட் அணு வழிமுறைகளைப் பயன்படுத்துகின்றன.
//! இந்த சமன்பாடு குறியீட்டின் சரியான தன்மையை பாதிக்கக் கூடாது என்பதை நினைவில் கொள்க, இது எச்சரிக்கையாக இருக்க வேண்டிய ஒன்று.
//!
//! இந்த தொகுதியில் உள்ள அணு வகைகள் எல்லா தளங்களிலும் கிடைக்காமல் போகலாம்.இருப்பினும், இங்குள்ள அணு வகைகள் அனைத்தும் பரவலாகக் கிடைக்கின்றன, இருப்பினும் அவை தற்போதுள்ளதை நம்பியிருக்கலாம்.சில குறிப்பிடத்தக்க விதிவிலக்குகள்:
//!
//! * PowerPC மற்றும் 32-பிட் சுட்டிகள் கொண்ட MIPS இயங்குதளங்களில் `AtomicU64` அல்லது `AtomicI64` வகைகள் இல்லை.
//! * ARM Linux க்கு இல்லாத `armv5te` போன்ற தளங்கள் `load` மற்றும் `store` செயல்பாடுகளை மட்டுமே வழங்குகின்றன, மேலும் `swap`, `fetch_add` போன்ற (CAS) செயல்பாடுகளை ஒப்பிட்டு மாற்றவும்.
//! கூடுதலாக, Linux இல், இந்த CAS செயல்பாடுகள் [operating system support] வழியாக செயல்படுத்தப்படுகின்றன, இது செயல்திறன் அபராதத்துடன் வரக்கூடும்.
//! * ARM `thumbv6m` உடனான இலக்குகள் `load` மற்றும் `store` செயல்பாடுகளை மட்டுமே வழங்குகின்றன, மேலும் `swap`, `fetch_add` போன்ற (CAS) செயல்பாடுகளை ஒப்பிட்டு மாற்றவும்.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! future இயங்குதளங்கள் சேர்க்கப்படலாம், அவை சில அணு செயல்பாடுகளுக்கு ஆதரவையும் கொண்டிருக்கவில்லை.அதிகபட்சமாக சிறிய குறியீடு எந்த அணு வகைகள் பயன்படுத்தப்படுகின்றன என்பதில் கவனமாக இருக்க வேண்டும்.
//! `AtomicUsize` மற்றும் `AtomicIsize` பொதுவாக மிகவும் சிறியவை, ஆனால் அவை எல்லா இடங்களிலும் கிடைக்காது.
//! குறிப்புக்கு, `std` நூலகத்திற்கு சுட்டிக்காட்டி அளவிலான அணுக்கள் தேவை, இருப்பினும் `core` இல்லை.
//!
//! தற்போது நீங்கள் அணுக்களுடன் குறியீட்டில் நிபந்தனையுடன் தொகுக்க `#[cfg(target_arch)]` ஐப் பயன்படுத்த வேண்டும்.ஒரு நிலையற்ற `#[cfg(target_has_atomic)]` உள்ளது, இது future இல் உறுதிப்படுத்தப்படலாம்.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! ஒரு எளிய ஸ்பின்லாக்:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // மற்ற நூல் பூட்டை வெளியிட காத்திருக்கவும்
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! நேரடி நூல்களின் உலகளாவிய எண்ணிக்கையை வைத்திருங்கள்:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// நூல்களுக்கு இடையில் பாதுகாப்பாக பகிரக்கூடிய பூலியன் வகை.
///
/// இந்த வகை [`bool`] போன்ற நினைவக நினைவக பிரதிநிதித்துவத்தைக் கொண்டுள்ளது.
///
/// **குறிப்பு**: இந்த வகை `u8` இன் அணு சுமைகள் மற்றும் கடைகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` க்கு துவக்கப்பட்ட `AtomicBool` ஐ உருவாக்குகிறது.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// அனுப்புவது மறைமுகமாக AtomicBool க்கு செயல்படுத்தப்படுகிறது.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// மூல சுட்டிக்காட்டி வகை, இது நூல்களுக்கு இடையில் பாதுகாப்பாக பகிரப்படலாம்.
///
/// இந்த வகை `*mut T` போன்ற நினைவக நினைவக பிரதிநிதித்துவத்தைக் கொண்டுள்ளது.
///
/// **குறிப்பு**: இந்த வகை அணு சுமைகளையும் சுட்டிகளின் கடைகளையும் ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்.
/// அதன் அளவு இலக்கு சுட்டிக்காட்டி அளவைப் பொறுத்தது.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// பூஜ்ய `AtomicPtr<T>` ஐ உருவாக்குகிறது.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// அணு நினைவக வரிசைகள்
///
/// நினைவக வரிசைகள் அணு செயல்பாடுகள் நினைவகத்தை ஒத்திசைக்கும் வழியைக் குறிப்பிடுகின்றன.
/// அதன் பலவீனமான [`Ordering::Relaxed`] இல், செயல்பாட்டால் நேரடியாகத் தொட்ட நினைவகம் மட்டுமே ஒத்திசைக்கப்படுகிறது.
/// மறுபுறம், ஒரு ஸ்டோர்-லோடு ஜோடி [`Ordering::SeqCst`] செயல்பாடுகள் மற்ற நினைவகத்தை ஒத்திசைக்கின்றன, மேலும் இதுபோன்ற செயல்பாடுகளின் மொத்த வரிசையை எல்லா நூல்களிலும் பாதுகாக்கின்றன.
///
///
/// Rust இன் நினைவக வரிசைகள் [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) ஆகும்.
///
/// மேலும் தகவலுக்கு [nomicon] ஐப் பார்க்கவும்.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// வரிசைப்படுத்தும் தடைகள் இல்லை, அணு செயல்பாடுகள் மட்டுமே.
    ///
    /// C ++ 20 இல் [`memory_order_relaxed`] உடன் ஒத்துள்ளது.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// ஒரு கடையுடன் இணைந்தால், முந்தைய மதிப்பீடுகள் அனைத்தும் இந்த மதிப்பின் எந்த சுமைக்கும் முன் [`Acquire`] (அல்லது வலுவான) வரிசைப்படுத்தலுடன் ஆர்டர் செய்யப்படும்.
    ///
    /// குறிப்பாக, முந்தைய மதிப்பீடுகள் அனைத்தும் இந்த மதிப்பின் [`Acquire`] (அல்லது வலுவான) சுமையைச் செய்யும் அனைத்து நூல்களுக்கும் தெரியும்.
    ///
    /// சுமைகளையும் கடைகளையும் இணைக்கும் ஒரு செயல்பாட்டிற்கு இந்த வரிசையைப் பயன்படுத்துவது [`Relaxed`] சுமை செயல்பாட்டிற்கு வழிவகுக்கிறது என்பதைக் கவனியுங்கள்!
    ///
    /// இந்த ஆர்டர் ஒரு கடையைச் செய்யக்கூடிய செயல்பாடுகளுக்கு மட்டுமே பொருந்தும்.
    ///
    /// C ++ 20 இல் [`memory_order_release`] உடன் ஒத்துள்ளது.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// ஒரு சுமையுடன் இணைந்தால், ஏற்றப்பட்ட மதிப்பு [`Release`] (அல்லது வலுவான) வரிசைப்படுத்தலுடன் ஒரு கடை செயல்பாட்டின் மூலம் எழுதப்பட்டிருந்தால், அடுத்தடுத்த செயல்பாடுகள் அனைத்தும் அந்தக் கடைக்குப் பிறகு ஆர்டர் செய்யப்படும்.
    /// குறிப்பாக, அடுத்தடுத்த அனைத்து சுமைகளும் கடைக்கு முன் எழுதப்பட்ட தரவைக் காணும்.
    ///
    /// சுமைகளையும் கடைகளையும் இணைக்கும் ஒரு செயல்பாட்டிற்கு இந்த வரிசைப்படுத்தலைப் பயன்படுத்துவது [`Relaxed`] ஸ்டோர் செயல்பாட்டிற்கு வழிவகுக்கிறது என்பதைக் கவனியுங்கள்!
    ///
    /// சுமைகளைச் செய்யக்கூடிய செயல்பாடுகளுக்கு மட்டுமே இந்த வரிசைப்படுத்தல் பொருந்தும்.
    ///
    /// C ++ 20 இல் [`memory_order_acquire`] உடன் ஒத்துள்ளது.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// [`Acquire`] மற்றும் [`Release`] இரண்டின் விளைவுகளையும் ஒன்றாகக் கொண்டுள்ளது:
    /// சுமைகளுக்கு இது [`Acquire`] வரிசைப்படுத்துதலைப் பயன்படுத்துகிறது.கடைகளுக்கு இது [`Release`] வரிசைப்படுத்துதலைப் பயன்படுத்துகிறது.
    ///
    /// `compare_and_swap` ஐப் பொறுத்தவரை, எந்தவொரு கடையையும் செய்யாமல் செயல்படுவது முடிவடையும், எனவே இது [`Acquire`] வரிசைப்படுத்தலைக் கொண்டுள்ளது என்பதைக் கவனியுங்கள்.
    ///
    /// இருப்பினும், `AcqRel` ஒருபோதும் [`Relaxed`] அணுகல்களைச் செய்யாது.
    ///
    /// சுமைகள் மற்றும் கடைகள் இரண்டையும் இணைக்கும் செயல்பாடுகளுக்கு மட்டுமே இந்த வரிசைப்படுத்தல் பொருந்தும்.
    ///
    /// C ++ 20 இல் [`memory_order_acq_rel`] உடன் ஒத்துள்ளது.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// [`பெறுதல்`]/[`வெளியீடு`]/[`அக்ரெல்`](முறையே சுமை, கடை, மற்றும் கடையுடன் ஏற்றுவதற்கான செயல்பாடுகளுக்கு) எல்லா நூல்களும் தொடர்ச்சியாக சீரான அனைத்து செயல்பாடுகளையும் ஒரே வரிசையில் காண்கின்றன என்பதற்கான கூடுதல் உத்தரவாதத்துடன் .
    ///
    ///
    /// C ++ 20 இல் [`memory_order_seq_cst`] உடன் ஒத்துள்ளது.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// ஒரு [`AtomicBool`] `false` க்கு துவக்கப்பட்டது.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// புதிய `AtomicBool` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// அடிப்படை [`bool`] க்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// இது பாதுகாப்பானது, ஏனென்றால் அணு தரவை வேறு எந்த நூல்களும் ஒரே நேரத்தில் அணுகவில்லை என்பதை மாற்றக்கூடிய குறிப்பு உத்தரவாதம் அளிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // பாதுகாப்பு: மாற்றக்கூடிய குறிப்பு தனிப்பட்ட உரிமையை உறுதி செய்கிறது.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` க்கு அணு அணுகலைப் பெறுக.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // பாதுகாப்பு: மாற்றக்கூடிய குறிப்பு தனிப்பட்ட உரிமையை உறுதி செய்கிறது, மற்றும்
        // `bool` மற்றும் `Self` இரண்டின் சீரமைப்பு 1 ஆகும்.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// அணுவை உட்கொண்டு, அதன் மதிப்பை வழங்குகிறது.
    ///
    /// இது பாதுகாப்பானது, ஏனென்றால் `self` ஐ மதிப்பால் கடந்து செல்வது வேறு எந்த நூல்களும் ஒரே நேரத்தில் அணு தரவை அணுகவில்லை என்பதற்கு உத்தரவாதம் அளிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool இலிருந்து மதிப்பை ஏற்றுகிறது.
    ///
    /// `load` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.
    /// சாத்தியமான மதிப்புகள் [`SeqCst`], [`Acquire`] மற்றும் [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Release`] அல்லது [`AcqRel`] என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // பாதுகாப்பு: எந்தவொரு தரவு பந்தயங்களும் அணு உள்ளார்ந்த மற்றும் மூலத்தால் தடுக்கப்படுகின்றன
        // சுட்டிக்காட்டி செல்லுபடியாகும், ஏனெனில் அது ஒரு குறிப்பிலிருந்து கிடைத்தது.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// ஒரு மதிப்பை bool இல் சேமிக்கிறது.
    ///
    /// `store` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.
    /// சாத்தியமான மதிப்புகள் [`SeqCst`], [`Release`] மற்றும் [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] அல்லது [`AcqRel`] என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // பாதுகாப்பு: எந்தவொரு தரவு பந்தயங்களும் அணு உள்ளார்ந்த மற்றும் மூலத்தால் தடுக்கப்படுகின்றன
        // சுட்டிக்காட்டி செல்லுபடியாகும், ஏனெனில் அது ஒரு குறிப்பிலிருந்து கிடைத்தது.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// ஒரு மதிப்பை bool இல் சேமித்து, முந்தைய மதிப்பைத் தருகிறது.
    ///
    /// `swap` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
    /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
    ///
    ///
    /// **Note:** இந்த முறை `u8` இல் அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// தற்போதைய மதிப்பு `current` மதிப்புக்கு சமமாக இருந்தால் ஒரு மதிப்பை [`bool`] இல் சேமிக்கிறது.
    ///
    /// வருவாய் மதிப்பு எப்போதும் முந்தைய மதிப்பு.இது `current` க்கு சமமாக இருந்தால், மதிப்பு புதுப்பிக்கப்பட்டது.
    ///
    /// `compare_and_swap` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தையும் எடுக்கிறது.
    /// [`AcqRel`] ஐப் பயன்படுத்தும் போது கூட, செயல்பாடு தோல்வியடையக்கூடும், எனவே ஒரு `Acquire` சுமையைச் செய்யலாம், ஆனால் `Release` சொற்பொருள் இல்லை.
    /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் கடையின் பகுதியாக இருந்தால், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது.
    ///
    /// **Note:** இந்த முறை `u8` இல் அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கிறது.
    ///
    /// # `compare_exchange` மற்றும் `compare_exchange_weak` க்கு இடம்பெயர்கிறது
    ///
    /// `compare_and_swap` நினைவக வரிசைகளுக்கான பின்வரும் மேப்பிங்குடன் `compare_exchange` க்கு சமம்:
    ///
    /// அசல் |வெற்றி |தோல்வி
    /// -------- | ------- | -------
    /// நிதானமாக |நிதானமாக |தளர்வான கையகப்படுத்தல் |பெறுங்கள் |வெளியீட்டைப் பெறுங்கள் |வெளியீடு |நிதானமான அக்ரெல் |அக்ரெல் |SeqCst ஐப் பெறுங்கள் |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ஒப்பீடு வெற்றிபெறும்போது கூட மோசமாக தோல்வியடைய அனுமதிக்கப்படுகிறது, இது ஒரு சுழற்சியில் ஒப்பீடு மற்றும் இடமாற்று பயன்படுத்தப்படும்போது கம்பைலர் சிறந்த சட்டசபை குறியீட்டை உருவாக்க அனுமதிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// தற்போதைய மதிப்பு `current` மதிப்புக்கு சமமாக இருந்தால் ஒரு மதிப்பை [`bool`] இல் சேமிக்கிறது.
    ///
    /// வருவாய் மதிப்பு என்பது புதிய மதிப்பு எழுதப்பட்டதா மற்றும் முந்தைய மதிப்பைக் கொண்டிருந்ததா என்பதைக் குறிக்கும் விளைவாகும்.
    /// வெற்றியின் போது இந்த மதிப்பு `current` க்கு சமமாக இருக்கும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
    ///
    /// `compare_exchange` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்க இரண்டு [`Ordering`] வாதங்கள் எடுக்கும்.
    /// `success` `current` உடன் ஒப்பீடு வெற்றிபெற்றால் நடைபெறும் வாசிப்பு-மாற்றியமைத்தல்-எழுதுதல் செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
    /// `failure` ஒப்பீடு தோல்வியுற்றால் நடைபெறும் சுமை செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
    /// [`Acquire`] ஐ வெற்றிகரமான வரிசைப்படுத்தலாகப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது, மேலும் [`Release`] ஐப் பயன்படுத்துவது வெற்றிகரமான சுமை [`Relaxed`] ஐ உருவாக்குகிறது.
    ///
    /// தோல்வி வரிசைப்படுத்தல் [`SeqCst`], [`Acquire`] அல்லது [`Relaxed`] ஆக மட்டுமே இருக்க முடியும் மற்றும் வெற்றி வரிசைப்படுத்தலை விட சமமானதாகவோ அல்லது பலவீனமாகவோ இருக்க வேண்டும்.
    ///
    /// **Note:** இந்த முறை `u8` இல் அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// தற்போதைய மதிப்பு `current` மதிப்புக்கு சமமாக இருந்தால் ஒரு மதிப்பை [`bool`] இல் சேமிக்கிறது.
    ///
    /// [`AtomicBool::compare_exchange`] ஐப் போலன்றி, ஒப்பீடு வெற்றிபெறும்போது கூட இந்த செயல்பாடு மோசமாக தோல்வியடையும், இது சில தளங்களில் மிகவும் திறமையான குறியீட்டை ஏற்படுத்தும்.
    ///
    /// வருவாய் மதிப்பு என்பது புதிய மதிப்பு எழுதப்பட்டதா மற்றும் முந்தைய மதிப்பைக் கொண்டிருந்ததா என்பதைக் குறிக்கும் விளைவாகும்.
    ///
    /// `compare_exchange_weak` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்க இரண்டு [`Ordering`] வாதங்கள் எடுக்கும்.
    /// `success` `current` உடன் ஒப்பீடு வெற்றிபெற்றால் நடைபெறும் வாசிப்பு-மாற்றியமைத்தல்-எழுதுதல் செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
    /// `failure` ஒப்பீடு தோல்வியுற்றால் நடைபெறும் சுமை செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
    /// [`Acquire`] ஐ வெற்றிகரமான வரிசைப்படுத்தலாகப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது, மேலும் [`Release`] ஐப் பயன்படுத்துவது வெற்றிகரமான சுமை [`Relaxed`] ஐ உருவாக்குகிறது.
    /// தோல்வி வரிசைப்படுத்தல் [`SeqCst`], [`Acquire`] அல்லது [`Relaxed`] ஆக மட்டுமே இருக்க முடியும் மற்றும் வெற்றி வரிசைப்படுத்தலை விட சமமானதாகவோ அல்லது பலவீனமாகவோ இருக்க வேண்டும்.
    ///
    /// **Note:** இந்த முறை `u8` இல் அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// பூலியன் மதிப்புடன் தருக்க "and".
    ///
    /// தற்போதைய மதிப்பு மற்றும் வாதம் `val` ஆகியவற்றில் ஒரு தருக்க "and" செயல்பாட்டைச் செய்கிறது, மேலும் புதிய மதிப்பை முடிவுக்கு அமைக்கிறது.
    ///
    /// முந்தைய மதிப்பை வழங்குகிறது.
    ///
    /// `fetch_and` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
    /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
    ///
    ///
    /// **Note:** இந்த முறை `u8` இல் அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// பூலியன் மதிப்புடன் தருக்க "nand".
    ///
    /// தற்போதைய மதிப்பு மற்றும் வாதம் `val` ஆகியவற்றில் ஒரு தருக்க "nand" செயல்பாட்டைச் செய்கிறது, மேலும் புதிய மதிப்பை முடிவுக்கு அமைக்கிறது.
    ///
    /// முந்தைய மதிப்பை வழங்குகிறது.
    ///
    /// `fetch_nand` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
    /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
    ///
    ///
    /// **Note:** இந்த முறை `u8` இல் அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // நாம் இங்கே அணு_நந்தைப் பயன்படுத்த முடியாது, ஏனெனில் இது தவறான மதிப்புடன் bool ஐ ஏற்படுத்தும்.
        // இது நிகழ்கிறது, ஏனெனில் அணு செயல்பாடு உள்நாட்டில் 8-பிட் முழு எண்ணுடன் செய்யப்படுகிறது, இது மேல் 7 பிட்களை அமைக்கும்.
        //
        // எனவே அதற்கு பதிலாக fetch_xor அல்லது இடமாற்று பயன்படுத்துகிறோம்.
        if val {
            // ! (x&true)== !x நாம் bool ஐ தலைகீழாக மாற்ற வேண்டும்.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true நாம் bool ஐ உண்மை என அமைக்க வேண்டும்.
            //
            self.swap(true, order)
        }
    }

    /// பூலியன் மதிப்புடன் தருக்க "or".
    ///
    /// தற்போதைய மதிப்பு மற்றும் வாதம் `val` ஆகியவற்றில் ஒரு தருக்க "or" செயல்பாட்டைச் செய்கிறது, மேலும் புதிய மதிப்பை முடிவுக்கு அமைக்கிறது.
    ///
    /// முந்தைய மதிப்பை வழங்குகிறது.
    ///
    /// `fetch_or` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
    /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
    ///
    ///
    /// **Note:** இந்த முறை `u8` இல் அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// பூலியன் மதிப்புடன் தருக்க "xor".
    ///
    /// தற்போதைய மதிப்பு மற்றும் வாதம் `val` ஆகியவற்றில் ஒரு தருக்க "xor" செயல்பாட்டைச் செய்கிறது, மேலும் புதிய மதிப்பை முடிவுக்கு அமைக்கிறது.
    ///
    /// முந்தைய மதிப்பை வழங்குகிறது.
    ///
    /// `fetch_xor` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
    /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
    ///
    ///
    /// **Note:** இந்த முறை `u8` இல் அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// மாற்றக்கூடிய சுட்டிக்காட்டி அடிப்படை [`bool`] க்கு வழங்குகிறது.
    ///
    /// அணு அல்லாத வாசிப்புகளைச் செய்வதும், அதன் விளைவாக வரும் முழு எண்ணில் எழுதுவதும் தரவு பந்தயமாக இருக்கலாம்.
    /// இந்த முறை பெரும்பாலும் FFI க்கு பயனுள்ளதாக இருக்கும், அங்கு செயல்பாட்டு கையொப்பம் `&AtomicBool` க்கு பதிலாக `*mut bool` ஐப் பயன்படுத்தலாம்.
    ///
    /// இந்த அணுக்கான பகிரப்பட்ட குறிப்பிலிருந்து ஒரு `*mut` சுட்டிக்காட்டி திரும்புவது பாதுகாப்பானது, ஏனெனில் அணு வகைகள் உள்துறை மாற்றத்துடன் செயல்படுகின்றன.
    /// ஒரு அணுவின் அனைத்து மாற்றங்களும் பகிரப்பட்ட குறிப்பு மூலம் மதிப்பை மாற்றுகின்றன, மேலும் அவை அணு செயல்பாடுகளைப் பயன்படுத்தும் வரை பாதுகாப்பாக செய்ய முடியும்.
    /// திரும்பிய மூல சுட்டிக்காட்டியின் எந்தவொரு பயன்பாட்டிற்கும் ஒரு `unsafe` தொகுதி தேவைப்படுகிறது, இன்னும் அதே கட்டுப்பாட்டை நிலைநிறுத்த வேண்டும்: அதன் செயல்பாடுகள் அணுக்களாக இருக்க வேண்டும்.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// மதிப்பைப் பெறுகிறது, மேலும் விருப்பமான புதிய மதிப்பைத் தரும் ஒரு செயல்பாட்டைப் பயன்படுத்துகிறது.செயல்பாடு `Some(_)` ஐ திரும்பினால் `Ok(previous_value)` இன் `Result` ஐ வழங்குகிறது, இல்லையெனில் `Err(previous_value)`.
    ///
    /// Note: செயல்பாடு `Some(_)` ஐ வழங்கும் வரை, மற்ற நூல்களிலிருந்து மதிப்பு மாற்றப்பட்டால் இது பல முறை செயல்பாட்டை அழைக்கக்கூடும், ஆனால் செயல்பாடு சேமிக்கப்பட்ட மதிப்புக்கு ஒரு முறை மட்டுமே பயன்படுத்தப்படும்.
    ///
    ///
    /// `fetch_update` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்க இரண்டு [`Ordering`] வாதங்கள் எடுக்கும்.
    /// முதலாவதாக, செயல்பாடு இறுதியாக வெற்றிபெறும்போது தேவையான வரிசையை விவரிக்கிறது, இரண்டாவது சுமைகளுக்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
    /// இவை முறையே [`AtomicBool::compare_exchange`] இன் வெற்றி மற்றும் தோல்வி வரிசைகளுக்கு ஒத்திருக்கும்.
    ///
    /// [`Acquire`] ஐ வெற்றிகரமான வரிசையாகப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது, மேலும் [`Release`] ஐப் பயன்படுத்துவது இறுதி வெற்றிகரமான சுமை [`Relaxed`] ஐ உருவாக்குகிறது.
    /// (failed) சுமை வரிசைப்படுத்தல் [`SeqCst`], [`Acquire`] அல்லது [`Relaxed`] ஆக மட்டுமே இருக்க முடியும் மற்றும் வெற்றி வரிசைப்படுத்தலை விட சமமானதாகவோ அல்லது பலவீனமாகவோ இருக்க வேண்டும்.
    ///
    /// **Note:** இந்த முறை `u8` இல் அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// புதிய `AtomicPtr` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// அடிப்படை சுட்டிக்காட்டிக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// இது பாதுகாப்பானது, ஏனென்றால் அணு தரவை வேறு எந்த நூல்களும் ஒரே நேரத்தில் அணுகவில்லை என்பதை மாற்றக்கூடிய குறிப்பு உத்தரவாதம் அளிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// ஒரு சுட்டிக்காட்டிக்கு அணு அணுகலைப் பெறுக.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - மாற்றக்கூடிய குறிப்பு தனிப்பட்ட உரிமையை உறுதி செய்கிறது.
        //  - மேலே சரிபார்க்கப்பட்டபடி, rust ஆல் ஆதரிக்கப்படும் அனைத்து தளங்களிலும் `*mut T` மற்றும் `Self` இன் சீரமைப்பு ஒன்றுதான்.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// அணுவை உட்கொண்டு, அதன் மதிப்பை வழங்குகிறது.
    ///
    /// இது பாதுகாப்பானது, ஏனென்றால் `self` ஐ மதிப்பால் கடந்து செல்வது வேறு எந்த நூல்களும் ஒரே நேரத்தில் அணு தரவை அணுகவில்லை என்பதற்கு உத்தரவாதம் அளிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// சுட்டிக்காட்டி இருந்து ஒரு மதிப்பை ஏற்றுகிறது.
    ///
    /// `load` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.
    /// சாத்தியமான மதிப்புகள் [`SeqCst`], [`Acquire`] மற்றும் [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Release`] அல்லது [`AcqRel`] என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// ஒரு மதிப்பை சுட்டிக்காட்டிக்குள் சேமிக்கிறது.
    ///
    /// `store` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.
    /// சாத்தியமான மதிப்புகள் [`SeqCst`], [`Release`] மற்றும் [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] அல்லது [`AcqRel`] என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// ஒரு மதிப்பை சுட்டிக்காட்டிக்குள் சேமித்து, முந்தைய மதிப்பைத் தருகிறது.
    ///
    /// `swap` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
    /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
    ///
    ///
    /// **Note:** சுட்டிகள் மீது அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே இந்த முறை கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// தற்போதைய மதிப்பு `current` மதிப்புக்கு சமமாக இருந்தால் ஒரு மதிப்பை சுட்டிக்காட்டிக்குள் சேமிக்கிறது.
    ///
    /// வருவாய் மதிப்பு எப்போதும் முந்தைய மதிப்பு.இது `current` க்கு சமமாக இருந்தால், மதிப்பு புதுப்பிக்கப்பட்டது.
    ///
    /// `compare_and_swap` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தையும் எடுக்கிறது.
    /// [`AcqRel`] ஐப் பயன்படுத்தும் போது கூட, செயல்பாடு தோல்வியடையக்கூடும், எனவே ஒரு `Acquire` சுமையைச் செய்யலாம், ஆனால் `Release` சொற்பொருள் இல்லை.
    /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் கடையின் பகுதியாக இருந்தால், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது.
    ///
    /// **Note:** சுட்டிகள் மீது அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே இந்த முறை கிடைக்கிறது.
    ///
    /// # `compare_exchange` மற்றும் `compare_exchange_weak` க்கு இடம்பெயர்கிறது
    ///
    /// `compare_and_swap` நினைவக வரிசைகளுக்கான பின்வரும் மேப்பிங்குடன் `compare_exchange` க்கு சமம்:
    ///
    /// அசல் |வெற்றி |தோல்வி
    /// -------- | ------- | -------
    /// நிதானமாக |நிதானமாக |தளர்வான கையகப்படுத்தல் |பெறுங்கள் |வெளியீட்டைப் பெறுங்கள் |வெளியீடு |நிதானமான அக்ரெல் |அக்ரெல் |SeqCst ஐப் பெறுங்கள் |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ஒப்பீடு வெற்றிபெறும்போது கூட மோசமாக தோல்வியடைய அனுமதிக்கப்படுகிறது, இது ஒரு சுழற்சியில் ஒப்பீடு மற்றும் இடமாற்று பயன்படுத்தப்படும்போது கம்பைலர் சிறந்த சட்டசபை குறியீட்டை உருவாக்க அனுமதிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// தற்போதைய மதிப்பு `current` மதிப்புக்கு சமமாக இருந்தால் ஒரு மதிப்பை சுட்டிக்காட்டிக்குள் சேமிக்கிறது.
    ///
    /// வருவாய் மதிப்பு என்பது புதிய மதிப்பு எழுதப்பட்டதா மற்றும் முந்தைய மதிப்பைக் கொண்டிருந்ததா என்பதைக் குறிக்கும் விளைவாகும்.
    /// வெற்றியின் போது இந்த மதிப்பு `current` க்கு சமமாக இருக்கும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
    ///
    /// `compare_exchange` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்க இரண்டு [`Ordering`] வாதங்கள் எடுக்கும்.
    /// `success` `current` உடன் ஒப்பீடு வெற்றிபெற்றால் நடைபெறும் வாசிப்பு-மாற்றியமைத்தல்-எழுதுதல் செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
    /// `failure` ஒப்பீடு தோல்வியுற்றால் நடைபெறும் சுமை செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
    /// [`Acquire`] ஐ வெற்றிகரமான வரிசைப்படுத்தலாகப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது, மேலும் [`Release`] ஐப் பயன்படுத்துவது வெற்றிகரமான சுமை [`Relaxed`] ஐ உருவாக்குகிறது.
    ///
    /// தோல்வி வரிசைப்படுத்தல் [`SeqCst`], [`Acquire`] அல்லது [`Relaxed`] ஆக மட்டுமே இருக்க முடியும் மற்றும் வெற்றி வரிசைப்படுத்தலை விட சமமானதாகவோ அல்லது பலவீனமாகவோ இருக்க வேண்டும்.
    ///
    /// **Note:** சுட்டிகள் மீது அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே இந்த முறை கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// தற்போதைய மதிப்பு `current` மதிப்புக்கு சமமாக இருந்தால் ஒரு மதிப்பை சுட்டிக்காட்டிக்குள் சேமிக்கிறது.
    ///
    /// [`AtomicPtr::compare_exchange`] ஐப் போலன்றி, ஒப்பீடு வெற்றிபெறும்போது கூட இந்த செயல்பாடு மோசமாக தோல்வியடையும், இது சில தளங்களில் மிகவும் திறமையான குறியீட்டை ஏற்படுத்தும்.
    ///
    /// வருவாய் மதிப்பு என்பது புதிய மதிப்பு எழுதப்பட்டதா மற்றும் முந்தைய மதிப்பைக் கொண்டிருந்ததா என்பதைக் குறிக்கும் விளைவாகும்.
    ///
    /// `compare_exchange_weak` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்க இரண்டு [`Ordering`] வாதங்கள் எடுக்கும்.
    /// `success` `current` உடன் ஒப்பீடு வெற்றிபெற்றால் நடைபெறும் வாசிப்பு-மாற்றியமைத்தல்-எழுதுதல் செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
    /// `failure` ஒப்பீடு தோல்வியுற்றால் நடைபெறும் சுமை செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
    /// [`Acquire`] ஐ வெற்றிகரமான வரிசைப்படுத்தலாகப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது, மேலும் [`Release`] ஐப் பயன்படுத்துவது வெற்றிகரமான சுமை [`Relaxed`] ஐ உருவாக்குகிறது.
    /// தோல்வி வரிசைப்படுத்தல் [`SeqCst`], [`Acquire`] அல்லது [`Relaxed`] ஆக மட்டுமே இருக்க முடியும் மற்றும் வெற்றி வரிசைப்படுத்தலை விட சமமானதாகவோ அல்லது பலவீனமாகவோ இருக்க வேண்டும்.
    ///
    /// **Note:** சுட்டிகள் மீது அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே இந்த முறை கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // பாதுகாப்பு: இந்த உள்ளார்ந்த பாதுகாப்பற்றது, ஏனெனில் இது ஒரு மூல சுட்டிக்காட்டி மீது இயங்குகிறது
        // ஆனால் சுட்டிக்காட்டி செல்லுபடியாகும் என்பதை நாங்கள் உறுதியாக அறிவோம் (குறிப்பு மூலம் எங்களிடம் உள்ள ஒரு `UnsafeCell` இலிருந்து அதைப் பெற்றுள்ளோம்) மற்றும் அணு செயல்பாடே `UnsafeCell` உள்ளடக்கங்களை பாதுகாப்பாக மாற்ற அனுமதிக்கிறது.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// மதிப்பைப் பெறுகிறது, மேலும் விருப்பமான புதிய மதிப்பைத் தரும் ஒரு செயல்பாட்டைப் பயன்படுத்துகிறது.செயல்பாடு `Some(_)` ஐ திரும்பினால் `Ok(previous_value)` இன் `Result` ஐ வழங்குகிறது, இல்லையெனில் `Err(previous_value)`.
    ///
    /// Note: செயல்பாடு `Some(_)` ஐ வழங்கும் வரை, மற்ற நூல்களிலிருந்து மதிப்பு மாற்றப்பட்டால் இது பல முறை செயல்பாட்டை அழைக்கக்கூடும், ஆனால் செயல்பாடு சேமிக்கப்பட்ட மதிப்புக்கு ஒரு முறை மட்டுமே பயன்படுத்தப்படும்.
    ///
    ///
    /// `fetch_update` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்க இரண்டு [`Ordering`] வாதங்கள் எடுக்கும்.
    /// முதலாவதாக, செயல்பாடு இறுதியாக வெற்றிபெறும்போது தேவையான வரிசையை விவரிக்கிறது, இரண்டாவது சுமைகளுக்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
    /// இவை முறையே [`AtomicPtr::compare_exchange`] இன் வெற்றி மற்றும் தோல்வி வரிசைகளுக்கு ஒத்திருக்கும்.
    ///
    /// [`Acquire`] ஐ வெற்றிகரமான வரிசையாகப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது, மேலும் [`Release`] ஐப் பயன்படுத்துவது இறுதி வெற்றிகரமான சுமை [`Relaxed`] ஐ உருவாக்குகிறது.
    /// (failed) சுமை வரிசைப்படுத்தல் [`SeqCst`], [`Acquire`] அல்லது [`Relaxed`] ஆக மட்டுமே இருக்க முடியும் மற்றும் வெற்றி வரிசைப்படுத்தலை விட சமமானதாகவோ அல்லது பலவீனமாகவோ இருக்க வேண்டும்.
    ///
    /// **Note:** சுட்டிகள் மீது அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே இந்த முறை கிடைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// ஒரு `bool` ஐ `AtomicBool` ஆக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // இந்த மேக்ரோ சில கட்டமைப்புகளில் பயன்படுத்தப்படாமல் முடிகிறது.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// நூல்களுக்கு இடையில் பாதுகாப்பாக பகிரக்கூடிய ஒரு முழு வகை.
        ///
        /// இந்த வகை அடிப்படை முழு வகை, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// அணு வகைகள் மற்றும் அணு அல்லாத வகைகளுக்கு இடையிலான வேறுபாடுகள் மற்றும் இந்த வகையின் பெயர்வுத்திறன் பற்றிய தகவல்களுக்கு மேலும் அறிய, தயவுசெய்து [module-level documentation] ஐப் பார்க்கவும்.
        ///
        ///
        /// **Note:** [`இன் அணு சுமைகள் மற்றும் கடைகளை ஆதரிக்கும் தளங்களில் மட்டுமே இந்த வகை கிடைக்கிறது
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// ஒரு அணு முழு எண் `0` க்கு துவக்கப்பட்டது.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // அனுப்புவது மறைமுகமாக செயல்படுத்தப்படுகிறது.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// புதிய அணு முழு எண்ணை உருவாக்குகிறது.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// அடிப்படை முழு எண்ணுக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
            ///
            /// இது பாதுகாப்பானது, ஏனென்றால் அணு தரவை வேறு எந்த நூல்களும் ஒரே நேரத்தில் அணுகவில்லை என்பதை மாற்றக்கூடிய குறிப்பு உத்தரவாதம் அளிக்கிறது.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - மாற்றக்கூடிய குறிப்பு தனிப்பட்ட உரிமையை உறுதி செய்கிறது.
                //  - `$int_type` மற்றும் `Self` இன் சீரமைப்பு ஒன்றுதான், இது $cfg_align ஆல் வாக்குறுதியளிக்கப்பட்டு மேலே சரிபார்க்கப்பட்டது.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// அணுவை உட்கொண்டு, அதன் மதிப்பை வழங்குகிறது.
            ///
            /// இது பாதுகாப்பானது, ஏனென்றால் `self` ஐ மதிப்பால் கடந்து செல்வது வேறு எந்த நூல்களும் ஒரே நேரத்தில் அணு தரவை அணுகவில்லை என்பதற்கு உத்தரவாதம் அளிக்கிறது.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// அணு முழு எண்ணிலிருந்து ஒரு மதிப்பை ஏற்றுகிறது.
            ///
            /// `load` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.
            /// சாத்தியமான மதிப்புகள் [`SeqCst`], [`Acquire`] மற்றும் [`Relaxed`].
            ///
            /// # Panics
            ///
            /// `order` [`Release`] அல்லது [`AcqRel`] என்றால் Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// அணு முழு எண்ணில் ஒரு மதிப்பை சேமிக்கிறது.
            ///
            /// `store` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.
            ///  சாத்தியமான மதிப்புகள் [`SeqCst`], [`Release`] மற்றும் [`Relaxed`].
            ///
            /// # Panics
            ///
            /// `order` [`Acquire`] அல்லது [`AcqRel`] என்றால் Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// ஒரு மதிப்பை அணு முழு எண்ணில் சேமித்து, முந்தைய மதிப்பைத் தருகிறது.
            ///
            /// `swap` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
            /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
            ///
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// தற்போதைய மதிப்பு `current` மதிப்புக்கு சமமாக இருந்தால் ஒரு மதிப்பை அணு முழு எண்ணில் சேமிக்கிறது.
            ///
            /// வருவாய் மதிப்பு எப்போதும் முந்தைய மதிப்பு.இது `current` க்கு சமமாக இருந்தால், மதிப்பு புதுப்பிக்கப்பட்டது.
            ///
            /// `compare_and_swap` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தையும் எடுக்கிறது.
            /// [`AcqRel`] ஐப் பயன்படுத்தும் போது கூட, செயல்பாடு தோல்வியடையக்கூடும், எனவே ஒரு `Acquire` சுமையைச் செய்யலாம், ஆனால் `Release` சொற்பொருள் இல்லை.
            ///
            /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் கடையின் பகுதியாக இருந்தால், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது.
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` மற்றும் `compare_exchange_weak` க்கு இடம்பெயர்கிறது
            ///
            /// `compare_and_swap` நினைவக வரிசைகளுக்கான பின்வரும் மேப்பிங்குடன் `compare_exchange` க்கு சமம்:
            ///
            /// அசல் |வெற்றி |தோல்வி
            /// -------- | ------- | -------
            /// நிதானமாக |நிதானமாக |தளர்வான கையகப்படுத்தல் |பெறுங்கள் |வெளியீட்டைப் பெறுங்கள் |வெளியீடு |நிதானமான அக்ரெல் |அக்ரெல் |SeqCst ஐப் பெறுங்கள் |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ஒப்பீடு வெற்றிபெறும்போது கூட மோசமாக தோல்வியடைய அனுமதிக்கப்படுகிறது, இது ஒரு சுழற்சியில் ஒப்பீடு மற்றும் இடமாற்று பயன்படுத்தப்படும்போது கம்பைலர் சிறந்த சட்டசபை குறியீட்டை உருவாக்க அனுமதிக்கிறது.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// தற்போதைய மதிப்பு `current` மதிப்புக்கு சமமாக இருந்தால் ஒரு மதிப்பை அணு முழு எண்ணில் சேமிக்கிறது.
            ///
            /// வருவாய் மதிப்பு என்பது புதிய மதிப்பு எழுதப்பட்டதா மற்றும் முந்தைய மதிப்பைக் கொண்டிருந்ததா என்பதைக் குறிக்கும் விளைவாகும்.
            /// வெற்றியின் போது இந்த மதிப்பு `current` க்கு சமமாக இருக்கும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
            ///
            /// `compare_exchange` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்க இரண்டு [`Ordering`] வாதங்கள் எடுக்கும்.
            /// `success` `current` உடன் ஒப்பீடு வெற்றிபெற்றால் நடைபெறும் வாசிப்பு-மாற்றியமைத்தல்-எழுதுதல் செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
            /// `failure` ஒப்பீடு தோல்வியுற்றால் நடைபெறும் சுமை செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
            /// [`Acquire`] ஐ வெற்றிகரமான வரிசைப்படுத்தலாகப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது, மேலும் [`Release`] ஐப் பயன்படுத்துவது வெற்றிகரமான சுமை [`Relaxed`] ஐ உருவாக்குகிறது.
            ///
            /// தோல்வி வரிசைப்படுத்தல் [`SeqCst`], [`Acquire`] அல்லது [`Relaxed`] ஆக மட்டுமே இருக்க முடியும் மற்றும் வெற்றி வரிசைப்படுத்தலை விட சமமானதாகவோ அல்லது பலவீனமாகவோ இருக்க வேண்டும்.
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// தற்போதைய மதிப்பு `current` மதிப்புக்கு சமமாக இருந்தால் ஒரு மதிப்பை அணு முழு எண்ணில் சேமிக்கிறது.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ஒப்பீடு வெற்றிபெறும்போது கூட இந்த செயல்பாடு மோசமாக தோல்வியடையும், இது சில தளங்களில் மிகவும் திறமையான குறியீட்டை ஏற்படுத்தும்.
            /// வருவாய் மதிப்பு என்பது புதிய மதிப்பு எழுதப்பட்டதா மற்றும் முந்தைய மதிப்பைக் கொண்டிருந்ததா என்பதைக் குறிக்கும் விளைவாகும்.
            ///
            /// `compare_exchange_weak` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்க இரண்டு [`Ordering`] வாதங்கள் எடுக்கும்.
            /// `success` `current` உடன் ஒப்பீடு வெற்றிபெற்றால் நடைபெறும் வாசிப்பு-மாற்றியமைத்தல்-எழுதுதல் செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
            /// `failure` ஒப்பீடு தோல்வியுற்றால் நடைபெறும் சுமை செயல்பாட்டிற்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.
            /// [`Acquire`] ஐ வெற்றிகரமான வரிசைப்படுத்தலாகப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது, மேலும் [`Release`] ஐப் பயன்படுத்துவது வெற்றிகரமான சுமை [`Relaxed`] ஐ உருவாக்குகிறது.
            ///
            /// தோல்வி வரிசைப்படுத்தல் [`SeqCst`], [`Acquire`] அல்லது [`Relaxed`] ஆக மட்டுமே இருக்க முடியும் மற்றும் வெற்றி வரிசைப்படுத்தலை விட சமமானதாகவோ அல்லது பலவீனமாகவோ இருக்க வேண்டும்.
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// mut old= val.load(Ordering::Relaxed);
            /// loop new புதியது=பழையது * 2;
            ///     போட்டி val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// தற்போதைய மதிப்பைச் சேர்க்கிறது, முந்தைய மதிப்பைத் தருகிறது.
            ///
            /// இந்த செயல்பாடு நிரம்பி வழிகிறது.
            ///
            /// `fetch_add` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
            /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
            ///
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// தற்போதைய மதிப்பிலிருந்து கழித்து, முந்தைய மதிப்பைத் தருகிறது.
            ///
            /// இந்த செயல்பாடு நிரம்பி வழிகிறது.
            ///
            /// `fetch_sub` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
            /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
            ///
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// தற்போதைய மதிப்புடன் பிட்வைஸ் "and".
            ///
            /// தற்போதைய மதிப்பு மற்றும் வாதம் `val` ஆகியவற்றில் பிட்வைஸ் "and" செயல்பாட்டைச் செய்கிறது, மேலும் புதிய மதிப்பை முடிவுக்கு அமைக்கிறது.
            ///
            /// முந்தைய மதிப்பை வழங்குகிறது.
            ///
            /// `fetch_and` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
            /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
            ///
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// தற்போதைய மதிப்புடன் பிட்வைஸ் "nand".
            ///
            /// தற்போதைய மதிப்பு மற்றும் வாதம் `val` ஆகியவற்றில் பிட்வைஸ் "nand" செயல்பாட்டைச் செய்கிறது, மேலும் புதிய மதிப்பை முடிவுக்கு அமைக்கிறது.
            ///
            /// முந்தைய மதிப்பை வழங்குகிறது.
            ///
            /// `fetch_nand` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
            /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
            ///
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// தற்போதைய மதிப்புடன் பிட்வைஸ் "or".
            ///
            /// தற்போதைய மதிப்பு மற்றும் வாதம் `val` ஆகியவற்றில் பிட்வைஸ் "or" செயல்பாட்டைச் செய்கிறது, மேலும் புதிய மதிப்பை முடிவுக்கு அமைக்கிறது.
            ///
            /// முந்தைய மதிப்பை வழங்குகிறது.
            ///
            /// `fetch_or` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
            /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
            ///
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// தற்போதைய மதிப்புடன் பிட்வைஸ் "xor".
            ///
            /// தற்போதைய மதிப்பு மற்றும் வாதம் `val` ஆகியவற்றில் பிட்வைஸ் "xor" செயல்பாட்டைச் செய்கிறது, மேலும் புதிய மதிப்பை முடிவுக்கு அமைக்கிறது.
            ///
            /// முந்தைய மதிப்பை வழங்குகிறது.
            ///
            /// `fetch_xor` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
            /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
            ///
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// மதிப்பைப் பெறுகிறது, மேலும் விருப்பமான புதிய மதிப்பைத் தரும் ஒரு செயல்பாட்டைப் பயன்படுத்துகிறது.செயல்பாடு `Some(_)` ஐ திரும்பினால் `Ok(previous_value)` இன் `Result` ஐ வழங்குகிறது, இல்லையெனில் `Err(previous_value)`.
            ///
            /// Note: செயல்பாடு `Some(_)` ஐ வழங்கும் வரை, மற்ற நூல்களிலிருந்து மதிப்பு மாற்றப்பட்டால் இது பல முறை செயல்பாட்டை அழைக்கக்கூடும், ஆனால் செயல்பாடு சேமிக்கப்பட்ட மதிப்புக்கு ஒரு முறை மட்டுமே பயன்படுத்தப்படும்.
            ///
            ///
            /// `fetch_update` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்க இரண்டு [`Ordering`] வாதங்கள் எடுக்கும்.
            /// முதலாவதாக, செயல்பாடு இறுதியாக வெற்றிபெறும்போது தேவையான வரிசைப்படுத்தலை விவரிக்கிறது, இரண்டாவது சுமைகளுக்கு தேவையான வரிசைப்படுத்தலை விவரிக்கிறது.இவை வெற்றி மற்றும் தோல்வி வரிசைகளுக்கு ஒத்திருக்கும்
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] ஐ வெற்றிகரமான வரிசையாகப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது, மேலும் [`Release`] ஐப் பயன்படுத்துவது இறுதி வெற்றிகரமான சுமை [`Relaxed`] ஐ உருவாக்குகிறது.
            /// (failed) சுமை வரிசைப்படுத்தல் [`SeqCst`], [`Acquire`] அல்லது [`Relaxed`] ஆக மட்டுமே இருக்க முடியும் மற்றும் வெற்றி வரிசைப்படுத்தலை விட சமமானதாகவோ அல்லது பலவீனமாகவோ இருக்க வேண்டும்.
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (வரிசைப்படுத்துதல்: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (வரிசைப்படுத்துதல்: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// தற்போதைய மதிப்புடன் அதிகபட்சம்.
            ///
            /// தற்போதைய மதிப்பு மற்றும் வாதம் `val` இன் அதிகபட்சத்தைக் கண்டறிந்து, புதிய மதிப்பை முடிவுக்கு அமைக்கிறது.
            ///
            /// முந்தைய மதிப்பை வழங்குகிறது.
            ///
            /// `fetch_max` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
            /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
            ///
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// பட்டி=42;
            /// max_foo=foo.fetch_max (பட்டி, Ordering::SeqCst).max(bar);
            /// உறுதிப்படுத்து! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// தற்போதைய மதிப்புடன் குறைந்தபட்சம்.
            ///
            /// தற்போதைய மதிப்பு மற்றும் வாதம் `val` இன் குறைந்தபட்சத்தைக் கண்டறிந்து, புதிய மதிப்பை முடிவுக்கு அமைக்கிறது.
            ///
            /// முந்தைய மதிப்பை வழங்குகிறது.
            ///
            /// `fetch_min` இந்த செயல்பாட்டின் நினைவக வரிசையை விவரிக்கும் ஒரு [`Ordering`] வாதத்தை எடுக்கிறது.அனைத்து வரிசைப்படுத்தும் முறைகளும் சாத்தியமாகும்.
            /// [`Acquire`] ஐப் பயன்படுத்துவது இந்த செயல்பாட்டின் [`Relaxed`] இன் அங்கமாகிறது என்பதையும், [`Release`] ஐப் பயன்படுத்துவதால் சுமை பகுதி [`Relaxed`] ஆகிறது என்பதையும் நினைவில் கொள்க.
            ///
            ///
            /// **குறிப்பு**: இந்த முறை அணு செயல்பாடுகளை ஆதரிக்கும் தளங்களில் மட்டுமே கிடைக்கும்
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// பட்டி=12;
            /// min_foo=foo.fetch_min (பட்டி, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // பாதுகாப்பு: தரவு இனங்கள் அணு உள்ளார்ந்தவற்றால் தடுக்கப்படுகின்றன.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// மாற்றக்கூடிய சுட்டிக்காட்டி அடிப்படை முழு எண்ணுக்கு வழங்குகிறது.
            ///
            /// அணு அல்லாத வாசிப்புகளைச் செய்வதும், அதன் விளைவாக வரும் முழு எண்ணில் எழுதுவதும் தரவு பந்தயமாக இருக்கலாம்.
            /// இந்த முறை பெரும்பாலும் FFI க்கு பயனுள்ளதாக இருக்கும், அங்கு செயல்பாட்டு கையொப்பம் பயன்படுத்தப்படலாம்
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// இந்த அணுக்கான பகிரப்பட்ட குறிப்பிலிருந்து ஒரு `*mut` சுட்டிக்காட்டி திரும்புவது பாதுகாப்பானது, ஏனெனில் அணு வகைகள் உள்துறை மாற்றத்துடன் செயல்படுகின்றன.
            /// ஒரு அணுவின் அனைத்து மாற்றங்களும் பகிரப்பட்ட குறிப்பு மூலம் மதிப்பை மாற்றுகின்றன, மேலும் அவை அணு செயல்பாடுகளைப் பயன்படுத்தும் வரை பாதுகாப்பாக செய்ய முடியும்.
            /// திரும்பிய மூல சுட்டிக்காட்டியின் எந்தவொரு பயன்பாட்டிற்கும் ஒரு `unsafe` தொகுதி தேவைப்படுகிறது, இன்னும் அதே கட்டுப்பாட்டை நிலைநிறுத்த வேண்டும்: அதன் செயல்பாடுகள் அணுக்களாக இருக்க வேண்டும்.
            ///
            ///
            /// # Examples
            ///
            /// `` (extern-declaration) ஐ புறக்கணிக்கவும்
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// வெளிப்புற "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // பாதுகாப்பு: `my_atomic_op` அணு இருக்கும் வரை பாதுகாப்பானது.
            /// பாதுகாப்பற்றது {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_store` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_load` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_swap` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// முந்தைய மதிப்பை வழங்குகிறது (__sync_fetch_and_add போன்றவை).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_add` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// முந்தைய மதிப்பை வழங்குகிறது (__sync_fetch_and_sub போன்றவை).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_sub` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_compare_exchange` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_compare_exchange_weak` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_and` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_nand` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_or` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_xor` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// அதிகபட்ச மதிப்பை வழங்குகிறது (கையொப்பமிடப்பட்ட ஒப்பீடு)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_max` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// நிமிட மதிப்பை வழங்குகிறது (கையொப்பமிடப்பட்ட ஒப்பீடு)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_min` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// அதிகபட்ச மதிப்பை வழங்குகிறது (கையொப்பமிடாத ஒப்பீடு)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_umax` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// நிமிட மதிப்பை வழங்குகிறது (கையொப்பமிடாத ஒப்பீடு)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // பாதுகாப்பு: அழைப்பாளர் `atomic_umin` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// ஒரு அணு வேலி.
///
/// குறிப்பிட்ட வரிசையைப் பொறுத்து, ஒரு வேலி கம்பைலர் மற்றும் சிபியு அதைச் சுற்றியுள்ள சில வகையான நினைவக செயல்பாடுகளை மறுவரிசைப்படுத்துவதைத் தடுக்கிறது.
/// இது ஒத்திசைவை உருவாக்குகிறது-அதற்கும் மற்ற அணுக்களில் அணு செயல்பாடுகள் அல்லது வேலிகளுக்கும் இடையிலான உறவுகள்.
///
/// (குறைந்தது) [`Release`] வரிசைப்படுத்தும் சொற்பொருளைக் கொண்ட ஒரு வேலி 'A', வேலி 'B' உடன் (குறைந்தது) [`Acquire`] சொற்பொருளுடன் ஒத்திசைக்கிறது, X மற்றும் Y செயல்பாடுகள் இருந்தால் மட்டுமே, இரண்டுமே சில அணு பொருள் 'M' இல் இயங்குகின்றன, அதாவது A க்கு முன் வரிசைப்படுத்தப்படுகிறது பி, ஒய் எம் மாற்றத்தை கவனிப்பதற்கு முன்பு எக்ஸ், ஒய் ஒத்திசைக்கப்படுகிறது.
/// இது A மற்றும் B க்கு இடையில் ஒரு சார்பு முன் சார்புநிலையை வழங்குகிறது.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] அல்லது [`Acquire`] சொற்பொருள்களுடன் அணு செயல்பாடுகளும் வேலியுடன் ஒத்திசைக்கப்படலாம்.
///
/// [`Acquire`] மற்றும் [`Release`] சொற்பொருள்களைக் கொண்டிருப்பதைத் தவிர, [`SeqCst`] வரிசைப்படுத்தும் வேலி, மற்ற [`SeqCst`] செயல்பாடுகள் மற்றும்/அல்லது வேலிகளின் உலகளாவிய நிரல் வரிசையில் பங்கேற்கிறது.
///
/// [`Acquire`], [`Release`], [`AcqRel`] மற்றும் [`SeqCst`] வரிசைகளை ஏற்றுக்கொள்கிறது.
///
/// # Panics
///
/// `order` [`Relaxed`] என்றால் Panics.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // ஸ்பின்லாக் அடிப்படையில் பரஸ்பர விலக்கு பழமையானது.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // பழைய மதிப்பு `false` ஆகும் வரை காத்திருங்கள்.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // இந்த வேலி `unlock` இல் கடையுடன் ஒத்திசைக்கிறது.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // பாதுகாப்பு: அணு வேலியைப் பயன்படுத்துவது பாதுகாப்பானது.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// ஒரு கம்பைலர் நினைவக வேலி.
///
/// `compiler_fence` எந்த இயந்திர குறியீட்டையும் வெளியிடுவதில்லை, ஆனால் கம்பைலர் செய்ய அனுமதிக்கப்பட்ட நினைவகத்தை மறு வரிசைப்படுத்துவதை கட்டுப்படுத்துகிறது.குறிப்பாக, கொடுக்கப்பட்ட [`Ordering`] சொற்பொருளைப் பொறுத்து, `compiler_fence` க்கான அழைப்பின் மறுபக்கத்திற்கு அழைப்புக்கு முன்னும் பின்னும் இருந்து வாசிப்புகளை அல்லது எழுதுவதை தொகுப்பி அனுமதிக்கக்கூடாது.இதுபோன்ற மறு வரிசைப்படுத்துதலை *வன்பொருள்* தடுக்காது **என்பதை** நினைவில் கொள்க.
///
/// ஒற்றை-திரிக்கப்பட்ட, செயல்படுத்தல் சூழலில் இது ஒரு சிக்கல் அல்ல, ஆனால் மற்ற நூல்கள் ஒரே நேரத்தில் நினைவகத்தை மாற்றும்போது, [`fence`] போன்ற வலுவான ஒத்திசைவு ஆதிமூலங்கள் தேவைப்படுகின்றன.
///
/// வெவ்வேறு வரிசைப்படுத்தும் சொற்பொருள்களால் தடுக்கப்பட்ட மறு வரிசைப்படுத்தல்:
///
///  - [`SeqCst`] உடன், இந்த புள்ளியில் படிக்க மற்றும் எழுதுவதை மறு வரிசைப்படுத்துவதற்கு அனுமதி இல்லை.
///  - [`Release`] உடன், முந்தைய வாசிப்புகள் மற்றும் எழுதுதல்களை முந்தைய அடுத்தடுத்த எழுத்துக்களை நகர்த்த முடியாது.
///  - [`Acquire`] உடன், முந்தைய வாசிப்புகளை விட அடுத்தடுத்த வாசிப்புகள் மற்றும் எழுத்துக்களை நகர்த்த முடியாது.
///  - [`AcqRel`] உடன், மேலே உள்ள இரண்டு விதிகளும் செயல்படுத்தப்படுகின்றன.
///
/// `compiler_fence` ஒரு நூல் பந்தயத்திலிருந்து *தன்னைத் தடுக்க* பொதுவாக மட்டுமே பயனுள்ளதாக இருக்கும்.அதாவது, கொடுக்கப்பட்ட நூல் ஒரு குறியீட்டை இயக்கி, பின்னர் குறுக்கிட்டு, குறியீட்டை வேறொரு இடத்தில் இயக்கத் தொடங்குகிறது (இன்னும் அதே நூலில் இருக்கும்போது, மற்றும் கருத்தியல் ரீதியாக அதே மையத்தில்).பாரம்பரிய நிரல்களில், சமிக்ஞை கையாளுபவர் பதிவு செய்யப்படும்போது மட்டுமே இது நிகழும்.
/// மேலும் குறைந்த-நிலை குறியீட்டில், குறுக்கீடுகளைக் கையாளும் போது, முன்-தூண்டுதலுடன் பச்சை நூல்களைச் செயல்படுத்தும்போது இதுபோன்ற சூழ்நிலைகள் ஏற்படலாம்.
/// ஆர்வமுள்ள வாசகர்கள் [memory barriers] பற்றிய Linux கர்னலின் விவாதத்தைப் படிக்க ஊக்குவிக்கப்படுகிறார்கள்.
///
/// # Panics
///
/// `order` [`Relaxed`] என்றால் Panics.
///
/// # Examples
///
/// `compiler_fence` இல்லாமல், பின்வரும் குறியீட்டில் உள்ள `assert_eq!` அனைத்தும் ஒரே நூலில் நடக்கும் போதிலும், வெற்றிபெற * உத்தரவாதம் இல்லை.
/// ஏன் என்பதைப் பார்க்க, கம்பைலர் `IMPORTANT_VARIABLE` மற்றும் `IS_READ` க்கு கடைகளை மாற்றுவதற்கு இலவசம் என்பதை நினைவில் கொள்ளுங்கள், ஏனெனில் அவை இரண்டும் `Ordering::Relaxed` ஆகும்.அவ்வாறு செய்தால், `IS_READY` புதுப்பிக்கப்பட்ட உடனேயே சமிக்ஞை கையாளுதல் செயல்படுத்தப்பட்டால், சமிக்ஞை கையாளுபவர் `IS_READY=1` ஐப் பார்ப்பார், ஆனால் `IMPORTANT_VARIABLE=0`.
/// ஒரு `compiler_fence` வைத்தியம் பயன்படுத்தி இந்த நிலைமை.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // முந்தைய எழுத்துக்கள் இந்த கட்டத்திற்கு அப்பால் நகர்த்தப்படுவதைத் தடுக்கவும்
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // பாதுகாப்பு: அணு வேலியைப் பயன்படுத்துவது பாதுகாப்பானது.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// செயலி ஒரு பிஸியான-காத்திருப்பு ஸ்பின்-லூப் ("ஸ்பின் லாக்") க்குள் இருப்பதாக சமிக்ஞை செய்கிறது.
///
/// இந்த செயல்பாடு [`hint::spin_loop`] க்கு ஆதரவாக நீக்கப்பட்டது.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}