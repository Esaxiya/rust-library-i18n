//! ஒத்திசைவு பழமையானவை

#![stable(feature = "rust1", since = "1.0.0")]

pub mod atomic;