//! சரங்களை வடிவமைத்தல் மற்றும் அச்சிடுவதற்கான பயன்பாடுகள்.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` ஆல் வழங்கப்படும் சாத்தியமான சீரமைப்புகள்
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// உள்ளடக்கங்களை இடது-சீரமைக்க வேண்டும் என்பதற்கான அறிகுறி.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// உள்ளடக்கங்கள் சரியாக சீரமைக்கப்பட வேண்டும் என்பதற்கான அறிகுறி.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// உள்ளடக்கங்கள் மையமாக சீரமைக்கப்பட வேண்டும் என்பதற்கான அறிகுறி.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// வடிவமைப்பு முறைகள் மூலம் திரும்பிய வகை.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// ஒரு செய்தியை ஸ்ட்ரீமில் வடிவமைப்பதில் இருந்து திரும்பும் பிழை வகை.
///
/// பிழை ஏற்பட்டதைத் தவிர வேறு பிழையை பரப்புவதை இந்த வகை ஆதரிக்காது.
/// எந்தவொரு கூடுதல் தகவலும் வேறு சில வழிகளில் அனுப்பப்படுவதற்கு ஏற்பாடு செய்யப்பட வேண்டும்.
///
/// நினைவில் கொள்ள வேண்டிய ஒரு முக்கியமான விஷயம் என்னவென்றால், `fmt::Error` வகை [`std::io::Error`] அல்லது [`std::error::Error`] உடன் குழப்பமடையக்கூடாது, இது உங்களுக்கும் இருக்கலாம்.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// யூனிகோட் ஏற்றுக்கொள்ளும் இடையகங்கள் அல்லது ஸ்ட்ரீம்களில் எழுத அல்லது வடிவமைக்க ஒரு trait.
///
/// இந்த trait UTF-8-குறியிடப்பட்ட தரவை மட்டுமே ஏற்றுக்கொள்கிறது மற்றும் இது [flushable] அல்ல.
/// நீங்கள் யூனிகோடை மட்டுமே ஏற்றுக்கொள்ள விரும்பினால், உங்களுக்கு பறிப்பு தேவையில்லை, நீங்கள் இந்த trait ஐ செயல்படுத்த வேண்டும்;
/// இல்லையெனில் நீங்கள் [`std::io::Write`] ஐ செயல்படுத்த வேண்டும்.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// இந்த எழுத்தாளருக்கு ஒரு சரம் துண்டு எழுதுகிறது, எழுத்து வெற்றி பெற்றதா என்பதைத் தருகிறது.
    ///
    /// முழு சரம் துண்டு வெற்றிகரமாக எழுதப்பட்டிருந்தால் மட்டுமே இந்த முறை வெற்றிபெற முடியும், மேலும் எல்லா தரவும் எழுதப்படும் வரை அல்லது பிழை ஏற்படும் வரை இந்த முறை திரும்பாது.
    ///
    ///
    /// # Errors
    ///
    /// இந்த செயல்பாடு [`Error`] இன் ஒரு உதாரணத்தை பிழையாக வழங்கும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// இந்த எழுத்தாளருக்கு ஒரு [`char`] எழுதுகிறது, எழுத்து வெற்றி பெற்றதா என்பதைத் தருகிறது.
    ///
    /// ஒற்றை [`char`] ஒன்றுக்கு மேற்பட்ட பைட்டுகளாக குறியாக்கம் செய்யப்படலாம்.
    /// முழு பைட் வரிசையும் வெற்றிகரமாக எழுதப்பட்டிருந்தால் மட்டுமே இந்த முறை வெற்றிபெற முடியும், மேலும் எல்லா தரவும் எழுதப்படும் வரை அல்லது பிழை ஏற்படும் வரை இந்த முறை திரும்பாது.
    ///
    ///
    /// # Errors
    ///
    /// இந்த செயல்பாடு [`Error`] இன் ஒரு உதாரணத்தை பிழையாக வழங்கும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// இந்த trait ஐ செயல்படுத்துபவர்களுடன் [`write!`] மேக்ரோவைப் பயன்படுத்துவதற்கான பசை.
    ///
    /// இந்த முறை பொதுவாக கைமுறையாக பயன்படுத்தப்படக்கூடாது, மாறாக [`write!`] மேக்ரோ மூலம் தான்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// வடிவமைப்பதற்கான கட்டமைப்பு.
///
/// ஒரு `Formatter` வடிவமைப்பு தொடர்பான பல்வேறு விருப்பங்களைக் குறிக்கிறது.
/// பயனர்கள் நேரடியாக `வடிவமைப்பாளரை 'உருவாக்கவில்லை;[`Debug`] மற்றும் [`Display`] போன்ற அனைத்து வடிவமைத்தல் traits இன் `fmt` முறைக்கு ஒன்றுக்கு மாற்றக்கூடிய குறிப்பு அனுப்பப்படுகிறது.
///
///
/// ஒரு `Formatter` உடன் தொடர்பு கொள்ள, வடிவமைப்பு தொடர்பான பல்வேறு விருப்பங்களை மாற்ற பல்வேறு முறைகளை நீங்கள் அழைப்பீர்கள்.
/// எடுத்துக்காட்டுகளுக்கு, கீழே உள்ள `Formatter` இல் வரையறுக்கப்பட்ட முறைகளின் ஆவணங்களைப் பார்க்கவும்.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// வாதம் என்பது அடிப்படையில் உகந்ததாக ஓரளவு பயன்படுத்தப்படும் வடிவமைப்பு செயல்பாடு, இது `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` க்கு சமம்.

extern "C" {
    type Opaque;
}

/// இந்த கட்டமைப்பு பொதுவான "argument" ஐ குறிக்கிறது, இது Xprintf குடும்ப செயல்பாடுகளால் எடுக்கப்படுகிறது.கொடுக்கப்பட்ட மதிப்பை வடிவமைக்க இது ஒரு செயல்பாட்டைக் கொண்டுள்ளது.
/// தொகுக்கும் நேரத்தில் செயல்பாடு மற்றும் மதிப்பு சரியான வகைகளைக் கொண்டிருப்பது உறுதி செய்யப்படுகிறது, பின்னர் இந்த கட்டமைப்பு ஒரு வகைக்கு வாதங்களை நியமனம் செய்ய பயன்படுகிறது.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// வடிவமைப்பு உள்கட்டமைப்பில் indices/counts உடன் தொடர்புடைய செயல்பாட்டு சுட்டிக்காட்டிக்கான ஒற்றை நிலையான மதிப்பை இது உறுதி செய்கிறது.
//
// எல்.எல்.வி.எம் ஐ.ஆருக்கு தற்போதைய குறைப்புடன் செயல்பாடுகள் எப்போதும் பெயரிடப்படாத_ஆடிஆர் எனக் குறிக்கப்படுவதால், இது போன்ற ஒரு செயல்பாடு சரியாக இருக்காது என்பதை நினைவில் கொள்க, எனவே அவற்றின் முகவரி எல்.எல்.வி.எம்-க்கு முக்கியமாகக் கருதப்படவில்லை, மேலும் as_usize cast தவறாக தொகுக்கப்பட்டிருக்கலாம்.
//
// நடைமுறையில், பயன்படுத்தப்படாத தரவுகளை நாங்கள் ஒருபோதும் as_usize என்று அழைக்க மாட்டோம் (வடிவமைப்பு வாதங்களின் நிலையான தலைமுறையின் விஷயமாக), எனவே இது ஒரு கூடுதல் சோதனை மட்டுமே.
//
// `USIZE_MARKER` இல் உள்ள செயல்பாட்டு சுட்டிக்காட்டி `&usize` ஐ அவர்களின் முதல் வாதமாக எடுத்துக் கொள்ளும் செயல்பாடுகளுக்கு *மட்டுமே* தொடர்புடைய முகவரியைக் கொண்டிருப்பதை நாங்கள் முதன்மையாக உறுதிப்படுத்த விரும்புகிறோம்.
// அனுப்பப்பட்ட குறிப்பிலிருந்து ஒரு பயன்பாட்டை நாங்கள் பாதுகாப்பாகத் தயாரிக்க முடியும் என்பதையும், இந்த முகவரி பயன்படுத்தப்படாத செயல்பாட்டை சுட்டிக்காட்டுவதில்லை என்பதையும் இங்கே படிக்க_அறிவிப்பு உறுதி செய்கிறது.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // பாதுகாப்பு: ptr என்பது ஒரு குறிப்பு
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // பாதுகாப்பு: ஏனெனில் `mem::transmute(x)` பாதுகாப்பானது
        //     1. `&'b T` இது `'b` உடன் தோன்றிய வாழ்நாளை வைத்திருக்கிறது (இதனால் வரம்பற்ற வாழ்நாள் இல்லை)
        //     2.
        //     `&'b T` மற்றும் `&'b Opaque` க்கு ஒரே மெமரி தளவமைப்பு உள்ளது (`T` `Sized` ஆக இருக்கும்போது, அது இங்கே உள்ளது) `fn(&T, &mut Formatter<'_>) -> Result` பாதுகாப்பானது, ஏனெனில் `fn(&T, &mut Formatter<'_>) -> Result` மற்றும் `fn(&Opaque, &mut Formatter<'_>) -> Result` ஆகியவை ஒரே ABI ஐக் கொண்டுள்ளன (`T` `Sized` இருக்கும் வரை)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // பாதுகாப்பு: `formatter` புலம் USIZE_MARKER என மட்டுமே அமைக்கப்பட்டுள்ளது
            // மதிப்பு ஒரு பயன்பாடு, எனவே இது பாதுகாப்பானது
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// வடிவங்கள்_ஆர்க்ஸின் v1 வடிவத்தில் கொடிகள் கிடைக்கின்றன
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Format_args! () மேக்ரோவைப் பயன்படுத்தும் போது, இந்த செயல்பாடு வாதங்கள் கட்டமைப்பை உருவாக்க பயன்படுகிறது.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// தரமற்ற வடிவமைப்பு அளவுருக்களைக் குறிப்பிட இந்த செயல்பாடு பயன்படுத்தப்படுகிறது.
    /// செல்லுபடியாகும் வாதங்கள் கட்டமைப்பை உருவாக்க `pieces` வரிசை குறைந்தபட்சம் `fmt` வரை இருக்க வேண்டும்.
    /// மேலும், `fmt` க்குள் உள்ள `Count`, `CountIsParam` அல்லது `CountIsNextParam` என்பது `argumentusize` உடன் உருவாக்கப்பட்ட ஒரு வாதத்தை சுட்டிக்காட்ட வேண்டும்.
    ///
    /// இருப்பினும், அவ்வாறு செய்யத் தவறியது பாதுகாப்பற்ற தன்மையை ஏற்படுத்தாது, ஆனால் செல்லாததை புறக்கணிக்கும்.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// வடிவமைக்கப்பட்ட உரையின் நீளத்தை மதிப்பிடுகிறது.
    ///
    /// `format!` ஐப் பயன்படுத்தும் போது ஆரம்ப `String` திறனை அமைப்பதற்கு இது பயன்படுத்தப்பட உள்ளது.
    /// Note: இது கீழ் அல்லது மேல் கட்டுப்பட்டதல்ல.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // வடிவமைப்பு சரம் ஒரு வாதத்துடன் தொடங்குகிறது என்றால், துண்டுகளின் நீளம் குறிப்பிடத்தக்கதாக இல்லாவிட்டால் எதையும் முன்கூட்டியே ஒதுக்க வேண்டாம்.
            //
            //
            0
        } else {
            // சில வாதங்கள் உள்ளன, எனவே எந்த கூடுதல் உந்துதலும் சரத்தை மறு ஒதுக்கீடு செய்யும்.
            //
            // அதைத் தவிர்க்க, நாங்கள் இங்கே "pre-doubling" திறன் கொண்டவர்கள்.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// இந்த அமைப்பு ஒரு வடிவமைப்பு சரத்தின் பாதுகாப்பாக முன் தொகுக்கப்பட்ட பதிப்பையும் அதன் வாதங்களையும் குறிக்கிறது.
/// இயக்க நேரத்தில் இதை உருவாக்க முடியாது, ஏனெனில் இது பாதுகாப்பாக செய்ய முடியாது, எனவே எந்த கட்டமைப்பாளர்களும் வழங்கப்படவில்லை மற்றும் மாற்றங்களைத் தடுக்க புலங்கள் தனிப்பட்டவை.
///
///
/// [`format_args!`] மேக்ரோ இந்த கட்டமைப்பின் ஒரு உதாரணத்தை பாதுகாப்பாக உருவாக்கும்.
/// மேக்ரோ வடிவமைப்பு சரத்தை தொகுக்கும் நேரத்தில் சரிபார்க்கிறது, எனவே [`write()`] மற்றும் [`format()`] செயல்பாடுகளின் பயன்பாடு பாதுகாப்பாக செய்யப்படலாம்.
///
/// `Debug` மற்றும் `Display` சூழல்களில் [`format_args!`] திரும்பும் `Arguments<'a>` ஐ நீங்கள் கீழே காணலாம்.
/// எடுத்துக்காட்டு `Debug` மற்றும் `Display` வடிவமைப்பை ஒரே விஷயமாகக் காட்டுகிறது: `format_args!` இல் உள்ள இடைக்கணிப்பு வடிவமைப்பு சரம்.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // அச்சிட சரம் துண்டுகளை வடிவமைக்கவும்.
    pieces: &'a [&'static str],

    // எல்லா விவரக்குறிப்புகளும் இயல்புநிலையாக இருந்தால் ("{}{}" ஐப் போல) ஒதுக்கிட விவரக்குறிப்புகள் அல்லது `None`.
    fmt: Option<&'a [rt::v1::Argument]>,

    // இடைக்கணிப்புக்கான டைனமிக் வாதங்கள், சரம் துண்டுகளுடன் ஒன்றிணைக்கப்பட வேண்டும்.
    // (ஒவ்வொரு வாதத்திற்கும் முன்னால் ஒரு சரம் துண்டு உள்ளது.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// வடிவமைக்க எந்த வாதங்களும் இல்லாவிட்டால், வடிவமைக்கப்பட்ட சரத்தைப் பெறுங்கள்.
    ///
    /// மிகவும் அற்பமான விஷயத்தில் ஒதுக்கீட்டைத் தவிர்க்க இது பயன்படுத்தப்படலாம்.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` ஒரு புரோகிராமர் எதிர்கொள்ளும், பிழைத்திருத்த சூழலில் வெளியீட்டை வடிவமைக்க வேண்டும்.
///
/// பொதுவாக, நீங்கள் `derive` ஒரு `Debug` செயல்படுத்த வேண்டும்.
///
/// மாற்று வடிவமைப்பு விவரக்குறிப்பு `#?` உடன் பயன்படுத்தும்போது, வெளியீடு அழகாக அச்சிடப்படுகிறது.
///
/// வடிவமைப்பாளர்களைப் பற்றிய கூடுதல் தகவலுக்கு, [the module-level documentation][module] ஐப் பார்க்கவும்.
///
/// [module]: ../../std/fmt/index.html
///
/// எல்லா துறைகளும் `Debug` ஐ செயல்படுத்தினால் இந்த trait ஐ `#[derive]` உடன் பயன்படுத்தலாம்.
/// கட்டமைப்புகளுக்கு `பெறும்போது, அது `struct` இன் பெயரையும், பின்னர் `{` ஐயும், பின்னர் ஒவ்வொரு புலத்தின் பெயரையும் கமாவால் பிரிக்கப்பட்ட பட்டியலையும், `Debug` மதிப்பையும், பின்னர் `}` ஐயும் பயன்படுத்தும்.
/// `Enum` க்காக, இது மாறுபாட்டின் பெயரைப் பயன்படுத்தும், பொருந்தினால், `(`, பின்னர் புலங்களின் `Debug` மதிப்புகள், பின்னர் `)`.
///
/// # Stability
///
/// பெறப்பட்ட `Debug` வடிவங்கள் நிலையானவை அல்ல, எனவே future Rust பதிப்புகளுடன் மாறக்கூடும்.
/// கூடுதலாக, நிலையான நூலகத்தால் வழங்கப்பட்ட வகைகளின் `Debug` செயலாக்கங்கள் (`libstd`, `libcore`, `liballoc`, முதலியன) நிலையானவை அல்ல, மேலும் future Rust பதிப்புகளுடன் மாறக்கூடும்.
///
///
/// # Examples
///
/// செயல்படுத்தல்:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// கைமுறையாக செயல்படுத்துகிறது:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`debug_struct`] போன்ற கையேடு செயலாக்கங்களுக்கு உங்களுக்கு உதவ [`Formatter`] கட்டமைப்பில் பல உதவி முறைகள் உள்ளன.
///
/// `Debug` `derive` அல்லது [`Formatter`] இல் பிழைத்திருத்த பில்டர் API ஐப் பயன்படுத்தி செயல்படுத்தல்கள் மாற்றுக் கொடியைப் பயன்படுத்தி அழகாக அச்சிடுவதை ஆதரிக்கின்றன: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` உடன் அழகான அச்சிடுதல்:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// கொடுக்கப்பட்ட வடிவமைப்பைப் பயன்படுத்தி மதிப்பை வடிவமைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` இல்லாமல் prelude இலிருந்து மேக்ரோ `Debug` ஐ மீண்டும் ஏற்றுமதி செய்ய தனி தொகுதி.
pub(crate) mod macros {
    /// trait `Debug` இன் ஒரு impl ஐ உருவாக்கும் மேக்ரோ.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// வெற்று வடிவத்திற்கு trait ஐ வடிவமைக்கவும், `{}`.
///
/// `Display` [`Debug`] ஐப் போன்றது, ஆனால் `Display` என்பது பயனர் எதிர்கொள்ளும் வெளியீட்டிற்கானது, எனவே அதைப் பெற முடியாது.
///
///
/// வடிவமைப்பாளர்களைப் பற்றிய கூடுதல் தகவலுக்கு, [the module-level documentation][module] ஐப் பார்க்கவும்.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ஒரு வகைக்கு `Display` ஐ செயல்படுத்துகிறது:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// கொடுக்கப்பட்ட வடிவமைப்பைப் பயன்படுத்தி மதிப்பை வடிவமைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait அதன் வெளியீட்டை base-8 இல் ஒரு எண்ணாக வடிவமைக்க வேண்டும்.
///
/// பழமையான கையொப்பமிடப்பட்ட முழு எண்களுக்கு (`i8` முதல் `i128`, மற்றும் `isize`), எதிர்மறை மதிப்புகள் இருவரின் நிரப்பு பிரதிநிதித்துவமாக வடிவமைக்கப்படுகின்றன.
///
///
/// மாற்றுக் கொடி, `#`, வெளியீட்டின் முன் ஒரு `0o` ஐ சேர்க்கிறது.
///
/// வடிவமைப்பாளர்களைப் பற்றிய கூடுதல் தகவலுக்கு, [the module-level documentation][module] ஐப் பார்க்கவும்.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` உடன் அடிப்படை பயன்பாடு:
///
/// ```
/// let x = 42; // 42 ஆக்டலில் '52' ஆகும்
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// ஒரு வகைக்கு `Octal` ஐ செயல்படுத்துகிறது:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 இன் செயல்பாட்டிற்கு பிரதிநிதி
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// கொடுக்கப்பட்ட வடிவமைப்பைப் பயன்படுத்தி மதிப்பை வடிவமைக்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait அதன் வெளியீட்டை பைனரியில் ஒரு எண்ணாக வடிவமைக்க வேண்டும்.
///
/// பழமையான கையொப்பமிடப்பட்ட முழு எண்களுக்கு ([`i8`] முதல் [`i128`], மற்றும் [`isize`]), எதிர்மறை மதிப்புகள் இருவரின் நிரப்பு பிரதிநிதித்துவமாக வடிவமைக்கப்படுகின்றன.
///
///
/// மாற்றுக் கொடி, `#`, வெளியீட்டின் முன் ஒரு `0b` ஐ சேர்க்கிறது.
///
/// வடிவமைப்பாளர்களைப் பற்றிய கூடுதல் தகவலுக்கு, [the module-level documentation][module] ஐப் பார்க்கவும்.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] உடன் அடிப்படை பயன்பாடு:
///
/// ```
/// let x = 42; // 42 என்பது பைனரியில் '101010' ஆகும்
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// ஒரு வகைக்கு `Binary` ஐ செயல்படுத்துகிறது:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 இன் செயல்பாட்டிற்கு பிரதிநிதி
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// கொடுக்கப்பட்ட வடிவமைப்பைப் பயன்படுத்தி மதிப்பை வடிவமைக்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait அதன் வெளியீட்டை ஹெக்ஸாடெசிமலில் ஒரு எண்ணாக வடிவமைக்க வேண்டும், `a` முதல் `f` வழியாக சிறிய வழக்கில்.
///
/// பழமையான கையொப்பமிடப்பட்ட முழு எண்களுக்கு (`i8` முதல் `i128`, மற்றும் `isize`), எதிர்மறை மதிப்புகள் இருவரின் நிரப்பு பிரதிநிதித்துவமாக வடிவமைக்கப்படுகின்றன.
///
///
/// மாற்றுக் கொடி, `#`, வெளியீட்டின் முன் ஒரு `0x` ஐ சேர்க்கிறது.
///
/// வடிவமைப்பாளர்களைப் பற்றிய கூடுதல் தகவலுக்கு, [the module-level documentation][module] ஐப் பார்க்கவும்.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` உடன் அடிப்படை பயன்பாடு:
///
/// ```
/// let x = 42; // 42 என்பது ஹெக்ஸில் '2a' ஆகும்
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// ஒரு வகைக்கு `LowerHex` ஐ செயல்படுத்துகிறது:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 இன் செயல்பாட்டிற்கு பிரதிநிதி
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// கொடுக்கப்பட்ட வடிவமைப்பைப் பயன்படுத்தி மதிப்பை வடிவமைக்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait அதன் வெளியீட்டை ஹெக்ஸாடெசிமலில் ஒரு எண்ணாக வடிவமைக்க வேண்டும், `A` முதல் `F` வழியாக மேல் வழக்கில்.
///
/// பழமையான கையொப்பமிடப்பட்ட முழு எண்களுக்கு (`i8` முதல் `i128`, மற்றும் `isize`), எதிர்மறை மதிப்புகள் இருவரின் நிரப்பு பிரதிநிதித்துவமாக வடிவமைக்கப்படுகின்றன.
///
///
/// மாற்றுக் கொடி, `#`, வெளியீட்டின் முன் ஒரு `0x` ஐ சேர்க்கிறது.
///
/// வடிவமைப்பாளர்களைப் பற்றிய கூடுதல் தகவலுக்கு, [the module-level documentation][module] ஐப் பார்க்கவும்.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` உடன் அடிப்படை பயன்பாடு:
///
/// ```
/// let x = 42; // 42 என்பது ஹெக்ஸில் '2A' ஆகும்
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// ஒரு வகைக்கு `UpperHex` ஐ செயல்படுத்துகிறது:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 இன் செயல்பாட்டிற்கு பிரதிநிதி
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// கொடுக்கப்பட்ட வடிவமைப்பைப் பயன்படுத்தி மதிப்பை வடிவமைக்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait அதன் வெளியீட்டை நினைவக இடமாக வடிவமைக்க வேண்டும்.
/// இது பொதுவாக ஹெக்ஸாடெசிமல் என வழங்கப்படுகிறது.
///
/// வடிவமைப்பாளர்களைப் பற்றிய கூடுதல் தகவலுக்கு, [the module-level documentation][module] ஐப் பார்க்கவும்.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` உடன் அடிப்படை பயன்பாடு:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // இது '0x7f06092ac6d0' போன்ற ஒன்றை உருவாக்குகிறது
/// ```
///
/// ஒரு வகைக்கு `Pointer` ஐ செயல்படுத்துகிறது:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // ஒரு `*const T` க்கு மாற்ற `as` ஐப் பயன்படுத்தவும், இது சுட்டிக்காட்டி செயல்படுத்துகிறது, அதை நாம் பயன்படுத்தலாம்
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// கொடுக்கப்பட்ட வடிவமைப்பைப் பயன்படுத்தி மதிப்பை வடிவமைக்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait அதன் வெளியீட்டை விஞ்ஞான குறியீட்டில் சிறிய வழக்கு `e` உடன் வடிவமைக்க வேண்டும்.
///
/// வடிவமைப்பாளர்களைப் பற்றிய கூடுதல் தகவலுக்கு, [the module-level documentation][module] ஐப் பார்க்கவும்.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` உடன் அடிப்படை பயன்பாடு:
///
/// ```
/// let x = 42.0; // 42.0 விஞ்ஞான குறியீட்டில் '4.2e1' ஆகும்
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// ஒரு வகைக்கு `LowerExp` ஐ செயல்படுத்துகிறது:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 இன் செயல்படுத்தலுக்கு பிரதிநிதி
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// கொடுக்கப்பட்ட வடிவமைப்பைப் பயன்படுத்தி மதிப்பை வடிவமைக்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait அதன் வெளியீட்டை விஞ்ஞான குறியீட்டில் ஒரு மேல்-வழக்கு `E` உடன் வடிவமைக்க வேண்டும்.
///
/// வடிவமைப்பாளர்களைப் பற்றிய கூடுதல் தகவலுக்கு, [the module-level documentation][module] ஐப் பார்க்கவும்.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` உடன் அடிப்படை பயன்பாடு:
///
/// ```
/// let x = 42.0; // 42.0 விஞ்ஞான குறியீட்டில் '4.2E1' ஆகும்
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// ஒரு வகைக்கு `UpperExp` ஐ செயல்படுத்துகிறது:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 இன் செயல்படுத்தலுக்கு பிரதிநிதி
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// கொடுக்கப்பட்ட வடிவமைப்பைப் பயன்படுத்தி மதிப்பை வடிவமைக்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` செயல்பாடு ஒரு வெளியீட்டு ஸ்ட்ரீமை எடுக்கும், மேலும் `format_args!` மேக்ரோவுடன் முன்பே தொகுக்கக்கூடிய ஒரு `Arguments` கட்டமைப்பு.
///
///
/// வழங்கப்பட்ட வெளியீட்டு நீரோட்டத்தில் குறிப்பிட்ட வடிவமைப்பு சரத்தின் படி வாதங்கள் வடிவமைக்கப்படும்.
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// [`write!`] ஐப் பயன்படுத்துவது விரும்பத்தக்கது என்பதை நினைவில் கொள்க.உதாரணமாக:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // எல்லா வாதங்களுக்கும் இயல்புநிலை வடிவமைப்பு அளவுருக்களைப் பயன்படுத்தலாம்.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // ஒவ்வொரு விவரக்குறிப்பிலும் ஒரு சரம் துண்டுக்கு முன்னால் தொடர்புடைய வாதம் உள்ளது.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // பாதுகாப்பு: ஆர்க் மற்றும் எக்ஸ் 100 எக்ஸ் ஆகியவை ஒரே வாதங்களிலிருந்து வந்தவை,
                // இது குறியீடுகள் எப்போதும் எல்லைக்குள் இருப்பதை உறுதி செய்கிறது.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // ஒரே ஒரு சரம் துண்டு மட்டுமே மீதமுள்ளது.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // பாதுகாப்பு: ஆர்க் மற்றும் ஆர்க்ஸ் ஒரே வாதங்களிலிருந்து வந்தவை,
    // இது குறியீடுகள் எப்போதும் எல்லைக்குள் இருப்பதை உறுதி செய்கிறது.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // சரியான வாதத்தை பிரித்தெடுக்கவும்
    debug_assert!(arg.position < args.len());
    // பாதுகாப்பு: ஆர்க் மற்றும் ஆர்க்ஸ் ஒரே வாதங்களிலிருந்து வந்தவை,
    // அதன் குறியீட்டு எப்போதும் எல்லைக்குள் இருப்பதை உறுதி செய்கிறது.
    let value = unsafe { args.get_unchecked(arg.position) };

    // பின்னர் உண்மையில் சில அச்சிடுதல் செய்யுங்கள்
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // பாதுகாப்பு: cnt மற்றும் args ஒரே வாதங்களிலிருந்து வந்தவை,
            // இந்த குறியீடு எப்போதும் எல்லைக்குள் இருப்பதை உறுதி செய்கிறது.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// ஏதாவது முடிந்த பிறகு திணிப்பு.`Formatter::padding` ஆல் வழங்கப்பட்டது.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// இந்த இடுகை திணிப்பை எழுதுங்கள்.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // இதை மாற்ற விரும்புகிறோம்
            buf: wrap(self.buf),

            // இவற்றைப் பாதுகாக்கவும்
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // அனைத்து வடிவமைப்பு traits பயன்படுத்தக்கூடிய வடிவமைத்தல் வாதங்களை திணிப்பு மற்றும் செயலாக்க உதவும் உதவி முறைகள்.
    //

    /// ஏற்கனவே ஒரு str இல் வெளியேற்றப்பட்ட ஒரு முழு எண்ணிற்கான சரியான திணிப்பை செய்கிறது.
    /// இந்த முறை மூலம் சேர்க்கப்படும் முழு எண்ணிற்கான அடையாளத்தை str கொண்டிருக்கக்கூடாது.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, அசல் முழு எண் நேர்மறை அல்லது பூஜ்ஜியமா என்பது.
    /// * முன்னொட்டு, '#' எழுத்து (Alternate) வழங்கப்பட்டால், இது எண்ணின் முன் வைக்க வேண்டிய முன்னொட்டு.
    ///
    /// * buf, எண் வடிவமைக்கப்பட்ட பைட் வரிசை
    ///
    /// இந்த செயல்பாடு வழங்கப்பட்ட கொடிகளுக்கும் குறைந்தபட்ச அகலத்திற்கும் சரியாக கணக்கிடப்படும்.
    /// இது துல்லியமாக கணக்கில் எடுத்துக்கொள்ளாது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // எண் வெளியீட்டிலிருந்து "-" ஐ அகற்ற வேண்டும்.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // அடையாளம் இருந்தால் அடையாளம் எழுதுகிறது, பின்னர் அது கோரப்பட்டால் முன்னொட்டு
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // இந்த கட்டத்தில் `width` புலம் ஒரு `min-width` அளவுருவாகும்.
        match self.width {
            // குறைந்தபட்ச நீளத் தேவைகள் எதுவும் இல்லை என்றால், நாம் பைட்டுகளை எழுதலாம்.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // நாங்கள் குறைந்தபட்ச அகலத்திற்கு மேல் இருக்கிறோமா என்று சரிபார்க்கவும், அப்படியானால் பைட்டுகளையும் எழுதலாம்.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // நிரப்பு எழுத்து பூஜ்ஜியமாக இருந்தால் அடையாளம் மற்றும் முன்னொட்டு திணிப்புக்கு முன் செல்கிறது
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // இல்லையெனில், அடையாளம் மற்றும் முன்னொட்டு திணிப்புக்குப் பின் செல்கிறது
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// இந்த செயல்பாடு ஒரு சரம் துண்டு எடுத்து குறிப்பிட்ட தொடர்புடைய வடிவமைப்புக் கொடிகளைப் பயன்படுத்திய பின் உள் இடையகத்திற்கு வெளியிடுகிறது.
    /// பொதுவான சரங்களுக்கு அங்கீகரிக்கப்பட்ட கொடிகள்:
    ///
    /// * அகலம், எதை வெளியேற்ற வேண்டும் என்பதற்கான குறைந்தபட்ச அகலம்
    /// * fill/align - வழங்கப்பட்ட சரம் திணிக்கப்பட வேண்டும் என்றால் எதை வெளியேற்றுவது மற்றும் எங்கு வெளியேற்றுவது
    /// * துல்லியம், உமிழும் அதிகபட்ச நீளம், இந்த நீளத்தை விட நீளமாக இருந்தால் சரம் துண்டிக்கப்படுகிறது
    ///
    /// இந்த செயல்பாடு `flag` அளவுருக்களை புறக்கணிக்கிறது என்பது குறிப்பிடத்தக்கது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // முன்னால் ஒரு விரைவான பாதை இருப்பதை உறுதிசெய்க
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // சரம் வடிவமைக்கப்படுவதற்கு `precision` புலம் ஒரு `max-width` என விளக்கப்படுகிறது.
        //
        let s = if let Some(max) = self.precision {
            // எங்கள் சரம் துல்லியமாக இருப்பதை விட நீளமாக இருந்தால், நாம் துண்டிக்கப்பட வேண்டும்.
            // இருப்பினும் `fill`, `width` மற்றும் `align` போன்ற பிற கொடிகள் எப்போதும் செயல்பட வேண்டும்.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // இங்கே எல்.எல்.வி.எம் `..i` panic `&s[..i]` ஆகாது என்பதை நிரூபிக்க முடியாது, ஆனால் அது panic முடியாது என்பதை நாங்கள் அறிவோம்.
                // `unsafe` ஐத் தவிர்க்க `get` + `unwrap_or` ஐப் பயன்படுத்தவும், இல்லையெனில் panic தொடர்பான எந்த குறியீட்டையும் இங்கே வெளியிட வேண்டாம்.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // இந்த கட்டத்தில் `width` புலம் ஒரு `min-width` அளவுருவாகும்.
        match self.width {
            // நாங்கள் அதிகபட்ச நீளத்தின் கீழ் இருந்தால், குறைந்தபட்ச நீளத் தேவைகள் எதுவும் இல்லை என்றால், நாம் சரத்தை வெளியேற்றலாம்
            //
            None => self.buf.write_str(s),
            // நாங்கள் அதிகபட்ச அகலத்தின் கீழ் இருந்தால், நாங்கள் குறைந்தபட்ச அகலத்திற்கு மேல் இருக்கிறோமா என்று சரிபார்க்கவும், அப்படியானால் அது சரத்தை வெளியிடுவது போல எளிதானது.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // நாங்கள் அதிகபட்சம் மற்றும் குறைந்தபட்ச அகலம் இரண்டிற்கும் கீழ் இருந்தால், குறிப்பிட்ட சரம் + சில சீரமைப்புடன் குறைந்தபட்ச அகலத்தை நிரப்பவும்.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// முன் திணிப்பை எழுதி, எழுதப்படாத பிந்தைய திணிப்பைத் திருப்பித் தரவும்.
    /// திணிக்கப்பட்ட விஷயத்திற்குப் பிறகு எழுதப்பட்ட பிந்தைய திணிப்பு உறுதி செய்ய அழைப்பாளர்கள் பொறுப்பு.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// வடிவமைக்கப்பட்ட பகுதிகளை எடுத்து திணிப்பு பொருந்தும்.
    /// அழைப்பாளர் ஏற்கனவே தேவையான துல்லியத்துடன் பகுதிகளை வழங்கியிருப்பதாகக் கருதுகிறது, இதனால் `self.precision` புறக்கணிக்கப்படும்.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // அடையாளம்-விழிப்புணர்வு பூஜ்ஜிய திணிப்புக்கு, நாங்கள் முதலில் அடையாளத்தை வழங்குகிறோம், ஆரம்பத்தில் இருந்தே எந்த அடையாளமும் இல்லை என்பது போல் நடந்து கொள்கிறோம்.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ஒரு அடையாளம் எப்போதும் முதலில் செல்லும்
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // வடிவமைக்கப்பட்ட பகுதிகளிலிருந்து அடையாளத்தை அகற்றவும்
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // மீதமுள்ள பாகங்கள் சாதாரண திணிப்பு செயல்முறை வழியாக செல்கின்றன.
            let len = formatted.len();
            let ret = if width <= len {
                // திணிப்பு இல்லை
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // இது பொதுவான வழக்கு, நாங்கள் குறுக்குவழியை எடுத்துக்கொள்கிறோம்
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // பாதுகாப்பு: இது `flt2dec::Part::Num` மற்றும் `flt2dec::Part::Copy` க்கு பயன்படுத்தப்படுகிறது.
            // ஒவ்வொரு கரி `c` `b'0'` மற்றும் `b'9'` க்கு இடையில் இருப்பதால் `flt2dec::Part::Num` ஐப் பயன்படுத்துவது பாதுகாப்பானது, அதாவது `s` செல்லுபடியாகும் UTF-8 ஆகும்.
            // `buf` வெற்று ASCII ஆக இருக்க வேண்டும் என்பதால் இது `flt2dec::Part::Copy(buf)` ஐப் பயன்படுத்துவது நடைமுறையில் பாதுகாப்பானது, ஆனால் `buf` க்கு `flt2dec::to_shortest_str` க்கு மோசமான மதிப்பில் யாராவது கடந்து செல்ல முடியும், ஏனெனில் இது ஒரு பொது செயல்பாடு.
            //
            // FIXME: இது யு.பியில் ஏற்படுமா என்பதைத் தீர்மானிக்கவும்.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 பூஜ்ஜியங்கள்
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// இந்த வடிவமைப்பில் உள்ள அடிப்படை இடையகத்திற்கு சில தரவை எழுதுகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // இது இதற்கு சமம்:
    ///         // எழுது! (வடிவமைப்பாளர், "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// வடிவமைக்கப்பட்ட சில தகவல்களை இந்த நிகழ்வில் எழுதுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// வடிவமைப்பதற்கான கொடிகள்
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// சீரமைப்பு இருக்கும் போதெல்லாம் 'fill' ஆக பயன்படுத்தப்படும் எழுத்து.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // ">" உடன் வலதுபுறத்தில் சீரமைப்பை அமைத்துள்ளோம்.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// எந்த வகையான சீரமைப்பு கோரப்பட்டது என்பதைக் குறிக்கும் கொடி.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// வெளியீடு இருக்க வேண்டும் என்று விருப்பமாக குறிப்பிடப்பட்ட முழு அகலம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // நாங்கள் ஒரு அகலத்தைப் பெற்றிருந்தால், அதைப் பயன்படுத்துகிறோம்
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // இல்லையெனில் நாங்கள் சிறப்பு எதுவும் செய்ய மாட்டோம்
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// எண் வகைகளுக்கு விருப்பமாக குறிப்பிடப்பட்ட துல்லியம்.
    /// மாற்றாக, சரம் வகைகளுக்கான அதிகபட்ச அகலம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // நாங்கள் ஒரு துல்லியத்தைப் பெற்றிருந்தால், அதைப் பயன்படுத்துகிறோம்.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // இல்லையெனில் நாம் இயல்புநிலையாக 2 ஆக இருக்கிறோம்.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` கொடி குறிப்பிடப்பட்டதா என்பதை தீர்மானிக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` கொடி குறிப்பிடப்பட்டதா என்பதை தீர்மானிக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // கழித்தல் அடையாளம் வேண்டுமா?ஒன்று எடுத்துக்கொள்!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` கொடி குறிப்பிடப்பட்டதா என்பதை தீர்மானிக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` கொடி குறிப்பிடப்பட்டதா என்பதை தீர்மானிக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // வடிவமைப்பாளரின் விருப்பங்களை நாங்கள் புறக்கணிக்கிறோம்.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: இந்த இரண்டு கொடிகளுக்கும் நாங்கள் விரும்பும் பொது API ஐத் தீர்மானியுங்கள்.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// கட்டமைப்புகளுக்கான [`fmt::Debug`] செயலாக்கங்களை உருவாக்க உதவ வடிவமைக்கப்பட்ட [`DebugStruct`] பில்டரை உருவாக்குகிறது.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// டூப்பிள் கட்டமைப்புகளுக்கான `fmt::Debug` செயலாக்கங்களை உருவாக்க உதவ வடிவமைக்கப்பட்ட `DebugTuple` பில்டரை உருவாக்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// பட்டியல் போன்ற கட்டமைப்புகளுக்கான `fmt::Debug` செயலாக்கங்களை உருவாக்க உதவ வடிவமைக்கப்பட்ட `DebugList` பில்டரை உருவாக்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// செட் போன்ற கட்டமைப்புகளுக்கு `fmt::Debug` செயலாக்கங்களை உருவாக்க உதவ வடிவமைக்கப்பட்ட `DebugSet` பில்டரை உருவாக்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// இந்த மிகவும் சிக்கலான எடுத்துக்காட்டில், பொருத்த ஆயுதங்களின் பட்டியலை உருவாக்க [`format_args!`] மற்றும் `.debug_set()` ஐப் பயன்படுத்துகிறோம்:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// வரைபடம் போன்ற கட்டமைப்புகளுக்கான `fmt::Debug` செயலாக்கங்களை உருவாக்க உதவ வடிவமைக்கப்பட்ட `DebugMap` பில்டரை உருவாக்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// முக்கிய வடிவமைப்பின் செயல்பாடுகள் traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // கரி தப்பிக்க வேண்டும் என்றால், இதுவரை பேக்லாக் பறித்துவிட்டு எழுதுங்கள், இல்லையெனில் தவிர்க்கவும்
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // மாற்றுக் கொடி ஏற்கனவே லோயர்ஹெக்ஸால் சிறப்புடையதாகக் கருதப்படுகிறது-இது 0x உடன் முன்னொட்டு வேண்டுமா என்பதைக் குறிக்கிறது.
        // பூஜ்ஜிய நீட்டிப்பு வேண்டுமா இல்லையா என்பதைப் புரிந்துகொள்வதற்கு இதைப் பயன்படுத்துகிறோம், பின்னர் முன்னொட்டைப் பெற நிபந்தனையின்றி அதை அமைக்கிறோம்.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// பல்வேறு முக்கிய வகைகளுக்கு Display/Debug ஐ செயல்படுத்துதல்

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell மாற்றத்தக்க வகையில் கடன் வாங்கப்பட்டுள்ளது, எனவே அதன் மதிப்பை இங்கே பார்க்க முடியாது.
                // அதற்கு பதிலாக ஒரு ஒதுக்கிடத்தைக் காட்டு.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// சோதனைகள் இங்கே இருக்கும் என்று நீங்கள் எதிர்பார்த்திருந்தால், அதற்கு பதிலாக core/tests/fmt.rs கோப்பைப் பாருங்கள், இங்கே எல்லா rt::Piece கட்டமைப்புகளையும் உருவாக்குவதை விட இது மிகவும் எளிதானது.
//
// ஒதுக்கீடு தேவைப்படுபவர்களுக்கு, crate ஒதுக்கீட்டில் சோதனைகள் உள்ளன.