use crate::fmt::{Debug, Display, Formatter, LowerExp, Result, UpperExp};
use crate::mem::MaybeUninit;
use crate::num::flt2dec;

// இதை இன்லைன் செய்யாதீர்கள், எனவே அழைப்பாளர்கள் இந்த செயல்பாடு தேவைப்படும் ஸ்டேக் இடத்தைப் பயன்படுத்த வேண்டாம்.
//
#[inline(never)]
fn float_to_decimal_common_exact<T>(
    fmt: &mut Formatter<'_>,
    num: &T,
    sign: flt2dec::Sign,
    precision: usize,
) -> Result
where
    T: flt2dec::DecodableFloat,
{
    let mut buf: [MaybeUninit<u8>; 1024] = MaybeUninit::uninit_array(); // f32 மற்றும் f64 க்கு போதுமானது
    let mut parts: [MaybeUninit<flt2dec::Part<'_>>; 4] = MaybeUninit::uninit_array();
    let formatted = flt2dec::to_exact_fixed_str(
        flt2dec::strategy::grisu::format_exact,
        *num,
        sign,
        precision,
        &mut buf,
        &mut parts,
    );
    fmt.pad_formatted_parts(&formatted)
}

// இதை இன்லைன் செய்யாதீர்கள், எனவே இது மற்றும் மேலே உள்ள இரண்டையும் அழைக்கும் அழைப்பாளர்கள் சில சந்தர்ப்பங்களில் இரு செயல்பாடுகளின் ஒருங்கிணைந்த அடுக்கு இடத்தைப் பயன்படுத்தி முறுக்க மாட்டார்கள்.
//
#[inline(never)]
fn float_to_decimal_common_shortest<T>(
    fmt: &mut Formatter<'_>,
    num: &T,
    sign: flt2dec::Sign,
    precision: usize,
) -> Result
where
    T: flt2dec::DecodableFloat,
{
    // f32 மற்றும் f64 க்கு போதுமானது
    let mut buf: [MaybeUninit<u8>; flt2dec::MAX_SIG_DIGITS] = MaybeUninit::uninit_array();
    let mut parts: [MaybeUninit<flt2dec::Part<'_>>; 4] = MaybeUninit::uninit_array();
    let formatted = flt2dec::to_shortest_str(
        flt2dec::strategy::grisu::format_shortest,
        *num,
        sign,
        precision,
        &mut buf,
        &mut parts,
    );
    fmt.pad_formatted_parts(&formatted)
}

// மிதக்கும் புள்ளியின் பொதுவான குறியீடு பிழைத்திருத்தம் மற்றும் காட்சி.
fn float_to_decimal_common<T>(
    fmt: &mut Formatter<'_>,
    num: &T,
    negative_zero: bool,
    min_precision: usize,
) -> Result
where
    T: flt2dec::DecodableFloat,
{
    let force_sign = fmt.sign_plus();
    let sign = match (force_sign, negative_zero) {
        (false, false) => flt2dec::Sign::Minus,
        (false, true) => flt2dec::Sign::MinusRaw,
        (true, false) => flt2dec::Sign::MinusPlus,
        (true, true) => flt2dec::Sign::MinusPlusRaw,
    };

    if let Some(precision) = fmt.precision {
        float_to_decimal_common_exact(fmt, num, sign, precision)
    } else {
        float_to_decimal_common_shortest(fmt, num, sign, min_precision)
    }
}

// இதை இன்லைன் செய்யாதீர்கள், எனவே அழைப்பாளர்கள் இந்த செயல்பாடு தேவைப்படும் ஸ்டேக் இடத்தைப் பயன்படுத்த வேண்டாம்.
//
#[inline(never)]
fn float_to_exponential_common_exact<T>(
    fmt: &mut Formatter<'_>,
    num: &T,
    sign: flt2dec::Sign,
    precision: usize,
    upper: bool,
) -> Result
where
    T: flt2dec::DecodableFloat,
{
    let mut buf: [MaybeUninit<u8>; 1024] = MaybeUninit::uninit_array(); // f32 மற்றும் f64 க்கு போதுமானது
    let mut parts: [MaybeUninit<flt2dec::Part<'_>>; 6] = MaybeUninit::uninit_array();
    let formatted = flt2dec::to_exact_exp_str(
        flt2dec::strategy::grisu::format_exact,
        *num,
        sign,
        precision,
        upper,
        &mut buf,
        &mut parts,
    );
    fmt.pad_formatted_parts(&formatted)
}

// இதை இன்லைன் செய்யாதீர்கள், எனவே இது மற்றும் மேலே உள்ள இரண்டையும் அழைக்கும் அழைப்பாளர்கள் சில சந்தர்ப்பங்களில் இரு செயல்பாடுகளின் ஒருங்கிணைந்த அடுக்கு இடத்தைப் பயன்படுத்தி முறுக்க மாட்டார்கள்.
//
#[inline(never)]
fn float_to_exponential_common_shortest<T>(
    fmt: &mut Formatter<'_>,
    num: &T,
    sign: flt2dec::Sign,
    upper: bool,
) -> Result
where
    T: flt2dec::DecodableFloat,
{
    // f32 மற்றும் f64 க்கு போதுமானது
    let mut buf: [MaybeUninit<u8>; flt2dec::MAX_SIG_DIGITS] = MaybeUninit::uninit_array();
    let mut parts: [MaybeUninit<flt2dec::Part<'_>>; 6] = MaybeUninit::uninit_array();
    let formatted = flt2dec::to_shortest_exp_str(
        flt2dec::strategy::grisu::format_shortest,
        *num,
        sign,
        (0, 0),
        upper,
        &mut buf,
        &mut parts,
    );
    fmt.pad_formatted_parts(&formatted)
}

// மிதக்கும் புள்ளியின் பொதுவான குறியீடு லோயர் எக்ஸ்ப் மற்றும் அப்பர் எக்ஸ்ப்.
fn float_to_exponential_common<T>(fmt: &mut Formatter<'_>, num: &T, upper: bool) -> Result
where
    T: flt2dec::DecodableFloat,
{
    let force_sign = fmt.sign_plus();
    let sign = match force_sign {
        false => flt2dec::Sign::Minus,
        true => flt2dec::Sign::MinusPlus,
    };

    if let Some(precision) = fmt.precision {
        // 1 ஒருங்கிணைந்த இலக்கம் + `precision` பின்னம் இலக்கங்கள்= `precision + 1` மொத்த இலக்கங்கள்
        float_to_exponential_common_exact(fmt, num, sign, precision + 1, upper)
    } else {
        float_to_exponential_common_shortest(fmt, num, sign, upper)
    }
}

macro_rules! floating {
    ($ty:ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Debug for $ty {
            fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
                float_to_decimal_common(fmt, self, true, 1)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Display for $ty {
            fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
                float_to_decimal_common(fmt, self, false, 0)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl LowerExp for $ty {
            fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
                float_to_exponential_common(fmt, self, false)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl UpperExp for $ty {
            fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
                float_to_exponential_common(fmt, self, true)
            }
        }
    };
}

floating! { f32 }
floating! { f64 }