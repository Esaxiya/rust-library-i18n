//! இது ifmt பயன்படுத்தும் உள் தொகுதி!இயக்க நேரம்.இந்த கட்டமைப்புகள் நிலையான வரிசைகளுக்கு நேரத்திற்கு முன்னதாக வடிவமைப்பு சரங்களை முன்கூட்டியே தொகுக்கின்றன.
//!
//! இந்த வரையறைகள் அவற்றின் `ct` சமமானவைகளுக்கு ஒத்தவை, ஆனால் இவை நிலையான முறையில் ஒதுக்கப்படலாம் மற்றும் இயக்க நேரத்திற்கு சற்று உகந்ததாக இருக்கும் என்பதில் வேறுபடுகின்றன
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// வடிவமைப்பு உத்தரவின் ஒரு பகுதியாக கோரக்கூடிய சாத்தியமான சீரமைப்புகள்.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// உள்ளடக்கங்களை இடது-சீரமைக்க வேண்டும் என்பதற்கான அறிகுறி.
    Left,
    /// உள்ளடக்கங்கள் சரியாக சீரமைக்கப்பட வேண்டும் என்பதற்கான அறிகுறி.
    Right,
    /// உள்ளடக்கங்கள் மையமாக சீரமைக்கப்பட வேண்டும் என்பதற்கான அறிகுறி.
    Center,
    /// எந்த சீரமைப்பு கோரப்படவில்லை.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) மற்றும் [precision](https://doc.rust-lang.org/std/fmt/#precision) குறிப்பான்களால் பயன்படுத்தப்படுகிறது.
#[derive(Copy, Clone)]
pub enum Count {
    /// ஒரு நேரடி எண்ணுடன் குறிப்பிடப்பட்டுள்ளது, மதிப்பை சேமிக்கிறது
    Is(usize),
    /// `$` மற்றும் `*` தொடரியல் பயன்படுத்தி குறிப்பிடப்பட்டுள்ளது, குறியீட்டை `args` இல் சேமிக்கிறது
    Param(usize),
    /// குறிப்பிடப்படவில்லை
    Implied,
}