//! இந்த தொகுதி `Any` trait ஐ செயல்படுத்துகிறது, இது இயக்க நேர பிரதிபலிப்பு மூலம் எந்த `'static` வகையையும் மாறும் தட்டச்சு செய்ய உதவுகிறது.
//!
//! `Any` ஒரு `TypeId` ஐப் பெற தன்னைப் பயன்படுத்தலாம், மேலும் trait பொருளாகப் பயன்படுத்தும்போது கூடுதல் அம்சங்களைக் கொண்டுள்ளது.
//! `&dyn Any` (கடன் வாங்கிய trait பொருள்) என, இது `is` மற்றும் `downcast_ref` முறைகளைக் கொண்டுள்ளது, இதில் உள்ள மதிப்பு கொடுக்கப்பட்ட வகையா என்பதை சோதிக்கவும், உள் மதிப்பை ஒரு வகையாகப் பார்க்கவும்.
//! `&mut dyn Any` ஆக, உள் மதிப்புக்கு மாற்றத்தக்க குறிப்பைப் பெறுவதற்கு `downcast_mut` முறையும் உள்ளது.
//! `Box<dyn Any>` `downcast` முறையைச் சேர்க்கிறது, இது `Box<T>` ஆக மாற்ற முயற்சிக்கிறது.
//! முழு விவரங்களுக்கு [`Box`] ஆவணங்களைப் பார்க்கவும்.
//!
//! ஒரு மதிப்பு ஒரு குறிப்பிட்ட கான்கிரீட் வகையா என்பதை சோதிக்க `&dyn Any` வரையறுக்கப்பட்டுள்ளது என்பதை நினைவில் கொள்க, மேலும் ஒரு வகை trait ஐ செயல்படுத்துகிறதா என்பதை சோதிக்க பயன்படுத்த முடியாது.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # ஸ்மார்ட் சுட்டிகள் மற்றும் `dyn Any`
//!
//! `Any` ஐ trait பொருளாகப் பயன்படுத்தும் போது மனதில் கொள்ள வேண்டிய ஒரு நடத்தை, குறிப்பாக `Box<dyn Any>` அல்லது `Arc<dyn Any>` போன்ற வகைகளுடன், மதிப்பில் `.type_id()` ஐ அழைப்பது வெறுமனே * கொள்கலனின் `TypeId` ஐ உருவாக்கும், ஆனால் அடிப்படை trait பொருள் அல்ல.
//!
//! ஸ்மார்ட் சுட்டிக்காட்டிக்கு பதிலாக `&dyn Any` ஆக மாற்றுவதன் மூலம் இதைத் தவிர்க்கலாம், இது பொருளின் `TypeId` ஐ வழங்கும்.
//! உதாரணத்திற்கு:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // நீங்கள் இதை விரும்புவதற்கான வாய்ப்புகள் அதிகம்:
//! let actual_id = (&*boxed).type_id();
//! // ... இதை விட:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! ஒரு செயல்பாட்டிற்கு அனுப்பப்பட்ட மதிப்பை வெளியேற்ற விரும்பும் சூழ்நிலையைக் கவனியுங்கள்.
//! பிழைத்திருத்தத்தை செயல்படுத்துவதில் நாங்கள் பணிபுரியும் மதிப்பு எங்களுக்குத் தெரியும், ஆனால் அதன் உறுதியான வகை எங்களுக்குத் தெரியாது.சில வகைகளுக்கு சிறப்பு சிகிச்சையை வழங்க விரும்புகிறோம்: இந்த விஷயத்தில் சரம் மதிப்புகளின் நீளத்தை அவற்றின் மதிப்புக்கு முன் அச்சிடுகிறது.
//! தொகுக்கும் நேரத்தில் எங்கள் மதிப்பின் உறுதியான வகை எங்களுக்குத் தெரியாது, எனவே அதற்கு பதிலாக இயக்க நேர பிரதிபலிப்பைப் பயன்படுத்த வேண்டும்.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // பிழைத்திருத்தத்தை செயல்படுத்தும் எந்த வகைக்கும் லாகர் செயல்பாடு.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // எங்கள் மதிப்பை `String` ஆக மாற்ற முயற்சிக்கவும்.
//!     // வெற்றிகரமாக இருந்தால், சரத்தின் நீளத்தையும் அதன் மதிப்பையும் வெளியிட விரும்புகிறோம்.
//!     // இல்லையென்றால், இது வேறு வகை: அலங்காரமில்லாமல் அச்சிடுங்கள்.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // இந்த செயல்பாடு அதன் அளவுருவை அதனுடன் வேலை செய்வதற்கு முன்பு வெளியேற்ற விரும்புகிறது.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... வேறு ஏதாவது வேலை செய்யுங்கள்
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// எந்த trait
///////////////////////////////////////////////////////////////////////////////

/// டைனமிக் தட்டச்சு பின்பற்ற ஒரு trait.
///
/// பெரும்பாலான வகைகள் `Any` ஐ செயல்படுத்துகின்றன.இருப்பினும், `ஸ்டேடிக்` குறிப்பு இல்லாத எந்த வகையிலும் இல்லை.
/// மேலும் விவரங்களுக்கு [module-level documentation][mod] ஐப் பார்க்கவும்.
///
/// [mod]: crate::any
// இந்த trait பாதுகாப்பற்றது அல்ல, இருப்பினும் பாதுகாப்பற்ற குறியீட்டில் (எ.கா., `downcast`) அதன் ஒரே impl இன் `type_id` செயல்பாட்டின் பிரத்தியேகங்களை நாங்கள் நம்பியுள்ளோம்.பொதுவாக, இது ஒரு சிக்கலாக இருக்கும், ஆனால் `Any` இன் ஒரே தூண்டுதல் ஒரு போர்வை செயல்படுத்தல் என்பதால், வேறு எந்த குறியீடும் `Any` ஐ செயல்படுத்த முடியாது.
//
// இந்த trait ஐ நாம் பாதுகாப்பற்றதாக மாற்ற முடியும்-இது அனைத்து செயலாக்கங்களையும் நாங்கள் கட்டுப்படுத்துவதால், அது உடைப்பை ஏற்படுத்தாது-ஆனால் இவை இரண்டும் உண்மையில் தேவையில்லை என்பதால் நாங்கள் தேர்வுசெய்கிறோம் மற்றும் பாதுகாப்பற்ற traits மற்றும் பாதுகாப்பற்ற முறைகள் (அதாவது, `type_id` ஐ அழைப்பது இன்னும் பாதுகாப்பாக இருக்கும், ஆனால் ஆவணங்களில் இதுபோன்று குறிப்பிட விரும்புகிறோம்).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` இன் `TypeId` ஐப் பெறுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// எந்த trait பொருள்களுக்கான நீட்டிப்பு முறைகள்.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// எ.கா., ஒரு நூலில் சேருவது அச்சிடப்படலாம், எனவே `unwrap` உடன் பயன்படுத்தலாம் என்பதை உறுதிப்படுத்தவும்.
// அனுப்புதல் மேம்பாட்டுடன் பணிபுரிந்தால் இறுதியில் தேவைப்படாது.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// பெட்டி வகை `T` க்கு சமமாக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // இந்த செயல்பாடு உடனடிப்படுத்தப்பட்ட `TypeId` வகையைப் பெறுங்கள்.
        let t = TypeId::of::<T>();

        // trait பொருள் (`self`) இல் வகையின் `TypeId` ஐப் பெறுக.
        let concrete = self.type_id();

        // சமத்துவத்தில் `TypeId` இரண்டையும் ஒப்பிடுக.
        t == concrete
    }

    /// பெட்டி மதிப்பு `T` வகையாக இருந்தால், அல்லது அது இல்லாவிட்டால் `None` க்கு சில குறிப்புகளை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // பாதுகாப்பு: நாம் சரியான வகையை சுட்டிக்காட்டுகிறோமா என்று சோதித்தோம், நாங்கள் நம்பலாம்
            // நினைவக பாதுகாப்பிற்கான சோதனை, ஏனென்றால் எல்லா வகைகளுக்கும் எதையும் நாங்கள் செயல்படுத்தியுள்ளோம்;எங்கள் தூண்டுதலுடன் முரண்படுவதால் வேறு எந்த தூண்டுதல்களும் இருக்க முடியாது.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// பெட்டியின் மதிப்பு `T` வகையாக இருந்தால், அல்லது அது இல்லாவிட்டால் `None` என சில மாற்றத்தக்க குறிப்பை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // பாதுகாப்பு: நாம் சரியான வகையை சுட்டிக்காட்டுகிறோமா என்று சோதித்தோம், நாங்கள் நம்பலாம்
            // நினைவக பாதுகாப்பிற்கான சோதனை, ஏனென்றால் எல்லா வகைகளுக்கும் எதையும் நாங்கள் செயல்படுத்தியுள்ளோம்;எங்கள் தூண்டுதலுடன் முரண்படுவதால் வேறு எந்த தூண்டுதல்களும் இருக்க முடியாது.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` வகையில் வரையறுக்கப்பட்ட முறைக்கு முன்னோக்கி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` வகையில் வரையறுக்கப்பட்ட முறைக்கு முன்னோக்கி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` வகையில் வரையறுக்கப்பட்ட முறைக்கு முன்னோக்கி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` வகையில் வரையறுக்கப்பட்ட முறைக்கு முன்னோக்கி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` வகையில் வரையறுக்கப்பட்ட முறைக்கு முன்னோக்கி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` வகையில் வரையறுக்கப்பட்ட முறைக்கு முன்னோக்கி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID மற்றும் அதன் முறைகள்
///////////////////////////////////////////////////////////////////////////////

/// ஒரு `TypeId` ஒரு வகைக்கான உலகளவில் தனித்துவமான அடையாளங்காட்டியைக் குறிக்கிறது.
///
/// ஒவ்வொரு `TypeId` ஒரு ஒளிபுகா பொருளாகும், இது உள்ளே இருப்பதை ஆய்வு செய்ய அனுமதிக்காது, ஆனால் குளோனிங், ஒப்பீடு, அச்சிடுதல் மற்றும் காண்பித்தல் போன்ற அடிப்படை செயல்பாடுகளை அனுமதிக்கிறது.
///
///
/// ஒரு `TypeId` தற்போது `'static` ஐக் குறிக்கும் வகைகளுக்கு மட்டுமே கிடைக்கிறது, ஆனால் இந்த வரம்பு future இல் அகற்றப்படலாம்.
///
/// `TypeId` `Hash`, `PartialOrd` மற்றும் `Ord` ஐ செயல்படுத்துகையில், Rust வெளியீடுகளுக்கு இடையில் ஹாஷ்கள் மற்றும் வரிசைப்படுத்தல் மாறுபடும் என்பது கவனிக்கத்தக்கது.
/// உங்கள் குறியீட்டின் உள்ளே அவற்றை நம்புவதில் ஜாக்கிரதை!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// இந்த பொதுவான செயல்பாடு உடனடிப்படுத்தப்பட்ட வகையின் `TypeId` ஐ வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// ஒரு வகையின் பெயரை சரம் துண்டுகளாக வழங்குகிறது.
///
/// # Note
///
/// இது கண்டறியும் பயன்பாட்டிற்காக வடிவமைக்கப்பட்டுள்ளது.
/// திரும்பிய சரத்தின் சரியான உள்ளடக்கங்கள் மற்றும் வடிவம் குறிப்பிடப்படவில்லை, இது வகையின் சிறந்த முயற்சி விளக்கத்தைத் தவிர.
/// எடுத்துக்காட்டாக, `type_name::<Option<String>>()` திரும்பக்கூடிய சரங்களில் `"Option<String>"` மற்றும் `"std::option::Option<std::string::String>"` ஆகியவை அடங்கும்.
///
///
/// திரும்பிய சரம் ஒரு வகையின் தனித்துவமான அடையாளங்காட்டியாக கருதப்படக்கூடாது, ஏனெனில் பல வகைகள் ஒரே வகை பெயருக்கு வரைபடமாக இருக்கலாம்.
/// இதேபோல், திரும்பிய சரத்தில் ஒரு வகையின் அனைத்து பகுதிகளும் தோன்றும் என்பதற்கு எந்த உத்தரவாதமும் இல்லை: எடுத்துக்காட்டாக, வாழ்நாள் குறிப்பான்கள் தற்போது சேர்க்கப்படவில்லை.
/// கூடுதலாக, தொகுப்பியின் பதிப்புகளுக்கு இடையில் வெளியீடு மாறக்கூடும்.
///
/// தற்போதைய செயல்படுத்தல் கம்பைலர் கண்டறிதல் மற்றும் பிழைத்திருத்தம் போன்ற அதே உள்கட்டமைப்பைப் பயன்படுத்துகிறது, ஆனால் இது உத்தரவாதம் அளிக்கப்படவில்லை.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// சுட்டிக்காட்டப்பட்ட-மதிப்பின் வகையின் பெயரை ஒரு சரம் துண்டுகளாக வழங்குகிறது.
/// இது `type_name::<T>()` ஐப் போன்றது, ஆனால் ஒரு மாறி வகை எளிதில் கிடைக்காத இடத்தில் பயன்படுத்தலாம்.
///
/// # Note
///
/// இது கண்டறியும் பயன்பாட்டிற்காக வடிவமைக்கப்பட்டுள்ளது.வகையின் சிறந்த முயற்சி விளக்கத்தைத் தவிர, சரத்தின் சரியான உள்ளடக்கங்கள் மற்றும் வடிவம் குறிப்பிடப்படவில்லை.
/// எடுத்துக்காட்டாக, `type_name_of_val::<Option<String>>(None)` `"Option<String>"` அல்லது `"std::option::Option<std::string::String>"` ஐ வழங்கலாம், ஆனால் `"foobar"` அல்ல.
///
/// கூடுதலாக, தொகுப்பியின் பதிப்புகளுக்கு இடையில் வெளியீடு மாறக்கூடும்.
///
/// இந்த செயல்பாடு trait பொருள்களை தீர்க்காது, அதாவது `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` ஐ திரும்பக் கொடுக்கலாம், ஆனால் `"u32"` அல்ல.
///
/// வகை பெயரை ஒரு வகையின் தனிப்பட்ட அடையாளங்காட்டியாக கருதக்கூடாது;
/// பல வகைகள் ஒரே வகை பெயரைப் பகிரலாம்.
///
/// தற்போதைய செயல்படுத்தல் கம்பைலர் கண்டறிதல் மற்றும் பிழைத்திருத்தம் போன்ற அதே உள்கட்டமைப்பைப் பயன்படுத்துகிறது, ஆனால் இது உத்தரவாதம் அளிக்கப்படவில்லை.
///
/// # Examples
///
/// இயல்புநிலை முழு எண் மற்றும் மிதவை வகைகளை அச்சிடுகிறது.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}