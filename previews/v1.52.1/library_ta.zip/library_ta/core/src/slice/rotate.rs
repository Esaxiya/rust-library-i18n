// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` வரம்பை சுழற்றுகிறது, அதாவது `mid` இல் உள்ள உறுப்பு முதல் உறுப்பு ஆகும்.சமமாக, வரம்பு `left` கூறுகளை இடதுபுறமாக அல்லது `right` உறுப்புகளை வலப்புறம் சுழற்றுகிறது.
///
/// # Safety
///
/// குறிப்பிட்ட வரம்பு வாசிப்பதற்கும் எழுதுவதற்கும் செல்லுபடியாகும்.
///
/// # Algorithm
///
/// அல்காரிதம் 1 `left + right` இன் சிறிய மதிப்புகளுக்கு அல்லது பெரிய `T` க்கு பயன்படுத்தப்படுகிறது.
/// உறுப்புகள் அவற்றின் இறுதி நிலைகளுக்கு ஒரு நேரத்தில் `mid - left` இல் தொடங்கி `right` படிகள் மட்டு `left + right` ஆல் முன்னேறுகின்றன, அதாவது ஒரே ஒரு தற்காலிக தேவை.
/// இறுதியில், நாங்கள் `mid - left` இல் திரும்பி வருகிறோம்.
/// இருப்பினும், `gcd(left + right, right)` 1 இல்லையென்றால், மேலே உள்ள படிகள் உறுப்புகளைத் தவிர்த்தன.
/// உதாரணத்திற்கு:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// அதிர்ஷ்டவசமாக, இறுதி செய்யப்பட்ட உறுப்புகளுக்கு இடையில் தவிர்க்கப்பட்ட உறுப்புகளின் எண்ணிக்கை எப்போதும் சமமாக இருக்கும், எனவே நாம் நமது தொடக்க நிலையை ஈடுசெய்து அதிக சுற்றுகளைச் செய்யலாம் (மொத்த சுற்றுகளின் எண்ணிக்கை `gcd(left + right, right)` value) ஆகும்.
///
/// இறுதி முடிவு என்னவென்றால், அனைத்து கூறுகளும் ஒரு முறை மற்றும் ஒரே ஒரு முறை மட்டுமே இறுதி செய்யப்படுகின்றன.
///
/// `left + right` பெரியதாக இருந்தால் அல்காரிதம் 2 பயன்படுத்தப்படுகிறது, ஆனால் `min(left, right)` ஒரு ஸ்டாக் பஃப்பரில் பொருந்தும் அளவுக்கு சிறியது.
/// `min(left, right)` கூறுகள் இடையகத்தின் மீது நகலெடுக்கப்படுகின்றன, `memmove` மற்றவர்களுக்குப் பயன்படுத்தப்படுகிறது, மேலும் இடையகத்தில் உள்ளவை அவை தோன்றிய இடத்தின் எதிர் பக்கத்தில் உள்ள துளைக்குள் நகர்த்தப்படுகின்றன.
///
/// `left + right` போதுமானதாகிவிட்டால், திசையன் செய்யக்கூடிய வழிமுறைகள் மேலே உள்ளதை விட சிறப்பாக செயல்படுகின்றன.
/// ஒரே நேரத்தில் பல சுற்றுகளைச் செய்வதன் மூலம் அல்காரிதம் 1 ஐ திசையன் செய்ய முடியும், ஆனால் `left + right` மிகப்பெரியதாக இருக்கும் வரை சராசரியாக மிகக் குறைவான சுற்றுகள் உள்ளன, மேலும் ஒரு சுற்றின் மோசமான நிலை எப்போதும் இருக்கும்.
/// அதற்கு பதிலாக, ஒரு சிறிய சுழற்சி சிக்கல் இருக்கும் வரை `min(left, right)` கூறுகளை மீண்டும் மாற்றுவதை வழிமுறை 3 பயன்படுத்துகிறது.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` இடமாற்றம் இடதுபுறத்தில் இருந்து நடக்கும்.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. இந்த வழக்குகள் சரிபார்க்கப்படாவிட்டால் கீழேயுள்ள வழிமுறைகள் தோல்வியடையும்
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // அல்காரிதம் 1 மைக்ரோபென்மார்க்ஸ் சீரற்ற மாற்றங்களுக்கான சராசரி செயல்திறன் `left + right == 32` வரை எல்லா வழிகளிலும் சிறந்தது என்பதைக் குறிக்கிறது, ஆனால் மோசமான நிலை செயல்திறன் 16 ஐக் கூட உடைக்கிறது.
            // 24 நடுத்தர மைதானமாக தேர்வு செய்யப்பட்டது.
            // `T` இன் அளவு 4 `பயன்பாட்டு அளவை விட பெரியதாக இருந்தால், இந்த வழிமுறை மற்ற வழிமுறைகளையும் விஞ்சும்.
            //
            //
            let x = unsafe { mid.sub(left) };
            // முதல் சுற்றின் ஆரம்பம்
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` ஐக் கணக்கிடுவதன் மூலம் கைக்கு முன்னால் காணலாம், ஆனால் ஒரு சுழற்சியைச் செய்வது வேகமானது, இது gcd ஐ ஒரு பக்க விளைவுகளாகக் கணக்கிடுகிறது, பின்னர் மீதமுள்ள துண்டுகளைச் செய்கிறது
            //
            //
            let mut gcd = right;
            // ஒரு தற்காலிகத்தை ஒரு முறை படிப்பதற்கும், பின்னோக்கி நகலெடுப்பதற்கும், பின்னர் அந்த தற்காலிகத்தை மிக இறுதியில் எழுதுவதற்கும் பதிலாக தற்காலிகங்களை மாற்றுவது வேகமானது என்பதை வரையறைகள் வெளிப்படுத்துகின்றன.
            // இரண்டை நிர்வகிக்க வேண்டியதற்கு பதிலாக, தற்காலிகங்களை மாற்றுவது அல்லது மாற்றுவது சுழற்சியில் ஒரு நினைவக முகவரியை மட்டுமே பயன்படுத்துகிறது என்பதற்கு இது காரணமாக இருக்கலாம்.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` ஐ அதிகரிப்பதற்குப் பதிலாக, அது எல்லைக்கு வெளியே இருக்கிறதா என்று சோதிப்பதற்குப் பதிலாக, `i` அடுத்த அதிகரிப்பில் எல்லைக்கு வெளியே செல்லுமா என்பதை நாங்கள் சரிபார்க்கிறோம்.
                // இது சுட்டிகள் அல்லது `usize` ஐ மடக்குவதைத் தடுக்கிறது.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // முதல் சுற்றின் முடிவு
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` என்றால் இந்த நிபந்தனை இங்கே இருக்க வேண்டும்
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // துண்டுகளை அதிக சுற்றுகளுடன் முடிக்கவும்
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` பூஜ்ஜிய அளவிலான வகை அல்ல, எனவே அதன் அளவைக் கொண்டு பிரிப்பது சரி.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // அல்காரிதம் 2 இங்குள்ள `[T; 0]` இது T க்கு சரியான முறையில் சீரமைக்கப்படுவதை உறுதி செய்வதாகும்
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // அல்காரிதம் 3 இந்த வழிமுறையின் கடைசி இடமாற்றம் எங்கே இருக்கும் என்பதைக் கண்டுபிடிப்பதும், இந்த வழிமுறை போன்ற அருகிலுள்ள துகள்களை மாற்றுவதற்குப் பதிலாக அந்த கடைசி துண்டைப் பயன்படுத்தி மாற்றுவதும் ஒரு மாற்று வழி உள்ளது, ஆனால் இந்த வழி இன்னும் வேகமாக உள்ளது.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // அல்காரிதம் 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}