//! ஸ்லைஸின் ஈரேட்டர்களால் பயன்படுத்தப்படும் மேக்ரோக்கள்.

// Is_empty மற்றும் லென் இன்லைன் ஒரு பெரிய செயல்திறன் வித்தியாசத்தை ஏற்படுத்துகிறது
macro_rules! is_empty {
    // ஒரு ZST ஐரேட்டரின் நீளத்தை நாம் குறியாக்கம் செய்யும் முறை, இது ZST மற்றும் ZST அல்லாத இரண்டிற்கும் வேலை செய்கிறது.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// சில எல்லை சோதனைகளில் இருந்து விடுபட (`position` ஐப் பார்க்கவும்), நீளத்தை சற்றே எதிர்பாராத வகையில் கணக்கிடுகிறோம்.
// (`கோட்ஜென்/ஸ்லைஸ்-பொசிஷன்-பவுண்ட்ஸ்-செக்` மூலம் சோதிக்கப்பட்டது.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // நாங்கள் சில நேரங்களில் பாதுகாப்பற்ற தொகுதிக்குள் பயன்படுத்தப்படுகிறோம்

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // இந்த _cannot_ `unchecked_sub` ஐப் பயன்படுத்துகிறது, ஏனென்றால் நீண்ட ZST ஸ்லைஸ் ஐரேட்டர்களின் நீளத்தைக் குறிக்க மடக்குவதை நாங்கள் சார்ந்து இருக்கிறோம்.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // `start <= end`, `offset_from` ஐ விட சிறப்பாக செய்ய முடியும் என்பதை நாங்கள் அறிவோம், இது கையொப்பமிடப்பட வேண்டும்.
            // பொருத்தமான கொடிகளை இங்கே அமைப்பதன் மூலம் எல்.எல்.வி.எம்-க்கு இதைச் சொல்லலாம், இது எல்லை சோதனைகளை அகற்ற உதவுகிறது.
            // பாதுகாப்பு: மாறாத வகை மூலம், `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // சுட்டிகள் வகை அளவின் துல்லியமான பெருக்கத்தால் வேறுபடுகின்றன என்று எல்.எல்.வி.எம்-க்குச் சொல்வதன் மூலம், இது `(end - start) < size` க்கு பதிலாக `len() == 0` ஐ `start == end` வரை மேம்படுத்தலாம்.
            //
            // பாதுகாப்பு: மாறாத வகை மூலம், சுட்டிகள் சீரமைக்கப்படுகின்றன
            //         அவற்றுக்கிடையேயான தூரம் சுட்டிக்காட்டி அளவின் பலமாக இருக்க வேண்டும்
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` மற்றும் `IterMut` ஐரேட்டர்களின் பகிரப்பட்ட வரையறை
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // முதல் உறுப்பை திருப்பி, ஈரேட்டரின் தொடக்கத்தை 1 ஆல் முன்னோக்கி நகர்த்துகிறது.
        // இன்லைன் செய்யப்பட்ட செயல்பாட்டுடன் ஒப்பிடும்போது செயல்திறனை பெரிதும் மேம்படுத்துகிறது.
        // ஈரேட்டர் காலியாக இருக்கக்கூடாது.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // கடைசி உறுப்பை திருப்பி, ஈரேட்டரின் முடிவை 1 ஆல் பின்னோக்கி நகர்த்துகிறது.
        // இன்லைன் செய்யப்பட்ட செயல்பாட்டுடன் ஒப்பிடும்போது செயல்திறனை பெரிதும் மேம்படுத்துகிறது.
        // ஈரேட்டர் காலியாக இருக்கக்கூடாது.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // T ஒரு ZST ஆக இருக்கும்போது, iterator இன் முடிவை `n` ஆல் பின்னோக்கி நகர்த்துவதன் மூலம் சுருங்குகிறது.
        // `n` `self.len()` ஐ விட அதிகமாக இருக்கக்கூடாது.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // ஈரேட்டரிலிருந்து ஒரு துண்டுகளை உருவாக்குவதற்கான உதவி செயல்பாடு.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // பாதுகாப்பு: சுட்டிக்காட்டி கொண்ட ஒரு துண்டுகளிலிருந்து ஈரேட்டர் உருவாக்கப்பட்டது
                // `self.ptr` மற்றும் நீளம் `len!(self)`.
                // `from_raw_parts` க்கான அனைத்து முன்நிபந்தனைகளும் பூர்த்தி செய்யப்படுகின்றன என்பதற்கு இது உத்தரவாதம் அளிக்கிறது.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // ஐரேட்டரின் தொடக்கத்தை `offset` உறுப்புகளால் முன்னோக்கி நகர்த்துவதற்கான உதவி செயல்பாடு, பழைய தொடக்கத்தைத் தருகிறது.
            //
            // பாதுகாப்பற்றது ஏனெனில் ஆஃப்செட் `self.len()` ஐ விட அதிகமாக இருக்கக்கூடாது.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // பாதுகாப்பு: அழைப்பாளர் `offset` `self.len()` ஐ தாண்டாது என்று உத்தரவாதம் அளிக்கிறது,
                    // எனவே இந்த புதிய சுட்டிக்காட்டி `self` க்குள் உள்ளது, இதனால் பூஜ்யமற்றது என்று உத்தரவாதம் அளிக்கப்படுகிறது.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // மறு செய்கையின் முடிவை `offset` உறுப்புகளால் பின்னோக்கி நகர்த்துவதற்கான உதவி செயல்பாடு, புதிய முடிவைத் தருகிறது.
            //
            // பாதுகாப்பற்றது ஏனெனில் ஆஃப்செட் `self.len()` ஐ விட அதிகமாக இருக்கக்கூடாது.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // பாதுகாப்பு: அழைப்பாளர் `offset` `self.len()` ஐ தாண்டாது என்று உத்தரவாதம் அளிக்கிறது,
                    // இது ஒரு `isize` ஐ நிரம்பி வழியாது என்று உத்தரவாதம் அளிக்கப்படுகிறது.
                    // மேலும், இதன் விளைவாக வரும் சுட்டிக்காட்டி `slice` இன் எல்லைகளில் உள்ளது, இது `offset` க்கான பிற தேவைகளை பூர்த்தி செய்கிறது.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // துண்டுகள் மூலம் செயல்படுத்தப்படலாம், ஆனால் இது எல்லை சோதனைகளைத் தவிர்க்கிறது

                // பாதுகாப்பு: ஒரு துண்டின் தொடக்க சுட்டிக்காட்டி என்பதால் `assume` அழைப்புகள் பாதுகாப்பானவை
                // பூஜ்யமற்றதாக இருக்க வேண்டும், மற்றும் ZST அல்லாதவற்றின் துண்டுகள் பூஜ்யமற்ற இறுதி சுட்டிக்காட்டி கொண்டிருக்க வேண்டும்.
                // முதலில் ஈரேட்டர் காலியாக இருக்கிறதா என்று நாங்கள் சோதிப்பதால் `next_unchecked!` க்கான அழைப்பு பாதுகாப்பானது.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // இந்த ஈரேட்டர் இப்போது காலியாக உள்ளது.
                    if mem::size_of::<T>() == 0 {
                        // `ptr` ஒருபோதும் 0 ஆக இருக்கக்கூடாது என்பதால் இதை நாம் செய்ய வேண்டும், ஆனால் `end` (மடக்குதல் காரணமாக) இருக்கலாம்.
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // பாதுகாப்பு: T ZST இல்லையென்றால் முடிவு 0 ஆக இருக்க முடியாது, ஏனெனில் ptr 0 இல்லை மற்றும் முடிவு>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // பாதுகாப்பு: நாங்கள் எல்லைக்குட்பட்டவர்கள்.`post_inc_start` ZST களுக்கு கூட சரியானதைச் செய்கிறது.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // `try_fold` ஐப் பயன்படுத்தும் இயல்புநிலை செயலாக்கத்தை நாங்கள் மேலெழுதும், ஏனெனில் இந்த எளிய செயல்படுத்தல் குறைந்த எல்.எல்.வி.எம் ஐ.ஆரை உருவாக்குகிறது மற்றும் தொகுக்க வேகமானது.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // `try_fold` ஐப் பயன்படுத்தும் இயல்புநிலை செயலாக்கத்தை நாங்கள் மேலெழுதும், ஏனெனில் இந்த எளிய செயல்படுத்தல் குறைந்த எல்.எல்.வி.எம் ஐ.ஆரை உருவாக்குகிறது மற்றும் தொகுக்க வேகமானது.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // `try_fold` ஐப் பயன்படுத்தும் இயல்புநிலை செயலாக்கத்தை நாங்கள் மேலெழுதும், ஏனெனில் இந்த எளிய செயல்படுத்தல் குறைந்த எல்.எல்.வி.எம் ஐ.ஆரை உருவாக்குகிறது மற்றும் தொகுக்க வேகமானது.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // `try_fold` ஐப் பயன்படுத்தும் இயல்புநிலை செயலாக்கத்தை நாங்கள் மேலெழுதும், ஏனெனில் இந்த எளிய செயல்படுத்தல் குறைந்த எல்.எல்.வி.எம் ஐ.ஆரை உருவாக்குகிறது மற்றும் தொகுக்க வேகமானது.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // `try_fold` ஐப் பயன்படுத்தும் இயல்புநிலை செயலாக்கத்தை நாங்கள் மேலெழுதும், ஏனெனில் இந்த எளிய செயல்படுத்தல் குறைந்த எல்.எல்.வி.எம் ஐ.ஆரை உருவாக்குகிறது மற்றும் தொகுக்க வேகமானது.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // `try_fold` ஐப் பயன்படுத்தும் இயல்புநிலை செயலாக்கத்தை நாங்கள் மேலெழுதும், ஏனெனில் இந்த எளிய செயல்படுத்தல் குறைந்த எல்.எல்.வி.எம் ஐ.ஆரை உருவாக்குகிறது மற்றும் தொகுக்க வேகமானது.
            // மேலும், `assume` ஒரு எல்லை சரிபார்ப்பைத் தவிர்க்கிறது.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // பாதுகாப்பு: வளைய மாற்றத்தால் எல்லைக்குட்பட்டதாக நாங்கள் உத்தரவாதம் அளிக்கிறோம்:
                        // `i >= n`, `self.next()` `None` ஐத் தருகிறது மற்றும் வளையம் உடைகிறது.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // `try_fold` ஐப் பயன்படுத்தும் இயல்புநிலை செயலாக்கத்தை நாங்கள் மேலெழுதும், ஏனெனில் இந்த எளிய செயல்படுத்தல் குறைந்த எல்.எல்.வி.எம் ஐ.ஆரை உருவாக்குகிறது மற்றும் தொகுக்க வேகமானது.
            // மேலும், `assume` ஒரு எல்லை சரிபார்ப்பைத் தவிர்க்கிறது.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // பாதுகாப்பு: `i` `n` இல் தொடங்கும் என்பதால் `n` ஐ விட குறைவாக இருக்க வேண்டும்
                        // மற்றும் குறைந்து வருகிறது.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // பாதுகாப்பு: அழைப்பாளர் `i` எல்லைக்குட்பட்டது என்று உத்தரவாதம் அளிக்க வேண்டும்
                // அடிப்படை ஸ்லைஸ், எனவே `i` ஒரு `isize` ஐ நிரம்பி வழிய முடியாது, மேலும் திரும்பிய குறிப்புகள் ஸ்லைஸின் ஒரு உறுப்பைக் குறிக்க உத்தரவாதம் அளிக்கப்படுகின்றன, இதனால் செல்லுபடியாகும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
                //
                // அதே குறியீட்டுடன் நாங்கள் மீண்டும் அழைக்கப்படவில்லை என்பதையும் அழைப்பாளர் உத்தரவாதம் அளிக்கிறார் என்பதையும் நினைவில் கொள்க, மேலும் இந்த சந்தாவை அணுகக்கூடிய வேறு எந்த முறைகளும் அழைக்கப்படவில்லை, எனவே திரும்பப் பெறப்பட்ட குறிப்பு மாற்றத்தக்கதாக இருக்க இது செல்லுபடியாகும்
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // துண்டுகள் மூலம் செயல்படுத்தப்படலாம், ஆனால் இது எல்லை சோதனைகளைத் தவிர்க்கிறது

                // பாதுகாப்பு: ஒரு துண்டின் தொடக்க சுட்டிக்காட்டி பூஜ்யமாக இருக்கக்கூடாது என்பதால் `assume` அழைப்புகள் பாதுகாப்பானவை,
                // மற்றும் ZST அல்லாதவற்றின் துண்டுகள் பூஜ்யமற்ற இறுதி சுட்டிக்காட்டி கொண்டிருக்க வேண்டும்.
                // முதலில் ஈரேட்டர் காலியாக இருக்கிறதா என்று நாங்கள் சோதிப்பதால் `next_back_unchecked!` க்கான அழைப்பு பாதுகாப்பானது.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // இந்த ஈரேட்டர் இப்போது காலியாக உள்ளது.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // பாதுகாப்பு: நாங்கள் எல்லைக்குட்பட்டவர்கள்.`pre_dec_end` ZST களுக்கு கூட சரியானதைச் செய்கிறது.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}