//! `[T]` க்கான traits ஐ ஒப்பிடுங்கள்.

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// அழைப்புகள் செயல்படுத்தல் memcmp வழங்கப்பட்டது.
    ///
    /// தரவை u8 என விளக்குகிறது.
    ///
    /// 0 க்கு சமமாகவும், <0 க்கும் குறைவாகவும்> 0 ஐ விட அதிகமாகவும் வழங்குகிறது.
    ///
    // FIXME(#32610): திரும்ப வகை c_int ஆக இருக்க வேண்டும்
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// vectors [lexicographically](Ord#lexicographical-comparison) இன் ஒப்பீட்டை செயல்படுத்துகிறது.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// vectors [lexicographically](Ord#lexicographical-comparison) இன் ஒப்பீட்டை செயல்படுத்துகிறது.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// ஸ்லைஸின் பகுதி எக் சிறப்புக்கு இடைநிலை trait
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// பொதுவான துண்டு சமத்துவம்
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// வகைகள் அனுமதிக்கும்போது பைட்வைஸ் சமத்துவத்திற்கு memcmp ஐப் பயன்படுத்தவும்
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // பாதுகாப்பு: `self` மற்றும் `other` ஆகியவை குறிப்புகள் மற்றும் அவை செல்லுபடியாகும் என்று உத்தரவாதம் அளிக்கப்படுகின்றன.
        // இரண்டு துண்டுகள் மேலே ஒரே அளவைக் கொண்டிருக்கின்றனவா என்று சோதிக்கப்பட்டுள்ளது.
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// ஸ்லைஸின் பகுதி பகுதியின் சிறப்புக்காக இடைநிலை trait
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // கம்பைலரில் கட்டுப்படுத்தப்பட்ட காசோலை நீக்குதலை இயக்க லூப் மறு செய்கை வரம்பில் நறுக்கவும்
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// இதுதான் நாம் பெற விரும்பும் தூண்டுதல்.துரதிர்ஷ்டவசமாக இது ஒலி இல்லை.
// `partial_ord_slice.rs` ஐப் பார்க்கவும்.
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// ஸ்லைஸின் ஆர்டின் நிபுணத்துவத்திற்கான இடைநிலை trait
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // கம்பைலரில் கட்டுப்படுத்தப்பட்ட காசோலை நீக்குதலை இயக்க லூப் மறு செய்கை வரம்பில் நறுக்கவும்
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// memcmp கையொப்பமிடப்படாத பைட்டுகளின் வரிசையை லெக்சோகிராஃபிக்காக ஒப்பிடுகிறது.
// இது [u8] க்கு நாம் விரும்பும் வரிசையுடன் பொருந்துகிறது, ஆனால் மற்றவர்கள் இல்லை ([i8] கூட இல்லை).
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // பாதுகாப்பு: `left` மற்றும் `right` ஆகியவை குறிப்புகள் மற்றும் அவை செல்லுபடியாகும் என்று உத்தரவாதம் அளிக்கப்படுகின்றன.
            // அந்த இடைவெளியில் படிக்க இரு பகுதிகளும் செல்லுபடியாகும் என்பதை உறுதிப்படுத்தும் இரு நீளங்களின் குறைந்தபட்சத்தையும் நாங்கள் பயன்படுத்துகிறோம்.
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// `Eq` க்கு ஒரு முறை இருந்தாலும் `Eq` இல் நிபுணத்துவம் பெற அனுமதிக்க ஹேக்.
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait அவற்றின் பைட்வைஸ் பிரதிநிதித்துவத்தைப் பயன்படுத்தி சமத்துவத்துடன் ஒப்பிடக்கூடிய வகைகளுக்கு செயல்படுத்தப்படுகிறது
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // பாதுகாப்பு: `i8` மற்றும் `u8` ஆகியவை ஒரே நினைவக அமைப்பைக் கொண்டுள்ளன, இதனால் `x.as_ptr()` ஐ அனுப்புகிறது
        // `*const u8` பாதுகாப்பானது என்பதால்.
        // `x.as_ptr()` ஒரு குறிப்பிலிருந்து வருகிறது, இதனால் `x.len()` ஸ்லைஸின் நீளத்திற்கான வாசிப்புகளுக்கு செல்லுபடியாகும் என்று உத்தரவாதம் அளிக்கப்படுகிறது, இது `isize::MAX` ஐ விட பெரியதாக இருக்க முடியாது.
        // திரும்பிய துண்டு ஒருபோதும் மாற்றப்படவில்லை.
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}