//! ASCII `[u8]` இல் செயல்பாடுகள்.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// இந்த ஸ்லைஸில் உள்ள அனைத்து பைட்டுகளும் ASCII வரம்பிற்குள் இருக்கிறதா என்று சரிபார்க்கிறது.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// இரண்டு துண்டுகள் ஒரு ஆஸ்கி வழக்கு-உணர்வற்ற பொருத்தம் என்பதை சரிபார்க்கிறது.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` போலவே, ஆனால் தற்காலிகங்களை ஒதுக்காமல் மற்றும் நகலெடுக்காமல்.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// இந்த துண்டை அதன் ASCII மேல் வழக்குக்கு சமமான இடத்தில் மாற்றுகிறது.
    ///
    /// ASCII எழுத்துக்கள் 'a' முதல் 'z' வரை 'A' முதல் 'Z' வரை மாற்றப்படுகின்றன, ஆனால் ASCII அல்லாத எழுத்துக்கள் மாறாமல் உள்ளன.
    ///
    /// ஏற்கனவே உள்ள ஒன்றை மாற்றாமல் புதிய பெரிய மதிப்பைத் தர, [`to_ascii_uppercase`] ஐப் பயன்படுத்தவும்.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// இந்த துண்டை அதன் ASCII லோயர் கேஸ் சமமான இடத்தில் மாற்றுகிறது.
    ///
    /// ASCII எழுத்துக்கள் 'A' முதல் 'Z' வரை 'a' முதல் 'z' வரை மாற்றப்படுகின்றன, ஆனால் ASCII அல்லாத எழுத்துக்கள் மாறாமல் உள்ளன.
    ///
    /// ஏற்கனவே உள்ள ஒன்றை மாற்றாமல் புதிய சிறிய மதிப்பைத் தர, [`to_ascii_lowercase`] ஐப் பயன்படுத்தவும்.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` என்ற வார்த்தையில் ஏதேனும் பைட் nonascii (>=128) எனில் `true` ஐ வழங்குகிறது.
/// `../str/mod.rs` இலிருந்து ஸ்னார்ஃபெட், இது utf8 சரிபார்ப்புக்கு ஒத்த ஒன்றைச் செய்கிறது.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// உகந்த ASCII சோதனை, இது பைட்-அட்-எ-டைம் செயல்பாடுகளுக்குப் பதிலாக (முடிந்தவரை) பயன்பாட்டைப் பயன்படுத்துகிறது.
///
/// நாம் இங்கு பயன்படுத்தும் வழிமுறை மிகவும் எளிது.`s` மிகவும் குறுகியதாக இருந்தால், நாங்கள் ஒவ்வொரு பைட்டையும் சரிபார்த்து அதைச் செய்வோம்.இல்லையெனில்:
///
/// - வரிசைப்படுத்தப்படாத சுமையுடன் முதல் வார்த்தையைப் படியுங்கள்.
/// - சுட்டிக்காட்டி சீரமைக்கவும், சீரமைக்கப்பட்ட சுமைகளுடன் இறுதி வரை அடுத்தடுத்த சொற்களைப் படியுங்கள்.
/// - வரிசைப்படுத்தப்படாத சுமையுடன் `s` இலிருந்து கடைசி `usize` ஐப் படிக்கவும்.
///
/// இந்த சுமைகளில் ஏதேனும் `contains_nonascii` (above) உண்மையைத் தரும் ஒன்றை உருவாக்கினால், பதில் தவறானது என்று எங்களுக்குத் தெரியும்.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // ஒரு நேரத்தில் செயல்படுத்தப்படுவதிலிருந்து நாம் எதையும் பெற முடியாவிட்டால், மீண்டும் ஒரு அளவிடல் வட்டத்திற்கு விழவும்.
    //
    // `usize` க்கு `size_of::<usize>()` போதுமான சீரமைப்பு இல்லாத கட்டமைப்புகளுக்காகவும் இதைச் செய்கிறோம், ஏனெனில் இது ஒரு வித்தியாசமான edge வழக்கு.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // வரிசைப்படுத்தப்படாத முதல் வார்த்தையை நாங்கள் எப்போதும் படிப்போம், அதாவது `align_offset`
    // 0, சீரமைக்கப்பட்ட வாசிப்புக்கு மீண்டும் அதே மதிப்பைப் படிப்போம்.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // பாதுகாப்பு: மேலே உள்ள `len < USIZE_SIZE` ஐ சரிபார்க்கிறோம்.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // இதை மேலே, ஓரளவு மறைமுகமாக சோதித்தோம்.
    // `offset_to_aligned` என்பது `align_offset` அல்லது `USIZE_SIZE` என்பதை நினைவில் கொள்க, இவை இரண்டும் மேலே வெளிப்படையாக சரிபார்க்கப்படுகின்றன.
    //
    debug_assert!(offset_to_aligned <= len);

    // பாதுகாப்பு: word_ptr என்பது நாம் படிக்கப் பயன்படுத்தும் (சரியாக சீரமைக்கப்பட்ட) பயன்பாட்டு ptr ஆகும்
    // துண்டின் நடுத்தர பகுதி.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` `word_ptr` இன் பைட் குறியீடாகும், இது லூப் எண்ட் காசோலைகளுக்குப் பயன்படுத்தப்படுகிறது.
    let mut byte_pos = offset_to_aligned;

    // சித்தப்பிரமை சீரமைப்பு பற்றி சரிபார்க்கவும், ஏனெனில் நாங்கள் வரிசைப்படுத்தப்படாத சுமைகளைச் செய்ய உள்ளோம்.
    // நடைமுறையில் இது `align_offset` இல் ஒரு பிழையைத் தவிர்த்து சாத்தியமற்றதாக இருக்க வேண்டும்.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // கடைசியாக சீரமைக்கப்பட்ட சொல் வரை அடுத்தடுத்த சொற்களைப் படியுங்கள், கடைசியாக சீரமைக்கப்பட்ட வார்த்தையைத் தவிர்த்து வால் சரிபார்ப்பில் செய்ய வேண்டும், வால் எப்போதும் ஒரு `usize` ஆக இருப்பதை உறுதிசெய்து, கூடுதல் branch `byte_pos == len` க்கு.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // வாசிப்பு வரம்பில் உள்ளதா என்பதை நல்லறிவு சரிபார்க்கவும்
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // `byte_pos` பற்றிய எங்கள் அனுமானங்கள் உள்ளன.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // பாதுகாப்பு: `word_ptr` சரியாக சீரமைக்கப்பட்டிருப்பதை நாங்கள் அறிவோம் (ஏனெனில்
        // `align_offset`), மேலும் `word_ptr` க்கும் முடிவுக்கும் இடையில் போதுமான பைட்டுகள் இருப்பதை நாங்கள் அறிவோம்
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // பாதுகாப்பு: எக்ஸ் 00 எக்ஸ் என்று எங்களுக்குத் தெரியும்
        // இந்த `add` க்குப் பிறகு, `word_ptr` அதிகபட்சமாக ஒரு கடந்த காலமாக இருக்கும்.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // உண்மையில் ஒரு `usize` மட்டுமே எஞ்சியிருப்பதை உறுதிசெய்ய நல்லறிவு சோதனை.
    // இது எங்கள் வளைய நிபந்தனையால் உறுதி செய்யப்பட வேண்டும்.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // பாதுகாப்பு: இது `len >= USIZE_SIZE` ஐ நம்பியுள்ளது, இது தொடக்கத்தில் நாங்கள் சரிபார்க்கிறோம்.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}