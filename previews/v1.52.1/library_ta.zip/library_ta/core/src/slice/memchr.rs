// rust-memchr இலிருந்து எடுக்கப்பட்ட அசல் செயல்படுத்தல்.
// பதிப்புரிமை 2015 ஆண்ட்ரூ கேலண்ட், ப்ளஸ் மற்றும் நிக்கோலாஸ் கோச்

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// துண்டிப்பு பயன்படுத்தவும்.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `x` இல் பூஜ்ஜிய பைட் இருந்தால் `true` ஐ வழங்குகிறது.
///
/// *மேட்டர்ஸ் கம்ப்யூட்டேஷனல்*, ஜே. அர்ன்ட்:
///
/// "ஒவ்வொரு பைட்டுகளிலிருந்தும் ஒன்றைக் கழித்துவிட்டு, பின்னர் பைட்டுகளைத் தேடுவதே இதன் யோசனை.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` இல் பைட் `x` உடன் பொருந்தக்கூடிய முதல் குறியீட்டை வழங்குகிறது.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // சிறிய துண்டுகளுக்கான வேகமான பாதை
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // ஒரே நேரத்தில் இரண்டு `usize` சொற்களைப் படிப்பதன் மூலம் ஒற்றை பைட் மதிப்பை ஸ்கேன் செய்யுங்கள்.
    //
    // `text` ஐ மூன்று பகுதிகளாகப் பிரிக்கவும்
    // - சீரமைக்கப்படாத ஆரம்ப பகுதி, உரையில் முதல் சொல் சீரமைக்கப்பட்ட முகவரிக்கு முன்
    // - உடல், ஒரு நேரத்தில் 2 சொற்களால் ஸ்கேன் செய்யுங்கள்
    // - கடைசியாக மீதமுள்ள பகுதி, <2 சொல் அளவு

    // சீரமைக்கப்பட்ட எல்லை வரை தேடுங்கள்
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // உரையின் உடலைத் தேடுங்கள்
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // பாதுகாப்பு: குறைந்தபட்சம் 2 * usize_bytes தூரத்திற்கு உத்தரவாதம் அளிக்கிறது
        // ஆஃப்செட் மற்றும் ஸ்லைஸின் முடிவுக்கு இடையில்.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // பொருந்தக்கூடிய பைட் இருந்தால் உடைக்கவும்
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // உடல் வளையம் நிறுத்தப்பட்ட பிறகு பைட்டைக் கண்டறியவும்.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` இல் பைட் `x` உடன் பொருந்தும் கடைசி குறியீட்டை வழங்குகிறது.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // ஒரே நேரத்தில் இரண்டு `usize` சொற்களைப் படிப்பதன் மூலம் ஒற்றை பைட் மதிப்பை ஸ்கேன் செய்யுங்கள்.
    //
    // `text` ஐ மூன்று பகுதிகளாகப் பிரிக்கவும்:
    // - சீரமைக்கப்படாத வால், உரையில் கடைசி வார்த்தையின் சீரமைக்கப்பட்ட முகவரிக்குப் பிறகு,
    // - உடல், ஒரே நேரத்தில் 2 சொற்களால் ஸ்கேன் செய்யப்படுகிறது,
    // - மீதமுள்ள முதல் பைட்டுகள், <2 சொல் அளவு.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // முன்னொட்டு மற்றும் பின்னொட்டின் நீளத்தைப் பெற இதை நாங்கள் அழைக்கிறோம்.
        // நடுவில் நாம் எப்போதும் ஒரே நேரத்தில் இரண்டு துகள்களை செயலாக்குகிறோம்.
        // பாதுகாப்பு: `align_to` ஆல் கையாளப்படும் அளவு வேறுபாடுகளைத் தவிர `[u8]` ஐ `[usize]` க்கு மாற்றுவது பாதுகாப்பானது.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // உரையின் உடலைத் தேடுங்கள், நாங்கள் min_aligned_offset ஐக் கடக்கவில்லை என்பதை உறுதிப்படுத்திக் கொள்ளுங்கள்.
    // ஆஃப்செட் எப்போதும் சீரமைக்கப்படுகிறது, எனவே `>` ஐ சோதனை செய்வது போதுமானது மற்றும் சாத்தியமான வழிதல் தவிர்க்கிறது.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // பாதுகாப்பு: ஆஃப்செட் லென், suffix.len() இல் தொடங்குகிறது, அதை விட அதிகமாக இருக்கும் வரை
        // min_aligned_offset (prefix.len()) மீதமுள்ள தூரம் குறைந்தது 2 * chunk_bytes ஆகும்.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // பொருந்தும் பைட் இருந்தால் உடைக்கவும்.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // உடல் வளையம் நிறுத்தப்படுவதற்கு முன்பு பைட்டைக் கண்டறியவும்.
    text[..offset].iter().rposition(|elt| *elt == x)
}