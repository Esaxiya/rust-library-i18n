// ignore-tidy-filelength

//! துண்டு மேலாண்மை மற்றும் கையாளுதல்.
//!
//! மேலும் விவரங்களுக்கு [`std::slice`] ஐப் பார்க்கவும்.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// தூய rust memchr செயல்படுத்தல், rust-memchr இலிருந்து எடுக்கப்பட்டது
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// யூனிட் டெஸ்ட் ஹெப்ஸோர்ட்டுக்கு வேறு வழியில்லை என்பதால் மட்டுமே இந்த செயல்பாடு பொதுவில் உள்ளது.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// ஸ்லைஸில் உள்ள உறுப்புகளின் எண்ணிக்கையை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // பாதுகாப்பு: கான்ஸ்ட் ஒலி, ஏனெனில் நீள புலத்தை ஒரு பயன்பாடாக மாற்றுவோம் (அது இருக்க வேண்டும்)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // பாதுகாப்பு: இது பாதுகாப்பானது, ஏனெனில் `&[T]` மற்றும் `FatPtr<T>` ஆகியவை ஒரே தளவமைப்பைக் கொண்டுள்ளன.
            // `std` மட்டுமே இந்த உத்தரவாதத்தை வழங்க முடியும்.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: இது நிலையானதாக இருக்கும்போது `crate::ptr::metadata(self)` உடன் மாற்றவும்.
            // இந்த எழுத்தின் படி இது "Const-stable functions can only call other const-stable functions" பிழையை ஏற்படுத்துகிறது.
            //

            // பாதுகாப்பு: `PtrRepr` தொழிற்சங்கத்திலிருந்து மதிப்பை அணுகுவது பாதுகாப்பானது * const T என்பதால்
            // மற்றும் PtrComponents<T>ஒரே நினைவக தளவமைப்புகள் உள்ளன.
            // std மட்டுமே இந்த உத்தரவாதத்தை வழங்க முடியும்.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// ஸ்லைஸின் நீளம் 0 இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ஸ்லைஸின் முதல் உறுப்பை வழங்குகிறது, அல்லது அது காலியாக இருந்தால் `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// துண்டின் முதல் உறுப்புக்கு மாற்றக்கூடிய சுட்டிக்காட்டி அல்லது காலியாக இருந்தால் `None` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// ஸ்லைஸின் முதல் மற்றும் மீதமுள்ள அனைத்து உறுப்புகளையும் வழங்குகிறது, அல்லது அது காலியாக இருந்தால் `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ஸ்லைஸின் முதல் மற்றும் மீதமுள்ள அனைத்து உறுப்புகளையும் வழங்குகிறது, அல்லது அது காலியாக இருந்தால் `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ஸ்லைஸின் கடைசி மற்றும் மீதமுள்ள அனைத்து உறுப்புகளையும் வழங்குகிறது, அல்லது அது காலியாக இருந்தால் `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ஸ்லைஸின் கடைசி மற்றும் மீதமுள்ள அனைத்து உறுப்புகளையும் வழங்குகிறது, அல்லது அது காலியாக இருந்தால் `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ஸ்லைஸின் கடைசி உறுப்பை வழங்குகிறது, அல்லது அது காலியாக இருந்தால் `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// ஸ்லைஸில் உள்ள கடைசி உருப்படிக்கு மாற்றக்கூடிய சுட்டிக்காட்டி வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// குறியீட்டு வகையைப் பொறுத்து ஒரு உறுப்பு அல்லது துணைக்கு ஒரு குறிப்பை வழங்குகிறது.
    ///
    /// - ஒரு நிலை வழங்கப்பட்டால், அந்த நிலையில் உள்ள உறுப்புக்கான குறிப்பை அல்லது எல்லைக்கு அப்பாற்பட்டால் `None` ஐ வழங்குகிறது.
    ///
    /// - ஒரு வரம்பைக் கொடுத்தால், அந்த வரம்போடு தொடர்புடைய சந்தாவை வழங்குகிறது, அல்லது எல்லைக்கு அப்பாற்பட்டால் `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// குறியீட்டு வகையை பொறுத்து ஒரு உறுப்பு அல்லது துணைக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது ([`get`] ஐப் பார்க்கவும்) அல்லது குறியீட்டு எல்லைக்கு அப்பாற்பட்டால் `None`.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// எல்லை சரிபார்ப்பு செய்யாமல், ஒரு உறுப்பு அல்லது துணைக்கு ஒரு குறிப்பை வழங்குகிறது.
    ///
    /// பாதுகாப்பான மாற்றாக [`get`] ஐப் பார்க்கவும்.
    ///
    /// # Safety
    ///
    /// இந்த முறையை எல்லைக்கு அப்பாற்பட்ட குறியீட்டுடன் அழைப்பது *[வரையறுக்கப்படாத நடத்தை]* இதன் விளைவாக வரும் குறிப்பு பயன்படுத்தப்படாவிட்டாலும் கூட.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // பாதுகாப்பு: அழைப்பாளர் `get_unchecked` க்கான பெரும்பாலான பாதுகாப்புத் தேவைகளை நிலைநிறுத்த வேண்டும்;
        // `self` ஒரு பாதுகாப்பான குறிப்பு என்பதால், துண்டு துண்டிக்க முடியாதது.
        // திரும்பிய சுட்டிக்காட்டி பாதுகாப்பானது, ஏனெனில் `SliceIndex` இன் impls அது என்று உத்தரவாதம் அளிக்க வேண்டும்.
        unsafe { &*index.get_unchecked(self) }
    }

    /// எல்லை சரிபார்ப்பு செய்யாமல், ஒரு உறுப்பு அல்லது துணைக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// பாதுகாப்பான மாற்றாக [`get_mut`] ஐப் பார்க்கவும்.
    ///
    /// # Safety
    ///
    /// இந்த முறையை எல்லைக்கு அப்பாற்பட்ட குறியீட்டுடன் அழைப்பது *[வரையறுக்கப்படாத நடத்தை]* இதன் விளைவாக வரும் குறிப்பு பயன்படுத்தப்படாவிட்டாலும் கூட.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // பாதுகாப்பு: அழைப்பாளர் `get_unchecked_mut` க்கான பாதுகாப்புத் தேவைகளை நிலைநிறுத்த வேண்டும்;
        // `self` ஒரு பாதுகாப்பான குறிப்பு என்பதால், துண்டு துண்டிக்க முடியாதது.
        // திரும்பிய சுட்டிக்காட்டி பாதுகாப்பானது, ஏனெனில் `SliceIndex` இன் impls அது என்று உத்தரவாதம் அளிக்க வேண்டும்.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// ஸ்லைஸின் இடையகத்திற்கு மூல சுட்டிக்காட்டி வழங்குகிறது.
    ///
    /// இந்த செயல்பாடு திரும்பும் சுட்டிக்காட்டிக்கு துண்டு அதிகமாக இருப்பதை அழைப்பவர் உறுதிப்படுத்த வேண்டும், இல்லையெனில் அது குப்பைகளை சுட்டிக்காட்டி முடிவடையும்.
    ///
    /// இந்த சுட்டிக்காட்டி அல்லது அதிலிருந்து பெறப்பட்ட எந்த ஒரு சுட்டியையும் பயன்படுத்தி (non-transitively) சுட்டிக்காட்டி நினைவகம் ஒருபோதும் (ஒரு `UnsafeCell` க்குள் தவிர) எழுதப்படவில்லை என்பதையும் அழைப்பாளர் உறுதிப்படுத்த வேண்டும்.
    /// ஸ்லைஸின் உள்ளடக்கங்களை நீங்கள் மாற்ற வேண்டும் என்றால், [`as_mut_ptr`] ஐப் பயன்படுத்தவும்.
    ///
    /// இந்த ஸ்லைஸால் குறிப்பிடப்பட்ட கொள்கலனை மாற்றியமைப்பது அதன் இடையகத்தை மறு ஒதுக்கீடு செய்யக்கூடும், இது எந்த சுட்டிகளையும் செல்லாது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// ஸ்லைஸின் இடையகத்திற்கு பாதுகாப்பற்ற மாற்றக்கூடிய சுட்டிக்காட்டி வழங்குகிறது.
    ///
    /// இந்த செயல்பாடு திரும்பும் சுட்டிக்காட்டிக்கு துண்டு அதிகமாக இருப்பதை அழைப்பவர் உறுதிப்படுத்த வேண்டும், இல்லையெனில் அது குப்பைகளை சுட்டிக்காட்டி முடிவடையும்.
    ///
    /// இந்த ஸ்லைஸால் குறிப்பிடப்பட்ட கொள்கலனை மாற்றியமைப்பது அதன் இடையகத்தை மறு ஒதுக்கீடு செய்யக்கூடும், இது எந்த சுட்டிகளையும் செல்லாது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// ஸ்லைஸில் பரவியிருக்கும் இரண்டு மூல சுட்டிகளை வழங்குகிறது.
    ///
    /// திரும்பிய வரம்பு அரை திறந்திருக்கும், இதன் பொருள் இறுதி சுட்டிக்காட்டி புள்ளிகள் *ஒரு கடந்த காலம்* ஸ்லைஸின் கடைசி உறுப்பு.
    /// இந்த வழியில், ஒரு வெற்று துண்டு இரண்டு சம சுட்டிகளால் குறிக்கப்படுகிறது, மேலும் இரண்டு சுட்டிகள் இடையே உள்ள வேறுபாடு துண்டுகளின் அளவைக் குறிக்கிறது.
    ///
    /// இந்த சுட்டிகளைப் பயன்படுத்துவதற்கான எச்சரிக்கைகளுக்கு [`as_ptr`] ஐப் பார்க்கவும்.இறுதி சுட்டிக்காட்டிக்கு கூடுதல் எச்சரிக்கை தேவைப்படுகிறது, ஏனெனில் இது துண்டில் சரியான உறுப்பை சுட்டிக்காட்டாது.
    ///
    /// சி ++ இல் பொதுவானது போல, நினைவகத்தில் உள்ள உறுப்புகளின் வரம்பைக் குறிக்க இரண்டு சுட்டிகளைப் பயன்படுத்தும் வெளிநாட்டு இடைமுகங்களுடன் தொடர்புகொள்வதற்கு இந்த செயல்பாடு பயனுள்ளதாக இருக்கும்.
    ///
    ///
    /// ஒரு உறுப்புக்கான சுட்டிக்காட்டி இந்த துண்டின் ஒரு உறுப்பைக் குறிக்கிறதா என்று சோதிக்கவும் இது பயனுள்ளதாக இருக்கும்:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // பாதுகாப்பு: இங்கே `add` பாதுகாப்பானது, ஏனெனில்:
        //
        //   - இரண்டு சுட்டிகளும் ஒரே பொருளின் ஒரு பகுதியாகும், ஏனெனில் பொருளை நேரடியாக கடந்தும் சுட்டிக்காட்டுகிறது.
        //
        //   - இங்கே குறிப்பிட்டுள்ளபடி, துண்டின் அளவு isize::MAX பைட்டுகளை விட பெரிதாக இருக்காது:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - முகவரி இடத்தின் முடிவில் துண்டுகள் மடிக்காததால், சம்பந்தப்பட்டவை எதுவும் இல்லை.
        //
        // pointer::add இன் ஆவணங்களைக் காண்க.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// துண்டில் பரவியிருக்கும் இரண்டு பாதுகாப்பற்ற மாற்றக்கூடிய சுட்டிகளை வழங்குகிறது.
    ///
    /// திரும்பிய வரம்பு அரை திறந்திருக்கும், இதன் பொருள் இறுதி சுட்டிக்காட்டி புள்ளிகள் *ஒரு கடந்த காலம்* ஸ்லைஸின் கடைசி உறுப்பு.
    /// இந்த வழியில், ஒரு வெற்று துண்டு இரண்டு சம சுட்டிகளால் குறிக்கப்படுகிறது, மேலும் இரண்டு சுட்டிகள் இடையே உள்ள வேறுபாடு துண்டுகளின் அளவைக் குறிக்கிறது.
    ///
    /// இந்த சுட்டிகளைப் பயன்படுத்துவதற்கான எச்சரிக்கைகளுக்கு [`as_mut_ptr`] ஐப் பார்க்கவும்.
    /// இறுதி சுட்டிக்காட்டிக்கு கூடுதல் எச்சரிக்கை தேவைப்படுகிறது, ஏனெனில் இது துண்டில் சரியான உறுப்பை சுட்டிக்காட்டாது.
    ///
    /// சி ++ இல் பொதுவானது போல, நினைவகத்தில் உள்ள உறுப்புகளின் வரம்பைக் குறிக்க இரண்டு சுட்டிகளைப் பயன்படுத்தும் வெளிநாட்டு இடைமுகங்களுடன் தொடர்புகொள்வதற்கு இந்த செயல்பாடு பயனுள்ளதாக இருக்கும்.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // பாதுகாப்பு: இங்கே `add` ஏன் பாதுகாப்பானது என்பதற்கு மேலே உள்ள as_ptr_range() ஐப் பார்க்கவும்.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// ஸ்லைஸில் இரண்டு கூறுகளை மாற்றுகிறது.
    ///
    /// # Arguments
    ///
    /// * a, முதல் தனிமத்தின் குறியீடு
    /// * b, இரண்டாவது தனிமத்தின் குறியீடு
    ///
    /// # Panics
    ///
    /// `a` அல்லது `b` எல்லைக்கு அப்பாற்பட்டால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // ஒரு vector இலிருந்து இரண்டு மாற்றக்கூடிய கடன்களை எடுக்க முடியாது, எனவே அதற்கு பதிலாக மூல சுட்டிகள் பயன்படுத்தவும்.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // பாதுகாப்பு: பாதுகாப்பான மாற்றக்கூடிய குறிப்புகளிலிருந்து `pa` மற்றும் `pb` ஆகியவை உருவாக்கப்பட்டுள்ளன மற்றும் பார்க்கவும்
        // ஸ்லைஸில் உள்ள உறுப்புகளுக்கு, எனவே செல்லுபடியாகும் மற்றும் சீரமைக்கப்படுவதாக உத்தரவாதம் அளிக்கப்படுகிறது.
        // `a` மற்றும் `b` க்குப் பின்னால் உள்ள உறுப்புகளை அணுகுவது சரிபார்க்கப்படுகிறது, மேலும் எல்லைக்கு வெளியே இருக்கும்போது panic இருக்கும்.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// ஸ்லைஸில் உள்ள தனிமங்களின் வரிசையை மாற்றியமைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // மிகச் சிறிய வகைகளுக்கு, சாதாரண பாதையில் உள்ள அனைத்து தனிப்பட்ட வாசிப்புகளும் மோசமாக செயல்படுகின்றன.
        // ஒரு பெரிய துண்டை ஏற்றுவதன் மூலமும், பதிவேட்டை மாற்றியமைப்பதன் மூலமும், திறமையாக வடிவமைக்கப்படாத load/store கொடுக்கப்பட்டால், நாங்கள் சிறப்பாகச் செய்ய முடியும்.
        //

        // எல்.எல்.வி.எம் இதை எங்களுக்காகச் செய்யும், ஏனெனில் வரிசைப்படுத்தப்படாத வாசிப்புகள் திறமையானவையா என்பதை விட எங்களுக்கு நன்றாகத் தெரியும் (வெவ்வேறு ARM பதிப்புகளுக்கு இடையில் மாற்றங்கள் இருப்பதால், எடுத்துக்காட்டாக) மற்றும் சிறந்த துண்டின் அளவு என்னவாக இருக்கும்.
        // துரதிர்ஷ்டவசமாக, LLVM 4.0 (2017-05) ஐப் பொறுத்தவரை இது சுழற்சியை மட்டுமே அவிழ்த்து விடுகிறது, எனவே இதை நாமே செய்ய வேண்டும்.
        // (கருதுகோள்: தலைகீழ் சிக்கலானது, ஏனெனில் பக்கங்களை வித்தியாசமாக சீரமைக்க முடியும்-நீளம் ஒற்றைப்படையாக இருக்கும்போது இருக்கும்-எனவே முன் மற்றும் பின்னிணைப்புகளை வெளியிடுவதற்கு வழி இல்லை-நடுவில் முழுமையாக சீரமைக்கப்பட்ட சிம்டைப் பயன்படுத்த.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // ஒரு பயன்பாட்டில் u8 களை மாற்ற llvm.bswap உள்ளார்ந்த பயன்படுத்தவும்
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // பாதுகாப்பு: இங்கே சரிபார்க்க பல விஷயங்கள் உள்ளன:
                //
                // - மேலே உள்ள cfg காசோலை காரணமாக `chunk` 4 அல்லது 8 என்பதை நினைவில் கொள்க.எனவே `chunk - 1` நேர்மறையானது.
                // - லூப் காசோலை உத்தரவாதம் அளிப்பதால் குறியீட்டு `i` உடன் குறியீட்டு முறை நன்றாக உள்ளது
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - குறியீட்டு `ln - i - chunk = ln - (i + chunk)` உடன் அட்டவணைப்படுத்தல் நன்றாக உள்ளது:
                //   - `i + chunk > 0` அற்பமான உண்மை.
                //   - லூப் காசோலை உத்தரவாதம்:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, இதனால் கழித்தல் பாயவில்லை.
                // - `read_unaligned` மற்றும் `write_unaligned` அழைப்புகள் நன்றாக உள்ளன:
                //   - `pa` குறியீட்டு `i` க்கு புள்ளிகள், அங்கு `i < ln / 2 - (chunk - 1)` (மேலே காண்க) மற்றும் `pb` குறியீட்டு `ln - i - chunk` க்கு புள்ளிகள், எனவே இரண்டும் குறைந்தது `chunk` பல பைட்டுகள் `self` இன் முடிவிலிருந்து தொலைவில் உள்ளன.
                //
                //   - எந்த துவக்கப்பட்ட நினைவகமும் செல்லுபடியாகும் `usize` ஆகும்.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // ஒரு u32 இல் u16 களைத் திருப்ப சுழற்சி-மூலம்-16 ஐப் பயன்படுத்தவும்
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // பாதுகாப்பு: எக்ஸ் 00 எக்ஸ் என்றால் எக்ஸ் 02 எக்ஸ் இலிருந்து வரிசைப்படுத்தப்படாத எக்ஸ் 01 எக்ஸ் படிக்க முடியும்
                // (மற்றும் வெளிப்படையாக `i < ln`), ஏனென்றால் ஒவ்வொரு உறுப்பு 2 பைட்டுகள் மற்றும் நாங்கள் 4 ஐப் படிக்கிறோம்.
                //
                // `i + chunk - 1 < ln / 2` # நிலை இருக்கும்போது
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // இது 2 ஆல் வகுக்கப்பட்ட நீளத்தை விட குறைவாக இருப்பதால், அது எல்லைகளில் இருக்க வேண்டும்.
                //
                // `0 < i + chunk <= ln` என்ற நிபந்தனை எப்போதும் மதிக்கப்படுவதாகவும், `pb` சுட்டிக்காட்டி பாதுகாப்பாகப் பயன்படுத்தப்படுவதை உறுதிசெய்கிறது என்பதும் இதன் பொருள்.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // பாதுகாப்பு: `i` ஸ்லைஸின் பாதி நீளத்தை விட தாழ்வானது
            // `i` மற்றும் `ln - i - 1` ஐ அணுகுவது பாதுகாப்பானது (`i` 0 இல் தொடங்குகிறது மற்றும் `ln / 2 - 1` ஐ விட அதிகமாக செல்லாது).
            // இதன் விளைவாக வரும் சுட்டிகள் `pa` மற்றும் `pb` ஆகியவை செல்லுபடியாகும் மற்றும் சீரமைக்கப்படுகின்றன, மேலும் அவற்றிலிருந்து படிக்கலாம் மற்றும் எழுதலாம்.
            //
            //
            unsafe {
                // பாதுகாப்பான இடமாற்றத்தில் எல்லைகள் சரிபார்க்கப்படுவதைத் தவிர்க்க பாதுகாப்பற்ற இடமாற்று.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// துண்டுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// ஒவ்வொரு மதிப்பையும் மாற்ற அனுமதிக்கும் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// அனைத்து தொடர்ச்சியான windows நீளம் `size` க்கும் மேலாக ஒரு ஈரேட்டரை வழங்குகிறது.
    /// windows ஒன்றுடன் ஒன்று.
    /// ஸ்லைஸ் `size` ஐ விடக் குறைவாக இருந்தால், ஈரேட்டர் எந்த மதிப்புகளையும் அளிக்காது.
    ///
    /// # Panics
    ///
    /// `size` 0 என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ஸ்லைஸ் `size` ஐ விடக் குறைவாக இருந்தால்:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// ஸ்லைஸின் தொடக்கத்தில் தொடங்கி, ஒரு நேரத்தில் ஸ்லைஸின் `chunk_size` உறுப்புகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// துகள்கள் துண்டுகள் மற்றும் ஒன்றுடன் ஒன்று இல்லை.`chunk_size` ஸ்லைஸின் நீளத்தைப் பிரிக்கவில்லை என்றால், கடைசி துண்டின் நீளம் `chunk_size` இருக்காது.
    ///
    /// இந்த ஈரேட்டரின் மாறுபாட்டிற்காக [`chunks_exact`] ஐப் பார்க்கவும், அது எப்போதும் சரியாக `chunk_size` உறுப்புகளின் துகள்களையும், அதே ஈரேட்டருக்கு [`rchunks`] ஐயும் தருகிறது, ஆனால் ஸ்லைஸின் முடிவில் தொடங்குகிறது.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// ஸ்லைஸின் தொடக்கத்தில் தொடங்கி, ஒரு நேரத்தில் ஸ்லைஸின் `chunk_size` உறுப்புகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// துகள்கள் மாற்றக்கூடிய துண்டுகள், அவை ஒன்றுடன் ஒன்று இல்லை.`chunk_size` ஸ்லைஸின் நீளத்தைப் பிரிக்கவில்லை என்றால், கடைசி துண்டின் நீளம் `chunk_size` இருக்காது.
    ///
    /// இந்த ஈரேட்டரின் மாறுபாட்டிற்காக [`chunks_exact_mut`] ஐப் பார்க்கவும், அது எப்போதும் சரியாக `chunk_size` உறுப்புகளின் துகள்களையும், அதே ஈரேட்டருக்கு [`rchunks_mut`] ஐயும் தருகிறது, ஆனால் ஸ்லைஸின் முடிவில் தொடங்குகிறது.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// ஸ்லைஸின் தொடக்கத்தில் தொடங்கி, ஒரு நேரத்தில் ஸ்லைஸின் `chunk_size` உறுப்புகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// துகள்கள் துண்டுகள் மற்றும் ஒன்றுடன் ஒன்று இல்லை.
    /// `chunk_size` ஸ்லைஸின் நீளத்தைப் பிரிக்கவில்லை என்றால், கடைசியாக `chunk_size-1` கூறுகள் தவிர்க்கப்படும், மேலும் இது ஈரேட்டரின் `remainder` செயல்பாட்டிலிருந்து மீட்டெடுக்கப்படலாம்.
    ///
    ///
    /// ஒவ்வொரு துண்டிலும் சரியாக `chunk_size` கூறுகள் இருப்பதால், கம்பைலர் பெரும்பாலும் [`chunks`] ஐ விட சிறந்த குறியீட்டை மேம்படுத்தலாம்.
    ///
    /// இந்த ஈரேட்டரின் மாறுபாட்டிற்காக [`chunks`] ஐப் பார்க்கவும், மீதமுள்ளதை சிறிய துண்டாகவும், அதே ஈரேட்டருக்கு [`rchunks_exact`] ஐயும் தருகிறது, ஆனால் ஸ்லைஸின் முடிவில் தொடங்குகிறது.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// ஸ்லைஸின் தொடக்கத்தில் தொடங்கி, ஒரு நேரத்தில் ஸ்லைஸின் `chunk_size` உறுப்புகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// துகள்கள் மாற்றக்கூடிய துண்டுகள், அவை ஒன்றுடன் ஒன்று இல்லை.
    /// `chunk_size` ஸ்லைஸின் நீளத்தைப் பிரிக்கவில்லை என்றால், கடைசியாக `chunk_size-1` கூறுகள் தவிர்க்கப்படும், மேலும் இது ஈரேட்டரின் `into_remainder` செயல்பாட்டிலிருந்து மீட்டெடுக்கப்படலாம்.
    ///
    ///
    /// ஒவ்வொரு துண்டிலும் சரியாக `chunk_size` கூறுகள் இருப்பதால், கம்பைலர் பெரும்பாலும் [`chunks_mut`] ஐ விட சிறந்த குறியீட்டை மேம்படுத்தலாம்.
    ///
    /// இந்த ஈரேட்டரின் மாறுபாட்டிற்காக [`chunks_mut`] ஐப் பார்க்கவும், மீதமுள்ளதை சிறிய துண்டாகவும், அதே ஈரேட்டருக்கு [`rchunks_exact_mut`] ஐயும் தருகிறது, ஆனால் ஸ்லைஸின் முடிவில் தொடங்குகிறது.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// ஸ்லைஸை `N`-உறுப்பு வரிசைகளின் துண்டுகளாகப் பிரிக்கிறது, மீதமுள்ள எதுவும் இல்லை என்று கருதி.
    ///
    ///
    /// # Safety
    ///
    /// இது எப்போது என்று அழைக்கப்படலாம்
    /// - துண்டு சரியாக `N`-உறுப்பு துகள்களாக (aka `self.len() % N == 0`)) பிரிக்கிறது.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // பாதுகாப்பு: 1-உறுப்பு துகள்கள் ஒருபோதும் எஞ்சியிருக்காது
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // பாதுகாப்பு: ஸ்லைஸ் நீளம் (6) 3 இன் பெருக்கமாகும்
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // இவை ஆதாரமற்றவை:
    /// // துண்டாக விடுங்கள்: &[[_;5]]= slice.as_chunks_unchecked()//ஸ்லைஸ் நீளம் 5 லெட் துகள்களின் பெருக்கமல்ல:&[[_;0]]= slice.as_chunks_unchecked()//பூஜ்ஜிய நீள துண்டுகள் ஒருபோதும் அனுமதிக்கப்படாது
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // பாதுகாப்பு: இதை அழைக்க எங்கள் முன்நிபந்தனை சரியாக தேவை
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // பாதுகாப்பு: நாங்கள் `new_len * N` உறுப்புகளின் ஒரு துண்டுகளை இடுகிறோம்
        // `new_len` இன் ஒரு துண்டு பல `N` கூறுகள் துகள்கள்.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// ஸ்லைஸின் தொடக்கத்தில் தொடங்கி, `N`-உறுப்பு வரிசைகளின் துண்டுகளாகவும், மீதமுள்ள துண்டு `N` ஐ விடக் குறைவான நீளமாகவும் பிரிக்கிறது.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ஆக இருந்தால் Panics. இந்த முறை உறுதிப்படுத்தப்படுவதற்கு முன்பு இந்த காசோலை தொகுக்கும் நேர பிழையாக மாற்றப்படும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // பாதுகாப்பு: நாங்கள் ஏற்கனவே பூஜ்ஜியத்திற்கு பீதியடைந்தோம், மேலும் கட்டுமானத்தால் உறுதி செய்யப்பட்டோம்
        // சந்தாவின் நீளம் N இன் பெருக்கமாகும்.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// ஸ்லைஸின் முடிவில் தொடங்கி, `N`-உறுப்பு வரிசைகளின் துண்டுகளாகவும், மீதமுள்ள துண்டு `N` ஐ விடக் குறைவான நீளமாகவும் பிரிக்கிறது.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ஆக இருந்தால் Panics. இந்த முறை உறுதிப்படுத்தப்படுவதற்கு முன்பு இந்த காசோலை தொகுக்கும் நேர பிழையாக மாற்றப்படும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // பாதுகாப்பு: நாங்கள் ஏற்கனவே பூஜ்ஜியத்திற்கு பீதியடைந்தோம், மேலும் கட்டுமானத்தால் உறுதி செய்யப்பட்டோம்
        // சந்தாவின் நீளம் N இன் பெருக்கமாகும்.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// ஸ்லைஸின் தொடக்கத்தில் தொடங்கி, ஒரு நேரத்தில் ஸ்லைஸின் `N` உறுப்புகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// துகள்கள் வரிசை குறிப்புகள் மற்றும் ஒன்றுடன் ஒன்று இல்லை.
    /// `N` ஸ்லைஸின் நீளத்தைப் பிரிக்கவில்லை என்றால், கடைசியாக `N-1` கூறுகள் தவிர்க்கப்படும், மேலும் இது ஈரேட்டரின் `remainder` செயல்பாட்டிலிருந்து மீட்டெடுக்கப்படலாம்.
    ///
    ///
    /// இந்த முறை [`chunks_exact`] க்கு சமமான பொதுவான பொதுவானதாகும்.
    ///
    /// # Panics
    ///
    /// `N` 0 ஆக இருந்தால் Panics. இந்த முறை உறுதிப்படுத்தப்படுவதற்கு முன்பு இந்த காசோலை தொகுக்கும் நேர பிழையாக மாற்றப்படும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// ஸ்லைஸை `N`-உறுப்பு வரிசைகளின் துண்டுகளாகப் பிரிக்கிறது, மீதமுள்ள எதுவும் இல்லை என்று கருதி.
    ///
    ///
    /// # Safety
    ///
    /// இது எப்போது என்று அழைக்கப்படலாம்
    /// - துண்டு சரியாக `N`-உறுப்பு துகள்களாக (aka `self.len() % N == 0`)) பிரிக்கிறது.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // பாதுகாப்பு: 1-உறுப்பு துகள்கள் ஒருபோதும் எஞ்சியிருக்காது
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // பாதுகாப்பு: ஸ்லைஸ் நீளம் (6) 3 இன் பெருக்கமாகும்
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // இவை ஆதாரமற்றவை:
    /// // துண்டாக விடுங்கள்: &[[_;5]]= slice.as_chunks_unchecked_mut()//ஸ்லைஸ் நீளம் 5 லெட் துகள்களின் பெருக்கமல்ல:&[[_;0]]= slice.as_chunks_unchecked_mut()//பூஜ்ஜிய நீள துண்டுகள் ஒருபோதும் அனுமதிக்கப்படாது
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // பாதுகாப்பு: இதை அழைக்க எங்கள் முன்நிபந்தனை சரியாக தேவை
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // பாதுகாப்பு: நாங்கள் `new_len * N` உறுப்புகளின் ஒரு துண்டுகளை இடுகிறோம்
        // `new_len` இன் ஒரு துண்டு பல `N` கூறுகள் துகள்கள்.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// ஸ்லைஸின் தொடக்கத்தில் தொடங்கி, `N`-உறுப்பு வரிசைகளின் துண்டுகளாகவும், மீதமுள்ள துண்டு `N` ஐ விடக் குறைவான நீளமாகவும் பிரிக்கிறது.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ஆக இருந்தால் Panics. இந்த முறை உறுதிப்படுத்தப்படுவதற்கு முன்பு இந்த காசோலை தொகுக்கும் நேர பிழையாக மாற்றப்படும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // பாதுகாப்பு: நாங்கள் ஏற்கனவே பூஜ்ஜியத்திற்கு பீதியடைந்தோம், மேலும் கட்டுமானத்தால் உறுதி செய்யப்பட்டோம்
        // சந்தாவின் நீளம் N இன் பெருக்கமாகும்.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// ஸ்லைஸின் முடிவில் தொடங்கி, `N`-உறுப்பு வரிசைகளின் துண்டுகளாகவும், மீதமுள்ள துண்டு `N` ஐ விடக் குறைவான நீளமாகவும் பிரிக்கிறது.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ஆக இருந்தால் Panics. இந்த முறை உறுதிப்படுத்தப்படுவதற்கு முன்பு இந்த காசோலை தொகுக்கும் நேர பிழையாக மாற்றப்படும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // பாதுகாப்பு: நாங்கள் ஏற்கனவே பூஜ்ஜியத்திற்கு பீதியடைந்தோம், மேலும் கட்டுமானத்தால் உறுதி செய்யப்பட்டோம்
        // சந்தாவின் நீளம் N இன் பெருக்கமாகும்.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// ஸ்லைஸின் தொடக்கத்தில் தொடங்கி, ஒரு நேரத்தில் ஸ்லைஸின் `N` உறுப்புகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// துகள்கள் மாற்றக்கூடிய வரிசை குறிப்புகள் மற்றும் ஒன்றுடன் ஒன்று இல்லை.
    /// `N` ஸ்லைஸின் நீளத்தைப் பிரிக்கவில்லை என்றால், கடைசியாக `N-1` கூறுகள் தவிர்க்கப்படும், மேலும் இது ஈரேட்டரின் `into_remainder` செயல்பாட்டிலிருந்து மீட்டெடுக்கப்படலாம்.
    ///
    ///
    /// இந்த முறை [`chunks_exact_mut`] க்கு சமமான பொதுவான பொதுவானதாகும்.
    ///
    /// # Panics
    ///
    /// `N` 0 ஆக இருந்தால் Panics. இந்த முறை உறுதிப்படுத்தப்படுவதற்கு முன்பு இந்த காசோலை தொகுக்கும் நேர பிழையாக மாற்றப்படும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// ஒரு துண்டின் `N` உறுப்புகளின் windows ஐ ஒன்றுடன் ஒன்று சேர்ப்பதன் மூலம் ஒரு ஐரேட்டரை வழங்குகிறது, இது ஸ்லைஸின் தொடக்கத்தில் தொடங்கி.
    ///
    ///
    /// இது [`windows`] க்கு சமமான பொதுவான பொதுவானதாகும்.
    ///
    /// `N` ஸ்லைஸின் அளவை விட அதிகமாக இருந்தால், அது windows இல்லை.
    ///
    /// # Panics
    ///
    /// `N` 0 என்றால் Panics.
    /// இந்த முறை உறுதிப்படுத்தப்படுவதற்கு முன்பு இந்த காசோலை தொகுக்கும் நேர பிழையாக மாற்றப்படும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// ஸ்லைஸின் முடிவில் தொடங்கி, ஒரு நேரத்தில் ஸ்லைஸின் `chunk_size` உறுப்புகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// துகள்கள் துண்டுகள் மற்றும் ஒன்றுடன் ஒன்று இல்லை.`chunk_size` ஸ்லைஸின் நீளத்தைப் பிரிக்கவில்லை என்றால், கடைசி துண்டின் நீளம் `chunk_size` இருக்காது.
    ///
    /// இந்த ஈரேட்டரின் மாறுபாட்டிற்காக [`rchunks_exact`] ஐப் பார்க்கவும், அது எப்போதும் சரியாக `chunk_size` உறுப்புகளின் துகள்களையும், அதே ஈரேட்டருக்கு [`chunks`] ஐயும் தருகிறது, ஆனால் ஸ்லைஸின் தொடக்கத்தில் தொடங்குகிறது.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// ஸ்லைஸின் முடிவில் தொடங்கி, ஒரு நேரத்தில் ஸ்லைஸின் `chunk_size` உறுப்புகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// துகள்கள் மாற்றக்கூடிய துண்டுகள், அவை ஒன்றுடன் ஒன்று இல்லை.`chunk_size` ஸ்லைஸின் நீளத்தைப் பிரிக்கவில்லை என்றால், கடைசி துண்டின் நீளம் `chunk_size` இருக்காது.
    ///
    /// இந்த ஈரேட்டரின் மாறுபாட்டிற்காக [`rchunks_exact_mut`] ஐப் பார்க்கவும், அது எப்போதும் சரியாக `chunk_size` உறுப்புகளின் துகள்களையும், அதே ஈரேட்டருக்கு [`chunks_mut`] ஐயும் தருகிறது, ஆனால் ஸ்லைஸின் தொடக்கத்தில் தொடங்குகிறது.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// ஸ்லைஸின் முடிவில் தொடங்கி, ஒரு நேரத்தில் ஸ்லைஸின் `chunk_size` உறுப்புகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// துகள்கள் துண்டுகள் மற்றும் ஒன்றுடன் ஒன்று இல்லை.
    /// `chunk_size` ஸ்லைஸின் நீளத்தைப் பிரிக்கவில்லை என்றால், கடைசியாக `chunk_size-1` கூறுகள் தவிர்க்கப்படும், மேலும் இது ஈரேட்டரின் `remainder` செயல்பாட்டிலிருந்து மீட்டெடுக்கப்படலாம்.
    ///
    /// ஒவ்வொரு துண்டிலும் சரியாக `chunk_size` கூறுகள் இருப்பதால், கம்பைலர் பெரும்பாலும் [`chunks`] ஐ விட சிறந்த குறியீட்டை மேம்படுத்தலாம்.
    ///
    /// இந்த ஈரேட்டரின் மாறுபாட்டிற்காக [`rchunks`] ஐப் பார்க்கவும், மீதமுள்ளதை சிறிய துண்டாகவும், அதே ஈரேட்டருக்கு [`chunks_exact`] ஐயும் தருகிறது, ஆனால் ஸ்லைஸின் தொடக்கத்தில் தொடங்குகிறது.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// ஸ்லைஸின் முடிவில் தொடங்கி, ஒரு நேரத்தில் ஸ்லைஸின் `chunk_size` உறுப்புகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// துகள்கள் மாற்றக்கூடிய துண்டுகள், அவை ஒன்றுடன் ஒன்று இல்லை.
    /// `chunk_size` ஸ்லைஸின் நீளத்தைப் பிரிக்கவில்லை என்றால், கடைசியாக `chunk_size-1` கூறுகள் தவிர்க்கப்படும், மேலும் இது ஈரேட்டரின் `into_remainder` செயல்பாட்டிலிருந்து மீட்டெடுக்கப்படலாம்.
    ///
    /// ஒவ்வொரு துண்டிலும் சரியாக `chunk_size` கூறுகள் இருப்பதால், கம்பைலர் பெரும்பாலும் [`chunks_mut`] ஐ விட சிறந்த குறியீட்டை மேம்படுத்தலாம்.
    ///
    /// இந்த ஈரேட்டரின் மாறுபாட்டிற்காக [`rchunks_mut`] ஐப் பார்க்கவும், மீதமுள்ளதை சிறிய துண்டாகவும், அதே ஈரேட்டருக்கு [`chunks_exact_mut`] ஐயும் தருகிறது, ஆனால் ஸ்லைஸின் தொடக்கத்தில் தொடங்குகிறது.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// தனிமங்களை பிரிக்க முன்னறிவிப்பைப் பயன்படுத்தி ஒன்றுடன் ஒன்று அல்லாத ஓடுகளை உருவாக்கும் ஸ்லைஸ் மீது ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// முன்னறிவிப்பு தங்களைத் தொடர்ந்து வரும் இரண்டு கூறுகளில் அழைக்கப்படுகிறது, இதன் பொருள் முன்கணிப்பு `slice[0]` மற்றும் `slice[1]` இல் அழைக்கப்படுகிறது, பின்னர் `slice[1]` மற்றும் `slice[2]` மற்றும் பலவற்றில் அழைக்கப்படுகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// வரிசைப்படுத்தப்பட்ட சந்தாக்களைப் பிரித்தெடுக்க இந்த முறையைப் பயன்படுத்தலாம்:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// தனிமங்களை பிரிக்க முன்னறிவிப்பைப் பயன்படுத்தி ஒன்றுடன் ஒன்று மாற்றப்படாத மாற்றக்கூடிய ரன்களை உருவாக்கும் ஸ்லைஸின் மீது ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// முன்னறிவிப்பு தங்களைத் தொடர்ந்து வரும் இரண்டு கூறுகளில் அழைக்கப்படுகிறது, இதன் பொருள் முன்கணிப்பு `slice[0]` மற்றும் `slice[1]` இல் அழைக்கப்படுகிறது, பின்னர் `slice[1]` மற்றும் `slice[2]` மற்றும் பலவற்றில் அழைக்கப்படுகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// வரிசைப்படுத்தப்பட்ட சந்தாக்களைப் பிரித்தெடுக்க இந்த முறையைப் பயன்படுத்தலாம்:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// ஒரு குறியீட்டில் ஒரு துண்டுகளை இரண்டாகப் பிரிக்கிறது.
    ///
    /// முதலாவது `[0, mid)` இலிருந்து அனைத்து குறியீடுகளையும் கொண்டிருக்கும் (குறியீட்டு `mid` ஐத் தவிர) மற்றும் இரண்டாவது `[mid, len)` இலிருந்து அனைத்து குறியீடுகளையும் கொண்டிருக்கும் (குறியீட்டு `len` ஐத் தவிர).
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // பாதுகாப்பு: `[ptr; mid]` மற்றும் `[mid; len]` ஆகியவை `self` க்குள் உள்ளன, அவை
        // `from_raw_parts_mut` இன் தேவைகளை பூர்த்தி செய்கிறது.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// ஒரு குறியீட்டு இடத்தில் ஒரு மாற்றக்கூடிய துண்டுகளை இரண்டாகப் பிரிக்கிறது.
    ///
    /// முதலாவது `[0, mid)` இலிருந்து அனைத்து குறியீடுகளையும் கொண்டிருக்கும் (குறியீட்டு `mid` ஐத் தவிர) மற்றும் இரண்டாவது `[mid, len)` இலிருந்து அனைத்து குறியீடுகளையும் கொண்டிருக்கும் (குறியீட்டு `len` ஐத் தவிர).
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // பாதுகாப்பு: `[ptr; mid]` மற்றும் `[mid; len]` ஆகியவை `self` க்குள் உள்ளன, அவை
        // `from_raw_parts_mut` இன் தேவைகளை பூர்த்தி செய்கிறது.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// எல்லைகளைச் சரிபார்க்காமல், ஒரு குறியீட்டை ஒரு குறியீட்டில் இரண்டாகப் பிரிக்கிறது.
    ///
    /// முதலாவது `[0, mid)` இலிருந்து அனைத்து குறியீடுகளையும் கொண்டிருக்கும் (குறியீட்டு `mid` ஐத் தவிர) மற்றும் இரண்டாவது `[mid, len)` இலிருந்து அனைத்து குறியீடுகளையும் கொண்டிருக்கும் (குறியீட்டு `len` ஐத் தவிர).
    ///
    ///
    /// பாதுகாப்பான மாற்றாக [`split_at`] ஐப் பார்க்கவும்.
    ///
    /// # Safety
    ///
    /// இந்த முறையை எல்லைக்கு அப்பாற்பட்ட குறியீட்டுடன் அழைப்பது *[வரையறுக்கப்படாத நடத்தை]* இதன் விளைவாக வரும் குறிப்பு பயன்படுத்தப்படாவிட்டாலும் கூட.அழைப்பவர் `0 <= mid <= self.len()` என்பதை உறுதிப்படுத்த வேண்டும்.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // பாதுகாப்பு: அழைப்பாளர் அந்த `0 <= mid <= self.len()` ஐ சரிபார்க்க வேண்டும்
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// எல்லைகளைச் சரிபார்க்காமல், ஒரு மாற்றக்கூடிய துண்டுகளை ஒரு குறியீட்டில் இரண்டாகப் பிரிக்கிறது.
    ///
    /// முதலாவது `[0, mid)` இலிருந்து அனைத்து குறியீடுகளையும் கொண்டிருக்கும் (குறியீட்டு `mid` ஐத் தவிர) மற்றும் இரண்டாவது `[mid, len)` இலிருந்து அனைத்து குறியீடுகளையும் கொண்டிருக்கும் (குறியீட்டு `len` ஐத் தவிர).
    ///
    ///
    /// பாதுகாப்பான மாற்றாக [`split_at_mut`] ஐப் பார்க்கவும்.
    ///
    /// # Safety
    ///
    /// இந்த முறையை எல்லைக்கு அப்பாற்பட்ட குறியீட்டுடன் அழைப்பது *[வரையறுக்கப்படாத நடத்தை]* இதன் விளைவாக வரும் குறிப்பு பயன்படுத்தப்படாவிட்டாலும் கூட.அழைப்பவர் `0 <= mid <= self.len()` என்பதை உறுதிப்படுத்த வேண்டும்.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // பாதுகாப்பு: அழைப்பாளர் அந்த `0 <= mid <= self.len()` ஐ சரிபார்க்க வேண்டும்.
        //
        // `[ptr; mid]` மற்றும் `[mid; len]` ஒன்றுடன் ஒன்று இல்லை, எனவே மாற்றக்கூடிய குறிப்பைத் திருப்புவது நல்லது.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred` உடன் பொருந்தக்கூடிய உறுப்புகளால் பிரிக்கப்பட்ட சந்தாக்களின் மீது ஒரு ஈரேட்டரை வழங்குகிறது.
    /// பொருந்திய உறுப்பு சந்தாக்களில் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// முதல் உறுப்பு பொருந்தினால், வெற்று துண்டு என்பது ஈரேட்டரால் திரும்பிய முதல் உருப்படியாக இருக்கும்.
    /// இதேபோல், ஸ்லைஸில் உள்ள கடைசி உறுப்பு பொருந்தினால், வெற்று துண்டு என்பது ஈரேட்டரால் வழங்கப்பட்ட கடைசி உருப்படியாக இருக்கும்:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// பொருந்திய இரண்டு கூறுகள் நேரடியாக அருகில் இருந்தால், அவற்றுக்கிடையே ஒரு வெற்று துண்டு இருக்கும்:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred` உடன் பொருந்தக்கூடிய உறுப்புகளால் பிரிக்கப்பட்ட மாற்றக்கூடிய சந்தாக்களின் மீது ஒரு ஈரேட்டரை வழங்குகிறது.
    /// பொருந்திய உறுப்பு சந்தாக்களில் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred` உடன் பொருந்தக்கூடிய உறுப்புகளால் பிரிக்கப்பட்ட சந்தாக்களின் மீது ஒரு ஈரேட்டரை வழங்குகிறது.
    /// பொருந்திய உறுப்பு முந்தைய சப்ளைஸின் முடிவில் ஒரு டெர்மினேட்டராக உள்ளது.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ஸ்லைஸின் கடைசி உறுப்பு பொருந்தினால், அந்த உறுப்பு முந்தைய துண்டுகளின் டெர்மினேட்டராக கருதப்படும்.
    ///
    /// அந்த துண்டு, செயலி வழங்கிய கடைசி உருப்படியாக இருக்கும்.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred` உடன் பொருந்தக்கூடிய உறுப்புகளால் பிரிக்கப்பட்ட மாற்றக்கூடிய சந்தாக்களின் மீது ஒரு ஈரேட்டரை வழங்குகிறது.
    /// பொருந்திய உறுப்பு முந்தைய சப்ளைஸில் ஒரு டெர்மினேட்டராக உள்ளது.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// `pred` உடன் பொருந்தக்கூடிய உறுப்புகளால் பிரிக்கப்பட்ட சந்தாக்களின் மீது ஒரு ஐரேட்டரை வழங்குகிறது, இது ஸ்லைஸின் முடிவில் தொடங்கி பின்னோக்கி வேலை செய்கிறது.
    /// பொருந்திய உறுப்பு சந்தாக்களில் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()` ஐப் போலவே, முதல் அல்லது கடைசி உறுப்பு பொருந்தினால், வெற்று துண்டு, ஈரேட்டரால் திரும்பிய முதல் (அல்லது கடைசி) உருப்படியாக இருக்கும்.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// `pred` உடன் பொருந்தக்கூடிய உறுப்புகளால் பிரிக்கப்பட்ட மாற்றக்கூடிய சந்தாக்களின் மீது ஒரு ஈரேட்டரை வழங்குகிறது, இது ஸ்லைஸின் முடிவில் தொடங்கி பின்னோக்கி வேலை செய்கிறது.
    /// பொருந்திய உறுப்பு சந்தாக்களில் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// `pred` உடன் பொருந்தக்கூடிய உறுப்புகளால் பிரிக்கப்பட்ட சந்தாக்களின் மீது ஒரு ஈரேட்டரை வழங்குகிறது, இது பெரும்பாலான `n` உருப்படிகளுக்குத் திரும்புவதற்கு மட்டுப்படுத்தப்பட்டுள்ளது.
    /// பொருந்திய உறுப்பு சந்தாக்களில் இல்லை.
    ///
    /// திரும்பிய கடைசி உறுப்பு, ஏதேனும் இருந்தால், துண்டின் எஞ்சியிருக்கும்.
    ///
    /// # Examples
    ///
    /// ஸ்லைஸ் பிளவை 3 ஆல் வகுக்கக்கூடிய எண்களால் ஒரு முறை அச்சிடுக (அதாவது, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// `pred` உடன் பொருந்தக்கூடிய உறுப்புகளால் பிரிக்கப்பட்ட சந்தாக்களின் மீது ஒரு ஈரேட்டரை வழங்குகிறது, இது பெரும்பாலான `n` உருப்படிகளுக்குத் திரும்புவதற்கு மட்டுப்படுத்தப்பட்டுள்ளது.
    /// பொருந்திய உறுப்பு சந்தாக்களில் இல்லை.
    ///
    /// திரும்பிய கடைசி உறுப்பு, ஏதேனும் இருந்தால், துண்டின் எஞ்சியிருக்கும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// `pred` உடன் பொருந்தக்கூடிய உறுப்புகளால் பிரிக்கப்பட்ட சந்தாக்களின் மீது ஒரு ஈரேட்டரை வழங்குகிறது, இது பெரும்பாலான `n` உருப்படிகளுக்கு திரும்புவதற்கு வரையறுக்கப்பட்டுள்ளது.
    /// இது துண்டின் முடிவில் தொடங்கி பின்னோக்கி வேலை செய்கிறது.
    /// பொருந்திய உறுப்பு சந்தாக்களில் இல்லை.
    ///
    /// திரும்பிய கடைசி உறுப்பு, ஏதேனும் இருந்தால், துண்டின் எஞ்சியிருக்கும்.
    ///
    /// # Examples
    ///
    /// ஸ்லைஸ் பிளவை ஒரு முறை அச்சிடுக, முடிவில் இருந்து தொடங்கி, 3 ஆல் வகுக்கக்கூடிய எண்களால் (அதாவது, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// `pred` உடன் பொருந்தக்கூடிய உறுப்புகளால் பிரிக்கப்பட்ட சந்தாக்களின் மீது ஒரு ஈரேட்டரை வழங்குகிறது, இது பெரும்பாலான `n` உருப்படிகளுக்கு திரும்புவதற்கு வரையறுக்கப்பட்டுள்ளது.
    /// இது துண்டின் முடிவில் தொடங்கி பின்னோக்கி வேலை செய்கிறது.
    /// பொருந்திய உறுப்பு சந்தாக்களில் இல்லை.
    ///
    /// திரும்பிய கடைசி உறுப்பு, ஏதேனும் இருந்தால், துண்டின் எஞ்சியிருக்கும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// துண்டில் கொடுக்கப்பட்ட மதிப்புடன் ஒரு உறுப்பு இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// உங்களிடம் `&T` இல்லை என்றால், ஆனால் `T: Borrow<U>` போன்ற ஒரு `&U` (எ.கா.
    /// `சரம்: கடன்<str>`), நீங்கள் `iter().any` ஐப் பயன்படுத்தலாம்:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` துண்டு
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` உடன் தேடுங்கள்
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `needle` என்பது ஸ்லைஸின் முன்னொட்டு என்றால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// `needle` ஒரு வெற்று துண்டாக இருந்தால் எப்போதும் `true` ஐ வழங்குகிறது:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// `needle` என்பது ஸ்லைஸின் பின்னொட்டு என்றால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// `needle` ஒரு வெற்று துண்டாக இருந்தால் எப்போதும் `true` ஐ வழங்குகிறது:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// அகற்றப்பட்ட முன்னொட்டுடன் ஒரு சந்தாவை வழங்குகிறது.
    ///
    /// ஸ்லைஸ் `prefix` உடன் தொடங்கினால், `Some` இல் மூடப்பட்டிருக்கும் முன்னொட்டுக்குப் பிறகு சந்தாவை வழங்குகிறது.
    /// `prefix` காலியாக இருந்தால், அசல் துண்டுகளை மட்டும் தருகிறது.
    ///
    /// ஸ்லைஸ் `prefix` உடன் தொடங்கவில்லை என்றால், `None` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // ஸ்லைஸ் பேட்டர்ன் மிகவும் சிக்கலானதாக மாறும்போது, இந்த செயல்பாட்டை மீண்டும் எழுத வேண்டும்.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// நீக்கப்பட்ட பின்னொட்டுடன் ஒரு சந்தாவை வழங்குகிறது.
    ///
    /// ஸ்லைஸ் `suffix` உடன் முடிவடைந்தால், `Some` இல் மூடப்பட்ட பின்னொட்டுக்கு முன் சந்தாவை வழங்குகிறது.
    /// `suffix` காலியாக இருந்தால், அசல் துண்டுகளை மட்டும் தருகிறது.
    ///
    /// ஸ்லைஸ் `suffix` உடன் முடிவடையவில்லை என்றால், `None` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // ஸ்லைஸ் பேட்டர்ன் மிகவும் சிக்கலானதாக மாறும்போது, இந்த செயல்பாட்டை மீண்டும் எழுத வேண்டும்.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// கொடுக்கப்பட்ட உறுப்புக்கு இந்த வரிசைப்படுத்தப்பட்ட துண்டுகளை பைனரி தேடுகிறது.
    ///
    /// மதிப்பு கண்டறியப்பட்டால், பொருந்தும் உறுப்பின் குறியீட்டைக் கொண்ட [`Result::Ok`] திரும்பும்.
    /// பல போட்டிகள் இருந்தால், ஏதேனும் ஒரு போட்டியைத் திருப்பித் தரலாம்.
    /// மதிப்பு கண்டுபிடிக்கப்படவில்லை எனில், வரிசைப்படுத்தப்பட்ட வரிசையை பராமரிக்கும் போது பொருந்தக்கூடிய உறுப்பு செருகக்கூடிய குறியீட்டைக் கொண்ட [`Result::Err`] திரும்பும்.
    ///
    ///
    /// [`binary_search_by`], [`binary_search_by_key`] மற்றும் [`partition_point`] ஐயும் காண்க.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// நான்கு கூறுகளின் வரிசையைத் தேடுகிறது.
    /// முதலாவது தனித்துவமாக நிர்ணயிக்கப்பட்ட நிலையில் காணப்படுகிறது;இரண்டாவது மற்றும் மூன்றாவது காணப்படவில்லை;நான்காவது `[1, 4]` இல் எந்த நிலைக்கும் பொருந்தக்கூடும்.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// வரிசைப்படுத்தப்பட்ட vector இல் ஒரு பொருளைச் செருக விரும்பினால், வரிசை வரிசையை பராமரிக்கும்போது:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// ஒப்பீட்டாளர் செயல்பாட்டுடன் இந்த வரிசைப்படுத்தப்பட்ட துண்டுகளை பைனரி தேடுகிறது.
    ///
    /// ஒப்பீட்டாளர் செயல்பாடு அடிப்படை ஸ்லைஸின் வரிசை வரிசைக்கு ஒத்த ஒரு வரிசையை செயல்படுத்த வேண்டும், அதன் வாதம் `Less`, `Equal` அல்லது `Greater` விரும்பிய இலக்கு என்பதைக் குறிக்கும் வரிசைக் குறியீட்டைத் தருகிறது.
    ///
    ///
    /// மதிப்பு கண்டறியப்பட்டால், பொருந்தும் உறுப்பின் குறியீட்டைக் கொண்ட [`Result::Ok`] திரும்பும்.பல போட்டிகள் இருந்தால், ஏதேனும் ஒரு போட்டியைத் திருப்பித் தரலாம்.
    /// மதிப்பு கண்டுபிடிக்கப்படவில்லை எனில், வரிசைப்படுத்தப்பட்ட வரிசையை பராமரிக்கும் போது பொருந்தக்கூடிய உறுப்பு செருகக்கூடிய குறியீட்டைக் கொண்ட [`Result::Err`] திரும்பும்.
    ///
    /// [`binary_search`], [`binary_search_by_key`] மற்றும் [`partition_point`] ஐயும் காண்க.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// நான்கு கூறுகளின் வரிசையைத் தேடுகிறது.முதலாவது தனித்துவமாக நிர்ணயிக்கப்பட்ட நிலையில் காணப்படுகிறது;இரண்டாவது மற்றும் மூன்றாவது காணப்படவில்லை;நான்காவது `[1, 4]` இல் எந்த நிலைக்கும் பொருந்தக்கூடும்.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // பாதுகாப்பு: பின்வரும் மாற்றங்களால் அழைப்பு பாதுகாப்பாக உள்ளது:
            // - `mid >= 0`
            // - `mid < size`: `mid` ஆனது `[left; right)` கட்டுப்பட்டதாகும்.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // பொருத்தத்தை விட if/else கட்டுப்பாட்டு ஓட்டத்தை நாங்கள் பயன்படுத்துவதற்கான காரணம், ஒப்பீட்டு நடவடிக்கைகளை பொருத்தமானது மறுவரிசைப்படுத்துகிறது, இது சரியான உணர்திறன் கொண்டது.
            //
            // இது u8 க்கான x86 asm: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// பைனரி இந்த வரிசைப்படுத்தப்பட்ட துண்டுகளை ஒரு முக்கிய பிரித்தெடுத்தல் செயல்பாட்டுடன் தேடுகிறது.
    ///
    /// ஸ்லைஸ் விசையால் வரிசைப்படுத்தப்படுகிறது என்று கருதுகிறது, உதாரணமாக [`sort_by_key`] உடன் அதே விசை பிரித்தெடுத்தல் செயல்பாட்டைப் பயன்படுத்துகிறது.
    ///
    /// மதிப்பு கண்டறியப்பட்டால், பொருந்தும் உறுப்பின் குறியீட்டைக் கொண்ட [`Result::Ok`] திரும்பும்.
    /// பல போட்டிகள் இருந்தால், ஏதேனும் ஒரு போட்டியைத் திருப்பித் தரலாம்.
    /// மதிப்பு கண்டுபிடிக்கப்படவில்லை எனில், வரிசைப்படுத்தப்பட்ட வரிசையை பராமரிக்கும் போது பொருந்தக்கூடிய உறுப்பு செருகக்கூடிய குறியீட்டைக் கொண்ட [`Result::Err`] திரும்பும்.
    ///
    ///
    /// [`binary_search`], [`binary_search_by`] மற்றும் [`partition_point`] ஐயும் காண்க.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// அவற்றின் இரண்டாவது உறுப்புகளால் வரிசைப்படுத்தப்பட்ட ஜோடிகளின் துண்டுகளாக நான்கு கூறுகளின் வரிசையைத் தேடுகிறது.
    /// முதலாவது தனித்துவமாக நிர்ணயிக்கப்பட்ட நிலையில் காணப்படுகிறது;இரண்டாவது மற்றும் மூன்றாவது காணப்படவில்லை;நான்காவது `[1, 4]` இல் எந்த நிலைக்கும் பொருந்தக்கூடும்.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // `slice::sort_by_key` crate `alloc` இல் இருப்பதால் Lint rustdoc::broken_intra_doc_links அனுமதிக்கப்படுகிறது, மேலும் `core` ஐ உருவாக்கும் போது இது இன்னும் இல்லை.
    //
    // கீழ்நிலை crate க்கான இணைப்புகள்: #74481.ஆதிமனிதர்கள் libstd (#73423) இல் மட்டுமே ஆவணப்படுத்தப்பட்டிருப்பதால், இது ஒருபோதும் நடைமுறையில் உடைந்த இணைப்புகளுக்கு வழிவகுக்காது.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// துண்டுகளை வரிசைப்படுத்துகிறது, ஆனால் சம உறுப்புகளின் வரிசையை பாதுகாக்காது.
    ///
    /// இந்த வகை நிலையற்றது (அதாவது, சமமான கூறுகளை மறுவரிசைப்படுத்தலாம்), இடத்தில் (அதாவது, ஒதுக்கவில்லை), மற்றும் *O*(*n*\*log(* n*)) மோசமான நிலை.
    ///
    /// # தற்போதைய செயல்படுத்தல்
    ///
    /// தற்போதைய வழிமுறை ஆர்சன் பீட்டர்ஸின் [pattern-defeating quicksort][pdqsort] ஐ அடிப்படையாகக் கொண்டது, இது சீரற்ற குவிக்சார்ட்டின் வேகமான சராசரி வழக்கை ஹெப்ஸோர்ட்டின் மிக மோசமான வழக்குடன் இணைக்கிறது, அதே நேரத்தில் சில வடிவங்களுடன் துண்டுகளில் நேரியல் நேரத்தை அடைகிறது.
    /// சீரழிந்த நிகழ்வுகளைத் தவிர்ப்பதற்கு இது சில சீரற்ற தன்மையைப் பயன்படுத்துகிறது, ஆனால் நிலையான seed உடன் எப்போதும் நிர்ணயிக்கும் நடத்தை அளிக்கிறது.
    ///
    /// இது சில நிலையான நிகழ்வுகளைத் தவிர, நிலையான வரிசையாக்கத்தை விட வேகமாக இருக்கும், எ.கா., துண்டு பல ஒருங்கிணைந்த வரிசைப்படுத்தப்பட்ட காட்சிகளைக் கொண்டிருக்கும் போது.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// ஒரு ஒப்பீட்டு செயல்பாட்டுடன் துண்டுகளை வரிசைப்படுத்துகிறது, ஆனால் சம உறுப்புகளின் வரிசையை பாதுகாக்காது.
    ///
    /// இந்த வகை நிலையற்றது (அதாவது, சமமான கூறுகளை மறுவரிசைப்படுத்தலாம்), இடத்தில் (அதாவது, ஒதுக்கவில்லை), மற்றும் *O*(*n*\*log(* n*)) மோசமான நிலை.
    ///
    /// ஒப்பீட்டாளர் செயல்பாடு ஸ்லைஸில் உள்ள உறுப்புகளுக்கான மொத்த வரிசையை வரையறுக்க வேண்டும்.வரிசைப்படுத்துதல் மொத்தமாக இல்லாவிட்டால், உறுப்புகளின் வரிசை குறிப்பிடப்படவில்லை.ஒரு ஆர்டர் என்றால் மொத்த ஆர்டர் (எல்லா `a`, `b` மற்றும் `c` க்கும்):
    ///
    /// * மொத்த மற்றும் ஆண்டிசீமெட்ரிக்: சரியாக `a < b`, `a == b` அல்லது `a > b` இல் ஒன்று உண்மை, மற்றும்
    /// * இடைநிலை, `a < b` மற்றும் `b < c` என்பது `a < c` ஐ குறிக்கிறது.இது `==` மற்றும் `>` இரண்டிற்கும் வைத்திருக்க வேண்டும்.
    ///
    /// எடுத்துக்காட்டாக, [`f64`] [`Ord`] ஐ செயல்படுத்தாததால், `NaN != NaN`, ஸ்லைஸில் `NaN` இல்லை என்பதை அறிந்தால், `partial_cmp` ஐ எங்கள் வரிசை செயல்பாடாகப் பயன்படுத்தலாம்.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # தற்போதைய செயல்படுத்தல்
    ///
    /// தற்போதைய வழிமுறை ஆர்சன் பீட்டர்ஸின் [pattern-defeating quicksort][pdqsort] ஐ அடிப்படையாகக் கொண்டது, இது சீரற்ற குவிக்சார்ட்டின் வேகமான சராசரி வழக்கை ஹெப்ஸோர்ட்டின் மிக மோசமான வழக்குடன் இணைக்கிறது, அதே நேரத்தில் சில வடிவங்களுடன் துண்டுகளில் நேரியல் நேரத்தை அடைகிறது.
    /// சீரழிந்த நிகழ்வுகளைத் தவிர்ப்பதற்கு இது சில சீரற்ற தன்மையைப் பயன்படுத்துகிறது, ஆனால் நிலையான seed உடன் எப்போதும் நிர்ணயிக்கும் நடத்தை அளிக்கிறது.
    ///
    /// இது சில நிலையான நிகழ்வுகளைத் தவிர, நிலையான வரிசையாக்கத்தை விட வேகமாக இருக்கும், எ.கா., துண்டு பல ஒருங்கிணைந்த வரிசைப்படுத்தப்பட்ட காட்சிகளைக் கொண்டிருக்கும் போது.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // தலைகீழ் வரிசையாக்கம்
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// ஒரு முக்கிய பிரித்தெடுத்தல் செயல்பாட்டுடன் துண்டுகளை வரிசைப்படுத்துகிறது, ஆனால் சம உறுப்புகளின் வரிசையை பாதுகாக்காது.
    ///
    /// இந்த வகை நிலையற்றது (அதாவது, சமமான கூறுகளை மறுவரிசைப்படுத்தலாம்), இடத்தில் (அதாவது, ஒதுக்கவில்லை), மற்றும் *O*(m\* * n *\* log(*n*)) மோசமான நிலை, முக்கிய செயல்பாடு *O*(*மீ*).
    ///
    /// # தற்போதைய செயல்படுத்தல்
    ///
    /// தற்போதைய வழிமுறை ஆர்சன் பீட்டர்ஸின் [pattern-defeating quicksort][pdqsort] ஐ அடிப்படையாகக் கொண்டது, இது சீரற்ற குவிக்சார்ட்டின் வேகமான சராசரி வழக்கை ஹெப்ஸோர்ட்டின் மிக மோசமான வழக்குடன் இணைக்கிறது, அதே நேரத்தில் சில வடிவங்களுடன் துண்டுகளில் நேரியல் நேரத்தை அடைகிறது.
    /// சீரழிந்த நிகழ்வுகளைத் தவிர்ப்பதற்கு இது சில சீரற்ற தன்மையைப் பயன்படுத்துகிறது, ஆனால் நிலையான seed உடன் எப்போதும் நிர்ணயிக்கும் நடத்தை அளிக்கிறது.
    ///
    /// அதன் முக்கிய அழைப்பு உத்தி காரணமாக, முக்கிய செயல்பாடு விலை உயர்ந்த சந்தர்ப்பங்களில் [`sort_unstable_by_key`](#method.sort_unstable_by_key) [`sort_by_cached_key`](#method.sort_by_cached_key) ஐ விட மெதுவாக இருக்கும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// `index` இல் உள்ள உறுப்பு அதன் இறுதி வரிசைப்படுத்தப்பட்ட நிலையில் இருக்கும் வகையில் ஸ்லைஸை மறுவரிசைப்படுத்தவும்.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// `index` இல் உள்ள உறுப்பு அதன் இறுதி வரிசைப்படுத்தப்பட்ட நிலையில் இருக்கும் ஒரு ஒப்பீட்டு செயல்பாட்டுடன் துண்டுகளை மறுவரிசைப்படுத்தவும்.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// `index` இல் உள்ள உறுப்பு அதன் இறுதி வரிசைப்படுத்தப்பட்ட நிலையில் இருக்கும் ஒரு முக்கிய பிரித்தெடுத்தல் செயல்பாட்டுடன் துண்டுகளை மறுவரிசைப்படுத்தவும்.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// `index` இல் உள்ள உறுப்பு அதன் இறுதி வரிசைப்படுத்தப்பட்ட நிலையில் இருக்கும் வகையில் ஸ்லைஸை மறுவரிசைப்படுத்தவும்.
    ///
    /// இந்த மறுசீரமைப்பில் `i < index` நிலையில் உள்ள எந்த மதிப்பும் `j > index` நிலையில் உள்ள எந்த மதிப்பையும் விட குறைவாகவோ அல்லது சமமாகவோ இருக்கும் கூடுதல் சொத்து உள்ளது.
    /// கூடுதலாக, இந்த மறுசீரமைப்பு நிலையற்றது (அதாவது
    /// எந்தவொரு சமமான கூறுகளும் `index` நிலையில் முடிவடையும்), இடத்தில் (அதாவது
    /// ஒதுக்கவில்லை), மற்றும் *O*(*n*) மோசமான நிலை.
    /// இந்த செயல்பாடு மற்ற நூலகங்களில் "kth element" என்றும் அழைக்கப்படுகிறது.
    /// இது பின்வரும் மதிப்புகளின் மும்மடங்கைத் தருகிறது: கொடுக்கப்பட்ட குறியீட்டில் உள்ளதை விடக் குறைவான அனைத்து கூறுகளும், கொடுக்கப்பட்ட குறியீட்டில் உள்ள மதிப்பும், கொடுக்கப்பட்ட குறியீட்டில் உள்ளதை விட அதிகமான அனைத்து கூறுகளும்.
    ///
    ///
    /// # தற்போதைய செயல்படுத்தல்
    ///
    /// தற்போதைய வழிமுறை [`sort_unstable`] க்குப் பயன்படுத்தப்படும் அதே குவிக்சோர்ட் வழிமுறையின் விரைவு தேர்வு பகுதியை அடிப்படையாகக் கொண்டது.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` போது Panics, அதாவது வெற்று துண்டுகளில் எப்போதும் panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // சராசரி கண்டுபிடிக்க
    /// v.select_nth_unstable(2);
    ///
    /// // குறிப்பிட்ட குறியீட்டைப் பற்றி நாம் வரிசைப்படுத்தும் முறையின் அடிப்படையில், துண்டு பின்வருவனவற்றில் ஒன்றாக இருக்கும் என்று எங்களுக்கு உத்தரவாதம் அளிக்கப்படுகிறது.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` இல் உள்ள உறுப்பு அதன் இறுதி வரிசைப்படுத்தப்பட்ட நிலையில் இருக்கும் ஒரு ஒப்பீட்டு செயல்பாட்டுடன் துண்டுகளை மறுவரிசைப்படுத்தவும்.
    ///
    /// ஒப்பீட்டாளர் செயல்பாட்டைப் பயன்படுத்தி `j > index` நிலையில் உள்ள எந்த மதிப்பும் `j > index` நிலையில் உள்ள எந்த மதிப்பையும் விட குறைவாகவோ அல்லது சமமாகவோ இருக்கும் கூடுதல் சொத்து இந்த மறுசீரமைப்பில் உள்ளது.
    /// கூடுதலாக, இந்த மறுவரிசைப்படுத்தல் நிலையற்றது (அதாவது எந்தவொரு சமமான கூறுகளும் `index` நிலையில் முடிவடையும்), இடத்தில் (அதாவது ஒதுக்கவில்லை) மற்றும் *O*(*n*) மோசமான நிலை.
    /// இந்த செயல்பாடு மற்ற நூலகங்களில் "kth element" என்றும் அழைக்கப்படுகிறது.
    /// இது பின்வரும் மதிப்புகளின் மும்மடங்கைத் தருகிறது: கொடுக்கப்பட்ட குறியீட்டில் உள்ளதை விடக் குறைவான அனைத்து கூறுகளும், கொடுக்கப்பட்ட குறியீட்டில் உள்ள மதிப்பும், கொடுக்கப்பட்ட குறியீட்டில் உள்ளதை விட அதிகமான அனைத்து கூறுகளும், வழங்கப்பட்ட ஒப்பீட்டாளர் செயல்பாட்டைப் பயன்படுத்தி.
    ///
    ///
    /// # தற்போதைய செயல்படுத்தல்
    ///
    /// தற்போதைய வழிமுறை [`sort_unstable`] க்குப் பயன்படுத்தப்படும் அதே குவிக்சோர்ட் வழிமுறையின் விரைவு தேர்வு பகுதியை அடிப்படையாகக் கொண்டது.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` போது Panics, அதாவது வெற்று துண்டுகளில் எப்போதும் panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // துண்டு இறங்கு வரிசையில் வரிசைப்படுத்தப்பட்டதைப் போல சராசரியைக் கண்டறியவும்.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // குறிப்பிட்ட குறியீட்டைப் பற்றி நாம் வரிசைப்படுத்தும் முறையின் அடிப்படையில், துண்டு பின்வருவனவற்றில் ஒன்றாக இருக்கும் என்று எங்களுக்கு உத்தரவாதம் அளிக்கப்படுகிறது.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` இல் உள்ள உறுப்பு அதன் இறுதி வரிசைப்படுத்தப்பட்ட நிலையில் இருக்கும் ஒரு முக்கிய பிரித்தெடுத்தல் செயல்பாட்டுடன் துண்டுகளை மறுவரிசைப்படுத்தவும்.
    ///
    /// இந்த மறுசீரமைப்பில் `i < index` நிலையில் உள்ள எந்த மதிப்பும் முக்கிய பிரித்தெடுத்தல் செயல்பாட்டைப் பயன்படுத்தி `j > index` நிலையில் உள்ள எந்த மதிப்பையும் விட குறைவாகவோ அல்லது சமமாகவோ இருக்கும் கூடுதல் சொத்து உள்ளது.
    /// கூடுதலாக, இந்த மறுவரிசைப்படுத்தல் நிலையற்றது (அதாவது எந்தவொரு சமமான கூறுகளும் `index` நிலையில் முடிவடையும்), இடத்தில் (அதாவது ஒதுக்கவில்லை) மற்றும் *O*(*n*) மோசமான நிலை.
    /// இந்த செயல்பாடு மற்ற நூலகங்களில் "kth element" என்றும் அழைக்கப்படுகிறது.
    /// இது பின்வரும் மதிப்புகளின் மும்மடங்கைத் தருகிறது: கொடுக்கப்பட்ட குறியீட்டில் உள்ளதை விடக் குறைவான அனைத்து கூறுகளும், கொடுக்கப்பட்ட குறியீட்டில் உள்ள மதிப்பும், கொடுக்கப்பட்ட குறியீட்டில் உள்ளதை விட அதிகமான அனைத்து கூறுகளும், வழங்கப்பட்ட முக்கிய பிரித்தெடுத்தல் செயல்பாட்டைப் பயன்படுத்தி.
    ///
    ///
    /// # தற்போதைய செயல்படுத்தல்
    ///
    /// தற்போதைய வழிமுறை [`sort_unstable`] க்குப் பயன்படுத்தப்படும் அதே குவிக்சோர்ட் வழிமுறையின் விரைவு தேர்வு பகுதியை அடிப்படையாகக் கொண்டது.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` போது Panics, அதாவது வெற்று துண்டுகளில் எப்போதும் panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // முழுமையான மதிப்புக்கு ஏற்ப வரிசை வரிசைப்படுத்தப்பட்டதைப் போல சராசரியைத் திரும்பவும்.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // குறிப்பிட்ட குறியீட்டைப் பற்றி நாம் வரிசைப்படுத்தும் முறையின் அடிப்படையில், துண்டு பின்வருவனவற்றில் ஒன்றாக இருக்கும் என்று எங்களுக்கு உத்தரவாதம் அளிக்கப்படுகிறது.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// [`PartialEq`] trait செயலாக்கத்தின்படி தொடர்ச்சியாக மீண்டும் மீண்டும் வரும் அனைத்து கூறுகளையும் ஸ்லைஸின் முடிவுக்கு நகர்த்துகிறது.
    ///
    ///
    /// இரண்டு துண்டுகளை வழங்குகிறது.முதலாவது தொடர்ச்சியான தொடர்ச்சியான கூறுகள் இல்லை.
    /// இரண்டாவதாக அனைத்து நகல்களும் குறிப்பிட்ட வரிசையில் இல்லை.
    ///
    /// துண்டு வரிசைப்படுத்தப்பட்டால், முதலில் திரும்பிய துண்டில் நகல்கள் எதுவும் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// கொடுக்கப்பட்ட சமத்துவ உறவை திருப்திப்படுத்தும் துண்டின் இறுதி வரை தொடர்ச்சியான உறுப்புகளில் முதலாவது அனைத்தையும் நகர்த்துகிறது.
    ///
    /// இரண்டு துண்டுகளை வழங்குகிறது.முதலாவது தொடர்ச்சியான தொடர்ச்சியான கூறுகள் இல்லை.
    /// இரண்டாவதாக அனைத்து நகல்களும் குறிப்பிட்ட வரிசையில் இல்லை.
    ///
    /// `same_bucket` செயல்பாடு துண்டுகளிலிருந்து இரண்டு உறுப்புகளுக்கான குறிப்புகளை அனுப்பியது மற்றும் உறுப்புகள் சமமாக ஒப்பிடுகிறதா என்பதை தீர்மானிக்க வேண்டும்.
    /// உறுப்புகள் ஸ்லைஸில் உள்ள வரிசையில் இருந்து எதிர் வரிசையில் அனுப்பப்படுகின்றன, எனவே `same_bucket(a, b)` `true` ஐ திருப்பி அளித்தால், `a` ஸ்லைஸின் முடிவில் நகர்த்தப்படுகிறது.
    ///
    ///
    /// துண்டு வரிசைப்படுத்தப்பட்டால், முதலில் திரும்பிய துண்டில் நகல்கள் எதுவும் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // `self` க்கு மாற்றக்கூடிய குறிப்பு எங்களிடம் இருந்தாலும்,*தன்னிச்சையான* மாற்றங்களைச் செய்ய முடியாது.`same_bucket` அழைப்புகள் panic ஆக இருக்கக்கூடும், எனவே துண்டு எல்லா நேரங்களிலும் சரியான நிலையில் இருப்பதை உறுதி செய்ய வேண்டும்.
        //
        // இதை நாங்கள் கையாளும் முறை இடமாற்றுகளைப் பயன்படுத்துவதன் மூலம்;எல்லா உறுப்புகளையும் மீறிச் செல்கிறோம், நாம் செல்லும்போது இடமாற்றம் செய்கிறோம், இதனால் இறுதியில் நாம் வைத்திருக்க விரும்பும் கூறுகள் முன்னால் இருக்கும், மேலும் நாம் நிராகரிக்க விரும்புவோர் பின்னால் இருக்கிறார்கள்.
        // நாம் பின்னர் துண்டு பிரிக்க முடியும்.
        // இந்த செயல்பாடு இன்னும் `O(n)` ஆகும்.
        //
        // எடுத்துக்காட்டு: இந்த நிலையில் தொடங்குகிறோம், அங்கு `r` "அடுத்தது" என்பதைக் குறிக்கிறது
        // படிக்க "மற்றும் `w` next_write` ஐ குறிக்கிறது.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // self[r] ஐ சுயத்துடன் ஒப்பிடுகையில் [w-1], இது ஒரு நகல் அல்ல, எனவே நாம் self[r] மற்றும் self[w] ஐ மாற்றிக் கொள்கிறோம் (r==w என எந்த விளைவும் இல்லை) பின்னர் r மற்றும் w இரண்டையும் அதிகரிக்கிறோம், இதனால் எங்களை விட்டு விடுகிறோம்:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] ஐ சுயத்துடன் ஒப்பிடுகையில் [w-1], இந்த மதிப்பு ஒரு நகல், எனவே நாங்கள் `r` ஐ அதிகரிக்கிறோம், ஆனால் எல்லாவற்றையும் மாற்றாமல் விட்டுவிடுகிறோம்:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] ஐ சுயத்துடன் ஒப்பிடுகையில் [w-1], இது ஒரு நகல் அல்ல, எனவே self[r] மற்றும் self[w] ஐ மாற்றவும் மற்றும் முன்கூட்டியே r மற்றும் w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // நகல் அல்ல, மீண்டும்:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // நகல், advance r. End துண்டு.W இல் பிரிக்கவும்.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // பாதுகாப்பு: `while` நிபந்தனை `next_read` மற்றும் `next_write` க்கு உத்தரவாதம் அளிக்கிறது
        // `len` ஐ விடக் குறைவாக இருக்கும், இதனால் `self` க்குள் இருக்கும்.
        // `prev_ptr_write` `ptr_write` க்கு முன் ஒரு உறுப்பை சுட்டிக்காட்டுகிறது, ஆனால் `next_write` 1 இல் தொடங்குகிறது, எனவே `prev_ptr_write` ஒருபோதும் 0 க்கும் குறைவாக இருக்காது மற்றும் துண்டுக்குள் இருக்கும்.
        // இது `ptr_read`, `prev_ptr_write` மற்றும் `ptr_write` ஆகியவற்றைக் குறைப்பதற்கான தேவைகளையும், `ptr.add(next_read)`, `ptr.add(next_write - 1)` மற்றும் `prev_ptr_write.offset(1)` ஐப் பயன்படுத்துவதற்கான தேவைகளையும் பூர்த்தி செய்கிறது.
        //
        //
        // `next_write` ஒரு வட்டத்திற்கு ஒரு முறை ஒரு முறை அதிகரிக்கப்படுகிறது, அதாவது எந்த உறுப்பு மாற்றப்பட வேண்டியிருக்கும் போது தவிர்க்கப்படுவதில்லை.
        //
        // `ptr_read` மற்றும் `prev_ptr_write` ஒருபோதும் ஒரே உறுப்பை சுட்டிக்காட்டுவதில்லை.`&mut *ptr_read`, `&mut* prev_ptr_write` பாதுகாப்பாக இருக்க இது தேவை.
        // விளக்கம் வெறுமனே `next_read >= next_write` எப்போதும் உண்மைதான், இதனால் `next_read > next_write - 1` கூட.
        //
        //
        //
        //
        //
        unsafe {
            // மூல சுட்டிகள் பயன்படுத்துவதன் மூலம் எல்லை சோதனைகளைத் தவிர்க்கவும்.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// ஒரே விசையை தீர்க்கும் துண்டுகளின் முடிவிற்கு தொடர்ச்சியான உறுப்புகளில் முதலாவது அனைத்தையும் நகர்த்துகிறது.
    ///
    ///
    /// இரண்டு துண்டுகளை வழங்குகிறது.முதலாவது தொடர்ச்சியான தொடர்ச்சியான கூறுகள் இல்லை.
    /// இரண்டாவதாக அனைத்து நகல்களும் குறிப்பிட்ட வரிசையில் இல்லை.
    ///
    /// துண்டு வரிசைப்படுத்தப்பட்டால், முதலில் திரும்பிய துண்டில் நகல்கள் எதுவும் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// ஸ்லைஸின் இடத்திலேயே சுழல்கிறது, அதாவது ஸ்லைஸின் முதல் `mid` கூறுகள் இறுதிவரை நகரும், கடைசி `self.len() - mid` கூறுகள் முன் நோக்கி நகரும்.
    /// `rotate_left` ஐ அழைத்த பிறகு, முன்னர் குறியீட்டு `mid` இல் உள்ள உறுப்பு ஸ்லைஸில் முதல் உறுப்பு ஆகும்.
    ///
    /// # Panics
    ///
    /// `mid` ஸ்லைஸின் நீளத்தை விட அதிகமாக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.`mid == self.len()` _not_ panic ஐ செய்கிறது மற்றும் இது ஒரு விருப்பமற்ற சுழற்சி என்பதை நினைவில் கொள்க.
    ///
    /// # Complexity
    ///
    /// நேரியல் (`self.len()`) நேரத்தில்) எடுக்கும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// ஒரு சந்தாவைச் சுழற்றுகிறது:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // பாதுகாப்பு: `[p.add(mid) - mid, p.add(mid) + k)` வரம்பு அற்பமானது
        // `ptr_rotate` தேவைக்கேற்ப, படிப்பதற்கும் எழுதுவதற்கும் செல்லுபடியாகும்.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// ஸ்லைஸின் இடத்திலேயே சுழல்கிறது, அதாவது ஸ்லைஸின் முதல் `self.len() - k` கூறுகள் இறுதிவரை நகரும், கடைசி `k` கூறுகள் முன் நோக்கி நகரும்.
    /// `rotate_right` ஐ அழைத்த பிறகு, முன்னர் குறியீட்டு `self.len() - k` இல் உள்ள உறுப்பு ஸ்லைஸில் முதல் உறுப்பு ஆகும்.
    ///
    /// # Panics
    ///
    /// `k` ஸ்லைஸின் நீளத்தை விட அதிகமாக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.`k == self.len()` _not_ panic ஐ செய்கிறது மற்றும் இது ஒரு ஒப்-சுழற்சி அல்ல என்பதை நினைவில் கொள்க.
    ///
    /// # Complexity
    ///
    /// நேரியல் (`self.len()`) நேரத்தில்) எடுக்கும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// ஒரு சந்தாவை சுழற்று:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // பாதுகாப்பு: `[p.add(mid) - mid, p.add(mid) + k)` வரம்பு அற்பமானது
        // `ptr_rotate` தேவைக்கேற்ப, படிப்பதற்கும் எழுதுவதற்கும் செல்லுபடியாகும்.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value` ஐ குளோனிங் செய்வதன் மூலம் உறுப்புகளுடன் `self` ஐ நிரப்புகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// மூடுதலை மீண்டும் மீண்டும் அழைப்பதன் மூலம் திரும்பிய உறுப்புகளுடன் `self` ஐ நிரப்புகிறது.
    ///
    /// இந்த முறை புதிய மதிப்புகளை உருவாக்க ஒரு மூடுதலைப் பயன்படுத்துகிறது.கொடுக்கப்பட்ட மதிப்பை நீங்கள் [`Clone`] ஆக விரும்பினால், [`fill`] ஐப் பயன்படுத்தவும்.
    /// மதிப்புகளை உருவாக்க நீங்கள் [`Default`] trait ஐப் பயன்படுத்த விரும்பினால், நீங்கள் [`Default::default`] ஐ வாதமாக அனுப்பலாம்.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// உறுப்புகளை `src` இலிருந்து `self` க்கு நகலெடுக்கிறது.
    ///
    /// `src` இன் நீளம் `self` க்கு சமமாக இருக்க வேண்டும்.
    ///
    /// `T` `Copy` ஐ செயல்படுத்தினால், [`copy_from_slice`] ஐப் பயன்படுத்துவது அதிக செயல்திறன் மிக்கதாக இருக்கும்.
    ///
    /// # Panics
    ///
    /// இரண்டு துண்டுகள் வெவ்வேறு நீளங்களைக் கொண்டிருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
    ///
    /// # Examples
    ///
    /// ஒரு துண்டுகளிலிருந்து மற்றொன்றுக்கு இரண்டு கூறுகளை குளோனிங் செய்தல்:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // துண்டுகள் ஒரே நீளமாக இருக்க வேண்டும் என்பதால், மூல துண்டுகளை நான்கு உறுப்புகளிலிருந்து இரண்டாக வெட்டுகிறோம்.
    /// // நாங்கள் இதைச் செய்யாவிட்டால் அது panic ஆக இருக்கும்.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ஒரு குறிப்பிட்ட வரம்பில் ஒரு குறிப்பிட்ட தரவுக்கு மாறாத குறிப்புகள் இல்லாத ஒரே ஒரு மாற்றத்தக்க குறிப்பு மட்டுமே இருக்க முடியும் என்று செயல்படுத்துகிறது.
    /// இதன் காரணமாக, ஒரு துண்டில் `clone_from_slice` ஐப் பயன்படுத்த முயற்சிப்பது தொகு தோல்விக்கு வழிவகுக்கும்:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// இதைச் செய்ய, ஒரு துண்டிலிருந்து இரண்டு தனித்துவமான துணை துண்டுகளை உருவாக்க [`split_at_mut`] ஐப் பயன்படுத்தலாம்:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// எல்லா உறுப்புகளையும் `src` இலிருந்து `self` க்கு நகலெடுக்கிறது, ஒரு memcpy ஐப் பயன்படுத்தி.
    ///
    /// `src` இன் நீளம் `self` க்கு சமமாக இருக்க வேண்டும்.
    ///
    /// `T` `Copy` ஐ செயல்படுத்தவில்லை என்றால், [`clone_from_slice`] ஐப் பயன்படுத்தவும்.
    ///
    /// # Panics
    ///
    /// இரண்டு துண்டுகள் வெவ்வேறு நீளங்களைக் கொண்டிருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
    ///
    /// # Examples
    ///
    /// ஒரு துண்டிலிருந்து இரண்டு கூறுகளை மற்றொன்றுக்கு நகலெடுக்கிறது:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // துண்டுகள் ஒரே நீளமாக இருக்க வேண்டும் என்பதால், மூல துண்டுகளை நான்கு உறுப்புகளிலிருந்து இரண்டாக வெட்டுகிறோம்.
    /// // நாங்கள் இதைச் செய்யாவிட்டால் அது panic ஆக இருக்கும்.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ஒரு குறிப்பிட்ட வரம்பில் ஒரு குறிப்பிட்ட தரவுக்கு மாறாத குறிப்புகள் இல்லாத ஒரே ஒரு மாற்றத்தக்க குறிப்பு மட்டுமே இருக்க முடியும் என்று செயல்படுத்துகிறது.
    /// இதன் காரணமாக, ஒரு துண்டில் `copy_from_slice` ஐப் பயன்படுத்த முயற்சிப்பது தொகு தோல்விக்கு வழிவகுக்கும்:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// இதைச் செய்ய, ஒரு துண்டிலிருந்து இரண்டு தனித்துவமான துணை துண்டுகளை உருவாக்க [`split_at_mut`] ஐப் பயன்படுத்தலாம்:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // அழைப்பு தளத்தை வீக்கப்படுத்தாமல் இருக்க panic குறியீடு பாதை ஒரு குளிர் செயல்பாட்டில் வைக்கப்பட்டது.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // பாதுகாப்பு: வரையறையின்படி `self.len()` உறுப்புகளுக்கு `self` செல்லுபடியாகும், மேலும் `src` இருந்தது
        // ஒரே நீளம் உள்ளதா என சரிபார்க்கப்பட்டது.
        // துண்டுகள் ஒன்றுடன் ஒன்று மாற முடியாது, ஏனெனில் மாற்றக்கூடிய குறிப்புகள் பிரத்தியேகமானவை.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// துண்டுகளின் ஒரு பகுதியிலிருந்து தனக்கு இன்னொரு பகுதிக்கு உறுப்புகளை நகலெடுக்கிறது.
    ///
    /// `src` இருந்து நகலெடுக்க `self` க்குள் இருக்கும் வரம்பு.
    /// `dest` `self` க்குள் நகலெடுக்க வரம்பின் தொடக்க குறியீடாகும், இது `src` க்கு சமமான நீளத்தைக் கொண்டிருக்கும்.
    /// இரண்டு வரம்புகளும் ஒன்றுடன் ஒன்று இருக்கலாம்.
    /// இரண்டு வரம்புகளின் முனைகள் `self.len()` ஐ விட குறைவாகவோ அல்லது சமமாகவோ இருக்க வேண்டும்.
    ///
    /// # Panics
    ///
    /// ஸ்லைஸின் முடிவை வரம்பு மீறிவிட்டால் அல்லது `src` இன் முடிவு தொடக்கத்திற்கு முன்பே இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// ஒரு துண்டுக்குள் நான்கு பைட்டுகளை நகலெடுக்கிறது:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // பாதுகாப்பு: `ptr::copy` க்கான நிபந்தனைகள் அனைத்தும் மேலே சரிபார்க்கப்பட்டுள்ளன,
        // `ptr::add` க்கானவை.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `self` இல் உள்ள அனைத்து கூறுகளையும் `other` இல் உள்ளவர்களுடன் மாற்றுகிறது.
    ///
    /// `other` இன் நீளம் `self` க்கு சமமாக இருக்க வேண்டும்.
    ///
    /// # Panics
    ///
    /// இரண்டு துண்டுகள் வெவ்வேறு நீளங்களைக் கொண்டிருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
    ///
    /// # Example
    ///
    /// துண்டுகள் முழுவதும் இரண்டு கூறுகளை மாற்றுதல்:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust ஒரு குறிப்பிட்ட நோக்கத்தில் ஒரு குறிப்பிட்ட தரவுக்கு ஒரு மாற்றத்தக்க குறிப்பு மட்டுமே இருக்க முடியும் என்று செயல்படுத்துகிறது.
    ///
    /// இதன் காரணமாக, ஒரு துண்டில் `swap_with_slice` ஐப் பயன்படுத்த முயற்சிப்பது தொகு தோல்விக்கு வழிவகுக்கும்:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// இதைச் சுற்றி வேலை செய்ய, ஒரு துண்டிலிருந்து இரண்டு தனித்துவமான மாற்றக்கூடிய துணை துண்டுகளை உருவாக்க [`split_at_mut`] ஐப் பயன்படுத்தலாம்:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // பாதுகாப்பு: வரையறையின்படி `self.len()` உறுப்புகளுக்கு `self` செல்லுபடியாகும், மேலும் `src` இருந்தது
        // ஒரே நீளம் உள்ளதா என சரிபார்க்கப்பட்டது.
        // துண்டுகள் ஒன்றுடன் ஒன்று மாற முடியாது, ஏனெனில் மாற்றக்கூடிய குறிப்புகள் பிரத்தியேகமானவை.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}` க்கான நடுத்தர மற்றும் பின்தங்கிய துண்டுகளின் நீளத்தைக் கணக்கிடுவதற்கான செயல்பாடு.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // `rest` ஐப் பற்றி நாம் என்ன செய்யப் போகிறோம் என்பது மிகக் குறைந்த எண்ணிக்கையிலான `T` களில் எதை வைக்கலாம் என்பதைக் கண்டுபிடிப்பதாகும்.
        //
        // அத்தகைய ஒவ்வொரு "multiple" க்கும் எத்தனை `T` கள் தேவை.
        //
        // உதாரணமாக T=u8 U=u16 ஐக் கவனியுங்கள்.பின்னர் 1 U ஐ 2 Ts இல் வைக்கலாம்.எளிமையானது.
        // இப்போது, உதாரணமாக size_of: :<T>=16, size_of::<U>=24.</u>
        // `rest` ஸ்லைஸில் ஒவ்வொரு 3 Ts க்கு பதிலாக 2 எங்களை வைக்கலாம்.
        // இன்னும் கொஞ்சம் சிக்கலானது.
        //
        // இதைக் கணக்கிடுவதற்கான சூத்திரம்:
        //
        // எங்களை= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // விரிவாக்கப்பட்ட மற்றும் எளிமைப்படுத்தப்பட்டவை:
        //
        // எங்களை=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // அதிர்ஷ்டவசமாக இவை அனைத்தும் நிலையான மதிப்பீடு என்பதால் ... இங்கே செயல்திறன் முக்கியமல்ல!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // மறுபயன்பாட்டு ஸ்டீனின் வழிமுறை நாம் இன்னும் இந்த `const fn` ஐ உருவாக்க வேண்டும் (மேலும் நாம் செய்தால் மறுநிகழ்வு வழிமுறைக்கு மாற்ற வேண்டும்) ஏனென்றால் எல்.எல்.வி.எம்-ஐ நம்பியிருப்பது இவை அனைத்தையும் பாதுகாக்க…நன்றாக, இது எனக்கு சங்கடமாக இருக்கிறது.
            //
            //

            // பாதுகாப்பு: `a` மற்றும் `b` ஆகியவை பூஜ்ஜியமற்ற மதிப்புகள் என சரிபார்க்கப்படுகின்றன.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // 2 இன் அனைத்து காரணிகளையும் b இலிருந்து அகற்றவும்
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // பாதுகாப்பு: `b` பூஜ்ஜியமற்றது என சோதிக்கப்படுகிறது.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // இந்த அறிவைக் கொண்டு ஆயுதம் ஏந்திய நாம் எத்தனை `யு'களைப் பொருத்த முடியும் என்பதைக் காணலாம்!
        let us_len = self.len() / ts * us;
        // பின்னால் எத்தனை `டி` கள் இருக்கும்!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// துண்டுகளை வேறொரு வகைக்கு மாற்றவும், வகைகளின் சீரமைப்பு பராமரிக்கப்படுவதை உறுதி செய்கிறது.
    ///
    /// இந்த முறை துண்டுகளை மூன்று தனித்தனி துண்டுகளாகப் பிரிக்கிறது: முன்னொட்டு, ஒரு புதிய வகையின் சரியாக சீரமைக்கப்பட்ட நடுத்தர துண்டு, மற்றும் பின்னொட்டு துண்டு.
    /// இந்த முறை நடுத்தர துண்டுகளை ஒரு குறிப்பிட்ட வகை மற்றும் உள்ளீட்டு துண்டுக்கு மிகப் பெரிய நீளமாக மாற்றக்கூடும், ஆனால் உங்கள் வழிமுறையின் செயல்திறன் மட்டுமே அதைப் பொறுத்தது, அதன் சரியானது அல்ல.
    ///
    /// உள்ளீட்டு தரவு அனைத்தும் முன்னொட்டு அல்லது பின்னொட்டு துண்டுகளாக திருப்பி அனுப்பப்படுவது அனுமதிக்கப்படுகிறது.
    ///
    /// உள்ளீட்டு உறுப்பு `T` அல்லது வெளியீட்டு உறுப்பு `U` பூஜ்ஜிய அளவிலானதாக இருக்கும்போது இந்த முறைக்கு எந்த நோக்கமும் இல்லை, மேலும் எதையும் பிரிக்காமல் அசல் துண்டுகளை வழங்கும்.
    ///
    /// # Safety
    ///
    /// இந்த முறை அடிப்படையில் திரும்பிய நடுத்தர ஸ்லைஸில் உள்ள உறுப்புகளைப் பொறுத்தவரை ஒரு `transmute` ஆகும், எனவே `transmute::<T, U>` தொடர்பான அனைத்து வழக்கமான எச்சரிக்கைகளும் இங்கே பொருந்தும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // இந்த செயல்பாட்டின் பெரும்பகுதி நிலையான மதிப்பீடு செய்யப்படும் என்பதை நினைவில் கொள்க,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST களை சிறப்பாகக் கையாளவும், அதாவது-அவற்றைக் கையாள வேண்டாம்.
            return (self, &[], &[]);
        }

        // முதலில், முதல் மற்றும் 2 வது துண்டுக்கு இடையில் எந்த கட்டத்தில் பிரிக்கிறோம் என்பதைக் கண்டறியவும்.
        // ptr.align_offset உடன் எளிதானது.
        let ptr = self.as_ptr();
        // பாதுகாப்பு: விரிவான பாதுகாப்பு கருத்துக்கு `align_to_mut` முறையைப் பார்க்கவும்.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // பாதுகாப்பு: இப்போது `rest` நிச்சயமாக சீரமைக்கப்பட்டுள்ளது, எனவே கீழே உள்ள `from_raw_parts` சரி,
            // அழைப்பாளர் `T` ஐ `U` க்கு பாதுகாப்பாக மாற்ற முடியும் என்று உத்தரவாதம் அளிப்பதால்.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// துண்டுகளை வேறொரு வகைக்கு மாற்றவும், வகைகளின் சீரமைப்பு பராமரிக்கப்படுவதை உறுதி செய்கிறது.
    ///
    /// இந்த முறை துண்டுகளை மூன்று தனித்தனி துண்டுகளாகப் பிரிக்கிறது: முன்னொட்டு, ஒரு புதிய வகையின் சரியாக சீரமைக்கப்பட்ட நடுத்தர துண்டு, மற்றும் பின்னொட்டு துண்டு.
    /// இந்த முறை நடுத்தர துண்டுகளை ஒரு குறிப்பிட்ட வகை மற்றும் உள்ளீட்டு துண்டுக்கு மிகப் பெரிய நீளமாக மாற்றக்கூடும், ஆனால் உங்கள் வழிமுறையின் செயல்திறன் மட்டுமே அதைப் பொறுத்தது, அதன் சரியானது அல்ல.
    ///
    /// உள்ளீட்டு தரவு அனைத்தும் முன்னொட்டு அல்லது பின்னொட்டு துண்டுகளாக திருப்பி அனுப்பப்படுவது அனுமதிக்கப்படுகிறது.
    ///
    /// உள்ளீட்டு உறுப்பு `T` அல்லது வெளியீட்டு உறுப்பு `U` பூஜ்ஜிய அளவிலானதாக இருக்கும்போது இந்த முறைக்கு எந்த நோக்கமும் இல்லை, மேலும் எதையும் பிரிக்காமல் அசல் துண்டுகளை வழங்கும்.
    ///
    /// # Safety
    ///
    /// இந்த முறை அடிப்படையில் திரும்பிய நடுத்தர ஸ்லைஸில் உள்ள உறுப்புகளைப் பொறுத்தவரை ஒரு `transmute` ஆகும், எனவே `transmute::<T, U>` தொடர்பான அனைத்து வழக்கமான எச்சரிக்கைகளும் இங்கே பொருந்தும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // இந்த செயல்பாட்டின் பெரும்பகுதி நிலையான மதிப்பீடு செய்யப்படும் என்பதை நினைவில் கொள்க,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST களை சிறப்பாகக் கையாளவும், அதாவது-அவற்றைக் கையாள வேண்டாம்.
            return (self, &mut [], &mut []);
        }

        // முதலில், முதல் மற்றும் 2 வது துண்டுக்கு இடையில் எந்த கட்டத்தில் பிரிக்கிறோம் என்பதைக் கண்டறியவும்.
        // ptr.align_offset உடன் எளிதானது.
        let ptr = self.as_ptr();
        // பாதுகாப்பு: இங்கே U க்காக சீரமைக்கப்பட்ட சுட்டிகளைப் பயன்படுத்துவோம் என்பதை உறுதிசெய்கிறோம்
        // மீதமுள்ள முறை.U ஐ இலக்காகக் கொண்ட ஒரு சீரமைப்புடன் ஒரு சுட்டிக்காட்டி&[T] க்கு அனுப்புவதன் மூலம் இது செய்யப்படுகிறது.
        // `crate::ptr::align_offset` சரியாக சீரமைக்கப்பட்ட மற்றும் செல்லுபடியாகும் சுட்டிக்காட்டி `ptr` உடன் அழைக்கப்படுகிறது (இது `self` பற்றிய குறிப்பிலிருந்து வருகிறது) மற்றும் இரண்டு சக்தியுடன் கூடிய அளவு (இது U க்கான சீரமைப்பிலிருந்து வருவதால்), அதன் பாதுகாப்பு தடைகளை பூர்த்தி செய்கிறது.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // இதற்குப் பிறகு நாம் மீண்டும் `rest` ஐப் பயன்படுத்த முடியாது, அது அதன் மாற்று `mut_ptr` ஐ செல்லாததாக்கும்!பாதுகாப்பு: `align_to` க்கான கருத்துகளைப் பார்க்கவும்.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// இந்த துண்டின் கூறுகள் வரிசைப்படுத்தப்பட்டதா என சரிபார்க்கிறது.
    ///
    /// அதாவது, ஒவ்வொரு உறுப்பு `a` க்கும் அதன் பின்வரும் உறுப்பு `b` க்கும், `a <= b` வைத்திருக்க வேண்டும்.துண்டு சரியாக பூஜ்ஜியம் அல்லது ஒரு உறுப்பை அளித்தால், `true` திரும்பும்.
    ///
    /// `Self::Item` என்பது `PartialOrd` மட்டுமே, ஆனால் `Ord` அல்ல எனில், மேலே உள்ள வரையறை, தொடர்ச்சியான இரண்டு உருப்படிகளையும் ஒப்பிட முடியாவிட்டால் இந்த செயல்பாடு `false` ஐ வழங்குகிறது என்பதைக் குறிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// கொடுக்கப்பட்ட ஒப்பீட்டாளர் செயல்பாட்டைப் பயன்படுத்தி இந்த துண்டின் கூறுகள் வரிசைப்படுத்தப்பட்டிருக்கிறதா என சரிபார்க்கிறது.
    ///
    /// `PartialOrd::partial_cmp` ஐப் பயன்படுத்துவதற்குப் பதிலாக, இந்த செயல்பாடு இரண்டு உறுப்புகளின் வரிசையை தீர்மானிக்க கொடுக்கப்பட்ட `compare` செயல்பாட்டைப் பயன்படுத்துகிறது.
    /// அது தவிர, இது [`is_sorted`] க்கு சமம்;மேலும் தகவலுக்கு அதன் ஆவணங்களைப் பார்க்கவும்.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// கொடுக்கப்பட்ட விசை பிரித்தெடுத்தல் செயல்பாட்டைப் பயன்படுத்தி இந்த துண்டின் கூறுகள் வரிசைப்படுத்தப்பட்டிருக்கிறதா என சரிபார்க்கிறது.
    ///
    /// ஸ்லைஸின் கூறுகளை நேரடியாக ஒப்பிடுவதற்கு பதிலாக, இந்த செயல்பாடு `f` ஆல் நிர்ணயிக்கப்பட்டபடி, உறுப்புகளின் விசைகளை ஒப்பிடுகிறது.
    /// அது தவிர, இது [`is_sorted`] க்கு சமம்;மேலும் தகவலுக்கு அதன் ஆவணங்களைப் பார்க்கவும்.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// கொடுக்கப்பட்ட முன்கணிப்புக்கு ஏற்ப பகிர்வு புள்ளியின் குறியீட்டை வழங்குகிறது (இரண்டாவது பகிர்வின் முதல் தனிமத்தின் குறியீடு).
    ///
    /// கொடுக்கப்பட்ட முன்னறிவிப்பின் படி துண்டு பகிர்வு செய்யப்படுகிறது.
    /// இதன் பொருள் என்னவென்றால், முன்னறிவிப்பு உண்மையான வருமானம் தரும் அனைத்து கூறுகளும் துண்டுகளின் தொடக்கத்தில்தான் இருக்கும், மேலும் முன்னறிவிப்பு தவறான வருமானத்தை அளிக்கும் அனைத்து கூறுகளும் முடிவில் உள்ளன.
    ///
    /// எடுத்துக்காட்டாக, [7, 15, 3, 5, 4, 12, 6] என்பது முன்னறிவிக்கப்பட்ட x% 2!=0 இன் கீழ் ஒரு பகிர்வு செய்யப்பட்டுள்ளது (அனைத்து ஒற்றைப்படை எண்களும் தொடக்கத்தில் உள்ளன, அனைத்தும் முடிவில் கூட).
    ///
    /// இந்த துண்டு பகிர்வு செய்யப்படாவிட்டால், திரும்பிய முடிவு குறிப்பிடப்படாதது மற்றும் அர்த்தமற்றது, ஏனெனில் இந்த முறை ஒரு வகையான பைனரி தேடலை செய்கிறது.
    ///
    /// [`binary_search`], [`binary_search_by`] மற்றும் [`binary_search_by_key`] ஐயும் காண்க.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // பாதுகாப்பு: `left < right` போது, `left <= mid < right`.
            // எனவே `left` எப்போதும் அதிகரிக்கிறது மற்றும் `right` எப்போதும் குறைகிறது, அவற்றில் ஒன்று தேர்ந்தெடுக்கப்படுகிறது.இரண்டு நிகழ்வுகளிலும் `left <= right` திருப்தி அளிக்கிறது.எனவே ஒரு கட்டத்தில் `left < right` என்றால், அடுத்த கட்டத்தில் `left <= right` திருப்தி அடைகிறது.
            //
            // எனவே `left != right` இருக்கும் வரை, `0 <= left < right <= len` திருப்தி அடைகிறது, இந்த வழக்கு `0 <= mid < len` கூட திருப்தி அடைந்தால்.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: நாம் அவற்றை ஒரே நீளத்திற்கு வெளிப்படையாக வெட்ட வேண்டும்
        // வரம்புகளைச் சரிபார்ப்பதைத் தவிர்ப்பதற்கு ஆப்டிமைசருக்கு எளிதாக இருக்கும்.
        // ஆனால் இதை நம்பியிருக்க முடியாது என்பதால், டி: நகலுக்கான வெளிப்படையான நிபுணத்துவமும் எங்களிடம் உள்ளது.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// வெற்று துண்டுகளை உருவாக்குகிறது.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// மாற்றக்கூடிய வெற்று துண்டுகளை உருவாக்குகிறது.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// துண்டுகளில் உள்ள வடிவங்கள், தற்போது, `strip_prefix` மற்றும் `strip_suffix` ஆல் மட்டுமே பயன்படுத்தப்படுகின்றன.
/// ஒரு future புள்ளியில், `core::str::Pattern` ஐ (எழுதும் நேரத்தில் `str` க்கு மட்டுப்படுத்தப்பட்டவை) துண்டுகளாக பொதுமைப்படுத்தலாம் என்று நம்புகிறோம், பின்னர் இந்த trait மாற்றப்படும் அல்லது அகற்றப்படும்.
///
pub trait SlicePattern {
    /// துண்டுகளின் உறுப்பு வகை பொருந்துகிறது.
    type Item;

    /// தற்போது, `SlicePattern` இன் நுகர்வோருக்கு ஒரு துண்டு தேவை.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}