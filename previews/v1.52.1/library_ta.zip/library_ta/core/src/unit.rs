use crate::iter::FromIterator;

/// ஒரு ஈரேட்டரிலிருந்து அனைத்து யூனிட் உருப்படிகளையும் ஒன்றோடு ஒன்று சுருக்குகிறது.
///
/// பிழைகள் பற்றி மட்டுமே நீங்கள் அக்கறை கொண்ட `Result<(), E>` க்கு சேகரிப்பது போன்ற உயர்-நிலை சுருக்கங்களுடன் இணைந்தால் இது மிகவும் பயனுள்ளதாக இருக்கும்:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}