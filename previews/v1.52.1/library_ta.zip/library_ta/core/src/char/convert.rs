//! எழுத்து மாற்றங்கள்.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// ஒரு `u32` ஐ `char` ஆக மாற்றுகிறது.
///
/// எல்லா [`char`] களும் செல்லுபடியாகும் [`u32`] கள் என்பதை நினைவில் கொள்க, மேலும் அவற்றுடன் ஒன்றை அனுப்பலாம்
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// இருப்பினும், தலைகீழ் உண்மை இல்லை: எல்லா செல்லுபடியாகும் [`u32`] கள் செல்லுபடியாகாது [`கரி`] கள்.
/// `from_u32()` உள்ளீடு ஒரு [`char`] க்கான சரியான மதிப்பு இல்லையென்றால் `None` ஐ வழங்கும்.
///
/// இந்த காசோலைகளை புறக்கணிக்கும் இந்த செயல்பாட்டின் பாதுகாப்பற்ற பதிப்பிற்கு, [`from_u32_unchecked`] ஐப் பார்க்கவும்.
///
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// உள்ளீடு செல்லுபடியாகும் [`char`] இல்லாதபோது `None` ஐத் தருகிறது:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// செல்லுபடியை புறக்கணித்து, `u32` ஐ `char` ஆக மாற்றுகிறது.
///
/// எல்லா [`char`] களும் செல்லுபடியாகும் [`u32`] கள் என்பதை நினைவில் கொள்க, மேலும் அவற்றுடன் ஒன்றை அனுப்பலாம்
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// இருப்பினும், தலைகீழ் உண்மை இல்லை: எல்லா செல்லுபடியாகும் [`u32`] கள் செல்லுபடியாகாது [`கரி`] கள்.
/// `from_u32_unchecked()` இதைப் புறக்கணித்து, கண்மூடித்தனமாக [`char`] க்கு அனுப்பலாம், இது தவறான ஒன்றை உருவாக்கும்.
///
///
/// # Safety
///
/// இந்த செயல்பாடு பாதுகாப்பற்றது, ஏனெனில் இது தவறான `char` மதிப்புகளை உருவாக்கக்கூடும்.
///
/// இந்த செயல்பாட்டின் பாதுகாப்பான பதிப்பிற்கு, [`from_u32`] செயல்பாட்டைப் பார்க்கவும்.
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // பாதுகாப்பு: அழைப்பாளர் `i` செல்லுபடியாகும் கரி மதிப்பு என்று உத்தரவாதம் அளிக்க வேண்டும்.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// ஒரு [`char`] ஐ [`u32`] ஆக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// ஒரு [`char`] ஐ [`u64`] ஆக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // குறியீட்டு புள்ளியின் மதிப்புக்கு கரி அனுப்பப்படுகிறது, பின்னர் பூஜ்ஜியம் 64 பிட் வரை நீட்டிக்கப்படுகிறது.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] ஐப் பார்க்கவும்
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// ஒரு [`char`] ஐ [`u128`] ஆக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // குறியீட்டு புள்ளியின் மதிப்புக்கு கரி அனுப்பப்படுகிறது, பின்னர் பூஜ்ஜியம் 128 பிட் வரை நீட்டிக்கப்படுகிறது.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] ஐப் பார்க்கவும்
        c as u128
    }
}

/// ஒரு பைட்டை 0x00 இல் வரைபடமாக்குகிறது ..=0xFF ஐ ஒரு `char` க்கு குறியீட்டு புள்ளி அதே மதிப்பைக் கொண்டுள்ளது, U + 0000 இல் ..=U + 00FF.
///
/// யூனிகோட் வடிவமைக்கப்பட்டுள்ளது, இது ஐஏஎன்ஏ ஐஎஸ்ஓ-8859-1 என்று அழைக்கும் எழுத்துக்குறி குறியீட்டுடன் பைட்டுகளை திறம்பட டிகோட் செய்கிறது.
/// இந்த குறியாக்கம் ASCII உடன் இணக்கமானது.
///
/// இது ISO/IEC 8859-1 அக்காவிலிருந்து வேறுபட்டது என்பதை நினைவில் கொள்க
/// ஐஎஸ்ஓ 8859-1 (ஒரு குறைவான ஹைபனுடன்), இது சில எக்ஸ் 100 எக்ஸ், பைட் மதிப்புகளை எந்த எழுத்துக்கும் ஒதுக்கவில்லை.
/// ISO-8859-1 (IANA ஒன்று) அவற்றை C0 மற்றும் C1 கட்டுப்பாட்டுக் குறியீடுகளுக்கு ஒதுக்குகிறது.
///
/// இது விண்டோஸ்-1252 அக்காவிலிருந்து * வேறுபட்டது என்பதை நினைவில் கொள்க
/// குறியீடு பக்கம் 1252, இது ஒரு சூப்பர்செட் ISO/IEC 8859-1 ஆகும், இது சில (அனைத்துமே இல்லை!) வெற்றிடங்களை நிறுத்தற்குறி மற்றும் பல்வேறு லத்தீன் எழுத்துக்களுக்கு ஒதுக்குகிறது.
///
/// விஷயங்களை மேலும் குழப்ப, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` மற்றும் `windows-1252` அனைத்தும் விண்டோஸ்-1252 இன் சூப்பர்செட்டிற்கான மாற்றுப்பெயர்கள், அவை மீதமுள்ள வெற்றிடங்களை தொடர்புடைய C0 மற்றும் C1 கட்டுப்பாட்டுக் குறியீடுகளுடன் நிரப்புகின்றன.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// ஒரு [`u8`] ஐ [`char`] ஆக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// ஒரு எரிப்பதை பாகுபடுத்தும்போது திருப்பித் தரக்கூடிய பிழை.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // பாதுகாப்பு: இது சட்டப்பூர்வ யூனிகோட் மதிப்பு என்று சரிபார்க்கப்பட்டது
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32 இலிருந்து கரிக்கு மாற்றம் தோல்வியடையும் போது பிழை வகை திரும்பியது.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// கொடுக்கப்பட்ட ரேடிக்ஸில் ஒரு இலக்கத்தை `char` ஆக மாற்றுகிறது.
///
/// இங்கே ஒரு 'radix' சில நேரங்களில் 'base' என்றும் அழைக்கப்படுகிறது.
/// இரண்டின் ஒரு ரேடிக்ஸ் ஒரு பைனரி எண், பத்து, தசம, மற்றும் பதினாறு, ஹெக்ஸாடெசிமல் ஆகியவற்றின் ரேடிக்ஸ் சில பொதுவான மதிப்புகளைக் கொடுக்கிறது.
///
/// தன்னிச்சையான ரேடிஸ்கள் துணைபுரிகின்றன.
///
/// `from_digit()` கொடுக்கப்பட்ட ரேடிக்ஸில் உள்ளீடு ஒரு இலக்கமாக இல்லாவிட்டால் `None` ஐ வழங்கும்.
///
/// # Panics
///
/// 36 ஐ விட பெரிய ரேடிக்ஸ் கொடுத்தால் Panics.
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // தசம 11 என்பது அடிப்படை 16 இல் ஒற்றை இலக்கமாகும்
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// உள்ளீடு ஒரு இலக்கமாக இல்லாதபோது `None` ஐத் தருகிறது:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// ஒரு பெரிய ரேடிக்ஸ் கடந்து, ஒரு panic ஐ ஏற்படுத்துகிறது:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}