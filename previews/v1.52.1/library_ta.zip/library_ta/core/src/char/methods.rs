//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` க்கு மிக உயர்ந்த செல்லுபடியாகும் குறியீடு புள்ளி.
    ///
    /// ஒரு `char` என்பது ஒரு [Unicode Scalar Value] ஆகும், அதாவது இது ஒரு [Code Point], ஆனால் ஒரு குறிப்பிட்ட வரம்பிற்குள் மட்டுமே.
    /// `MAX` செல்லுபடியாகும் [Unicode Scalar Value] மிக உயர்ந்த செல்லுபடியாகும் குறியீடு புள்ளி.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` டிகோடிங் பிழையைக் குறிக்க யூனிகோடில் () பயன்படுத்தப்படுகிறது.
    ///
    /// உதாரணமாக, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) க்கு மோசமாக உருவாக்கப்பட்ட UTF-8 பைட்டுகளை கொடுக்கும்போது இது நிகழலாம்.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char` மற்றும் `str` முறைகளின் யூனிகோட் பாகங்கள் அடிப்படையாகக் கொண்ட [Unicode](http://www.unicode.org/) இன் பதிப்பு.
    ///
    /// யூனிகோடின் புதிய பதிப்புகள் தவறாமல் வெளியிடப்படுகின்றன, பின்னர் யூனிகோடைப் பொறுத்து நிலையான நூலகத்தில் உள்ள அனைத்து முறைகளும் புதுப்பிக்கப்படும்.
    /// எனவே சில `char` மற்றும் `str` முறைகளின் நடத்தை மற்றும் காலப்போக்கில் இந்த நிலையான மாற்றங்களின் மதிப்பு.
    /// இது * ஒரு முறிவு மாற்றமாக கருதப்படவில்லை.
    ///
    /// பதிப்பு எண் திட்டம் [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) இல் விளக்கப்பட்டுள்ளது.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` இல் UTF-16 குறியாக்கப்பட்ட குறியீடு புள்ளிகளில் ஒரு ஈரேட்டரை உருவாக்குகிறது, இணைக்கப்படாத வாகைகளை `பிழை 'எனத் தருகிறது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` முடிவுகளை மாற்று எழுத்துடன் மாற்றுவதன் மூலம் நஷ்டமான டிகோடரைப் பெறலாம்:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// ஒரு `u32` ஐ `char` ஆக மாற்றுகிறது.
    ///
    /// எல்லா `கரி'களும் செல்லுபடியாகும் [` u32`] கள் என்பதை நினைவில் கொள்க, மேலும் அவற்றில் ஒன்றை அனுப்பலாம்
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// இருப்பினும், தலைகீழ் உண்மை இல்லை: எல்லா செல்லுபடியாகும் [`u32`] கள் செல்லுபடியாகும்`கரி` கள் அல்ல.
    /// `from_u32()` உள்ளீடு ஒரு `char` க்கான சரியான மதிப்பு இல்லையென்றால் `None` ஐ வழங்கும்.
    ///
    /// இந்த காசோலைகளை புறக்கணிக்கும் இந்த செயல்பாட்டின் பாதுகாப்பற்ற பதிப்பிற்கு, [`from_u32_unchecked`] ஐப் பார்க்கவும்.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// உள்ளீடு செல்லுபடியாகும் `char` இல்லாதபோது `None` ஐத் தருகிறது:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// செல்லுபடியை புறக்கணித்து, `u32` ஐ `char` ஆக மாற்றுகிறது.
    ///
    /// எல்லா `கரி'களும் செல்லுபடியாகும் [` u32`] கள் என்பதை நினைவில் கொள்க, மேலும் அவற்றில் ஒன்றை அனுப்பலாம்
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// இருப்பினும், தலைகீழ் உண்மை இல்லை: எல்லா செல்லுபடியாகும் [`u32`] கள் செல்லுபடியாகும்`கரி` கள் அல்ல.
    /// `from_u32_unchecked()` இதைப் புறக்கணித்து, `char` க்கு கண்மூடித்தனமாக நடிக்கும், இது தவறான ஒன்றை உருவாக்கும்.
    ///
    ///
    /// # Safety
    ///
    /// இந்த செயல்பாடு பாதுகாப்பற்றது, ஏனெனில் இது தவறான `char` மதிப்புகளை உருவாக்கக்கூடும்.
    ///
    /// இந்த செயல்பாட்டின் பாதுகாப்பான பதிப்பிற்கு, [`from_u32`] செயல்பாட்டைப் பார்க்கவும்.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // பாதுகாப்பு: பாதுகாப்பு ஒப்பந்தத்தை அழைப்பவர் உறுதிப்படுத்த வேண்டும்.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// கொடுக்கப்பட்ட ரேடிக்ஸில் ஒரு இலக்கத்தை `char` ஆக மாற்றுகிறது.
    ///
    /// இங்கே ஒரு 'radix' சில நேரங்களில் 'base' என்றும் அழைக்கப்படுகிறது.
    /// இரண்டின் ஒரு ரேடிக்ஸ் ஒரு பைனரி எண், பத்து, தசம, மற்றும் பதினாறு, ஹெக்ஸாடெசிமல் ஆகியவற்றின் ரேடிக்ஸ் சில பொதுவான மதிப்புகளைக் கொடுக்கிறது.
    ///
    /// தன்னிச்சையான ரேடிஸ்கள் துணைபுரிகின்றன.
    ///
    /// `from_digit()` கொடுக்கப்பட்ட ரேடிக்ஸில் உள்ளீடு ஒரு இலக்கமாக இல்லாவிட்டால் `None` ஐ வழங்கும்.
    ///
    /// # Panics
    ///
    /// 36 ஐ விட பெரிய ரேடிக்ஸ் கொடுத்தால் Panics.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // தசம 11 என்பது அடிப்படை 16 இல் ஒற்றை இலக்கமாகும்
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// உள்ளீடு ஒரு இலக்கமாக இல்லாதபோது `None` ஐத் தருகிறது:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// ஒரு பெரிய ரேடிக்ஸ் கடந்து, ஒரு panic ஐ ஏற்படுத்துகிறது:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// கொடுக்கப்பட்ட ரேடிக்ஸில் ஒரு `char` ஒரு இலக்கமாக இருந்தால் சரிபார்க்கிறது.
    ///
    /// இங்கே ஒரு 'radix' சில நேரங்களில் 'base' என்றும் அழைக்கப்படுகிறது.
    /// இரண்டின் ஒரு ரேடிக்ஸ் ஒரு பைனரி எண், பத்து, தசம, மற்றும் பதினாறு, ஹெக்ஸாடெசிமல் ஆகியவற்றின் ரேடிக்ஸ் சில பொதுவான மதிப்புகளைக் கொடுக்கிறது.
    ///
    /// தன்னிச்சையான ரேடிஸ்கள் துணைபுரிகின்றன.
    ///
    /// [`is_numeric()`] உடன் ஒப்பிடும்போது, இந்த செயல்பாடு `0-9`, `a-z` மற்றும் `A-Z` எழுத்துக்களை மட்டுமே அங்கீகரிக்கிறது.
    ///
    /// 'Digit' பின்வரும் எழுத்துக்கள் மட்டுமே என வரையறுக்கப்படுகிறது:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' பற்றிய விரிவான புரிதலுக்கு, [`is_numeric()`] ஐப் பார்க்கவும்.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// 36 ஐ விட பெரிய ரேடிக்ஸ் கொடுத்தால் Panics.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// ஒரு பெரிய ரேடிக்ஸ் கடந்து, ஒரு panic ஐ ஏற்படுத்துகிறது:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// கொடுக்கப்பட்ட ரேடிக்ஸில் ஒரு `char` ஐ இலக்கமாக மாற்றுகிறது.
    ///
    /// இங்கே ஒரு 'radix' சில நேரங்களில் 'base' என்றும் அழைக்கப்படுகிறது.
    /// இரண்டின் ஒரு ரேடிக்ஸ் ஒரு பைனரி எண், பத்து, தசம, மற்றும் பதினாறு, ஹெக்ஸாடெசிமல் ஆகியவற்றின் ரேடிக்ஸ் சில பொதுவான மதிப்புகளைக் கொடுக்கிறது.
    ///
    /// தன்னிச்சையான ரேடிஸ்கள் துணைபுரிகின்றன.
    ///
    /// 'Digit' பின்வரும் எழுத்துக்கள் மட்டுமே என வரையறுக்கப்படுகிறது:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// கொடுக்கப்பட்ட ரேடிக்ஸில் ஒரு இலக்கத்தை `char` குறிப்பிடவில்லை என்றால் `None` ஐ வழங்குகிறது.
    ///
    /// # Panics
    ///
    /// 36 ஐ விட பெரிய ரேடிக்ஸ் கொடுத்தால் Panics.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// இலக்கமில்லாத முடிவுகளை கடந்து செல்வது தோல்வியடைகிறது:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// ஒரு பெரிய ரேடிக்ஸ் கடந்து, ஒரு panic ஐ ஏற்படுத்துகிறது:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` நிலையானது மற்றும் 10 அல்லது சிறியதாக இருக்கும் நிகழ்வுகளுக்கான செயல்பாட்டு வேகத்தை மேம்படுத்த குறியீடு இங்கே பிரிக்கப்பட்டுள்ளது
        //
        let val = if likely(radix <= 10) {
            // இலக்கமாக இல்லாவிட்டால், ரேடிக்ஸ் விட பெரிய எண் உருவாக்கப்படும்.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// ஒரு கதாபாத்திரத்தின் ஹெக்ஸாடெசிமல் யூனிகோட் தப்பிப்பதை `சார்` எனக் கொடுக்கும் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// இது `\u{NNNNNN}` வடிவத்தின் Rust தொடரியல் கொண்ட எழுத்துக்களில் இருந்து தப்பிக்கும், அங்கு `NNNNNN` என்பது ஒரு அறுகோண பிரதிநிதித்துவம் ஆகும்.
    ///
    ///
    /// # Examples
    ///
    /// ஒரு செயலாளராக:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ஐ நேரடியாகப் பயன்படுத்துதல்:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// இரண்டும் இதற்கு சமம்:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` ஐப் பயன்படுத்துதல்:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1, c==0 க்கு ஒரு இலக்கத்தை அச்சிட வேண்டும் என்று குறியீடு கணக்கிடுகிறது மற்றும் (இது ஒன்றே)(31, 32) கீழ்நோக்கி வருவதைத் தவிர்க்கிறது
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // மிக முக்கியமான ஹெக்ஸ் இலக்கத்தின் குறியீடு
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// விரிவாக்கப்பட்ட கிராஃபீம் குறியீட்டு புள்ளிகளில் இருந்து தப்பிக்க விருப்பமாக அனுமதிக்கும் `escape_debug` இன் நீட்டிக்கப்பட்ட பதிப்பு.
    /// இது ஒரு சரத்தின் தொடக்கத்தில் இருக்கும்போது தெளிவற்ற மதிப்பெண்கள் போன்ற எழுத்துக்களை சிறப்பாக வடிவமைக்க எங்களை அனுமதிக்கிறது.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// ஒரு கதாபாத்திரத்தின் நேரடி தப்பிக்கும் குறியீட்டை `char`s எனக் கொடுக்கும் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// இது `str` அல்லது `char` இன் `Debug` செயலாக்கங்களைப் போன்ற எழுத்துக்களில் இருந்து தப்பிக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// ஒரு செயலாளராக:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ஐ நேரடியாகப் பயன்படுத்துதல்:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// இரண்டும் இதற்கு சமம்:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` ஐப் பயன்படுத்துதல்:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// ஒரு கதாபாத்திரத்தின் நேரடி தப்பிக்கும் குறியீட்டை `char`s எனக் கொடுக்கும் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// C ++ 11 மற்றும் ஒத்த சி-குடும்ப மொழிகள் உட்பட பல்வேறு மொழிகளில் சட்டபூர்வமான எழுத்தறிவுகளை உருவாக்குவதற்கான ஒரு சார்புடன் இயல்புநிலை தேர்ந்தெடுக்கப்படுகிறது.
    /// சரியான விதிகள்:
    ///
    /// * தாவல் `\t` ஆக தப்பிக்கப்படுகிறது.
    /// * வண்டி திரும்புவது `\r` ஆக தப்பிக்கப்படுகிறது.
    /// * வரி ஊட்டம் `\n` ஆக தப்பிக்கப்படுகிறது.
    /// * ஒற்றை மேற்கோள் `\'` ஆக தப்பிக்கப்படுகிறது.
    /// * இரட்டை மேற்கோள் `\"` ஆக தப்பிக்கப்படுகிறது.
    /// * பேக்ஸ்லாஷ் `\\` ஆக தப்பிக்கப்படுகிறது.
    /// * 'அச்சிடக்கூடிய ASCII' வரம்பில் `0x20` .. `0x7e` உள்ளடக்கிய எந்த எழுத்தும் தப்பிக்கப்படவில்லை.
    /// * மற்ற அனைத்து கதாபாத்திரங்களுக்கும் ஹெக்ஸாடெசிமல் யூனிகோட் தப்பிக்கிறது;[`escape_unicode`] ஐப் பார்க்கவும்.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// ஒரு செயலாளராக:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ஐ நேரடியாகப் பயன்படுத்துதல்:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// இரண்டும் இதற்கு சமம்:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` ஐப் பயன்படுத்துதல்:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 இல் குறியிடப்பட்டால் இந்த `char` தேவைப்படும் பைட்டுகளின் எண்ணிக்கையை வழங்குகிறது.
    ///
    /// அந்த பைட்டுகளின் எண்ணிக்கை எப்போதும் 1 முதல் 4 வரை இருக்கும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` வகை அதன் உள்ளடக்கங்கள் UTF-8 என்று உத்தரவாதம் அளிக்கிறது, எனவே ஒவ்வொரு குறியீடு புள்ளியும் `&str` இல் `char` Vs ஆக குறிப்பிடப்பட்டால் அது எடுக்கும் நீளத்தை ஒப்பிடலாம்:
    ///
    ///
    /// ```
    /// // எழுத்துகளாக
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // இரண்டையும் மூன்று பைட்டுகளாகக் குறிப்பிடலாம்
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ஒரு &str ஆக, இவை இரண்டும் UTF-8 இல் குறியாக்கம் செய்யப்பட்டுள்ளன
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // அவர்கள் மொத்தம் ஆறு பைட்டுகள் எடுப்பதை நாம் காணலாம் ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... &str போன்றது
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 இல் குறியிடப்பட்டால் இந்த `char` தேவைப்படும் 16-பிட் குறியீடு அலகுகளின் எண்ணிக்கையை வழங்குகிறது.
    ///
    ///
    /// இந்த கருத்தின் கூடுதல் விளக்கத்திற்கு [`len_utf8()`] க்கான ஆவணங்களைக் காண்க.
    /// இந்த செயல்பாடு ஒரு கண்ணாடி, ஆனால் UTF-8 க்கு பதிலாக UTF-16 க்கு.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// வழங்கப்பட்ட பைட் பஃப்பரில் இந்த எழுத்தை UTF-8 என குறியாக்குகிறது, பின்னர் குறியிடப்பட்ட எழுத்தை கொண்ட இடையகத்தின் துணைக்குழுவை வழங்குகிறது.
    ///
    ///
    /// # Panics
    ///
    /// இடையக போதுமானதாக இல்லாவிட்டால் Panics.
    /// எந்த `char` ஐ குறியாக்க போதுமான நீளம் நான்கு இடையக உள்ளது.
    ///
    /// # Examples
    ///
    /// இந்த இரண்டு எடுத்துக்காட்டுகளிலும், 'ß' குறியாக்க இரண்டு பைட்டுகள் எடுக்கும்.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// மிகவும் சிறிய ஒரு இடையகம்:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // பாதுகாப்பு: `char` ஒரு வாகை அல்ல, எனவே இது செல்லுபடியாகும் UTF-8 ஆகும்.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// வழங்கப்பட்ட `u16` இடையகத்திற்கு இந்த எழுத்தை UTF-16 என குறியாக்குகிறது, பின்னர் குறியாக்கப்பட்ட எழுத்தை கொண்ட இடையகத்தின் சந்தாவை வழங்குகிறது.
    ///
    ///
    /// # Panics
    ///
    /// இடையக போதுமானதாக இல்லாவிட்டால் Panics.
    /// எந்த `char` ஐ குறியாக்க போதுமான நீளம் 2 இன் இடையகம் உள்ளது.
    ///
    /// # Examples
    ///
    /// இந்த இரண்டு எடுத்துக்காட்டுகளிலும், '𝕊' குறியாக்க இரண்டு `u16` களை எடுக்கும்.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// மிகவும் சிறிய ஒரு இடையகம்:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// இந்த `char` க்கு `Alphabetic` சொத்து இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// `Alphabetic` [Unicode Standard] இன் அத்தியாயம் 4 (எழுத்து பண்புகள்) இல் விவரிக்கப்பட்டுள்ளது மற்றும் [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] இல் குறிப்பிடப்பட்டுள்ளது.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // காதல் என்பது பல விஷயங்கள், ஆனால் அது அகரவரிசை அல்ல
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// இந்த `char` க்கு `Lowercase` சொத்து இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// `Lowercase` [Unicode Standard] இன் அத்தியாயம் 4 (எழுத்து பண்புகள்) இல் விவரிக்கப்பட்டுள்ளது மற்றும் [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] இல் குறிப்பிடப்பட்டுள்ளது.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // பல்வேறு சீன ஸ்கிரிப்டுகள் மற்றும் நிறுத்தற்குறிகள் வழக்கு இல்லை, மற்றும்:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// இந்த `char` க்கு `Uppercase` சொத்து இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// `Uppercase` [Unicode Standard] இன் அத்தியாயம் 4 (எழுத்து பண்புகள்) இல் விவரிக்கப்பட்டுள்ளது மற்றும் [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] இல் குறிப்பிடப்பட்டுள்ளது.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // பல்வேறு சீன ஸ்கிரிப்டுகள் மற்றும் நிறுத்தற்குறிகள் வழக்கு இல்லை, மற்றும்:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// இந்த `char` க்கு `White_Space` சொத்து இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] இல் குறிப்பிடப்பட்டுள்ளது.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // உடைக்காத இடம்
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// இந்த `char` [`is_alphabetic()`] அல்லது [`is_numeric()`] ஐ திருப்தி செய்தால் `true` ஐ வழங்குகிறது.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// இந்த `char` கட்டுப்பாட்டு குறியீடுகளுக்கான பொதுவான வகையைக் கொண்டிருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// கட்டுப்பாட்டுக் குறியீடுகள் (`Cc` இன் பொதுவான வகையுடன் குறியீடு புள்ளிகள்) [Unicode Standard] இன் அத்தியாயம் 4 (எழுத்து பண்புகள்) இல் விவரிக்கப்பட்டுள்ளன மற்றும் [Unicode Character Database][ucd] [`UnicodeData.txt`] இல் குறிப்பிடப்பட்டுள்ளன.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// இந்த `char` க்கு `Grapheme_Extend` சொத்து இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] இல் விவரிக்கப்பட்டுள்ளது மற்றும் [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] இல் குறிப்பிடப்பட்டுள்ளது.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// இந்த `char` எண்களுக்கான பொதுவான வகைகளில் ஒன்றைக் கொண்டிருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// எண்களுக்கான பொதுவான பிரிவுகள் (தசம இலக்கங்களுக்கான `Nd`, கடிதம் போன்ற எண் எழுத்துக்களுக்கு `Nl` மற்றும் பிற எண் எழுத்துகளுக்கு `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`] இல் குறிப்பிடப்பட்டுள்ளன.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// இந்த `char` இன் சிற்றெழுத்து மேப்பிங்கை ஒன்று அல்லது அதற்கு மேற்பட்டதாக வழங்கும் ஒரு ஈரேட்டரை வழங்குகிறது
    /// `char`s.
    ///
    /// இந்த `char` க்கு ஸ்மால் மேப்பிங் இல்லை என்றால், ஈரேட்டர் அதே `char` ஐ வழங்குகிறது.
    ///
    /// இந்த `char` ஆனது [Unicode Character Database][ucd] [`UnicodeData.txt`] ஆல் வழங்கப்பட்ட ஒன்று முதல் ஒரு சிறிய வரைபடத்தைக் கொண்டிருந்தால், ஐரேட்டர் அந்த `char` ஐ அளிக்கிறது.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// இந்த `char` க்கு சிறப்புக் கருத்தாய்வு தேவைப்பட்டால் (எ.கா. பல `கரி` கள்) ஐரேட்டர் [`SpecialCasing.txt`] வழங்கிய`கரி` (களை) அளிக்கிறது.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// இந்த செயல்பாடு தையல் இல்லாமல் நிபந்தனையற்ற வரைபடத்தை செய்கிறது.அதாவது, மாற்றம் சூழல் மற்றும் மொழியிலிருந்து சுயாதீனமாக உள்ளது.
    ///
    /// [Unicode Standard] இல், அத்தியாயம் 4 (எழுத்து பண்புகள்) பொதுவாக வழக்கு மேப்பிங்கைப் பற்றி விவாதிக்கிறது மற்றும் அத்தியாயம் 3 (Conformance) வழக்கு மாற்றத்திற்கான இயல்புநிலை வழிமுறையைப் பற்றி விவாதிக்கிறது.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ஒரு செயலாளராக:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ஐ நேரடியாகப் பயன்படுத்துதல்:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// இரண்டும் இதற்கு சமம்:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` ஐப் பயன்படுத்துதல்:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // சில நேரங்களில் இதன் விளைவாக ஒன்றுக்கு மேற்பட்ட எழுத்துக்கள் இருக்கும்:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // பெரிய எழுத்து மற்றும் சிறிய எழுத்துக்கள் இல்லாத எழுத்துக்கள் தங்களுக்குள் மாறுகின்றன.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// இந்த `char` இன் பெரிய மேப்பிங்கை ஒன்று அல்லது அதற்கு மேற்பட்டதாக வழங்கும் ஒரு ஐரேட்டரை வழங்குகிறது
    /// `char`s.
    ///
    /// இந்த `char` க்கு ஒரு பெரிய மேப்பிங் இல்லை என்றால், ஈரேட்டர் அதே `char` ஐ வழங்குகிறது.
    ///
    /// இந்த `char` க்கு [Unicode Character Database][ucd] [`UnicodeData.txt`] வழங்கிய ஒன்று முதல் ஒரு பெரிய மேப்பிங் இருந்தால், ஐரேட்டர் அந்த `char` ஐ அளிக்கிறது.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// இந்த `char` க்கு சிறப்புக் கருத்தாய்வு தேவைப்பட்டால் (எ.கா. பல `கரி` கள்) ஐரேட்டர் [`SpecialCasing.txt`] வழங்கிய`கரி` (களை) அளிக்கிறது.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// இந்த செயல்பாடு தையல் இல்லாமல் நிபந்தனையற்ற வரைபடத்தை செய்கிறது.அதாவது, மாற்றம் சூழல் மற்றும் மொழியிலிருந்து சுயாதீனமாக உள்ளது.
    ///
    /// [Unicode Standard] இல், அத்தியாயம் 4 (எழுத்து பண்புகள்) பொதுவாக வழக்கு மேப்பிங்கைப் பற்றி விவாதிக்கிறது மற்றும் அத்தியாயம் 3 (Conformance) வழக்கு மாற்றத்திற்கான இயல்புநிலை வழிமுறையைப் பற்றி விவாதிக்கிறது.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ஒரு செயலாளராக:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ஐ நேரடியாகப் பயன்படுத்துதல்:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// இரண்டும் இதற்கு சமம்:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` ஐப் பயன்படுத்துதல்:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // சில நேரங்களில் இதன் விளைவாக ஒன்றுக்கு மேற்பட்ட எழுத்துக்கள் இருக்கும்:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // பெரிய எழுத்து மற்றும் சிறிய எழுத்துக்கள் இல்லாத எழுத்துக்கள் தங்களுக்குள் மாறுகின்றன.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # இடம் பற்றிய குறிப்பு
    ///
    /// துருக்கியில், லத்தீன் மொழியில் 'i' க்கு சமமானது இரண்டுக்கு பதிலாக ஐந்து வடிவங்களைக் கொண்டுள்ளது:
    ///
    /// * 'Dotless': I/ı, சில நேரங்களில் எழுதப்பட்டது
    /// * 'Dotted': /I
    ///
    /// ஸ்மால் புள்ளியிடப்பட்ட 'i' லத்தீன் போன்றது என்பதை நினைவில் கொள்க.எனவே:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// இங்கே `upper_i` இன் மதிப்பு உரையின் மொழியை நம்பியுள்ளது: நாம் `en-US` இல் இருந்தால், அது `"I"` ஆக இருக்க வேண்டும், ஆனால் நாம் `tr_TR` இல் இருந்தால், அது `"İ"` ஆக இருக்க வேண்டும்.
    /// `to_uppercase()` இதை கணக்கில் எடுத்துக்கொள்ளாது, எனவே:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// மொழிகளில் உள்ளது.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// மதிப்பு ASCII வரம்பிற்குள் இருக்கிறதா என்று சரிபார்க்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// அதன் ASCII மேல் வழக்கில் மதிப்பின் நகலை சமமாக்குகிறது.
    ///
    /// ASCII எழுத்துக்கள் 'a' முதல் 'z' வரை 'A' முதல் 'Z' வரை மாற்றப்படுகின்றன, ஆனால் ASCII அல்லாத எழுத்துக்கள் மாறாமல் உள்ளன.
    ///
    /// இடத்தில் உள்ள மதிப்பை உயர்த்த, [`make_ascii_uppercase()`] ஐப் பயன்படுத்தவும்.
    ///
    /// ASCII அல்லாத எழுத்துக்களுக்கு மேலதிகமாக ASCII எழுத்துக்களை பெரிய எழுப்ப, [`to_uppercase()`] ஐப் பயன்படுத்தவும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// அதன் ஆஸ்கி லோயர் கேஸில் மதிப்பின் நகலை சமமாக்குகிறது.
    ///
    /// ASCII எழுத்துக்கள் 'A' முதல் 'Z' வரை 'a' முதல் 'z' வரை மாற்றப்படுகின்றன, ஆனால் ASCII அல்லாத எழுத்துக்கள் மாறாமல் உள்ளன.
    ///
    /// இடத்தில் மதிப்பைக் குறைக்க, [`make_ascii_lowercase()`] ஐப் பயன்படுத்தவும்.
    ///
    /// ASCII அல்லாத எழுத்துக்களுக்கு கூடுதலாக ASCII எழுத்துக்களைக் குறைக்க, [`to_lowercase()`] ஐப் பயன்படுத்தவும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// இரண்டு மதிப்புகள் ஒரு ஆஸ்கி வழக்கு-உணர்வற்ற பொருத்தம் என்பதை சரிபார்க்கிறது.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` க்கு சமம்.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// இந்த வகையை அதன் ASCII மேல் வழக்குக்கு சமமான இடத்தில் மாற்றுகிறது.
    ///
    /// ASCII எழுத்துக்கள் 'a' முதல் 'z' வரை 'A' முதல் 'Z' வரை மாற்றப்படுகின்றன, ஆனால் ASCII அல்லாத எழுத்துக்கள் மாறாமல் உள்ளன.
    ///
    /// ஏற்கனவே உள்ள ஒன்றை மாற்றாமல் புதிய பெரிய மதிப்பைத் தர, [`to_ascii_uppercase()`] ஐப் பயன்படுத்தவும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// இந்த வகையை அதன் ASCII லோயர் கேஸ் சமமான இடத்தில் மாற்றுகிறது.
    ///
    /// ASCII எழுத்துக்கள் 'A' முதல் 'Z' வரை 'a' முதல் 'z' வரை மாற்றப்படுகின்றன, ஆனால் ASCII அல்லாத எழுத்துக்கள் மாறாமல் உள்ளன.
    ///
    /// ஏற்கனவே உள்ள ஒன்றை மாற்றாமல் புதிய சிறிய மதிப்பைத் தர, [`to_ascii_lowercase()`] ஐப் பயன்படுத்தவும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// மதிப்பு ஒரு ஆஸ்கி அகரவரிசை எழுத்து என்பதை சரிபார்க்கிறது:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', அல்லது
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// மதிப்பு ஒரு ஆஸ்கி பெரிய எழுத்துக்குறி என்பதை சரிபார்க்கிறது:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// மதிப்பு ஒரு ஆஸ்கி சிற்றெழுத்து எழுத்து என்பதை சரிபார்க்கிறது:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// மதிப்பு ஒரு ஆஸ்கி எண்ணெழுத்து எழுத்து என்பதை சரிபார்க்கிறது:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', அல்லது
    /// - U + 0061 'a' ..=U + 007A 'z', அல்லது
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// மதிப்பு ஒரு ஆஸ்கி தசம இலக்கமாக இருந்தால் சரிபார்க்கிறது:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// மதிப்பு ASCII ஹெக்ஸாடெசிமல் இலக்கமாக இருந்தால் சரிபார்க்கிறது:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', அல்லது
    /// - U + 0041 'A' ..=U + 0046 'F', அல்லது
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// மதிப்பு ஒரு ஆஸ்கி நிறுத்தற்குறி எழுத்து என்பதை சரிபார்க்கிறது:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, அல்லது
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, அல்லது
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, அல்லது
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// மதிப்பு ஒரு ஆஸ்கி கிராஃபிக் எழுத்து என்றால் சரிபார்க்கிறது:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// மதிப்பு ஒரு ஆஸ்கி வைட்ஸ்பேஸ் எழுத்து என்றால் சரிபார்க்கிறது:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, அல்லது U + 000D CARRIAGE RETURN.
    ///
    /// Rust WhatWG இன்ஃப்ரா ஸ்டாண்டர்டின் [definition of ASCII whitespace][infra-aw] ஐப் பயன்படுத்துகிறது.பரந்த பயன்பாட்டில் வேறு பல வரையறைகள் உள்ளன.
    /// உதாரணமாக, [the POSIX locale][pct] இல் U + 000B VERTICAL TAB மற்றும் மேலே உள்ள அனைத்து எழுத்துகளும் அடங்கும், ஆனால்-அதே விவரக்குறிப்பிலிருந்து-[Bourne shell இல் "field splitting" க்கான இயல்புநிலை விதி][bfs]*மட்டுமே* SPACE, HORIZONTAL TAB மற்றும் இடைவெளியாக LINE FEED.
    ///
    ///
    /// ஏற்கனவே உள்ள கோப்பு வடிவமைப்பை செயலாக்கும் ஒரு நிரலை நீங்கள் எழுதுகிறீர்கள் என்றால், இந்த செயல்பாட்டைப் பயன்படுத்துவதற்கு முன்பு அந்த வடிவமைப்பின் இடைவெளியின் வரையறை என்ன என்பதைச் சரிபார்க்கவும்.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// மதிப்பு ஒரு ஆஸ்கி கட்டுப்பாட்டு எழுத்து என்றால் சரிபார்க்கிறது:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, அல்லது U + 007F DELETE.
    /// பெரும்பாலான ASCII இடைவெளியின் எழுத்துக்கள் கட்டுப்பாட்டு எழுத்துக்கள் என்பதை நினைவில் கொள்க, ஆனால் SPACE இல்லை.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// வழங்கப்பட்ட பைட் பஃப்பரில் ஒரு மூல u32 மதிப்பை UTF-8 என குறியாக்குகிறது, பின்னர் குறியாக்கப்பட்ட எழுத்தை கொண்ட இடையகத்தின் சந்தாவை வழங்குகிறது.
///
///
/// `char::encode_utf8` போலல்லாமல், இந்த முறை வாடகை வரம்பில் குறியீட்டு புள்ளிகளையும் கையாளுகிறது.
/// (வாடகை வரம்பில் ஒரு `char` ஐ உருவாக்குவது UB ஆகும்.) இதன் விளைவாக செல்லுபடியாகும் [generalized UTF-8] ஆனால் செல்லுபடியாகும் UTF-8 அல்ல.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// இடையக போதுமானதாக இல்லாவிட்டால் Panics.
/// எந்த `char` ஐ குறியாக்க போதுமான நீளம் நான்கு இடையக உள்ளது.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// வழங்கப்பட்ட `u16` இடையகத்திற்கு ஒரு மூல u32 மதிப்பை UTF-16 என குறியாக்குகிறது, பின்னர் குறியாக்கப்பட்ட தன்மையைக் கொண்ட இடையகத்தின் சந்தாவை வழங்குகிறது.
///
///
/// `char::encode_utf16` போலல்லாமல், இந்த முறை வாடகை வரம்பில் குறியீட்டு புள்ளிகளையும் கையாளுகிறது.
/// (வாடகை வரம்பில் ஒரு `char` ஐ உருவாக்குவது யுபி ஆகும்.)
///
/// # Panics
///
/// இடையக போதுமானதாக இல்லாவிட்டால் Panics.
/// எந்த `char` ஐ குறியாக்க போதுமான நீளம் 2 இன் இடையகம் உள்ளது.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // பாதுகாப்பு: எழுத போதுமான பிட்டுகள் உள்ளதா என்பதை ஒவ்வொரு கையும் சரிபார்க்கிறது
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP மூலம் விழுகிறது
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // துணை விமானங்கள் வாகைகளாக உடைகின்றன.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}