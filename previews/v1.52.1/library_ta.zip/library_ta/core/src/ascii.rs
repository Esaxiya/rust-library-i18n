//! ஆஸ்கி சரங்கள் மற்றும் எழுத்துக்களில் செயல்பாடுகள்.
//!
//! Rust இல் உள்ள பெரும்பாலான சரம் செயல்பாடுகள் UTF-8 சரங்களில் செயல்படுகின்றன.
//! இருப்பினும், சில நேரங்களில் ஒரு குறிப்பிட்ட செயல்பாட்டிற்கான ASCII எழுத்தை மட்டுமே கருத்தில் கொள்வது கூடுதல் அர்த்தமுள்ளதாக இருக்கும்.
//!
//! [`escape_default`] செயல்பாடு கொடுக்கப்பட்ட எழுத்தின் தப்பித்த பதிப்பின் பைட்டுகளுக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
//!
//!

#![stable(feature = "core_ascii", since = "1.26.0")]

use crate::fmt;
use crate::iter::FusedIterator;
use crate::ops::Range;
use crate::str::from_utf8_unchecked;

/// ஒரு பைட்டின் தப்பித்த பதிப்பின் மீது ஒரு ஈரேட்டர்.
///
/// இந்த `struct` [`escape_default`] செயல்பாட்டால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct EscapeDefault {
    range: Range<usize>,
    data: [u8; 4],
}

/// `u8` இன் தப்பித்த பதிப்பை உருவாக்கும் ஒரு ஈரேட்டரை வழங்குகிறது.
///
/// C ++ 11 மற்றும் ஒத்த சி-குடும்ப மொழிகள் உட்பட பல்வேறு மொழிகளில் சட்டபூர்வமான எழுத்தறிவுகளை உருவாக்குவதற்கான ஒரு சார்புடன் இயல்புநிலை தேர்ந்தெடுக்கப்படுகிறது.
/// சரியான விதிகள்:
///
/// * தாவல் `\t` ஆக தப்பிக்கப்படுகிறது.
/// * வண்டி திரும்புவது `\r` ஆக தப்பிக்கப்படுகிறது.
/// * வரி ஊட்டம் `\n` ஆக தப்பிக்கப்படுகிறது.
/// * ஒற்றை மேற்கோள் `\'` ஆக தப்பிக்கப்படுகிறது.
/// * இரட்டை மேற்கோள் `\"` ஆக தப்பிக்கப்படுகிறது.
/// * பேக்ஸ்லாஷ் `\\` ஆக தப்பிக்கப்படுகிறது.
/// * 'அச்சிடக்கூடிய ASCII' வரம்பில் `0x20` .. `0x7e` உள்ளடக்கிய எந்த எழுத்தும் தப்பிக்கப்படவில்லை.
/// * வேறு எந்த எழுத்துகளுக்கும் '\xNN' வடிவத்தின் ஹெக்ஸ் தப்பிக்கும்.
/// * இந்த செயல்பாட்டால் யூனிகோட் தப்பிப்புகள் ஒருபோதும் உருவாக்கப்படுவதில்லை.
///
/// # Examples
///
/// ```
/// use std::ascii;
///
/// let escaped = ascii::escape_default(b'0').next().unwrap();
/// assert_eq!(b'0', escaped);
///
/// let mut escaped = ascii::escape_default(b'\t');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b't', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\r');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'r', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\n');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'n', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\'');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\'', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'"');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'"', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\\');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\\', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\x9d');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'x', escaped.next().unwrap());
/// assert_eq!(b'9', escaped.next().unwrap());
/// assert_eq!(b'd', escaped.next().unwrap());
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn escape_default(c: u8) -> EscapeDefault {
    let (data, len) = match c {
        b'\t' => ([b'\\', b't', 0, 0], 2),
        b'\r' => ([b'\\', b'r', 0, 0], 2),
        b'\n' => ([b'\\', b'n', 0, 0], 2),
        b'\\' => ([b'\\', b'\\', 0, 0], 2),
        b'\'' => ([b'\\', b'\'', 0, 0], 2),
        b'"' => ([b'\\', b'"', 0, 0], 2),
        b'\x20'..=b'\x7e' => ([c, 0, 0, 0], 1),
        _ => ([b'\\', b'x', hexify(c >> 4), hexify(c & 0xf)], 4),
    };

    return EscapeDefault { range: 0..len, data };

    fn hexify(b: u8) -> u8 {
        match b {
            0..=9 => b'0' + b,
            _ => b'a' + b - 10,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Iterator for EscapeDefault {
    type Item = u8;
    fn next(&mut self) -> Option<u8> {
        self.range.next().map(|i| self.data[i])
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.range.size_hint()
    }
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl DoubleEndedIterator for EscapeDefault {
    fn next_back(&mut self) -> Option<u8> {
        self.range.next_back().map(|i| self.data[i])
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ExactSizeIterator for EscapeDefault {}
#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for EscapeDefault {}

#[stable(feature = "ascii_escape_display", since = "1.39.0")]
impl fmt::Display for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // பாதுகாப்பு: சரி, ஏனெனில் `escape_default` செல்லுபடியாகும் utf-8 தரவை மட்டுமே உருவாக்கியது
        f.write_str(unsafe { from_utf8_unchecked(&self.data[self.range.clone()]) })
    }
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("EscapeDefault { .. }")
    }
}