//! இந்த தொகுதி பிற அறிவிக்கப்பட்ட வகைகளால் நிழலாடாத பயன்பாட்டை அனுமதிக்க பழமையான வகைகளை மறுபரிசீலனை செய்கிறது.
//!
//! இது பொதுவாக மேக்ரோ உருவாக்கிய குறியீட்டில் மட்டுமே பயனுள்ளதாக இருக்கும்.
//!
//! இதற்கு ஒரு எடுத்துக்காட்டு என்னவென்றால், ஒரு புதிய கட்டமைப்பு மற்றும் அதற்கான தூண்டுதலை உருவாக்கும் போது:
//!
//! ```rust,compile_fail
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!
//! `SOME_PROPERTY` தொடர்புடைய மாறிலி தொகுக்காது என்பதை நினைவில் கொள்க, ஏனெனில் அதன் வகை `bool` என்பது பழமையான bool வகையை விட struct ஐ குறிக்கிறது.
//!
//!
//! சரியான செயல்படுத்தல் இப்படி இருக்கும்:
//!
//! ```rust
//! # #[allow(non_camel_case_types)]
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: core::primitive::bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!

#[stable(feature = "core_primitive", since = "1.43.0")]
pub use bool;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use char;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use isize;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use str;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use usize;