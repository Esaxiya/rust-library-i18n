use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// இந்த செயல்பாடு ஒரே இடத்தில் பயன்படுத்தப்பட்டு, அதன் செயல்பாட்டை இன்லைன் செய்ய முடியும் என்றாலும், அவ்வாறு செய்வதற்கான முந்தைய முயற்சிகள் rustc ஐ மெதுவாக்கியது:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// நினைவகத் தொகுதியின் தளவமைப்பு.
///
/// `Layout` இன் ஒரு நிகழ்வு நினைவகத்தின் ஒரு குறிப்பிட்ட அமைப்பை விவரிக்கிறது.
/// ஒரு ஒதுக்கீட்டாளருக்கு கொடுக்க ஒரு உள்ளீடாக நீங்கள் `Layout` ஐ உருவாக்குகிறீர்கள்.
///
/// எல்லா தளவமைப்புகளும் தொடர்புடைய அளவு மற்றும் இரண்டு சக்தி கொண்ட சீரமைப்பு ஆகியவற்றைக் கொண்டுள்ளன.
///
/// (அனைத்து நினைவக கோரிக்கைகளும் பூஜ்ஜியமற்றதாக இருக்க வேண்டும் என்று `GlobalAlloc` க்கு தேவைப்பட்டாலும், தளவமைப்புகள் பூஜ்ஜியமற்ற அளவைக் கொண்டிருக்க *தேவையில்லை* என்பதை நினைவில் கொள்க.
/// ஒரு அழைப்பாளர் இது போன்ற நிபந்தனைகளை பூர்த்தி செய்வதை உறுதி செய்ய வேண்டும், குறிப்பிட்ட ஒதுக்கீட்டை தளர்வான தேவைகளுடன் பயன்படுத்த வேண்டும் அல்லது அதிக மென்மையான `Allocator` இடைமுகத்தைப் பயன்படுத்த வேண்டும்.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // கோரப்பட்ட நினைவகத்தின் தொகுதி, பைட்டுகளில் அளவிடப்படுகிறது.
    size_: usize,

    // கோரப்பட்ட நினைவகத்தின் தொகுதி, பைட்டுகளில் அளவிடப்படுகிறது.
    // இது எப்போதுமே ஒரு சக்தி-இரண்டு என்பதை நாங்கள் உறுதிசெய்கிறோம், ஏனென்றால் `posix_memalign` போன்ற API க்கு இது தேவைப்படுகிறது, மேலும் இது லேஅவுட் கட்டமைப்பாளர்களுக்கு விதிக்க நியாயமான தடையாகும்.
    //
    //
    // (இருப்பினும், எங்களுக்கு ஒத்ததாக `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) தேவையில்லை
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// கொடுக்கப்பட்ட `size` மற்றும் `align` இலிருந்து ஒரு `Layout` ஐ உருவாக்குகிறது, அல்லது பின்வரும் நிபந்தனைகளில் ஏதேனும் பூர்த்தி செய்யப்படாவிட்டால் `LayoutError` ஐ வழங்குகிறது:
    ///
    /// * `align` பூஜ்ஜியமாக இருக்கக்கூடாது,
    ///
    /// * `align` இரண்டு சக்தியாக இருக்க வேண்டும்,
    ///
    /// * `size`, `align` இன் அருகிலுள்ள பல மடங்கு வரை வட்டமிடும்போது, நிரம்பி வழியக்கூடாது (அதாவது, வட்டமான மதிப்பு `usize::MAX` ஐ விட குறைவாகவோ அல்லது சமமாகவோ இருக்க வேண்டும்).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (இரண்டு சக்தி என்பது சீரமைப்பைக் குறிக்கிறது!=0.)

        // வட்டமான அளவு:
        //   size_rounded_up=(அளவு + சீரமை, 1)&! (சீரமை, 1);
        //
        // அந்த சீரமைப்பு மேலே இருந்து எங்களுக்குத் தெரியும்!=0.
        // சேர்ப்பது (சீரமைத்தல், 1) நிரம்பி வழியவில்லை என்றால், வட்டமிடுவது நன்றாக இருக்கும்.
        //
        // மாறாக,&-மாஸ்கிங்! (சீரமை, 1) குறைந்த-வரிசை-பிட்களை மட்டுமே கழிக்கும்.
        // ஆகவே, கூட்டுத்தொகையுடன் வழிதல் ஏற்பட்டால்,&-மாஸ்க் அந்த வழிதல் செயல்தவிர்க்க போதுமான அளவு கழிக்க முடியாது.
        //
        //
        // கூட்டுத்தொகை வழிதல் சரிபார்க்க தேவையானது மற்றும் போதுமானது என்பதை மேலே குறிக்கிறது.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // பாதுகாப்பு: `from_size_align_unchecked` க்கான நிபந்தனைகள் உள்ளன
        // மேலே சரிபார்க்கப்பட்டது.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// எல்லா காசோலைகளையும் தவிர்த்து, ஒரு தளவமைப்பை உருவாக்குகிறது.
    ///
    /// # Safety
    ///
    /// [`Layout::from_size_align`] இலிருந்து முன் நிபந்தனைகளை சரிபார்க்காததால் இந்த செயல்பாடு பாதுகாப்பற்றது.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // பாதுகாப்பு: அழைப்பாளர் `align` பூஜ்ஜியத்தை விட அதிகமாக இருப்பதை உறுதி செய்ய வேண்டும்.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// இந்த தளவமைப்பின் நினைவக தொகுதிக்கான பைட்டுகளில் குறைந்தபட்ச அளவு.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// இந்த தளவமைப்பின் நினைவக தொகுதிக்கான குறைந்தபட்ச பைட் சீரமைப்பு.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` வகை மதிப்பை வைத்திருக்க ஏற்ற `Layout` ஐ உருவாக்குகிறது.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // பாதுகாப்பு: சீரமைப்பு Rust ஆல் இரண்டு சக்தியாக இருக்கும்
        // அளவு + சீரமை காம்போ எங்கள் முகவரி இடத்தில் பொருந்தும் என்று உத்தரவாதம் அளிக்கப்பட்டுள்ளது.
        // இதன் விளைவாக, தேர்வுசெய்யப்படாத கட்டமைப்பாளரைப் பயன்படுத்தி, panics குறியீட்டைச் செருகுவதைத் தவிர்க்க, அது போதுமானதாக இல்லை என்றால்.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` க்கான ஆதரவு கட்டமைப்பை ஒதுக்க பயன்படுத்தக்கூடிய ஒரு பதிவை விவரிக்கும் தளவமைப்பை உருவாக்குகிறது (இது ஒரு trait அல்லது ஒரு துண்டு போன்ற பிற அளவிடப்படாத வகையாக இருக்கலாம்).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // பாதுகாப்பு: இது ஏன் பாதுகாப்பற்ற மாறுபாட்டைப் பயன்படுத்துகிறது என்பதற்கான `new` இல் பகுத்தறிவைக் காண்க
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` க்கான ஆதரவு கட்டமைப்பை ஒதுக்க பயன்படுத்தக்கூடிய ஒரு பதிவை விவரிக்கும் தளவமைப்பை உருவாக்குகிறது (இது ஒரு trait அல்லது ஒரு துண்டு போன்ற பிற அளவிடப்படாத வகையாக இருக்கலாம்).
    ///
    /// # Safety
    ///
    /// பின்வரும் நிபந்தனைகள் இருந்தால் மட்டுமே இந்த செயல்பாடு பாதுகாப்பானது:
    ///
    /// - `T` `Sized` ஆக இருந்தால், இந்த செயல்பாடு எப்போதும் அழைக்க பாதுகாப்பானது.
    /// - `T` இன் அளவிடப்படாத வால் என்றால்:
    ///     - ஒரு [slice], பின்னர் ஸ்லைஸ் வால் நீளம் ஒரு முழு எண்ணாக இருக்க வேண்டும், மேலும் *முழு மதிப்பு*(டைனமிக் வால் நீளம் + நிலையான அளவிலான முன்னொட்டு) அளவு `isize` இல் பொருந்த வேண்டும்.
    ///     - ஒரு [trait object], பின்னர் சுட்டிக்காட்டியின் vtable பகுதி ஒரு அளவிடப்படாத ஒருங்கிணைப்பால் பெறப்பட்ட `T` வகைக்கு செல்லுபடியாகும் vtable ஐ சுட்டிக்காட்ட வேண்டும், மேலும் *முழு மதிப்பு*(டைனமிக் வால் நீளம் + நிலையான அளவிலான முன்னொட்டு) அளவு `isize` இல் பொருந்த வேண்டும்.
    ///
    ///     - ஒரு (unstable) [extern type], பின்னர் இந்த செயல்பாடு எப்போதும் அழைப்பது பாதுகாப்பானது, ஆனால் வெளிப்புற வகையின் தளவமைப்பு அறியப்படாததால் panic அல்லது தவறான மதிப்பைத் தரலாம்.
    ///     இது ஒரு வெளிப்புற வகை வால் குறித்த குறிப்பில் [`Layout::for_value`] இன் அதே நடத்தை.
    ///     - இல்லையெனில், இந்த செயல்பாட்டை அழைக்க பழமைவாதமாக அனுமதிக்கப்படவில்லை.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // பாதுகாப்பு: இந்த செயல்பாடுகளின் முன்நிபந்தனைகளை அழைப்பாளருக்கு அனுப்புகிறோம்
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // பாதுகாப்பு: இது ஏன் பாதுகாப்பற்ற மாறுபாட்டைப் பயன்படுத்துகிறது என்பதற்கான `new` இல் பகுத்தறிவைக் காண்க
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// தொங்கும் ஒரு `NonNull` ஐ உருவாக்குகிறது, ஆனால் இந்த தளவமைப்புக்கு நன்கு சீரமைக்கப்பட்டது.
    ///
    /// சுட்டிக்காட்டி மதிப்பு செல்லுபடியாகும் சுட்டிக்காட்டியைக் குறிக்கக்கூடும் என்பதை நினைவில் கொள்க, அதாவது இது "not yet initialized" செண்டினல் மதிப்பாக பயன்படுத்தப்படக்கூடாது.
    /// சோம்பேறியாக ஒதுக்கும் வகைகள் வேறு சில வழிகளில் துவக்கத்தைக் கண்காணிக்க வேண்டும்.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // பாதுகாப்பு: சீரமை பூஜ்ஜியமற்றது என்று உத்தரவாதம் அளிக்கப்படுகிறது
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` போன்ற அதே தளவமைப்பின் மதிப்பை வைத்திருக்கக்கூடிய பதிவை விவரிக்கும் ஒரு தளவமைப்பை உருவாக்குகிறது, ஆனால் இது `align` (பைட்டுகளில் அளவிடப்படுகிறது) சீரமைப்புடன் சீரமைக்கப்படுகிறது.
    ///
    ///
    /// `self` ஏற்கனவே பரிந்துரைக்கப்பட்ட சீரமைப்பை சந்தித்தால், பின்னர் `self` ஐ வழங்குகிறது.
    ///
    /// திரும்பிய தளவமைப்பு வேறுபட்ட சீரமைப்பு உள்ளதா என்பதைப் பொருட்படுத்தாமல், இந்த முறை ஒட்டுமொத்த அளவிற்கு எந்த திணிப்பையும் சேர்க்காது என்பதை நினைவில் கொள்க.
    /// வேறு வார்த்தைகளில் கூறுவதானால், `K` அளவு 16 ஐக் கொண்டிருந்தால், `K.align_to(32)`*இன்னும்* அளவு 16 ஐக் கொண்டிருக்கும்.
    ///
    /// `self.size()` மற்றும் கொடுக்கப்பட்ட `align` ஆகியவற்றின் கலவையானது [`Layout::from_size_align`] இல் பட்டியலிடப்பட்டுள்ள நிபந்தனைகளை மீறினால் பிழையை வழங்குகிறது.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// பின்வரும் முகவரி `align` ஐ (பைட்டுகளில் அளவிடப்படுகிறது) பூர்த்திசெய்யும் என்பதை உறுதிப்படுத்த `self` க்குப் பிறகு நாம் செருக வேண்டிய திணிப்பின் அளவை வழங்குகிறது.
    ///
    /// எ.கா.
    ///
    ///
    /// இந்த செயல்பாட்டின் வருவாய் மதிப்பு `align` இரண்டு சக்தியாக இல்லாவிட்டால் எந்த அர்த்தமும் இல்லை.
    ///
    /// திரும்பப் பெறப்பட்ட மதிப்பின் பயன்பாட்டிற்கு, ஒதுக்கப்பட்ட நினைவகத் தொகுதிக்கான தொடக்க முகவரியின் சீரமைப்புக்கு `align` குறைவாகவோ அல்லது சமமாகவோ இருக்க வேண்டும் என்பதை நினைவில் கொள்க.இந்த தடையை பூர்த்தி செய்வதற்கான ஒரு வழி `align <= self.align()` ஐ உறுதி செய்வதாகும்.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // வட்டமான மதிப்பு:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // பின்னர் திணிப்பு வேறுபாட்டை நாங்கள் தருகிறோம்: `len_rounded_up - len`.
        //
        // நாங்கள் முழுவதும் மட்டு எண்கணிதத்தைப் பயன்படுத்துகிறோம்:
        //
        // 1. align> 0 என உத்தரவாதம் அளிக்கப்படுகிறது, எனவே சீரமை, 1 எப்போதும் செல்லுபடியாகும்.
        //
        // 2.
        // `len + align - 1` அதிகபட்சமாக `align - 1` மூலம் நிரம்பி வழியும், எனவே `!(align - 1)` உடன்&-மாஸ்க் வழிதல் விஷயத்தில், `len_rounded_up` தானாகவே 0 ஆக இருப்பதை உறுதி செய்யும்.
        //
        //    இவ்வாறு திரும்பிய திணிப்பு, `len` இல் சேர்க்கப்படும்போது, 0 ஐ அளிக்கிறது, இது `align` சீரமைப்பை அற்பமாக திருப்தி செய்கிறது.
        //
        // (நிச்சயமாக, மேலே உள்ள முறையில் நினைவகத் தொகுதிகளை ஒதுக்க முயற்சிக்கும் அளவு மற்றும் திணிப்பு வழிதல் ஒதுக்கீட்டாளர் எப்படியும் ஒரு பிழையை ஏற்படுத்தும்.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// இந்த தளவமைப்பின் அளவை அமைப்பின் சீரமைப்பின் பல மடங்கு வரை வட்டமிடுவதன் மூலம் ஒரு தளவமைப்பை உருவாக்குகிறது.
    ///
    ///
    /// இது `padding_needed_for` இன் முடிவை தளவமைப்பின் தற்போதைய அளவுக்குச் சேர்ப்பதற்குச் சமம்.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // இது நிரம்பி வழிய முடியாது.தளவமைப்பின் மாற்றத்திலிருந்து மேற்கோள்:
        // > `size`, `align` இன் அருகிலுள்ள பல மடங்கு வரை வட்டமிடும்போது,
        // > நிரம்பி வழியக்கூடாது (அதாவது, வட்டமான மதிப்பு குறைவாக இருக்க வேண்டும்
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` இன் `n` நிகழ்வுகளுக்கான பதிவை விவரிக்கும் ஒரு தளவமைப்பை உருவாக்குகிறது, ஒவ்வொன்றிற்கும் இடையில் பொருத்தமான அளவு திணிப்புடன், ஒவ்வொரு நிகழ்விற்கும் அதன் கோரப்பட்ட அளவு மற்றும் சீரமைப்பு வழங்கப்படுவதை உறுதிசெய்கிறது.
    /// வெற்றியில், `(k, offs)` ஐ வழங்குகிறது, அங்கு `k` என்பது வரிசையின் தளவமைப்பு மற்றும் `offs` என்பது வரிசையில் உள்ள ஒவ்வொரு தனிமத்தின் தொடக்கத்திற்கும் இடையிலான தூரம்.
    ///
    /// எண்கணித வழிதல், `LayoutError` ஐ வழங்குகிறது.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // இது நிரம்பி வழிய முடியாது.தளவமைப்பின் மாற்றத்திலிருந்து மேற்கோள்:
        // > `size`, `align` இன் அருகிலுள்ள பல மடங்கு வரை வட்டமிடும்போது,
        // > நிரம்பி வழியக்கூடாது (அதாவது, வட்டமான மதிப்பு குறைவாக இருக்க வேண்டும்
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // பாதுகாப்பு: self.align ஏற்கனவே செல்லுபடியாகும் என்று அறியப்படுகிறது மற்றும் ஒதுக்கீடு_அளவு உள்ளது
        // ஏற்கனவே துடுப்பு.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` க்கான பதிவை விவரிக்கும் தளவமைப்பை உருவாக்குகிறது, அதன்பிறகு `next`, `next` சரியாக சீரமைக்கப்படுவதை உறுதி செய்வதற்கு தேவையான எந்த திணிப்பையும் உள்ளடக்கியது, ஆனால் *பின்னால் திணிப்பு இல்லை*.
    ///
    /// சி பிரதிநிதித்துவ தளவமைப்பு `repr(C)` உடன் பொருந்த, நீங்கள் அனைத்து புலங்களுடனும் தளவமைப்பை நீட்டித்த பிறகு `pad_to_align` ஐ அழைக்க வேண்டும்.
    /// (இயல்புநிலை Rust பிரதிநிதித்துவ தளவமைப்பு `repr(Rust)`, as it is unspecified.) உடன் பொருந்த வழி இல்லை
    ///
    /// இரு பகுதிகளின் சீரமைப்பை உறுதி செய்வதற்காக, விளைந்த தளவமைப்பின் சீரமைப்பு `self` மற்றும் `next` இன் அதிகபட்சமாக இருக்கும் என்பதை நினைவில் கொள்க.
    ///
    /// `Ok((k, offset))` ஐ வழங்குகிறது, அங்கு `k` என்பது ஒருங்கிணைந்த பதிவின் தளவமைப்பு மற்றும் `offset` என்பது பைட்டுகளில், இணைந்த பதிவில் பதிக்கப்பட்ட `next` இன் தொடக்கத்தின் தொடர்புடைய இடமாகும் (பதிவு ஆஃப்செட் 0 இல் தொடங்குகிறது என்று கருதி).
    ///
    ///
    /// எண்கணித வழிதல், `LayoutError` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ஒரு `#[repr(C)]` கட்டமைப்பின் தளவமைப்பு மற்றும் அதன் புலங்களின் தளவமைப்புகளிலிருந்து புலங்களின் ஆஃப்செட்களைக் கணக்கிட:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` உடன் இறுதி செய்ய நினைவில் கொள்க!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // அது வேலை செய்கிறது என்பதை சோதிக்கவும்
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` இன் `n` நிகழ்வுகளுக்கான பதிவை விவரிக்கும் தளவமைப்பை உருவாக்குகிறது, ஒவ்வொரு நிகழ்விற்கும் இடையில் திணிப்பு இல்லை.
    ///
    /// `repeat` ஐப் போலன்றி, `self` இன் குறிப்பிட்ட நிகழ்வுகள் சரியாக சீரமைக்கப்பட்டிருந்தாலும் கூட, `self` இன் தொடர்ச்சியான நிகழ்வுகள் சரியாக சீரமைக்கப்படும் என்பதற்கு `repeat_packed` உத்தரவாதம் அளிக்காது என்பதை நினைவில் கொள்க.
    /// வேறு வார்த்தைகளில் கூறுவதானால், ஒரு வரிசையை ஒதுக்க `repeat_packed` ஆல் வழங்கப்பட்ட தளவமைப்பு பயன்படுத்தப்பட்டால், வரிசையில் உள்ள அனைத்து கூறுகளும் சரியாக சீரமைக்கப்படும் என்பதற்கு உத்தரவாதம் இல்லை.
    ///
    /// எண்கணித வழிதல், `LayoutError` ஐ வழங்குகிறது.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self` க்கான பதிவை விவரிக்கும் தளவமைப்பை உருவாக்குகிறது, பின்னர் `next` இரண்டிற்கும் இடையே கூடுதல் திணிப்பு இல்லை.
    /// எந்த திணிப்பும் செருகப்படாததால், `next` இன் சீரமைப்பு பொருத்தமற்றது, மேலும் இதன் விளைவாக அமைப்பில் *எதுவும்* இணைக்கப்படவில்லை.
    ///
    ///
    /// எண்கணித வழிதல், `LayoutError` ஐ வழங்குகிறது.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` க்கான பதிவை விவரிக்கும் தளவமைப்பை உருவாக்குகிறது.
    ///
    /// எண்கணித வழிதல், `LayoutError` ஐ வழங்குகிறது.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` அல்லது வேறு சில `Layout` கட்டமைப்பாளருக்கு வழங்கப்பட்ட அளவுருக்கள் அதன் ஆவணப்படுத்தப்பட்ட தடைகளை பூர்த்தி செய்யாது.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (trait பிழையின் கீழ்நிலை தூண்டுதலுக்கு இது எங்களுக்குத் தேவை)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}