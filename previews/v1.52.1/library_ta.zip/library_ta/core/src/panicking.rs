//! லிப்கோருக்கான Panic ஆதரவு
//!
//! மைய நூலகம் பீதியை வரையறுக்க முடியாது, ஆனால் அது *பீதியை* அறிவிக்கிறது.
//! இதன் பொருள் லிப்கோரின் செயல்பாடுகள் panic க்கு அனுமதிக்கப்படுகின்றன, ஆனால் பயனுள்ளதாக இருக்க ஒரு அப்ஸ்ட்ரீம் crate லிப்கோர் பயன்படுத்த பீதியை வரையறுக்க வேண்டும்.
//! பீதிக்கான தற்போதைய இடைமுகம்:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! இந்த வரையறை எந்தவொரு பொது செய்தியையும் பீதியடைய அனுமதிக்கிறது, ஆனால் இது ஒரு `Box<Any>` மதிப்பில் தோல்வியடைய அனுமதிக்காது.
//! (`PanicInfo` ஒரு `&(dyn Any + Send)` ஐக் கொண்டுள்ளது, இதற்காக `PanicInfo: : internal_constructor` இல் போலி மதிப்பை நிரப்புகிறோம்.) இதற்குக் காரணம் லிப்கோர் ஒதுக்க அனுமதிக்கப்படவில்லை.
//!
//!
//! இந்த தொகுதி வேறு சில பீதி செயல்பாடுகளைக் கொண்டுள்ளது, ஆனால் இவை தொகுப்பிற்கு தேவையான லாங் உருப்படிகள் மட்டுமே.அனைத்து panics இந்த ஒரு செயல்பாட்டின் மூலம் இயக்கப்படுகிறது.
//! உண்மையான சின்னம் `#[panic_handler]` பண்புக்கூறு மூலம் அறிவிக்கப்படுகிறது.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// எந்த வடிவமைப்பும் பயன்படுத்தப்படாதபோது லிப்கோரின் `panic!` மேக்ரோவின் அடிப்படை செயல்படுத்தல்.
#[cold]
// முடிந்தவரை அழைப்பு தளங்களில் குறியீடு வீக்கத்தைத் தவிர்க்க panic_immediate_abort வரை ஒருபோதும் இன்லைன் செய்ய வேண்டாம்
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // வழிதல் மற்றும் பிற `Assert` MIR டெர்மினேட்டர்களில் panic க்கான கோட்ஜென் தேவைப்படுகிறது
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // மேல்நிலை அளவைக் குறைக்க, format_args! ("{}", Expr) க்கு பதிலாக Arguments::new_v1 ஐப் பயன்படுத்தவும்.
    // வடிவமைப்பு_ஆர்க்ஸ்!எக்ஸ்ப்ரரை எழுத மேக்ரோ str இன் டிஸ்ப்ளே trait ஐப் பயன்படுத்துகிறது, இது Formatter::pad ஐ அழைக்கிறது, இது சரம் துண்டிப்பு மற்றும் திணிப்புக்கு இடமளிக்க வேண்டும் (இங்கு எதுவும் பயன்படுத்தப்படவில்லை என்றாலும்).
    //
    // Arguments::new_v1 ஐப் பயன்படுத்துவதால், வெளியீடு பைனரியிலிருந்து Formatter::pad ஐ கம்பைலர் தவிர்க்க அனுமதிக்கலாம், சில கிலோபைட்டுகள் வரை சேமிக்கப்படுகிறது.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // கான்ஸ்ட்-மதிப்பீடு செய்யப்பட்ட panics க்கு தேவை
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice அணுகலில் panic க்கான கோட்ஜென் தேவை
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// வடிவமைத்தல் பயன்படுத்தப்படும்போது லிப்கோரின் எக்ஸ் 100 எக்ஸ் மேக்ரோவின் அடிப்படை செயல்படுத்தல்.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // குறிப்பு இந்த செயல்பாடு ஒருபோதும் FFI எல்லையை கடக்காது;இது ஒரு Rust-to-Rust அழைப்பு, இது `#[panic_handler]` செயல்பாட்டிற்கு தீர்க்கப்படும்.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // பாதுகாப்பு: `panic_impl` பாதுகாப்பான Rust குறியீட்டில் வரையறுக்கப்பட்டுள்ளது, இதனால் அழைக்க பாதுகாப்பானது.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` மற்றும் `assert_ne!` மேக்ரோக்களுக்கான உள் செயல்பாடு
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}