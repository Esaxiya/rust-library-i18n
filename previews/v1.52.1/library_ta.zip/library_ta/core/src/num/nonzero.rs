//! பூஜ்ஜியத்திற்கு சமமாக இல்லை என்று அறியப்படும் முழு எண்ணின் வரையறைகள்.

use crate::fmt;
use crate::ops::{BitOr, BitOrAssign, Div, Rem};
use crate::str::FromStr;

use super::from_str_radix;
use super::{IntErrorKind, ParseIntError};
use crate::intrinsics;

macro_rules! impl_nonzero_fmt {
    ( #[$stability: meta] ( $( $Trait: ident ),+ ) for $Ty: ident ) => {
        $(
            #[$stability]
            impl fmt::$Trait for $Ty {
                #[inline]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    self.get().fmt(f)
                }
            }
        )+
    }
}

macro_rules! nonzero_integers {
    ( $( #[$stability: meta] $Ty: ident($Int: ty); )+ ) => {
        $(
            /// பூஜ்ஜியத்திற்கு சமமாக இருக்காது என்று அறியப்படும் ஒரு முழு எண்.
            ///
            /// இது சில நினைவக தளவமைப்பு தேர்வுமுறைக்கு உதவுகிறது.
            #[doc = concat!("For example, `Option<", stringify!($Ty), ">` is the same size as `", stringify!($Int), "`:")]
            /// ```rust
            /// std::mem::size_of ஐப் பயன்படுத்து;
            #[doc = concat!("assert_eq!(size_of::<Option<core::num::", stringify!($Ty), ">>(), size_of::<", stringify!($Int), ">());")]
            /// ```
            #[$stability]
            #[derive(Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
            #[repr(transparent)]
            #[rustc_layout_scalar_valid_range_start(1)]
            #[rustc_nonnull_optimization_guaranteed]
            pub struct $Ty($Int);

            impl $Ty {
                /// மதிப்பைச் சரிபார்க்காமல் பூஜ்ஜியமற்றதை உருவாக்குகிறது.
                ///
                /// # Safety
                ///
                /// மதிப்பு பூஜ்ஜியமாக இருக்கக்கூடாது.
                #[$stability]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                #[inline]
                pub const unsafe fn new_unchecked(n: $Int) -> Self {
                    // பாதுகாப்பு: அழைப்பாளரால் இது பாதுகாப்பாக இருக்கும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
                    unsafe { Self(n) }
                }

                /// கொடுக்கப்பட்ட மதிப்பு பூஜ்ஜியமாக இல்லாவிட்டால் பூஜ்ஜியமற்றதை உருவாக்குகிறது.
                #[$stability]
                #[rustc_const_stable(feature = "const_nonzero_int_methods", since = "1.47.0")]
                #[inline]
                pub const fn new(n: $Int) -> Option<Self> {
                    if n != 0 {
                        // பாதுகாப்பு: `0` இல்லை என்பதை நாங்கள் சோதித்தோம்
                        Some(unsafe { Self(n) })
                    } else {
                        None
                    }
                }

                /// மதிப்பை ஒரு பழமையான வகையாக வழங்குகிறது.
                #[$stability]
                #[inline]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                pub const fn get(self) -> $Int {
                    self.0
                }

            }

            #[stable(feature = "from_nonzero", since = "1.31.0")]
            impl From<$Ty> for $Int {
                #[doc = concat!("Converts a `", stringify!($Ty), "` into an `", stringify!($Int), "`")]
                #[inline]
                fn from(nonzero: $Ty) -> Self {
                    nonzero.0
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: Self) -> Self::Output {
                    // பாதுகாப்பு: `self` மற்றும் `rhs` இரண்டும் nonzero என்பதால், தி
                    // பிட்வைஸின் விளைவாக-அல்லது nonzero ஆக இருக்கும்.
                    unsafe { $Ty::new_unchecked(self.get() | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Int> for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: $Int) -> Self::Output {
                    // பாதுகாப்பு: `self` nonzero என்பதால், இதன் விளைவாக
                    // பிட்வைஸ்-அல்லது `rhs` இன் மதிப்பைப் பொருட்படுத்தாமல் nonzero ஆக இருக்கும்.
                    //
                    unsafe { $Ty::new_unchecked(self.get() | rhs) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Ty> for $Int {
                type Output = $Ty;
                #[inline]
                fn bitor(self, rhs: $Ty) -> Self::Output {
                    // பாதுகாப்பு: `rhs` nonzero என்பதால், இதன் விளைவாக
                    // பிட்வைஸ்-அல்லது `self` இன் மதிப்பைப் பொருட்படுத்தாமல் nonzero ஆக இருக்கும்.
                    //
                    unsafe { $Ty::new_unchecked(self | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: Self) {
                    *self = *self | rhs;
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign<$Int> for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: $Int) {
                    *self = *self | rhs;
                }
            }

            impl_nonzero_fmt! {
                #[$stability] (Debug, Display, Binary, Octal, LowerHex, UpperHex) for $Ty
            }
        )+
    }
}

nonzero_integers! {
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU8(u8);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU16(u16);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU32(u32);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU64(u64);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU128(u128);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroUsize(usize);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI8(i8);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI16(i16);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI32(i32);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI64(i64);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI128(i128);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroIsize(isize);
}

macro_rules! from_str_radix_nzint_impl {
    ($($t:ty)*) => {$(
        #[stable(feature = "nonzero_parse", since = "1.35.0")]
        impl FromStr for $t {
            type Err = ParseIntError;
            fn from_str(src: &str) -> Result<Self, Self::Err> {
                Self::new(from_str_radix(src, 10)?)
                    .ok_or(ParseIntError {
                        kind: IntErrorKind::Zero
                    })
            }
        }
    )*}
}

from_str_radix_nzint_impl! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize
NonZeroI8 NonZeroI16 NonZeroI32 NonZeroI64 NonZeroI128 NonZeroIsize }

macro_rules! nonzero_leading_trailing_zeros {
    ( $( $Ty: ident($Uint: ty) , $LeadingTestExpr:expr ;)+ ) => {
        $(
            impl $Ty {
                /// `self` இன் பைனரி பிரதிநிதித்துவத்தில் முன்னணி பூஜ்ஜியங்களின் எண்ணிக்கையை வழங்குகிறது.
                ///
                /// பல கட்டமைப்புகளில், பூஜ்ஜியத்தின் சிறப்பு கையாளுதலைத் தவிர்க்க முடியும் என்பதால், இந்த செயல்பாடு அடிப்படை முழு எண் வகைகளில் `leading_zeros()` ஐ விட சிறப்பாக செயல்பட முடியும்.
                ///
                /// # Examples
                ///
                /// அடிப்படை பயன்பாடு:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(", stringify!($LeadingTestExpr), ").unwrap();")]
                /// assert_eq!(n.leading_zeros(), 0);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn leading_zeros(self) -> u32 {
                    // பாதுகாப்பு: `self` பூஜ்ஜியமாக இருக்க முடியாது என்பதால் ctlz_nonzero ஐ அழைப்பது பாதுகாப்பானது
                    unsafe { intrinsics::ctlz_nonzero(self.0 as $Uint) as u32 }
                }

                /// `self` இன் பைனரி பிரதிநிதித்துவத்தில் பின்தங்கிய பூஜ்ஜியங்களின் எண்ணிக்கையை வழங்குகிறது.
                ///
                /// பல கட்டமைப்புகளில், பூஜ்ஜியத்தின் சிறப்பு கையாளுதலைத் தவிர்க்க முடியும் என்பதால், இந்த செயல்பாடு அடிப்படை முழு எண் வகைகளில் `trailing_zeros()` ஐ விட சிறப்பாக செயல்பட முடியும்.
                ///
                ///
                /// # Examples
                ///
                /// அடிப்படை பயன்பாடு:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(0b0101000).unwrap();")]
                /// assert_eq!(n.trailing_zeros(), 3);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn trailing_zeros(self) -> u32 {
                    // பாதுகாப்பு: `self` பூஜ்ஜியமாக இருக்க முடியாது என்பதால் cttz_nonzero ஐ அழைப்பது பாதுகாப்பானது
                    unsafe { intrinsics::cttz_nonzero(self.0 as $Uint) as u32 }
                }

            }
        )+
    }
}

nonzero_leading_trailing_zeros! {
    NonZeroU8(u8), u8::MAX;
    NonZeroU16(u16), u16::MAX;
    NonZeroU32(u32), u32::MAX;
    NonZeroU64(u64), u64::MAX;
    NonZeroU128(u128), u128::MAX;
    NonZeroUsize(usize), usize::MAX;
    NonZeroI8(u8), -1i8;
    NonZeroI16(u16), -1i16;
    NonZeroI32(u32), -1i32;
    NonZeroI64(u64), -1i64;
    NonZeroI128(u128), -1i128;
    NonZeroIsize(usize), -1isize;
}

macro_rules! nonzero_integers_div {
    ( $( $Ty: ident($Int: ty); )+ ) => {
        $(
            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Div<$Ty> for $Int {
                type Output = $Int;
                /// இந்த செயல்பாடு பூஜ்ஜியத்தை நோக்கிச் செல்கிறது, சரியான முடிவின் எந்த பகுதியையும் துண்டிக்கிறது, மேலும் panic முடியாது.
                ///
                #[inline]
                fn div(self, other: $Ty) -> $Int {
                    // பாதுகாப்பு: `other` ஒரு nonzero என்பதால், பூஜ்ஜியத்தால் div சரிபார்க்கப்படுகிறது,
                    // மற்றும் MIN/-1 சரிபார்க்கப்பட்டது, ஏனெனில் `self` கையொப்பமிடாத முழு எண்ணாக உள்ளது.
                    unsafe { crate::intrinsics::unchecked_div(self, other.get()) }
                }
            }

            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Rem<$Ty> for $Int {
                type Output = $Int;
                /// இந்த செயல்பாடு `n % d == n - (n / d) * d` ஐ திருப்தி செய்கிறது, மேலும் panic முடியாது.
                #[inline]
                fn rem(self, other: $Ty) -> $Int {
                    // பாதுகாப்பு: எக்ஸ் 100 எக்ஸ் ஒரு நொஜெரோ என்பதால் பூஜ்ஜியத்தால் ரெம் சரிபார்க்கப்படுகிறது,
                    // மற்றும் MIN/-1 சரிபார்க்கப்பட்டது, ஏனெனில் `self` கையொப்பமிடாத முழு எண்ணாக உள்ளது.
                    unsafe { crate::intrinsics::unchecked_rem(self, other.get()) }
                }
            }
        )+
    }
}

nonzero_integers_div! {
    NonZeroU8(u8);
    NonZeroU16(u16);
    NonZeroU32(u32);
    NonZeroU64(u64);
    NonZeroU128(u128);
    NonZeroUsize(usize);
}

macro_rules! nonzero_unsigned_is_power_of_two {
    ( $( $Ty: ident )+ ) => {
        $(
            impl $Ty {

                /// சில `k` க்கு `self == (1 << k)` என்றால் மட்டுமே `true` ஐ வழங்குகிறது.
                ///
                /// பல கட்டமைப்புகளில், பூஜ்ஜியத்தின் சிறப்பு கையாளுதலைத் தவிர்க்க முடியும் என்பதால், இந்த செயல்பாடு அடிப்படை முழு எண் வகைகளில் `is_power_of_two()` ஐ விட சிறப்பாக செயல்பட முடியும்.
                ///
                ///
                /// # Examples
                ///
                /// அடிப்படை பயன்பாடு:
                ///
                /// ```
                /// #![feature(nonzero_is_power_of_two)]
                ///
                #[doc = concat!("let eight = std::num::", stringify!($Ty), "::new(8).unwrap();")]
                /// assert!(eight.is_power_of_two());
                #[doc = concat!("let ten = std::num::", stringify!($Ty), "::new(10).unwrap();")]
                /// assert!(!ten.is_power_of_two());
                /// ```
                #[unstable(feature = "nonzero_is_power_of_two", issue = "81106")]
                #[inline]
                pub const fn is_power_of_two(self) -> bool {
                    // எல்.எல்.வி.எம் 11 இங்கே காணப்படும் செயலாக்கத்திற்கு `unchecked_sub(x, 1) & x == 0` ஐ இயல்பாக்குகிறது.
                    // அடிப்படை x86-64 இலக்கில், இது பூஜ்ஜிய சோதனைக்கு 3 வழிமுறைகளை சேமிக்கிறது.
                    // BMI1 உடன் x86_64 இல், nonzero ஆனது `BLSR` க்கு குறியீட்டை அனுமதிக்கிறது, இது அடிப்படை முழு வகை வகைகளில் `POPCNT` செயல்படுத்தலுடன் ஒப்பிடும்போது ஒரு வழிமுறையைச் சேமிக்கிறது.
                    //

                    intrinsics::ctpop(self.get()) < 2
                }

            }
        )+
    }
}

nonzero_unsigned_is_power_of_two! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize }