macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// இந்த முழு எண் வகையால் குறிப்பிடக்கூடிய மிகச்சிறிய மதிப்பு.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// இந்த முழு எண் வகையால் குறிப்பிடக்கூடிய மிகப்பெரிய மதிப்பு.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// பிட்களில் இந்த முழு எண் வகையின் அளவு.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// கொடுக்கப்பட்ட அடித்தளத்தில் ஒரு சரம் துண்டுகளை ஒரு முழு எண்ணாக மாற்றுகிறது.
        ///
        /// சரம் ஒரு விருப்பமான `+` அடையாளமாக இருக்கும், அதைத் தொடர்ந்து இலக்கங்கள் இருக்கும் என்று எதிர்பார்க்கப்படுகிறது.
        ///
        /// இடைவெளியும் முன்னும் பின்னும் ஒரு பிழையைக் குறிக்கும்.
        /// `radix` ஐப் பொறுத்து இலக்கங்கள் இந்த எழுத்துக்களின் துணைக்குழு ஆகும்:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// `radix` 2 முதல் 36 வரம்பில் இல்லை என்றால் இந்த செயல்பாடு panics.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` இன் பைனரி பிரதிநிதித்துவத்தில் உள்ளவர்களின் எண்ணிக்கையை வழங்குகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// `self` இன் பைனரி பிரதிநிதித்துவத்தில் பூஜ்ஜியங்களின் எண்ணிக்கையை வழங்குகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` இன் பைனரி பிரதிநிதித்துவத்தில் முன்னணி பூஜ்ஜியங்களின் எண்ணிக்கையை வழங்குகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// `self` இன் பைனரி பிரதிநிதித்துவத்தில் பின்தங்கிய பூஜ்ஜியங்களின் எண்ணிக்கையை வழங்குகிறது.
        ///
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// `self` இன் பைனரி பிரதிநிதித்துவத்தில் முன்னணி நபர்களின் எண்ணிக்கையை வழங்குகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// `self` இன் பைனரி பிரதிநிதித்துவத்தில் பின்தங்கியவர்களின் எண்ணிக்கையை வழங்குகிறது.
        ///
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// ஒரு குறிப்பிட்ட அளவு, `n` மூலம் பிட்களை இடதுபுறமாக மாற்றி, துண்டிக்கப்பட்ட பிட்களை விளைவாக வரும் முழு எண்ணின் இறுதியில் போர்த்தி விடுகிறது.
        ///
        ///
        /// இது `<<` ஷிஃப்டிங் ஆபரேட்டரின் அதே செயல்பாடு அல்ல என்பதை நினைவில் கொள்க!
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// துண்டிக்கப்பட்ட பிட்களை ஒரு குறிப்பிட்ட அளவு, `n` மூலம் வலப்பக்கமாக மாற்றுகிறது, இதன் விளைவாக வெட்டப்பட்ட பிட்களை முழு எண்ணின் தொடக்கத்தில் மடிக்கிறது.
        ///
        ///
        /// இது `>>` ஷிஃப்டிங் ஆபரேட்டரின் அதே செயல்பாடு அல்ல என்பதை நினைவில் கொள்க!
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// முழு எண்ணின் பைட் வரிசையை மாற்றியமைக்கிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.swap_bytes() ஆகட்டும்;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// முழு எண்ணில் உள்ள பிட்களின் வரிசையை மாற்றியமைக்கிறது.
        /// குறைவான குறிப்பிடத்தக்க பிட் மிகவும் குறிப்பிடத்தக்க பிட் ஆகிறது, இரண்டாவது குறைந்தது-குறிப்பிடத்தக்க பிட் இரண்டாவது மிக முக்கியமான பிட் ஆகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.reverse_bits() ஆகட்டும்;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// பெரிய எண்டியனில் இருந்து இலக்கின் முடிவுக்கு ஒரு முழு எண்ணை மாற்றுகிறது.
        ///
        /// பெரிய எண்டியனில் இது ஒரு விருப்பம் இல்லை.
        /// சிறிய எண்டியனில் பைட்டுகள் மாற்றப்படுகின்றன.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg என்றால்! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// சிறிய எண்டியனில் இருந்து இலக்கின் முடிவுக்கு ஒரு முழு எண்ணை மாற்றுகிறது.
        ///
        /// சிறிய எண்டியனில் இது ஒரு விருப்பம் இல்லை.
        /// பெரிய எண்டியனில் பைட்டுகள் மாற்றப்படுகின்றன.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg என்றால்! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` ஐ இலக்குகளின் முடிவில் இருந்து பெரிய எண்டியனாக மாற்றுகிறது.
        ///
        /// பெரிய எண்டியனில் இது ஒரு விருப்பம் இல்லை.
        /// சிறிய எண்டியனில் பைட்டுகள் மாற்றப்படுகின்றன.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg என்றால்! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // அல்லது இருக்க வேண்டாமா?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` ஐ இலக்கின் முடிவில் இருந்து சிறிய எண்டியனாக மாற்றுகிறது.
        ///
        /// சிறிய எண்டியனில் இது ஒரு விருப்பம் இல்லை.
        /// பெரிய எண்டியனில் பைட்டுகள் மாற்றப்படுகின்றன.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg என்றால்! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// முழு எண் சேர்த்தல் சரிபார்க்கப்பட்டது.
        /// `self + rhs` ஐக் கணக்கிடுகிறது, வழிதல் ஏற்பட்டால் `None` ஐத் தருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// தேர்வு செய்யப்படாத முழு எண் கூட்டல்.`self + rhs` ஐக் கணக்கிடுகிறது, வழிதல் ஏற்படாது என்று கருதி.
        /// இது வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // பாதுகாப்பு: அழைப்பாளர் `unchecked_add` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// சரிபார்க்கப்பட்ட முழு எண் கழித்தல்.
        /// `self - rhs` ஐக் கணக்கிடுகிறது, வழிதல் ஏற்பட்டால் `None` ஐத் தருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// தேர்வு செய்யப்படாத முழு கழித்தல்.`self - rhs` ஐக் கணக்கிடுகிறது, வழிதல் ஏற்படாது என்று கருதி.
        /// இது வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // பாதுகாப்பு: அழைப்பாளர் `unchecked_sub` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// சரிபார்க்கப்பட்ட முழு எண் பெருக்கல்.
        /// `self * rhs` ஐக் கணக்கிடுகிறது, வழிதல் ஏற்பட்டால் `None` ஐத் தருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// தேர்வு செய்யப்படாத முழு பெருக்கல்.`self * rhs` ஐக் கணக்கிடுகிறது, வழிதல் ஏற்படாது என்று கருதி.
        /// இது வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // பாதுகாப்பு: அழைப்பாளர் `unchecked_mul` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// முழு எண் பிரிவு சரிபார்க்கப்பட்டது.
        /// `self / rhs` ஐக் கணக்கிடுகிறது, `rhs == 0` என்றால் `None` ஐத் தருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // பாதுகாப்பு: பூஜ்ஜியத்தால் div மேலே சரிபார்க்கப்பட்டது மற்றும் கையொப்பமிடாத வகைகளுக்கு வேறு எதுவும் இல்லை
                // பிரிவுக்கான தோல்வி முறைகள்
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// சரிபார்க்கப்பட்ட யூக்ளிடியன் பிரிவு.
        /// `self.div_euclid(rhs)` ஐக் கணக்கிடுகிறது, `rhs == 0` என்றால் `None` ஐத் தருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// சரிபார்க்கப்பட்ட முழு எண்.
        /// `self % rhs` ஐக் கணக்கிடுகிறது, `rhs == 0` என்றால் `None` ஐத் தருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // பாதுகாப்பு: பூஜ்ஜியத்தால் div மேலே சரிபார்க்கப்பட்டது மற்றும் கையொப்பமிடாத வகைகளுக்கு வேறு எதுவும் இல்லை
                // பிரிவுக்கான தோல்வி முறைகள்
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// சரிபார்க்கப்பட்ட யூக்ளிடியன் மட்டு.
        /// `self.rem_euclid(rhs)` ஐக் கணக்கிடுகிறது, `rhs == 0` என்றால் `None` ஐத் தருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// சரிபார்க்கப்பட்ட மறுப்பு.`-self` ஐக் கணக்கிடுகிறது, `சுய==இல்லாவிட்டால் `None` ஐத் தருகிறது
        /// 0`.
        ///
        /// எந்த நேர்மறை முழு எண்ணையும் நிராகரிப்பது நிரம்பி வழியும் என்பதை நினைவில் கொள்க.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// சரிபார்க்கப்பட்ட ஷிப்ட் இடது.
        /// `self << rhs` ஐக் கணக்கிடுகிறது, `rhs` `self` இல் உள்ள பிட்களின் எண்ணிக்கையை விட பெரியதாகவோ அல்லது சமமாகவோ இருந்தால் `None` ஐத் தருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// சரிபார்க்கப்பட்ட ஷிப்ட் வலது.
        /// `self >> rhs` ஐக் கணக்கிடுகிறது, `rhs` `self` இல் உள்ள பிட்களின் எண்ணிக்கையை விட பெரியதாகவோ அல்லது சமமாகவோ இருந்தால் `None` ஐத் தருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// சரிபார்க்கப்பட்ட அடுக்கு.
        /// `self.pow(exp)` ஐக் கணக்கிடுகிறது, வழிதல் ஏற்பட்டால் `None` ஐத் தருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // exp!=0 என்பதால், இறுதியாக exp 1 ஆக இருக்க வேண்டும்.
            // அடுக்கு இறுதி பிட்டைத் தனித்தனியாகக் கையாளுங்கள், ஏனெனில் அடித்தளத்தை ஸ்கொயர் செய்வது தேவையில்லை, மேலும் தேவையற்ற வழிதல் ஏற்படக்கூடும்.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// முழு எண் கூட்டல் நிறைவு.
        /// `self + rhs` ஐக் கணக்கிடுகிறது, நிரம்பி வழிகிறது என்பதற்குப் பதிலாக எண் எல்லைகளில் நிறைவுற்றது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// முழு எண்ணைக் கழித்தல்.
        /// `self - rhs` ஐக் கணக்கிடுகிறது, நிரம்பி வழிகிறது என்பதற்குப் பதிலாக எண் எல்லைகளில் நிறைவுற்றது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// முழு எண் பெருக்கத்தை நிறைவு செய்கிறது.
        /// `self * rhs` ஐக் கணக்கிடுகிறது, நிரம்பி வழிகிறது என்பதற்குப் பதிலாக எண் எல்லைகளில் நிறைவுற்றது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// முழு எக்ஸ்போனென்டேஷன் நிறைவு.
        /// `self.pow(exp)` ஐக் கணக்கிடுகிறது, நிரம்பி வழிகிறது என்பதற்கு பதிலாக எண் எல்லைகளில் நிறைவுற்றது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// (modular) சேர்த்தலை மடக்குதல்.
        /// `self + rhs` ஐக் கணக்கிடுகிறது, வகையின் எல்லையில் சுற்றி வருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) கழிப்பதை மடக்குதல்.
        /// `self - rhs` ஐக் கணக்கிடுகிறது, வகையின் எல்லையில் சுற்றி வருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) பெருக்கத்தை மடக்குதல்.
        /// `self * rhs` ஐக் கணக்கிடுகிறது, வகையின் எல்லையில் சுற்றி வருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// இந்த எடுத்துக்காட்டு முழு எண் வகைகளுக்கு இடையில் பகிரப்பட்டுள்ளது என்பதை நினைவில் கொள்க.
        /// `u8` ஏன் இங்கே பயன்படுத்தப்படுகிறது என்பதை இது விளக்குகிறது.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) பிரிவை மடக்குதல்.`self / rhs` கணக்கிடுகிறது.
        /// கையொப்பமிடாத வகைகளில் மூடப்பட்ட பிரிவு சாதாரண பிரிவு.
        /// மடக்குதல் எப்போதும் நடக்க வழி இல்லை.
        /// இந்த செயல்பாடு உள்ளது, இதனால் அனைத்து செயல்பாடுகளும் மடக்குதல் செயல்பாடுகளில் கணக்கிடப்படுகின்றன.
        ///
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// யூக்ளிடியன் பிரிவை மடக்குதல்.`self.div_euclid(rhs)` கணக்கிடுகிறது.
        /// கையொப்பமிடாத வகைகளில் மூடப்பட்ட பிரிவு சாதாரண பிரிவு.
        /// மடக்குதல் எப்போதும் நடக்க வழி இல்லை.
        /// இந்த செயல்பாடு உள்ளது, இதனால் அனைத்து செயல்பாடுகளும் மடக்குதல் செயல்பாடுகளில் கணக்கிடப்படுகின்றன.
        /// நேர்மறை முழு எண்களுக்கு, பிரிவின் அனைத்து பொதுவான வரையறைகளும் சமமாக இருப்பதால், இது `self.wrapping_div(rhs)` க்கு சமமாக இருக்கும்.
        ///
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// மீதமுள்ள (modular) ஐ மடக்குதல்.`self % rhs` கணக்கிடுகிறது.
        /// கையொப்பமிடப்படாத வகைகளில் மீதமுள்ள கணக்கீடு வழக்கமான மீதமுள்ள கணக்கீடு மட்டுமே.
        ///
        /// மடக்குதல் எப்போதும் நடக்க வழி இல்லை.
        /// இந்த செயல்பாடு உள்ளது, இதனால் அனைத்து செயல்பாடுகளும் மடக்குதல் செயல்பாடுகளில் கணக்கிடப்படுகின்றன.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// யூக்ளிடியன் மாடுலோவை மடக்குதல்.`self.rem_euclid(rhs)` கணக்கிடுகிறது.
        /// கையொப்பமிடப்படாத வகைகளில் மட்டுப்படுத்தப்பட்ட மட்டு கணக்கீடு வழக்கமான மீதமுள்ள கணக்கீடு மட்டுமே.
        /// மடக்குதல் எப்போதும் நடக்க வழி இல்லை.
        /// இந்த செயல்பாடு உள்ளது, இதனால் அனைத்து செயல்பாடுகளும் மடக்குதல் செயல்பாடுகளில் கணக்கிடப்படுகின்றன.
        /// நேர்மறை முழு எண்களுக்கு, பிரிவின் அனைத்து பொதுவான வரையறைகளும் சமமாக இருப்பதால், இது `self.wrapping_rem(rhs)` க்கு சமமாக இருக்கும்.
        ///
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular) நிராகரிப்பை மடக்குதல்.
        /// `-self` ஐக் கணக்கிடுகிறது, வகையின் எல்லையில் சுற்றி வருகிறது.
        ///
        /// கையொப்பமிடப்படாத வகைகளுக்கு எதிர்மறை சமமானவை இல்லை என்பதால், இந்த செயல்பாட்டின் அனைத்து பயன்பாடுகளும் மடக்கப்படும் (`-0` தவிர).
        /// தொடர்புடைய கையொப்பமிடப்பட்ட வகையின் அதிகபட்சத்தை விட சிறிய மதிப்புகளுக்கு, இதன் விளைவாக கையொப்பமிடப்பட்ட மதிப்பை அனுப்புவதற்கு சமம்.
        ///
        /// எந்த பெரிய மதிப்புகளும் `MAX + 1 - (val - MAX - 1)` க்கு சமமானவை, அங்கு `MAX` என்பது கையொப்பமிடப்பட்ட வகையின் அதிகபட்சமாகும்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// இந்த எடுத்துக்காட்டு முழு எண் வகைகளுக்கு இடையில் பகிரப்பட்டுள்ளது என்பதை நினைவில் கொள்க.
        /// `i8` ஏன் இங்கே பயன்படுத்தப்படுகிறது என்பதை இது விளக்குகிறது.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-இலவச பிட்வைஸ் ஷிப்ட்-இடது;
        /// `self << mask(rhs)` ஐ அளிக்கிறது, அங்கு `mask` `rhs` இன் எந்த உயர்-வரிசை பிட்களையும் நீக்குகிறது, இது மாற்றமானது வகையின் பிட்வித் ஐ விட அதிகமாக இருக்கும்.
        ///
        /// இது * சுழலும்-இடது போன்றது அல்ல என்பதை நினைவில் கொள்க;எல்.எச்.எஸ்-ல் இருந்து மாற்றப்பட்ட பிட்கள் மறு முனைக்குத் திரும்புவதை விட, ஒரு மடக்குதல்-இடது-இடத்தின் ஆர்.எச்.எஸ் வகை வரம்பிற்கு கட்டுப்படுத்தப்படுகிறது.
        /// பழமையான முழு எண் வகைகள் அனைத்தும் ஒரு [`rotate_left`](Self::rotate_left) செயல்பாட்டை செயல்படுத்துகின்றன, அதற்கு பதிலாக நீங்கள் விரும்புவதாக இருக்கலாம்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // பாதுகாப்பு: வகையின் பிட்சைஸ் மூலம் மறைப்பது நாம் மாற்றாமல் இருப்பதை உறுதி செய்கிறது
            // எல்லைக்கு வெளியே
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-இலவச பிட்வைஸ் ஷிப்ட்-வலது;
        /// `self >> mask(rhs)` ஐ அளிக்கிறது, அங்கு `mask` `rhs` இன் எந்த உயர்-வரிசை பிட்களையும் நீக்குகிறது, இது மாற்றமானது வகையின் பிட்வித் ஐ விட அதிகமாக இருக்கும்.
        ///
        /// இது * சுழலும்-வலதுபுறத்திற்கு சமமானதல்ல என்பதை நினைவில் கொள்க;ஒரு மடக்குதல்-வலதுபுறத்தின் RHS வகை வரம்பிற்கு மட்டுப்படுத்தப்பட்டுள்ளது, LHS இலிருந்து மாற்றப்பட்ட பிட்கள் மறு முனைக்குத் திரும்புவதை விட.
        /// பழமையான முழு எண் வகைகள் அனைத்தும் ஒரு [`rotate_right`](Self::rotate_right) செயல்பாட்டை செயல்படுத்துகின்றன, அதற்கு பதிலாக நீங்கள் விரும்புவதாக இருக்கலாம்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // பாதுகாப்பு: வகையின் பிட்சைஸ் மூலம் மறைப்பது நாம் மாற்றாமல் இருப்பதை உறுதி செய்கிறது
            // எல்லைக்கு வெளியே
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) அதிவேகத்தை மடக்குதல்.
        /// `self.pow(exp)` ஐக் கணக்கிடுகிறது, வகையின் எல்லையில் சுற்றி வருகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 என்பதால், இறுதியாக exp 1 ஆக இருக்க வேண்டும்.
            // அடுக்கு இறுதி பிட்டைத் தனித்தனியாகக் கையாளுங்கள், ஏனெனில் அடித்தளத்தை ஸ்கொயர் செய்வது தேவையில்லை, மேலும் தேவையற்ற வழிதல் ஏற்படக்கூடும்.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` ஐக் கணக்கிடுகிறது
        ///
        /// எண்கணித வழிதல் ஏற்படுமா என்பதைக் குறிக்கும் பூலியனுடன் சேர்த்தலின் ஒரு துணியை வழங்குகிறது.
        /// ஒரு வழிதல் ஏற்பட்டிருந்தால், மூடப்பட்ட மதிப்பு திரும்பப் பெறப்படும்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` ஐக் கணக்கிடுகிறது
        ///
        /// ஒரு எண்கணித வழிதல் ஏற்படுமா என்பதைக் குறிக்கும் பூலியனுடன் கழித்தலின் ஒரு துணியை வழங்குகிறது.
        /// ஒரு வழிதல் ஏற்பட்டிருந்தால், மூடப்பட்ட மதிப்பு திரும்பப் பெறப்படும்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` மற்றும் `rhs` இன் பெருக்கத்தைக் கணக்கிடுகிறது.
        ///
        /// ஒரு எண்கணித வழிதல் ஏற்படுமா என்பதைக் குறிக்கும் பூலியனுடன் பெருக்கத்தின் ஒரு துணியை வழங்குகிறது.
        /// ஒரு வழிதல் ஏற்பட்டிருந்தால், மூடப்பட்ட மதிப்பு திரும்பப் பெறப்படும்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// இந்த எடுத்துக்காட்டு முழு எண் வகைகளுக்கு இடையில் பகிரப்பட்டுள்ளது என்பதை நினைவில் கொள்க.
        /// `u32` ஏன் இங்கே பயன்படுத்தப்படுகிறது என்பதை இது விளக்குகிறது.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` ஐ `rhs` ஆல் வகுக்கும்போது வகுப்பியைக் கணக்கிடுகிறது.
        ///
        /// எண்கணித வழிதல் ஏற்படுமா என்பதைக் குறிக்கும் பூலியன் உடன் வகுப்பியின் ஒரு துணியை வழங்குகிறது.
        /// கையொப்பமிடப்படாத முழு எண்களுக்கு வழிதல் ஒருபோதும் ஏற்படாது என்பதை நினைவில் கொள்க, எனவே இரண்டாவது மதிப்பு எப்போதும் `false` ஆகும்.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ஆக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// யூக்ளிடியன் பிரிவு `self.div_euclid(rhs)` இன் அளவைக் கணக்கிடுகிறது.
        ///
        /// எண்கணித வழிதல் ஏற்படுமா என்பதைக் குறிக்கும் பூலியன் உடன் வகுப்பியின் ஒரு துணியை வழங்குகிறது.
        /// கையொப்பமிடப்படாத முழு எண்களுக்கு வழிதல் ஒருபோதும் ஏற்படாது என்பதை நினைவில் கொள்க, எனவே இரண்டாவது மதிப்பு எப்போதும் `false` ஆகும்.
        /// நேர்மறை முழு எண்களுக்கு, பிரிவின் அனைத்து பொதுவான வரையறைகளும் சமமாக இருப்பதால், இது `self.overflowing_div(rhs)` க்கு சமமாக இருக்கும்.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ஆக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// `self` ஐ `rhs` ஆல் வகுக்கும்போது மீதமுள்ளதைக் கணக்கிடுகிறது.
        ///
        /// எண்கணித வழிதல் ஏற்படுமா என்பதைக் குறிக்கும் பூலியனுடன் பிரித்தபின் மீதமுள்ள ஒரு துணியை வழங்குகிறது.
        /// கையொப்பமிடப்படாத முழு எண்களுக்கு வழிதல் ஒருபோதும் ஏற்படாது என்பதை நினைவில் கொள்க, எனவே இரண்டாவது மதிப்பு எப்போதும் `false` ஆகும்.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ஆக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// மீதமுள்ள `self.rem_euclid(rhs)` ஐ யூக்ளிடியன் பிரிவின் மூலம் கணக்கிடுகிறது.
        ///
        /// ஒரு எண்கணித வழிதல் ஏற்படுமா என்பதைக் குறிக்கும் பூலியன் உடன் பிரித்தபின் மட்டு ஒரு டூப்பை வழங்குகிறது.
        /// கையொப்பமிடப்படாத முழு எண்களுக்கு வழிதல் ஒருபோதும் ஏற்படாது என்பதை நினைவில் கொள்க, எனவே இரண்டாவது மதிப்பு எப்போதும் `false` ஆகும்.
        /// நேர்மறை முழு எண்களுக்கு, பிரிவின் பொதுவான வரையறைகள் அனைத்தும் சமமாக இருப்பதால், இந்த செயல்பாடு `self.overflowing_rem(rhs)` க்கு சமமாக இருக்கும்.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ஆக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// நிரம்பி வழிகின்ற பாணியில் சுயத்தை எதிர்மறையாகக் கொண்டுள்ளது.
        ///
        /// கையொப்பமிடாத இந்த மதிப்பின் நிராகரிப்பைக் குறிக்கும் மதிப்பைத் திருப்புவதற்கு மடக்குதல் செயல்பாடுகளைப் பயன்படுத்தி `!self + 1` ஐ வழங்குகிறது.
        /// நேர்மறையான கையொப்பமிடாத மதிப்புகளுக்கு வழிதல் எப்போதும் நிகழ்கிறது என்பதை நினைவில் கொள்க, ஆனால் 0 ஐ நிராகரிப்பது நிரம்பி வழிவதில்லை.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// `rhs` பிட்களால் இடதுபுறமாக மாறுகிறது.
        ///
        /// ஷிப்ட் மதிப்பு பிட்களின் எண்ணிக்கையை விட பெரியதா அல்லது சமமானதா என்பதைக் குறிக்கும் பூலியனுடன் சுயமாக மாற்றப்பட்ட பதிப்பின் ஒரு டூப்பை வழங்குகிறது.
        /// ஷிப்ட் மதிப்பு மிகப் பெரியதாக இருந்தால், மதிப்பு (N-1) ஐ மறைக்கிறது, அங்கு N என்பது பிட்களின் எண்ணிக்கையாகும், மேலும் இந்த மதிப்பு மாற்றத்தை செய்ய பயன்படுத்தப்படுகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` பிட்களால் சுய உரிமையை மாற்றுகிறது.
        ///
        /// ஷிப்ட் மதிப்பு பிட்களின் எண்ணிக்கையை விட பெரியதா அல்லது சமமானதா என்பதைக் குறிக்கும் பூலியனுடன் சுயமாக மாற்றப்பட்ட பதிப்பின் ஒரு டூப்பை வழங்குகிறது.
        /// ஷிப்ட் மதிப்பு மிகப் பெரியதாக இருந்தால், மதிப்பு (N-1) ஐ மறைக்கிறது, அங்கு N என்பது பிட்களின் எண்ணிக்கையாகும், மேலும் இந்த மதிப்பு மாற்றத்தை செய்ய பயன்படுத்தப்படுகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// `exp` இன் சக்திக்கு சுயத்தை உயர்த்துகிறது, ஸ்கொரிங் மூலம் அதிவேகத்தைப் பயன்படுத்துகிறது.
        ///
        /// ஒரு வழிதல் நிகழ்ந்ததா என்பதைக் குறிக்கும் bool உடன் அதிவேகத்தின் ஒரு துணியை வழங்குகிறது.
        ///
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, உண்மை));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // நிரம்பி வழியும்_மூலின் முடிவுகளை சேமிப்பதற்கான இடத்தை கீறவும்.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 என்பதால், இறுதியாக exp 1 ஆக இருக்க வேண்டும்.
            // அடுக்கு இறுதி பிட்டைத் தனித்தனியாகக் கையாளுங்கள், ஏனெனில் அடித்தளத்தை ஸ்கொயர் செய்வது தேவையில்லை, மேலும் தேவையற்ற வழிதல் ஏற்படக்கூடும்.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// `exp` இன் சக்திக்கு சுயத்தை உயர்த்துகிறது, ஸ்கொரிங் மூலம் அதிவேகத்தைப் பயன்படுத்துகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 என்பதால், இறுதியாக exp 1 ஆக இருக்க வேண்டும்.
            // அடுக்கு இறுதி பிட்டைத் தனித்தனியாகக் கையாளுங்கள், ஏனெனில் அடித்தளத்தை ஸ்கொயர் செய்வது தேவையில்லை, மேலும் தேவையற்ற வழிதல் ஏற்படக்கூடும்.
            //
            //
            acc * base
        }

        /// யூக்ளிடியன் பிரிவை செய்கிறது.
        ///
        /// நேர்மறை முழு எண்களுக்கு, பிரிவின் அனைத்து பொதுவான வரையறைகளும் சமமாக இருப்பதால், இது `self / rhs` க்கு சமமாக இருக்கும்.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ஆக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// `self (mod rhs)` இன் மிகக் குறைந்த அளவைக் கணக்கிடுகிறது.
        ///
        /// நேர்மறை முழு எண்களுக்கு, பிரிவின் அனைத்து பொதுவான வரையறைகளும் சமமாக இருப்பதால், இது `self % rhs` க்கு சமமாக இருக்கும்.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ஆக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// சில `k` க்கு `self == 2^k` என்றால் மட்டுமே `true` ஐ வழங்குகிறது.
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // இரண்டின் அடுத்த சக்தியை விட குறைவான ஒன்றைத் தருகிறது.
        // (8u8 க்கு அடுத்த இரண்டு சக்தி 8u8 மற்றும் 6u8 க்கு 8u8 ஆகும்)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // இந்த முறை நிரம்பி வழிய முடியாது, ஏனெனில் `next_power_of_two` வழிதல் நிகழ்வுகளில் இது வகையின் அதிகபட்ச மதிப்பைத் தருகிறது, மேலும் 0 க்கு 0 ஐத் தரலாம்.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // பாதுகாப்பு: ஏனெனில் `p > 0`, இது முற்றிலும் முன்னணி பூஜ்ஜியங்களைக் கொண்டிருக்க முடியாது.
            // அதாவது ஷிப்ட் எப்போதுமே எல்லைக்குட்பட்டது, மேலும் சில செயலிகள் (இன்டெல் ப்ரீ-ஹாஸ்வெல் போன்றவை) வாதம் பூஜ்ஜியமற்றதாக இருக்கும்போது மிகவும் திறமையான சி.டி.எல்.எஸ் உள்ளார்ந்த தன்மையைக் கொண்டுள்ளன.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// `self` ஐ விட பெரிய அல்லது அதற்கு சமமான இரண்டின் மிகச்சிறிய சக்தியை வழங்குகிறது.
        ///
        /// வருவாய் மதிப்பு நிரம்பி வழிகிறது (அதாவது, வகை `uN` க்கான `self > (1 << (N-1))`), இது பிழைத்திருத்த பயன்முறையில் panics மற்றும் வருவாய் மதிப்பு வெளியீட்டு பயன்முறையில் 0 உடன் மூடப்பட்டிருக்கும் (முறை 0 ஐத் தரக்கூடிய ஒரே சூழ்நிலை).
        ///
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// `n` ஐ விட பெரிய அல்லது அதற்கு சமமான இரண்டின் மிகச்சிறிய சக்தியை வழங்குகிறது.
        /// இரண்டின் அடுத்த சக்தி வகையின் அதிகபட்ச மதிப்பை விட அதிகமாக இருந்தால், `None` திரும்பும், இல்லையெனில் இருவரின் சக்தி `Some` இல் மூடப்பட்டிருக்கும்.
        ///
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// `n` ஐ விட பெரிய அல்லது அதற்கு சமமான இரண்டின் மிகச்சிறிய சக்தியை வழங்குகிறது.
        /// இரண்டின் அடுத்த சக்தி வகையின் அதிகபட்ச மதிப்பை விட அதிகமாக இருந்தால், வருவாய் மதிப்பு `0` உடன் மூடப்பட்டிருக்கும்.
        ///
        ///
        /// # Examples
        ///
        /// அடிப்படை பயன்பாடு:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// பிக்-எண்டியன் (network) பைட் வரிசையில் பைட் வரிசையாக இந்த முழு எண்ணின் நினைவக பிரதிநிதித்துவத்தைத் தரவும்.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// இந்த முழு எண்ணின் நினைவக பிரதிநிதித்துவத்தை சிறிய-எண்டியன் பைட் வரிசையில் பைட் வரிசையாகத் திருப்புக.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// இந்த முழு எண்ணின் நினைவக பிரதிநிதித்துவத்தை சொந்த பைட் வரிசையில் பைட் வரிசையாகத் தரவும்.
        ///
        /// இலக்கு தளத்தின் சொந்த முடிவு பயன்படுத்தப்படுவதால், சிறிய குறியீடு அதற்கு பதிலாக [`to_be_bytes`] அல்லது [`to_le_bytes`] ஐப் பயன்படுத்த வேண்டும்.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     பைட்டுகள், cfg என்றால்! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } else {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // பாதுகாப்பு: முழு ஒலி முழு பழைய தரவு வகைகளாக இருப்பதால், நாம் எப்போதும் முடியும்
        // பைட்டுகளின் வரிசைகளுக்கு அவற்றை மாற்றவும்
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // பாதுகாப்பு: முழு எண்கள் பழைய பழைய தரவு வகைகளாகும், எனவே அவற்றை எப்போதும் மாற்றலாம்
            // பைட்டுகளின் வரிசைகள்
            unsafe { mem::transmute(self) }
        }

        /// இந்த முழு எண்ணின் நினைவக பிரதிநிதித்துவத்தை சொந்த பைட் வரிசையில் பைட் வரிசையாகத் தரவும்.
        ///
        ///
        /// [`to_ne_bytes`] முடிந்த போதெல்லாம் இதை விட முன்னுரிமை அளிக்கப்பட வேண்டும்.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// பைட்டுகள்= num.as_ne_bytes();
        /// assert_eq!(
        ///     பைட்டுகள், cfg என்றால்! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } else {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // பாதுகாப்பு: முழு எண்கள் பழைய பழைய தரவு வகைகளாகும், எனவே அவற்றை எப்போதும் மாற்றலாம்
            // பைட்டுகளின் வரிசைகள்
            unsafe { &*(self as *const Self as *const _) }
        }

        /// பெரிய எண்டியனில் ஒரு பைட் வரிசையாக அதன் பிரதிநிதித்துவத்திலிருந்து ஒரு சொந்த எண்டியன் முழு எண் மதிப்பை உருவாக்கவும்.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ஐப் பயன்படுத்து;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * உள்ளீடு=ஓய்வு;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// சிறிய எண்டியனில் ஒரு பைட் வரிசையாக அதன் பிரதிநிதித்துவத்திலிருந்து ஒரு சொந்த எண்டியன் முழு எண் மதிப்பை உருவாக்கவும்.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ஐப் பயன்படுத்து;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * உள்ளீடு=ஓய்வு;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// நேட்டிவ் எண்டியன்ஸில் ஒரு பைட் வரிசையாக அதன் நினைவக பிரதிநிதித்துவத்திலிருந்து ஒரு சொந்த எண்டியன் முழு எண் மதிப்பை உருவாக்கவும்.
        ///
        /// இலக்கு தளத்தின் சொந்த முடிவு பயன்படுத்தப்படுவதால், சிறிய குறியீடு [`from_be_bytes`] அல்லது [`from_le_bytes`] ஐப் பயன்படுத்த விரும்புகிறது.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } else {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ஐப் பயன்படுத்து;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * உள்ளீடு=ஓய்வு;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // பாதுகாப்பு: முழு ஒலி முழு பழைய தரவு வகைகளாக இருப்பதால், நாம் எப்போதும் முடியும்
        // அவர்களுக்கு மாற்றவும்
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // பாதுகாப்பு: முழு எண்கள் பழைய பழைய தரவு வகைகளாகும், எனவே நாம் எப்போதும் அவற்றுக்கு மாற்றலாம்
            unsafe { mem::transmute(bytes) }
        }

        /// புதிய குறியீடு பயன்படுத்த விரும்ப வேண்டும்
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// இந்த முழு எண் வகையால் குறிப்பிடக்கூடிய மிகச்சிறிய மதிப்பை வழங்குகிறது.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// புதிய குறியீடு பயன்படுத்த விரும்ப வேண்டும்
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// இந்த முழு எண் வகையால் குறிப்பிடக்கூடிய மிகப்பெரிய மதிப்பை வழங்குகிறது.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}