//! "மிதக்கும் புள்ளி எண்களை விரைவாகவும் துல்லியமாகவும் அச்சிடுதல்" [^ 1] இன் படம் 3 இன் கிட்டத்தட்ட நேரடி (ஆனால் சற்று உகந்ததாக) Rust மொழிபெயர்ப்பு.
//!
//!
//! [^1]: Burger, ஆர்.ஜி மற்றும் டிப்விக், ஆர்.கே 1996. மிதக்கும் புள்ளி எண்களை அச்சிடுதல்
//!   விரைவாகவும் துல்லியமாகவும்.SIGPLAN இல்லை.31, 5 (மே. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n) க்கு `இலக்கத்தின் முன் கணக்கிடப்பட்ட வரிசைகள்
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// `x < 16 * scale` போது மட்டுமே பொருந்தக்கூடியது;`scaleN` `scale.mul_small(N)` ஆக இருக்க வேண்டும்
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// டிராகனுக்கான குறுகிய பயன்முறை செயல்படுத்தல்.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // வடிவமைக்க `v` எண் அறியப்படுகிறது:
    // - `mant * 2^exp` க்கு சமம்;
    // - அசல் வகைக்கு முன்னால் `(mant - 2 *minus)* 2^exp`;மற்றும்
    // - அசல் வகையில் `(mant + 2 *plus)* 2^exp` ஐத் தொடர்ந்து.
    //
    // வெளிப்படையாக, `minus` மற்றும் `plus` பூஜ்ஜியமாக இருக்க முடியாது.(முடிவிலிகளுக்கு, நாங்கள் எல்லைக்கு அப்பாற்பட்ட மதிப்புகளைப் பயன்படுத்துகிறோம்.) குறைந்தது ஒரு இலக்கத்தையாவது உருவாக்கப்படுகிறது என்றும் கருதுகிறோம், அதாவது, `mant` கூட பூஜ்ஜியமாக இருக்க முடியாது.
    //
    // இதன் பொருள் `low = (mant - minus)*2^exp` மற்றும் `high = (mant + plus)* 2^exp` க்கு இடையிலான எந்த எண்ணும் இந்த துல்லியமான மிதக்கும் புள்ளி எண்ணுடன் வரைபடமாக இருக்கும், அசல் மன்டிசா சமமாக இருக்கும்போது (அதாவது, `!mant_was_odd`) வரம்புகள் சேர்க்கப்படும்.
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` ஆகும்
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` ஐ திருப்திப்படுத்தும் அசல் உள்ளீடுகளிலிருந்து `k_0` ஐ மதிப்பிடுங்கள்.
    // இறுக்கமான பிணைந்த `k` திருப்திகரமான `10^(k-1) < high <= 10^k` பின்னர் கணக்கிடப்படுகிறது.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` ஐ பின் வடிவமாக மாற்றவும்:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` ஐ `10^k` ஆல் வகுக்கவும்.இப்போது `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (அல்லது `>=`) போது சரிசெய்தல்.
    // நாம் உண்மையில் `scale` ஐ மாற்றியமைக்கவில்லை, ஏனெனில் அதற்கு பதிலாக ஆரம்ப பெருக்கத்தை தவிர்க்கலாம்.
    // இப்போது `scale < mant + plus <= scale * 10` மற்றும் இலக்கங்களை உருவாக்க நாங்கள் தயாராக உள்ளோம்.
    //
    // `scale - plus < mant < scale` போது `d[0]` * பூஜ்ஜியமாக இருக்கலாம் என்பதை நினைவில் கொள்க.
    // இந்த வழக்கில் ரவுண்டிங்-அப் நிலை (கீழே உள்ள `up`) உடனடியாக தூண்டப்படும்.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // `scale` ஐ 10 ஆல் அளவிடுவதற்கு சமம்
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // இலக்க தலைமுறைக்கு கேச் `(2, 4, 8) * scale`.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // `d[0..n-1]` என்பது இதுவரை உருவாக்கப்பட்ட இலக்கங்கள்:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (இவ்வாறு `mant / scale < 10`) இங்கு `d[i..j]` என்பது `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // ஒரு இலக்கத்தை உருவாக்கு: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // இது மாற்றியமைக்கப்பட்ட டிராகன் வழிமுறையின் எளிமைப்படுத்தப்பட்ட விளக்கமாகும்.
        // பல இடைநிலை வழித்தோன்றல்கள் மற்றும் முழுமையான வாதங்கள் வசதிக்காக தவிர்க்கப்பட்டுள்ளன.
        //
        // நாங்கள் `n` ஐ புதுப்பித்தபடி, மாற்றியமைக்கப்பட்ட மாற்றங்களுடன் தொடங்கவும்:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `d[0..n-1]` என்பது `low` மற்றும் `high` க்கு இடையிலான குறுகிய பிரதிநிதித்துவம் என்று வைத்துக் கொள்ளுங்கள், அதாவது, `d[0..n-1]` பின்வரும் இரண்டையும் திருப்திப்படுத்துகிறது, ஆனால் `d[0..n-2]` இல்லை:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: இலக்கங்கள் `v` க்கு சுற்று);மற்றும்
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (கடைசி இலக்கம் சரியானது).
        //
        // இரண்டாவது நிபந்தனை `2 * mant <= scale` க்கு எளிதாக்குகிறது.
        // `mant`, `low` மற்றும் `high` ஆகியவற்றின் அடிப்படையில் மாற்றங்களைத் தீர்ப்பது முதல் நிபந்தனையின் எளிமையான பதிப்பை அளிக்கிறது: `-plus < mant < minus`.
        // `-plus < 0 <= mant` முதல், `mant < minus` மற்றும் `2 * mant <= scale` போது சரியான குறுகிய பிரதிநிதித்துவம் எங்களிடம் உள்ளது.
        // (அசல் மன்டிசா சமமாக இருக்கும்போது முந்தையது `mant <= minus` ஆகிறது.)
        //
        // இரண்டாவது வைத்திருக்காதபோது (`2 * mant> அளவுகோல்`), கடைசி இலக்கத்தை அதிகரிக்க வேண்டும்.
        // அந்த நிலையை மீட்டமைக்க இது போதுமானது: இலக்க தலைமுறை `0 <= v / 10^(k-n) - d[0..n-1] < 1` க்கு உத்தரவாதம் அளிக்கிறது என்பதை நாங்கள் ஏற்கனவே அறிவோம்.
        // இந்த வழக்கில், முதல் நிபந்தனை `-plus < mant - scale < minus` ஆகிறது.
        // தலைமுறைக்குப் பிறகு `mant < scale` முதல், எங்களிடம் `scale < mant + plus` உள்ளது.
        // (மீண்டும், அசல் மன்டிசா சமமாக இருக்கும்போது இது `scale <= mant + plus` ஆகிறது.)
        //
        // சுருக்கமாக:
        // - `mant < minus` (அல்லது `<=`) போது `down` ஐ நிறுத்தி (இலக்கங்களை அப்படியே வைத்திருங்கள்).
        // - `scale < mant + plus` (அல்லது `<=`) போது `up` ஐ நிறுத்தவும் (கடைசி இலக்கத்தை அதிகரிக்கவும்).
        // - இல்லையெனில் உருவாக்குங்கள்.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // எங்களிடம் மிகக் குறுகிய பிரதிநிதித்துவம் உள்ளது, ரவுண்டிங்கிற்குச் செல்லுங்கள்

        // மாற்றங்களை மீட்டெடுக்கவும்.
        // இது வழிமுறையை எப்போதும் நிறுத்துகிறது: `minus` மற்றும் `plus` எப்போதும் அதிகரிக்கிறது, ஆனால் `mant` கிளிப் செய்யப்பட்ட மட்டு `scale` மற்றும் `scale` சரி செய்யப்பட்டது.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // நான்) ரவுண்டிங்-அப் நிபந்தனை மட்டுமே தூண்டப்பட்டபோது, அல்லது ii) இரண்டு நிபந்தனைகளும் தூண்டப்பட்டு, டை பிரேக்கிங் ரவுண்டிங் வரை விரும்புகிறது.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ரவுண்டிங் நீளத்தை மாற்றினால், அடுக்கு மாற வேண்டும்.
        // இந்த நிபந்தனை பூர்த்தி செய்வது மிகவும் கடினம் (சாத்தியமற்றது) என்று தோன்றுகிறது, ஆனால் நாங்கள் இங்கே பாதுகாப்பாகவும் சீராகவும் இருக்கிறோம்.
        //
        // பாதுகாப்பு: மேலே அந்த நினைவகத்தை நாங்கள் துவக்கினோம்.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // பாதுகாப்பு: மேலே அந்த நினைவகத்தை நாங்கள் துவக்கினோம்.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// டிராகனுக்கான சரியான மற்றும் நிலையான பயன்முறை செயல்படுத்தல்.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` ஐ திருப்திப்படுத்தும் அசல் உள்ளீடுகளிலிருந்து `k_0` ஐ மதிப்பிடுங்கள்.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` ஐ `10^k` ஆல் வகுக்கவும்.இப்போது `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // `mant + plus >= scale` போது சரிசெய்தல், அங்கு `plus / scale = 10^-buf.len() / 2`.
    // நிலையான அளவிலான பிக்னத்தை வைத்திருக்க, நாங்கள் உண்மையில் `mant + floor(plus) >= scale` ஐப் பயன்படுத்துகிறோம்.
    // நாம் உண்மையில் `scale` ஐ மாற்றியமைக்கவில்லை, ஏனெனில் அதற்கு பதிலாக ஆரம்ப பெருக்கத்தை தவிர்க்கலாம்.
    // மீண்டும் குறுகிய வழிமுறையுடன், `d[0]` பூஜ்ஜியமாக இருக்கலாம், ஆனால் இறுதியில் அது வட்டமிடப்படும்.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // `scale` ஐ 10 ஆல் அளவிடுவதற்கு சமம்
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // கடைசி இலக்க வரம்புடன் நாங்கள் பணிபுரிகிறோம் என்றால், இரட்டை வட்டமிடுதலைத் தவிர்ப்பதற்காக உண்மையான ஒழுங்கமைப்பிற்கு முன் இடையகத்தை சுருக்க வேண்டும்.
    //
    // முழுமையாக்கும் போது மீண்டும் இடையகத்தை பெரிதாக்க வேண்டும் என்பதை நினைவில் கொள்க!
    let mut len = if k < limit {
        // அச்சச்சோ, எங்களால் *ஒரு* இலக்கத்தை கூட உருவாக்க முடியாது.
        // 9.5 போன்ற ஒன்றை நாங்கள் பெற்றுள்ளோம், அது 10 ஆக வட்டமிடப்படும் போது இது சாத்தியமாகும்.
        // `k == limit` போது நிகழும் மற்றும் சரியாக ஒரு இலக்கத்தை உருவாக்க வேண்டிய பிற்கால ரவுண்டிங்-அப் வழக்கைத் தவிர்த்து, நாங்கள் ஒரு வெற்று இடையகத்தைத் தருகிறோம்.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // இலக்க தலைமுறைக்கு கேச் `(2, 4, 8) * scale`.
        // (இது விலை உயர்ந்ததாக இருக்கும், எனவே இடையக காலியாக இருக்கும்போது அவற்றைக் கணக்கிட வேண்டாம்.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // பின்வரும் இலக்கங்கள் அனைத்தும் பூஜ்ஜியங்களாகும், நாங்கள் இங்கே நிறுத்துகிறோம் * ரவுண்டிங் செய்ய முயற்சிக்க வேண்டாம்!மாறாக, மீதமுள்ள இலக்கங்களை நிரப்பவும்.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // பாதுகாப்பு: மேலே அந்த நினைவகத்தை நாங்கள் துவக்கினோம்.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // பின்வரும் இலக்கங்கள் சரியாக 5000 ஆக இருந்தால், இலக்கங்களின் நடுவில் நிறுத்தினால் ..., முந்தைய இலக்கத்தை சரிபார்த்து, சமமாகச் சுற்ற முயற்சிக்கவும் (அதாவது, முந்தைய இலக்க சமமாக இருக்கும்போது வட்டமிடுவதைத் தவிர்க்கவும்).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // பாதுகாப்பு: `buf[len-1]` துவக்கப்பட்டது.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ரவுண்டிங் நீளத்தை மாற்றினால், அடுக்கு மாற வேண்டும்.
        // ஆனால் எங்களிடம் ஒரு குறிப்பிட்ட எண்ணிக்கையிலான இலக்கங்கள் கோரப்பட்டுள்ளன, எனவே இடையகத்தை மாற்ற வேண்டாம் ...
        // பாதுகாப்பு: மேலே அந்த நினைவகத்தை நாங்கள் துவக்கினோம்.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... அதற்கு பதிலாக நிலையான துல்லியத்தை நாங்கள் கோரவில்லை என்றால்.
            // அசல் இடையக காலியாக இருந்தால், கூடுதல் இலக்கத்தை `k == limit` (edge வழக்கு) போது மட்டுமே சேர்க்க முடியும் என்பதையும் சரிபார்க்க வேண்டும்.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // பாதுகாப்பு: மேலே அந்த நினைவகத்தை நாங்கள் துவக்கினோம்.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}