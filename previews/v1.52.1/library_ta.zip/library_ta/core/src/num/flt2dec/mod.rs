/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// இது விரிவாக ஆவணப்படுத்தப்பட்டாலும், இது கொள்கை அடிப்படையில் தனிப்பட்டது, இது சோதனைக்கு மட்டுமே பொதுவானது.
// எங்களை அம்பலப்படுத்த வேண்டாம்.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// இலக்க-தலைமுறை வழிமுறைகள்.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// குறுகிய பயன்முறைக்கு தேவையான இடையகத்தின் குறைந்தபட்ச அளவு.
///
/// இது ஒரு சிறிய அற்பமானது அல்ல, ஆனால் இது குறுகிய முடிவைக் கொண்ட வழிமுறைகளை வடிவமைப்பதில் இருந்து குறிப்பிடத்தக்க தசம இலக்கங்களின் அதிகபட்ச எண்ணிக்கையாகும்.
///
/// சரியான சூத்திரம் `ceil(# bits in mantissa * log_10 2 + 1)` ஆகும்.
pub const MAX_SIG_DIGITS: usize = 17;

/// `d` தசம இலக்கங்களைக் கொண்டிருக்கும்போது, கடைசி இலக்கத்தை அதிகரித்து, கேரியைப் பரப்புங்கள்.
/// நீளம் மாறும்போது அடுத்த இலக்கத்தை வழங்குகிறது.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] எல்லாம் ஒன்பது
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 அதிகரித்த அடுக்குடன் 1000..000 வரை சுற்றுகள்
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // ஒரு வெற்று இடையகம் வட்டமிடுகிறது (சற்று விசித்திரமான ஆனால் நியாயமான)
            Some(b'1')
        }
    }
}

/// வடிவமைக்கப்பட்ட பாகங்கள்.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// பூஜ்ஜிய இலக்கங்களின் எண்ணிக்கை கொடுக்கப்பட்டுள்ளது.
    Zero(usize),
    /// 5 இலக்கங்கள் வரை ஒரு நேரடி எண்.
    Num(u16),
    /// கொடுக்கப்பட்ட பைட்டுகளின் சொற்களஞ்சியம்.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// கொடுக்கப்பட்ட பகுதியின் சரியான பைட் நீளத்தை வழங்குகிறது.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// வழங்கப்பட்ட இடையகத்தில் ஒரு பகுதியை எழுதுகிறார்.
    /// எழுதப்பட்ட பைட்டுகளின் எண்ணிக்கையை வழங்குகிறது, அல்லது இடையகம் போதுமானதாக இல்லாவிட்டால் `None`.
    /// (இது இன்னும் ஓரளவு எழுதப்பட்ட பைட்டுகளை இடையகத்தில் விடக்கூடும்; அதை நம்ப வேண்டாம்.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// ஒன்று அல்லது அதற்கு மேற்பட்ட பகுதிகளைக் கொண்ட வடிவமைக்கப்பட்ட முடிவு.
/// இதை பைட் இடையகத்திற்கு எழுதலாம் அல்லது ஒதுக்கப்பட்ட சரத்திற்கு மாற்றலாம்.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// `""`, `"-"` அல்லது `"+"` ஐக் குறிக்கும் ஒரு பைட் துண்டு.
    pub sign: &'static str,
    /// ஒரு அடையாளம் மற்றும் விருப்ப பூஜ்ஜிய திணிப்புக்குப் பிறகு வடிவமைக்கப்பட்ட பாகங்கள்.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// ஒருங்கிணைந்த வடிவமைக்கப்பட்ட முடிவின் சரியான பைட் நீளத்தை வழங்குகிறது.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// வடிவமைக்கப்பட்ட அனைத்து பகுதிகளையும் வழங்கப்பட்ட இடையகத்தில் எழுதுகிறது.
    /// எழுதப்பட்ட பைட்டுகளின் எண்ணிக்கையை வழங்குகிறது, அல்லது இடையகம் போதுமானதாக இல்லாவிட்டால் `None`.
    /// (இது இன்னும் ஓரளவு எழுதப்பட்ட பைட்டுகளை இடையகத்தில் விடக்கூடும்; அதை நம்ப வேண்டாம்.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// தசம இலக்கங்கள் `0.<...buf...> * 10^exp` ஐ தசம வடிவத்தில் கொடுக்கப்பட்ட வடிவங்கள் குறைந்தது கொடுக்கப்பட்ட பகுதியளவு இலக்கங்களுடன்.
///
/// இதன் விளைவாக வழங்கப்பட்ட பாகங்கள் வரிசையில் சேமிக்கப்படுகிறது மற்றும் எழுதப்பட்ட பகுதிகளின் ஒரு துண்டு திரும்பும்.
///
/// `frac_digits` `buf` இல் உண்மையான பகுதியளவு இலக்கங்களின் எண்ணிக்கையை விட குறைவாக இருக்கலாம்;
/// இது புறக்கணிக்கப்படும் மற்றும் முழு இலக்கங்கள் அச்சிடப்படும்.காண்பிக்கப்பட்ட இலக்கங்களுக்குப் பிறகு கூடுதல் பூஜ்ஜியங்களை அச்சிட மட்டுமே இது பயன்படுத்தப்படுகிறது.
/// இதனால் 0 இன் `frac_digits` என்பது கொடுக்கப்பட்ட இலக்கங்களை மட்டுமே அச்சிடும், வேறு ஒன்றும் இல்லை.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // கடைசி இலக்க நிலையில் கட்டுப்பாடு இருந்தால், `buf` மெய்நிகர் பூஜ்ஜியங்களுடன் இடதுபுறமாக இருக்கும் என்று கருதப்படுகிறது.
    // மெய்நிகர் பூஜ்ஜியங்களின் எண்ணிக்கை, `nzeroes`, `max(0, exp + frac_digits - buf.len())` க்கு சமம், இதனால் கடைசி இலக்க `exp - buf.len() - nzeroes` இன் நிலை `-frac_digits` ஐ விட அதிகமாக இருக்காது:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |பூஜ்ஜியங்கள் |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` வழிதல் தவிர்க்க ஒவ்வொரு வழக்குக்கும் தனித்தனியாக கணக்கிடப்படுகிறது.
    //

    if exp <= 0 {
        // காண்பிக்கப்பட்ட இலக்கங்களுக்கு முன் தசம புள்ளி: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // பாதுகாப்பு: `..4` உறுப்புகளை நாங்கள் துவக்கினோம்.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // பாதுகாப்பு: `..3` உறுப்புகளை நாங்கள் துவக்கினோம்.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // தசம புள்ளி காண்பிக்கப்பட்ட இலக்கங்களுக்குள் உள்ளது: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // பாதுகாப்பு: `..4` உறுப்புகளை நாங்கள் துவக்கினோம்.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // பாதுகாப்பு: `..3` உறுப்புகளை நாங்கள் துவக்கினோம்.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // காண்பிக்கப்பட்ட இலக்கங்களுக்குப் பிறகு தசம புள்ளி: [1234][____0000] அல்லது [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // பாதுகாப்பு: `..4` உறுப்புகளை நாங்கள் துவக்கினோம்.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // பாதுகாப்பு: `..2` உறுப்புகளை நாங்கள் துவக்கினோம்.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// கொடுக்கப்பட்ட தசம இலக்கங்கள் `0.<...buf...> * 10^exp` ஐ அதிவேக வடிவத்தில் குறைந்தது கொடுக்கப்பட்ட குறிப்பிடத்தக்க இலக்கங்களுடன் வடிவமைக்கிறது.
///
/// `upper` `true` ஆக இருக்கும்போது, அடுக்கு `E` ஆல் முன்னொட்டாக இருக்கும்;இல்லையெனில் அது `e`.
/// இதன் விளைவாக வழங்கப்பட்ட பாகங்கள் வரிசையில் சேமிக்கப்படுகிறது மற்றும் எழுதப்பட்ட பகுதிகளின் ஒரு துண்டு திரும்பும்.
///
/// `min_digits` `buf` இல் உண்மையான குறிப்பிடத்தக்க இலக்கங்களின் எண்ணிக்கையை விட குறைவாக இருக்கலாம்;
/// இது புறக்கணிக்கப்படும் மற்றும் முழு இலக்கங்கள் அச்சிடப்படும்.காண்பிக்கப்பட்ட இலக்கங்களுக்குப் பிறகு கூடுதல் பூஜ்ஜியங்களை அச்சிட மட்டுமே இது பயன்படுத்தப்படுகிறது.
/// எனவே, `min_digits == 0` என்பது கொடுக்கப்பட்ட இலக்கங்களை மட்டுமே அச்சிடும், வேறு ஒன்றும் இல்லை.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // எக்ஸ்ப் i16::MIN ஆக இருக்கும்போது நீரோட்டத்தைத் தவிர்க்கவும்
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // பாதுகாப்பு: `..n + 2` உறுப்புகளை நாங்கள் துவக்கினோம்.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// வடிவமைப்பு விருப்பங்களில் கையொப்பமிடுங்கள்.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// எதிர்மறை பூஜ்ஜியமற்ற மதிப்புகளுக்கு மட்டுமே `-` ஐ அச்சிடுகிறது.
    Minus, // -inf -1 0 0 1 inf nan
    /// எந்த எதிர்மறை மதிப்புகளுக்கும் (எதிர்மறை பூஜ்ஜியம் உட்பட) மட்டுமே `-` ஐ அச்சிடுகிறது.
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// எதிர்மறை பூஜ்ஜியமற்ற மதிப்புகளுக்கு `-` ஐ அச்சிடுகிறது, இல்லையெனில் `+`.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// எந்த எதிர்மறை மதிப்புகளுக்கும் (எதிர்மறை பூஜ்ஜியம் உட்பட) `-` ஐ அச்சிடுகிறது, இல்லையெனில் `+` ஐ அச்சிடுகிறது.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// வடிவமைக்கப்பட வேண்டிய அடையாளத்துடன் தொடர்புடைய நிலையான பைட் சரத்தை வழங்குகிறது.
/// இது `""`, `"+"` அல்லது `"-"` ஆக இருக்கலாம்.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// கொடுக்கப்பட்ட மிதக்கும் புள்ளி எண்ணை தசம வடிவத்தில் குறைந்தது கொடுக்கப்பட்ட பகுதியளவு இலக்கங்களுடன் வடிவமைக்கிறது.
/// கொடுக்கப்பட்ட பைட் இடையகத்தை ஒரு கீறலாகப் பயன்படுத்தும்போது, வழங்கப்பட்ட பாகங்கள் வரிசையில் முடிவு சேமிக்கப்படுகிறது.
/// `upper` தற்போது பயன்படுத்தப்படாதது, ஆனால் வரையறுக்கப்படாத மதிப்புகள், அதாவது `inf` மற்றும் `nan` ஆகியவற்றை மாற்றுவதற்கான future முடிவுக்கு விடப்பட்டுள்ளது.
///
/// வழங்கப்பட வேண்டிய முதல் பகுதி எப்போதும் ஒரு `Part::Sign` ஆகும் (எந்த அடையாளமும் வழங்கப்படாவிட்டால் இது வெற்று சரமாக இருக்கலாம்).
///
/// `format_shortest` அடிப்படை-தலைமுறை செயல்பாடாக இருக்க வேண்டும்.
/// அது துவக்கிய இடையகத்தின் பகுதியை அது திருப்பித் தர வேண்டும்.
/// இதற்காக நீங்கள் `strategy::grisu::format_shortest` ஐ விரும்பலாம்.
///
/// `frac_digits` `v` இல் உண்மையான பகுதியளவு இலக்கங்களின் எண்ணிக்கையை விட குறைவாக இருக்கலாம்;
/// இது புறக்கணிக்கப்படும் மற்றும் முழு இலக்கங்கள் அச்சிடப்படும்.காண்பிக்கப்பட்ட இலக்கங்களுக்குப் பிறகு கூடுதல் பூஜ்ஜியங்களை அச்சிட மட்டுமே இது பயன்படுத்தப்படுகிறது.
/// இதனால் 0 இன் `frac_digits` என்பது கொடுக்கப்பட்ட இலக்கங்களை மட்டுமே அச்சிடும், வேறு ஒன்றும் இல்லை.
///
/// பைட் இடையக குறைந்தபட்சம் `MAX_SIG_DIGITS` பைட்டுகள் நீளமாக இருக்க வேண்டும்.
/// `frac_digits = 10` உடன் `[+][0.][0000][2][0000]` போன்ற மோசமான நிலை காரணமாக குறைந்தது 4 பாகங்கள் கிடைக்க வேண்டும்.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // பாதுகாப்பு: `..2` உறுப்புகளை நாங்கள் துவக்கினோம்.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// கொடுக்கப்பட்ட மிதக்கும் புள்ளி எண்ணை தசம வடிவத்தில் அல்லது அதிவேக வடிவத்தில் வடிவமைக்கிறது, இதன் விளைவாக ஏற்படும் அடுக்கு.
/// கொடுக்கப்பட்ட பைட் இடையகத்தை ஒரு கீறலாகப் பயன்படுத்தும்போது, வழங்கப்பட்ட பாகங்கள் வரிசையில் முடிவு சேமிக்கப்படுகிறது.
/// `upper` வரையறுக்கப்பட்ட மதிப்புகள் (`inf` மற்றும் `nan`) அல்லது அதிவேக முன்னொட்டு (`e` அல்லது `E`) வழக்கைத் தீர்மானிக்கப் பயன்படுகிறது.
/// வழங்கப்பட வேண்டிய முதல் பகுதி எப்போதும் ஒரு `Part::Sign` ஆகும் (எந்த அடையாளமும் வழங்கப்படாவிட்டால் இது வெற்று சரமாக இருக்கலாம்).
///
/// `format_shortest` அடிப்படை-தலைமுறை செயல்பாடாக இருக்க வேண்டும்.
/// அது துவக்கிய இடையகத்தின் பகுதியை அது திருப்பித் தர வேண்டும்.
/// இதற்காக நீங்கள் `strategy::grisu::format_shortest` ஐ விரும்பலாம்.
///
/// `dec_bounds` என்பது ஒரு இரட்டை `(lo, hi)` ஆகும், இது `10^lo <= V < 10^hi` ஆக இருக்கும்போது மட்டுமே எண் தசமமாக வடிவமைக்கப்படுகிறது.
/// உண்மையான `v` க்கு பதிலாக இது *வெளிப்படையான*`V` என்பதை நினைவில் கொள்க!இதனால் எக்ஸ்போனென்ஷியல் வடிவத்தில் எந்த அச்சிடப்பட்ட அடுக்கு இந்த வரம்பில் இருக்க முடியாது, எந்த குழப்பத்தையும் தவிர்க்கலாம்.
///
///
/// பைட் இடையக குறைந்தபட்சம் `MAX_SIG_DIGITS` பைட்டுகள் நீளமாக இருக்க வேண்டும்.
/// `[+][1][.][2345][e][-][6]` போன்ற மோசமான நிலை காரணமாக குறைந்தது 6 பாகங்கள் கிடைக்க வேண்டும்.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// கொடுக்கப்பட்ட டிகோட் செய்யப்பட்ட எக்ஸ்போனெண்டிலிருந்து கணக்கிடப்பட்ட அதிகபட்ச இடையக அளவிற்கு ஒரு கச்சா தோராயத்தை (மேல் பிணைப்பு) வழங்குகிறது.
///
/// சரியான வரம்பு:
///
/// - `exp < 0` போது, அதிகபட்ச நீளம் `ceil(log_10 (5^-exp * (2^64 - 1)))` ஆகும்.
/// - `exp >= 0` போது, அதிகபட்ச நீளம் `ceil(log_10 (2^exp * (2^64 - 1)))` ஆகும்.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` இது `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` ஐ விடக் குறைவானது, இது `20 + (1 + exp* log_10 x)` ஐ விடக் குறைவாகும்.
/// `log_10 2 < 5/16` மற்றும் `log_10 5 < 12/16` என்ற உண்மைகளை நாங்கள் பயன்படுத்துகிறோம், இது எங்கள் நோக்கங்களுக்காக போதுமானது.
///
/// நமக்கு இது ஏன் தேவை?கடைசி இலக்கக் கட்டுப்பாட்டால் வரையறுக்கப்படாவிட்டால் `format_exact` செயல்பாடுகள் முழு இடையகத்தையும் நிரப்புகின்றன, ஆனால் கோரப்பட்ட இலக்கங்களின் எண்ணிக்கை அபத்தமானது என்று சொல்லலாம் (அதாவது, 30,000 இலக்கங்கள்).
///
/// பெரும்பாலான இடையகமானது பூஜ்ஜியங்களால் நிரப்பப்படும், எனவே எல்லா இடையகங்களையும் முன்பே ஒதுக்க நாங்கள் விரும்பவில்லை.
/// இதன் விளைவாக, எந்தவொரு வாதங்களுக்கும்,
/// `f64` க்கு 826 பைட்டுகள் இடையக போதுமானதாக இருக்க வேண்டும்.மிக மோசமான நிலைக்கு உண்மையான எண்ணுடன் இதை ஒப்பிடுங்கள்: 770 பைட்டுகள் (எக்ஸ் 01 எக்ஸ் போது).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// மிதக்கும் புள்ளி எண்ணை அதிவேக வடிவத்தில் கொடுக்கப்பட்ட வடிவங்கள் சரியாக கொடுக்கப்பட்ட குறிப்பிடத்தக்க இலக்கங்களைக் கொண்டுள்ளன.
/// கொடுக்கப்பட்ட பைட் இடையகத்தை ஒரு கீறலாகப் பயன்படுத்தும்போது, வழங்கப்பட்ட பாகங்கள் வரிசையில் முடிவு சேமிக்கப்படுகிறது.
/// `upper` அடுக்கு முன்னொட்டு (`e` அல்லது `E`) வழக்கைத் தீர்மானிக்கப் பயன்படுகிறது.
/// வழங்கப்பட வேண்டிய முதல் பகுதி எப்போதும் ஒரு `Part::Sign` ஆகும் (எந்த அடையாளமும் வழங்கப்படாவிட்டால் இது வெற்று சரமாக இருக்கலாம்).
///
/// `format_exact` அடிப்படை-தலைமுறை செயல்பாடாக இருக்க வேண்டும்.
/// அது துவக்கிய இடையகத்தின் பகுதியை அது திருப்பித் தர வேண்டும்.
/// இதற்காக நீங்கள் `strategy::grisu::format_exact` ஐ விரும்பலாம்.
///
/// `ndigits` மிகப் பெரியதாக இல்லாவிட்டால் பைட் இடையக குறைந்தபட்சம் `ndigits` பைட்டுகள் நீளமாக இருக்க வேண்டும், நிலையான எண்ணிக்கையிலான இலக்கங்கள் மட்டுமே எப்போதும் எழுதப்படும்.
/// (`f64` க்கான டிப்பிங் பாயிண்ட் சுமார் 800 ஆகும், எனவே 1000 பைட்டுகள் போதுமானதாக இருக்க வேண்டும்.) `[+][1][.][2345][e][-][6]` போன்ற மோசமான நிலை காரணமாக குறைந்தது 6 பாகங்கள் கிடைக்க வேண்டும்.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // பாதுகாப்பு: `..3` உறுப்புகளை நாங்கள் துவக்கினோம்.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// மிதக்கும் புள்ளி எண்ணை தசம வடிவத்தில் கொடுக்கப்பட்ட வடிவங்கள் சரியாக கொடுக்கப்பட்ட பகுதியளவு இலக்கங்களுடன்.
/// கொடுக்கப்பட்ட பைட் இடையகத்தை ஒரு கீறலாகப் பயன்படுத்தும்போது, வழங்கப்பட்ட பாகங்கள் வரிசையில் முடிவு சேமிக்கப்படுகிறது.
/// `upper` தற்போது பயன்படுத்தப்படாதது, ஆனால் வரையறுக்கப்படாத மதிப்புகள், அதாவது `inf` மற்றும் `nan` ஆகியவற்றை மாற்றுவதற்கான future முடிவுக்கு விடப்பட்டுள்ளது.
/// வழங்கப்பட வேண்டிய முதல் பகுதி எப்போதும் ஒரு `Part::Sign` ஆகும் (எந்த அடையாளமும் வழங்கப்படாவிட்டால் இது வெற்று சரமாக இருக்கலாம்).
///
/// `format_exact` அடிப்படை-தலைமுறை செயல்பாடாக இருக்க வேண்டும்.
/// அது துவக்கிய இடையகத்தின் பகுதியை அது திருப்பித் தர வேண்டும்.
/// இதற்காக நீங்கள் `strategy::grisu::format_exact` ஐ விரும்பலாம்.
///
/// `frac_digits` மிகப் பெரியதாக இல்லாவிட்டால், பைட் இடையகம் வெளியீட்டிற்கு போதுமானதாக இருக்க வேண்டும், நிலையான எண்ணிக்கையிலான இலக்கங்கள் மட்டுமே எப்போதும் எழுதப்படும்.
/// (`f64` க்கான டிப்பிங் பாயிண்ட் சுமார் 800, மற்றும் 1000 பைட்டுகள் போதுமானதாக இருக்க வேண்டும்.) `frac_digits = 10` உடன் `[+][0.][0000][2][0000]` போன்ற மோசமான நிலை காரணமாக குறைந்தது 4 பாகங்கள் கிடைக்க வேண்டும்.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // பாதுகாப்பு: `..2` உறுப்புகளை நாங்கள் துவக்கினோம்.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // `frac_digits` அபத்தமானது என்று பெரியது *சாத்தியம்*.
            // `format_exact` இந்த விஷயத்தில் இலக்கங்களை ரெண்டரிங் செய்வதற்கு முன்பே முடிவடையும், ஏனென்றால் நாங்கள் `maxlen` ஆல் கண்டிப்பாக வரையறுக்கப்பட்டுள்ளோம்.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // கட்டுப்பாட்டை பூர்த்தி செய்ய முடியவில்லை, எனவே இது `exp` ஐப் பொருட்படுத்தாமல் பூஜ்ஜியத்தைப் போல வழங்க வேண்டும்.
                // இறுதி ரவுண்டிங் முடிந்த பின்னரே இந்த கட்டுப்பாடு பூர்த்தி செய்யப்பட்டுள்ளது என்ற வழக்கு இதில் இல்லை;இது `exp = limit + 1` உடன் வழக்கமான வழக்கு.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // பாதுகாப்பு: `..2` உறுப்புகளை நாங்கள் துவக்கினோம்.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // பாதுகாப்பு: `..1` உறுப்புகளை நாங்கள் துவக்கினோம்.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}