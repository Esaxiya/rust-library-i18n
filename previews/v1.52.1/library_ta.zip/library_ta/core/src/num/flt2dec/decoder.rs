//! மிதக்கும் புள்ளி மதிப்பை தனிப்பட்ட பாகங்கள் மற்றும் பிழை வரம்புகளாகக் குறிக்கிறது.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// டிகோட் செய்யப்படாத வரையறுக்கப்பட்ட மதிப்பு, அதாவது:
///
/// - அசல் மதிப்பு `mant * 2^exp` க்கு சமம்.
///
/// - `(mant - minus)*2^exp` முதல் `(mant + plus)* 2^exp` வரையிலான எந்த எண்ணும் அசல் மதிப்புக்கு வட்டமிடும்.
/// `inclusive` `true` ஆக இருக்கும்போது மட்டுமே வரம்பு அடங்கும்.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// அளவிடப்பட்ட மன்டிசா.
    pub mant: u64,
    /// குறைந்த பிழை வரம்பு.
    pub minus: u64,
    /// மேல் பிழை வரம்பு.
    pub plus: u64,
    /// அடிப்படை 2 இல் பகிரப்பட்ட அடுக்கு.
    pub exp: i16,
    /// பிழை வரம்பு உள்ளடக்கியதாக இருக்கும்போது உண்மை.
    ///
    /// IEEE 754 இல், அசல் மன்டிசா சமமாக இருந்தபோது இது உண்மை.
    pub inclusive: bool,
}

/// டிகோட் செய்யப்படாத மதிப்பு.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// நேர்மறை அல்லது எதிர்மறை முடிவிலிகள்.
    Infinite,
    /// பூஜ்ஜியம், நேர்மறை அல்லது எதிர்மறை.
    Zero,
    /// மேலும் டிகோட் செய்யப்பட்ட புலங்களுடன் வரையறுக்கப்பட்ட எண்கள்.
    Finite(Decoded),
}

/// `டிகோட்` செய்யக்கூடிய மிதக்கும் புள்ளி வகை.
pub trait DecodableFloat: RawFloat + Copy {
    /// குறைந்தபட்ச நேர்மறை இயல்பாக்கப்பட்ட மதிப்பு.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// கொடுக்கப்பட்ட மிதக்கும் புள்ளி எண்ணிலிருந்து ஒரு அடையாளம் (எதிர்மறையாக இருக்கும்போது உண்மை) மற்றும் `FullDecoded` மதிப்பை வழங்குகிறது.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // அண்டை: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode எப்போதுமே அடுக்கு பாதுகாக்கிறது, எனவே மன்டிஸ்ஸா துணைக்கு அளவிடப்படுகிறது.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // அண்டை: (அதிகபட்சம், காலாவதியானது, 1)-(மினர்மன்ட், எக்ஸ்ப்)-(மினர்மன்ட் + 1, எக்ஸ்ப்)
                // எங்கே maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // அண்டை: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}