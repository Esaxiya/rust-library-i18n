//! ஒருங்கிணைந்த வகைகளுக்கு மாற்றுவதற்கான பிழை வகைகள்.

use crate::convert::Infallible;
use crate::fmt;

/// சரிபார்க்கப்பட்ட ஒருங்கிணைந்த வகை மாற்றம் தோல்வியுற்றால் பிழை வகை திரும்பியது.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // `Infallible` `!` க்கு மாற்றுப்பெயராக மாறும்போது மேலே உள்ள `From<Infallible> for TryFromIntError` போன்ற குறியீடு தொடர்ந்து செயல்படும் என்பதை உறுதிப்படுத்த கட்டாயத்தை விட பொருந்தவும்.
        //
        //
        match never {}
    }
}

/// ஒரு முழு எண்ணை பாகுபடுத்தும்போது திருப்பித் தரக்கூடிய பிழை.
///
/// இந்த பிழை [`i8::from_str_radix`] போன்ற பழமையான முழு எண் வகைகளில் `from_str_radix()` செயல்பாடுகளுக்கான பிழை வகையாக பயன்படுத்தப்படுகிறது.
///
/// # சாத்தியமான காரணங்கள்
///
/// பிற காரணங்களுக்கிடையில், `ParseIntError` சரம் இடைவெளியில் முன்னணி அல்லது பின்னால் இருப்பதால் தூக்கி எறியப்படலாம், எ.கா., நிலையான உள்ளீட்டிலிருந்து பெறப்படும் போது.
///
/// [`str::trim()`] முறையைப் பயன்படுத்துவது பாகுபடுத்துவதற்கு முன்பு எந்த இடைவெளியும் இல்லை என்பதை உறுதி செய்கிறது.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// ஒரு முழு எண்ணை பாகுபடுத்தல் தோல்வியடையும் பல்வேறு வகையான பிழைகளை சேமிக்க Enum.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// பாகுபடுத்தப்பட்ட மதிப்பு காலியாக உள்ளது.
    ///
    /// பிற காரணங்களுக்கிடையில், வெற்று சரம் பாகுபடுத்தும்போது இந்த மாறுபாடு கட்டமைக்கப்படும்.
    Empty,
    /// அதன் சூழலில் தவறான இலக்கத்தைக் கொண்டுள்ளது.
    ///
    /// பிற காரணங்களுக்கிடையில், ASCII அல்லாத எரிப்பொருளைக் கொண்ட ஒரு சரத்தை பாகுபடுத்தும்போது இந்த மாறுபாடு கட்டமைக்கப்படும்.
    ///
    /// ஒரு `+` அல்லது `-` ஒரு சரத்திற்குள் அதன் சொந்தமாக அல்லது ஒரு எண்ணின் நடுவில் தவறாக வைக்கப்படும்போது இந்த மாறுபாடு கட்டமைக்கப்படுகிறது.
    ///
    ///
    InvalidDigit,
    /// இலக்கு முழு எண் வகையைச் சேமிக்க முழு எண் மிகப் பெரியது.
    PosOverflow,
    /// இலக்கு முழு எண் வகையில் சேமிக்க முழு எண் மிகவும் சிறியது.
    NegOverflow,
    /// மதிப்பு பூஜ்ஜியமாக இருந்தது
    ///
    /// பாகுபடுத்தும் சரம் பூஜ்ஜியத்தின் மதிப்பைக் கொண்டிருக்கும்போது இந்த மாறுபாடு வெளியேற்றப்படும், இது பூஜ்ஜியமற்ற வகைகளுக்கு சட்டவிரோதமானது.
    ///
    Zero,
}

impl ParseIntError {
    /// ஒரு முழு எண் தோல்வியுற்றதற்கான விரிவான காரணத்தை வெளியிடுகிறது.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}