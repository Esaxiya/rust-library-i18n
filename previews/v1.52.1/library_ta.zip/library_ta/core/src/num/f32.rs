//! `f32` ஒற்றை துல்லியமான மிதக்கும் புள்ளி வகைக்கு குறிப்பிட்ட மாறிலிகள்.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! `consts` துணை தொகுதியில் கணித ரீதியாக குறிப்பிடத்தக்க எண்கள் வழங்கப்படுகின்றன.
//!
//! இந்த தொகுதியில் நேரடியாக வரையறுக்கப்பட்ட மாறிலிகளுக்கு (`consts` துணை-தொகுதியில் வரையறுக்கப்பட்டவற்றிலிருந்து வேறுபட்டது), புதிய குறியீடு அதற்கு பதிலாக `f32` வகையில் நேரடியாக வரையறுக்கப்பட்ட தொடர்புடைய மாறிலிகளைப் பயன்படுத்த வேண்டும்.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f32` இன் உள் பிரதிநிதித்துவத்தின் ரேடிக்ஸ் அல்லது அடிப்படை.
/// அதற்கு பதிலாக [`f32::RADIX`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // நோக்கம் கொண்ட வழி
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// அடிப்படை 2 இல் குறிப்பிடத்தக்க இலக்கங்களின் எண்ணிக்கை.
/// அதற்கு பதிலாக [`f32::MANTISSA_DIGITS`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // நோக்கம் கொண்ட வழி
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// அடிப்படை 10 இல் குறிப்பிடத்தக்க இலக்கங்களின் தோராயமான எண்ணிக்கை.
/// அதற்கு பதிலாக [`f32::DIGITS`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // நோக்கம் கொண்ட வழி
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] `f32` க்கான மதிப்பு.
/// அதற்கு பதிலாக [`f32::EPSILON`] ஐப் பயன்படுத்தவும்.
///
/// இது `1.0` க்கும் அடுத்த பெரிய பிரதிநிதித்துவ எண்ணிற்கும் உள்ள வித்தியாசம்.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // நோக்கம் கொண்ட வழி
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// மிகச்சிறிய வரையறுக்கப்பட்ட `f32` மதிப்பு.
/// அதற்கு பதிலாக [`f32::MIN`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // நோக்கம் கொண்ட வழி
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// சிறிய நேர்மறை சாதாரண `f32` மதிப்பு.
/// அதற்கு பதிலாக [`f32::MIN_POSITIVE`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // நோக்கம் கொண்ட வழி
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// மிகப்பெரிய வரையறுக்கப்பட்ட `f32` மதிப்பு.
/// அதற்கு பதிலாக [`f32::MAX`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // நோக்கம் கொண்ட வழி
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// 2 அடுக்கு குறைந்தபட்ச இயல்பான சக்தியை விட பெரியது.
/// அதற்கு பதிலாக [`f32::MIN_EXP`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // நோக்கம் கொண்ட வழி
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// 2 அடுக்கு அதிகபட்ச சக்தி.
/// அதற்கு பதிலாக [`f32::MAX_EXP`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // நோக்கம் கொண்ட வழி
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// 10 அடுக்கு குறைந்தபட்ச சாத்தியமான சாதாரண சக்தி.
/// அதற்கு பதிலாக [`f32::MIN_10_EXP`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // நோக்கம் கொண்ட வழி
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// 10 அடுக்கு அதிகபட்ச சக்தி.
/// அதற்கு பதிலாக [`f32::MAX_10_EXP`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // நோக்கம் கொண்ட வழி
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// எண் (NaN) அல்ல.
/// அதற்கு பதிலாக [`f32::NAN`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // நோக்கம் கொண்ட வழி
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// முடிவிலி (∞).
/// அதற்கு பதிலாக [`f32::INFINITY`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // நோக்கம் கொண்ட வழி
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// எதிர்மறை முடிவிலி (−∞).
/// அதற்கு பதிலாக [`f32::NEG_INFINITY`] ஐப் பயன்படுத்தவும்.
///
/// # Examples
///
/// ```rust
/// // நீக்கப்பட்ட வழி
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // நோக்கம் கொண்ட வழி
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// அடிப்படை கணித மாறிலிகள்.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath இலிருந்து கணித மாறிலிகளுடன் மாற்றவும்.

    /// ஆர்க்கிமிடிஸின் நிலையான (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// முழு வட்ட மாறிலி (τ)
    ///
    /// 2π க்கு சமம்.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// யூலரின் எண் (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// `f32` இன் உள் பிரதிநிதித்துவத்தின் ரேடிக்ஸ் அல்லது அடிப்படை.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// அடிப்படை 2 இல் குறிப்பிடத்தக்க இலக்கங்களின் எண்ணிக்கை.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// அடிப்படை 10 இல் குறிப்பிடத்தக்க இலக்கங்களின் தோராயமான எண்ணிக்கை.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] `f32` க்கான மதிப்பு.
    ///
    /// இது `1.0` க்கும் அடுத்த பெரிய பிரதிநிதித்துவ எண்ணிற்கும் உள்ள வித்தியாசம்.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// மிகச்சிறிய வரையறுக்கப்பட்ட `f32` மதிப்பு.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// சிறிய நேர்மறை சாதாரண `f32` மதிப்பு.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// மிகப்பெரிய வரையறுக்கப்பட்ட `f32` மதிப்பு.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// 2 அடுக்கு குறைந்தபட்ச இயல்பான சக்தியை விட பெரியது.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// 2 அடுக்கு அதிகபட்ச சக்தி.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// 10 அடுக்கு குறைந்தபட்ச சாத்தியமான சாதாரண சக்தி.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// 10 அடுக்கு அதிகபட்ச சக்தி.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// எண் (NaN) அல்ல.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// முடிவிலி (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// எதிர்மறை முடிவிலி (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// இந்த மதிப்பு `NaN` ஆக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): பெயர்வுத்திறன் குறித்த கவலைகள் காரணமாக `abs` பொதுவில் லிப்கோரில் கிடைக்காது, எனவே இந்த செயல்படுத்தல் உள்நாட்டில் தனியார் பயன்பாட்டிற்காக உள்ளது.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// இந்த மதிப்பு நேர்மறை முடிவிலி அல்லது எதிர்மறை முடிவிலி என்றால் `true` ஐ வழங்குகிறது, இல்லையெனில் `false`.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// இந்த எண் எல்லையற்றதாகவோ அல்லது `NaN` ஆகவோ இல்லாவிட்டால் `true` ஐ வழங்குகிறது.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN ஐ தனித்தனியாக கையாள வேண்டிய அவசியமில்லை: சுயமானது NaN என்றால், ஒப்பீடு உண்மை இல்லை, விரும்பியபடி.
        //
        self.abs_private() < Self::INFINITY
    }

    /// எண் [subnormal] ஆக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // `0` மற்றும் `min` க்கு இடையிலான மதிப்புகள் அசாதாரணமானது.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// எண் பூஜ்ஜியம், எல்லையற்றது, [subnormal] அல்லது `NaN` இல்லை எனில் `true` ஐ வழங்குகிறது.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // `0` மற்றும் `min` க்கு இடையிலான மதிப்புகள் அசாதாரணமானது.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// எண்ணின் மிதக்கும் புள்ளி வகையை வழங்குகிறது.
    /// ஒரே ஒரு சொத்து மட்டுமே சோதிக்கப் போகிறது என்றால், அதற்கு பதிலாக குறிப்பிட்ட முன்கணிப்பைப் பயன்படுத்துவது பொதுவாக வேகமானது.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// `self` ஆனது `+0.0` உட்பட நேர்மறையான அடையாளத்தைக் கொண்டிருந்தால் `true` ஐ வழங்குகிறது, நேர்மறை அடையாளம் பிட் மற்றும் நேர்மறை முடிவிலி கொண்ட `NaN` கள்.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// `self` க்கு எதிர்மறை அடையாளம் இருந்தால், `-0.0`, எதிர்மறை அடையாளம் பிட் மற்றும் எதிர்மறை முடிவிலி கொண்ட `NaN` கள் இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 கூறுகிறது: x எதிர்மறை அடையாளம் இருந்தால் மட்டுமே isSignMinus(x) உண்மை.
        // isSignMinus பூஜ்ஜியங்களுக்கும் NaN களுக்கும் பொருந்தும்.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// ஒரு எண்ணின் பரஸ்பர (inverse) ஐ எடுக்கிறது, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// ரேடியன்களை டிகிரிக்கு மாற்றுகிறது.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // சிறந்த துல்லியத்திற்கு ஒரு மாறிலியைப் பயன்படுத்தவும்.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// டிகிரிகளை ரேடியன்களாக மாற்றுகிறது.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// இரண்டு எண்களின் அதிகபட்சத்தை வழங்குகிறது.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// வாதங்களில் ஒன்று NaN என்றால், மற்ற வாதம் திரும்பும்.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// இரண்டு எண்களின் குறைந்தபட்சத்தை வழங்குகிறது.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// வாதங்களில் ஒன்று NaN என்றால், மற்ற வாதம் திரும்பும்.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// பூஜ்ஜியத்தை நோக்கிச் சென்று எந்த பழமையான முழு எண் வகையிலும் மாறுகிறது, மதிப்பு வரையறுக்கப்பட்டதாகவும் அந்த வகைக்கு பொருந்துகிறது என்றும் கருதுகிறது.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// மதிப்பு அவசியம்:
    ///
    /// * `NaN` ஆக இருக்கக்கூடாது
    /// * எல்லையற்றதாக இருக்கக்கூடாது
    /// * அதன் பகுதியளவு பகுதியைக் குறைத்தபின், திரும்ப வகை `Int` இல் பிரதிநிதித்துவப்படுத்துங்கள்
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // பாதுகாப்பு: அழைப்பாளர் `FloatToInt::to_int_unchecked` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u32` க்கு மூல உருமாற்றம்.
    ///
    /// இது தற்போது எல்லா தளங்களிலும் `transmute::<f32, u32>(self)` க்கு ஒத்ததாக இருக்கிறது.
    ///
    /// இந்த செயல்பாட்டின் பெயர்வுத்திறன் குறித்த சில விவாதங்களுக்கு `from_bits` ஐப் பார்க்கவும் (கிட்டத்தட்ட சிக்கல்கள் எதுவும் இல்லை).
    ///
    /// இந்த செயல்பாடு `as` வார்ப்பிலிருந்து வேறுபட்டது என்பதை நினைவில் கொள்க, இது *எண்* மதிப்பைப் பாதுகாக்க முயற்சிக்கிறது, பிட்வைஸ் மதிப்பு அல்ல.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() நடிப்பதில்லை!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // பாதுகாப்பு: `u32` என்பது ஒரு பழைய பழைய தரவு வகை, எனவே நாம் எப்போதும் அதற்கு மாற்றலாம்
        unsafe { mem::transmute(self) }
    }

    /// `u32` இலிருந்து மூல உருமாற்றம்.
    ///
    /// இது தற்போது எல்லா தளங்களிலும் `transmute::<u32, f32>(v)` க்கு ஒத்ததாக இருக்கிறது.
    /// இது இரண்டு காரணங்களுக்காக, நம்பமுடியாத அளவிற்கு சிறியது என்று மாறிவிடும்:
    ///
    /// * அனைத்து ஆதரவு தளங்களிலும் மிதவைகள் மற்றும் இன்ட்கள் ஒரே மாதிரியான தன்மையைக் கொண்டுள்ளன.
    /// * IEEE-754 மிதவைகளின் பிட் தளவமைப்பை மிகத் துல்லியமாகக் குறிப்பிடுகிறது.
    ///
    /// இருப்பினும் ஒரு எச்சரிக்கை உள்ளது: IEEE-754 இன் 2008 பதிப்பிற்கு முன்பு, NaN சிக்னலிங் பிட்டை எவ்வாறு விளக்குவது என்பது உண்மையில் குறிப்பிடப்படவில்லை.
    /// பெரும்பாலான தளங்கள் (குறிப்பாக x86 மற்றும் ARM) 2008 இல் தரப்படுத்தப்பட்ட விளக்கத்தைத் தேர்ந்தெடுத்தன, ஆனால் சில (குறிப்பாக MIPS) செய்யவில்லை.
    /// இதன் விளைவாக, MIPS இல் உள்ள அனைத்து சமிக்ஞை NaN களும் x86 இல் அமைதியான NaN கள், மற்றும் நேர்மாறாகவும் உள்ளன.
    ///
    /// சிக்னலிங்-நெஸ் குறுக்கு-தளத்தை பாதுகாக்க முயற்சிப்பதை விட, இந்த செயல்படுத்தல் சரியான பிட்களைப் பாதுகாக்க உதவுகிறது.
    /// இதன் பொருள், இந்த முறையின் விளைவாக பிணையத்தில் ஒரு x86 இயந்திரத்திலிருந்து MIPS ஒன்றுக்கு அனுப்பப்பட்டாலும் NaN களில் குறியிடப்பட்ட எந்த பேலோடுகளும் பாதுகாக்கப்படும்.
    ///
    ///
    /// இந்த முறையின் முடிவுகள் அவற்றை உருவாக்கிய அதே கட்டமைப்பால் மட்டுமே கையாளப்பட்டால், பெயர்வுத்திறன் கவலை இல்லை.
    ///
    /// உள்ளீடு NaN இல்லையென்றால், பெயர்வுத்திறன் கவலை இல்லை.
    ///
    /// சமிக்ஞை பற்றி நீங்கள் கவலைப்படாவிட்டால் (மிகவும் சாத்தியம்), பின்னர் பெயர்வுத்திறன் கவலை இல்லை.
    ///
    /// இந்த செயல்பாடு `as` வார்ப்பிலிருந்து வேறுபட்டது என்பதை நினைவில் கொள்க, இது *எண்* மதிப்பைப் பாதுகாக்க முயற்சிக்கிறது, பிட்வைஸ் மதிப்பு அல்ல.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // பாதுகாப்பு: `u32` என்பது ஒரு பழைய பழைய தரவு வகை, எனவே நாம் எப்போதும் அதிலிருந்து மாறலாம்
        // SNaN உடனான பாதுகாப்பு சிக்கல்கள் மிக மோசமாக இருந்தன என்று அது மாறிவிடும்!ஹூரே!
        unsafe { mem::transmute(v) }
    }

    /// பெரிய-எண்டியன் (network) பைட் வரிசையில் இந்த மிதக்கும் புள்ளி எண்ணின் நினைவக பிரதிநிதித்துவத்தை பைட் வரிசையாகத் திருப்புக.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// இந்த மிதக்கும் புள்ளி எண்ணின் நினைவக பிரதிநிதித்துவத்தை சிறிய-எண்டியன் பைட் வரிசையில் பைட் வரிசையாகத் திருப்புக.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// இந்த மிதக்கும் புள்ளி எண்ணின் நினைவக பிரதிநிதித்துவத்தை சொந்த பைட் வரிசையில் ஒரு பைட் வரிசையாக வழங்கவும்.
    ///
    /// இலக்கு தளத்தின் சொந்த முடிவு பயன்படுத்தப்படுவதால், சிறிய குறியீடு அதற்கு பதிலாக [`to_be_bytes`] அல்லது [`to_le_bytes`] ஐப் பயன்படுத்த வேண்டும்.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// இந்த மிதக்கும் புள்ளி எண்ணின் நினைவக பிரதிநிதித்துவத்தை சொந்த பைட் வரிசையில் ஒரு பைட் வரிசையாக வழங்கவும்.
    ///
    ///
    /// [`to_ne_bytes`] முடிந்த போதெல்லாம் இதை விட முன்னுரிமை அளிக்கப்பட வேண்டும்.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // பாதுகாப்பு: `f32` என்பது ஒரு பழைய பழைய தரவு வகை, எனவே நாம் எப்போதும் அதற்கு மாற்றலாம்
        unsafe { &*(self as *const Self as *const _) }
    }

    /// பெரிய எண்டியனில் பைட் வரிசையாக அதன் பிரதிநிதித்துவத்திலிருந்து மிதக்கும் புள்ளி மதிப்பை உருவாக்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// சிறிய எண்டியனில் பைட் வரிசையாக அதன் பிரதிநிதித்துவத்திலிருந்து ஒரு மிதக்கும் புள்ளி மதிப்பை உருவாக்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// சொந்த எண்டியனில் ஒரு பைட் வரிசையாக அதன் பிரதிநிதித்துவத்திலிருந்து ஒரு மிதக்கும் புள்ளி மதிப்பை உருவாக்கவும்.
    ///
    /// இலக்கு தளத்தின் சொந்த முடிவு பயன்படுத்தப்படுவதால், சிறிய குறியீடு [`from_be_bytes`] அல்லது [`from_le_bytes`] ஐப் பயன்படுத்த விரும்புகிறது.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// சுய மற்றும் பிற மதிப்புகளுக்கு இடையில் ஒரு வரிசையை வழங்குகிறது.
    /// மிதக்கும் புள்ளி எண்களுக்கு இடையிலான நிலையான பகுதி ஒப்பீடு போலல்லாமல், இந்த ஒப்பீடு எப்போதும் IEEE 754 (2008 திருத்தம்) மிதக்கும் புள்ளி தரத்தில் வரையறுக்கப்பட்டுள்ளபடி மொத்த ஆர்டர் முன்கணிப்புக்கு ஏற்ப ஒரு வரிசையை உருவாக்குகிறது.
    /// மதிப்புகள் பின்வரும் வரிசையில் வரிசைப்படுத்தப்பட்டுள்ளன:
    /// - எதிர்மறை அமைதியான NaN
    /// - எதிர்மறை சமிக்ஞை NaN
    /// - எதிர்மறை முடிவிலி
    /// - எதிர்மறை எண்கள்
    /// - எதிர்மறை அசாதாரண எண்கள்
    /// - எதிர்மறை பூஜ்ஜியம்
    /// - நேர்மறை பூஜ்ஜியம்
    /// - நேர்மறை அசாதாரண எண்கள்
    /// - நேர்மறை எண்கள்
    /// - நேர்மறை முடிவிலி
    /// - நேர்மறை சமிக்ஞை NaN
    /// - நேர்மறை அமைதியான NaN
    ///
    /// இந்த செயல்பாடு எப்போதும் `f32` இன் [`PartialOrd`] மற்றும் [`PartialEq`] செயலாக்கங்களுடன் உடன்படாது என்பதை நினைவில் கொள்க.குறிப்பாக, அவை எதிர்மறை மற்றும் நேர்மறை பூஜ்ஜியத்தை சமமாகக் கருதுகின்றன, அதே நேரத்தில் `total_cmp` இல்லை.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // எதிர்மறைகளில், இருவரின் நிரப்பு எண்களாக ஒத்த அமைப்பை அடைய அடையாளம் தவிர அனைத்து பிட்களையும் புரட்டவும்
        //
        // இது ஏன் வேலை செய்கிறது?IEEE 754 மிதவைகள் மூன்று புலங்களைக் கொண்டுள்ளன:
        // பிட், அடுக்கு மற்றும் மன்டிசாவை அடையாளம் காணவும்.ஒட்டுமொத்தமாக அடுக்கு மற்றும் மன்டிசா புலங்களின் தொகுப்பு, அவற்றின் பிட்வைஸ் வரிசை அளவு வரையறுக்கப்பட்டுள்ள எண் அளவிற்கு சமமாக இருக்கும் என்ற சொத்தைக் கொண்டுள்ளது.
        // அளவு பொதுவாக NaN மதிப்புகளில் வரையறுக்கப்படவில்லை, ஆனால் IEEE 754 totalOrder NaN மதிப்புகளை பிட்வைஸ் வரிசையைப் பின்பற்றவும் வரையறுக்கிறது.இது ஆவண கருத்தில் விளக்கப்பட்ட ஒழுங்கிற்கு வழிவகுக்கிறது.
        // இருப்பினும், அளவின் பிரதிநிதித்துவம் எதிர்மறை மற்றும் நேர்மறை எண்களுக்கு ஒரே மாதிரியானது-அடையாளம் பிட் மட்டுமே வேறுபட்டது.
        // கையொப்பமிடப்பட்ட முழு எண்ணாக மிதவைகளை எளிதில் ஒப்பிட்டுப் பார்க்க, எதிர்மறை எண்களின் விஷயத்தில் நாம் அடுக்கு மற்றும் மன்டிசா பிட்களை புரட்ட வேண்டும்.
        // எண்களை "two's complement" வடிவத்திற்கு திறம்பட மாற்றுகிறோம்.
        //
        // புரட்டுவதைச் செய்ய, அதற்கு எதிராக ஒரு முகமூடியையும் XOR ஐயும் உருவாக்குகிறோம்.
        // எதிர்மறை கையொப்பமிடப்பட்ட மதிப்புகளிலிருந்து ஒரு "all-ones except for the sign bit" முகமூடியை நாங்கள் கிளை இல்லாமல் கணக்கிடுகிறோம்: வலதுபுறம் மாற்றுவது முழு எண்ணை நீட்டிக்கிறது, எனவே நாம் குறியீட்டு பிட்களுடன் முகமூடியை "fill" செய்கிறோம், பின்னர் கையொப்பமிடாததாக மாற்றுகிறோம்.
        //
        // நேர்மறையான மதிப்புகளில், முகமூடி அனைத்தும் பூஜ்ஜியங்களாகும், எனவே இது ஒரு விருப்பம் இல்லை.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// ஒரு மதிப்பை ஒரு குறிப்பிட்ட இடைவெளியில் NaN ஆகக் கட்டுப்படுத்துங்கள்.
    ///
    /// `self` `max` ஐ விட அதிகமாக இருந்தால் `max` ஐயும், `self` `min` ஐ விட குறைவாக இருந்தால் `min` ஐ வழங்குகிறது.
    /// இல்லையெனில் இது `self` ஐ வழங்குகிறது.
    ///
    /// ஆரம்ப மதிப்பு NaN ஆக இருந்தால் இந்த செயல்பாடு NaN ஐ வழங்குகிறது என்பதை நினைவில் கொள்க.
    ///
    /// # Panics
    ///
    /// `min > max`, `min` NaN அல்லது `max` NaN எனில் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}