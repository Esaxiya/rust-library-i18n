//! நேர்மறை IEEE 754 மிதவைகளில் பிட் ஃபிட்லிங்.எதிர்மறை எண்கள் இல்லை மற்றும் கையாள தேவையில்லை.
//! இயல்பான மிதக்கும் புள்ளி எண்கள் (frac, exp) என ஒரு நியமன பிரதிநிதித்துவத்தைக் கொண்டுள்ளன, அதாவது மதிப்பு 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), N என்பது பிட்களின் எண்ணிக்கை.
//!
//! அசாதாரணங்கள் சற்று வித்தியாசமாகவும் வித்தியாசமாகவும் இருக்கின்றன, ஆனால் அதே கொள்கை பொருந்தும்.
//!
//! எவ்வாறாயினும், இங்கே நாம் அவற்றை f நேர்மறையுடன் (sig, k) பிரதிநிதித்துவப்படுத்துகிறோம், அதாவது மதிப்பு f *
//! 2 <sup>இ</sup> ."hidden bit" ஐ வெளிப்படையாக வெளியிடுவதைத் தவிர, இது மான்டிசா ஷிப்ட் என்று அழைக்கப்படுவதன் மூலம் அடுக்கை மாற்றுகிறது.
//!
//! மற்றொரு வழியைக் கூறுங்கள், பொதுவாக மிதவைகள் (1) என எழுதப்படுகின்றன, ஆனால் இங்கே அவை (2) என எழுதப்படுகின்றன:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! நாங்கள் (1) ஐ **பகுதியளவு பிரதிநிதித்துவம்** மற்றும் (2) ஐ **ஒருங்கிணைந்த பிரதிநிதித்துவம்** என்று அழைக்கிறோம்.
//!
//! இந்த தொகுதியில் உள்ள பல செயல்பாடுகள் சாதாரண எண்களை மட்டுமே கையாளுகின்றன.Dec2flt நடைமுறைகள் பழமைவாதமாக மிகச் சிறிய மற்றும் மிகப் பெரிய எண்ணிக்கையில் உலகளவில் சரியான மெதுவான பாதையை (அல்காரிதம் எம்) எடுத்துக்கொள்கின்றன.
//! அந்த வழிமுறைக்கு next_float() மட்டுமே தேவைப்படுகிறது, இது அசாதாரண மற்றும் பூஜ்ஜியங்களைக் கையாளும்.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` மற்றும் `f64` க்கான அனைத்து மாற்றுக் குறியீட்டையும் அடிப்படையில் நகலெடுப்பதைத் தவிர்க்க ஒரு உதவியாளர் trait.
///
/// இது ஏன் அவசியம் என்பதற்கு பெற்றோர் தொகுதியின் ஆவணக் கருத்தைப் பார்க்கவும்.
///
/// **ஒருபோதும்** மற்ற வகைகளுக்கு செயல்படுத்தப்பட வேண்டுமா அல்லது dec2flt தொகுதிக்கு வெளியே பயன்படுத்தப்பட வேண்டுமா.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` மற்றும் `from_bits` ஆல் பயன்படுத்தப்படும் வகை.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// ஒரு முழு எண்ணுக்கு மூல உருமாற்றம் செய்கிறது.
    fn to_bits(self) -> Self::Bits;

    /// ஒரு முழு எண்ணிலிருந்து மூல உருமாற்றம் செய்கிறது.
    fn from_bits(v: Self::Bits) -> Self;

    /// இந்த எண் அடங்கும் வகையை வழங்குகிறது.
    fn classify(self) -> FpCategory;

    /// மன்டிசா, அடுக்கு மற்றும் முழு எண்ணாக கையொப்பமிடுகிறது.
    fn integer_decode(self) -> (u64, i16, i8);

    /// மிதவை டிகோட் செய்கிறது.
    fn unpack(self) -> Unpacked;

    /// சரியாகக் குறிப்பிடக்கூடிய சிறிய முழு எண்ணிலிருந்து காஸ்ட்கள்.
    /// Panic முழு எண்ணைக் குறிப்பிட முடியாவிட்டால், இந்த தொகுதியில் உள்ள மற்ற குறியீடு ஒருபோதும் நடக்கக்கூடாது என்பதை உறுதி செய்கிறது.
    fn from_int(x: u64) -> Self;

    /// முன் கணக்கிடப்பட்ட அட்டவணையிலிருந்து 10 <sup>இ</sup> மதிப்பைப் பெறுகிறது.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` க்கான Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// பெயர் என்ன சொல்கிறது.
    /// உள்ளார்ந்தவற்றைக் கையாள்வதை விட கடின குறியீட்டை எளிதாக்குவது மற்றும் எல்.எல்.வி.எம் மாறிலி அதை மடிப்பதாக நம்புகிறது.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // வழிதல் அல்லது பூஜ்ஜியத்தை உருவாக்க முடியாத உள்ளீடுகளின் தசம இலக்கங்களில் ஒரு பழமைவாத பிணைப்பு
    /// subnormals.அநேகமாக அதிகபட்ச இயல்பான மதிப்பின் தசம அடுக்கு, எனவே பெயர்.
    const MAX_NORMAL_DIGITS: usize;

    /// மிக முக்கியமான தசம இலக்கத்தை விட அதிகமான இட மதிப்பு இருக்கும்போது, அந்த எண்ணிக்கை நிச்சயமாக முடிவிலிக்கு வட்டமானது.
    ///
    const INF_CUTOFF: i64;

    /// மிக முக்கியமான தசம இலக்கத்திற்கு இட மதிப்பு குறைவாக இருக்கும்போது, அந்த எண்ணிக்கை நிச்சயமாக பூஜ்ஜியமாக வட்டமிடப்படுகிறது.
    ///
    const ZERO_CUTOFF: i64;

    /// அடுக்கு பிட்களின் எண்ணிக்கை.
    const EXP_BITS: u8;

    /// மறைக்கப்பட்ட பிட் உட்பட * முக்கியத்துவத்தில் உள்ள பிட்களின் எண்ணிக்கை.
    const SIG_BITS: u8;

    /// மறைக்கப்பட்ட பிட்டைத் தவிர்த்து * முக்கியத்துவத்தில் உள்ள பிட்களின் எண்ணிக்கை.
    const EXPLICIT_SIG_BITS: u8;

    /// பகுதியளவு பிரதிநிதித்துவத்தில் அதிகபட்ச சட்ட அடுக்கு.
    const MAX_EXP: i16;

    /// பகுதியளவு பிரதிநிதித்துவத்தில் குறைந்தபட்ச சட்ட அடுக்கு, துணை இயல்புகளைத் தவிர.
    const MIN_EXP: i16;

    /// `MAX_EXP` ஒருங்கிணைந்த பிரதிநிதித்துவத்திற்கு, அதாவது, மாற்றத்துடன்.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` குறியாக்கம் செய்யப்பட்டுள்ளது (அதாவது, ஆஃப்செட் சார்புடன்)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` ஒருங்கிணைந்த பிரதிநிதித்துவத்திற்கு, அதாவது, மாற்றத்துடன்.
    const MIN_EXP_INT: i16;

    /// ஒருங்கிணைந்த பிரதிநிதித்துவத்தில் அதிகபட்ச இயல்பாக்கப்பட்ட முக்கியத்துவம்.
    const MAX_SIG: u64;

    /// ஒருங்கிணைந்த பிரதிநிதித்துவத்தில் குறைந்தபட்ச இயல்பாக்கப்பட்ட முக்கியத்துவம்.
    const MIN_SIG: u64;
}

// பெரும்பாலும் #34344 க்கான ஒரு தீர்வு.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// மன்டிசா, அடுக்கு மற்றும் முழு எண்ணாக கையொப்பமிடுகிறது.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // அடுக்கு சார்பு + மன்டிசா மாற்றம்
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // அனைத்து தளங்களிலும் `as` சரியாகச் சுற்றுமா என்பது rkruppe நிச்சயமற்றது.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// மன்டிசா, அடுக்கு மற்றும் முழு எண்ணாக கையொப்பமிடுகிறது.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // அடுக்கு சார்பு + மன்டிசா மாற்றம்
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // அனைத்து தளங்களிலும் `as` சரியாகச் சுற்றுமா என்பது rkruppe நிச்சயமற்றது.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// ஒரு `Fp` ஐ மிக நெருக்கமான இயந்திர மிதவை வகையாக மாற்றுகிறது.
/// அசாதாரண முடிவுகளைக் கையாளாது.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 பிட் ஆகும், எனவே xe ஆனது 63 இன் மன்டிசா மாற்றத்தைக் கொண்டுள்ளது
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64-பிட் முக்கியத்துவத்தை T::SIG_BITS பிட்களுக்கு அரை-க்கு-சமமாக வட்டமிடுங்கள்.
/// அடுக்கு வழிதல் கையாளாது.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // மன்டிசா மாற்றத்தை சரிசெய்யவும்
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// இயல்பாக்கப்பட்ட எண்களுக்கு `RawFloat::unpack()` இன் தலைகீழ்.
/// இயல்பாக்கப்பட்ட எண்களுக்கு முக்கியத்துவம் அல்லது அடுக்கு செல்லுபடியாகாவிட்டால் Panics.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // மறைக்கப்பட்ட பிட்டை அகற்று
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // அடுக்கு சார்பு மற்றும் மன்டிசா மாற்றத்திற்கான அடுக்கு சரிசெய்யவும்
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+") இல் அடையாளம் பிட்டை விடுங்கள், எங்கள் எண்கள் அனைத்தும் நேர்மறையானவை
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ஒரு அசாதாரணத்தை உருவாக்குங்கள்.0 இன் மன்டிசா அனுமதிக்கப்படுகிறது மற்றும் பூஜ்ஜியத்தை உருவாக்குகிறது.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // குறியாக்கப்பட்ட அடுக்கு 0, அடையாளம் பிட் 0, எனவே நாம் பிட்களை மறுபரிசீலனை செய்ய வேண்டும்.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ஒரு Fp உடன் ஒரு பிக்னத்தை தோராயமாக மதிப்பிடுங்கள்.0.5 ULP க்குள் அரை முதல் சமமாக இருக்கும் சுற்றுகள்.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // குறியீட்டு `start` க்கு முன்னர் அனைத்து பிட்களையும் துண்டித்துவிட்டோம், அதாவது, `start` அளவு மூலம் திறம்பட வலதுபுறமாக மாற்றுவோம், எனவே இது நமக்குத் தேவையான அடுக்கு ஆகும்.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // துண்டிக்கப்பட்ட பிட்களைப் பொறுத்து சுற்று (half-to-even).
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// மிகப்பெரிய மிதக்கும் புள்ளி எண்ணை வாதத்தை விட கண்டிப்பாக சிறியதாகக் காண்கிறது.
/// சப்நார்மல்கள், பூஜ்ஜியம் அல்லது அடுக்கு வழிதல் ஆகியவற்றைக் கையாளாது.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// வாதத்தை விட கண்டிப்பாக பெரிய சிறிய மிதக்கும் புள்ளி எண்ணைக் கண்டறியவும்.
// இந்த செயல்பாடு நிறைவுற்றது, அதாவது, next_float(inf) ==inf.
// இந்த தொகுதியில் உள்ள பெரும்பாலான குறியீடுகளைப் போலன்றி, இந்த செயல்பாடு பூஜ்ஜியம், அசாதாரணங்கள் மற்றும் முடிவிலிகளைக் கையாளுகிறது.
// இருப்பினும், இங்குள்ள மற்ற எல்லா குறியீடுகளையும் போலவே, இது NaN மற்றும் எதிர்மறை எண்களைக் கையாள்வதில்லை.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // இது உண்மையாக இருப்பது மிகவும் நல்லது என்று தோன்றுகிறது, ஆனால் அது செயல்படுகிறது.
        // 0.0 அனைத்து பூஜ்ஜிய வார்த்தையாக குறியிடப்பட்டுள்ளது.அசாதாரணமானவை 0x000 மீ ... மீ எங்கே எம் என்பது மன்டிஸா.
        // குறிப்பாக, மிகச்சிறிய சப்நார்மல் 0x0 ... 01 மற்றும் மிகப்பெரியது 0x000F ... F.
        // மிகச்சிறிய சாதாரண எண் 0x0010 ... 0, எனவே இந்த மூலையில் உள்ள வழக்கும் செயல்படுகிறது.
        // அதிகரிப்பு மன்டிசாவை நிரம்பி வழிகிறது என்றால், கேரி பிட் நாம் விரும்பியபடி அடுக்கு அதிகரிக்கிறது, மேலும் மன்டிசா பிட்கள் பூஜ்ஜியமாகின்றன.
        // மறைக்கப்பட்ட பிட் மாநாட்டின் காரணமாக, இதுவும் நாம் விரும்புவதுதான்!
        // இறுதியாக, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}