//! பிக்னம்களுக்கான பயன்பாட்டு செயல்பாடுகள் முறைகளாக மாறுவதற்கு அதிக அர்த்தம் இல்லை.

// சரி இந்த தொகுதியின் பெயர் சற்று துரதிர்ஷ்டவசமானது, ஏனென்றால் மற்ற தொகுதிகள் `core::num` ஐ இறக்குமதி செய்கின்றன.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place` ஐ விட குறைவான முக்கியத்துவம் வாய்ந்த அனைத்து பிட்களையும் துண்டிப்பது ஒரு தொடர்புடைய பிழையை 0.5 ULP ஐ விட குறைவாகவோ, சமமாகவோ அல்லது அதிகமாகவோ அறிமுகப்படுத்துகிறதா என்பதை சோதிக்கவும்.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // மீதமுள்ள அனைத்து பிட்களும் பூஜ்ஜியமாக இருந்தால், அது= 0.5 ULP, இல்லையெனில்> 0.5 அதிக பிட்கள் இல்லாவிட்டால் (அரை_பிட்==0), கீழேயுள்ளவையும் சரியாக சமத்தை அளிக்கிறது.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// தசம இலக்கங்களை மட்டுமே கொண்ட ASCII சரத்தை `u64` ஆக மாற்றுகிறது.
///
/// வழிதல் அல்லது தவறான எழுத்துக்களுக்கான காசோலைகளைச் செய்யாது, எனவே அழைப்பவர் கவனமாக இல்லாவிட்டால், இதன் விளைவாக போலியானது மற்றும் panic (இது `unsafe` ஆக இருக்காது).
/// கூடுதலாக, வெற்று சரங்கள் பூஜ்ஜியமாக கருதப்படுகின்றன.
/// ஏனெனில் இந்த செயல்பாடு உள்ளது
///
/// 1. `&[u8]` இல் `FromStr` ஐப் பயன்படுத்துவதற்கு `from_utf8_unchecked` தேவைப்படுகிறது, இது மோசமானது, மற்றும்
/// 2. `integral.parse()` மற்றும் `fractional.parse()` இன் முடிவுகளை ஒன்றாக இணைப்பது இந்த முழு செயல்பாட்டை விட மிகவும் சிக்கலானது.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII இலக்கங்களின் சரத்தை ஒரு பிக்னமாக மாற்றுகிறது.
///
/// `from_str_unchecked` ஐப் போலவே, இந்த செயல்பாடும் இலக்கங்கள் அல்லாதவற்றை களைய பாகுபடுத்தியை நம்பியுள்ளது.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// ஒரு பிக்னத்தை 64 பிட் முழு எண்ணாக அவிழ்த்து விடுகிறது.எண் மிகப் பெரியதாக இருந்தால் Panics.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// பிட்களின் வரம்பைப் பிரித்தெடுக்கிறது.

/// குறியீட்டு 0 மிகக் குறைவான குறிப்பிடத்தக்க பிட் மற்றும் வழக்கம் போல் வரம்பு அரை திறந்திருக்கும்.
/// திரும்பும் வகைக்கு பொருந்துவதை விட அதிகமான பிட்களைப் பிரித்தெடுக்கும்படி கேட்டால் Panics.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}