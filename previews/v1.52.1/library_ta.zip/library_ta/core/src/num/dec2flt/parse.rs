//! படிவத்தின் தசம சரத்தை சரிபார்த்தல் மற்றும் சிதைத்தல்:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! வேறு வார்த்தைகளில் கூறுவதானால், நிலையான மிதவை-புள்ளி தொடரியல், இரண்டு விதிவிலக்குகளுடன்: எந்த அடையாளமும் இல்லை, மற்றும் "inf" மற்றும் "NaN" ஐக் கையாளுதல் இல்லை.இவை இயக்கி செயல்பாடு (super::dec2flt) ஆல் கையாளப்படுகின்றன.
//!
//! செல்லுபடியாகும் உள்ளீடுகளை அங்கீகரிப்பது ஒப்பீட்டளவில் எளிதானது என்றாலும், இந்த தொகுதி எண்ணற்ற தவறான மாறுபாடுகளை நிராகரிக்க வேண்டும், ஒருபோதும் panic, மற்றும் பிற தொகுதிகள் panic (அல்லது வழிதல்) அல்ல என்பதை நம்பியிருக்கும் பல சோதனைகளை செய்ய வேண்டும்.
//!
//! விஷயங்களை மோசமாக்க, உள்ளீட்டின் மீது ஒரே பாஸில் நடக்கும் அனைத்தும்.
//! எனவே, எதையும் மாற்றும்போது கவனமாக இருங்கள், மற்ற தொகுதிகளுடன் இருமுறை சரிபார்க்கவும்.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// தசம சரத்தின் சுவாரஸ்யமான பகுதிகள்.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// தசம அடுக்கு, 18 க்கும் குறைவான தசம இலக்கங்களைக் கொண்டிருப்பதாக உத்தரவாதம்.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// உள்ளீட்டு சரம் செல்லுபடியாகும் மிதக்கும் புள்ளி எண்ணாக இருந்தால் சரிபார்க்கிறது, அப்படியானால், ஒருங்கிணைந்த பகுதி, பகுதியளவு மற்றும் அதிலுள்ள அடுக்கு ஆகியவற்றைக் கண்டறியவும்.
/// அறிகுறிகளைக் கையாளவில்லை.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' க்கு முன் இலக்கங்கள் இல்லை
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // புள்ளிக்கு முன்னும் பின்னும் எங்களுக்கு குறைந்தபட்சம் ஒரு இலக்கமாவது தேவைப்படுகிறது.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // பின் பகுதிக்குப் பிறகு குப்பைகளைப் பின்தொடர்வது
            }
        }
        _ => Invalid, // முதல் இலக்க சரத்திற்குப் பிறகு குப்பைகளைப் பின்தொடர்வது
    }
}

/// முதல் இலக்கமற்ற எழுத்து வரை தசம இலக்கங்களை செதுக்குகிறது.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// அடுக்கு பிரித்தெடுத்தல் மற்றும் பிழை சோதனை.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // அடுக்குக்குப் பின் குப்பைகளைப் பின்தொடர்வது
    }
    if number.is_empty() {
        return Invalid; // வெற்று அடுக்கு
    }
    // இந்த கட்டத்தில், எங்களிடம் நிச்சயமாக சரியான இலக்கங்கள் உள்ளன.இது ஒரு `i64` இல் வைக்க மிக நீண்டதாக இருக்கலாம், ஆனால் அது மிகப்பெரியதாக இருந்தால், உள்ளீடு நிச்சயமாக பூஜ்ஜியம் அல்லது முடிவிலி ஆகும்.
    // தசம இலக்கங்களில் உள்ள ஒவ்வொரு பூஜ்ஜியமும் அதிவேகத்தை +/-1 ஆல் மட்டுமே சரிசெய்கிறது என்பதால், exp=10 ^ 18 இல் உள்ளீடு 17 எக்ஸாபைட் (!) பூஜ்ஜியங்களாக இருக்க வேண்டும்.
    //
    // இது நாம் பூர்த்தி செய்ய வேண்டிய ஒரு பயன்பாட்டு வழக்கு அல்ல.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}