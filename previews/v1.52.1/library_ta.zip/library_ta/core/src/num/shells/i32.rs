//! 32-பிட் கையொப்பமிடப்பட்ட முழு எண் வகைக்கான மாறிலிகள்.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! புதிய குறியீடு தொடர்புடைய மாறிலிகளை நேரடியாக பழமையான வகைகளில் பயன்படுத்த வேண்டும்.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }