//! சுட்டிக்காட்டி அளவிலான கையொப்பமிடப்படாத முழு எண் வகைக்கான மாறிலிகள்.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! புதிய குறியீடு தொடர்புடைய மாறிலிகளை நேரடியாக பழமையான வகைகளில் பயன்படுத்த வேண்டும்.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }