use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// *வாரிசு* மற்றும் *முன்னோடி* செயல்பாடுகள் பற்றிய கருத்தைக் கொண்ட பொருள்கள்.
///
/// *வாரிசு* செயல்பாடு அதிகமாக ஒப்பிடும் மதிப்புகளை நோக்கி நகர்கிறது.
/// *முன்னோடி* செயல்பாடு குறைவாக ஒப்பிடும் மதிப்புகளை நோக்கி நகர்கிறது.
///
/// # Safety
///
/// இந்த trait `unsafe` ஆகும், ஏனெனில் இது `unsafe trait TrustedLen` செயலாக்கங்களின் பாதுகாப்பிற்காக சரியாக இருக்க வேண்டும், மேலும் இந்த trait ஐப் பயன்படுத்துவதன் முடிவுகள் `unsafe` குறியீட்டால் நம்பப்படலாம், மேலும் அவை சரியானவை மற்றும் பட்டியலிடப்பட்ட கடமைகளை நிறைவேற்றும்.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start` இலிருந்து `end` க்குத் தேவையான *வாரிசு* படிகளின் எண்ணிக்கையை வழங்குகிறது.
    ///
    /// படிகளின் எண்ணிக்கை `usize` ஐ நிரம்பி வழிகிறது என்றால் `None` ஐ வழங்குகிறது (அல்லது எல்லையற்றது, அல்லது `end` ஒருபோதும் அடையப்படாவிட்டால்).
    ///
    ///
    /// # Invariants
    ///
    /// எந்த `a`, `b` மற்றும் `n` க்கும்:
    ///
    /// * `steps_between(&a, &b) == Some(n)` என்றால் மற்றும் `Step::forward_checked(&a, n) == Some(b)` என்றால் மட்டுமே
    /// * `steps_between(&a, &b) == Some(n)` என்றால் மற்றும் `Step::backward_checked(&a, n) == Some(a)` என்றால் மட்டுமே
    /// * `steps_between(&a, &b) == Some(n)` `a <= b` என்றால் மட்டுமே
    ///   * இணை: `steps_between(&a, &b) == Some(0)` என்றால் மற்றும் `a == b` என்றால் மட்டுமே
    ///   * `a <= b` என்பது _not_ என்பது `steps_between(&a, &b) != None` ஐ குறிக்கிறது என்பதை நினைவில் கொள்க;
    ///     `b` ஐப் பெறுவதற்கு `usize::MAX` க்கும் மேற்பட்ட படிகள் தேவைப்படும் போது இதுதான்
    /// * `steps_between(&a, &b) == None` `a > b` என்றால்
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// `self` `count` முறைகளின் *வாரிசை* எடுத்துக்கொள்வதன் மூலம் பெறப்படும் மதிப்பை வழங்குகிறது.
    ///
    /// இது `Self` ஆல் ஆதரிக்கப்படும் மதிப்புகளின் வரம்பை நிரம்பி வழிகிறது என்றால், `None` ஐ வழங்குகிறது.
    ///
    /// # Invariants
    ///
    /// எந்த `a`, `n` மற்றும் `m` க்கும்:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// `n + m` நிரம்பி வழியும் எந்த `a`, `n` மற்றும் `m` க்கும்:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// எந்த `a` மற்றும் `n` க்கும்:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` முறைகளின் *வாரிசை* எடுத்துக்கொள்வதன் மூலம் பெறப்படும் மதிப்பை வழங்குகிறது.
    ///
    /// இது `Self` ஆல் ஆதரிக்கப்படும் மதிப்புகளின் வரம்பை நிரம்பி வழிகிறது என்றால், இந்த செயல்பாடு panic, மடக்கு அல்லது நிறைவுற்றதாக அனுமதிக்கப்படுகிறது.
    ///
    /// பிழைத்திருத்த வலியுறுத்தல்கள் இயக்கப்பட்டிருக்கும்போது panic க்கு பரிந்துரைக்கப்பட்ட நடத்தை, இல்லையெனில் மடக்கு அல்லது நிறைவு.
    ///
    /// பாதுகாப்பற்ற குறியீடு நிரம்பி வழியும் பிறகு நடத்தையின் சரியான தன்மையை நம்பக்கூடாது.
    ///
    /// # Invariants
    ///
    /// எந்தவொரு `a`, `n` மற்றும் `m` க்கும், வழிதல் எதுவும் நிகழாது:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// எந்த `a` மற்றும் `n` க்கும், எந்த வழிதல் ஏற்படாது:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// `self` `count` முறைகளின் *வாரிசை* எடுத்துக்கொள்வதன் மூலம் பெறப்படும் மதிப்பை வழங்குகிறது.
    ///
    /// # Safety
    ///
    /// `Self` ஆல் ஆதரிக்கப்படும் மதிப்புகளின் வரம்பை இந்த செயல்பாடு செயல்படுத்துவது வரையறுக்கப்படாத நடத்தை.
    /// இது நிரம்பி வழியாது என்று உங்களால் உத்தரவாதம் அளிக்க முடியாவிட்டால், அதற்கு பதிலாக `forward` அல்லது `forward_checked` ஐப் பயன்படுத்தவும்.
    ///
    /// # Invariants
    ///
    /// எந்த `a` க்கும்:
    ///
    /// * `b > a` போன்ற `b` இருந்தால், `Step::forward_unchecked(a, 1)` ஐ அழைப்பது பாதுகாப்பானது
    /// * `steps_between(&a, &b) == Some(n)` போன்ற `b`, `n` இருந்தால், எந்த `m <= n` க்கும் `Step::forward_unchecked(a, m)` ஐ அழைப்பது பாதுகாப்பானது.
    ///
    ///
    /// எந்த `a` மற்றும் `n` க்கும், எந்த வழிதல் ஏற்படாது:
    ///
    /// * `Step::forward_unchecked(a, n)` இது `Step::forward(a, n)` க்கு சமம்
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// `self` `count` முறைகளின் *முன்னோடி* ஐ எடுத்து பெறப்படும் மதிப்பை வழங்குகிறது.
    ///
    /// இது `Self` ஆல் ஆதரிக்கப்படும் மதிப்புகளின் வரம்பை நிரம்பி வழிகிறது என்றால், `None` ஐ வழங்குகிறது.
    ///
    /// # Invariants
    ///
    /// எந்த `a`, `n` மற்றும் `m` க்கும்:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// எந்த `a` மற்றும் `n` க்கும்:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` முறைகளின் *முன்னோடி* ஐ எடுத்து பெறப்படும் மதிப்பை வழங்குகிறது.
    ///
    /// இது `Self` ஆல் ஆதரிக்கப்படும் மதிப்புகளின் வரம்பை நிரம்பி வழிகிறது என்றால், இந்த செயல்பாடு panic, மடக்கு அல்லது நிறைவுற்றதாக அனுமதிக்கப்படுகிறது.
    ///
    /// பிழைத்திருத்த வலியுறுத்தல்கள் இயக்கப்பட்டிருக்கும்போது panic க்கு பரிந்துரைக்கப்பட்ட நடத்தை, இல்லையெனில் மடக்கு அல்லது நிறைவு.
    ///
    /// பாதுகாப்பற்ற குறியீடு நிரம்பி வழியும் பிறகு நடத்தையின் சரியான தன்மையை நம்பக்கூடாது.
    ///
    /// # Invariants
    ///
    /// எந்தவொரு `a`, `n` மற்றும் `m` க்கும், வழிதல் எதுவும் நிகழாது:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// எந்த `a` மற்றும் `n` க்கும், எந்த வழிதல் ஏற்படாது:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// `self` `count` முறைகளின் *முன்னோடி* ஐ எடுத்து பெறப்படும் மதிப்பை வழங்குகிறது.
    ///
    /// # Safety
    ///
    /// `Self` ஆல் ஆதரிக்கப்படும் மதிப்புகளின் வரம்பை இந்த செயல்பாடு செயல்படுத்துவது வரையறுக்கப்படாத நடத்தை.
    /// இது நிரம்பி வழியாது என்று உங்களால் உத்தரவாதம் அளிக்க முடியாவிட்டால், அதற்கு பதிலாக `backward` அல்லது `backward_checked` ஐப் பயன்படுத்தவும்.
    ///
    /// # Invariants
    ///
    /// எந்த `a` க்கும்:
    ///
    /// * `b < a` போன்ற `b` இருந்தால், `Step::backward_unchecked(a, 1)` ஐ அழைப்பது பாதுகாப்பானது
    /// * `steps_between(&b, &a) == Some(n)` போன்ற `b`, `n` இருந்தால், எந்த `m <= n` க்கும் `Step::backward_unchecked(a, m)` ஐ அழைப்பது பாதுகாப்பானது.
    ///
    ///
    /// எந்த `a` மற்றும் `n` க்கும், எந்த வழிதல் ஏற்படாது:
    ///
    /// * `Step::backward_unchecked(a, n)` இது `Step::backward(a, n)` க்கு சமம்
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// இவை இன்னும் மேக்ரோ-உருவாக்கப்பட்டவை, ஏனெனில் முழு எண் எழுத்தர்கள் வெவ்வேறு வகைகளுக்குத் தீர்க்கிறார்கள்.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // பாதுகாப்பு: அழைப்பாளர் `start + n` நிரம்பி வழிவதில்லை என்று உத்தரவாதம் அளிக்க வேண்டும்.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // பாதுகாப்பு: அழைப்பாளர் `start - n` நிரம்பி வழிவதில்லை என்று உத்தரவாதம் அளிக்க வேண்டும்.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // பிழைத்திருத்த உருவாக்கங்களில், வழிதல் மீது panic ஐத் தூண்டவும்.
            // வெளியீட்டு கட்டமைப்பில் இது முற்றிலும் மேம்படுத்தப்பட வேண்டும்.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // எ.கா. அனுமதிக்க கணிதத்தை மடக்குங்கள் `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // பிழைத்திருத்த உருவாக்கங்களில், வழிதல் மீது panic ஐத் தூண்டவும்.
            // வெளியீட்டு கட்டமைப்பில் இது முற்றிலும் மேம்படுத்தப்பட வேண்டும்.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // எ.கா. அனுமதிக்க கணிதத்தை மடக்குங்கள் `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // இது $u_narrower <=usize ஐ நம்பியுள்ளது
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // n வரம்பிற்கு வெளியே இருந்தால், `unsigned_start + n` கூட
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // n வரம்பிற்கு வெளியே இருந்தால், `unsigned_start - n` கூட
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // இது $i_narrower <=usize ஐ நம்பியுள்ளது
                        //
                        // ஐசைஸுக்கு வார்ப்பது அகலத்தை நீட்டிக்கிறது, ஆனால் அடையாளத்தை பாதுகாக்கிறது.
                        // ஐசைஸ் ஸ்பேஸில் மடக்குதல்_சப்பைப் பயன்படுத்தவும், ஐசைஸ் வரம்பிற்குள் பொருந்தாத வேறுபாட்டைக் கணக்கிட பயன்படுத்தவும்.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // i8 க்கு 200 வரம்பில்லாமல் இருந்தாலும், `Step::forward(-120_i8, 200) == Some(80_i8)` போன்ற வழக்குகளை மடக்குதல் கையாளுகிறது.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // கூட்டல் நிரம்பி வழிகிறது
                            }
                        }
                        // N எ.கா. வரம்பிற்கு வெளியே இருந்தால்
                        // u8, i8 இன் முழு வரம்பையும் விட இது பெரியது, எனவே `any_i8 + n` அவசியம் i8 ஐ நிரம்பி வழிகிறது.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // i8 க்கு 200 வரம்பில்லாமல் இருந்தாலும், `Step::forward(-120_i8, 200) == Some(80_i8)` போன்ற வழக்குகளை மடக்குதல் கையாளுகிறது.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // கழித்தல் நிரம்பி வழிகிறது
                            }
                        }
                        // N எ.கா. வரம்பிற்கு வெளியே இருந்தால்
                        // u8, i8 இன் முழு வரம்பையும் விட இது பெரியது, எனவே `any_i8 - n` அவசியம் i8 ஐ நிரம்பி வழிகிறது.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // வேறுபாடு எ.கா.க்கு மிகப் பெரியதாக இருந்தால்
                            // i128, இது குறைவான பிட்களைப் பயன்படுத்துவதற்கு மிகப் பெரியதாக இருக்கும்.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // பாதுகாப்பு: ரெஸ் என்பது சரியான யூனிகோட் அளவிடுதல் ஆகும்
            // (0x110000 க்கு கீழே மற்றும் 0xD800..0xE000 இல் இல்லை)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // பாதுகாப்பு: ரெஸ் என்பது சரியான யூனிகோட் அளவிடுதல் ஆகும்
        // (0x110000 க்கு கீழே மற்றும் 0xD800..0xE000 இல் இல்லை)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // பாதுகாப்பு: அழைப்பாளர் இது நிரம்பி வழியாது என்று உத்தரவாதம் அளிக்க வேண்டும்
        // ஒரு எரிப்பிற்கான மதிப்புகளின் வரம்பு.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // பாதுகாப்பு: அழைப்பாளர் இது நிரம்பி வழியாது என்று உத்தரவாதம் அளிக்க வேண்டும்
            // ஒரு எரிப்பிற்கான மதிப்புகளின் வரம்பு.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // பாதுகாப்பு: முந்தைய ஒப்பந்தத்தின் காரணமாக, இது உத்தரவாதம்
        // அழைப்பாளரால் செல்லுபடியாகும் கரி.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // பாதுகாப்பு: அழைப்பாளர் இது நிரம்பி வழியாது என்று உத்தரவாதம் அளிக்க வேண்டும்
        // ஒரு எரிப்பிற்கான மதிப்புகளின் வரம்பு.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // பாதுகாப்பு: அழைப்பாளர் இது நிரம்பி வழியாது என்று உத்தரவாதம் அளிக்க வேண்டும்
            // ஒரு எரிப்பிற்கான மதிப்புகளின் வரம்பு.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // பாதுகாப்பு: முந்தைய ஒப்பந்தத்தின் காரணமாக, இது உத்தரவாதம்
        // அழைப்பாளரால் செல்லுபடியாகும் கரி.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // பாதுகாப்பு: முன் நிபந்தனை சரிபார்க்கப்பட்டது
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // பாதுகாப்பு: முன் நிபந்தனை சரிபார்க்கப்பட்டது
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// இந்த மேக்ரோக்கள் பல்வேறு வரம்பு வகைகளுக்கு `ExactSizeIterator` impls ஐ உருவாக்குகின்றன.
//
// * `ExactSizeIterator::len` ஒரு துல்லியமான `usize` ஐ எப்போதும் திருப்பித் தர வேண்டும், எனவே எந்த வரம்பும் `usize::MAX` ஐ விட நீண்டதாக இருக்க முடியாது.
//
// * `Range<_>` இல் உள்ள முழு வகைகளுக்கு இது `usize` ஐ விட குறுகலான அல்லது அகலமான வகைகளுக்கு பொருந்தும்.
//   `RangeInclusive<_>` இல் உள்ள முழு வகைகளுக்கு, எ.கா. முதல் `usize` ஐ விட *கண்டிப்பாக குறுகலான* வகைகளுக்கு இதுதான்
//   `(0..=u64::MAX).len()` `u64::MAX + 1` ஆக இருக்கும்.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // மேலே உள்ள பகுத்தறிவுக்கு இவை தவறானவை, ஆனால் அவை Rust 1.0.0 இல் உறுதிப்படுத்தப்பட்டதால் அவற்றை அகற்றுவது ஒரு முறிவு மாற்றமாகும்.
    // எனவே எ.கா.
    // `(0..66_000_u32).len()` எடுத்துக்காட்டாக, 16-பிட் இயங்குதளங்களில் பிழை அல்லது எச்சரிக்கைகள் இல்லாமல் தொகுக்கும், ஆனால் தொடர்ந்து தவறான முடிவைத் தரும்.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // மேலே உள்ள பகுத்தறிவுக்கு இவை தவறானவை, ஆனால் அவை Rust 1.26.0 இல் உறுதிப்படுத்தப்பட்டதால் அவற்றை அகற்றுவது ஒரு முறிவு மாற்றமாகும்.
    // எனவே எ.கா.
    // `(0..=u16::MAX).len()` எடுத்துக்காட்டாக, 16-பிட் இயங்குதளங்களில் பிழை அல்லது எச்சரிக்கைகள் இல்லாமல் தொகுக்கும், ஆனால் தொடர்ந்து தவறான முடிவைத் தரும்.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // பாதுகாப்பு: முன் நிபந்தனை சரிபார்க்கப்பட்டது
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // பாதுகாப்பு: முன் நிபந்தனை சரிபார்க்கப்பட்டது
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // பாதுகாப்பு: முன் நிபந்தனை சரிபார்க்கப்பட்டது
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // பாதுகாப்பு: முன் நிபந்தனை சரிபார்க்கப்பட்டது
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // பாதுகாப்பு: முன் நிபந்தனை சரிபார்க்கப்பட்டது
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // பாதுகாப்பு: முன் நிபந்தனை சரிபார்க்கப்பட்டது
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}