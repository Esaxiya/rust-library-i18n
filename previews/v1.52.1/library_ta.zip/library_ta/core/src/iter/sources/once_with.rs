use crate::iter::{FusedIterator, TrustedLen};

/// வழங்கப்பட்ட மூடுதலைத் தொடங்குவதன் மூலம் சோம்பேறித்தனமாக ஒரு மதிப்பை உருவாக்கும் ஒரு ஈரேட்டரை உருவாக்குகிறது.
///
/// ஒற்றை மதிப்பு ஜெனரேட்டரை [`chain()`] இல் பிற வகையான மறு செய்கைக்கு மாற்றியமைக்க இது பொதுவாகப் பயன்படுத்தப்படுகிறது.
/// ஏறக்குறைய எல்லாவற்றையும் உள்ளடக்கிய ஒரு ஈரேட்டர் உங்களிடம் இருக்கலாம், ஆனால் உங்களுக்கு கூடுதல் சிறப்பு வழக்கு தேவை.
/// ஐரேட்டர்களில் செயல்படும் ஒரு செயல்பாடு உங்களிடம் இருக்கலாம், ஆனால் நீங்கள் ஒரு மதிப்பை மட்டுமே செயலாக்க வேண்டும்.
///
/// [`once()`] போலல்லாமல், இந்த செயல்பாடு கோரிக்கையின் அடிப்படையில் சோம்பேறியை உருவாக்கும்.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// use std::iter;
///
/// // ஒன்று தனிமையான எண்
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ஒன்று, நாம் பெறுவது அவ்வளவுதான்
/// assert_eq!(None, one.next());
/// ```
///
/// மற்றொரு ஈரேட்டருடன் சேர்ந்து சங்கிலி.
/// `.foo` கோப்பகத்தின் ஒவ்வொரு கோப்பையும் மீண்டும் இயக்க விரும்புகிறோம், ஆனால் ஒரு கட்டமைப்பு கோப்பு,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // DirEntry-s இன் மறு செய்கையிலிருந்து பாத்பஃப்ஸின் ஒரு செயலியாக மாற்ற வேண்டும், எனவே நாங்கள் வரைபடத்தைப் பயன்படுத்துகிறோம்
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // இப்போது, எங்கள் உள்ளமைவு கோப்பிற்கான எங்கள் செயலி
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // இரண்டு ஈரேட்டர்களையும் ஒன்றாக ஒரு பெரிய ஈரேட்டராக இணைக்கவும்
/// let files = dirs.chain(config);
///
/// // இது .foo மற்றும் .foorc இல் உள்ள எல்லா கோப்புகளையும் எங்களுக்கு வழங்கும்
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// வழங்கப்பட்ட மூடல் `F: FnOnce() -> A` ஐப் பயன்படுத்துவதன் மூலம் `A` வகை ஒற்றை உறுப்பைக் கொடுக்கும் ஒரு ஈரேட்டர்.
///
///
/// இந்த `struct` [`once_with()`] செயல்பாட்டால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}