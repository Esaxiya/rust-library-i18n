use crate::fmt;

/// ஒவ்வொரு மறு செய்கையும் வழங்கப்பட்ட மூடல் `F: FnMut() -> Option<T>` ஐ அழைக்கும் புதிய மறு செய்கையை உருவாக்குகிறது.
///
/// இது ஒரு பிரத்யேக வகையை உருவாக்கி அதற்கான [`Iterator`] trait ஐ செயல்படுத்துவதற்கான அதிக சொற்களஞ்சிய வாக்கிய அமைப்பைப் பயன்படுத்தாமல் எந்தவொரு நடத்தையுடனும் தனிப்பயன் ஈரேட்டரை உருவாக்க அனுமதிக்கிறது.
///
/// `FromFn` ஐரேட்டர் மூடலின் நடத்தை பற்றி அனுமானங்களைச் செய்யாது, எனவே பழமைவாதமாக [`FusedIterator`] ஐ செயல்படுத்தாது, அல்லது [`Iterator::size_hint()`] ஐ அதன் இயல்புநிலை `(0, None)` இலிருந்து மேலெழுதும்.
///
///
/// மூடல் கைப்பற்றல்களையும் அதன் சூழலையும் மறு செய்கைகளில் நிலையை அறிய பயன்படுத்தலாம்.ஈரேட்டர் எவ்வாறு பயன்படுத்தப்படுகிறது என்பதைப் பொறுத்து, இதற்கு மூடுதலில் [`move`] முக்கிய சொல்லைக் குறிப்பிட வேண்டியிருக்கும்.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// [module-level documentation] இலிருந்து எதிர் செயலியை மீண்டும் செயல்படுத்தலாம்:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // எங்கள் எண்ணிக்கையை அதிகரிக்கவும்.இதனால்தான் நாங்கள் பூஜ்ஜியத்தில் தொடங்கினோம்.
///     count += 1;
///
///     // நாங்கள் எண்ணுவதை முடித்திருக்கிறோமா இல்லையா என்பதைப் பார்க்கவும்.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// ஒவ்வொரு மறு செய்கையும் வழங்கப்பட்ட மூடல் `F: FnMut() -> Option<T>` என்று அழைக்கும் ஒரு மறு செய்கை.
///
/// இந்த `struct` [`iter::from_fn()`] செயல்பாட்டால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}