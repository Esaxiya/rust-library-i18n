use crate::{fmt, iter::FusedIterator};

/// ஒரு புதிய ஐரேட்டரை உருவாக்குகிறது, அங்கு ஒவ்வொரு அடுத்தடுத்த உருப்படியும் முந்தையதை அடிப்படையாகக் கொண்டு கணக்கிடப்படுகிறது.
///
/// ஈரேட்டர் கொடுக்கப்பட்ட முதல் உருப்படியுடன் (ஏதேனும் இருந்தால்) தொடங்குகிறது மற்றும் ஒவ்வொரு உருப்படியின் வாரிசையும் கணக்கிட கொடுக்கப்பட்ட `FnMut(&T) -> Option<T>` மூடுதலை அழைக்கிறது.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // இந்த செயல்பாடு `impl Iterator<Item=T>` ஐத் திருப்பினால், அது `unfold` ஐ அடிப்படையாகக் கொண்டிருக்கலாம் மற்றும் பிரத்யேக வகை தேவையில்லை.
    //
    // இருப்பினும் பெயரிடப்பட்ட `Successors<T, F>` வகையை வைத்திருப்பது `T` மற்றும் `F` இருக்கும்போது `Clone` ஆக அனுமதிக்கிறது.
    Successors { next: first, succ }
}

/// ஒவ்வொரு புதிய உருப்படியும் முந்தையதை அடிப்படையாகக் கொண்டு கணக்கிடப்படும் புதிய மறு செய்கை.
///
/// இந்த `struct` [`iter::successors()`] செயல்பாட்டால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}