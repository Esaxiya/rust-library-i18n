use crate::iter::{FusedIterator, TrustedLen};

/// ஒரு உறுப்பை முடிவில்லாமல் மீண்டும் செய்யும் புதிய ஈரேட்டரை உருவாக்குகிறது.
///
/// `repeat()` செயல்பாடு ஒரு மதிப்பை மீண்டும் மீண்டும் செய்கிறது.
///
/// `repeat()` போன்ற எல்லையற்ற மறு செய்கைகள் பெரும்பாலும் [`Iterator::take()`] போன்ற அடாப்டர்களுடன் பயன்படுத்தப்படுகின்றன, அவை வரையறுக்கப்பட்டவை.
///
/// உங்களுக்கு தேவையான ஈரேட்டரின் உறுப்பு வகை `Clone` ஐ செயல்படுத்தவில்லை என்றால், அல்லது மீண்டும் மீண்டும் உறுப்பை நினைவகத்தில் வைக்க விரும்பவில்லை என்றால், அதற்கு பதிலாக நீங்கள் [`repeat_with()`] செயல்பாட்டைப் பயன்படுத்தலாம்.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// use std::iter;
///
/// // எண் 4 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // ஆமாம், இன்னும் நான்கு
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] உடன் வரையறுக்கப்பட்டவை:
///
/// ```
/// use std::iter;
///
/// // அந்த கடைசி உதாரணம் பல பவுண்டரிகள்.நான்கு பவுண்டரிகள் மட்டுமே இருப்போம்.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... இப்போது நாங்கள் முடித்துவிட்டோம்
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// ஒரு உறுப்பை முடிவில்லாமல் மீண்டும் செய்யும் ஒரு செயலி.
///
/// இந்த `struct` [`repeat()`] செயல்பாட்டால் உருவாக்கப்பட்டது.மேலும் அதன் ஆவணங்களைக் காண்க.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}