use crate::iter::{FusedIterator, TrustedLen};

/// வழங்கப்பட்ட மூடல், ரிப்பீட்டரைப் பயன்படுத்துவதன் மூலம் `A` வகை கூறுகளை முடிவில்லாமல் மீண்டும் செய்யும் புதிய ஈரேட்டரை உருவாக்குகிறது. `F: FnMut() -> A`.
///
/// `repeat_with()` செயல்பாடு ரிப்பீட்டரை மீண்டும் மீண்டும் அழைக்கிறது.
///
/// `repeat_with()` போன்ற எல்லையற்ற மறு செய்கைகள் பெரும்பாலும் [`Iterator::take()`] போன்ற அடாப்டர்களுடன் பயன்படுத்தப்படுகின்றன, அவை வரையறுக்கப்பட்டவை.
///
/// உங்களுக்கு தேவைப்படும் ஐரேட்டரின் உறுப்பு வகை [`Clone`] ஐ செயல்படுத்துகிறது, மேலும் மூல உறுப்பை நினைவகத்தில் வைத்திருப்பது சரி என்றால், அதற்கு பதிலாக நீங்கள் [`repeat()`] செயல்பாட்டைப் பயன்படுத்த வேண்டும்.
///
///
/// `repeat_with()` ஆல் தயாரிக்கப்படும் ஒரு ஈரேட்டர் ஒரு [`DoubleEndedIterator`] அல்ல.
/// [`DoubleEndedIterator`] ஐ திருப்பித் தர உங்களுக்கு `repeat_with()` தேவைப்பட்டால், உங்கள் பயன்பாட்டு வழக்கை விளக்கும் கிட்ஹப் சிக்கலைத் திறக்கவும்.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// use std::iter;
///
/// // `Clone` இல்லாத அல்லது இன்னும் நினைவகத்தில் இருக்க விரும்பாத ஒரு வகையின் சில மதிப்பு நம்மிடம் உள்ளது என்று வைத்துக் கொள்வோம், ஏனெனில் அது விலை உயர்ந்தது:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // ஒரு குறிப்பிட்ட மதிப்பு எப்போதும்:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// பிறழ்வைப் பயன்படுத்துதல் மற்றும் வரையறுக்கப்பட்டவை:
///
/// ```rust
/// use std::iter;
///
/// // பூஜ்ஜியத்திலிருந்து இரண்டின் மூன்றாவது சக்தி வரை:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... இப்போது நாங்கள் முடித்துவிட்டோம்
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// வழங்கப்பட்ட மூடல் `F: FnMut() -> A` ஐப் பயன்படுத்துவதன் மூலம் `A` வகை கூறுகளை முடிவில்லாமல் மீண்டும் செய்யும் ஒரு ஈரேட்டர்.
///
///
/// இந்த `struct` [`repeat_with()`] செயல்பாட்டால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}