use crate::{iter::FusedIterator, ops::Try};

/// முடிவில்லாமல் திரும்பத் திரும்பச் சொல்லும் ஒரு செயலி.
///
/// இந்த `struct` [`Iterator`] இல் [`cycle`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // சுழற்சி மறு செய்கை வெற்று அல்லது எல்லையற்றது
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // தற்போதைய ஈரேட்டரை முழுமையாக மீண்டும் இயக்கவும்.
        // இது அவசியம், ஏனென்றால் `self.orig` இல்லாதபோது கூட `self.iter` காலியாக இருக்கலாம்
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // முழு சுழற்சியை நிறைவுசெய்து, சுழற்சியின் மறு செய்கை காலியாக இருக்கிறதா இல்லையா என்பதைக் கண்காணிக்கும்.
        // எல்லையற்ற சுழற்சியைத் தடுக்க வெற்று மறு செய்கை செய்தால் நாம் ஆரம்பத்தில் திரும்ப வேண்டும்
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // `fold` மேலெழுதும் இல்லை, ஏனென்றால் `fold` க்கு `Cycle` க்கு அதிக அர்த்தம் இல்லை, மேலும் இயல்புநிலையை விட எதையும் சிறப்பாக செய்ய முடியாது.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}