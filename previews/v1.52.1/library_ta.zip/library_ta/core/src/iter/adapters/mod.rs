use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// இந்த trait நிபந்தனைகளின் கீழ் ஒரு இன்டரேட்டர்-அடாப்டர் பைப்லைனில் மூல-நிலைக்கு இடைநிலை அணுகலை வழங்குகிறது
/// * ஈரேட்டர் மூல `S` தானே `SourceIter<Source = S>` ஐ செயல்படுத்துகிறது
/// * மூலத்திற்கும் பைப்லைன் நுகர்வோருக்கும் இடையில் குழாய்த்திட்டத்தில் ஒவ்வொரு அடாப்டருக்கும் இந்த trait ஐ பிரதிநிதித்துவப்படுத்தும் செயல்படுத்தல் உள்ளது.
///
/// மூலமானது சொந்தமான ஐரேட்டர் ஸ்ட்ரக்டாக இருக்கும்போது (பொதுவாக `IntoIter` என அழைக்கப்படுகிறது) பின்னர் இது [`FromIterator`] செயலாக்கங்களை சிறப்புப்படுத்த அல்லது ஒரு ஈரேட்டர் ஓரளவு தீர்ந்துவிட்ட பிறகு மீதமுள்ள கூறுகளை மீட்டெடுக்க பயனுள்ளதாக இருக்கும்.
///
///
/// செயலாக்கங்கள் ஒரு குழாய்வழியின் உள்-மிக மூலத்தை அணுக வேண்டிய அவசியமில்லை என்பதை நினைவில் கொள்க.ஒரு மாநில இடைநிலை அடாப்டர் குழாய்த்திட்டத்தின் ஒரு பகுதியை ஆவலுடன் மதிப்பீடு செய்து அதன் உள் சேமிப்பை ஆதாரமாக அம்பலப்படுத்தக்கூடும்.
///
/// trait பாதுகாப்பற்றது, ஏனெனில் செயல்படுத்துபவர்கள் கூடுதல் பாதுகாப்பு பண்புகளை நிலைநிறுத்த வேண்டும்.
/// விவரங்களுக்கு [`as_inner`] ஐப் பார்க்கவும்.
///
/// # Examples
///
/// ஓரளவு நுகரப்படும் மூலத்தை மீட்டெடுக்கிறது:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// ஒரு ஈரேட்டர் பைப்லைனில் ஒரு மூல நிலை.
    type Source: Iterator;

    /// ஒரு ஈரேட்டர் பைப்லைனின் மூலத்தை மீட்டெடுக்கவும்.
    ///
    /// # Safety
    ///
    /// அழைப்பாளரால் மாற்றப்படாவிட்டால், அவற்றின் வாழ்நாளில் அதே மாற்றத்தக்க குறிப்பை செயல்படுத்த வேண்டும்.
    /// அழைப்பாளர்கள் மறுதொடக்கத்தை நிறுத்தும்போது மட்டுமே குறிப்பை மாற்றலாம் மற்றும் மூலத்தைப் பிரித்தெடுத்த பிறகு ஈரேட்டர் பைப்லைனை கைவிடலாம்.
    ///
    /// இதன் பொருள், மறு செய்கை அடாப்டர்கள் மறு செய்கையின் போது மாறாத மூலத்தை நம்பலாம், ஆனால் அவற்றின் டிராப் செயலாக்கங்களில் அவர்கள் அதை நம்ப முடியாது.
    ///
    /// இந்த முறையைச் செயல்படுத்துவதால், அடாப்டர்கள் அவற்றின் மூலத்திற்கான தனிப்பட்ட அணுகலை மட்டுமே கைவிடுவதோடு, முறை பெறுதல் வகைகளின் அடிப்படையில் வழங்கப்படும் உத்தரவாதங்களை மட்டுமே நம்ப முடியும்.
    /// தடைசெய்யப்பட்ட அணுகல் இல்லாததால், அடாப்டர்கள் மூலத்தின் பொது API ஐ அதன் உள் அணுகலைக் கொண்டிருக்கும்போது கூட அவற்றை நிலைநிறுத்த வேண்டும்.
    ///
    /// அதற்கும் மூலத்திற்கும் இடையில் அமர்ந்திருக்கும் அடாப்டர்களுக்கு ஒரே அணுகல் இருப்பதால், அதன் பொது API உடன் ஒத்துப்போகும் எந்த நிலையிலும் மூலத்தை அழைப்பாளர்கள் எதிர்பார்க்க வேண்டும்.
    /// குறிப்பாக ஒரு அடாப்டர் கண்டிப்பாக தேவையானதை விட அதிகமான கூறுகளை உட்கொண்டிருக்கலாம்.
    ///
    /// இந்த தேவைகளின் ஒட்டுமொத்த குறிக்கோள் ஒரு குழாய் பயன்பாட்டை நுகர்வோர் அனுமதிப்பதாகும்
    /// * மறு செய்கை நிறுத்தப்பட்ட பிறகு மூலத்தில் எஞ்சியிருப்பது
    /// * நுகர்வு ஈரேட்டரை முன்னேற்றுவதன் மூலம் பயன்படுத்தப்படாத நினைவகம்
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// அடிப்படை ஈரேட்டர் `Result::Ok` மதிப்புகளை உருவாக்கும் வரை வெளியீட்டை உருவாக்கும் ஒரு ஈரேட்டர் அடாப்டர்.
///
///
/// பிழை ஏற்பட்டால், ஈரேட்டர் நிறுத்தப்பட்டு பிழை சேமிக்கப்படும்.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// கொடுக்கப்பட்ட ஐரேட்டரை ஒரு `Result<T, _>` க்கு பதிலாக `T` ஐ வழங்கியது போல் செயலாக்கவும்.
/// ஏதேனும் பிழைகள் உள் செயலியை நிறுத்தும் மற்றும் ஒட்டுமொத்த முடிவு பிழையாக இருக்கும்.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}