/// ஒரு [`Iterator`] இலிருந்து மாற்றம்.
///
/// ஒரு வகைக்கு `FromIterator` ஐ செயல்படுத்துவதன் மூலம், அது எவ்வாறு ஒரு செயலிலிருந்து உருவாக்கப்படும் என்பதை வரையறுக்கிறீர்கள்.
/// சில வகையான தொகுப்பை விவரிக்கும் வகைகளுக்கு இது பொதுவானது.
///
/// [`FromIterator::from_iter()`] இது அரிதாகவே வெளிப்படையாக அழைக்கப்படுகிறது, அதற்கு பதிலாக [`Iterator::collect()`] முறை மூலம் பயன்படுத்தப்படுகிறது.
///
/// மேலும் எடுத்துக்காட்டுகளுக்கு [`Iterator::collect()`]'s ஆவணங்களைக் காண்க.
///
/// மேலும் காண்க: [`IntoIterator`].
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` ஐ மறைமுகமாக பயன்படுத்த [`Iterator::collect()`] ஐப் பயன்படுத்துதல்:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// உங்கள் வகைக்கு `FromIterator` ஐ செயல்படுத்துகிறது:
///
/// ```
/// use std::iter::FromIterator;
///
/// // ஒரு மாதிரி சேகரிப்பு, அது வெக் மீது ஒரு போர்வையாகும்<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // அதற்கு சில முறைகளைத் தருவோம், இதன்மூலம் ஒன்றை உருவாக்கி அதில் விஷயங்களைச் சேர்க்கலாம்.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // நாங்கள் FromIterator ஐ செயல்படுத்துவோம்
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // இப்போது நாம் ஒரு புதிய ஈரேட்டரை உருவாக்கலாம் ...
/// let iter = (0..5).into_iter();
///
/// // ... அதிலிருந்து ஒரு MyCollection ஐ உருவாக்கவும்
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // படைப்புகளையும் சேகரிக்கவும்!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// ஒரு செயலிலிருந்து ஒரு மதிப்பை உருவாக்குகிறது.
    ///
    /// மேலும் அறிய [module-level documentation] ஐப் பார்க்கவும்.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] ஆக மாற்றுதல்.
///
/// ஒரு வகைக்கு `IntoIterator` ஐ செயல்படுத்துவதன் மூலம், அது எவ்வாறு ஒரு செயலியாக மாற்றப்படும் என்பதை வரையறுக்கிறீர்கள்.
/// சில வகையான தொகுப்பை விவரிக்கும் வகைகளுக்கு இது பொதுவானது.
///
/// `IntoIterator` ஐ செயல்படுத்துவதன் ஒரு நன்மை என்னவென்றால், உங்கள் வகை [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) ஆக இருக்கும்.
///
///
/// மேலும் காண்க: [`FromIterator`].
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// உங்கள் வகைக்கு `IntoIterator` ஐ செயல்படுத்துகிறது:
///
/// ```
/// // ஒரு மாதிரி சேகரிப்பு, அது வெக் மீது ஒரு போர்வையாகும்<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // அதற்கு சில முறைகளைத் தருவோம், இதன்மூலம் ஒன்றை உருவாக்கி அதில் விஷயங்களைச் சேர்க்கலாம்.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // நாங்கள் IntoIterator ஐ செயல்படுத்துவோம்
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // இப்போது நாம் ஒரு புதிய தொகுப்பை உருவாக்கலாம் ...
/// let mut c = MyCollection::new();
///
/// // ... அதில் சில விஷயங்களைச் சேர்க்கவும் ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... பின்னர் அதை ஒரு ஈரேட்டராக மாற்றவும்:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` ஐ trait bound ஆகப் பயன்படுத்துவது பொதுவானது.இது உள்ளீட்டு சேகரிப்பு வகையை மாற்ற அனுமதிக்கிறது, இது இன்னும் ஒரு செயலியாக இருக்கும் வரை.
/// கட்டுப்படுத்துவதன் மூலம் கூடுதல் வரம்புகளைக் குறிப்பிடலாம்
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// மீண்டும் கூறப்படும் கூறுகளின் வகை.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// இதை எந்த வகையான ஈரேட்டராக மாற்றுகிறோம்?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// ஒரு மதிப்பிலிருந்து ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// மேலும் அறிய [module-level documentation] ஐப் பார்க்கவும்.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// ஒரு செயலியின் உள்ளடக்கங்களுடன் தொகுப்பை நீட்டிக்கவும்.
///
/// மதிப்பீட்டாளர்கள் தொடர்ச்சியான மதிப்புகளை உருவாக்குகிறார்கள், மேலும் தொகுப்புகள் மதிப்புகளின் தொடராகவும் கருதப்படலாம்.
/// `Extend` trait இந்த இடைவெளியைக் குறைக்கிறது, இது அந்த ஈரேட்டரின் உள்ளடக்கங்களைச் சேர்ப்பதன் மூலம் ஒரு தொகுப்பை நீட்டிக்க அனுமதிக்கிறது.
/// ஏற்கனவே இருக்கும் விசையுடன் தொகுப்பை நீட்டிக்கும்போது, அந்த நுழைவு புதுப்பிக்கப்படுகிறது அல்லது சம விசைகளுடன் பல உள்ளீடுகளை அனுமதிக்கும் வசூல் விஷயத்தில், அந்த நுழைவு செருகப்படுகிறது.
///
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// // சில எழுத்துகளுடன் நீங்கள் ஒரு சரத்தை நீட்டலாம்:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` ஐ செயல்படுத்துகிறது:
///
/// ```
/// // ஒரு மாதிரி சேகரிப்பு, அது வெக் மீது ஒரு போர்வையாகும்<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // அதற்கு சில முறைகளைத் தருவோம், இதன்மூலம் ஒன்றை உருவாக்கி அதில் விஷயங்களைச் சேர்க்கலாம்.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection i32 களின் பட்டியலைக் கொண்டிருப்பதால், i32 க்கான விரிவாக்கத்தை செயல்படுத்துகிறோம்
/// impl Extend<i32> for MyCollection {
///
///     // கான்கிரீட் வகை கையொப்பத்துடன் இது சற்று எளிமையானது: ஐடரேட்டராக மாற்றக்கூடிய எதையும் நீட்டிக்க அழைக்கலாம், இது எங்களுக்கு i32 களை வழங்குகிறது.
///     // ஏனெனில் MyCollection இல் வைக்க i32 கள் தேவை.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // செயல்படுத்தல் மிகவும் நேரடியானது: ஈரேட்டர் வழியாக லூப், மற்றும் எக்ஸ் 100 எக்ஸ் ஒவ்வொரு உறுப்புக்கும் நமக்கு.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // எங்கள் தொகுப்பை இன்னும் மூன்று எண்களுடன் விரிவாக்குவோம்
/// c.extend(vec![1, 2, 3]);
///
/// // இந்த கூறுகளை முடிவில் சேர்த்துள்ளோம்
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// ஒரு செயலியின் உள்ளடக்கங்களுடன் தொகுப்பை விரிவுபடுத்துகிறது.
    ///
    /// இந்த trait க்கு தேவையான ஒரே முறை இது என்பதால், [trait-level] டாக்ஸில் கூடுதல் விவரங்கள் உள்ளன.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// // சில எழுத்துகளுடன் நீங்கள் ஒரு சரத்தை நீட்டலாம்:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// சரியாக ஒரு உறுப்புடன் தொகுப்பை விரிவுபடுத்துகிறது.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// கொடுக்கப்பட்ட எண்ணிக்கையிலான கூடுதல் கூறுகளுக்கான தொகுப்பில் இருப்பு திறன்.
    ///
    /// இயல்புநிலை செயல்படுத்தல் எதுவும் செய்யாது.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}