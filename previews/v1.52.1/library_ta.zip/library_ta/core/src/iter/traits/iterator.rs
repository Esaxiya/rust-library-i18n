// புறக்கணிப்பு-நேர்த்தியான-கோப்புநீளம் இந்த கோப்பு கிட்டத்தட்ட பிரத்தியேகமாக `Iterator` இன் வரையறையைக் கொண்டுள்ளது.
// அதை நாம் பல கோப்புகளாக பிரிக்க முடியாது.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// ஈரேட்டர்களைக் கையாள்வதற்கான இடைமுகம்.
///
/// இது முக்கிய மறு செய்கை trait ஆகும்.
/// பொதுவாக ஈரேட்டர்களின் கருத்து பற்றி மேலும் அறிய, தயவுசெய்து [module-level documentation] ஐப் பார்க்கவும்.
/// குறிப்பாக, நீங்கள் [implement `Iterator`][impl] ஐ எவ்வாறு தெரிந்து கொள்ள விரும்பலாம்.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// மீண்டும் கூறப்படும் கூறுகளின் வகை.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ஈரேட்டரை முன்னேற்றுகிறது மற்றும் அடுத்த மதிப்பை வழங்குகிறது.
    ///
    /// மறு செய்கை முடிந்ததும் [`None`] ஐ வழங்குகிறது.
    /// தனிப்பட்ட மறு செய்கை செயலாக்கங்கள் மறுதொடக்கத்தை மீண்டும் தொடங்கத் தேர்வுசெய்யலாம், எனவே `next()` ஐ மீண்டும் அழைப்பது அல்லது ஒரு கட்டத்தில் [`Some(Item)`] ஐத் திருப்பித் தரத் தொடங்கலாம்.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() க்கான அழைப்பு அடுத்த மதிப்பை வழங்குகிறது ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... பின்னர் அது முடிந்ததும் எதுவும் இல்லை.
    /// assert_eq!(None, iter.next());
    ///
    /// // கூடுதல் அழைப்புகள் `None` ஐ வழங்கலாம் அல்லது திரும்பப் பெறக்கூடாது.இங்கே, அவர்கள் எப்போதும் செய்வார்கள்.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// ஈரேட்டரின் மீதமுள்ள நீளத்தின் எல்லைகளை வழங்குகிறது.
    ///
    /// குறிப்பாக, `size_hint()` முதல் உறுப்பு கீழ் பிணைப்பாகவும், இரண்டாவது உறுப்பு மேல் பிணைப்பாகவும் இருக்கும் ஒரு டூப்பிளை வழங்குகிறது.
    ///
    /// திரும்பப் பெறப்படும் டூப்பிளின் இரண்டாவது பாதி ஒரு [`விருப்பம்`]`<`[`பயன்படுத்து`] `>`.
    /// இங்கே ஒரு [`None`] என்றால், அறியப்பட்ட மேல் எல்லை இல்லை, அல்லது மேல் எல்லை [`usize`] ஐ விட பெரியது.
    ///
    /// # செயல்படுத்தல் குறிப்புகள்
    ///
    /// ஒரு ஈரேட்டர் செயல்படுத்தல் அறிவிக்கப்பட்ட உறுப்புகளின் எண்ணிக்கையை அளிக்கிறது என்பது செயல்படுத்தப்படவில்லை.ஒரு தரமற்ற ஈரேட்டர் குறைந்த வரம்பை விட குறைவாகவோ அல்லது உறுப்புகளின் மேல் வரம்பை விட அதிகமாகவோ இருக்கலாம்.
    ///
    /// `size_hint()` முதன்மையாக, ஈரேட்டரின் உறுப்புகளுக்கு இடத்தை ஒதுக்குவது போன்ற மேம்படுத்தல்களுக்குப் பயன்படுத்தப்பட வேண்டும், ஆனால் எ.கா.வை நம்பக்கூடாது, பாதுகாப்பற்ற குறியீட்டில் எல்லை சரிபார்ப்புகளைத் தவிர்க்கவும்.
    /// `size_hint()` இன் தவறான செயல்படுத்தல் நினைவக பாதுகாப்பு மீறல்களுக்கு வழிவகுக்கக்கூடாது.
    ///
    /// இது செயல்படுத்தல் சரியான மதிப்பீட்டை வழங்க வேண்டும், இல்லையெனில் இது trait இன் நெறிமுறையின் மீறலாக இருக்கும்.
    ///
    /// இயல்புநிலை செயலாக்கம் `(0,` [`எதுவுமில்லை`]`)`ஐ வழங்குகிறது, இது எந்தவொரு செயலாளருக்கும் சரியானது.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// மிகவும் சிக்கலான உதாரணம்:
    ///
    /// ```
    /// // பூஜ்ஜியத்திலிருந்து பத்து வரையிலான சம எண்கள்.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // நாம் பூஜ்ஜியத்திலிருந்து பத்து மடங்கு திரும்பலாம்.
    /// // இது ஐந்து என்பதை அறிந்தால் filter() ஐ இயக்காமல் சாத்தியமில்லை.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() உடன் மேலும் ஐந்து எண்களைச் சேர்ப்போம்
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // இப்போது இரண்டு எல்லைகளும் ஐந்து அதிகரித்துள்ளன
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// மேல் எல்லைக்கு `None` ஐத் தருகிறது:
    ///
    /// ```
    /// // எல்லையற்ற மறு செய்கைக்கு மேல் எல்லை இல்லை மற்றும் அதிகபட்சமாக குறைந்த பிணைப்பு உள்ளது
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// மறு செய்கை நுகர்வு, மறு செய்கைகளின் எண்ணிக்கையை எண்ணி அதை திருப்பித் தருகிறது.
    ///
    /// இந்த முறை [`None`] ஐ [`None`] எதிர்கொள்ளும் வரை மீண்டும் மீண்டும் அழைக்கும், இது [`Some`] ஐ எத்தனை முறை பார்த்தது என்பதைத் தருகிறது.
    /// ஈரேட்டரில் எந்த உறுப்புகளும் இல்லாவிட்டாலும், ஒரு முறையாவது [`next`] ஐ அழைக்க வேண்டும் என்பதை நினைவில் கொள்க.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # வழிதல் நடத்தை
    ///
    /// இந்த வழி வழிதல் என்பதிலிருந்து பாதுகாக்காது, எனவே [`usize::MAX`] க்கும் மேற்பட்ட உறுப்புகளைக் கொண்ட ஒரு ஈரேட்டரின் கூறுகளை எண்ணுவது தவறான முடிவை அல்லது panics ஐ உருவாக்குகிறது.
    ///
    /// பிழைத்திருத்த வலியுறுத்தல்கள் இயக்கப்பட்டால், ஒரு panic உத்தரவாதம் அளிக்கப்படுகிறது.
    ///
    /// # Panics
    ///
    /// ஈரேட்டரில் [`usize::MAX`] க்கும் மேற்பட்ட கூறுகள் இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கலாம்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// கடைசி உறுப்பை திருப்பி, ஈரேட்டரை பயன்படுத்துகிறது.
    ///
    /// இந்த முறை [`None`] ஐ வழங்கும் வரை ஈரேட்டரை மதிப்பீடு செய்யும்.
    /// அவ்வாறு செய்யும்போது, அது தற்போதைய உறுப்பைக் கண்காணிக்கும்.
    /// [`None`] திரும்பிய பிறகு, `last()` பின்னர் பார்த்த கடைசி உறுப்பை வழங்கும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` உறுப்புகளால் ஈரேட்டரை மேம்படுத்துகிறது.
    ///
    /// இந்த முறை [`None`] ஐ எதிர்கொள்ளும் வரை [`next`] ஐ `n` வரை அழைப்பதன் மூலம் `n` கூறுகளை ஆர்வத்துடன் தவிர்க்கும்.
    ///
    /// `advance_by(n)` `n` உறுப்புகளால் ஈரேட்டர் வெற்றிகரமாக முன்னேறினால் [`Ok(())`][Ok] ஐ திருப்பித் தரும், அல்லது [`None`] எதிர்கொண்டால் [`Err(k)`][Err], அங்கு `k` என்பது உறுப்புகள் வெளியேறும் முன் ஈரேட்டர் முன்னேறும் உறுப்புகளின் எண்ணிக்கை (அதாவது
    /// ஈரேட்டரின் நீளம்).
    /// `k` எப்போதும் `n` ஐ விட குறைவாக இருக்கும் என்பதை நினைவில் கொள்க.
    ///
    /// `advance_by(0)` ஐ அழைப்பது எந்த உறுப்புகளையும் நுகராது, எப்போதும் [`Ok(())`][Ok] ஐ வழங்குகிறது.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` மட்டுமே தவிர்க்கப்பட்டது
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// ஈரேட்டரின் `n` வது உறுப்பை வழங்குகிறது.
    ///
    /// பெரும்பாலான குறியீட்டு செயல்பாடுகளைப் போலவே, எண்ணிக்கையும் பூஜ்ஜியத்திலிருந்து தொடங்குகிறது, எனவே `nth(0)` முதல் மதிப்பை, `nth(1)` இரண்டாவது மதிப்பை அளிக்கிறது.
    ///
    /// எல்லா முந்தைய உறுப்புகளும், திரும்பிய உறுப்புகளும், ஈரேட்டரிலிருந்து நுகரப்படும் என்பதை நினைவில் கொள்க.
    /// அதாவது முந்தைய கூறுகள் நிராகரிக்கப்படும், மேலும் ஒரே ஐரேட்டரில் `nth(0)` ஐ பல முறை அழைப்பது வெவ்வேறு கூறுகளைத் தரும்.
    ///
    ///
    /// `nth()` `n` ஐரேட்டரின் நீளத்தை விட அதிகமாகவோ அல்லது சமமாகவோ இருந்தால் [`None`] ஐ வழங்கும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` ஐ பல முறை அழைப்பது ஈரேட்டரை முன்னாடி விடாது:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1` க்கும் குறைவான கூறுகள் இருந்தால் `None` ஐத் தருகிறது:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// ஒரே கட்டத்தில் தொடங்கி ஒரு ஈரேட்டரை உருவாக்குகிறது, ஆனால் ஒவ்வொரு மறு செய்கையிலும் கொடுக்கப்பட்ட தொகையை அடியெடுத்து வைக்கிறது.
    ///
    /// குறிப்பு 1: கொடுக்கப்பட்ட படியைப் பொருட்படுத்தாமல், ஈரேட்டரின் முதல் உறுப்பு எப்போதும் திருப்பித் தரப்படும்.
    ///
    /// குறிப்பு 2: புறக்கணிக்கப்பட்ட கூறுகள் இழுக்கப்படும் நேரம் சரி செய்யப்படவில்லை.
    /// `StepBy` `next(), nth(step-1), nth(step-1),…` வரிசை போல செயல்படுகிறது, ஆனால் அந்த வரிசையைப் போல நடந்து கொள்ளவும் இலவசம்
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// செயல்திறன் காரணங்களுக்காக சில மறுபயன்பாட்டாளர்களுக்கு எந்த வழி பயன்படுத்தப்படுகிறது.
    /// இரண்டாவது வழி முந்தைய செயலியை முன்னெடுத்துச் செல்லும், மேலும் அதிகமான பொருட்களை உட்கொள்ளக்கூடும்.
    ///
    /// `advance_n_and_return_first` இதற்கு சமம்:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// கொடுக்கப்பட்ட படி `0` ஆக இருந்தால் முறை panic ஆக இருக்கும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// இரண்டு ஐரேட்டர்களை எடுத்து, இரண்டிலும் ஒரு புதிய ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// `chain()` ஒரு புதிய ஈரேட்டரைத் தரும், இது முதலில் முதல் ஈரேட்டரிடமிருந்து மதிப்புகள் மீதும், இரண்டாவது ஐரேட்டரிலிருந்து மதிப்புகள் மீதும் மீண்டும் வரும்.
    ///
    /// வேறு வார்த்தைகளில் கூறுவதானால், இது ஒரு சங்கிலியில் இரண்டு ஈரேட்டர்களை ஒன்றாக இணைக்கிறது.🔗
    ///
    /// [`once`] ஒற்றை மதிப்பை மற்ற வகை மறு செய்கைகளின் சங்கிலியாக மாற்ற பொதுவாகப் பயன்படுத்தப்படுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` க்கான வாதம் [`IntoIterator`] ஐப் பயன்படுத்துவதால், ஒரு [`Iterator`] ஆக மட்டுமல்லாமல், [`Iterator`] ஆக மாற்றக்கூடிய எதையும் நாம் அனுப்ப முடியும்.
    /// எடுத்துக்காட்டாக, (`&[T]`) துண்டுகள் [`IntoIterator`] ஐ செயல்படுத்துகின்றன, எனவே நேரடியாக `chain()` க்கு அனுப்பலாம்:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// நீங்கள் Windows API உடன் பணிபுரிந்தால், நீங்கள் [`OsStr`] ஐ `Vec<u16>` ஆக மாற்ற விரும்பலாம்:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// ஜோடிகளின் ஒற்றை ஈரேட்டராக இரண்டு ஐரேட்டர்களை 'ஜிப்ஸ் அப்' செய்கிறது.
    ///
    /// `zip()` ஒரு புதிய ஈரேட்டரைத் தருகிறது, இது மற்ற இரண்டு ஈரேட்டர்களைக் காட்டிலும் மீண்டும் செயல்படும், முதல் உறுப்பு முதல் ஈரேட்டரிலிருந்து வரும் ஒரு டப்பிளைத் தருகிறது, இரண்டாவது உறுப்பு இரண்டாவது ஈரேட்டரிலிருந்து வருகிறது.
    ///
    ///
    /// வேறு வார்த்தைகளில் கூறுவதானால், இது இரண்டு ஐரேட்டர்களை ஒன்றாக இணைக்கிறது.
    ///
    /// ஈரேட்டர் [`None`] ஐத் திருப்பினால், ஜிப் செய்யப்பட்ட ஈரேட்டரிலிருந்து [`next`] [`None`] ஐத் தரும்.
    /// முதல் ஈரேட்டர் [`None`] ஐ வழங்கினால், `zip` ஷார்ட்-சர்க்யூட் மற்றும் `next` இரண்டாவது ஐரேட்டரில் அழைக்கப்படாது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` க்கான வாதம் [`IntoIterator`] ஐப் பயன்படுத்துவதால், ஒரு [`Iterator`] ஆக மட்டுமல்லாமல், [`Iterator`] ஆக மாற்றக்கூடிய எதையும் நாம் அனுப்ப முடியும்.
    /// எடுத்துக்காட்டாக, (`&[T]`) துண்டுகள் [`IntoIterator`] ஐ செயல்படுத்துகின்றன, எனவே நேரடியாக `zip()` க்கு அனுப்பலாம்:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` எல்லையற்ற ஈரேட்டரை வரையறுக்கப்பட்ட ஒன்றிற்கு ஜிப் செய்ய பெரும்பாலும் பயன்படுத்தப்படுகிறது.
    /// இது இயங்குகிறது, ஏனெனில் வரையறுக்கப்பட்ட ஈரேட்டர் இறுதியில் [`None`] ஐத் திருப்பி, ரிவிட் முடிவடையும்.`(0..)` உடன் ஜிப் செய்வது [`enumerate`] போல தோற்றமளிக்கும்:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// அசல் மறு செய்கையின் அருகிலுள்ள உருப்படிகளுக்கு இடையில் `separator` இன் நகலை வைக்கும் புதிய ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// `separator` [`Clone`] ஐ செயல்படுத்தவில்லை அல்லது ஒவ்வொரு முறையும் கணக்கிட வேண்டியிருந்தால், [`intersperse_with`] ஐப் பயன்படுத்தவும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` இலிருந்து முதல் உறுப்பு.
    /// assert_eq!(a.next(), Some(&100)); // பிரிப்பான்.
    /// assert_eq!(a.next(), Some(&1));   // `a` இலிருந்து அடுத்த உறுப்பு.
    /// assert_eq!(a.next(), Some(&100)); // பிரிப்பான்.
    /// assert_eq!(a.next(), Some(&2));   // `a` இலிருந்து கடைசி உறுப்பு.
    /// assert_eq!(a.next(), None);       // ஈரேட்டர் முடிந்தது.
    /// ```
    ///
    /// `intersperse` பொதுவான உறுப்பைப் பயன்படுத்தி ஒரு ஈரேட்டரின் உருப்படிகளில் சேர மிகவும் பயனுள்ளதாக இருக்கும்:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// ஒரு புதிய ஐரேட்டரை உருவாக்குகிறது, இது `separator` ஆல் உருவாக்கப்பட்ட உருப்படியை அசல் ஈரேட்டரின் அருகிலுள்ள உருப்படிகளுக்கு இடையில் வைக்கிறது.
    ///
    /// ஒவ்வொரு முறையும் அடிப்படை உருப்படியிலிருந்து இரண்டு அருகிலுள்ள உருப்படிகளுக்கு இடையில் ஒரு உருப்படி வைக்கப்படும் போது மூடல் சரியாக அழைக்கப்படும்;
    /// குறிப்பாக, அடிப்படை உருப்படி இரண்டு உருப்படிகளுக்குக் குறைவாகவும், கடைசி உருப்படி வழங்கப்பட்ட பின்னரும் மூடல் அழைக்கப்படாது.
    ///
    ///
    /// ஈரேட்டரின் உருப்படி [`Clone`] ஐ செயல்படுத்தினால், [`intersperse`] ஐப் பயன்படுத்துவது எளிதாக இருக்கலாம்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` இலிருந்து முதல் உறுப்பு.
    /// assert_eq!(it.next(), Some(NotClone(99))); // பிரிப்பான்.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` இலிருந்து அடுத்த உறுப்பு.
    /// assert_eq!(it.next(), Some(NotClone(99))); // பிரிப்பான்.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` இலிருந்து கடைசி உறுப்பு.
    /// assert_eq!(it.next(), None);               // ஈரேட்டர் முடிந்தது.
    /// ```
    ///
    /// `intersperse_with` பிரிப்பான் கணக்கிட வேண்டிய சூழ்நிலைகளில் பயன்படுத்தலாம்:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // மூடல் ஒரு பொருளை உருவாக்க அதன் சூழலை மாற்றிக் கொள்கிறது.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// ஒரு மூடுதலை எடுத்து ஒவ்வொரு உறுப்புக்கும் அந்த மூடுதலை அழைக்கும் ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// `map()` அதன் வாதத்தின் மூலம் ஒரு ஈரேட்டரை இன்னொருவருக்கு மாற்றுகிறது:
    /// [`FnMut`] ஐ செயல்படுத்தும் ஒன்று.இது ஒரு புதிய ஈரேட்டரை உருவாக்குகிறது, இது அசல் ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் இந்த மூடல் என்று அழைக்கப்படுகிறது.
    ///
    /// நீங்கள் வகைகளில் சிந்திப்பதில் நல்லவராக இருந்தால், இது போன்ற `map()` ஐப் பற்றி நீங்கள் சிந்திக்கலாம்:
    /// உங்களிடம் சில வகை `A` இன் கூறுகளைத் தரும் ஒரு ஈரேட்டர் இருந்தால், வேறு சில வகை `B` இன் ஒரு ஈரேட்டரை நீங்கள் விரும்பினால், நீங்கள் `map()` ஐப் பயன்படுத்தலாம், இது ஒரு மூடியைக் கடந்து ஒரு `A` ஐ எடுத்து `B` ஐ வழங்குகிறது.
    ///
    ///
    /// `map()` கருத்தியல் ரீதியாக ஒரு [`for`] வளையத்திற்கு ஒத்ததாகும்.இருப்பினும், `map()` சோம்பேறியாக இருப்பதால், நீங்கள் ஏற்கனவே மற்ற ஐரேட்டர்களுடன் பணிபுரியும் போது இது சிறப்பாகப் பயன்படுத்தப்படுகிறது.
    /// நீங்கள் ஒரு பக்க விளைவுக்காக ஒருவித சுழற்சியைச் செய்கிறீர்கள் என்றால், `map()` ஐ விட [`for`] ஐப் பயன்படுத்துவது மிகவும் முட்டாள்தனமாக கருதப்படுகிறது.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// நீங்கள் ஒருவித பக்க விளைவைச் செய்கிறீர்கள் என்றால், [`for`] ஐ `map()` க்கு விரும்புங்கள்:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // இதை செய்ய வேண்டாம்:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // அது சோம்பேறியாக இருப்பதால் அது கூட இயக்காது.Rust இதைப் பற்றி எச்சரிக்கும்.
    ///
    /// // அதற்கு பதிலாக, இதற்குப் பயன்படுத்தவும்:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// ஒரு செயலியின் ஒவ்வொரு உறுப்புக்கும் ஒரு மூடுதலை அழைக்கிறது.
    ///
    /// இது ஐடரேட்டரில் ஒரு [`for`] லூப்பைப் பயன்படுத்துவதற்கு சமம், இருப்பினும் `break` மற்றும் `continue` ஆகியவை மூடியதிலிருந்து சாத்தியமில்லை.
    /// `for` சுழற்சியைப் பயன்படுத்துவது பொதுவாக மிகவும் முட்டாள்தனமானது, ஆனால் நீண்ட மறு செய்கை சங்கிலிகளின் முடிவில் உருப்படிகளைச் செயலாக்கும்போது `for_each` மிகவும் தெளிவாக இருக்கலாம்.
    ///
    /// சில சந்தர்ப்பங்களில், `for_each` ஒரு வட்டத்தை விட வேகமாகவும் இருக்கலாம், ஏனெனில் இது `Chain` போன்ற அடாப்டர்களில் உள் மறு செய்கையைப் பயன்படுத்தும்.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// அத்தகைய ஒரு சிறிய எடுத்துக்காட்டுக்கு, ஒரு `for` வளையம் தூய்மையாக இருக்கலாம், ஆனால் `for_each` ஒரு செயல்பாட்டு பாணியை நீண்ட ஐரேட்டர்களுடன் வைத்திருக்க விரும்பத்தக்கது:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// ஒரு உறுப்பு வழங்கப்பட வேண்டுமா என்பதை தீர்மானிக்க மூடுதலைப் பயன்படுத்தும் ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// ஒரு உறுப்பு கொடுக்கப்பட்டால் மூடல் `true` அல்லது `false` ஐத் தர வேண்டும்.திருப்பி அனுப்பப்பட்டவர் மூடல் உண்மையாகத் திரும்பும் கூறுகளை மட்டுமே வழங்கும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ஏனெனில் `filter()` க்கு அனுப்பப்பட்ட மூடல் ஒரு குறிப்பை எடுத்துக்கொள்கிறது, மேலும் பல மறுபயன்பாட்டாளர்கள் குறிப்புகளை மீறிச் செல்கிறார்கள், இது குழப்பமான சூழ்நிலைக்கு வழிவகுக்கிறது, அங்கு மூடலின் வகை இரட்டைக் குறிப்பு ஆகும்:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // இரண்டு * கள் தேவை!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ஒன்றை அகற்றுவதற்கு பதிலாக வாதத்தில் அழிப்பதைப் பயன்படுத்துவது பொதுவானது:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // இருவரும் *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// அல்லது இரண்டும்:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // இரண்டு &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// இந்த அடுக்குகளின்.
    ///
    /// `iter.filter(f).next()` என்பது `iter.find(f)` க்கு சமம் என்பதை நினைவில் கொள்க.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// வடிப்பான்கள் மற்றும் வரைபடங்கள் இரண்டையும் உருவாக்கும் ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// திரும்பிய ஈரேட்டர் வழங்கப்படும் மூடல் `Some(value)` ஐ வழங்கும் `மதிப்பு`க்களை மட்டுமே தருகிறது.
    ///
    /// `filter_map` [`filter`] மற்றும் [`map`] இன் சங்கிலிகளை இன்னும் சுருக்கமாக உருவாக்க பயன்படுத்தலாம்.
    /// கீழேயுள்ள எடுத்துக்காட்டு, `map().filter().map()` ஐ `filter_map` க்கு ஒரு அழைப்பாக எவ்வாறு சுருக்கலாம் என்பதைக் காட்டுகிறது.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// இங்கே அதே உதாரணம், ஆனால் [`filter`] மற்றும் [`map`] உடன்:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// ஒரு மறு செய்கையை உருவாக்குகிறது, இது தற்போதைய மறு செய்கை எண்ணிக்கையையும் அடுத்த மதிப்பையும் தருகிறது.
    ///
    /// ஈரேட்டர் திரும்பும் மகசூல் ஜோடிகள் `(i, val)`, இங்கு `i` என்பது மறு செய்கையின் தற்போதைய குறியீடாகும் மற்றும் `val` என்பது ஈரேட்டரால் வழங்கப்பட்ட மதிப்பு.
    ///
    ///
    /// `enumerate()` அதன் எண்ணிக்கையை [`usize`] ஆக வைத்திருக்கிறது.
    /// நீங்கள் வேறு அளவிலான முழு எண்ணால் எண்ண விரும்பினால், [`zip`] செயல்பாடு ஒத்த செயல்பாட்டை வழங்குகிறது.
    ///
    /// # வழிதல் நடத்தை
    ///
    /// இந்த வழி வழிதல் என்பதிலிருந்து பாதுகாக்காது, எனவே [`usize::MAX`] க்கும் மேற்பட்ட கூறுகளை கணக்கிடுவது தவறான முடிவை அல்லது panics ஐ உருவாக்குகிறது.
    /// பிழைத்திருத்த வலியுறுத்தல்கள் இயக்கப்பட்டால், ஒரு panic உத்தரவாதம் அளிக்கப்படுகிறது.
    ///
    /// # Panics
    ///
    /// திரும்பப் பெறப்பட வேண்டிய குறியீடானது ஒரு [`usize`] ஐ நிரம்பி வழிகிறது என்றால் திரும்பிய மறு செய்கை panic ஆக இருக்கலாம்.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// ஒரு ஈரேட்டரை உருவாக்குகிறது, இது எக்ஸ் 100 எக்ஸ் ஐப் பயன்படுத்தி ஈரேட்டரின் அடுத்த உறுப்பைப் பயன்படுத்தாமல் பார்க்க முடியும்.
    ///
    /// ஒரு செயலிக்கு [`peek`] முறையைச் சேர்க்கிறது.மேலும் தகவலுக்கு அதன் ஆவணங்களைப் பார்க்கவும்.
    ///
    /// முதல் முறையாக [`peek`] அழைக்கப்படும் போது அடிப்படை ஐரேட்டர் இன்னும் முன்னேறுகிறது என்பதை நினைவில் கொள்க: அடுத்த உறுப்பை மீட்டெடுப்பதற்காக, [`next`] அடிப்படை ஐரேட்டரில் அழைக்கப்படுகிறது, எனவே எந்த பக்க விளைவுகளும் (அதாவது
    ///
    /// [`next`] முறையின் அடுத்த மதிப்பைப் பெறுவதைத் தவிர வேறு எதுவும் நிகழும்.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future ஐப் பார்ப்போம்
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // நாம் பல முறை peek() செய்யலாம், ஈரேட்டர் முன்னேறாது
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // மறு செய்கை முடிந்ததும், peek() ஆகும்
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// ஒரு முன்னறிவிப்பின் அடிப்படையில் [`தவிர்]] கூறுகள் ஒரு ஐரேட்டரை உருவாக்குகிறது.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` ஒரு வாதத்தை மூடுவதை எடுக்கிறது.இது ஈரேட்டரின் ஒவ்வொரு உறுப்புகளிலும் இந்த மூடுதலை அழைக்கும், மேலும் இது `false` ஐ வழங்கும் வரை உறுப்புகளை புறக்கணிக்கும்.
    ///
    /// `false` திரும்பிய பிறகு, `skip_while()`'s வேலை முடிந்தது, மீதமுள்ள கூறுகள் வழங்கப்படுகின்றன.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ஏனெனில் `skip_while()` க்கு அனுப்பப்பட்ட மூடல் ஒரு குறிப்பை எடுத்துக்கொள்கிறது, மேலும் பல மறுபயன்பாட்டாளர்கள் குறிப்புகளை மீறிச் செல்கிறார்கள், இது குழப்பமான சூழ்நிலைக்கு வழிவகுக்கிறது, அங்கு மூடல் வாதத்தின் வகை இரட்டை குறிப்பு ஆகும்:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // இரண்டு * கள் தேவை!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ஆரம்ப `false` க்குப் பிறகு நிறுத்துதல்:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // இது பொய்யாக இருந்திருக்கும், ஏனெனில் எங்களுக்கு ஏற்கனவே தவறானது கிடைத்ததால், skip_while() இனி பயன்படுத்தப்படாது
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// ஒரு முன்னறிவிப்பின் அடிப்படையில் உறுப்புகளை விளைவிக்கும் ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// `take_while()` ஒரு வாதத்தை மூடுவதை எடுக்கிறது.இது ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் இந்த மூடுதலை அழைக்கும், மேலும் இது `true` ஐ வழங்கும் போது உறுப்புகளை விளைவிக்கும்.
    ///
    /// `false` திரும்பிய பிறகு, `take_while()`'s வேலை முடிந்தது, மீதமுள்ள கூறுகள் புறக்கணிக்கப்படுகின்றன.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ஏனெனில் `take_while()` க்கு அனுப்பப்பட்ட மூடல் ஒரு குறிப்பை எடுத்துக்கொள்கிறது, மேலும் பல மறுபயன்பாட்டாளர்கள் குறிப்புகளை மீறிச் செல்கிறார்கள், இது குழப்பமான சூழ்நிலைக்கு வழிவகுக்கிறது, அங்கு மூடலின் வகை இரட்டைக் குறிப்பு ஆகும்:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // இரண்டு * கள் தேவை!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ஆரம்ப `false` க்குப் பிறகு நிறுத்துதல்:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // பூஜ்ஜியத்தை விடக் குறைவான கூறுகள் எங்களிடம் உள்ளன, ஆனால் எங்களுக்கு ஏற்கனவே ஒரு பொய் கிடைத்ததால், take_while() இனி பயன்படுத்தப்படாது
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` மதிப்பைச் சேர்க்க வேண்டுமா இல்லையா என்பதைப் பார்க்க வேண்டும் என்பதால், அதை நீக்குவதை நுகர்வு செய்பவர்கள் பார்ப்பார்கள்:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` இனி இல்லை, ஏனென்றால் மறு செய்கை நிறுத்தப்பட வேண்டுமா என்று பார்க்கும் பொருட்டு இது நுகரப்பட்டது, ஆனால் மீண்டும் செயலியில் வைக்கப்படவில்லை.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// ஒரு முன்னறிவிப்பு மற்றும் வரைபடங்களின் அடிப்படையில் உறுப்புகள் இரண்டையும் விளைவிக்கும் ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// `map_while()` ஒரு வாதத்தை மூடுவதை எடுக்கிறது.
    /// இது ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் இந்த மூடுதலை அழைக்கும், மேலும் இது [`Some(_)`][`Some`] ஐ வழங்கும் போது உறுப்புகளை விளைவிக்கும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// இங்கே அதே உதாரணம், ஆனால் [`take_while`] மற்றும் [`map`] உடன்:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ஆரம்ப [`None`] க்குப் பிறகு நிறுத்துதல்:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // u32 (4, 5) இல் பொருந்தக்கூடிய கூடுதல் கூறுகள் எங்களிடம் உள்ளன, ஆனால் `map_while` `-3` க்கு `None` ஐ வழங்கியது (`predicate` `None` ஐ திருப்பியது போல) மற்றும் `collect` முதல் `None` சந்தித்த நேரத்தில் நிறுத்தப்படும்.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()` மதிப்பைச் சேர்க்க வேண்டுமா இல்லையா என்பதைப் பார்க்க வேண்டும் என்பதால், அதை நீக்குவதை நுகர்வு செய்பவர்கள் பார்ப்பார்கள்:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` இனி இல்லை, ஏனென்றால் மறு செய்கை நிறுத்தப்பட வேண்டுமா என்று பார்க்கும் பொருட்டு இது நுகரப்பட்டது, ஆனால் மீண்டும் செயலியில் வைக்கப்படவில்லை.
    ///
    /// [`take_while`] போலல்லாமல் இந்த ஈரேட்டர் **இணைக்கப்படவில்லை** என்பதை நினைவில் கொள்க.
    /// முதல் [`None`] திரும்பிய பின் இந்த ஈரேட்டர் என்ன தருகிறது என்பதும் குறிப்பிடப்படவில்லை.
    /// உங்களுக்கு இணைந்த ஐரேட்டர் தேவைப்பட்டால், [`fuse`] ஐப் பயன்படுத்தவும்.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// முதல் `n` உறுப்புகளைத் தவிர்க்கும் ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// அவை உட்கொண்ட பிறகு, மீதமுள்ள கூறுகள் விளைகின்றன.
    /// இந்த முறையை நேரடியாக மீறுவதற்கு பதிலாக, `nth` முறையை மேலெழுதவும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// அதன் முதல் `n` கூறுகளை விளைவிக்கும் ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` இது வரையறுக்கப்பட்டதாக மாற்ற, எல்லையற்ற ஈரேட்டருடன் பெரும்பாலும் பயன்படுத்தப்படுகிறது:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `n` க்கும் குறைவான கூறுகள் கிடைத்தால், `take` தன்னை அடிப்படை ஈரேட்டரின் அளவிற்கு மட்டுப்படுத்தும்:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// [`fold`] ஐ ஒத்த ஒரு ஈரேட்டர் அடாப்டர் உள் நிலையை வைத்திருக்கிறது மற்றும் புதிய ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` இரண்டு வாதங்களை எடுக்கிறது: உள் நிலைக்கு விதைக்கும் ஆரம்ப மதிப்பு, மற்றும் இரண்டு வாதங்களுடன் மூடல், முதலாவது உள் நிலைக்கு மாறக்கூடிய குறிப்பு மற்றும் இரண்டாவது ஒரு ஈரேட்டர் உறுப்பு.
    ///
    /// மறு செய்கைகளுக்கு இடையில் நிலையைப் பகிர்ந்து கொள்ள மூடல் உள் நிலைக்கு ஒதுக்கப்படலாம்.
    ///
    /// மறு செய்கையில், மூடுதலானது ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் பயன்படுத்தப்படும் மற்றும் மூடியிலிருந்து திரும்பும் மதிப்பு, ஒரு [`Option`], ஈரேட்டரால் வழங்கப்படுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ஒவ்வொரு மறு செய்கையும், நாம் உறுப்பு மூலம் மாநிலத்தை பெருக்குவோம்
    ///     *state = *state * x;
    ///
    ///     // பின்னர், நாங்கள் அரசின் மறுப்பை வழங்குவோம்
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// வரைபடத்தைப் போல செயல்படும் ஒரு ஈரேட்டரை உருவாக்குகிறது, ஆனால் உள்ளமைக்கப்பட்ட கட்டமைப்பைத் தட்டையானது.
    ///
    /// [`map`] அடாப்டர் மிகவும் பயனுள்ளதாக இருக்கும், ஆனால் மூடல் வாதம் மதிப்புகளை உருவாக்கும் போது மட்டுமே.
    /// அதற்கு பதிலாக ஒரு ஈரேட்டரை உருவாக்கினால், கூடுதல் திசைதிருப்பல் உள்ளது.
    /// `flat_map()` இந்த கூடுதல் அடுக்கை அதன் சொந்தமாக அகற்றும்.
    ///
    /// நீங்கள் `flat_map(f)` ஐ [`வரைபடம்] பிங்கின் சொற்பொருள் சமமானதாகக் கருதலாம், பின்னர் `map(f).flatten()` இல் உள்ளதைப் போல [` தட்டையானது`].
    ///
    /// `flat_map()` பற்றி சிந்திக்க மற்றொரு வழி: [`வரைபடத்தின்] மூடல் ஒவ்வொரு உறுப்புக்கும் ஒரு உருப்படியைத் தருகிறது, மேலும் `flat_map()`'s மூடல் ஒவ்வொரு உறுப்புக்கும் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ஒரு ஈரேட்டரைத் தருகிறது
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// உள்ளமைக்கப்பட்ட கட்டமைப்பைத் தட்டையான ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// உங்களிடம் ஈரேட்டர்களின் ஒரு ஈரேட்டர் அல்லது ஐரேட்டர்களாக மாற்றக்கூடிய விஷயங்களை ஒரு ஈரேட்டர் வைத்திருக்கும்போது இது பயனுள்ளதாக இருக்கும், மேலும் நீங்கள் ஒரு நிலை திசைதிருப்பலை அகற்ற விரும்புகிறீர்கள்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// மேப்பிங் மற்றும் தட்டையானது:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ஒரு ஈரேட்டரைத் தருகிறது
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// நீங்கள் இதை [`flat_map()`] இன் அடிப்படையில் மீண்டும் எழுதலாம், இது இந்த விஷயத்தில் விரும்பத்தக்கது, ஏனெனில் இது நோக்கத்தை இன்னும் தெளிவாக தெரிவிக்கிறது:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ஒரு ஈரேட்டரைத் தருகிறது
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// தட்டையானது ஒரு நேரத்தில் ஒரு நிலை கூடுகளை மட்டுமே நீக்குகிறது:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// இங்கே `flatten()` ஒரு "deep" தட்டையானது செய்யாது என்பதைக் காண்கிறோம்.
    /// அதற்கு பதிலாக, ஒரு நிலை கூடுகள் மட்டுமே அகற்றப்படுகின்றன.அதாவது, நீங்கள் `flatten()` ஒரு முப்பரிமாண வரிசை என்றால், இதன் விளைவாக இரு பரிமாணமாக இருக்கும், ஆனால் ஒரு பரிமாணமாக இருக்காது.
    /// ஒரு பரிமாண அமைப்பைப் பெற, நீங்கள் மீண்டும் `flatten()` வேண்டும்.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// முதல் [`None`] க்குப் பிறகு முடிவடையும் ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// ஒரு ஈரேட்டர் [`None`] ஐ வழங்கிய பிறகு, future அழைப்புகள் [`Some(T)`] ஐ மீண்டும் வழங்கலாம் அல்லது வழங்காது.
    /// `fuse()` ஒரு ஈரேட்டரைத் தழுவி, ஒரு [`None`] வழங்கப்பட்ட பிறகு, அது எப்போதும் [`None`] ஐ எப்போதும் வழங்கும் என்பதை உறுதி செய்கிறது.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// // சில மற்றும் எதுவுமில்லை என்று மாற்றும் ஒரு செயலி
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // அது சமமாக இருந்தால், Some(i32), வேறு எதுவும் இல்லை
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // எங்கள் ஈரேட்டர் முன்னும் பின்னுமாக செல்வதைக் காணலாம்
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // இருப்பினும், அதை இணைத்தவுடன் ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // இது எப்போதும் முதல் முறையாக `None` ஐ வழங்கும்.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// ஒரு ஈரேட்டரின் ஒவ்வொரு உறுப்புடனும் ஏதாவது செய்கிறதா, மதிப்பைக் கடக்கிறது.
    ///
    /// ஐரேட்டர்களைப் பயன்படுத்தும் போது, நீங்கள் பலவற்றை ஒன்றாகச் சேர்ப்பீர்கள்.
    /// அத்தகைய குறியீட்டில் பணிபுரியும் போது, குழாயின் பல்வேறு பகுதிகளில் என்ன நடக்கிறது என்பதை நீங்கள் பார்க்க விரும்பலாம்.அதைச் செய்ய, `inspect()` க்கு அழைப்பைச் செருகவும்.
    ///
    /// உங்கள் இறுதிக் குறியீட்டில் இருப்பதை விட பிழைத்திருத்த கருவியாக `inspect()` பயன்படுத்தப்படுவது மிகவும் பொதுவானது, ஆனால் பிழைகள் நிராகரிக்கப்படுவதற்கு முன்பு உள்நுழைய வேண்டியிருக்கும் போது சில சூழ்நிலைகளில் பயன்பாடுகள் பயனுள்ளதாக இருக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // இந்த ஈரேட்டர் வரிசை சிக்கலானது.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // என்ன நடக்கிறது என்பதை விசாரிக்க சில inspect() அழைப்புகளைச் சேர்ப்போம்
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// இது அச்சிடும்:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// பிழைகளை நிராகரிப்பதற்கு முன் அவற்றை பதிவு செய்தல்:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// இது அச்சிடும்:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// அதை உட்கொள்வதை விட, ஒரு ஈரேட்டரை கடன் வாங்குகிறது.
    ///
    /// அசல் ஈரேட்டரின் உரிமையைத் தக்க வைத்துக் கொள்ளும்போது, ஈரேட்டர் அடாப்டர்களைப் பயன்படுத்துவதை அனுமதிக்க இது பயனுள்ளதாக இருக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // நாங்கள் அதை மீண்டும் பயன்படுத்த முயற்சித்தால், அது இயங்காது.
    /// // பின்வரும் வரி "பிழை: நகர்த்தப்பட்ட மதிப்பின் பயன்பாடு: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // அதை மீண்டும் முயற்சிப்போம்
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // அதற்கு பதிலாக, நாங்கள் ஒரு .by_ref() இல் சேர்க்கிறோம்
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // இப்போது இது நன்றாக உள்ளது:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// ஒரு ஈரேட்டரை ஒரு தொகுப்பாக மாற்றுகிறது.
    ///
    /// `collect()` எதையும் மீண்டும் எடுக்க முடியும், மேலும் அதை தொடர்புடைய தொகுப்பாக மாற்றலாம்.
    /// நிலையான நூலகத்தில் இது மிகவும் சக்திவாய்ந்த முறைகளில் ஒன்றாகும், இது பல்வேறு சூழல்களில் பயன்படுத்தப்படுகிறது.
    ///
    /// `collect()` பயன்படுத்தப்படும் மிக அடிப்படையான முறை ஒரு தொகுப்பை மற்றொரு தொகுப்பாக மாற்றுவதாகும்.
    /// நீங்கள் ஒரு தொகுப்பை எடுத்து, அதில் [`iter`] ஐ அழைக்கவும், ஒரு சில மாற்றங்களைச் செய்யவும், பின்னர் `collect()` ஐ இறுதியில் செய்யவும்.
    ///
    /// `collect()` வழக்கமான தொகுப்புகள் இல்லாத வகைகளின் நிகழ்வுகளையும் உருவாக்கலாம்.
    /// எடுத்துக்காட்டாக, [`char`] களில் இருந்து ஒரு [`String`] ஐ உருவாக்க முடியும், மேலும் [`Result<T, E>`][`Result`] உருப்படிகளின் மறு செய்கை `Result<Collection<T>, E>` இல் சேகரிக்கப்படலாம்.
    ///
    /// மேலும் விவரங்களுக்கு கீழே உள்ள எடுத்துக்காட்டுகளைப் பார்க்கவும்.
    ///
    /// `collect()` மிகவும் பொதுவானது என்பதால், இது வகை அனுமானத்தில் சிக்கல்களை ஏற்படுத்தும்.
    /// எனவே, X001 என அழைக்கப்படும் தொடரியல் நீங்கள் பார்க்கும் சில நேரங்களில் `collect()` ஒன்றாகும்: `::<>`.
    /// நீங்கள் எந்த சேகரிப்பில் சேகரிக்க முயற்சிக்கிறீர்கள் என்பதை குறிப்பாக புரிந்துகொள்ள வழிமுறை உதவுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// எங்களுக்கு இடது புறத்தில் `: Vec<i32>` தேவை என்பதை நினைவில் கொள்க.ஏனென்றால், அதற்கு பதிலாக ஒரு [`VecDeque<T>`] ஐ நாம் சேகரிக்க முடியும்:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` ஐ குறிப்பதற்கு பதிலாக 'turbofish' ஐப் பயன்படுத்துதல்:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` நீங்கள் சேகரிப்பதைப் பற்றி மட்டுமே அக்கறை கொண்டிருப்பதால், நீங்கள் இன்னும் டர்போஃபிஷுடன் ஒரு பகுதி வகை குறிப்பான `_` ஐப் பயன்படுத்தலாம்:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] ஐ உருவாக்க `collect()` ஐப் பயன்படுத்துதல்:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// உங்களிடம் [`முடிவு<T, E>`][`முடிவு`] கள், அவற்றில் ஏதேனும் தோல்வியுற்றதா என்பதை அறிய நீங்கள் `collect()` ஐப் பயன்படுத்தலாம்:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // எங்களுக்கு முதல் பிழையைத் தருகிறது
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // பதில்களின் பட்டியலை எங்களுக்கு வழங்குகிறது
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// ஒரு ஈரேட்டரைப் பயன்படுத்துகிறது, அதிலிருந்து இரண்டு தொகுப்புகளை உருவாக்குகிறது.
    ///
    /// `partition()` க்கு அனுப்பப்பட்ட முன்னறிவிப்பு `true` அல்லது `false` ஐ வழங்க முடியும்.
    /// `partition()` ஒரு ஜோடியைத் தருகிறது, இது `true` ஐத் திருப்பிய அனைத்து உறுப்புகளும், மற்றும் `false` ஐத் திருப்பிய அனைத்து உறுப்புகளும்.
    ///
    ///
    /// [`is_partitioned()`] மற்றும் [`partition_in_place()`] ஐயும் காண்க.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// கொடுக்கப்பட்ட முன்னறிவிப்பின் படி இந்த இடரேட்டரின் உறுப்புகளை *இடத்தில்* மறுவரிசைப்படுத்துகிறது, அதாவது `true` ஐ திருப்பித் தரும் அனைத்துமே `false` ஐத் தரும் அனைத்திற்கும் முந்தியவை.
    ///
    /// கண்டுபிடிக்கப்பட்ட `true` உறுப்புகளின் எண்ணிக்கையை வழங்குகிறது.
    ///
    /// பகிர்வு செய்யப்பட்ட பொருட்களின் ஒப்பீட்டு வரிசை பராமரிக்கப்படவில்லை.
    ///
    /// [`is_partitioned()`] மற்றும் [`partition()`] ஐயும் காண்க.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // சமநிலை மற்றும் முரண்பாடுகளுக்கு இடையில் பகிர்வு
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: எண்ணிக்கை நிரம்பி வழிவதைப் பற்றி நாம் கவலைப்பட வேண்டுமா?விட அதிகமாக இருப்பதற்கான ஒரே வழி
        // `usize::MAX` மாற்றக்கூடிய குறிப்புகள் ZST களுடன் உள்ளன, அவை பகிர்வுக்கு பயனுள்ளதாக இல்லை ...

        // `Self` இல் பொதுவான தன்மையைத் தவிர்க்க இந்த மூடல் "factory" செயல்பாடுகள் உள்ளன.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // முதல் `false` ஐ மீண்டும் மீண்டும் கண்டுபிடித்து கடைசி `true` உடன் மாற்றவும்.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// கொடுக்கப்பட்ட முன்கணிப்புக்கு ஏற்ப இந்த ஈரேட்டரின் கூறுகள் பகிர்வு செய்யப்பட்டுள்ளதா என சரிபார்க்கிறது, அதாவது `true` ஐ திருப்பித் தரும் அனைத்தும் `false` ஐத் தரும் அனைத்திற்கும் முந்தியுள்ளது.
    ///
    ///
    /// [`partition()`] மற்றும் [`partition_in_place()`] ஐயும் காண்க.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // எல்லா பொருட்களும் `true` ஐ சோதிக்கின்றன, அல்லது முதல் பிரிவு `false` இல் நின்றுவிடுகிறது, அதன்பிறகு மேலும் `true` உருப்படிகள் இல்லை என்பதை நாங்கள் சரிபார்க்கிறோம்.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// ஒரு செயல்பாட்டை வெற்றிகரமாக திரும்பும் வரை, ஒரு ஒற்றை, இறுதி மதிப்பை உருவாக்கும் ஒரு ஈரேட்டர் முறை.
    ///
    /// `try_fold()` இரண்டு வாதங்களை எடுக்கிறது: ஒரு ஆரம்ப மதிப்பு, மற்றும் இரண்டு வாதங்களுடன் ஒரு மூடல்: ஒரு 'accumulator' மற்றும் ஒரு உறுப்பு.
    /// மூடல் வெற்றிகரமாக திரும்பும், அடுத்த மறு செய்கைக்கு குவிப்பான் வைத்திருக்க வேண்டிய மதிப்புடன், அல்லது அது தோல்வியைத் தருகிறது, பிழை மதிப்புடன் உடனடியாக அழைப்பாளருக்கு (short-circuiting) க்கு மீண்டும் பிரச்சாரம் செய்யப்படுகிறது.
    ///
    ///
    /// ஆரம்ப மதிப்பு என்பது முதல் அழைப்பில் குவிப்பான் வைத்திருக்கும் மதிப்பு.மூடுதலைப் பயன்படுத்துவது ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் எதிராக வெற்றிபெற்றால், `try_fold()` இறுதி குவிப்பானை வெற்றியாக வழங்குகிறது.
    ///
    /// உங்களிடம் ஏதாவது ஒரு தொகுப்பு இருக்கும் போதெல்லாம் மடிப்பு பயனுள்ளதாக இருக்கும், மேலும் அதிலிருந்து ஒரு மதிப்பை உருவாக்க விரும்புகிறது.
    ///
    /// # செயல்படுத்துபவர்களுக்கு குறிப்பு
    ///
    /// பிற (forward) முறைகளில் பலவற்றின் அடிப்படையில் இயல்புநிலை செயலாக்கங்கள் உள்ளன, எனவே இயல்புநிலை `for` லூப் செயல்படுத்தலை விட சிறப்பாக ஏதாவது செய்ய முடிந்தால் இதை வெளிப்படையாக செயல்படுத்த முயற்சிக்கவும்.
    ///
    /// குறிப்பாக, இந்த ஐரேட்டர் இயற்றப்பட்ட உள் பகுதிகளில் இந்த அழைப்பு `try_fold()` ஐ முயற்சிக்கவும்.
    /// பல அழைப்புகள் தேவைப்பட்டால், திரட்டல் மதிப்பைக் கட்டுப்படுத்த `?` ஆபரேட்டர் வசதியாக இருக்கலாம், ஆனால் அந்த ஆரம்ப வருவாய்க்கு முன்னர் உறுதிப்படுத்தப்பட வேண்டிய எந்தவொரு மாற்றத்தையும் ஜாக்கிரதை.
    /// இது ஒரு `&mut self` முறை, எனவே இங்கே ஒரு பிழையைத் தாக்கிய பிறகு மறு செய்கை மீண்டும் தொடங்கப்பட வேண்டும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // வரிசையின் அனைத்து உறுப்புகளின் சரிபார்க்கப்பட்ட தொகை
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 100 உறுப்பைச் சேர்க்கும்போது இந்த தொகை நிரம்பி வழிகிறது
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // இது குறுகிய சுற்று என்பதால், மீதமுள்ள கூறுகள் இன்னும் ஈரேட்டர் மூலம் கிடைக்கின்றன.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ஈரேட்டரில் உள்ள ஒவ்வொரு உருப்படிக்கும் ஒரு தவறான செயல்பாட்டைப் பயன்படுத்தும் ஒரு ஈரேட்டர் முறை, முதல் பிழையை நிறுத்தி அந்த பிழையைத் தருகிறது.
    ///
    ///
    /// இது [`for_each()`] இன் தவறான வடிவம் அல்லது [`try_fold()`] இன் நிலையற்ற பதிப்பாகவும் கருதப்படலாம்.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // இது குறுகிய சுற்று, எனவே மீதமுள்ள உருப்படிகள் இன்னும் ஐரேட்டரில் உள்ளன:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// ஒரு செயல்பாட்டைப் பயன்படுத்துவதன் மூலம் ஒவ்வொரு உறுப்புகளையும் ஒரு குவிப்பானாக மடித்து, இறுதி முடிவைத் தருகிறது.
    ///
    /// `fold()` இரண்டு வாதங்களை எடுக்கிறது: ஒரு ஆரம்ப மதிப்பு, மற்றும் இரண்டு வாதங்களுடன் ஒரு மூடல்: ஒரு 'accumulator' மற்றும் ஒரு உறுப்பு.
    /// மூடல் அடுத்த மறு செய்கைக்கு குவிப்பான் வைத்திருக்க வேண்டிய மதிப்பை வழங்குகிறது.
    ///
    /// ஆரம்ப மதிப்பு என்பது முதல் அழைப்பில் குவிப்பான் வைத்திருக்கும் மதிப்பு.
    ///
    /// ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் இந்த மூடுதலைப் பயன்படுத்திய பிறகு, `fold()` குவிப்பானைத் தருகிறது.
    ///
    /// இந்த செயல்பாடு சில நேரங்களில் 'reduce' அல்லது 'inject' என அழைக்கப்படுகிறது.
    ///
    /// உங்களிடம் ஏதாவது ஒரு தொகுப்பு இருக்கும் போதெல்லாம் மடிப்பு பயனுள்ளதாக இருக்கும், மேலும் அதிலிருந்து ஒரு மதிப்பை உருவாக்க விரும்புகிறது.
    ///
    /// Note: `fold()`, மற்றும் முழு மறுசெயலையும் கடந்து செல்லும் ஒத்த முறைகள், traits இல் கூட, எல்லையற்ற மறு செய்கையாளர்களுக்கு நிறுத்தப்படாது, இதன் விளைவாக வரையறுக்கப்பட்ட நேரத்தில் முடிவு தீர்மானிக்கப்படுகிறது.
    ///
    /// Note: திரட்டல் வகை மற்றும் உருப்படி வகை ஒரே மாதிரியாக இருந்தால், முதல் உறுப்பை ஆரம்ப மதிப்பாகப் பயன்படுத்த [`reduce()`] ஐப் பயன்படுத்தலாம்.
    ///
    /// # செயல்படுத்துபவர்களுக்கு குறிப்பு
    ///
    /// பிற (forward) முறைகளில் பலவற்றின் அடிப்படையில் இயல்புநிலை செயலாக்கங்கள் உள்ளன, எனவே இயல்புநிலை `for` லூப் செயல்படுத்தலை விட சிறப்பாக ஏதாவது செய்ய முடிந்தால் இதை வெளிப்படையாக செயல்படுத்த முயற்சிக்கவும்.
    ///
    ///
    /// குறிப்பாக, இந்த ஐரேட்டர் இயற்றப்பட்ட உள் பகுதிகளில் இந்த அழைப்பு `fold()` ஐ முயற்சிக்கவும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // வரிசையின் அனைத்து உறுப்புகளின் கூட்டுத்தொகை
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// மறு செய்கையின் ஒவ்வொரு அடியிலும் இங்கே நடப்போம்:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// எனவே, எங்கள் இறுதி முடிவு, `6`.
    ///
    /// ஐரேட்டர்களை அதிகம் பயன்படுத்தாத நபர்கள் ஒரு முடிவைக் கட்டியெழுப்ப விஷயங்களின் பட்டியலுடன் `for` லூப்பைப் பயன்படுத்துவது பொதுவானது.அவற்றை `fold()`s ஆக மாற்றலாம்:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // வளையத்திற்கு:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // அவை ஒன்றே
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// குறைக்கும் செயல்பாட்டை மீண்டும் மீண்டும் பயன்படுத்துவதன் மூலம், உறுப்புகளை ஒற்றை ஒன்றிற்குக் குறைக்கிறது.
    ///
    /// ஈரேட்டர் காலியாக இருந்தால், [`None`] ஐ வழங்குகிறது;இல்லையெனில், குறைப்பின் முடிவை வழங்குகிறது.
    ///
    /// குறைந்த பட்சம் ஒரு உறுப்பு கொண்ட ஈரேட்டர்களுக்கு, இது ஈரேட்டரின் முதல் உறுப்புடன் ஆரம்ப மதிப்பாக [`fold()`] க்கு சமம், அடுத்தடுத்த ஒவ்வொரு உறுப்புகளையும் அதில் மடிக்கிறது.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// அதிகபட்ச மதிப்பைக் கண்டறியவும்:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// மறு செய்கையின் ஒவ்வொரு உறுப்பு ஒரு முன்னறிவிப்புடன் பொருந்தினால் சோதனைகள்.
    ///
    /// `all()` `true` அல்லது `false` ஐ வழங்கும் ஒரு மூடல் எடுக்கும்.இது ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் இந்த மூடுதலைப் பயன்படுத்துகிறது, மேலும் அவை அனைத்தும் `true` ஐத் திருப்பினால், `all()` ஐயும் செய்கிறது.
    /// அவர்களில் யாராவது `false` ஐ திருப்பித் தந்தால், அது `false` ஐ வழங்குகிறது.
    ///
    /// `all()` குறுகிய சுற்று;வேறு வார்த்தைகளில் கூறுவதானால், இது ஒரு `false` ஐக் கண்டறிந்தவுடன் செயலாக்கத்தை நிறுத்திவிடும், வேறு என்ன நடந்தாலும், இதன் விளைவாக `false` ஆக இருக்கும்.
    ///
    ///
    /// வெற்று ஈரேட்டர் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// முதல் `false` இல் நிறுத்துதல்:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // இன்னும் உறுப்புகள் இருப்பதால் நாம் இன்னும் `iter` ஐப் பயன்படுத்தலாம்.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// மறு செய்கையின் எந்த உறுப்பு ஒரு முன்னறிவிப்புடன் பொருந்தினால் சோதனைகள்.
    ///
    /// `any()` `true` அல்லது `false` ஐ வழங்கும் ஒரு மூடல் எடுக்கும்.இது ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் இந்த மூடுதலைப் பயன்படுத்துகிறது, மேலும் அவற்றில் ஏதேனும் `true` ஐத் திருப்பினால், `any()` ஐயும் செய்கிறது.
    /// அவர்கள் அனைவரும் `false` ஐத் திருப்பினால், அது `false` ஐ வழங்குகிறது.
    ///
    /// `any()` குறுகிய சுற்று;வேறு வார்த்தைகளில் கூறுவதானால், இது ஒரு `true` ஐக் கண்டறிந்தவுடன் செயலாக்கத்தை நிறுத்திவிடும், வேறு என்ன நடந்தாலும், இதன் விளைவாக `true` ஆக இருக்கும்.
    ///
    ///
    /// வெற்று ஈரேட்டர் `false` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// முதல் `true` இல் நிறுத்துதல்:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // இன்னும் உறுப்புகள் இருப்பதால் நாம் இன்னும் `iter` ஐப் பயன்படுத்தலாம்.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// ஒரு முன்னறிவிப்பை திருப்திப்படுத்தும் ஒரு செயலியின் உறுப்புக்கான தேடல்கள்.
    ///
    /// `find()` `true` அல்லது `false` ஐ வழங்கும் ஒரு மூடல் எடுக்கும்.
    /// இது ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் இந்த மூடுதலைப் பயன்படுத்துகிறது, மேலும் அவற்றில் ஏதேனும் `true` ஐத் திருப்பினால், `find()` [`Some(element)`] ஐ வழங்குகிறது.
    /// அவர்கள் அனைவரும் `false` ஐத் திருப்பினால், அது [`None`] ஐ வழங்குகிறது.
    ///
    /// `find()` குறுகிய சுற்று;வேறு வார்த்தைகளில் கூறுவதானால், மூடல் `true` ஐ வழங்கியவுடன் செயலாக்கத்தை நிறுத்தும்.
    ///
    /// ஏனெனில் `find()` ஒரு குறிப்பை எடுத்துக்கொள்கிறது, மேலும் பல மறுபயன்பாட்டாளர்கள் குறிப்புகளை மீறிச் செல்கிறார்கள், இது வாதம் இரட்டைக் குறிப்பாக இருக்கும் குழப்பமான சூழ்நிலைக்கு வழிவகுக்கிறது.
    ///
    /// இந்த விளைவை கீழே உள்ள எடுத்துக்காட்டுகளில், `&&x` உடன் காணலாம்.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// முதல் `true` இல் நிறுத்துதல்:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // இன்னும் உறுப்புகள் இருப்பதால் நாம் இன்னும் `iter` ஐப் பயன்படுத்தலாம்.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)` என்பது `iter.filter(f).next()` க்கு சமம் என்பதை நினைவில் கொள்க.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// ஈரேட்டரின் உறுப்புகளுக்கு செயல்பாட்டைப் பயன்படுத்துகிறது மற்றும் முதல் இல்லாத முடிவை வழங்குகிறது.
    ///
    ///
    /// `iter.find_map(f)` இது `iter.filter_map(f).next()` க்கு சமம்.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// ஈரேட்டரின் உறுப்புகளுக்கு செயல்பாட்டைப் பயன்படுத்துகிறது மற்றும் முதல் உண்மையான முடிவு அல்லது முதல் பிழையை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// ஒரு ஈரேட்டரில் ஒரு உறுப்புக்கான தேடல்கள், அதன் குறியீட்டைத் தருகின்றன.
    ///
    /// `position()` `true` அல்லது `false` ஐ வழங்கும் ஒரு மூடல் எடுக்கும்.
    /// இது ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் இந்த மூடுதலைப் பயன்படுத்துகிறது, மேலும் அவற்றில் ஒன்று `true` ஐத் திருப்பினால், `position()` [`Some(index)`] ஐ வழங்குகிறது.
    /// அவை அனைத்தும் `false` ஐத் திருப்பினால், அது [`None`] ஐ வழங்குகிறது.
    ///
    /// `position()` குறுகிய சுற்று;வேறு வார்த்தைகளில் கூறுவதானால், இது ஒரு `true` ஐக் கண்டறிந்தவுடன் செயலாக்கத்தை நிறுத்திவிடும்.
    ///
    /// # வழிதல் நடத்தை
    ///
    /// இந்த வழி வழிதல் என்பதிலிருந்து பாதுகாக்காது, எனவே [`usize::MAX`] க்கு மேல் பொருந்தாத கூறுகள் இருந்தால், அது தவறான முடிவை அல்லது panics ஐ உருவாக்குகிறது.
    ///
    /// பிழைத்திருத்த வலியுறுத்தல்கள் இயக்கப்பட்டால், ஒரு panic உத்தரவாதம் அளிக்கப்படுகிறது.
    ///
    /// # Panics
    ///
    /// ஈரேட்டரில் `usize::MAX` க்கும் பொருந்தாத கூறுகள் இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கலாம்.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// முதல் `true` இல் நிறுத்துதல்:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // இன்னும் உறுப்புகள் இருப்பதால் நாம் இன்னும் `iter` ஐப் பயன்படுத்தலாம்.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // திரும்பிய குறியீட்டு ஐரேட்டர் நிலையைப் பொறுத்தது
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// வலதுபுறத்தில் இருந்து ஒரு ஈரேட்டரில் உள்ள ஒரு உறுப்புக்கான தேடல்கள், அதன் குறியீட்டைத் தருகின்றன.
    ///
    /// `rposition()` `true` அல்லது `false` ஐ வழங்கும் ஒரு மூடல் எடுக்கும்.
    /// இது முடிவில் இருந்து தொடங்கி, ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் இந்த மூடுதலைப் பயன்படுத்துகிறது, அவற்றில் ஒன்று `true` ஐத் திருப்பினால், `rposition()` [`Some(index)`] ஐ வழங்குகிறது.
    ///
    /// அவை அனைத்தும் `false` ஐத் திருப்பினால், அது [`None`] ஐ வழங்குகிறது.
    ///
    /// `rposition()` குறுகிய சுற்று;வேறு வார்த்தைகளில் கூறுவதானால், இது ஒரு `true` ஐக் கண்டறிந்தவுடன் செயலாக்கத்தை நிறுத்திவிடும்.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// முதல் `true` இல் நிறுத்துதல்:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // இன்னும் உறுப்புகள் இருப்பதால் நாம் இன்னும் `iter` ஐப் பயன்படுத்தலாம்.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // இங்கே ஒரு வழிதல் சோதனை தேவையில்லை, ஏனென்றால் `ExactSizeIterator` என்பது உறுப்புகளின் எண்ணிக்கை `usize` இல் பொருந்துகிறது என்பதைக் குறிக்கிறது.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// ஒரு செயலியின் அதிகபட்ச உறுப்பை வழங்குகிறது.
    ///
    /// பல கூறுகள் சமமாக அதிகபட்சமாக இருந்தால், கடைசி உறுப்பு திரும்பும்.
    /// ஈரேட்டர் காலியாக இருந்தால், [`None`] திரும்பும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// ஒரு செயலியின் குறைந்தபட்ச உறுப்பை வழங்குகிறது.
    ///
    /// பல கூறுகள் சமமாக குறைந்தபட்சமாக இருந்தால், முதல் உறுப்பு திரும்பும்.
    /// ஈரேட்டர் காலியாக இருந்தால், [`None`] திரும்பும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// குறிப்பிட்ட செயல்பாட்டிலிருந்து அதிகபட்ச மதிப்பைக் கொடுக்கும் உறுப்பை வழங்குகிறது.
    ///
    ///
    /// பல கூறுகள் சமமாக அதிகபட்சமாக இருந்தால், கடைசி உறுப்பு திரும்பும்.
    /// ஈரேட்டர் காலியாக இருந்தால், [`None`] திரும்பும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// குறிப்பிட்ட ஒப்பீட்டு செயல்பாட்டைப் பொறுத்து அதிகபட்ச மதிப்பைக் கொடுக்கும் உறுப்பை வழங்குகிறது.
    ///
    ///
    /// பல கூறுகள் சமமாக அதிகபட்சமாக இருந்தால், கடைசி உறுப்பு திரும்பும்.
    /// ஈரேட்டர் காலியாக இருந்தால், [`None`] திரும்பும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// குறிப்பிட்ட செயல்பாட்டிலிருந்து குறைந்தபட்ச மதிப்பைக் கொடுக்கும் உறுப்பை வழங்குகிறது.
    ///
    ///
    /// பல கூறுகள் சமமாக குறைந்தபட்சமாக இருந்தால், முதல் உறுப்பு திரும்பும்.
    /// ஈரேட்டர் காலியாக இருந்தால், [`None`] திரும்பும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// குறிப்பிட்ட ஒப்பீட்டு செயல்பாட்டைப் பொறுத்து குறைந்தபட்ச மதிப்பைக் கொடுக்கும் உறுப்பை வழங்குகிறது.
    ///
    ///
    /// பல கூறுகள் சமமாக குறைந்தபட்சமாக இருந்தால், முதல் உறுப்பு திரும்பும்.
    /// ஈரேட்டர் காலியாக இருந்தால், [`None`] திரும்பும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ஒரு செயலியின் திசையை மாற்றுகிறது.
    ///
    /// வழக்கமாக, இடரேட்டர்கள் இடமிருந்து வலமாக மீண்டும் செல்கின்றன.
    /// `rev()` ஐப் பயன்படுத்திய பிறகு, ஒரு ஈரேட்டர் அதற்கு பதிலாக வலமிருந்து இடமாகச் செல்லும்.
    ///
    /// ஈரேட்டருக்கு ஒரு முடிவு இருந்தால் மட்டுமே இது சாத்தியமாகும், எனவே `rev()` [`DoubleEndedIterator`] களில் மட்டுமே இயங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// ஜோடிகளின் மறு செய்கையை ஒரு ஜோடி கொள்கலன்களாக மாற்றுகிறது.
    ///
    /// `unzip()` ஜோடிகளின் முழு மறுசெயலாளரைப் பயன்படுத்துகிறது, இரண்டு தொகுப்புகளை உருவாக்குகிறது: ஒன்று ஜோடிகளின் இடது உறுப்புகளிலிருந்து, ஒன்று சரியான உறுப்புகளிலிருந்து.
    ///
    ///
    /// இந்த செயல்பாடு, ஒருவிதத்தில், [`zip`] க்கு எதிரானது.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// அதன் அனைத்து கூறுகளையும் நகலெடுக்கும் ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// உங்களிடம் `&T` க்கு மேல் ஒரு ஈரேட்டர் இருக்கும்போது இது பயனுள்ளதாக இருக்கும், ஆனால் உங்களுக்கு `T` க்கு மேல் ஒரு ஈரேட்டர் தேவை.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // நகலெடுக்கப்பட்டது .map(|&x| x) போன்றது
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// [`குளோன்`] அதன் அனைத்து கூறுகளையும் கொண்ட ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// உங்களிடம் `&T` க்கு மேல் ஒரு ஈரேட்டர் இருக்கும்போது இது பயனுள்ளதாக இருக்கும், ஆனால் உங்களுக்கு `T` க்கு மேல் ஒரு ஈரேட்டர் தேவை.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // குளோன் என்பது முழு எண்களுக்கு .map(|&x| x) போன்றது
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// ஒரு ஈரேட்டரை முடிவில்லாமல் மீண்டும் செய்கிறது.
    ///
    /// [`None`] இல் நிறுத்துவதற்குப் பதிலாக, மறுதொடக்கம் ஆரம்பத்தில் இருந்தே மீண்டும் தொடங்கும்.மீண்டும் மீண்டும் செய்த பிறகு, அது மீண்டும் தொடக்கத்தில் தொடங்கும்.மீண்டும்.
    /// மீண்டும்.
    /// Forever.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// ஒரு செயலியின் கூறுகளை தொகுக்கிறது.
    ///
    /// ஒவ்வொரு உறுப்புகளையும் எடுத்து, அவற்றை ஒன்றாகச் சேர்த்து, முடிவைத் தருகிறது.
    ///
    /// வெற்று ஈரேட்டர் வகையின் பூஜ்ஜிய மதிப்பை வழங்குகிறது.
    ///
    /// # Panics
    ///
    /// `sum()` ஐ அழைக்கும் போது மற்றும் ஒரு பழமையான முழு வகை திரும்பும்போது, கணக்கீடு வழிதல் மற்றும் பிழைத்திருத்த வலியுறுத்தல்கள் இயக்கப்பட்டால் இந்த முறை panic ஆக இருக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// அனைத்து உறுப்புகளையும் பெருக்கி, முழு மறு செய்கை மீதும் செயல்படுகிறது
    ///
    /// வெற்று ஈரேட்டர் வகையின் ஒரு மதிப்பை வழங்குகிறது.
    ///
    /// # Panics
    ///
    /// `product()` ஐ அழைக்கும் போது மற்றும் ஒரு பழமையான முழு வகை திரும்பும்போது, கணக்கீடு நிரம்பி வழிகிறது மற்றும் பிழைத்திருத்த வலியுறுத்தல்கள் இயக்கப்பட்டால் முறை panic ஆகும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) இந்த [`Iterator`] இன் கூறுகளை மற்றொன்றுடன் ஒப்பிடுகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) இந்த [`Iterator`] இன் கூறுகளை மற்றொரு ஒப்பீட்டு செயல்பாட்டுடன் ஒப்பிடுகிறது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) இந்த [`Iterator`] இன் கூறுகளை மற்றொன்றுடன் ஒப்பிடுகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) இந்த [`Iterator`] இன் கூறுகளை மற்றொரு ஒப்பீட்டு செயல்பாட்டுடன் ஒப்பிடுகிறது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// இந்த [`Iterator`] இன் கூறுகள் மற்றொன்றுக்கு சமமாக இருக்கிறதா என்பதை தீர்மானிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// இந்த [`Iterator`] இன் கூறுகள் குறிப்பிட்ட சமத்துவ செயல்பாட்டைப் பொறுத்தவரை மற்றொன்றுக்கு சமமாக இருக்கிறதா என்பதை தீர்மானிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// இந்த [`Iterator`] இன் கூறுகள் மற்றொன்றுக்கு சமமற்றதா என்பதை தீர்மானிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// இந்த [`Iterator`] இன் கூறுகள் மற்றொன்றை விட [lexicographically](Ord#lexicographical-comparison) குறைவாக இருந்தால் தீர்மானிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// இந்த [`Iterator`] இன் கூறுகள் [lexicographically](Ord#lexicographical-comparison) குறைவாகவோ அல்லது இன்னொருவருக்கு சமமாகவோ இருக்கிறதா என்பதை தீர்மானிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// இந்த [`Iterator`] இன் கூறுகள் மற்றொன்றை விட [lexicographically](Ord#lexicographical-comparison) அதிகமாக இருந்தால் தீர்மானிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// இந்த [`Iterator`] இன் கூறுகள் [lexicographically](Ord#lexicographical-comparison) மற்றொன்றை விட அதிகமாகவோ அல்லது சமமாகவோ இருக்கிறதா என்பதை தீர்மானிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// இந்த செயலியின் கூறுகள் வரிசைப்படுத்தப்பட்டதா என சரிபார்க்கிறது.
    ///
    /// அதாவது, ஒவ்வொரு உறுப்பு `a` க்கும் அதன் பின்வரும் உறுப்பு `b` க்கும், `a <= b` வைத்திருக்க வேண்டும்.ஈரேட்டர் சரியாக பூஜ்ஜியம் அல்லது ஒரு உறுப்பை அளித்தால், `true` திரும்பும்.
    ///
    /// `Self::Item` என்பது `PartialOrd` மட்டுமே, ஆனால் `Ord` அல்ல எனில், மேலே உள்ள வரையறை, தொடர்ச்சியான இரண்டு உருப்படிகளையும் ஒப்பிட முடியாவிட்டால் இந்த செயல்பாடு `false` ஐ வழங்குகிறது என்பதைக் குறிக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// கொடுக்கப்பட்ட ஒப்பீட்டாளர் செயல்பாட்டைப் பயன்படுத்தி இந்த செயலியின் கூறுகள் வரிசைப்படுத்தப்பட்டிருக்கிறதா என சரிபார்க்கிறது.
    ///
    /// `PartialOrd::partial_cmp` ஐப் பயன்படுத்துவதற்குப் பதிலாக, இந்த செயல்பாடு இரண்டு உறுப்புகளின் வரிசையை தீர்மானிக்க கொடுக்கப்பட்ட `compare` செயல்பாட்டைப் பயன்படுத்துகிறது.
    /// அது தவிர, இது [`is_sorted`] க்கு சமம்;மேலும் தகவலுக்கு அதன் ஆவணங்களைப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// கொடுக்கப்பட்ட விசை பிரித்தெடுத்தல் செயல்பாட்டைப் பயன்படுத்தி இந்த ஈரேட்டரின் கூறுகள் வரிசைப்படுத்தப்பட்டிருக்கிறதா என சரிபார்க்கிறது.
    ///
    /// ஈரேட்டரின் கூறுகளை நேரடியாக ஒப்பிடுவதற்கு பதிலாக, இந்த செயல்பாடு `f` ஆல் நிர்ணயிக்கப்பட்டபடி, உறுப்புகளின் விசைகளை ஒப்பிடுகிறது.
    /// அது தவிர, இது [`is_sorted`] க்கு சமம்;மேலும் தகவலுக்கு அதன் ஆவணங்களைப் பார்க்கவும்.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] ஐப் பார்க்கவும்
    // முறை தீர்மானத்தில் பெயர் மோதல்களைத் தவிர்ப்பதே அசாதாரண பெயர் #76479 ஐப் பார்க்கவும்.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}