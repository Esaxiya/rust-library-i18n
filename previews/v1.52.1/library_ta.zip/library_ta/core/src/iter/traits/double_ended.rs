use crate::ops::{ControlFlow, Try};

/// இரு முனைகளிலிருந்தும் உறுப்புகளை வழங்கக்கூடிய ஒரு ஈரேட்டர்.
///
/// `DoubleEndedIterator` ஐ செயல்படுத்தும் ஏதோவொன்று [`Iterator`] ஐ செயல்படுத்தும் ஒரு கூடுதல் திறனைக் கொண்டுள்ளது: `உருப்படி'களை பின்புறத்திலிருந்து எடுக்கும் திறனையும், முன்பக்கத்தையும்.
///
///
/// முன்னும் பின்னுமாக ஒரே வரம்பில் வேலை செய்கின்றன, அவற்றைக் கடக்க வேண்டாம் என்பதைக் கவனத்தில் கொள்ள வேண்டியது அவசியம்: அவை நடுவில் சந்திக்கும் போது மறு செய்கை முடிந்துவிடும்.
///
/// [`Iterator`] நெறிமுறைக்கு ஒத்த பாணியில், ஒரு `DoubleEndedIterator` ஒரு [`next_back()`] இலிருந்து [`None`] ஐ திருப்பி அளித்தவுடன், அதை மீண்டும் அழைப்பது [`Some`] ஐ மீண்டும் கொடுக்காது அல்லது திரும்ப வரக்கூடாது.
/// [`next()`] மற்றும் [`next_back()`] இந்த நோக்கத்திற்காக ஒன்றுக்கொன்று மாறக்கூடியவை.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// ஈரேட்டரின் முடிவில் இருந்து ஒரு உறுப்பை அகற்றி திருப்பித் தருகிறது.
    ///
    /// கூடுதல் கூறுகள் இல்லாதபோது `None` ஐ வழங்குகிறது.
    ///
    /// [trait-level] டாக்ஸில் கூடுதல் விவரங்கள் உள்ளன.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEndedIterator` இன் முறைகளால் வழங்கப்படும் கூறுகள் [`Iterator`] இன் முறைகளால் வழங்கப்பட்டவற்றிலிருந்து வேறுபடலாம்:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` உறுப்புகளால் பின்புறத்திலிருந்து ஈரேட்டரை முன்னேற்றுகிறது.
    ///
    /// `advance_back_by` [`advance_by`] இன் தலைகீழ் பதிப்பு.இந்த முறை `n` உறுப்புகளை பின்னால் இருந்து தொடங்கி [`next_back`] ஐ `n` வரை `n` வரை அழைப்பதன் மூலம் [`None`] எதிர்கொள்ளும் வரை ஆவலுடன் தவிர்க்கும்.
    ///
    /// `advance_back_by(n)` `n` உறுப்புகளால் ஈரேட்டர் வெற்றிகரமாக முன்னேறினால் [`Ok(())`] ஐ திருப்பித் தரும், அல்லது [`None`] எதிர்கொண்டால் [`Err(k)`], இங்கு `k` என்பது உறுப்புகள் வெளியேறும் முன் ஈரேட்டர் முன்னேறும் உறுப்புகளின் எண்ணிக்கை (அதாவது
    /// ஈரேட்டரின் நீளம்).
    /// `k` எப்போதும் `n` ஐ விட குறைவாக இருக்கும் என்பதை நினைவில் கொள்க.
    ///
    /// `advance_back_by(0)` ஐ அழைப்பது எந்த உறுப்புகளையும் நுகராது, எப்போதும் [`Ok(())`] ஐ வழங்குகிறது.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` மட்டுமே தவிர்க்கப்பட்டது
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// ஈரேட்டரின் முடிவில் இருந்து `n` வது உறுப்பை வழங்குகிறது.
    ///
    /// இது அடிப்படையில் [`Iterator::nth()`] இன் தலைகீழ் பதிப்பாகும்.
    /// பெரும்பாலான குறியீட்டு செயல்பாடுகளைப் போலவே, எண்ணிக்கை பூஜ்ஜியத்திலிருந்து தொடங்குகிறது, எனவே `nth_back(0)` முதல் மதிப்பை முடிவிலிருந்து, `nth_back(1)` இரண்டாவது, மற்றும் பலவற்றைத் தருகிறது.
    ///
    ///
    /// திரும்பிய உறுப்பு உட்பட, முடிவுக்கும் திரும்பிய உறுப்புக்கும் இடையிலான அனைத்து கூறுகளும் நுகரப்படும் என்பதை நினைவில் கொள்க.
    /// ஒரே ஐரேட்டரில் `nth_back(0)` ஐ பல முறை அழைப்பது வெவ்வேறு கூறுகளைத் தரும் என்பதும் இதன் பொருள்.
    ///
    /// `nth_back()` `n` ஐரேட்டரின் நீளத்தை விட அதிகமாகவோ அல்லது சமமாகவோ இருந்தால் [`None`] ஐ வழங்கும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` ஐ பல முறை அழைப்பது ஈரேட்டரை முன்னாடி விடாது:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1` க்கும் குறைவான கூறுகள் இருந்தால் `None` ஐத் தருகிறது:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// இது [`Iterator::try_fold()`] இன் தலைகீழ் பதிப்பு: இது ஈரேட்டரின் பின்புறத்திலிருந்து தொடங்கும் கூறுகளை எடுக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // இது குறுகிய சுற்று என்பதால், மீதமுள்ள கூறுகள் இன்னும் ஈரேட்டர் மூலம் கிடைக்கின்றன.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// பின்புறத்திலிருந்து தொடங்கி, ஒற்றை, இறுதி மதிப்பாக ஈரேட்டரின் கூறுகளைக் குறைக்கும் ஒரு ஈரேட்டர் முறை.
    ///
    /// இது [`Iterator::fold()`] இன் தலைகீழ் பதிப்பு: இது ஈரேட்டரின் பின்புறத்திலிருந்து தொடங்கும் கூறுகளை எடுக்கும்.
    ///
    /// `rfold()` இரண்டு வாதங்களை எடுக்கிறது: ஒரு ஆரம்ப மதிப்பு, மற்றும் இரண்டு வாதங்களுடன் ஒரு மூடல்: ஒரு 'accumulator' மற்றும் ஒரு உறுப்பு.
    /// மூடல் அடுத்த மறு செய்கைக்கு குவிப்பான் வைத்திருக்க வேண்டிய மதிப்பை வழங்குகிறது.
    ///
    /// ஆரம்ப மதிப்பு என்பது முதல் அழைப்பில் குவிப்பான் வைத்திருக்கும் மதிப்பு.
    ///
    /// ஈரேட்டரின் ஒவ்வொரு உறுப்புக்கும் இந்த மூடுதலைப் பயன்படுத்திய பிறகு, `rfold()` குவிப்பானைத் தருகிறது.
    ///
    /// இந்த செயல்பாடு சில நேரங்களில் 'reduce' அல்லது 'inject' என அழைக்கப்படுகிறது.
    ///
    /// உங்களிடம் ஏதாவது ஒரு தொகுப்பு இருக்கும் போதெல்லாம் மடிப்பு பயனுள்ளதாக இருக்கும், மேலும் அதிலிருந்து ஒரு மதிப்பை உருவாக்க விரும்புகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a இன் அனைத்து உறுப்புகளின் கூட்டுத்தொகை
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// இந்த எடுத்துக்காட்டு ஒரு சரத்தை உருவாக்குகிறது, இது ஒரு ஆரம்ப மதிப்பில் தொடங்கி ஒவ்வொரு உறுப்பையும் பின்புறத்திலிருந்து முன் வரை தொடர்கிறது:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// முன்னறிவிப்பை திருப்திப்படுத்தும் பின்புறத்திலிருந்து ஒரு ஈரேட்டரின் உறுப்புக்கான தேடல்கள்.
    ///
    /// `rfind()` `true` அல்லது `false` ஐ வழங்கும் ஒரு மூடல் எடுக்கும்.
    /// இது துவக்கத்தின் ஒவ்வொரு உறுப்புக்கும் பொருந்தும், இறுதியில் தொடங்கி, அவற்றில் ஏதேனும் `true` ஐத் திருப்பினால், `rfind()` [`Some(element)`] ஐ வழங்குகிறது.
    /// அவர்கள் அனைவரும் `false` ஐத் திருப்பினால், அது [`None`] ஐ வழங்குகிறது.
    ///
    /// `rfind()` குறுகிய சுற்று;வேறு வார்த்தைகளில் கூறுவதானால், மூடல் `true` ஐ வழங்கியவுடன் செயலாக்கத்தை நிறுத்தும்.
    ///
    /// ஏனெனில் `rfind()` ஒரு குறிப்பை எடுத்துக்கொள்கிறது, மேலும் பல மறுபயன்பாட்டாளர்கள் குறிப்புகளை மீறிச் செல்கிறார்கள், இது வாதம் இரட்டைக் குறிப்பாக இருக்கும் குழப்பமான சூழ்நிலைக்கு வழிவகுக்கிறது.
    ///
    /// இந்த விளைவை கீழே உள்ள எடுத்துக்காட்டுகளில், `&&x` உடன் காணலாம்.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// முதல் `true` இல் நிறுத்துதல்:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // இன்னும் உறுப்புகள் இருப்பதால் நாம் இன்னும் `iter` ஐப் பயன்படுத்தலாம்.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}