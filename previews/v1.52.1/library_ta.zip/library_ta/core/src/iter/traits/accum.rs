use crate::iter;
use crate::num::Wrapping;

/// ஒரு செயலியைச் சுருக்கி உருவாக்குவதன் மூலம் உருவாக்கக்கூடிய வகைகளைக் குறிக்க Trait.
///
/// இந்த trait ஐரேட்டர்களில் [`sum()`] முறையை செயல்படுத்த பயன்படுகிறது.
/// trait ஐ செயல்படுத்தும் வகைகள் [`sum()`] முறையால் உருவாக்கப்படலாம்.
/// [`FromIterator`] ஐப் போலவே இந்த trait ஐ அரிதாகவே நேரடியாக அழைக்க வேண்டும், அதற்கு பதிலாக [`Iterator::sum()`] மூலம் தொடர்பு கொள்ள வேண்டும்.
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// ஒரு ஈரேட்டரை எடுத்து, "summing up" உருப்படிகளால் உறுப்புகளிலிருந்து `Self` ஐ உருவாக்கும் முறை.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// ஒரு செயலியின் கூறுகளை பெருக்கி உருவாக்கக்கூடிய வகைகளைக் குறிக்க Trait.
///
/// இந்த trait ஐரேட்டர்களில் [`product()`] முறையை செயல்படுத்த பயன்படுகிறது.
/// trait ஐ செயல்படுத்தும் வகைகள் [`product()`] முறையால் உருவாக்கப்படலாம்.
/// [`FromIterator`] ஐப் போலவே இந்த trait ஐ அரிதாகவே நேரடியாக அழைக்க வேண்டும், அதற்கு பதிலாக [`Iterator::product()`] மூலம் தொடர்பு கொள்ள வேண்டும்.
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// உருப்படிகளை பெருக்கி, உறுப்புகளிலிருந்து `Self` ஐ உருவாக்கும் முறை.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// [`Iterator`] இல் உள்ள ஒவ்வொரு உறுப்புகளையும் எடுக்கிறது: இது ஒரு [`Err`] ஆக இருந்தால், கூடுதல் கூறுகள் எதுவும் எடுக்கப்படவில்லை, மேலும் [`Err`] திரும்பப் பெறப்படுகிறது.
    /// [`Err`] எதுவும் ஏற்படக்கூடாது என்றால், எல்லா உறுப்புகளின் கூட்டுத்தொகையும் திருப்பித் தரப்படும்.
    ///
    /// # Examples
    ///
    /// இது ஒரு vector இல் உள்ள ஒவ்வொரு முழு எண்ணையும் தொகுக்கிறது, எதிர்மறை உறுப்பு ஏற்பட்டால் தொகையை நிராகரிக்கிறது:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// [`Iterator`] இல் உள்ள ஒவ்வொரு உறுப்புகளையும் எடுக்கிறது: இது ஒரு [`Err`] ஆக இருந்தால், கூடுதல் கூறுகள் எதுவும் எடுக்கப்படவில்லை, மேலும் [`Err`] திரும்பப் பெறப்படுகிறது.
    /// [`Err`] எதுவும் ஏற்படக்கூடாது என்றால், எல்லா உறுப்புகளின் தயாரிப்பு திரும்பும்.
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// [`Iterator`] இல் உள்ள ஒவ்வொரு உறுப்புகளையும் எடுக்கிறது: இது ஒரு [`None`] ஆக இருந்தால், கூடுதல் கூறுகள் எதுவும் எடுக்கப்படவில்லை, மேலும் [`None`] திரும்பப் பெறப்படுகிறது.
    /// [`None`] எதுவும் ஏற்படக்கூடாது என்றால், எல்லா உறுப்புகளின் கூட்டுத்தொகையும் திருப்பித் தரப்படும்.
    ///
    /// # Examples
    ///
    /// இது ஒரு vector சரங்களில் 'a' எழுத்தின் நிலையை சுருக்கமாகக் கூறுகிறது, ஒரு வார்த்தைக்கு 'a' எழுத்து இல்லை என்றால் செயல்பாடு `None` ஐ வழங்குகிறது:
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// [`Iterator`] இல் உள்ள ஒவ்வொரு உறுப்புகளையும் எடுக்கிறது: இது ஒரு [`None`] ஆக இருந்தால், கூடுதல் கூறுகள் எதுவும் எடுக்கப்படவில்லை, மேலும் [`None`] திரும்பப் பெறப்படுகிறது.
    /// [`None`] எதுவும் ஏற்படக்கூடாது என்றால், எல்லா உறுப்புகளின் தயாரிப்பு திரும்பும்.
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}