//! வகைகளுக்கு இடையிலான மாற்றங்களுக்கு Traits.
//!
//! இந்த தொகுதியில் உள்ள traits ஒரு வகையிலிருந்து மற்றொரு வகைக்கு மாற்றுவதற்கான வழியை வழங்குகிறது.
//! ஒவ்வொரு trait வேறுபட்ட நோக்கத்திற்கு உதவுகிறது:
//!
//! - மலிவான குறிப்பு-க்கு-குறிப்பு மாற்றங்களுக்கு [`AsRef`] trait ஐ செயல்படுத்தவும்
//! - மலிவான மாற்றக்கூடிய-மாற்றக்கூடிய மாற்றங்களுக்கு [`AsMut`] trait ஐ செயல்படுத்தவும்
//! - மதிப்பு-க்கு-மதிப்பு மாற்றங்களை உட்கொள்வதற்கு [`From`] trait ஐ செயல்படுத்தவும்
//! - தற்போதைய crate க்கு வெளியே உள்ள வகைகளுக்கு மதிப்பு-க்கு-மதிப்பு மாற்றங்களை உட்கொள்வதற்கு [`Into`] trait ஐ செயல்படுத்தவும்
//! - [`TryFrom`] மற்றும் [`TryInto`] traits [`From`] மற்றும் [`Into`] போல செயல்படுகின்றன, ஆனால் மாற்றம் தோல்வியடையும் போது செயல்படுத்தப்பட வேண்டும்.
//!
//! இந்த தொகுதியில் உள்ள traits பெரும்பாலும் பொதுவான செயல்பாடுகளுக்கு trait bounds ஆகப் பயன்படுத்தப்படுகிறது, இது பல வகைகளின் வாதங்களுக்கு துணைபுரிகிறது.எடுத்துக்காட்டுகளுக்கு ஒவ்வொரு trait இன் ஆவணங்களையும் காண்க.
//!
//! ஒரு நூலக ஆசிரியராக, நீங்கள் எப்போதும் [`Into<U>`][`Into`] அல்லது [`TryInto<U>`][`TryInto`] ஐ விட [`From<T>`][`From`] அல்லது [`TryFrom<T>`][`TryFrom`] ஐ செயல்படுத்த விரும்புகிறீர்கள், ஏனெனில் [`From`] மற்றும் [`TryFrom`] ஆகியவை அதிக நெகிழ்வுத்தன்மையை வழங்குகின்றன மற்றும் சமமான [`Into`] அல்லது [`TryInto`] செயலாக்கங்களை இலவசமாக வழங்குகின்றன, நிலையான நூலகத்தில் ஒரு போர்வை செயல்படுத்தலுக்கு நன்றி.
//! Rust 1.41 க்கு முன் ஒரு பதிப்பைக் குறிவைக்கும்போது, தற்போதைய crate க்கு வெளியே ஒரு வகைக்கு மாற்றும்போது நேரடியாக [`Into`] அல்லது [`TryInto`] ஐ செயல்படுத்த வேண்டியது அவசியம்.
//!
//! # பொதுவான நடைமுறைகள்
//!
//! - [`AsRef`] மற்றும் உள் வகை ஒரு குறிப்பாக இருந்தால் [`AsMut`] தானாக-விலகல்
//! - [`இருந்து`]`<U>க்கு T` என்பது [`க்குள்]] குறிக்கிறது</u><T><U>U` க்கு</u>
//! - [`ட்ரைஃப்ரோம்`]`<U>என்பது டி` என்பதற்கு குறிக்கிறது [`ட்ரைன்டோ`]`</u><T><U>U` க்கு</u>
//! - [`From`] மற்றும் [`Into`] ஆகியவை நிர்பந்தமானவை, அதாவது எல்லா வகைகளும் தங்களை `into` மற்றும் `from` தங்களைத் தாங்களே உருவாக்க முடியும்
//!
//! பயன்பாட்டு எடுத்துக்காட்டுகளுக்கு ஒவ்வொரு trait ஐப் பார்க்கவும்.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// அடையாள செயல்பாடு.
///
/// இந்த செயல்பாட்டைப் பற்றி கவனிக்க இரண்டு விஷயங்கள் முக்கியம்:
///
/// - இது எப்போதும் `|x| x` போன்ற மூடுதலுக்கு சமமானதல்ல, ஏனெனில் மூடல் `x` ஐ வேறு வகைக்கு கட்டாயப்படுத்தக்கூடும்.
///
/// - இது செயல்பாட்டிற்கு அனுப்பப்பட்ட உள்ளீடு `x` ஐ நகர்த்துகிறது.
///
/// உள்ளீட்டைத் திருப்பித் தரும் ஒரு செயல்பாட்டைக் கொண்டிருப்பது விசித்திரமாகத் தோன்றினாலும், சில சுவாரஸ்யமான பயன்கள் உள்ளன.
///
///
/// # Examples
///
/// பிற, சுவாரஸ்யமான, செயல்பாடுகளின் வரிசையில் எதுவும் செய்ய `identity` ஐப் பயன்படுத்துதல்:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // ஒன்றைச் சேர்ப்பது ஒரு சுவாரஸ்யமான செயல்பாடு என்று பாசாங்கு செய்வோம்.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// நிபந்தனையில் `identity` ஐ "do nothing" அடிப்படை வழக்காகப் பயன்படுத்துதல்:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // மேலும் சுவாரஸ்யமான விஷயங்களைச் செய்யுங்கள் ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` இன் மறு செய்கையின் `Some` வகைகளை வைத்திருக்க `identity` ஐப் பயன்படுத்துதல்:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// மலிவான குறிப்பு-க்கு-குறிப்பு மாற்றத்தை செய்யப் பயன்படுகிறது.
///
/// இந்த trait என்பது [`AsMut`] ஐப் போன்றது, இது மாற்றத்தக்க குறிப்புகளுக்கு இடையில் மாற்ற பயன்படுகிறது.
/// நீங்கள் ஒரு விலையுயர்ந்த மாற்றத்தை செய்ய வேண்டுமானால், [`From`] ஐ `&T` வகைடன் செயல்படுத்துவது அல்லது தனிப்பயன் செயல்பாட்டை எழுதுவது நல்லது.
///
/// `AsRef` [`Borrow`] போன்ற அதே கையொப்பத்தைக் கொண்டுள்ளது, ஆனால் [`Borrow`] சில அம்சங்களில் வேறுபட்டது:
///
/// - `AsRef` போலல்லாமல், [`Borrow`] எந்த `T` க்கும் ஒரு போர்வை impl ஐக் கொண்டுள்ளது, மேலும் இது ஒரு குறிப்பு அல்லது மதிப்பை ஏற்க பயன்படுகிறது.
/// - [`Borrow`] கடன் வாங்கிய மதிப்பிற்கான [`Hash`], [`Eq`] மற்றும் [`Ord`] ஆகியவை சொந்தமான மதிப்புக்கு சமமானதாக இருக்க வேண்டும்.
/// இந்த காரணத்திற்காக, நீங்கள் ஒரு கட்டமைப்பின் ஒரு துறையை மட்டுமே கடன் வாங்க விரும்பினால், நீங்கள் `AsRef` ஐ செயல்படுத்தலாம், ஆனால் [`Borrow`] அல்ல.
///
/// **Note: இந்த trait தோல்வியடையக்கூடாது **.மாற்றம் தோல்வியடைந்தால், ஒரு பிரத்யேக முறையைப் பயன்படுத்தவும், இது [`Option<T>`] அல்லது [`Result<T, E>`] ஐ வழங்குகிறது.
///
/// # பொதுவான நடைமுறைகள்
///
/// - `AsRef` உள் வகை ஒரு குறிப்பு அல்லது மாற்றக்கூடிய குறிப்பு என்றால் தானாக-விலகல்கள் (எ.கா.: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds ஐப் பயன்படுத்துவதன் மூலம், வெவ்வேறு வகை வாதங்களை குறிப்பிட்ட வகை `T` க்கு மாற்றும் வரை அவற்றை ஏற்றுக்கொள்ளலாம்.
///
/// எடுத்துக்காட்டாக: ஒரு `AsRef<str>` எடுக்கும் பொதுவான செயல்பாட்டை உருவாக்குவதன் மூலம், [`&str`] ஆக மாற்றக்கூடிய அனைத்து குறிப்புகளையும் ஒரு வாதமாக ஏற்க விரும்புகிறோம் என்பதை வெளிப்படுத்துகிறோம்.
/// [`String`] மற்றும் [`&str`] இரண்டும் `AsRef<str>` ஐ செயல்படுத்துவதால், இரண்டையும் உள்ளீட்டு வாதமாக ஏற்றுக்கொள்ளலாம்.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// மாற்றத்தை செய்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// மலிவான மாற்றக்கூடிய-மாற்றக்கூடிய குறிப்பு மாற்றத்தை செய்யப் பயன்படுகிறது.
///
/// இந்த trait [`AsRef`] ஐ ஒத்திருக்கிறது, ஆனால் மாற்றக்கூடிய குறிப்புகளுக்கு இடையில் மாற்ற பயன்படுகிறது.
/// நீங்கள் ஒரு விலையுயர்ந்த மாற்றத்தை செய்ய வேண்டுமானால், [`From`] ஐ `&mut T` வகைடன் செயல்படுத்துவது அல்லது தனிப்பயன் செயல்பாட்டை எழுதுவது நல்லது.
///
/// **Note: இந்த trait தோல்வியடையக்கூடாது **.மாற்றம் தோல்வியடைந்தால், ஒரு பிரத்யேக முறையைப் பயன்படுத்தவும், இது [`Option<T>`] அல்லது [`Result<T, E>`] ஐ வழங்குகிறது.
///
/// # பொதுவான நடைமுறைகள்
///
/// - `AsMut` உள் வகை ஒரு மாற்றக்கூடிய குறிப்பு என்றால் தானாக-விலகல்கள் (எ.கா.: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// ஒரு பொதுவான செயல்பாட்டிற்காக `AsMut` ஐ trait bound ஆகப் பயன்படுத்துவதால், `&mut T` வகையாக மாற்றக்கூடிய அனைத்து மாற்றத்தக்க குறிப்புகளையும் நாம் ஏற்றுக்கொள்ளலாம்.
/// [`Box<T>`] `AsMut<T>` ஐ செயல்படுத்துவதால், `add_one` என்ற செயல்பாட்டை எழுதலாம், இது `&mut u64` ஆக மாற்றக்கூடிய அனைத்து வாதங்களையும் எடுக்கும்.
/// [`Box<T>`] `AsMut<T>` ஐ செயல்படுத்துவதால், `add_one` வகை `&mut Box<u64>` இன் வாதங்களையும் ஏற்றுக்கொள்கிறது:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// மாற்றத்தை செய்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// உள்ளீட்டு மதிப்பைப் பயன்படுத்தும் மதிப்பு-க்கு-மதிப்பு மாற்றம்.[`From`] க்கு நேர் எதிரானது.
///
/// ஒருவர் [`Into`] ஐ செயல்படுத்துவதைத் தவிர்த்து, அதற்கு பதிலாக [`From`] ஐ செயல்படுத்த வேண்டும்.
/// [`From`] ஐ தானாக செயல்படுத்துவது நிலையான நூலகத்தில் போர்வை செயல்படுத்தலுக்கு [`Into`] நன்றி ஒன்றை செயல்படுத்துகிறது.
///
/// [`Into`] ஐ மட்டுமே செயல்படுத்தும் வகைகளையும் பயன்படுத்த முடியும் என்பதை உறுதிப்படுத்த ஒரு பொதுவான செயல்பாட்டில் trait bounds ஐ குறிப்பிடும்போது [`From`] ஐ விட [`Into`] ஐப் பயன்படுத்தவும்.
///
/// **Note: இந்த trait தோல்வியடையக்கூடாது **.மாற்றம் தோல்வியடைந்தால், [`TryInto`] ஐப் பயன்படுத்தவும்.
///
/// # பொதுவான நடைமுறைகள்
///
/// - [`இருந்து`]`<T>U` என்பது `Into<U> for T` ஐ குறிக்கிறது
/// - [`Into`] பிரதிபலிப்பு, அதாவது `Into<T> for T` செயல்படுத்தப்படுகிறது
///
/// # Rust இன் பழைய பதிப்புகளில் வெளிப்புற வகைகளுக்கு மாற்ற [`Into`] ஐ செயல்படுத்துகிறது
///
/// Rust 1.41 க்கு முன்பு, இலக்கு வகை தற்போதைய crate இன் பகுதியாக இல்லாவிட்டால், நீங்கள் [`From`] ஐ நேரடியாக செயல்படுத்த முடியாது.
/// எடுத்துக்காட்டாக, இந்த குறியீட்டை எடுத்துக் கொள்ளுங்கள்:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// இது மொழியின் பழைய பதிப்புகளில் தொகுக்கத் தவறிவிடும், ஏனெனில் Rust இன் அனாதை விதிகள் இன்னும் கொஞ்சம் கண்டிப்பாக இருக்கும்.
/// இதைத் தவிர்க்க, நீங்கள் நேரடியாக [`Into`] ஐ செயல்படுத்தலாம்:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// [`Into`] ஒரு [`From`] செயல்படுத்தலை வழங்காது என்பதை புரிந்து கொள்ள வேண்டியது அவசியம் ([`From`] [`Into`] உடன் செய்வது போல).
/// எனவே, நீங்கள் எப்போதும் [`From`] ஐ செயல்படுத்த முயற்சிக்க வேண்டும், பின்னர் [`From`] ஐ செயல்படுத்த முடியாவிட்டால் [`Into`] க்கு திரும்பவும்.
///
/// # Examples
///
/// [`String`] செயல்படுத்துகிறது [`உள்ளே`]`<`[`வெக்`] `<` [`u8`]`>>`:
///
/// ஒரு குறிப்பிட்ட வகை `T` க்கு மாற்றக்கூடிய அனைத்து வாதங்களையும் ஒரு பொதுவான செயல்பாடு எடுக்க விரும்புகிறோம் என்பதை வெளிப்படுத்த, [`Into`]`இன் trait bound ஐப் பயன்படுத்தலாம்.<T>`.
///
/// எடுத்துக்காட்டாக: `is_hello` செயல்பாடு [`Vec`]`<`[`u8`] `>` ஆக மாற்றக்கூடிய அனைத்து வாதங்களையும் எடுக்கும்.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// மாற்றத்தை செய்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// உள்ளீட்டு மதிப்பை நுகரும் போது மதிப்பு-க்கு-மதிப்பு மாற்றங்களைச் செய்யப் பயன்படுகிறது.இது [`Into`] இன் பரஸ்பரமாகும்.
///
/// [`Into`] ஐ விட `From` ஐ செயல்படுத்துவதை ஒருவர் எப்போதும் விரும்ப வேண்டும், ஏனெனில் `From` ஐ தானாக செயல்படுத்துவது நிலையான நூலகத்தில் போர்வை செயல்படுத்தலுக்கு [`Into`] நன்றி ஒன்றை செயல்படுத்துகிறது.
///
///
/// Rust 1.41 க்கு முன் ஒரு பதிப்பைக் குறிவைத்து, தற்போதைய crate க்கு வெளியே ஒரு வகைக்கு மாற்றும்போது மட்டுமே [`Into`] ஐ செயல்படுத்தவும்.
/// `From` Rust இன் அனாதை விதிகளின் காரணமாக முந்தைய பதிப்புகளில் இந்த வகை மாற்றங்களைச் செய்ய முடியவில்லை.
/// மேலும் விவரங்களுக்கு [`Into`] ஐப் பார்க்கவும்.
///
/// ஒரு பொதுவான செயல்பாட்டில் trait bounds ஐக் குறிப்பிடும்போது `From` ஐப் பயன்படுத்துவதற்கு [`Into`] ஐப் பயன்படுத்தவும்.
/// இந்த வழியில், [`Into`] ஐ நேரடியாக செயல்படுத்தும் வகைகளையும் வாதங்களாகப் பயன்படுத்தலாம்.
///
/// பிழை கையாளுதலின் போது `From` மிகவும் பயனுள்ளதாக இருக்கும்.தோல்வியடையும் திறன் கொண்ட ஒரு செயல்பாட்டை உருவாக்கும்போது, திரும்பும் வகை பொதுவாக `Result<T, E>` வடிவத்தில் இருக்கும்.
/// `From` trait பல பிழை வகைகளை இணைக்கும் ஒற்றை பிழை வகையை திருப்பி அனுப்ப ஒரு செயல்பாட்டை அனுமதிப்பதன் மூலம் பிழை கையாளுதலை எளிதாக்குகிறது.மேலும் விவரங்களுக்கு "Examples" பிரிவு மற்றும் [the book][book] ஐப் பார்க்கவும்.
///
/// **Note: இந்த trait தோல்வியடையக்கூடாது **.மாற்றம் தோல்வியடைந்தால், [`TryFrom`] ஐப் பயன்படுத்தவும்.
///
/// # பொதுவான நடைமுறைகள்
///
/// - `From<T> for U` குறிக்கிறது [`Into`]`<U>T` க்கான</u>
/// - `From` பிரதிபலிப்பு, அதாவது `From<T> for T` செயல்படுத்தப்படுகிறது
///
/// # Examples
///
/// [`String`] `From<&str>` ஐ செயல்படுத்துகிறது:
///
/// ஒரு `&str` இலிருந்து ஒரு சரத்திற்கு வெளிப்படையான மாற்றம் பின்வருமாறு செய்யப்படுகிறது:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// பிழை கையாளுதலைச் செய்யும்போது, உங்கள் சொந்த பிழை வகைக்கு `From` ஐ செயல்படுத்த பெரும்பாலும் பயனுள்ளதாக இருக்கும்.
/// அடிப்படை பிழை வகைகளை எங்கள் சொந்த தனிப்பயன் பிழை வகையாக மாற்றுவதன் மூலம், அடிப்படை பிழை வகையை இணைக்கிறது, அடிப்படை காரணம் குறித்த தகவலை இழக்காமல் ஒரு பிழை வகையை நாங்கள் திரும்பப் பெறலாம்.
/// '?' ஆபரேட்டர் `Into<CliError>::into` ஐ அழைப்பதன் மூலம் அடிப்படை பிழை வகையை தானாகவே எங்கள் தனிப்பயன் பிழை வகையாக மாற்றுகிறது, இது `From` ஐ செயல்படுத்தும்போது தானாக வழங்கப்படுகிறது.
/// `Into` இன் எந்த செயலாக்கத்தைப் பயன்படுத்த வேண்டும் என்பதை கம்பைலர் பின்னர் கருதுகிறது.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// மாற்றத்தை செய்கிறது.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self` ஐப் பயன்படுத்தும் ஒரு முயற்சித்த மாற்றம், இது விலை உயர்ந்ததாக இருக்கலாம் அல்லது இல்லாமல் இருக்கலாம்.
///
/// நூலக ஆசிரியர்கள் வழக்கமாக இந்த trait ஐ நேரடியாக செயல்படுத்தக்கூடாது, ஆனால் [`TryFrom`] trait ஐ செயல்படுத்த விரும்ப வேண்டும், இது அதிக நெகிழ்வுத்தன்மையை வழங்குகிறது மற்றும் சமமான `TryInto` செயல்படுத்தலை இலவசமாக வழங்குகிறது, நிலையான நூலகத்தில் ஒரு போர்வை செயல்படுத்தலுக்கு நன்றி.
/// இது குறித்த கூடுதல் தகவலுக்கு, [`Into`] க்கான ஆவணங்களைப் பார்க்கவும்.
///
/// # `TryInto` ஐ செயல்படுத்துகிறது
///
/// இது [`Into`] ஐ செயல்படுத்துவதற்கான அதே கட்டுப்பாடுகளையும் பகுத்தறிவையும் அனுபவிக்கிறது, விவரங்களுக்கு அங்கே பார்க்கவும்.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// மாற்று பிழை ஏற்பட்டால் வகை திரும்பியது.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// மாற்றத்தை செய்கிறது.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// சில சூழ்நிலைகளில் கட்டுப்படுத்தப்பட்ட வழியில் தோல்வியடையக்கூடிய எளிய மற்றும் பாதுகாப்பான வகை மாற்றங்கள்.இது [`TryInto`] இன் பரஸ்பரமாகும்.
///
/// நீங்கள் ஒரு வகை மாற்றத்தைச் செய்யும்போது இது பயனுள்ளதாக இருக்கும், இது அற்பமாக வெற்றிபெறக்கூடும், ஆனால் சிறப்பு கையாளுதலும் தேவைப்படலாம்.
/// எடுத்துக்காட்டாக, [`From`] trait ஐப் பயன்படுத்தி ஒரு [`i64`] ஐ [`i32`] ஆக மாற்ற வழி இல்லை, ஏனெனில் ஒரு [`i64`] இல் ஒரு [`i32`] பிரதிநிதித்துவப்படுத்த முடியாத மதிப்பைக் கொண்டிருக்கலாம், எனவே மாற்றம் தரவை இழக்கும்.
///
/// இது [`i64`] ஐ ஒரு [`i32`] க்கு துண்டிப்பதன் மூலம் கையாளப்படலாம் (அடிப்படையில் [`i64`] இன் மதிப்பு மட்டு [`i32::MAX`] ஐக் கொடுக்கும்) அல்லது [`i32::MAX`] ஐ திருப்பி அனுப்புவதன் மூலம் அல்லது வேறு ஏதேனும் ஒரு முறை மூலம்.
/// [`From`] trait சரியான மாற்றங்களுக்காக வடிவமைக்கப்பட்டுள்ளது, எனவே `TryFrom` trait ஒரு வகை மாற்றம் மோசமாக இருக்கும்போது புரோகிராமருக்குத் தெரிவிக்கிறது மற்றும் அதை எவ்வாறு கையாள்வது என்பதை தீர்மானிக்க அனுமதிக்கிறது.
///
/// # பொதுவான நடைமுறைகள்
///
/// - `TryFrom<T> for U` குறிக்கிறது [`TryInto`]`<U>T` க்கான</u>
/// - [`try_from`] ரிஃப்ளெக்சிவ் ஆகும், இதன் பொருள் `TryFrom<T> for T` செயல்படுத்தப்பட்டுள்ளது மற்றும் தோல்வியடைய முடியாது-`T` வகையின் மதிப்பில் `T::try_from()` ஐ அழைப்பதற்கான தொடர்புடைய `Error` வகை [`Infallible`] ஆகும்.
/// [`!`] வகை உறுதிப்படுத்தப்படும்போது [`Infallible`] மற்றும் [`!`] சமமாக இருக்கும்.
///
/// `TryFrom<T>` பின்வருமாறு செயல்படுத்தலாம்:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// விவரிக்கப்பட்டுள்ளபடி, [`i32`] `ட்ரைஃப்ரோம் <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // `big_number` ஐ அமைதியாகக் குறைக்கிறது, உண்மைக்குப் பிறகு துண்டிக்கப்படுவதைக் கண்டறிந்து கையாள வேண்டும்.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // ஒரு பிழையைத் தருகிறது, ஏனெனில் `big_number` ஒரு `i32` இல் பொருந்தும் அளவுக்கு பெரிதாக உள்ளது.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` ஐ வழங்குகிறது.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// மாற்று பிழை ஏற்பட்டால் வகை திரும்பியது.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// மாற்றத்தை செய்கிறது.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ஜெனரிக் IMPLS
////////////////////////////////////////////////////////////////////////////////

// லிஃப்ட் ஓவர்&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut க்கு மேல் லிஃப்ட் என
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): மேலே உள்ள impls ஐ&/&mut க்கு பின்வரும் பொதுவான ஒன்றை மாற்றவும்:
// // டெரெஃப் மீது லிஃப்ட் என
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U :? அளவு> <U>D {fn as_ref(&self)-> &U for க்கான AsRef</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut க்கு மேல் தூக்குகிறது
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut க்கான மேலே உள்ள impl ஐ பின்வரும் பொதுவான ஒன்றை மாற்றவும்:
// // அஸ்மட் டெரெஃப்மட் மீது தூக்குகிறது
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U :? அளவு> <U>D {fn as_mut(&mut self)-> &mut U for க்கான AsMut</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// இருந்து குறிக்கிறது
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// இருந்து (இதனால்) பிரதிபலிப்பு
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **ஸ்திரத்தன்மை குறிப்பு:** இந்த impl இன்னும் இல்லை, ஆனால் அதை future இல் சேர்க்க "reserving space" ஆக இருக்கிறோம்.
/// விவரங்களுக்கு [rust-lang/rust#64715][#64715] ஐப் பார்க்கவும்.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): அதற்கு பதிலாக ஒரு கொள்கை ரீதியான தீர்வைச் செய்யுங்கள்.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// ட்ரைஃப்ரோம் ட்ரைஇன்டோவைக் குறிக்கிறது
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// தவறான மாற்றங்கள் ஒரு குடியேற்ற பிழை வகையுடன் தவறான மாற்றங்களுக்கு சொற்பொருளாகும்.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS ஐ இணைக்கவும்
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// பிழையில்லாத பிழை வகை
////////////////////////////////////////////////////////////////////////////////

/// ஒருபோதும் நடக்காத பிழைகளுக்கான பிழை வகை.
///
/// இந்த enum க்கு எந்த மாறுபாடும் இல்லை என்பதால், இந்த வகையின் மதிப்பு உண்மையில் ஒருபோதும் இருக்க முடியாது.
/// [`Result`] ஐப் பயன்படுத்தும் பொதுவான API களுக்கு இது பயனுள்ளதாக இருக்கும் மற்றும் பிழை வகையை அளவுருவாக்குகிறது, இதன் விளைவாக எப்போதும் [`Ok`] என்பதைக் குறிக்கிறது.
///
/// எடுத்துக்காட்டாக, [`TryFrom`] trait (ஒரு [`Result`] ஐ வழங்கும் மாற்றம்) ஒரு தலைகீழ் [`Into`] செயல்படுத்தல் இருக்கும் அனைத்து வகைகளுக்கும் ஒரு போர்வை செயல்படுத்தலைக் கொண்டுள்ளது.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future பொருந்தக்கூடிய தன்மை
///
/// இந்த enum ஆனது [the `!`“never”type][never] ஐப் போலவே உள்ளது, இது Rust இன் இந்த பதிப்பில் நிலையற்றது.
/// `!` உறுதிப்படுத்தப்படும்போது, `Infallible` ஐ ஒரு வகை மாற்றுப்பெயராக மாற்ற திட்டமிட்டுள்ளோம்:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …இறுதியில் `Infallible` ஐ நீக்குகிறது.
///
/// எவ்வாறாயினும், `!` ஒரு முழுமையான வகையாக உறுதிப்படுத்தப்படுவதற்கு முன்பு `!` தொடரியல் பயன்படுத்தக்கூடிய ஒரு வழக்கு உள்ளது: ஒரு செயல்பாட்டின் திரும்பும் வகையின் நிலையில்.
/// குறிப்பாக, இரண்டு வெவ்வேறு செயல்பாடு சுட்டிக்காட்டி வகைகளுக்கு இது சாத்தியமான செயலாக்கங்கள்:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` ஒரு enum ஆக இருப்பதால், இந்த குறியீடு செல்லுபடியாகும்.
/// இருப்பினும், `Infallible` ever type க்கு மாற்றுப்பெயராக மாறும்போது, இரண்டு `impl` களும் ஒன்றுடன் ஒன்று தொடங்கும், எனவே மொழியின் trait ஒத்திசைவு விதிகளால் அனுமதிக்கப்படாது.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}