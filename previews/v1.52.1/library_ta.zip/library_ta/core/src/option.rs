//! விருப்ப மதிப்புகள்.
//!
//! வகை [`Option`] ஒரு விருப்ப மதிப்பைக் குறிக்கிறது: ஒவ்வொரு [`Option`] ஆனது [`Some`] மற்றும் ஒரு மதிப்பு அல்லது [`None`] ஐக் கொண்டுள்ளது, மற்றும் இல்லை.
//! [`Option`] Rust குறியீட்டில் வகைகள் மிகவும் பொதுவானவை, ஏனெனில் அவை பல பயன்பாடுகளைக் கொண்டுள்ளன:
//!
//! * ஆரம்ப மதிப்புகள்
//! * அவற்றின் முழு உள்ளீட்டு வரம்பில் (பகுதி செயல்பாடுகள்) வரையறுக்கப்படாத செயல்பாடுகளுக்கான வருவாய் மதிப்புகள்
//! * எளிய பிழைகளைப் புகாரளிப்பதற்கான மதிப்பு திரும்பவும், அங்கு [`None`] பிழையில் திரும்பும்
//! * விருப்ப கட்டமைப்பு புலங்கள்
//! * கடன் பெறக்கூடிய அல்லது "taken" ஐ உருவாக்கக்கூடிய புலங்கள்
//! * விருப்ப செயல்பாடு வாதங்கள்
//! * சுறுசுறுப்பான சுட்டிகள்
//! * கடினமான சூழ்நிலைகளில் இருந்து விஷயங்களை மாற்றுவது
//!
//! [`விருப்பம்] கள் பொதுவாக ஒரு மதிப்பின் இருப்பை வினவுவதற்கும் நடவடிக்கை எடுப்பதற்கும் மாதிரி பொருத்தத்துடன் இணைக்கப்படுகின்றன, எப்போதும் [`None`] வழக்கைக் கணக்கிடுகின்றன.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // செயல்பாட்டின் வருவாய் மதிப்பு ஒரு விருப்பமாகும்
//! let result = divide(2.0, 3.0);
//!
//! // மதிப்பை மீட்டெடுப்பதற்கான முறை பொருத்தம்
//! match result {
//!     // பிரிவு செல்லுபடியாகும்
//!     Some(x) => println!("Result: {}", x),
//!     // பிரிவு தவறானது
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: `Option` நடைமுறையில் எவ்வாறு பயன்படுத்தப்படுகிறது என்பதைக் காட்டுங்கள், நிறைய முறைகள் உள்ளன
//
//! # விருப்பங்கள் மற்றும் சுட்டிகள் ("nullable" சுட்டிகள்)
//!
//! Rust இன் சுட்டிக்காட்டி வகைகள் எப்போதும் சரியான இடத்தை சுட்டிக்காட்ட வேண்டும்;"null" குறிப்புகள் எதுவும் இல்லை.அதற்கு பதிலாக, Rust இல் விருப்பமான சொந்த பெட்டியைப் போல *விருப்ப* சுட்டிகள் உள்ளன, [`விருப்பம்`]`<`[`பெட்டி<T>`]`>`.
//!
//! பின்வரும் எடுத்துக்காட்டு [`i32`] இன் விருப்ப பெட்டியை உருவாக்க [`Option`] ஐப் பயன்படுத்துகிறது.
//! முதலில் உள் [`i32`] மதிப்பைப் பயன்படுத்த, `check_optional` செயல்பாடு பெட்டியில் ஒரு மதிப்பைக் கொண்டிருக்கிறதா என்பதைத் தீர்மானிக்க மாதிரி பொருத்தத்தைப் பயன்படுத்த வேண்டும் என்பதைக் கவனியுங்கள் (அதாவது, இது [`Some(...)`][`Some`]) அல்லது ([`None`]) அல்ல.
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! [`Option<T>`] பின்வரும் வகைகளை `T` ஐ மேம்படுத்துவதற்கு Rust உத்தரவாதம் அளிக்கிறது, அதாவது [`Option<T>`] ஆனது `T` ஐப் போன்ற அளவைக் கொண்டுள்ளது:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` இந்த பட்டியலில் உள்ள வகைகளில் ஒன்றைச் சுற்றி கட்டமைக்கவும்.
//!
//! மேலேயுள்ள நிகழ்வுகளுக்கு, `T` இன் அனைத்து செல்லுபடியாகும் மதிப்புகளிலிருந்து [`mem::transmute`] மற்றும் `Some::<T>(_)` முதல் `T` வரை [`mem::transmute`] முடியும் என்பதற்கு மேலும் உத்தரவாதம் அளிக்கப்படுகிறது (ஆனால் `None::<T>` முதல் `T` வரை மாற்றுவது வரையறுக்கப்படாத நடத்தை).
//!
//! # Examples
//!
//! [`Option`] இல் அடிப்படை முறை பொருந்தும்:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // உள்ள சரத்திற்கு ஒரு குறிப்பு எடுத்துக் கொள்ளுங்கள்
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // உள்ள சரத்தை அகற்றி, விருப்பத்தை அழிக்கவும்
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! ஒரு வட்டத்திற்கு முன் [`None`] க்கு முடிவைத் தொடங்கவும்:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // தேட வேண்டிய தரவுகளின் பட்டியல்.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // நாங்கள் மிகப்பெரிய விலங்கின் பெயரைத் தேடப் போகிறோம், ஆனால் தொடங்குவதற்கு எங்களுக்கு `None` கிடைத்துள்ளது.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // இப்போது சில பெரிய விலங்குகளின் பெயரைக் கண்டுபிடித்துள்ளோம்
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` வகை.மேலும் அறிய [the module level documentation](self) ஐப் பார்க்கவும்.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// மதிப்பில்லை
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// சில மதிப்பு `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// வகை செயல்படுத்தல்
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // உள்ள மதிப்புகளை வினவுதல்
    /////////////////////////////////////////////////////////////////////////

    /// விருப்பம் ஒரு [`Some`] மதிப்பு என்றால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// விருப்பம் ஒரு [`None`] மதிப்பு என்றால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// விருப்பம் கொடுக்கப்பட்ட மதிப்பைக் கொண்ட [`Some`] மதிப்பாக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // குறிப்புகளுடன் பணிபுரியும் அடாப்டர்
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>` இலிருந்து `Option<&T>` ஆக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// அசலைப் பாதுகாத்து, `விருப்பம் <` [`சரம்`]`>`ஐ`விருப்பமாக <`[`பயன்படுத்து`] `>` ஆக மாற்றுகிறது.
    /// [`map`] முறை `self` வாதத்தை மதிப்பால் எடுத்துக்கொள்கிறது, அசலை உட்கொள்கிறது, எனவே இந்த நுட்பம் `as_ref` ஐப் பயன்படுத்துகிறது, முதலில் `Option` ஐ அசலுக்குள் உள்ள மதிப்பைக் குறிக்கும்.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // முதலில், `as_ref` உடன் `Option<String>` க்கு `Option<&String>` க்கு அனுப்பவும், பின்னர் `map` உடன் *அந்த* ஐ உட்கொள்ளவும், `text` ஐ அடுக்கில் விட்டு விடுங்கள்.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>` இலிருந்து `Option<&mut T>` ஆக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`பின்`]`<&விருப்பத்திலிருந்து மாற்றுகிறது<T>>`முதல்`விருப்பம் <`[`பின்`] `<&டி>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // பாதுகாப்பு: `x` ஆனது `self` இலிருந்து வருவதால் பின் செய்ய உத்தரவாதம் அளிக்கப்படுகிறது
        // இது பொருத்தப்பட்டுள்ளது.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`பின்`]`<&மட் விருப்பத்திலிருந்து மாற்றுகிறது<T>>`to`விருப்பம் <`[`பின்`] `<&மட் டி>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // பாதுகாப்பு: X002 க்குள் `Option` ஐ நகர்த்த `get_unchecked_mut` ஒருபோதும் பயன்படுத்தப்படாது.
        // `x` பின் செய்யப்படும் என்று உத்தரவாதம் அளிக்கப்படுகிறது, ஏனெனில் இது பொருத்தப்பட்ட `self` இலிருந்து வருகிறது.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // அடங்கிய மதிப்புகளைப் பெறுதல்
    /////////////////////////////////////////////////////////////////////////

    /// [`Some`] மதிப்பை உட்கொண்டு, கொண்ட [`Some`] மதிப்பை வழங்குகிறது.
    ///
    /// # Panics
    ///
    /// `msg` வழங்கிய தனிப்பயன் panic செய்தியுடன் மதிப்பு [`None`] ஆக இருந்தால் Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// [`Some`] மதிப்பை உட்கொண்டு, கொண்ட [`Some`] மதிப்பை வழங்குகிறது.
    ///
    /// இந்த செயல்பாடு panic ஆக இருக்கலாம் என்பதால், அதன் பயன்பாடு பொதுவாக ஊக்கமளிக்கிறது.
    /// அதற்கு பதிலாக, மாதிரி பொருத்தத்தைப் பயன்படுத்தவும், [`None`] வழக்கை வெளிப்படையாகக் கையாளவும் அல்லது [`unwrap_or`], [`unwrap_or_else`] அல்லது [`unwrap_or_default`] ஐ அழைக்கவும்.
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// சுய மதிப்பு [`None`] க்கு சமமாக இருந்தால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// உள்ள [`Some`] மதிப்பு அல்லது வழங்கப்பட்ட இயல்புநிலையை வழங்குகிறது.
    ///
    /// `unwrap_or` க்கு அனுப்பப்பட்ட வாதங்கள் ஆவலுடன் மதிப்பீடு செய்யப்படுகின்றன;ஒரு செயல்பாட்டு அழைப்பின் முடிவை நீங்கள் கடந்து செல்கிறீர்கள் என்றால், சோம்பலாக மதிப்பீடு செய்யப்படும் [`unwrap_or_else`] ஐப் பயன்படுத்த பரிந்துரைக்கப்படுகிறது.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// உள்ள [`Some`] மதிப்பை வழங்குகிறது அல்லது மூடியதிலிருந்து கணக்கிடுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// மதிப்பு [`None`] அல்ல என்பதை சரிபார்க்காமல், `self` மதிப்பை நுகரும் [`Some`] மதிப்பை வழங்குகிறது.
    ///
    ///
    /// # Safety
    ///
    /// இந்த முறையை [`None`] இல் அழைப்பது *[வரையறுக்கப்படாத நடத்தை]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // வரையறுக்கப்படாத நடத்தை!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // பாதுகாப்பு: பாதுகாப்பு ஒப்பந்தத்தை அழைப்பவர் உறுதிப்படுத்த வேண்டும்.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // அடங்கிய மதிப்புகளை மாற்றும்
    /////////////////////////////////////////////////////////////////////////

    /// அடங்கிய மதிப்புக்கு ஒரு செயல்பாட்டைப் பயன்படுத்துவதன் மூலம் `Option<T>` முதல் `Option<U>` வரை வரைபடம்.
    ///
    /// # Examples
    ///
    /// ஒரு `விருப்பத்தை <` [`சரம்`]`>`ஒரு`விருப்பமாக மாற்றுகிறது <`[`பயன்படுத்து`] `>`, அசலை உட்கொள்கிறது:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` `maybe_some_string` ஐ உட்கொண்டு, சுய மதிப்பை * எடுத்துக்கொள்கிறது
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// அடங்கிய மதிப்புக்கு (ஏதேனும் இருந்தால்) ஒரு செயல்பாட்டைப் பயன்படுத்துகிறது, அல்லது வழங்கப்பட்ட இயல்புநிலையைத் தருகிறது (இல்லையென்றால்).
    ///
    /// `map_or` க்கு அனுப்பப்பட்ட வாதங்கள் ஆவலுடன் மதிப்பீடு செய்யப்படுகின்றன;ஒரு செயல்பாட்டு அழைப்பின் முடிவை நீங்கள் கடந்து செல்கிறீர்கள் என்றால், சோம்பலாக மதிப்பீடு செய்யப்படும் [`map_or_else`] ஐப் பயன்படுத்த பரிந்துரைக்கப்படுகிறது.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// அடங்கிய மதிப்புக்கு (ஏதேனும் இருந்தால்) ஒரு செயல்பாட்டைப் பயன்படுத்துகிறது, அல்லது இயல்புநிலையைக் கணக்கிடுகிறது (இல்லையென்றால்).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` ஐ [`Result<T, E>`] ஆக மாற்றுகிறது, [`Some(v)`] ஐ [`Ok(v)`] ஆகவும், [`None`] ஐ [`Err(err)`] ஆகவும் மேப்பிங் செய்கிறது.
    ///
    /// `ok_or` க்கு அனுப்பப்பட்ட வாதங்கள் ஆவலுடன் மதிப்பீடு செய்யப்படுகின்றன;ஒரு செயல்பாட்டு அழைப்பின் முடிவை நீங்கள் கடந்து செல்கிறீர்கள் என்றால், சோம்பலாக மதிப்பீடு செய்யப்படும் [`ok_or_else`] ஐப் பயன்படுத்த பரிந்துரைக்கப்படுகிறது.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` ஐ [`Result<T, E>`] ஆக மாற்றுகிறது, [`Some(v)`] ஐ [`Ok(v)`] ஆகவும், [`None`] ஐ [`Err(err())`] ஆகவும் மேப்பிங் செய்கிறது.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// `value` ஐ விருப்பத்தில் செருகினால், அதற்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// விருப்பம் ஏற்கனவே ஒரு மதிப்பைக் கொண்டிருந்தால், பழைய மதிப்பு கைவிடப்படும்.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // பாதுகாப்பு: மேலே உள்ள குறியீடு விருப்பத்தை நிரப்பியது
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ஈட்டரேட்டர் கட்டமைப்பாளர்கள்
    /////////////////////////////////////////////////////////////////////////

    /// சாத்தியமான மதிப்புக்கு மேல் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// சாத்தியமான மதிப்புக்கு மேல் மாற்றக்கூடிய ஈரேட்டரை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // மதிப்புகள், ஆர்வமுள்ள மற்றும் சோம்பேறிகளின் பூலியன் செயல்பாடுகள்
    /////////////////////////////////////////////////////////////////////////

    /// விருப்பம் [`None`] எனில் [`None`] ஐ வழங்குகிறது, இல்லையெனில் `optb` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// விருப்பம் [`None`] ஆக இருந்தால் [`None`] ஐ வழங்குகிறது, இல்லையெனில் `f` ஐ மூடப்பட்ட மதிப்புடன் அழைத்து முடிவை வழங்குகிறது.
    ///
    ///
    /// சில மொழிகள் இந்த செயல்பாட்டை பிளாட்மேப் என்று அழைக்கின்றன.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// விருப்பம் [`None`] ஆக இருந்தால் [`None`] ஐ வழங்குகிறது, இல்லையெனில் மூடப்பட்ட மதிப்புடன் `predicate` ஐ அழைத்து திரும்பும்:
    ///
    ///
    /// - [`Some(t)`] `predicate` `true` ஐ வழங்கினால் (`t` என்பது மூடப்பட்ட மதிப்பு), மற்றும்
    /// - [`None`] `predicate` `false` ஐ வழங்கினால்.
    ///
    /// இந்த செயல்பாடு [`Iterator::filter()`] ஐப் போலவே செயல்படுகிறது.
    /// `Option<T>` ஒன்று அல்லது பூஜ்ஜிய உறுப்புகளுக்கு மேல் ஒரு ஈரேட்டராக இருப்பதை நீங்கள் கற்பனை செய்யலாம்.
    /// `filter()` எந்த கூறுகளை வைத்திருக்க வேண்டும் என்பதை தீர்மானிக்க உங்களை அனுமதிக்கிறது.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// ஒரு மதிப்பைக் கொண்டிருந்தால் விருப்பத்தை வழங்குகிறது, இல்லையெனில் `optb` ஐ வழங்குகிறது.
    ///
    /// `or` க்கு அனுப்பப்பட்ட வாதங்கள் ஆவலுடன் மதிப்பீடு செய்யப்படுகின்றன;ஒரு செயல்பாட்டு அழைப்பின் முடிவை நீங்கள் கடந்து செல்கிறீர்கள் என்றால், சோம்பலாக மதிப்பீடு செய்யப்படும் [`or_else`] ஐப் பயன்படுத்த பரிந்துரைக்கப்படுகிறது.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// இது ஒரு மதிப்பைக் கொண்டிருந்தால் விருப்பத்தை வழங்குகிறது, இல்லையெனில் `f` ஐ அழைத்து முடிவை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// `self` இல் சரியாக இருந்தால் [`Some`] ஐ வழங்குகிறது, `optb` [`Some`], இல்லையெனில் [`None`] ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // எதுவுமில்லை என செருக மற்றும் ஒரு குறிப்பைத் திருப்புவதற்கான நுழைவு போன்ற செயல்பாடுகள்
    /////////////////////////////////////////////////////////////////////////

    /// இது [`None`] ஆக இருந்தால், விருப்பத்தில் `value` ஐ செருகும், பின்னர் உள்ள மதிப்புக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// இயல்புநிலை மதிப்பை [`None`] ஆக இருந்தால் விருப்பத்தில் செருகும், பின்னர் உள்ள மதிப்புக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// `f` இலிருந்து கணக்கிடப்பட்ட மதிப்பை [`None`] ஆக இருந்தால் விருப்பத்தில் செருகும், பின்னர் உள்ள மதிப்புக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // பாதுகாப்பு: `self` க்கான `None` மாறுபாடு ஒரு `Some` ஆல் மாற்றப்பட்டிருக்கும்
            // மேலே உள்ள குறியீட்டில் மாறுபாடு.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// விருப்பத்திலிருந்து மதிப்பை வெளியே எடுத்து, ஒரு [`None`] ஐ அதன் இடத்தில் விட்டுவிடுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// விருப்பத்தில் உள்ள உண்மையான மதிப்பை அளவுருவில் கொடுக்கப்பட்ட மதிப்பால் மாற்றுகிறது, பழைய மதிப்பைக் கொண்டிருந்தால் திருப்பித் தருகிறது, ஒரு [`Some`] ஐ ஒன்றையும் வரையறுக்காமல் அதன் இடத்தில் விட்டுவிடுகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// மற்றொரு `Option` உடன் ஜிப்ஸ் `self`.
    ///
    /// `self` `Some(s)` ஆகவும், `other` `Some(o)` ஆகவும் இருந்தால், இந்த முறை `Some((s, o))` ஐ வழங்குகிறது.
    /// இல்லையெனில், `None` திரும்பும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// ஜிப்ஸ் `self` மற்றும் `f` செயல்பாட்டுடன் மற்றொரு `Option`.
    ///
    /// `self` `Some(s)` ஆகவும், `other` `Some(o)` ஆகவும் இருந்தால், இந்த முறை `Some(f(s, o))` ஐ வழங்குகிறது.
    /// இல்லையெனில், `None` திரும்பும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// விருப்பத்தின் உள்ளடக்கங்களை நகலெடுப்பதன் மூலம் ஒரு `Option<&T>` ஐ `Option<T>` க்கு வரைபடம் செய்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// விருப்பத்தின் உள்ளடக்கங்களை நகலெடுப்பதன் மூலம் ஒரு `Option<&mut T>` ஐ `Option<T>` க்கு வரைபடம் செய்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// விருப்பத்தின் உள்ளடக்கங்களை குளோன் செய்வதன் மூலம் ஒரு `Option<&T>` ஐ `Option<T>` க்கு வரைபடம் செய்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// விருப்பத்தின் உள்ளடக்கங்களை குளோன் செய்வதன் மூலம் ஒரு `Option<&mut T>` ஐ `Option<T>` க்கு வரைபடம் செய்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// [`None`] ஐ எதிர்பார்க்கும் போது எதையும் திருப்பித் தரும்போது `self` ஐப் பயன்படுத்துகிறது.
    ///
    /// # Panics
    ///
    /// Panics மதிப்பு ஒரு [`Some`] ஆக இருந்தால், அனுப்பப்பட்ட செய்தி உட்பட panic செய்தி மற்றும் [`Some`] இன் உள்ளடக்கம்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // எல்லா விசைகளும் தனித்தன்மை வாய்ந்தவை என்பதால் இது panic ஆகாது.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// [`None`] ஐ எதிர்பார்க்கும் போது எதையும் திருப்பித் தரும்போது `self` ஐப் பயன்படுத்துகிறது.
    ///
    /// # Panics
    ///
    /// Panics மதிப்பு ஒரு [`Some`] ஆக இருந்தால், தனிப்பயன் panic செய்தியுடன் [`சில`] மதிப்பால் வழங்கப்படுகிறது.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // எல்லா விசைகளும் தனித்தன்மை வாய்ந்தவை என்பதால் இது panic ஆகாது.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// உள்ள [`Some`] மதிப்பு அல்லது இயல்புநிலையை வழங்குகிறது
    ///
    /// `self` வாதத்தை எடுத்துக்கொள்கிறது, [`Some`] என்றால், உள்ள மதிப்பை அளிக்கிறது, இல்லையெனில் [`None`] என்றால், அந்த வகைக்கு [default value] ஐ வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ஒரு சரத்தை ஒரு முழு எண்ணாக மாற்றுகிறது, மோசமாக உருவாக்கப்பட்ட சரங்களை 0 ஆக மாற்றுகிறது (முழு எண்களுக்கான இயல்புநிலை மதிப்பு).
    /// [`parse`] [`FromStr`] ஐ செயல்படுத்தும் ஒரு சரத்தை வேறு எந்த வகையிலும் மாற்றுகிறது, [`None`] ஐ பிழையாக வழங்குகிறது.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (அல்லது `&Option<T>`) இலிருந்து `Option<&T::Target>` ஆக மாற்றுகிறது.
    ///
    /// அசல் விருப்பத்தை இடத்தில் விட்டுவிட்டு, அசல் ஒன்றைக் குறிக்கும் வகையில் புதிய ஒன்றை உருவாக்கி, கூடுதலாக உள்ளடக்கங்களை [`Deref`] வழியாக கட்டாயப்படுத்துகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (அல்லது `&mut Option<T>`) இலிருந்து `Option<&mut T::Target>` ஆக மாற்றுகிறது.
    ///
    /// அசல் `Option` ஐ இடத்திலேயே விட்டுவிட்டு, உள் வகையின் `Deref::Target` வகைக்கு மாற்றக்கூடிய குறிப்பைக் கொண்ட புதிய ஒன்றை உருவாக்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// ஒரு [`Result`] இன் `Option` ஐ `Option` இன் [`Result`] ஆக மாற்றுகிறது.
    ///
    /// [`None`] [`சரி`]`(`[`எதுவுமில்லை]]`)` க்கு மாற்றப்படும்.
    /// [`சில`]`(`[`சரி`] `(_))` மற்றும் [`சில`]`(`[`பிழை`] `(_))` [`சரி`]`(`[`சில`] `(_))` மற்றும் [`பிழை`]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// .expect() இன் குறியீடு அளவைக் குறைக்க இது ஒரு தனி செயல்பாடு.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// .expect_none() இன் குறியீடு அளவைக் குறைக்க இது ஒரு தனி செயல்பாடு.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait செயலாக்கங்கள்
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// சாத்தியமான மதிப்புக்கு மேல் நுகரும் ஈரேட்டரை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val` ஐ புதிய `Some` இல் நகலெடுக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>` இலிருந்து `Option<&T>` ஆக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// அசலைப் பாதுகாத்து, `விருப்பம் <` [`சரம்`]`>`ஐ`விருப்பமாக <`[`பயன்படுத்து`] `>` ஆக மாற்றுகிறது.
    /// [`map`] முறை `self` வாதத்தை மதிப்பால் எடுத்துக்கொள்கிறது, அசலை உட்கொள்கிறது, எனவே இந்த நுட்பம் `as_ref` ஐப் பயன்படுத்துகிறது, முதலில் `Option` ஐ அசலுக்குள் உள்ள மதிப்பைக் குறிக்கும்.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>` இலிருந்து `Option<&mut T>` ஆக மாற்றுகிறது
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// விருப்பத்தேர்வாளர்கள்
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// ஒரு [`Option`] இன் [`Some`] மாறுபாட்டைக் குறிக்கும் ஒரு மறு செய்கை.
///
/// [`Option`] ஒரு [`Some`] ஆக இருந்தால், ஒரு மதிப்பை ஈட்டரேட்டர் அளிக்கிறது, இல்லையெனில் எதுவும் இல்லை.
///
/// இந்த `struct` [`Option::iter`] செயல்பாட்டால் உருவாக்கப்பட்டது.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// ஒரு [`Option`] இன் [`Some`] மாறுபாட்டிற்கு மாற்றக்கூடிய குறிப்பில் ஒரு ஈரேட்டர்.
///
/// [`Option`] ஒரு [`Some`] ஆக இருந்தால், ஒரு மதிப்பை ஈட்டரேட்டர் அளிக்கிறது, இல்லையெனில் எதுவும் இல்லை.
///
/// இந்த `struct` [`Option::iter_mut`] செயல்பாட்டால் உருவாக்கப்பட்டது.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// ஒரு [`Option`] இன் [`Some`] மாறுபாட்டின் மதிப்பைக் காட்டிலும் ஒரு ஈரேட்டர்.
///
/// [`Option`] ஒரு [`Some`] ஆக இருந்தால், ஒரு மதிப்பை ஈட்டரேட்டர் அளிக்கிறது, இல்லையெனில் எதுவும் இல்லை.
///
/// இந்த `struct` [`Option::into_iter`] செயல்பாட்டால் உருவாக்கப்பட்டது.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// [`Iterator`] இல் உள்ள ஒவ்வொரு உறுப்புகளையும் எடுக்கிறது: இது [`None`][Option::None] ஆக இருந்தால், கூடுதல் கூறுகள் எதுவும் எடுக்கப்படவில்லை, மேலும் [`None`][Option::None] திரும்பப் பெறப்படுகிறது.
    /// [`None`][Option::None] எதுவும் ஏற்படக்கூடாது என்றால், ஒவ்வொரு [`Option`] இன் மதிப்புகள் கொண்ட ஒரு கொள்கலன் திரும்பப் பெறப்படும்.
    ///
    /// # Examples
    ///
    /// vector இல் உள்ள ஒவ்வொரு முழு எண்ணையும் அதிகரிக்கும் ஒரு எடுத்துக்காட்டு இங்கே.
    /// `add` இன் சரிபார்க்கப்பட்ட மாறுபாட்டை நாங்கள் பயன்படுத்துகிறோம், இது `None` ஐக் கொடுக்கும் போது கணக்கீடு நிரம்பி வழிகிறது.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// நீங்கள் பார்க்க முடியும் என, இது எதிர்பார்க்கப்பட்ட, சரியான உருப்படிகளை வழங்கும்.
    ///
    /// முழு எண்களின் பட்டியலிலிருந்து ஒன்றைக் கழிக்க முயற்சிக்கும் மற்றொரு எடுத்துக்காட்டு இங்கே, இந்த நேரத்தில் கீழ்நோக்கி சரிபார்க்கிறது:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// கடைசி உறுப்பு பூஜ்ஜியமாக இருப்பதால், அது நிரம்பி வழியும்.இதனால், இதன் விளைவாக மதிப்பு `None` ஆகும்.
    ///
    /// முந்தைய எடுத்துக்காட்டின் மாறுபாடு இங்கே, முதல் `None` க்குப் பிறகு `iter` இலிருந்து மேலதிக கூறுகள் எதுவும் எடுக்கப்படவில்லை என்பதைக் காட்டுகிறது.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// மூன்றாவது உறுப்பு ஒரு வழிதல் காரணமாக, மேலும் கூறுகள் எதுவும் எடுக்கப்படவில்லை, எனவே `shared` இன் இறுதி மதிப்பு 6 (= `3 + 2 + 1`), 16 அல்ல.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): இந்த செயல்திறன் பிழை மூடப்படும் போது இதை Iterator::scan உடன் மாற்றலாம்.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// முயற்சி ஆபரேட்டர் (`?`) ஐ `None` மதிப்புக்கு பயன்படுத்துவதன் விளைவாக ஏற்படும் பிழை வகை.
/// உங்கள் பிழை வகையாக மாற்ற `x?` ஐ (`x` ஒரு `Option<T>`) அனுமதிக்க விரும்பினால், நீங்கள் `YourErrorType` க்கு `impl From<NoneError>` ஐ செயல்படுத்தலாம்.
///
/// அவ்வாறான நிலையில், `Result<_, YourErrorType>` ஐ வழங்கும் ஒரு செயல்பாட்டிற்குள் `x?` ஒரு `None` மதிப்பை `Err` முடிவாக மொழிபெயர்க்கும்.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>` இலிருந்து `Option<T>` ஆக மாற்றுகிறது
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// தட்டையானது ஒரு நேரத்தில் ஒரு நிலை கூடுகளை மட்டுமே நீக்குகிறது:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}