//! சிப்ஹாஷின் செயல்படுத்தல்.

#![allow(deprecated)] // இந்த தொகுதியில் உள்ள வகைகள் நீக்கப்பட்டன

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// சிப்ஹாஷ் 1-3 இன் செயல்படுத்தல்.
///
/// இது தற்போது நிலையான நூலகத்தால் பயன்படுத்தப்படும் இயல்புநிலை ஹாஷிங் செயல்பாடாகும் (எ.கா., `collections::HashMap` இதை முன்னிருப்பாக பயன்படுத்துகிறது).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// சிப்ஹாஷ் 2-4 இன் செயல்படுத்தல்.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// சிப்ஹாஷ் 2-4 இன் செயல்படுத்தல்.
///
/// See: <https://131002.net/siphash/>
///
/// சிப்ஹாஷ் என்பது ஒரு பொது நோக்கத்திற்கான ஹாஷிங் செயல்பாடு: இது ஒரு நல்ல வேகத்தில் இயங்குகிறது (ஸ்பூக்கி மற்றும் சிட்டியுடன் போட்டி) மற்றும் வலுவான _keyed_ ஹாஷிங்கை அனுமதிக்கிறது.
///
/// இது உங்கள் ஹாஷ் அட்டவணைகளை [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) போன்ற வலுவான RNG இலிருந்து திறக்க அனுமதிக்கிறது.
///
/// சிப்ஹாஷ் வழிமுறை பொதுவாக வலுவானதாகக் கருதப்பட்டாலும், இது கிரிப்டோகிராஃபிக் நோக்கங்களுக்காக அல்ல.
/// எனவே, இந்த செயல்பாட்டின் அனைத்து கிரிப்டோகிராஃபிக் பயன்பாடுகளும் _strongly discouraged_ ஆகும்.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // எத்தனை பைட்டுகளை நாங்கள் செயலாக்கினோம்
    state: State,  // ஹாஷ் மாநிலம்
    tail: u64,     // பதப்படுத்தப்படாத பைட்டுகள் லே
    ntail: usize,  // வால் எத்தனை பைட்டுகள் செல்லுபடியாகும்
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 மற்றும் v1, v3 ஆகியவை வழிமுறையில் ஜோடிகளாகக் காண்பிக்கப்படுகின்றன, மேலும் SipHash இன் எளிமையான செயலாக்கங்கள் v02 மற்றும் v13 இன் vectors ஐப் பயன்படுத்தும்.
    //
    // இந்த வரிசையில் அவற்றை struct இல் வைப்பதன் மூலம், கம்பைலர் ஒரு சில எளிமையான மேம்படுத்தல்களைத் தானே எடுக்க முடியும்.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// LE வரிசையில், ஒரு பைட் ஸ்ட்ரீமில் இருந்து விரும்பிய வகையின் முழு எண்ணை ஏற்றுகிறது.
/// வரிசைப்படுத்தப்படாத முகவரியிலிருந்து ஏற்றுவதற்கான மிகச் சிறந்த வழியை கம்பைலர் உருவாக்க அனுமதிக்க `copy_nonoverlapping` ஐப் பயன்படுத்துகிறது.
///
///
/// பாதுகாப்பற்றது ஏனெனில்: i..i+size_of(int_ty) இல் தேர்வு செய்யப்படாத அட்டவணைப்படுத்தல்
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// ஒரு பைட் துண்டின் 7 பைட்டுகள் வரை ஒரு u64 ஐ ஏற்றுகிறது.
/// இது விகாரமாகத் தெரிகிறது, ஆனால் நிகழும் `copy_nonoverlapping` அழைப்புகள் (`load_int_le!` வழியாக) அனைத்தும் நிலையான அளவுகளைக் கொண்டுள்ளன மற்றும் `memcpy` ஐ அழைப்பதைத் தவிர்க்கின்றன, இது வேகத்திற்கு நல்லது.
///
///
/// பாதுகாப்பற்றது ஏனெனில்: தொடக்கத்தில் தேர்வுசெய்யப்படாத அட்டவணைப்படுத்தல்..ஸ்டார்ட் + லென்
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // u64 வெளியீட்டில் தற்போதைய பைட் குறியீடு (LSB இலிருந்து)
    let mut out = 0;
    if i + 3 < len {
        // பாதுகாப்பு: `i` `len` ஐ விட அதிகமாக இருக்கக்கூடாது, மேலும் அழைப்பாளர் உத்தரவாதம் அளிக்க வேண்டும்
        // குறியீட்டு தொடக்க..ஸ்டார்ட் + லென் எல்லைக்குட்பட்டது.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // பாதுகாப்பு: மேலே உள்ளதைப் போன்றது.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // பாதுகாப்பு: மேலே உள்ளதைப் போன்றது.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// 0 என அமைக்கப்பட்ட இரண்டு ஆரம்ப விசைகளுடன் புதிய `SipHasher` ஐ உருவாக்குகிறது.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// வழங்கப்பட்ட விசைகளில் இருந்து திறக்கப்பட்ட ஒரு `SipHasher` ஐ உருவாக்குகிறது.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// 0 என அமைக்கப்பட்ட இரண்டு ஆரம்ப விசைகளுடன் புதிய `SipHasher13` ஐ உருவாக்குகிறது.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// வழங்கப்பட்ட விசைகளில் இருந்து திறக்கப்பட்ட ஒரு `SipHasher13` ஐ உருவாக்குகிறது.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: முழு எண் ஹாஷிங் முறைகள் (`எழுத_உ *`, எக்ஸ் 100 எக்ஸ்) வரையறுக்கப்படவில்லை
    // இந்த வகைக்கு.
    // நாம் அவற்றைச் சேர்க்கலாம், librustc_data_structures/sip128.rs இல் `short_write` செயல்படுத்தலை நகலெடுக்கலாம் மற்றும் `SipHasher`, `SipHasher13` மற்றும் `DefaultHasher` இல் `write_u *`/`write_i*` முறைகளைச் சேர்க்கலாம்.
    //
    // சில வரையறைகளில் தொகுக்கும் வேகத்தை சற்று குறைக்கும் செலவில், அந்த ஹேஷர்களால் முழு எண் ஹேஷிங்கை இது பெரிதும் துரிதப்படுத்தும்.
    // விவரங்களுக்கு #69152 ஐப் பார்க்கவும்.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // பாதுகாப்பு: `cmp::min(length, needed)` `length` க்கு மேல் இருக்காது என்பது உறுதி
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // இடையக வால் இப்போது சுத்தப்படுத்தப்பட்டுள்ளது, புதிய உள்ளீட்டை செயலாக்கவும்.
        let len = length - needed;
        let left = len & 0x7; // லென்% 8

        let mut i = needed;
        while i < len - left {
            // பாதுகாப்பு: ஏனென்றால் `len - left` என்பது 8 இன் கீழ் உள்ள மிகப்பெரிய பெருக்கமாகும்
            // `len`, மேலும் `i` `needed` இல் தொடங்குவதால் `len` `length - needed` ஆக இருப்பதால், `i + 8` `length` ஐ விடக் குறைவாகவோ அல்லது சமமாகவோ உத்தரவாதம் அளிக்கப்படுகிறது.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // பாதுகாப்பு: `i` இப்போது `needed + len.div_euclid(8) * 8`,
        // எனவே `i + left` = `needed + len` = `length`, இது வரையறையின்படி `msg.len()` க்கு சமம்.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// 0 என அமைக்கப்பட்ட இரண்டு ஆரம்ப விசைகளுடன் `Hasher<S>` ஐ உருவாக்குகிறது.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}