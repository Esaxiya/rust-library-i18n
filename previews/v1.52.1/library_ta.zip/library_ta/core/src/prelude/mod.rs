//! லிப்கோர் prelude
//!
//! இந்த தொகுதி libcd இன் பயனர்களுக்காக வடிவமைக்கப்பட்டுள்ளது, அவை libstd உடன் இணைக்கப்படவில்லை.
//! நிலையான நூலகத்தின் prelude ஐப் போலவே `#![no_std]` பயன்படுத்தப்படும்போது இந்த தொகுதி இயல்புநிலையாக இறக்குமதி செய்யப்படுகிறது.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// கோர் prelude இன் 2015 பதிப்பு.
///
/// மேலும் அறிய [module-level documentation](self) ஐப் பார்க்கவும்.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// கோர் prelude இன் 2018 பதிப்பு.
///
/// மேலும் அறிய [module-level documentation](self) ஐப் பார்க்கவும்.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// கோர் prelude இன் 2021 பதிப்பு.
///
/// மேலும் அறிய [module-level documentation](self) ஐப் பார்க்கவும்.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: மேலும் பலவற்றைச் சேர்க்கவும்.
}