//! நிலையான நூலகத்தில் Panic ஆதரவு.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic பற்றிய தகவல்களை வழங்கும் ஒரு கட்டமைப்பு.
///
/// `PanicInfo` கட்டமைப்பு [`set_hook`] செயல்பாட்டால் அமைக்கப்பட்ட panic hook க்கு அனுப்பப்படுகிறது.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic உடன் தொடர்புடைய பேலோடை வழங்குகிறது.
    ///
    /// இது பொதுவாக, ஆனால் எப்போதும் இல்லை, `&'static str` அல்லது [`String`] ஆக இருக்கும்.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// `core` crate இலிருந்து (`std` இலிருந்து அல்ல) `panic!` மேக்ரோ ஒரு வடிவமைப்பு சரம் மற்றும் சில கூடுதல் வாதங்களுடன் பயன்படுத்தப்பட்டிருந்தால், அந்த செய்தியை [`fmt::write`] உடன் பயன்படுத்த தயாராக உள்ளது
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// கிடைத்தால், panic தோன்றிய இடம் பற்றிய தகவலை வழங்குகிறது.
    ///
    /// இந்த முறை தற்போது எப்போதும் [`Some`] ஐ வழங்கும், ஆனால் இது future பதிப்புகளில் மாறக்கூடும்.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: இது சில நேரங்களில் எதுவும் இல்லை என மாற்றப்பட்டால்,
        // std::panicking::default_hook மற்றும் std::panicking::begin_panic_fmt இல் அந்த வழக்கைக் கையாளுங்கள்.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: நாம் downcast_ref: : ஐப் பயன்படுத்த முடியாது<String>() இங்கே
        // சரம் லிப்கோரில் கிடைக்கவில்லை என்பதால்!
        // பல வாதங்களுடன் `std::panic!` அழைக்கப்படும் போது பேலோட் ஒரு சரம், ஆனால் அந்த விஷயத்தில் செய்தியும் கிடைக்கிறது.
        //

        self.location.fmt(formatter)
    }
}

/// panic இன் இருப்பிடம் பற்றிய தகவல்களைக் கொண்ட ஒரு கட்டமைப்பு.
///
/// இந்த அமைப்பு [`PanicInfo::location()`] ஆல் உருவாக்கப்பட்டது.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// சமத்துவம் மற்றும் வரிசைப்படுத்துதலுக்கான ஒப்பீடுகள் கோப்பு, வரி, பின்னர் நெடுவரிசை முன்னுரிமையில் செய்யப்படுகின்றன.
/// கோப்புகள் சரங்களாக ஒப்பிடப்படுகின்றன, `Path` அல்ல, இது எதிர்பாராததாக இருக்கலாம்.
/// மேலும் விவாதத்திற்கு [`இருப்பிடம்: : கோப்பு`] ஆவணங்களைக் காண்க.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// இந்த செயல்பாட்டின் அழைப்பாளரின் மூல இருப்பிடத்தை வழங்குகிறது.
    /// அந்த செயல்பாட்டின் அழைப்பாளர் சிறுகுறிப்பு செய்யப்பட்டால், அதன் அழைப்பு இருப்பிடம் திரும்பப் பெறப்படும், மேலும் கண்காணிக்கப்படாத செயல்பாட்டு உடலுக்குள் முதல் அழைப்பிற்கு அடுக்கி வைக்கப்படும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// இது அழைக்கப்படும் [`Location`] ஐ வழங்குகிறது.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// இந்த செயல்பாட்டின் வரையறையிலிருந்து ஒரு [`Location`] ஐ வழங்குகிறது.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // அதே தடமறியப்படாத செயல்பாட்டை வேறு இடத்தில் இயக்குவது அதே முடிவை நமக்குத் தருகிறது
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // தடமறியப்பட்ட செயல்பாட்டை வேறு இடத்தில் இயக்குவது வேறு மதிப்பை உருவாக்குகிறது
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic தோன்றிய மூல கோப்பின் பெயரை வழங்குகிறது.
    ///
    /// # `&str`, `&Path` அல்ல
    ///
    /// திரும்பிய பெயர் தொகுக்கும் கணினியில் ஒரு மூல பாதையை குறிக்கிறது, ஆனால் இதை நேரடியாக `&Path` ஆக பிரதிநிதித்துவப்படுத்துவது செல்லுபடியாகாது.
    /// தொகுக்கப்பட்ட குறியீடு உள்ளடக்கங்களை வழங்கும் அமைப்பை விட வேறு `Path` செயல்படுத்தலுடன் வேறு கணினியில் இயங்கக்கூடும், மேலும் இந்த நூலகத்தில் தற்போது வேறு "host path" வகை இல்லை.
    ///
    /// தொகுதி அமைப்பில் (பொதுவாக `#[path = "..."]` பண்புக்கூறு அல்லது அதைப் போன்றது) பல பாதைகள் வழியாக "the same" கோப்பை அடையும்போது மிகவும் ஆச்சரியமான நடத்தை ஏற்படுகிறது, இது இந்த செயல்பாட்டிலிருந்து மாறுபட்ட மதிப்புகளைத் தர ஒரே குறியீடாகத் தோன்றும்.
    ///
    ///
    /// # Cross-compilation
    ///
    /// ஹோஸ்ட் இயங்குதளம் மற்றும் இலக்கு இயங்குதளம் வேறுபடும்போது `Path::new` அல்லது ஒத்த கட்டமைப்பாளர்களுக்கு அனுப்ப இந்த மதிப்பு பொருத்தமானதல்ல.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic தோன்றிய வரி எண்ணை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic தோன்றிய நெடுவரிசையை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Libstd இலிருந்து `panic_unwind` மற்றும் பிற panic இயக்க நேரங்களுக்கு தரவை அனுப்ப libstd பயன்படுத்தும் உள் trait.
/// எந்த நேரத்திலும் உறுதிப்படுத்தப்பட வேண்டும், பயன்படுத்த வேண்டாம்.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// உள்ளடக்கங்களின் முழு உரிமையையும் எடுத்துக் கொள்ளுங்கள்.
    /// திரும்ப வகை உண்மையில் `Box<dyn Any + Send>`, ஆனால் நாம் லிப்கோரில் `Box` ஐப் பயன்படுத்த முடியாது.
    ///
    /// இந்த முறை அழைக்கப்பட்ட பிறகு, `self` இல் சில போலி இயல்புநிலை மதிப்பு மட்டுமே மீதமுள்ளது.
    /// இந்த முறையை இரண்டு முறை அழைப்பது அல்லது இந்த முறையை அழைத்த பிறகு `get` ஐ அழைப்பது பிழை.
    ///
    /// panic இயக்க நேரம் (`__rust_start_panic`) கடன் வாங்கிய `dyn BoxMeUp` ஐ மட்டுமே பெறுவதால் வாதம் கடன் வாங்கப்பட்டுள்ளது.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// உள்ளடக்கங்களை கடன் வாங்கவும்.
    fn get(&mut self) -> &(dyn Any + Send);
}