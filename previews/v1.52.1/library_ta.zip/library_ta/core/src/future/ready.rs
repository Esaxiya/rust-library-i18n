use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// ஒரு future ஐ உருவாக்குகிறது, அது உடனடியாக மதிப்புடன் தயாராக உள்ளது.
///
/// இந்த `struct` ஆனது [`ready()`] ஆல் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("Ready polled after completion"))
    }
}

/// ஒரு future ஐ உருவாக்குகிறது, அது உடனடியாக மதிப்புடன் தயாராக உள்ளது.
///
/// இந்த செயல்பாட்டின் மூலம் உருவாக்கப்பட்ட Futures செயல்பாட்டு ரீதியாக `async {}` மூலம் உருவாக்கப்பட்டதைப் போன்றது.
/// முக்கிய வேறுபாடு என்னவென்றால், இந்த செயல்பாட்டின் மூலம் உருவாக்கப்பட்ட futures பெயரிடப்பட்டு `Unpin` ஐ செயல்படுத்துகிறது.
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}