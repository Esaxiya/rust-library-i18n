use crate::future::Future;

/// `Future` ஆக மாற்றுதல்.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future வெளியீடு முடிந்ததும் உற்பத்தி செய்யும்.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// எந்த வகையான future ஐ இதை மாற்றுகிறோம்?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// ஒரு மதிப்பிலிருந்து future ஐ உருவாக்குகிறது.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}