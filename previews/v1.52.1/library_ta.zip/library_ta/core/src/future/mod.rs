#![stable(feature = "futures_api", since = "1.36.0")]

//! ஒத்திசைவற்ற மதிப்புகள்.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// இந்த வகை தேவைப்படுகிறது ஏனெனில்:
///
/// a) ஜெனரேட்டர்கள் `for<'a, 'b> Generator<&'a mut Context<'b>>` ஐ செயல்படுத்த முடியாது, எனவே நாம் ஒரு மூல சுட்டிக்காட்டி அனுப்ப வேண்டும் (<https://github.com/rust-lang/rust/issues/68923> ஐப் பார்க்கவும்).
///
/// b) மூல சுட்டிகள் மற்றும் `NonNull` ஆகியவை `Send` அல்லது `Sync` அல்ல, எனவே இது ஒவ்வொரு future non-Send/Sync ஐ உருவாக்கும், மேலும் நாங்கள் அதை விரும்பவில்லை.
///
/// இது `.await` இன் HIR குறைப்பையும் எளிதாக்குகிறது.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// ஒரு ஜெனரேட்டரை future இல் மடக்குங்கள்.
///
/// இந்த செயல்பாடு ஒரு `GenFuture` க்கு அடியில் கொடுக்கிறது, ஆனால் சிறந்த பிழை செய்திகளை (`GenFuture<[closure.....]>` ஐ விட `impl Future`) கொடுக்க அதை `impl Trait` இல் மறைக்கிறது.
///
// `const async fn` இலிருந்து மீண்ட பிறகு கூடுதல் பிழைகளைத் தவிர்க்க இது `const` ஆகும்
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // அடிப்படை ஜெனரேட்டரில் சுய-குறிப்புக் கடன்களை உருவாக்க async/await futures அசையாதது என்ற உண்மையை நாங்கள் நம்புகிறோம்.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // பாதுகாப்பு: நாங்கள் !Unpin + !Drop என்பதால் பாதுகாப்பானது, இது ஒரு புலம் திட்டம் மட்டுமே.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // ஜெனரேட்டரை மீண்டும் தொடங்கவும், `&mut Context` ஐ `NonNull` மூல சுட்டிக்காட்டியாக மாற்றவும்.
            // `.await` குறைப்பது பாதுகாப்பாக அதை `&mut Context` க்கு அனுப்பும்.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // பாதுகாப்பு: அழைப்பாளர் `cx.0` செல்லுபடியாகும் சுட்டிக்காட்டி என்று உத்தரவாதம் அளிக்க வேண்டும்
    // இது ஒரு மாற்றத்தக்க குறிப்புக்கான அனைத்து தேவைகளையும் பூர்த்தி செய்கிறது.
    unsafe { &mut *cx.0.as_ptr().cast() }
}