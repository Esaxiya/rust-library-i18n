//! வரிசைகளுக்கான `IntoIter` க்கு சொந்தமான ஐரேட்டரை வரையறுக்கிறது.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// ஒரு பை-மதிப்பு [array] ஐரேட்டர்.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// இதுதான் நாம் மீண்டும் செய்கிறோம்.
    ///
    /// குறியீட்டு `i` உடன் கூறுகள், அங்கு `alive.start <= i < alive.end` இன்னும் வழங்கப்படவில்லை மற்றும் செல்லுபடியாகும் வரிசை உள்ளீடுகள்.
    /// `i < alive.start` அல்லது `i >= alive.end` குறியீடுகளைக் கொண்ட கூறுகள் ஏற்கனவே வழங்கப்பட்டுள்ளன, இனி அவற்றை அணுகக்கூடாது!அந்த இறந்த கூறுகள் முற்றிலும் ஆரம்பிக்கப்படாத நிலையில் கூட இருக்கலாம்!
    ///
    ///
    /// எனவே மாற்றங்கள்:
    /// - `data[alive]` உயிருடன் உள்ளது (அதாவது சரியான கூறுகளைக் கொண்டுள்ளது)
    /// - `data[..alive.start]` மற்றும் `data[alive.end..]` இறந்துவிட்டன (அதாவது கூறுகள் ஏற்கனவே வாசிக்கப்பட்டன, இனி தொடக்கூடாது!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` இல் உள்ள கூறுகள் இன்னும் வழங்கப்படவில்லை.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// கொடுக்கப்பட்ட `array` க்கு மேல் ஒரு புதிய ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// *குறிப்பு*: இந்த முறை [`IntoIterator` is implemented for arrays][array-into-iter] க்குப் பிறகு, future இல் நீக்கப்படலாம்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // X001 க்கு பதிலாக `value` வகை இங்கே ஒரு `i32` ஆகும்
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // பாதுகாப்பு: இங்கே பரிமாற்றம் உண்மையில் பாதுகாப்பானது.`MaybeUninit` இன் டாக்ஸ்
        // promise:
        //
        // > `MaybeUninit<T>` ஒரே அளவு மற்றும் சீரமைப்பு இருப்பது உறுதி
        // > `T` ஆக.
        //
        // டாக்ஸ் `MaybeUninit<T>` இன் வரிசையிலிருந்து `T` வரிசைக்கு ஒரு பரிமாற்றத்தைக் காட்டுகிறது.
        //
        //
        // இதன் மூலம், இந்த துவக்கம் மாற்றங்களை திருப்தி செய்கிறது.

        // FIXME(LukasKalbertodt): உண்மையில் இங்கே `mem::transmute` ஐப் பயன்படுத்தவும், இது கான்ஸ்ட் ஜெனரிக்ஸுடன் வேலை செய்தவுடன்:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // அதுவரை, பிட்வைஸ் நகலை வேறு வகையாக உருவாக்க `mem::transmute_copy` ஐப் பயன்படுத்தலாம், பின்னர் `array` ஐ மறந்துவிடுங்கள், அதனால் அது கைவிடப்படாது.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// இதுவரை வழங்கப்படாத அனைத்து உறுப்புகளின் மாறாத துண்டுகளை வழங்குகிறது.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // பாதுகாப்பு: `alive` க்குள் உள்ள அனைத்து கூறுகளும் சரியாக துவக்கப்பட்டுள்ளன என்பதை நாங்கள் அறிவோம்.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// இதுவரை வழங்கப்படாத அனைத்து உறுப்புகளின் மாற்றத்தக்க துண்டுகளை வழங்குகிறது.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // பாதுகாப்பு: `alive` க்குள் உள்ள அனைத்து கூறுகளும் சரியாக துவக்கப்பட்டுள்ளன என்பதை நாங்கள் அறிவோம்.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // அடுத்த குறியீட்டை முன் இருந்து பெறவும்.
        //
        // `alive.start` ஐ 1 ஆல் அதிகரிப்பது `alive` தொடர்பான மாற்றத்தை பராமரிக்கிறது.
        // இருப்பினும், இந்த மாற்றத்தின் காரணமாக, ஒரு குறுகிய காலத்திற்கு, உயிருள்ள மண்டலம் இனி `data[alive]` அல்ல, ஆனால் `data[idx..alive.end]` ஆகும்.
        //
        self.alive.next().map(|idx| {
            // வரிசையிலிருந்து உறுப்பைப் படியுங்கள்.
            // பாதுகாப்பு: `idx` என்பது முன்னாள் "alive" பிராந்தியத்தில் ஒரு குறியீடாகும்
            // வரிசை.இந்த உறுப்பைப் படிப்பது என்பது `data[idx]` இப்போது இறந்ததாகக் கருதப்படுகிறது (அதாவது தொடாதே).
            // `idx` உயிருள்ள மண்டலத்தின் தொடக்கமாக இருந்ததால், உயிருள்ள மண்டலம் இப்போது மீண்டும் `data[alive]` ஆக உள்ளது, இது அனைத்து மாற்றங்களையும் மீட்டமைக்கிறது.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // அடுத்த குறியீட்டை பின்புறத்திலிருந்து பெறுங்கள்.
        //
        // `alive.end` ஐ 1 ஆல் குறைப்பது `alive` தொடர்பான மாற்றத்தை பராமரிக்கிறது.
        // இருப்பினும், இந்த மாற்றத்தின் காரணமாக, ஒரு குறுகிய காலத்திற்கு, உயிருள்ள மண்டலம் இனி `data[alive]` அல்ல, ஆனால் `data[alive.start..=idx]` ஆகும்.
        //
        self.alive.next_back().map(|idx| {
            // வரிசையிலிருந்து உறுப்பைப் படியுங்கள்.
            // பாதுகாப்பு: `idx` என்பது முன்னாள் "alive" பிராந்தியத்தில் ஒரு குறியீடாகும்
            // வரிசை.இந்த உறுப்பைப் படிப்பது என்பது `data[idx]` இப்போது இறந்ததாகக் கருதப்படுகிறது (அதாவது தொடாதே).
            // `idx` உயிருள்ள மண்டலத்தின் முடிவாக இருந்ததால், உயிருள்ள மண்டலம் இப்போது மீண்டும் `data[alive]` ஆக உள்ளது, இது அனைத்து மாற்றங்களையும் மீட்டமைக்கிறது.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // பாதுகாப்பு: இது பாதுகாப்பானது: `as_mut_slice` சரியாக துணை துண்டுகளை வழங்குகிறது
        // இன்னும் வெளியேற்றப்படாத மற்றும் கைவிடப்பட வேண்டிய உறுப்புகளின்.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // மாறாத `உயிருடன். ஸ்டார்ட் <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// ஈரேட்டர் உண்மையில் சரியான நீளத்தைப் புகாரளிக்கிறது.
// "alive" உறுப்புகளின் எண்ணிக்கை (அது இன்னும் வழங்கப்படும்) `alive` வரம்பின் நீளம்.
// இந்த வரம்பு `next` அல்லது `next_back` இல் நீளம் குறைக்கப்படுகிறது.
// அந்த முறைகளில் இது எப்போதும் 1 ஆல் குறைக்கப்படுகிறது, ஆனால் `Some(_)` திரும்பினால் மட்டுமே.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // குறிப்பு, சரியான உயிருள்ள வரம்பை நாம் உண்மையில் பொருத்த வேண்டிய அவசியமில்லை, எனவே `self` எங்கிருந்தாலும் ஆஃப்செட் 0 இல் குளோன் செய்யலாம்.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // அனைத்து உயிருள்ள கூறுகளையும் குளோன் செய்யுங்கள்.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // புதிய வரிசையில் ஒரு குளோனை எழுதுங்கள், பின்னர் அதன் உயிருள்ள வரம்பைப் புதுப்பிக்கவும்.
            // panics ஐ குளோனிங் செய்தால், முந்தைய உருப்படிகளை சரியாக கைவிடுவோம்.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // இதுவரை வழங்கப்படாத கூறுகளை மட்டுமே அச்சிடுக: விளைச்சல் பெற்ற கூறுகளை இனி அணுக முடியாது.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}