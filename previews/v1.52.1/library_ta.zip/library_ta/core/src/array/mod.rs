//! ஒரு குறிப்பிட்ட நீளம் வரை நிலையான நீள வரிசைகளுக்கு `Eq` போன்ற விஷயங்களை செயல்படுத்துதல்.
//! இறுதியில், நாம் எல்லா நீளங்களையும் பொதுமைப்படுத்த முடியும்.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T` க்கான குறிப்பை நீளம் 1 வரிசைக்கு (நகலெடுக்காமல்) மாற்றுகிறது.
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // பாதுகாப்பு: `&T` ஐ `&[T; 1]` ஆக மாற்றுவது ஒலி.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// `T` க்கு மாற்றக்கூடிய குறிப்பை நீளம் 1 வரிசைக்கு (நகலெடுக்காமல்) மாற்றக்கூடிய குறிப்பாக மாற்றுகிறது.
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // பாதுகாப்பு: `&mut T` ஐ `&mut [T; 1]` ஆக மாற்றுவது ஒலி.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// பயன்பாடு trait நிலையான அளவிலான வரிசைகளில் மட்டுமே செயல்படுத்தப்படுகிறது
///
/// இந்த trait ஆனது மற்ற traits ஐ நிலையான அளவு வரிசைகளில் அதிக மெட்டாடேட்டா வீக்கத்தை ஏற்படுத்தாமல் செயல்படுத்த பயன்படுத்தலாம்.
///
/// செயல்படுத்துபவர்களை நிலையான அளவு வரிசைகளுக்கு கட்டுப்படுத்துவதற்காக trait பாதுகாப்பற்றது எனக் குறிக்கப்பட்டுள்ளது.
/// இந்த trait இன் பயனர் ஒரு நிலையான அளவு வரிசையின் நினைவகத்தில் சரியான அமைப்பைக் கொண்டிருப்பதாகக் கருதலாம் (எடுத்துக்காட்டாக, பாதுகாப்பற்ற துவக்கத்திற்கு).
///
///
/// traits [`AsRef`] மற்றும் [`AsMut`] ஆகியவை நிலையான அளவு வரிசைகளாக இல்லாத வகைகளுக்கு ஒத்த முறைகளை வழங்குகின்றன என்பதை நினைவில் கொள்க.
/// செயல்படுத்துபவர்கள் அதற்கு பதிலாக அந்த traits ஐ விரும்ப வேண்டும்.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// வரிசையை மாற்ற முடியாத துண்டுக்கு மாற்றுகிறது
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// வரிசையை மாற்றக்கூடிய துண்டுகளாக மாற்றுகிறது
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// ஒரு துண்டிலிருந்து வரிசைக்கு மாற்றுவது தோல்வியடையும் போது பிழை வகை திரும்பியது.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // பாதுகாப்பு: சரி, ஏனெனில் நீளம் பொருந்துமா என்பதை நாங்கள் சோதித்தோம்
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // பாதுகாப்பு: சரி, ஏனெனில் நீளம் பொருந்துமா என்பதை நாங்கள் சோதித்தோம்
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: குறியீடு வீக்கத்தைக் குறைக்க சில குறைவான முக்கியமான குறிப்புகள் தவிர்க்கப்பட்டுள்ளன
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// [lexicographically](Ord#lexicographical-comparison) வரிசைகளின் ஒப்பீட்டை செயல்படுத்துகிறது.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// இயல்புநிலை impls ஐ கான்ஸ்ட் ஜெனரிக்ஸ் மூலம் செய்ய முடியாது, ஏனெனில் `[T; 0]` க்கு இயல்புநிலை செயல்படுத்த தேவையில்லை, மேலும் வெவ்வேறு எண்களுக்கு வெவ்வேறு impl தொகுதிகள் இருப்பது இன்னும் ஆதரிக்கப்படவில்லை.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// ஒவ்வொரு உறுப்புக்கும் வரிசையில் `f` செயல்பாடு பயன்படுத்தப்பட்டு, `self` போன்ற அதே அளவிலான வரிசையை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // பாதுகாப்பு: இந்த ஈரேட்டர் சரியாக `N` ஐ வழங்கும் என்பதை நாங்கள் அறிவோம்
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// ஜோடிகளின் ஒற்றை வரிசையில் இரண்டு வரிசைகளை 'ஜிப்ஸ் அப்' செய்கிறது.
    ///
    /// `zip()` ஒரு புதிய வரிசையைத் தருகிறது, அங்கு ஒவ்வொரு உறுப்பு ஒரு டூப்பிள் ஆகும், அங்கு முதல் உறுப்பு முதல் வரிசையிலிருந்து வருகிறது, இரண்டாவது உறுப்பு இரண்டாவது வரிசையிலிருந்து வருகிறது.
    ///
    /// வேறு வார்த்தைகளில் கூறுவதானால், இது இரண்டு வரிசைகளை ஒன்றாக இணைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // பாதுகாப்பு: இந்த ஈரேட்டர் சரியாக `N` ஐ வழங்கும் என்பதை நாங்கள் அறிவோம்
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// முழு வரிசையையும் கொண்ட ஒரு துண்டை வழங்குகிறது.`&s[..]` க்கு சமம்.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// முழு வரிசையையும் கொண்ட ஒரு மாற்றக்கூடிய துண்டை வழங்குகிறது.
    /// `&mut s[..]` க்கு சமம்.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// ஒவ்வொரு உறுப்பையும் கடன் வாங்கி, `self` போன்ற அதே அளவிலான குறிப்புகளின் வரிசையை வழங்குகிறது.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// [`map`](#method.map) போன்ற பிற முறைகளுடன் இணைந்தால் இந்த முறை மிகவும் பயனுள்ளதாக இருக்கும்.
    /// இந்த வழியில், அசல் வரிசையின் கூறுகள் `Copy` ஆக இல்லாவிட்டால் நகர்த்துவதைத் தவிர்க்கலாம்.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // அசல் வரிசையை நாம் இன்னும் அணுகலாம்: அது நகர்த்தப்படவில்லை.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // பாதுகாப்பு: இந்த ஈரேட்டர் சரியாக `N` ஐ வழங்கும் என்பதை நாங்கள் அறிவோம்
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// ஒவ்வொரு உறுப்பையும் மாற்றியமைக்கிறது மற்றும் `self` அதே அளவுடன் மாற்றக்கூடிய குறிப்புகளின் வரிசையை வழங்குகிறது.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // பாதுகாப்பு: இந்த ஈரேட்டர் சரியாக `N` ஐ வழங்கும் என்பதை நாங்கள் அறிவோம்
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `iter` இலிருந்து `N` உருப்படிகளை இழுத்து அவற்றை வரிசையாக வழங்குகிறது.
/// ஈரேட்டர் `N` ஐ விட குறைவான விளைச்சலைக் கொடுத்தால், இந்த செயல்பாடு வரையறுக்கப்படாத நடத்தையை வெளிப்படுத்துகிறது.
///
///
/// மேலும் தகவலுக்கு [`collect_into_array`] ஐப் பார்க்கவும்.
///
/// # Safety
///
/// `iter` குறைந்தது `N` உருப்படிகளை அளிக்கிறது என்பதை உத்தரவாதம் செய்வது அழைப்பாளரின் பொறுப்பாகும்.
/// இந்த நிலையை மீறுவது வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: இங்கே `TrustedLen` ஓரளவு சோதனை.இது ஒரு
    // உள் செயல்பாடு, எனவே இந்த பிணைப்பு ஒரு மோசமான யோசனையாக மாறினால் நீக்க தயங்க.
    // அவ்வாறான நிலையில், கீழே உள்ள குறைந்த `debug_assert!` ஐ அகற்றவும் நினைவில் கொள்ளுங்கள்!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // பாதுகாப்பு: செயல்பாட்டு ஒப்பந்தத்தால் மூடப்பட்டுள்ளது.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `iter` இலிருந்து `N` உருப்படிகளை இழுத்து அவற்றை வரிசையாக வழங்குகிறது.ஈரேட்டர் `N` ஐ விடக் குறைவான விளைச்சலைக் கொடுத்தால், `None` திரும்பப் பெறப்பட்டு, ஏற்கனவே வழங்கப்பட்ட அனைத்து பொருட்களும் கைவிடப்படும்.
///
/// ஈரேட்டர் ஒரு மாற்றக்கூடிய குறிப்பாக அனுப்பப்பட்டதால், இந்த செயல்பாடு `next` ஐ பெரும்பாலான `N` நேரங்களில் அழைக்கிறது என்பதால், மீதமுள்ள உருப்படிகளை மீட்டெடுக்க ஈரேட்டரைப் பயன்படுத்தலாம்.
///
///
/// `iter.next()` பீதி என்றால், ஏற்கனவே ஈரேட்டரால் வழங்கப்பட்ட அனைத்து பொருட்களும் கைவிடப்படும்.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // பாதுகாப்பு: வெற்று வரிசை எப்போதும் வசிக்கும் மற்றும் செல்லுபடியாகும் மாற்றங்கள் இல்லை.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // பாதுகாப்பு: இந்த மூல துண்டில் துவக்கப்பட்ட பொருள்கள் மட்டுமே இருக்கும்.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // பாதுகாப்பு: `guard.initialized` 0 இல் தொடங்குகிறது, இது ஒன்றில் அதிகரிக்கப்படுகிறது
        // லூப் மற்றும் லூப் N ஐ அடைந்தவுடன் அது நிறுத்தப்படும் (இது `array.len()`) ஆகும்.
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // முழு வரிசையும் துவக்கப்பட்டுள்ளதா என சரிபார்க்கவும்.
        if guard.initialized == N {
            mem::forget(guard);

            // பாதுகாப்பு: மேலே உள்ள நிபந்தனை அனைத்து உறுப்புகளும் என்று வலியுறுத்துகிறது
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // `guard.initialized` `N` ஐ அடைவதற்கு முன்பு ஈரேட்டர் தீர்ந்துவிட்டால் மட்டுமே இது அடையும்.
    //
    // `guard` இங்கே கைவிடப்பட்டது என்பதையும் நினைவில் கொள்க, ஏற்கனவே துவக்கப்பட்ட அனைத்து கூறுகளையும் கைவிடுகிறது.
    None
}