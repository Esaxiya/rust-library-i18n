#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! வெளிநாட்டு செயல்பாட்டு இடைமுகம் (FFI) பிணைப்புகள் தொடர்பான பயன்பாடுகள்.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// [pointer] ஆகப் பயன்படுத்தும்போது C இன் `void` வகைக்கு சமம்.
///
/// சாராம்சத்தில், `*const c_void` என்பது C இன் `const void*` க்கு சமம் மற்றும் `*mut c_void` என்பது C இன் `void*` க்கு சமம்.
/// இது C இன் `void` திரும்ப வகைக்கு சமமானதல்ல, இது Rust இன் `()` வகை.
///
/// FFI இல் ஒளிபுகா வகைகளுக்கு சுட்டிகள் மாதிரியாக, `extern type` உறுதிப்படுத்தப்படும் வரை, வெற்று பைட் வரிசையைச் சுற்றி newtype ரேப்பரைப் பயன்படுத்த பரிந்துரைக்கப்படுகிறது.
///
/// விவரங்களுக்கு [Nomicon] ஐப் பார்க்கவும்.
///
/// பழைய Rust தொகுப்பினை 1.1.0 வரை ஆதரிக்க விரும்பினால் ஒருவர் `std::os::raw::c_void` ஐப் பயன்படுத்தலாம்.
/// Rust 1.30.0 க்குப் பிறகு, இந்த வரையறையால் அது மீண்டும் ஏற்றுமதி செய்யப்பட்டது.
/// மேலும் தகவலுக்கு, தயவுசெய்து [RFC 2521] ஐப் படிக்கவும்.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, எல்.எல்.வி.எம் வெற்றிட சுட்டிக்காட்டி வகையை அங்கீகரிக்கவும், எக்ஸ் 100 எக்ஸ் போன்ற நீட்டிப்பு செயல்பாடுகளால், எல்.எல்.வி.எம் பிட்கோடில் ஐ 8 * ஆக குறிப்பிடப்பட வேண்டும்.
// இங்கே பயன்படுத்தப்படும் enum இதை உறுதிசெய்கிறது மற்றும் "raw" வகையை தனிப்பட்ட மாறுபாடுகளைக் கொண்டிருப்பதன் மூலம் தவறாகப் பயன்படுத்துவதைத் தடுக்கிறது.
// எங்களுக்கு இரண்டு வகைகள் தேவை, ஏனென்றால் தொகுப்பாளர் மறுபிரதி பண்புக்கூறு பற்றி புகார் செய்கிறார், மேலும் எங்களுக்கு குறைந்தபட்சம் ஒரு மாறுபாடு தேவை, இல்லையெனில் enum குடியேறாது, குறைந்தபட்சம் அத்தகைய சுட்டிகள் UB ஆக இருக்கும்.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// ஒரு `va_list` இன் அடிப்படை செயல்படுத்தல்.
// பெயர் WIP, இப்போது `VaListImpl` ஐப் பயன்படுத்துகிறது.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` க்கு மேல் மாறுபடும், எனவே ஒவ்வொரு `VaListImpl<'f>` பொருளும் அது வரையறுக்கப்பட்ட செயல்பாட்டின் பகுதியுடன் பிணைக்கப்பட்டுள்ளது
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ஒரு `va_list` இன் ஏபிஐ செயல்படுத்தல்.
/// மேலும் விவரங்களுக்கு [AArch64 Procedure Call Standard] ஐப் பார்க்கவும்.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ஒரு `va_list` இன் ஏபிஐ செயல்படுத்தல்.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ஒரு `va_list` இன் ஏபிஐ செயல்படுத்தல்.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// ஒரு `va_list` க்கு ஒரு ரேப்பர்
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// C இன் `va_list` உடன் பைனரி-இணக்கமான `VaListImpl` ஐ `VaList` ஆக மாற்றவும்.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// C இன் `va_list` உடன் பைனரி-இணக்கமான `VaListImpl` ஐ `VaList` ஆக மாற்றவும்.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait பொது இடைமுகங்களில் பயன்படுத்தப்பட வேண்டும், இருப்பினும், trait ஐ இந்த தொகுதிக்கு வெளியே பயன்படுத்த அனுமதிக்கக்கூடாது.
// ஒரு புதிய வகைக்கு trait ஐ செயல்படுத்த பயனர்களை அனுமதிப்பது (இதன் மூலம் va_arg உள்ளார்ந்த ஒரு புதிய வகையைப் பயன்படுத்த அனுமதிக்கிறது) வரையறுக்கப்படாத நடத்தைக்கு காரணமாக இருக்கலாம்.
//
// FIXME(dlrobertson): ஒரு பொது இடைமுகத்தில் VaArgSafe trait ஐப் பயன்படுத்துவதோடு, அதை வேறு எங்கும் பயன்படுத்த முடியாது என்பதை உறுதிப்படுத்தவும், trait ஒரு தனியார் தொகுதிக்குள் பொதுவில் இருக்க வேண்டும்.
// RFC 2145 செயல்படுத்தப்பட்டவுடன் இதை மேம்படுத்துவது குறித்து ஆராயுங்கள்.
//
//
//
//
mod sealed_trait {
    /// அனுமதிக்கப்பட்ட வகைகளை [super::VaListImpl::arg] உடன் பயன்படுத்த அனுமதிக்கும் Trait.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// அடுத்த வாதத்திற்கு முன்னேற்றம்.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // பாதுகாப்பு: அழைப்பாளர் `va_arg` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
        unsafe { va_arg(self) }
    }

    /// தற்போதைய இடத்தில் `va_list` ஐ நகலெடுக்கிறது.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // பாதுகாப்பு: அழைப்பாளர் `va_end` க்கான பாதுகாப்பு ஒப்பந்தத்தை ஆதரிக்க வேண்டும்.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // பாதுகாப்பு: நாங்கள் `MaybeUninit` க்கு எழுதுகிறோம், இதனால் இது துவக்கப்பட்டு `assume_init` சட்டபூர்வமானது
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: இது `va_end` ஐ அழைக்க வேண்டும், ஆனால் இதற்கு சுத்தமான வழி இல்லை
        // `drop` எப்போதுமே அதன் அழைப்பாளரிடம் சாய்ந்திருக்கும் என்பதற்கு உத்தரவாதம் அளிக்கிறது, எனவே `va_end` நேரடியாக தொடர்புடைய `va_copy` இன் அதே செயல்பாட்டிலிருந்து அழைக்கப்படும்.
        // `man va_end` C க்கு இது தேவைப்படுகிறது, மற்றும் LLVM அடிப்படையில் C சொற்பொருளைப் பின்பற்றுகிறது, எனவே `va_end` எப்போதும் `va_copy` போன்ற அதே செயல்பாட்டிலிருந்து அழைக்கப்படுகிறது என்பதை உறுதிப்படுத்த வேண்டும்.
        //
        // மேலும் விவரங்களுக்கு, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // தற்போதைய எல்.எல்.வி.எம் இலக்குகளில் எக்ஸ் 00 எக்ஸ் ஒரு விருப்பம் இல்லாததால் இது இப்போது செயல்படுகிறது.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` அல்லது `va_copy` உடன் துவக்கப்பட்ட பிறகு ஆர்க்லிஸ்ட் `ap` ஐ அழிக்கவும்.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// ஆர்க்லிஸ்ட் `src` இன் தற்போதைய இருப்பிடத்தை ஆர்க்லிஸ்ட் `dst` க்கு நகலெடுக்கிறது.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` இலிருந்து `T` வகை வாதத்தை ஏற்றுகிறது மற்றும் `ap` புள்ளிகளை வாதத்தை அதிகரிக்கவும்.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}