/// `?` ஆபரேட்டரின் நடத்தையைத் தனிப்பயனாக்க ஒரு trait.
///
/// `Try` ஐ செயல்படுத்தும் ஒரு வகை, இது success/failure இருப்பிடத்தின் அடிப்படையில் அதைக் காண ஒரு நியாயமான வழியைக் கொண்டுள்ளது.
/// இந்த trait ஏற்கனவே உள்ள ஒரு நிகழ்விலிருந்து அந்த வெற்றி அல்லது தோல்வி மதிப்புகளைப் பிரித்தெடுப்பதற்கும் வெற்றி அல்லது தோல்வி மதிப்பிலிருந்து ஒரு புதிய நிகழ்வை உருவாக்குவதற்கும் அனுமதிக்கிறது.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// வெற்றிகரமாக பார்க்கும்போது இந்த மதிப்பின் வகை.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// தோல்வியுற்றதாகக் கருதும்போது இந்த மதிப்பின் வகை.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" ஆபரேட்டரைப் பயன்படுத்துகிறது.`Ok(t)` இன் வருவாய் என்பது மரணதண்டனை சாதாரணமாக தொடர வேண்டும் என்பதாகும், மேலும் `?` இன் விளைவாக `t` மதிப்பு.
    /// `Err(e)` இன் வருவாய் என்பது மரணதண்டனை branch ஐ உட்புறமாக இணைக்கும் `catch` க்கு அல்லது செயல்பாட்டிலிருந்து திரும்ப வேண்டும் என்பதாகும்.
    ///
    /// ஒரு `Err(e)` முடிவு திரும்பினால், `e` மதிப்பு "wrapped" ஆக இருக்கும், இது இணைக்கப்பட்ட நோக்கத்தின் திரும்பும் வகையாகும் (இது `Try` ஐ செயல்படுத்த வேண்டும்).
    ///
    /// குறிப்பாக, `X::from_error(From::from(e))` மதிப்பு திரும்பப்பெறுகிறது, இங்கு `X` என்பது இணைக்கும் செயல்பாட்டின் திரும்ப வகை.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// கலப்பு முடிவை உருவாக்க பிழை மதிப்பை மடக்கு.
    /// எடுத்துக்காட்டாக, `Result::Err(x)` மற்றும் `Result::from_error(x)` ஆகியவை சமமானவை.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// கலப்பு முடிவை உருவாக்க சரி மதிப்பை மடக்கு.
    /// எடுத்துக்காட்டாக, `Result::Ok(x)` மற்றும் `Result::from_ok(x)` ஆகியவை சமமானவை.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}