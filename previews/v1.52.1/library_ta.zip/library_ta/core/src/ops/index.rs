/// மாறாத சூழல்களில் (`container[index]`) செயல்பாடுகளை அட்டவணைப்படுத்த பயன்படுகிறது.
///
/// `container[index]` உண்மையில் `*container.index(index)` க்கான தொடரியல் சர்க்கரை, ஆனால் மாறாத மதிப்பாகப் பயன்படுத்தும்போது மட்டுமே.
/// மாற்றக்கூடிய மதிப்பு கோரப்பட்டால், அதற்கு பதிலாக [`IndexMut`] பயன்படுத்தப்படுகிறது.
/// `value` வகை [`Copy`] ஐ செயல்படுத்தினால் `let value = v[index]` போன்ற நல்ல விஷயங்களை இது அனுமதிக்கிறது.
///
/// # Examples
///
/// பின்வரும் எடுத்துக்காட்டு `Index` ஐ படிக்க மட்டுமேயான `NucleotideCount` கொள்கலனில் செயல்படுத்துகிறது, இது தனிப்பட்ட எண்ணிக்கையை குறியீட்டு தொடரியல் மூலம் மீட்டெடுக்க உதவுகிறது.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// அட்டவணையிட்ட பிறகு திரும்பிய வகை.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// அட்டவணைப்படுத்தல் (`container[index]`) செயல்பாட்டை செய்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// மாற்றக்கூடிய சூழல்களில் (`container[index]`) செயல்பாடுகளை அட்டவணைப்படுத்த பயன்படுகிறது.
///
/// `container[index]` உண்மையில் `*container.index_mut(index)` க்கான தொடரியல் சர்க்கரை, ஆனால் மாற்றக்கூடிய மதிப்பாகப் பயன்படுத்தும்போது மட்டுமே.
/// மாறாத மதிப்பு கோரப்பட்டால், அதற்கு பதிலாக [`Index`] trait பயன்படுத்தப்படுகிறது.
/// இது `v[index] = value` போன்ற நல்ல விஷயங்களை அனுமதிக்கிறது.
///
/// # Examples
///
/// இரண்டு பக்கங்களைக் கொண்ட ஒரு `Balance` கட்டமைப்பின் மிக எளிமையான செயல்படுத்தல், ஒவ்வொன்றும் மாற்றத்தக்க மற்றும் மாறாமல் குறியிடப்படலாம்.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // இந்த விஷயத்தில், `balance[Side::Right]` என்பது `*balance.index(Side::Right)` க்கு சர்க்கரை, ஏனெனில் நாங்கள்* படிக்கிறோம் * `balance[Side::Right]` மட்டுமே, அதை எழுதவில்லை.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // இருப்பினும், இந்த விஷயத்தில் `balance[Side::Left]` என்பது `*balance.index_mut(Side::Left)` க்கு சர்க்கரை, ஏனெனில் நாங்கள் `balance[Side::Left]` ஐ எழுதுகிறோம்.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// மாற்றக்கூடிய அட்டவணைப்படுத்தல் (`container[index]`) செயல்பாட்டை செய்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}