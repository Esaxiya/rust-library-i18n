use crate::fmt;
use crate::hash::Hash;

/// வரம்பற்ற வரம்பு (`..`).
///
/// `RangeFull` முதன்மையாக [slicing index] ஆகப் பயன்படுத்தப்படுகிறது, இதன் சுருக்கெழுத்து `..` ஆகும்.
/// இது ஒரு [`Iterator`] ஆக பணியாற்ற முடியாது, ஏனெனில் அதற்கு தொடக்க புள்ளி இல்லை.
///
/// # Examples
///
/// `..` தொடரியல் ஒரு `RangeFull`:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// இது ஒரு [`IntoIterator`] செயல்படுத்தலைக் கொண்டிருக்கவில்லை, எனவே நீங்கள் இதை நேரடியாக `for` சுழற்சியில் பயன்படுத்த முடியாது.
/// இது தொகுக்காது:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// [slicing index] ஆகப் பயன்படுத்தப்படுகிறது, `RangeFull` முழு வரிசையையும் ஒரு துண்டுகளாக உருவாக்குகிறது.
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // இது `RangeFull` ஆகும்
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// ஒரு (half-open) வரம்பு எல்லாம் கீழே மற்றும் பிரத்தியேகமாக (`start..end`) க்கு மேலே உள்ளது.
///
///
/// `start..end` வரம்பில் `start <= x < end` உடன் அனைத்து மதிப்புகளும் உள்ளன.
/// `start >= end` என்றால் அது காலியாக உள்ளது.
///
/// # Examples
///
/// `start..end` தொடரியல் ஒரு `Range`:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // இது ஒரு `Range`
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // நகலெடுக்கவில்லை-#27186 ஐப் பார்க்கவும்
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// (inclusive) வரம்பின் கீழ் எல்லை.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// (exclusive) வரம்பின் மேல் எல்லை.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// `item` வரம்பில் இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// வரம்பில் உருப்படிகள் எதுவும் இல்லை என்றால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// இருபுறமும் ஒப்பிடமுடியாததாக இருந்தால் வரம்பு காலியாக உள்ளது:
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// ஒரு வரம்பு (`start..`) க்குக் கீழே மட்டுமே வரையறுக்கப்பட்டுள்ளது.
///
/// `RangeFrom` `start..` இல் `x >= start` உடன் அனைத்து மதிப்புகளும் உள்ளன.
///
/// *குறிப்பு*: [`Iterator`] செயல்படுத்தலில் வழிதல் (அடங்கிய தரவு வகை அதன் எண் வரம்பை அடையும் போது) panic, மடக்கு அல்லது நிறைவுற்றதாக அனுமதிக்கப்படுகிறது.
/// இந்த நடத்தை [`Step`] trait ஐ செயல்படுத்துவதன் மூலம் வரையறுக்கப்படுகிறது.
/// பழமையான முழு எண்களுக்கு, இது இயல்பான விதிகளைப் பின்பற்றுகிறது, மேலும் வழிதல் சரிபார்ப்பு சுயவிவரத்தை மதிக்கிறது (பிழைத்திருத்தத்தில் panic, வெளியீட்டில் மடக்கு).
/// நீங்கள் நினைப்பதை விட முன்னதாகவே வழிதல் நிகழ்கிறது என்பதையும் கவனியுங்கள்: அதிகபட்ச மதிப்பைக் கொடுக்கும் `next` க்கான அழைப்பில் வழிதல் நிகழ்கிறது, ஏனெனில் அடுத்த மதிப்பைக் கொடுக்க வரம்பை ஒரு நிலைக்கு அமைக்க வேண்டும்.
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` தொடரியல் ஒரு `RangeFrom`:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // இது ஒரு `RangeFrom`
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // நகலெடுக்கவில்லை-#27186 ஐப் பார்க்கவும்
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// (inclusive) வரம்பின் கீழ் எல்லை.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// `item` வரம்பில் இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// ஒரு வரம்பு (`..end`) க்கு மேலே மட்டுமே வரையறுக்கப்பட்டுள்ளது.
///
/// `RangeTo` `..end` இல் `x < end` உடன் அனைத்து மதிப்புகளும் உள்ளன.
/// இது ஒரு [`Iterator`] ஆக பணியாற்ற முடியாது, ஏனெனில் அதற்கு தொடக்க புள்ளி இல்லை.
///
/// # Examples
///
/// `..end` தொடரியல் ஒரு `RangeTo`:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// இது ஒரு [`IntoIterator`] செயல்படுத்தலைக் கொண்டிருக்கவில்லை, எனவே நீங்கள் இதை நேரடியாக `for` சுழற்சியில் பயன்படுத்த முடியாது.
/// இது தொகுக்காது:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// [slicing index] ஆகப் பயன்படுத்தப்படும்போது, `end` ஆல் குறிக்கப்பட்ட குறியீட்டுக்கு முன் `RangeTo` அனைத்து வரிசை கூறுகளின் துண்டுகளையும் உருவாக்குகிறது.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // இது ஒரு `RangeTo`
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// (exclusive) வரம்பின் மேல் எல்லை.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// `item` வரம்பில் இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// (`start..=end`) க்குக் கீழே மற்றும் அதற்கு மேல் உள்ள வரம்பு.
///
/// `RangeInclusive` `start..=end` இல் `x >= start` மற்றும் `x <= end` உடன் அனைத்து மதிப்புகளும் உள்ளன.`start <= end` வரை இது காலியாக உள்ளது.
///
/// இந்த மறு செய்கை [fused] ஆகும், ஆனால் மறு செய்கை முடிந்தபின் `start` மற்றும் `end` இன் குறிப்பிட்ட மதிப்புகள் **குறிப்பிடப்படாதவை** தவிர, [`.is_empty()`] தவிர வேறு மதிப்புகள் எதுவும் தயாரிக்கப்படாது.
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` தொடரியல் ஒரு `RangeInclusive`:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // இது ஒரு `RangeInclusive`
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // நகலெடுக்கவில்லை-#27186 ஐப் பார்க்கவும்
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // future இல் பிரதிநிதித்துவத்தை மாற்ற அனுமதிக்க இங்குள்ள புலங்கள் பொதுவில் இல்லை என்பதை நினைவில் கொள்க;குறிப்பாக, நாம் start/end ஐ வெளிப்படையாக வெளிப்படுத்தும்போது, (future/current) தனியார் புலங்களை மாற்றாமல் அவற்றை மாற்றுவது தவறான நடத்தைக்கு வழிவகுக்கும், எனவே அந்த பயன்முறையை நாங்கள் ஆதரிக்க விரும்பவில்லை.
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // இந்த புலம்:
    //  - `false` கட்டுமானத்தின் மீது
    //  - `false` மறு செய்கை ஒரு உறுப்பைக் கொடுத்தால் மற்றும் மறு செய்கை தீர்ந்துவிடாது
    //  - `true` மறு செய்கை செயலிழக்க பயன்படுத்தும்போது
    //
    // ஒரு பகுதி ஆர்ட் அல்லது சிறப்பு இல்லாமல் பார்ட்டியல் எக் மற்றும் ஹாஷை ஆதரிக்க இது தேவைப்படுகிறது.
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// புதிய உள்ளடக்கிய வரம்பை உருவாக்குகிறது.`start..=end` எழுதுவதற்கு சமம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// (inclusive) வரம்பின் கீழ் வரம்பை வழங்குகிறது.
    ///
    /// மறு செய்கைக்கு உள்ளடக்கிய வரம்பைப் பயன்படுத்தும் போது, மறு செய்கை முடிந்ததும் `start()` மற்றும் [`end()`] இன் மதிப்புகள் குறிப்பிடப்படவில்லை.
    /// உள்ளடக்கிய வரம்பு காலியாக உள்ளதா என்பதைத் தீர்மானிக்க, `start() > end()` ஐ ஒப்பிடுவதற்கு பதிலாக [`is_empty()`] முறையைப் பயன்படுத்தவும்.
    ///
    /// Note: இந்த முறையால் வழங்கப்பட்ட மதிப்பு குறிப்பிடப்படாது, வரம்பை சோர்வடையச் செய்த பிறகு.
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// (inclusive) வரம்பின் மேல் எல்லையை வழங்குகிறது.
    ///
    /// மறு செய்கைக்கு உள்ளடக்கிய வரம்பைப் பயன்படுத்தும் போது, மறு செய்கை முடிந்ததும் [`start()`] மற்றும் `end()` இன் மதிப்புகள் குறிப்பிடப்படவில்லை.
    /// உள்ளடக்கிய வரம்பு காலியாக உள்ளதா என்பதைத் தீர்மானிக்க, `start() > end()` ஐ ஒப்பிடுவதற்கு பதிலாக [`is_empty()`] முறையைப் பயன்படுத்தவும்.
    ///
    /// Note: இந்த முறையால் வழங்கப்பட்ட மதிப்பு குறிப்பிடப்படாது, வரம்பை சோர்வடையச் செய்த பிறகு.
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// `RangeInclusive` ஐ (குறைந்த பிணைப்பு, மேல் (inclusive) பிணைப்பு) என அழிக்கிறது.
    ///
    /// Note: இந்த முறையால் வழங்கப்பட்ட மதிப்பு குறிப்பிடப்படாது, வரம்பை சோர்வடையச் செய்த பிறகு.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// `SliceIndex` செயலாக்கங்களுக்கான பிரத்யேக `Range` ஆக மாற்றுகிறது.
    /// `end == usize::MAX` உடன் கையாள்வதற்கு அழைப்பாளர் பொறுப்பு.
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // நாங்கள் தீர்ந்துவிடவில்லை என்றால், நாங்கள் வெறுமனே `start..end + 1` ஐ வெட்ட விரும்புகிறோம்.
        // நாங்கள் தீர்ந்துவிட்டால், `end + 1..end + 1` உடன் வெட்டுவது எங்களுக்கு ஒரு வெற்று வரம்பைத் தருகிறது, அது அந்த இறுதிப் புள்ளிக்கான வரம்புகள்-சோதனைகளுக்கு உட்பட்டது.
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// `item` வரம்பில் இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// மறு செய்கை முடிந்ததும் இந்த முறை எப்போதும் `false` ஐ வழங்குகிறது:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // துல்லியமான புல மதிப்புகள் இங்கே குறிப்பிடப்படவில்லை
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// வரம்பில் உருப்படிகள் எதுவும் இல்லை என்றால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// இருபுறமும் ஒப்பிடமுடியாததாக இருந்தால் வரம்பு காலியாக உள்ளது:
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// மறு செய்கை முடிந்ததும் இந்த முறை `true` ஐ வழங்குகிறது:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // துல்லியமான புல மதிப்புகள் இங்கே குறிப்பிடப்படவில்லை
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// ஒரு வரம்பு (`..=end`) க்கு மேல் மட்டுமே உள்ளடக்கியது.
///
/// `RangeToInclusive` `..=end` இல் `x <= end` உடன் அனைத்து மதிப்புகளும் உள்ளன.
/// இது ஒரு [`Iterator`] ஆக பணியாற்ற முடியாது, ஏனெனில் அதற்கு தொடக்க புள்ளி இல்லை.
///
/// # Examples
///
/// `..=end` தொடரியல் ஒரு `RangeToInclusive`:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// இது ஒரு [`IntoIterator`] செயல்படுத்தலைக் கொண்டிருக்கவில்லை, எனவே நீங்கள் இதை நேரடியாக `for` சுழற்சியில் பயன்படுத்த முடியாது.இது தொகுக்காது:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// [slicing index] ஆகப் பயன்படுத்தப்படும்போது, `RangeToInclusive` அனைத்து வரிசை உறுப்புகளின் துண்டுகளையும் `end` ஆல் குறிக்கப்பட்ட குறியீட்டை உள்ளடக்கியது.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // இது ஒரு `RangeToInclusive`
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// (inclusive) வரம்பின் மேல் எல்லை
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// `item` வரம்பில் இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// RangeToInclusive<Idx>இருந்து impl முடியாது <RangeTo<Idx>> ஏனெனில் (..0).into() உடன் கீழ்நோக்கி சாத்தியமாகும்
//

/// விசைகளின் வரம்பின் இறுதிப் புள்ளி.
///
/// # Examples
///
/// `எல்லை` வரம்பு வரம்பு புள்ளிகள்:
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// [`BTreeMap::range`] க்கு ஒரு வாதமாக `பவுண்ட்`ஸின் ஒரு டூப்பிளைப் பயன்படுத்துதல்.
/// பெரும்பாலான சந்தர்ப்பங்களில், அதற்கு பதிலாக வரம்பு தொடரியல் (`1..5`) ஐப் பயன்படுத்துவது நல்லது என்பதை நினைவில் கொள்க.
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// உள்ளடக்கிய பிணைப்பு.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// ஒரு பிரத்யேக பிணைப்பு.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// எல்லையற்ற இறுதிப் புள்ளி.இந்த திசையில் எந்த வரம்பும் இல்லை என்பதைக் குறிக்கிறது.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>` இலிருந்து `Bound<&T>` ஆக மாற்றுகிறது.
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>` இலிருந்து `Bound<&T>` ஆக மாற்றுகிறது.
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// கட்டுப்பட்ட உள்ளடக்கங்களை குளோன் செய்வதன் மூலம் ஒரு `Bound<&T>` ஐ ஒரு `Bound<T>` க்கு வரைபடம்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` `..`, `a..`, `..b`, `..=c`, `d..e`, அல்லது `f..=g` போன்ற வரம்பு தொடரியல் மூலம் தயாரிக்கப்படும் Rust இன் உள்ளமைக்கப்பட்ட வரம்பு வகைகளால் செயல்படுத்தப்படுகிறது.
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// குறியீட்டு பிணைப்பைத் தொடங்குங்கள்.
    ///
    /// தொடக்க மதிப்பை `Bound` ஆக வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// இறுதி அட்டவணை பிணைக்கப்பட்டுள்ளது.
    ///
    /// இறுதி மதிப்பை `Bound` ஆக வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// `item` வரம்பில் இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // ஈரேட்டர் தீர்ந்துவிட்டால், நாங்கள் வழக்கமாக தொடக்க==முடிவைக் கொண்டிருக்கிறோம், ஆனால் வரம்பு காலியாக தோன்ற வேண்டும், அதில் எதுவும் இல்லை.
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}