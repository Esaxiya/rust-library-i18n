/// மாறாத ரிசீவரை எடுக்கும் அழைப்பு ஆபரேட்டரின் பதிப்பு.
///
/// `Fn` இன் நிகழ்வுகளை நிலைமாற்றாமல் மீண்டும் மீண்டும் அழைக்கலாம்.
///
/// *இந்த trait (`Fn`) ஆனது [function pointers] (`fn`) உடன் குழப்பமடையக்கூடாது.*
///
/// `Fn` கைப்பற்றப்பட்ட மாறிகள் பற்றிய மாறாத குறிப்புகளை மட்டுமே எடுக்கும் அல்லது எதையும் கைப்பற்றாத மூடுதல்களால் தானாகவே செயல்படுத்தப்படுகிறது, அத்துடன் (safe) [function pointers] (சில எச்சரிக்கைகளுடன், மேலும் விவரங்களுக்கு அவற்றின் ஆவணங்களைப் பார்க்கவும்).
///
/// கூடுதலாக, `Fn` ஐ செயல்படுத்தும் எந்த வகை `F` க்கும், `&F` `Fn` ஐ செயல்படுத்துகிறது.
///
/// [`FnMut`] மற்றும் [`FnOnce`] இரண்டும் `Fn` இன் சூப்பர் ட்ரெய்டுகள் என்பதால், `Fn` இன் எந்தவொரு நிகழ்வும் ஒரு [`FnMut`] அல்லது [`FnOnce`] எதிர்பார்க்கப்படும் அளவுருவாகப் பயன்படுத்தப்படலாம்.
///
/// செயல்பாடு போன்ற வகையின் ஒரு அளவுருவை நீங்கள் ஏற்றுக்கொள்ள விரும்பினால், அதை மீண்டும் மீண்டும் அழைக்க வேண்டும் மற்றும் நிலை மாறாமல் (எ.கா., ஒரே நேரத்தில் அழைக்கும் போது) `Fn` ஐ ஒரு வரம்பாகப் பயன்படுத்தவும்.
/// உங்களுக்கு இதுபோன்ற கடுமையான தேவைகள் தேவையில்லை என்றால், [`FnMut`] அல்லது [`FnOnce`] ஐ எல்லைகளாகப் பயன்படுத்துங்கள்.
///
/// இந்த தலைப்பில் மேலும் சில தகவல்களுக்கு [chapter on closures in *The Rust Programming Language*][book] ஐப் பார்க்கவும்.
///
/// `Fn` traits க்கான சிறப்பு தொடரியல் (எ.கா.
/// `Fn(usize, bool) -> usize`).இதன் தொழில்நுட்ப விவரங்களில் ஆர்வமுள்ளவர்கள் [the relevant section in the *Rustonomicon*][nomicon] ஐக் குறிப்பிடலாம்.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## மூடுதலை அழைக்கிறது
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` அளவுருவைப் பயன்படுத்துதல்
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // இதனால் regex அந்த `&str: !FnMut` ஐ நம்பலாம்
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// அழைப்பு செயல்பாட்டை செய்கிறது.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// மாற்றக்கூடிய ரிசீவரை எடுக்கும் அழைப்பு ஆபரேட்டரின் பதிப்பு.
///
/// `FnMut` இன் நிகழ்வுகளை மீண்டும் மீண்டும் அழைக்கலாம் மற்றும் நிலையை மாற்றலாம்.
///
/// `FnMut` கைப்பற்றப்பட்ட மாறிகள், மற்றும் [`Fn`], எ.கா., (safe) [function pointers] (`FnMut` [`Fn`] இன் சூப்பர் ட்ரெயிட் என்பதால்) செயல்படுத்தும் அனைத்து வகைகளையும் மாற்றியமைக்கும் குறிப்புகள் எடுக்கும் மூடல்களால் தானாக செயல்படுத்தப்படுகிறது.
/// கூடுதலாக, `FnMut` ஐ செயல்படுத்தும் எந்த வகை `F` க்கும், `&mut F` `FnMut` ஐ செயல்படுத்துகிறது.
///
/// [`FnOnce`] என்பது `FnMut` இன் சூப்பர் ட்ரெயிட் என்பதால், [`FnOnce`] எதிர்பார்க்கப்படும் இடத்தில் `FnMut` இன் எந்தவொரு நிகழ்வையும் பயன்படுத்தலாம், மேலும் [`Fn`] என்பது `FnMut` இன் துணைக்குழு என்பதால், `FnMut` எதிர்பார்க்கப்படும் இடத்தில் [`Fn`] இன் எந்தவொரு நிகழ்வையும் பயன்படுத்தலாம்.
///
/// செயல்பாடு போன்ற வகையின் அளவுருவை நீங்கள் ஏற்றுக்கொள்ள விரும்பினால், அதை மீண்டும் மீண்டும் அழைக்க வேண்டியிருக்கும் போது, `FnMut` ஐ ஒரு வரம்பாகப் பயன்படுத்தவும்.
/// அளவுரு நிலைமாற்றத்தை நீங்கள் விரும்பவில்லை என்றால், [`Fn`] ஐ ஒரு வரம்பாகப் பயன்படுத்தவும்;நீங்கள் அதை மீண்டும் மீண்டும் அழைக்க தேவையில்லை என்றால், [`FnOnce`] ஐப் பயன்படுத்தவும்.
///
/// இந்த தலைப்பில் மேலும் சில தகவல்களுக்கு [chapter on closures in *The Rust Programming Language*][book] ஐப் பார்க்கவும்.
///
/// `Fn` traits க்கான சிறப்பு தொடரியல் (எ.கா.
/// `Fn(usize, bool) -> usize`).இதன் தொழில்நுட்ப விவரங்களில் ஆர்வமுள்ளவர்கள் [the relevant section in the *Rustonomicon*][nomicon] ஐக் குறிப்பிடலாம்.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## மாற்றக்கூடிய கைப்பற்றல் மூடல் என்று அழைக்கப்படுகிறது
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` அளவுருவைப் பயன்படுத்துதல்
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // இதனால் regex அந்த `&str: !FnMut` ஐ நம்பலாம்
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// அழைப்பு செயல்பாட்டை செய்கிறது.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// மதிப்பு மதிப்பு பெறுநரை எடுக்கும் அழைப்பு ஆபரேட்டரின் பதிப்பு.
///
/// `FnOnce` இன் நிகழ்வுகளை அழைக்கலாம், ஆனால் பல முறை அழைக்க முடியாது.இதன் காரணமாக, ஒரு வகையைப் பற்றி அறியப்பட்ட ஒரே விஷயம், அது `FnOnce` ஐ செயல்படுத்துகிறது என்றால், அதை ஒரு முறை மட்டுமே அழைக்க முடியும்.
///
/// `FnOnce` கைப்பற்றப்பட்ட மாறிகள் மற்றும் [`FnMut`], எ.கா., (safe) [function pointers] ஐ செயல்படுத்தும் அனைத்து வகைகளும் (`FnOnce` என்பது [`FnMut`] இன் சூப்பர் ட்ரெய்ட் என்பதால்) தானாக செயல்படுத்தப்படுகிறது.
///
///
/// [`Fn`] மற்றும் [`FnMut`] இரண்டும் `FnOnce` இன் துணைக்குழுக்கள் என்பதால், [`Fn`] அல்லது [`FnMut`] இன் எந்தவொரு நிகழ்வும் ஒரு `FnOnce` எதிர்பார்க்கப்படும் இடத்தில் பயன்படுத்தப்படலாம்.
///
/// செயல்பாடு போன்ற வகையின் அளவுருவை நீங்கள் ஏற்றுக்கொள்ள விரும்பினால், அதை ஒரு முறை மட்டுமே அழைக்க வேண்டும்.
/// நீங்கள் அளவுருவை மீண்டும் மீண்டும் அழைக்க வேண்டும் என்றால், [`FnMut`] ஐ ஒரு வரம்பாகப் பயன்படுத்தவும்;நிலையை மாற்றக்கூடாது என்பதும் உங்களுக்குத் தேவைப்பட்டால், [`Fn`] ஐப் பயன்படுத்தவும்.
///
/// இந்த தலைப்பில் மேலும் சில தகவல்களுக்கு [chapter on closures in *The Rust Programming Language*][book] ஐப் பார்க்கவும்.
///
/// `Fn` traits க்கான சிறப்பு தொடரியல் (எ.கா.
/// `Fn(usize, bool) -> usize`).இதன் தொழில்நுட்ப விவரங்களில் ஆர்வமுள்ளவர்கள் [the relevant section in the *Rustonomicon*][nomicon] ஐக் குறிப்பிடலாம்.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` அளவுருவைப் பயன்படுத்துதல்
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` கைப்பற்றப்பட்ட மாறிகள் பயன்படுத்துகிறது, எனவே இதை ஒன்றுக்கு மேற்பட்ட முறை இயக்க முடியாது.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` ஐ மீண்டும் செயல்படுத்த முயற்சிப்பது `func` க்கு `use of moved value` பிழையை எறியும்.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` இந்த கட்டத்தில் இனி செயல்படுத்த முடியாது
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // இதனால் regex அந்த `&str: !FnMut` ஐ நம்பலாம்
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// அழைப்பு ஆபரேட்டர் பயன்படுத்தப்பட்ட பின் திரும்பிய வகை.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// அழைப்பு செயல்பாட்டை செய்கிறது.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}