use crate::ops::Try;

/// ஒரு செயல்பாட்டை ஆரம்பத்தில் இருந்து வெளியேற வேண்டுமா அல்லது வழக்கம் போல் செல்ல வேண்டுமா என்று சொல்ல பயன்படுகிறது.
///
/// விஷயங்களை வெளியேற்றும்போது இது பயன்படுத்தப்படுகிறது (வரைபடப் பயணங்கள் அல்லது பார்வையாளர்கள் போன்றவை) நீங்கள் ஆரம்பத்தில் வெளியேற வேண்டுமா என்பதை பயனர் தேர்வு செய்ய வேண்டும்.
/// Enum ஐ வைத்திருப்பது தெளிவுபடுத்துகிறது-"wait, what did `false` mean again?" ஆச்சரியப்படுவதற்கில்லை-மேலும் ஒரு மதிப்பு உட்பட அனுமதிக்கிறது.
///
/// # Examples
///
/// [`Iterator::try_for_each`] இலிருந்து ஆரம்பத்தில் வெளியேறுதல்:
///
/// ```
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// let r = (2..100).try_for_each(|x| {
///     if 403 % x == 0 {
///         return ControlFlow::Break(x)
///     }
///
///     ControlFlow::Continue(())
/// });
/// assert_eq!(r, ControlFlow::Break(13));
/// ```
///
/// ஒரு அடிப்படை மரம் பயணம்:
///
/// ```no_run
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// pub struct TreeNode<T> {
///     value: T,
///     left: Option<Box<TreeNode<T>>>,
///     right: Option<Box<TreeNode<T>>>,
/// }
///
/// impl<T> TreeNode<T> {
///     pub fn traverse_inorder<B>(&self, mut f: impl FnMut(&T) -> ControlFlow<B>) -> ControlFlow<B> {
///         if let Some(left) = &self.left {
///             left.traverse_inorder(&mut f)?;
///         }
///         f(&self.value)?;
///         if let Some(right) = &self.right {
///             right.traverse_inorder(&mut f)?;
///         }
///         ControlFlow::Continue(())
///     }
/// }
/// ```
#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ControlFlow<B, C = ()> {
    /// செயல்பாட்டின் அடுத்த கட்டத்திற்கு இயல்பாக செல்லுங்கள்.
    Continue(C),
    /// அடுத்தடுத்த கட்டங்களை இயக்காமல் செயல்பாட்டிலிருந்து வெளியேறவும்.
    Break(B),
    // ஆம், மாறுபாடுகளின் வரிசை வகை அளவுருக்களுடன் பொருந்தவில்லை.
    // அவர்கள் இந்த வரிசையில் இருக்கிறார்கள், இதனால் `ControlFlow<A, B>` <-> `Result<B, A>` என்பது `Try` செயல்படுத்தலில் ஒரு விருப்பமற்ற மாற்றமாகும்.
    //
}

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
impl<B, C> Try for ControlFlow<B, C> {
    type Ok = C;
    type Error = B;
    #[inline]
    fn into_result(self) -> Result<Self::Ok, Self::Error> {
        match self {
            ControlFlow::Continue(y) => Ok(y),
            ControlFlow::Break(x) => Err(x),
        }
    }
    #[inline]
    fn from_error(v: Self::Error) -> Self {
        ControlFlow::Break(v)
    }
    #[inline]
    fn from_ok(v: Self::Ok) -> Self {
        ControlFlow::Continue(v)
    }
}

impl<B, C> ControlFlow<B, C> {
    /// இது `Break` மாறுபாடாக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(ControlFlow::<i32, String>::Break(3).is_break());
    /// assert!(!ControlFlow::<String, i32>::Continue(3).is_break());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_break(&self) -> bool {
        matches!(*self, ControlFlow::Break(_))
    }

    /// இது `Continue` மாறுபாடாக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(!ControlFlow::<i32, String>::Break(3).is_continue());
    /// assert!(ControlFlow::<String, i32>::Continue(3).is_continue());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_continue(&self) -> bool {
        matches!(*self, ControlFlow::Continue(_))
    }

    /// `ControlFlow` ஐ `Option` ஆக மாற்றுகிறது, இது `ControlFlow` `Break` ஆகவும், இல்லையெனில் `None` ஆகவும் இருந்தால் `Some` ஆகும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert_eq!(ControlFlow::<i32, String>::Break(3).break_value(), Some(3));
    /// assert_eq!(ControlFlow::<String, i32>::Continue(3).break_value(), None);
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn break_value(self) -> Option<B> {
        match self {
            ControlFlow::Continue(..) => None,
            ControlFlow::Break(x) => Some(x),
        }
    }

    /// ஒரு செயல்பாட்டை முறிவு மதிப்பில் பயன்படுத்துவதன் மூலம் `ControlFlow<B, C>` முதல் `ControlFlow<T, C>` வரை வரைபடங்கள்.
    ///
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn map_break<T, F>(self, f: F) -> ControlFlow<T, C>
    where
        F: FnOnce(B) -> T,
    {
        match self {
            ControlFlow::Continue(x) => ControlFlow::Continue(x),
            ControlFlow::Break(x) => ControlFlow::Break(f(x)),
        }
    }
}

impl<R: Try> ControlFlow<R, R::Ok> {
    /// `Try` ஐ செயல்படுத்தும் எந்த வகையிலிருந்தும் ஒரு `ControlFlow` ஐ உருவாக்கவும்.
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn from_try(r: R) -> Self {
        match Try::into_result(r) {
            Ok(v) => ControlFlow::Continue(v),
            Err(v) => ControlFlow::Break(Try::from_error(v)),
        }
    }

    /// `Try` ஐ செயல்படுத்தும் எந்த வகையிலும் `ControlFlow` ஐ மாற்றவும்;
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn into_try(self) -> R {
        match self {
            ControlFlow::Continue(v) => Try::from_ok(v),
            ControlFlow::Break(v) => v,
        }
    }
}

impl<B> ControlFlow<B, ()> {
    /// `Continue` உடன் எந்த மதிப்பும் தேவையில்லை என்பது அடிக்கடி நிகழ்கிறது, எனவே நீங்கள் விரும்பினால், `(())` ஐ தட்டச்சு செய்வதைத் தவிர்க்க இது ஒரு வழியை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// let last_used = (1..10).chain(20..25).try_for_each(|x| {
    ///     partial_sum += x;
    ///     if partial_sum > 100 { ControlFlow::Break(x) }
    ///     else { ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(last_used.break_value(), Some(22));
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const CONTINUE: Self = ControlFlow::Continue(());
}

impl<C> ControlFlow<(), C> {
    /// `try_for_each` போன்ற API களுக்கு `Break` உடன் மதிப்புகள் தேவையில்லை, எனவே நீங்கள் விரும்பினால், `(())` ஐ தட்டச்சு செய்வதைத் தவிர்க்க இது ஒரு வழியை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// (1..10).chain(20..25).try_for_each(|x| {
    ///     if partial_sum > 100 { ControlFlow::BREAK }
    ///     else { partial_sum += x; ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(partial_sum, 108);
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const BREAK: Self = ControlFlow::Break(());
}