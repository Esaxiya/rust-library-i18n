/// `*v` போன்ற மாறாத dereferencing நடவடிக்கைகளுக்குப் பயன்படுத்தப்படுகிறது.
///
/// மாறாத சூழல்களில் (unary) `*` ஆபரேட்டருடன் வெளிப்படையான விலக்குதல் நடவடிக்கைகளுக்குப் பயன்படுத்தப்படுவதோடு கூடுதலாக, `Deref` பல சூழ்நிலைகளில் தொகுப்பாளரால் மறைமுகமாகப் பயன்படுத்தப்படுகிறது.
/// இந்த வழிமுறை ['`Deref` coercion'][more] என அழைக்கப்படுகிறது.
/// மாற்றக்கூடிய சூழல்களில், [`DerefMut`] பயன்படுத்தப்படுகிறது.
///
/// ஸ்மார்ட் சுட்டிகள் `Deref` ஐ செயல்படுத்துவது அவற்றின் பின்னால் உள்ள தரவை அணுக வசதியாகிறது, அதனால்தான் அவை `Deref` ஐ செயல்படுத்துகின்றன.
/// மறுபுறம், `Deref` மற்றும் [`DerefMut`] தொடர்பான விதிகள் குறிப்பாக ஸ்மார்ட் சுட்டிகள் பொருத்தமாக வடிவமைக்கப்பட்டுள்ளன.
/// இதன் காரணமாக, குழப்பத்தைத் தவிர்க்க ** `டெரெஃப்` ஸ்மார்ட் சுட்டிகளுக்கு மட்டுமே செயல்படுத்தப்பட வேண்டும்.
///
/// இதே போன்ற காரணங்களுக்காக,**இந்த trait ஒருபோதும் தோல்வியடையக்கூடாது**.`Deref` மறைமுகமாக செயல்படுத்தப்படும்போது, டிஃபெரென்சிங்கின் போது தோல்வி மிகவும் குழப்பமாக இருக்கும்.
///
/// # `Deref` வற்புறுத்தலில் மேலும்
///
/// `T` `Deref<Target = U>` ஐ செயல்படுத்துகிறது, மற்றும் `x` என்பது `T` வகையின் மதிப்பு என்றால், பின்:
///
/// * மாறாத சூழல்களில், `*x` (அங்கு `T` என்பது குறிப்பு அல்லது மூல சுட்டிக்காட்டி அல்ல) `* Deref::deref(&x)` க்கு சமம்.
/// * `&T` வகை மதிப்புகள் `&U` வகை மதிப்புகளுக்கு கட்டாயப்படுத்தப்படுகின்றன
/// * `T` `U` வகையின் அனைத்து (immutable) முறைகளையும் மறைமுகமாக செயல்படுத்துகிறது.
///
/// மேலும் விவரங்களுக்கு, [the chapter in *The Rust Programming Language*][book] மற்றும் [the dereference operator][ref-deref-op], [method resolution] மற்றும் [type coercions] இல் உள்ள குறிப்பு பிரிவுகளையும் பார்வையிடவும்.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ஒற்றை புலத்துடன் கூடிய ஒரு கட்டமைப்பு, இது கட்டமைப்பைக் குறிப்பதன் மூலம் அணுகக்கூடியது.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Dereferencing பிறகு விளைவாக வகை.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// மதிப்பைக் குறைக்கிறது.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` இல் உள்ளதைப் போல மாற்றக்கூடிய dereferencing நடவடிக்கைகளுக்குப் பயன்படுத்தப்படுகிறது.
///
/// மாற்றக்கூடிய சூழல்களில் (unary) `*` ஆபரேட்டருடன் வெளிப்படையான விலக்குதல் நடவடிக்கைகளுக்குப் பயன்படுத்தப்படுவதோடு கூடுதலாக, `DerefMut` பல சூழ்நிலைகளில் தொகுப்பாளரால் மறைமுகமாகப் பயன்படுத்தப்படுகிறது.
/// இந்த வழிமுறை ['`Deref` coercion'][more] என அழைக்கப்படுகிறது.
/// மாறாத சூழல்களில், [`Deref`] பயன்படுத்தப்படுகிறது.
///
/// ஸ்மார்ட் சுட்டிகள் `DerefMut` ஐ செயல்படுத்துவது அவற்றின் பின்னால் உள்ள தரவை மாற்றுவதற்கு வசதியானது, அதனால்தான் அவை `DerefMut` ஐ செயல்படுத்துகின்றன.
/// மறுபுறம், [`Deref`] மற்றும் `DerefMut` தொடர்பான விதிகள் குறிப்பாக ஸ்மார்ட் சுட்டிகள் பொருத்தமாக வடிவமைக்கப்பட்டுள்ளன.
/// இதன் காரணமாக, குழப்பத்தைத் தவிர்க்க ** `டெரெஃப்மட்` ஸ்மார்ட் சுட்டிகள் மட்டுமே செயல்படுத்தப்பட வேண்டும்.
///
/// இதே போன்ற காரணங்களுக்காக,**இந்த trait ஒருபோதும் தோல்வியடையக்கூடாது**.`DerefMut` மறைமுகமாக செயல்படுத்தப்படும்போது, டிஃபெரென்சிங்கின் போது தோல்வி மிகவும் குழப்பமாக இருக்கும்.
///
/// # `Deref` வற்புறுத்தலில் மேலும்
///
/// `T` `DerefMut<Target = U>` ஐ செயல்படுத்துகிறது, மற்றும் `x` என்பது `T` வகையின் மதிப்பு என்றால், பின்:
///
/// * மாற்றக்கூடிய சூழல்களில், `*x` (அங்கு `T` என்பது குறிப்பு அல்லது மூல சுட்டிக்காட்டி அல்ல) `* DerefMut::deref_mut(&mut x)` க்கு சமம்.
/// * `&mut T` வகை மதிப்புகள் `&mut U` வகை மதிப்புகளுக்கு கட்டாயப்படுத்தப்படுகின்றன
/// * `T` `U` வகையின் அனைத்து (mutable) முறைகளையும் மறைமுகமாக செயல்படுத்துகிறது.
///
/// மேலும் விவரங்களுக்கு, [the chapter in *The Rust Programming Language*][book] மற்றும் [the dereference operator][ref-deref-op], [method resolution] மற்றும் [type coercions] இல் உள்ள குறிப்பு பிரிவுகளையும் பார்வையிடவும்.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ஒற்றை புலத்துடன் கூடிய ஒரு கட்டமைப்பு, இது கட்டமைப்பைக் குறைப்பதன் மூலம் மாற்றக்கூடியது.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// மதிப்பை மாற்றியமைக்கிறது.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// `arbitrary_self_types` அம்சம் இல்லாமல், ஒரு struct ஐ ஒரு முறை பெறுநராகப் பயன்படுத்தலாம் என்பதைக் குறிக்கிறது.
///
/// இது `Box<T>`, `Rc<T>`, `&T` மற்றும் `Pin<P>` போன்ற stdlib சுட்டிக்காட்டி வகைகளால் செயல்படுத்தப்படுகிறது.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}