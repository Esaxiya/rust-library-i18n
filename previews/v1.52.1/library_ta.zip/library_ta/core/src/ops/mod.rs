//! அதிக ஏற்றக்கூடிய ஆபரேட்டர்கள்.
//!
//! இந்த traits ஐ செயல்படுத்துவது சில ஆபரேட்டர்களை ஓவர்லோட் செய்ய உங்களை அனுமதிக்கிறது.
//!
//! இந்த traits இல் சில prelude ஆல் இறக்குமதி செய்யப்படுகின்றன, எனவே அவை ஒவ்வொரு Rust நிரலிலும் கிடைக்கின்றன.traits ஆல் ஆதரிக்கப்படும் ஆபரேட்டர்களை மட்டுமே அதிக சுமை செய்ய முடியும்.
//! எடுத்துக்காட்டாக, கூட்டல் ஆபரேட்டர் (`+`) ஐ [`Add`] trait வழியாக ஓவர்லோட் செய்யலாம், ஆனால் அசைன்மென்ட் ஆபரேட்டர் (`=`) க்கு trait இன் ஆதரவு இல்லாததால், அதன் சொற்பொருளை ஓவர்லோட் செய்வதற்கான வழி இல்லை.
//! கூடுதலாக, இந்த தொகுதி புதிய ஆபரேட்டர்களை உருவாக்க எந்த வழிமுறையையும் வழங்காது.
//! பண்பற்ற ஓவர்லோடிங் அல்லது தனிப்பயன் ஆபரேட்டர்கள் தேவைப்பட்டால், Rust இன் தொடரியல் விரிவாக்க மேக்ரோக்கள் அல்லது கம்பைலர் செருகுநிரல்களைப் பார்க்க வேண்டும்.
//!
//! ஆபரேட்டர் traits இன் செயல்பாடுகள் அந்தந்த சூழல்களில் ஆச்சரியப்படத்தக்கதாக இருக்க வேண்டும், அவற்றின் வழக்கமான அர்த்தங்கள் மற்றும் [operator precedence] ஆகியவற்றை மனதில் வைத்துக் கொள்ளுங்கள்.
//! எடுத்துக்காட்டாக, [`Mul`] ஐ செயல்படுத்தும்போது, செயல்பாட்டில் பெருக்கத்திற்கு சில ஒற்றுமைகள் இருக்க வேண்டும் (மற்றும் அசோசியேட்டிவிட்டி போன்ற எதிர்பார்க்கப்படும் பண்புகளைப் பகிர்ந்து கொள்ளுங்கள்).
//!
//! `&&` மற்றும் `||` ஆபரேட்டர்கள் ஷார்ட்-சர்க்யூட், அதாவது, அவை அவற்றின் இரண்டாவது செயல்பாட்டை முடிவுக்கு பங்களித்தால் மட்டுமே மதிப்பீடு செய்கின்றன என்பதை நினைவில் கொள்க.இந்த நடத்தை traits ஆல் செயல்படுத்த முடியாததால், அதிக சுமை கொண்ட ஆபரேட்டர்களாக `&&` மற்றும் `||` ஆதரிக்கப்படவில்லை.
//!
//! பல ஆபரேட்டர்கள் தங்கள் செயல்பாடுகளை மதிப்பால் எடுத்துக்கொள்கிறார்கள்.உள்ளமைக்கப்பட்ட வகைகளை உள்ளடக்கிய பொதுவான அல்லாத சூழல்களில், இது பொதுவாக ஒரு பிரச்சினை அல்ல.
//! இருப்பினும், இந்த ஆபரேட்டர்களை பொதுவான குறியீட்டில் பயன்படுத்துவதற்கு, ஆபரேட்டர்கள் அவற்றை உட்கொள்வதை விட மதிப்புகளை மீண்டும் பயன்படுத்த வேண்டுமானால் சில கவனம் தேவை.எப்போதாவது [`clone`] ஐப் பயன்படுத்துவது ஒரு விருப்பமாகும்.
//! குறிப்புகளுக்கு கூடுதல் ஆபரேட்டர் செயலாக்கங்களை வழங்கும் வகைகளை நம்புவது மற்றொரு விருப்பமாகும்.
//! எடுத்துக்காட்டாக, கூடுதலாக ஆதரிக்கப்பட வேண்டிய பயனர் வரையறுக்கப்பட்ட வகை `T` க்கு, `T` மற்றும் `&T` இரண்டும் traits [`Add<T>`][`Add`] மற்றும் [`Add<&T>`][`Add`] ஐ செயல்படுத்துவது நல்லது, இதனால் தேவையற்ற குளோனிங் இல்லாமல் பொதுவான குறியீட்டை எழுத முடியும்.
//!
//!
//! # Examples
//!
//! இந்த எடுத்துக்காட்டு ஒரு `Point` கட்டமைப்பை உருவாக்குகிறது, இது [`Add`] மற்றும் [`Sub`] ஐ செயல்படுத்துகிறது, பின்னர் இரண்டு `புள்ளிகளைச் சேர்ப்பது மற்றும் கழிப்பதை நிரூபிக்கிறது.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! எடுத்துக்காட்டு செயல்படுத்த ஒவ்வொரு trait க்கான ஆவணங்களைக் காண்க.
//!
//! [`Fn`], [`FnMut`] மற்றும் [`FnOnce`] traits ஆகியவை செயல்பாடுகளைப் போல செயல்படுத்தக்கூடிய வகைகளால் செயல்படுத்தப்படுகின்றன.[`Fn`] `&self` ஐ எடுக்கும், [`FnMut`] `&mut self` ஐ எடுக்கும் மற்றும் [`FnOnce`] `self` ஐ எடுக்கும் என்பதை நினைவில் கொள்க.
//! இவை ஒரு நிகழ்வில் செயல்படுத்தப்படக்கூடிய மூன்று வகையான முறைகளுக்கு ஒத்திருக்கின்றன: அழைப்பு-மூலம்-குறிப்பு, அழைப்பு-மூலம்-மாற்றக்கூடிய-குறிப்பு, மற்றும் அழைப்பு-மதிப்பு.
//! இந்த traits இன் மிகவும் பொதுவான பயன்பாடு, செயல்பாடுகளை அல்லது மூடுதல்களை வாதங்களாக எடுத்துக் கொள்ளும் உயர்-நிலை செயல்பாடுகளுக்கு எல்லைகளாக செயல்படுவது.
//!
//! ஒரு அளவுருவாக [`Fn`] ஐ எடுத்துக்கொள்வது:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! ஒரு அளவுருவாக [`FnMut`] ஐ எடுத்துக்கொள்வது:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! ஒரு அளவுருவாக [`FnOnce`] ஐ எடுத்துக்கொள்வது:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` கைப்பற்றப்பட்ட மாறிகள் பயன்படுத்துகிறது, எனவே இதை ஒன்றுக்கு மேற்பட்ட முறை இயக்க முடியாது
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` ஐ மீண்டும் செயல்படுத்த முயற்சிப்பது `func` க்கு `use of moved value` பிழையை எறியும்
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` இந்த கட்டத்தில் இனி செயல்படுத்த முடியாது
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;