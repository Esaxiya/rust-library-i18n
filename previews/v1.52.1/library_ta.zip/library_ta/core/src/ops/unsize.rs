use crate::marker::Unsize;

/// Trait இது ஒரு சுட்டிக்காட்டி அல்லது ஒருவருக்கான ரேப்பர் என்பதைக் குறிக்கிறது, அங்கு சுட்டிக்காட்டி மீது அளவீடு செய்ய முடியும்.
///
/// மேலும் விவரங்களுக்கு [DST coercion RFC][dst-coerce] மற்றும் [the nomicon entry on coercion][nomicon-coerce] ஐப் பார்க்கவும்.
///
/// பில்டின் சுட்டிக்காட்டி வகைகளுக்கு, ஒரு மெல்லிய சுட்டிக்காட்டி முதல் கொழுப்பு சுட்டிக்காட்டிக்கு மாற்றுவதன் மூலம் `T: Unsize<U>` என்றால் `T` க்கு சுட்டிகள் `U` க்கு சுட்டிகள் கட்டாயப்படுத்தப்படும்.
///
/// தனிப்பயன் வகைகளுக்கு, இங்கே வற்புறுத்தல் `Foo<T>` ஐ `Foo<U>` க்கு கட்டாயப்படுத்துவதன் மூலம் செயல்படுகிறது.
/// `Foo<T>` இல் `T` சம்பந்தப்பட்ட ஒரு பாண்டம்டேட்டா அல்லாத புலம் மட்டுமே இருந்தால் மட்டுமே அத்தகைய தூண்டுதலை எழுத முடியும்.
/// அந்த புலத்தின் வகை `Bar<T>` ஆக இருந்தால், `CoerceUnsized<Bar<U>> for Bar<T>` இன் செயல்படுத்தல் இருக்க வேண்டும்.
/// `Bar<T>` புலத்தை `Bar<U>` க்கு கட்டாயப்படுத்துவதன் மூலமும், X003 ஐ உருவாக்க `Foo<T>` இலிருந்து மீதமுள்ள புலங்களை நிரப்புவதன் மூலமும் இந்த வற்புறுத்தல் செயல்படும்.
/// இது ஒரு சுட்டிக்காட்டி புலத்திற்கு திறம்பட துளையிட்டு, அதை கட்டாயப்படுத்தும்.
///
/// பொதுவாக, ஸ்மார்ட் சுட்டிகளுக்கு நீங்கள் `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ஐ செயல்படுத்துவீர்கள், விருப்பமான `?Sized` ஆனது `T` இல் பிணைக்கப்பட்டுள்ளது.
/// `Cell<T>` மற்றும் `RefCell<T>` போன்ற `T` ஐ நேரடியாக உட்பொதிக்கும் ரேப்பர் வகைகளுக்கு, நீங்கள் நேரடியாக `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` ஐ செயல்படுத்தலாம்.
///
/// இது `Cell<Box<T>>` போன்ற வகைகளின் வற்புறுத்தல்களை வேலை செய்ய அனுமதிக்கும்.
///
/// [`Unsize`][unsize] சுட்டிகள் பின்னால் இருந்தால் டிஎஸ்டிகளுக்கு கட்டாயப்படுத்தக்கூடிய வகைகளைக் குறிக்கப் பயன்படுகிறது.இது தொகுப்பால் தானாக செயல்படுத்தப்படுகிறது.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut டி-> எக்ஸ் 100 எக்ஸ்
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut டி-> * மட் யு
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// இது ஒரு பொருளின் ரிசீவர் வகையை அனுப்ப முடியுமா என்பதை சரிபார்க்க, பொருள் பாதுகாப்புக்காக பயன்படுத்தப்படுகிறது.
///
/// trait இன் எடுத்துக்காட்டு செயல்படுத்தல்:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}