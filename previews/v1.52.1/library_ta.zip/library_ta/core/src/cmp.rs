//! வரிசைப்படுத்துதல் மற்றும் ஒப்பிடுவதற்கான செயல்பாடு.
//!
//! இந்த தொகுதி மதிப்புகளை வரிசைப்படுத்துவதற்கும் ஒப்பிடுவதற்கும் பல்வேறு கருவிகளைக் கொண்டுள்ளது.சுருக்கமாக:
//!
//! * [`Eq`] மற்றும் [`PartialEq`] ஆகியவை traits ஆகும், அவை முறையே மதிப்புகளுக்கு இடையில் மொத்த மற்றும் பகுதி சமத்துவத்தை வரையறுக்க அனுமதிக்கின்றன.
//! அவற்றை செயல்படுத்துவது `==` மற்றும் `!=` ஆபரேட்டர்களை ஓவர்லோட் செய்கிறது.
//! * [`Ord`] மற்றும் [`PartialOrd`] ஆகியவை traits ஆகும், அவை முறையே மதிப்புகளுக்கு இடையில் மொத்த மற்றும் பகுதி வரிசைகளை வரையறுக்க அனுமதிக்கின்றன.
//!
//! அவற்றை செயல்படுத்துவது `<`, `<=`, `>` மற்றும் `>=` ஆபரேட்டர்களை ஓவர்லோட் செய்கிறது.
//! * [`Ordering`] இது [`Ord`] மற்றும் [`PartialOrd`] இன் முக்கிய செயல்பாடுகளால் வழங்கப்பட்ட ஒரு enum ஆகும், மேலும் ஒரு வரிசைப்படுத்தலை விவரிக்கிறது.
//! * [`Reverse`] ஒரு வரிசைமுறையை எளிதில் மாற்றியமைக்க உங்களை அனுமதிக்கும் ஒரு கட்டமைப்பு ஆகும்.
//! * [`max`] மற்றும் [`min`] என்பது [`Ord`] ஐ உருவாக்கும் செயல்பாடுகள் மற்றும் அதிகபட்சம் அல்லது குறைந்தபட்சம் இரண்டு மதிப்புகளைக் கண்டறிய உங்களை அனுமதிக்கும்.
//!
//! மேலும் விவரங்களுக்கு, பட்டியலில் உள்ள ஒவ்வொரு பொருளின் அந்தந்த ஆவணங்களையும் பார்க்கவும்.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) என்ற சமத்துவ ஒப்பீடுகளுக்கான Trait.
///
/// இந்த trait பகுதி சமத்துவத்தை அனுமதிக்கிறது, முழு சமநிலை உறவு இல்லாத வகைகளுக்கு.
/// எடுத்துக்காட்டாக, மிதக்கும் புள்ளி எண்களில் `NaN != NaN`, எனவே மிதக்கும் புள்ளி வகைகள் `PartialEq` ஐ செயல்படுத்துகின்றன, ஆனால் [`trait@Eq`] அல்ல.
///
/// முறையாக, சமத்துவம் இருக்க வேண்டும் (அனைத்து `a`, `b`, `c` வகை `A`, `B`, `C`):
///
/// - **சமச்சீர்**: `A: PartialEq<B>` மற்றும் `B: PartialEq<A>` எனில்,**`a==b` என்பது`b==a`** ஐ குறிக்கிறது;மற்றும்
///
/// - **இடைநிலை**: `A: PartialEq<B>` மற்றும் `B: PartialEq<C>` மற்றும் `A என்றால்:
///   பகுதி எக்<C>`, பின்னர் **` a==b`மற்றும் `b == c` என்பது`a==c`** ஐ குறிக்கிறது.
///
/// `B: PartialEq<A>` (symmetric) மற்றும் `A: PartialEq<C>` (transitive) impls இருப்பதை கட்டாயப்படுத்தவில்லை என்பதை நினைவில் கொள்க, ஆனால் இந்த தேவைகள் அவை இருக்கும்போதெல்லாம் பொருந்தும்.
///
/// ## Derivable
///
/// இந்த trait ஐ `#[derive]` உடன் பயன்படுத்தலாம்.கட்டமைப்புகளில் `பெறும்போது ', எல்லா புலங்களும் சமமாக இருந்தால் இரண்டு நிகழ்வுகள் சமம், எந்த புலங்களும் சமமாக இல்லாவிட்டால் சமமாக இருக்காது.Enums இல்`பெறும்போது ', ஒவ்வொரு மாறுபாடும் தனக்கு சமம் மற்றும் பிற வகைகளுக்கு சமமாக இருக்காது.
///
/// ## `PartialEq` ஐ எவ்வாறு செயல்படுத்தலாம்?
///
/// `PartialEq` [`eq`] முறையை மட்டுமே செயல்படுத்த வேண்டும்;[`ne`] இயல்பாக அதன் அடிப்படையில் வரையறுக்கப்படுகிறது.[`ne`] * இன் எந்தவொரு கையேடு செயலாக்கமும் [`eq`] என்பது [`ne`] இன் கடுமையான தலைகீழ் என்ற விதியை மதிக்க வேண்டும்;அதாவது, `!(a == b)` என்றால் மற்றும் `a != b` என்றால் மட்டுமே.
///
/// `PartialEq`, [`PartialOrd`] மற்றும் [`Ord`]*இன் செயல்பாடுகள்* ஒருவருக்கொருவர் உடன்பட வேண்டும்.சில traits ஐப் பெறுவதன் மூலமும் மற்றவர்களை கைமுறையாக செயல்படுத்துவதன் மூலமும் தற்செயலாக அவர்களை உடன்பட வைப்பது எளிது.
///
/// ஒரு டொமைனுக்கான எடுத்துக்காட்டு செயல்படுத்தல், அதில் இரண்டு புத்தகங்கள் அவற்றின் ஐ.எஸ்.பி.என் பொருந்தினால் ஒரே வடிவமாகக் கருதப்படுகின்றன, வடிவங்கள் வேறுபட்டிருந்தாலும் கூட:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## இரண்டு வெவ்வேறு வகைகளை நான் எவ்வாறு ஒப்பிடுவது?
///
/// நீங்கள் ஒப்பிடக்கூடிய வகை `PartialEq` இன் வகை அளவுருவால் கட்டுப்படுத்தப்படுகிறது.
/// எடுத்துக்காட்டாக, எங்கள் முந்தைய குறியீட்டை சிறிது மாற்றலாம்:
///
/// ```
/// // பெறப்பட்ட கருவிகள்<BookFormat>==<BookFormat>ஒப்பீடுகள்
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // செயல்படுத்தவும்<Book>==<BookFormat>ஒப்பீடுகள்
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // செயல்படுத்தவும்<BookFormat>==<Book>ஒப்பீடுகள்
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` ஐ `impl PartialEq<BookFormat> for Book` ஆக மாற்றுவதன் மூலம், `BookFormat` களை` புத்தகங்களுடன் 'ஒப்பிட அனுமதிக்கிறோம்.
///
/// மேலே உள்ளதைப் போன்ற ஒரு ஒப்பீடு, இது கட்டமைப்பின் சில புலங்களை புறக்கணிக்கிறது, இது ஆபத்தானது.இது ஒரு பகுதி சமநிலை உறவுக்கான தேவைகளை எதிர்பாராத விதமாக மீறுவதற்கு வழிவகுக்கும்.
/// எடுத்துக்காட்டாக, `BookFormat` க்கான `PartialEq<Book>` இன் மேலே செயல்படுத்தலை நாங்கள் வைத்திருந்தால், `Book` க்கு `PartialEq<Book>` இன் செயல்பாட்டைச் சேர்த்தால் (ஒரு `#[derive]` வழியாக அல்லது முதல் எடுத்துக்காட்டில் இருந்து கையேடு செயல்படுத்தல் வழியாக), இதன் விளைவாக பரிமாற்றத்தை மீறும்:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// இந்த முறை `self` மற்றும் `other` மதிப்புகள் சமமாக இருக்க சோதிக்கிறது, மேலும் இது `==` ஆல் பயன்படுத்தப்படுகிறது.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// இந்த முறை `!=` ஐ சோதிக்கிறது.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` இன் ஒரு impl ஐ உருவாக்கும் மேக்ரோ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) என்ற சமத்துவ ஒப்பீடுகளுக்கான Trait.
///
/// இதன் பொருள், `a == b` மற்றும் `a != b` ஆகியவை கடுமையான தலைகீழாக இருப்பதைத் தவிர, சமத்துவம் இருக்க வேண்டும் (எல்லா `a`, `b` மற்றும் `c` க்கும்):
///
/// - reflexive: `a == a`;
/// - சமச்சீர்: `a == b` என்பது `b == a` ஐ குறிக்கிறது;மற்றும்
/// - இடைநிலை: `a == b` மற்றும் `b == c` என்பது `a == c` ஐ குறிக்கிறது.
///
/// இந்த சொத்தை தொகுப்பாளரால் சரிபார்க்க முடியாது, எனவே `Eq` என்பது [`PartialEq`] ஐ குறிக்கிறது, மேலும் கூடுதல் முறைகள் எதுவும் இல்லை.
///
/// ## Derivable
///
/// இந்த trait ஐ `#[derive]` உடன் பயன்படுத்தலாம்.
/// `பெறும்போது`, `Eq` க்கு கூடுதல் முறைகள் இல்லாததால், இது ஒரு பகுதி சமநிலை உறவைக் காட்டிலும் இது ஒரு சமநிலை உறவு என்பதை தொகுப்பாளருக்கு மட்டுமே தெரிவிக்கிறது.
///
/// `derive` மூலோபாயத்திற்கு எல்லா புலங்களும் `Eq` தேவை என்பதை நினைவில் கொள்க, இது எப்போதும் விரும்பப்படாது.
///
/// ## `Eq` ஐ எவ்வாறு செயல்படுத்தலாம்?
///
/// நீங்கள் `derive` மூலோபாயத்தைப் பயன்படுத்த முடியாவிட்டால், உங்கள் வகை `Eq` ஐ செயல்படுத்துகிறது என்பதைக் குறிப்பிடவும், அதில் எந்த முறைகளும் இல்லை:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // இந்த முறையானது ஒரு வகையின் ஒவ்வொரு கூறுகளும் தன்னை#[பெறுகிறது] என்று கூறுகிறது, தற்போதைய பெறப்பட்ட உள்கட்டமைப்பு என்பது இந்த trait இல் ஒரு முறையைப் பயன்படுத்தாமல் இந்த கூற்றைச் செய்வது கிட்டத்தட்ட சாத்தியமற்றது.
    //
    //
    // இதை ஒருபோதும் கையால் செயல்படுத்தக்கூடாது.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` இன் ஒரு impl ஐ உருவாக்கும் மேக்ரோ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: இந்த கட்டமைப்பு#[பெற] க்கு மட்டுமே பயன்படுத்தப்படுகிறது
// ஒரு வகையின் ஒவ்வொரு கூறுகளும் EQ ஐ செயல்படுத்துகின்றன என்று வலியுறுத்துங்கள்.
//
// இந்த கட்டமைப்பு ஒருபோதும் பயனர் குறியீட்டில் தோன்றக்கூடாது.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// ஒரு `Ordering` என்பது இரண்டு மதிப்புகளுக்கு இடையிலான ஒப்பீட்டின் விளைவாகும்.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// ஒப்பிடும் மதிப்பு மற்றொன்றை விட குறைவாக இருக்கும் ஒரு வரிசைப்படுத்தல்.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// ஒப்பிடும் மதிப்பு மற்றொன்றுக்கு சமமாக இருக்கும் ஒரு வரிசைப்படுத்தல்.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// ஒப்பிடும் மதிப்பு மற்றொன்றை விட அதிகமாக இருக்கும் ஒரு வரிசைப்படுத்தல்.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// வரிசைப்படுத்துதல் `Equal` மாறுபாடாக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// வரிசைப்படுத்துதல் `Equal` மாறுபாடு இல்லையென்றால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// வரிசைப்படுத்துதல் `Less` மாறுபாடாக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// வரிசைப்படுத்துதல் `Greater` மாறுபாடாக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// வரிசைப்படுத்துதல் `Less` அல்லது `Equal` மாறுபாடாக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// வரிசைப்படுத்துதல் `Greater` அல்லது `Equal` மாறுபாடாக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` ஐ மாற்றுகிறது.
    ///
    /// * `Less` `Greater` ஆகிறது.
    /// * `Greater` `Less` ஆகிறது.
    /// * `Equal` `Equal` ஆகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை நடத்தை:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// ஒப்பீட்டை மாற்றியமைக்க இந்த முறையைப் பயன்படுத்தலாம்:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // வரிசையை மிகப்பெரியது முதல் சிறியது வரை வரிசைப்படுத்துங்கள்.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// சங்கிலிகள் இரண்டு வரிசைகள்.
    ///
    /// `Equal` இல்லாதபோது `self` ஐ வழங்குகிறது.இல்லையெனில் `other` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// கொடுக்கப்பட்ட செயல்பாட்டுடன் வரிசைப்படுத்தும் சங்கிலிகள்.
    ///
    /// `Equal` இல்லாதபோது `self` ஐ வழங்குகிறது.
    /// இல்லையெனில் `f` ஐ அழைத்து முடிவை அளிக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// தலைகீழ் வரிசைப்படுத்துவதற்கான ஒரு உதவி அமைப்பு.
///
/// இந்த கட்டமைப்பு [`Vec::sort_by_key`] போன்ற செயல்பாடுகளுடன் பயன்படுத்தப்படக்கூடிய ஒரு உதவியாளராகும், மேலும் ஒரு விசையின் ஒரு பகுதியை மாற்றியமைக்க பயன்படுத்தலாம்.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// [total order](https://en.wikipedia.org/wiki/Total_order) ஐ உருவாக்கும் வகைகளுக்கான Trait.
///
/// ஒரு ஆர்டர் என்றால் மொத்த ஆர்டர் (எல்லா `a`, `b` மற்றும் `c` க்கும்):
///
/// - மொத்த மற்றும் சமச்சீரற்ற: சரியாக `a < b`, `a == b` அல்லது `a > b` இல் ஒன்று உண்மை;மற்றும்
/// - இடைநிலை, `a < b` மற்றும் `b < c` என்பது `a < c` ஐ குறிக்கிறது.இது `==` மற்றும் `>` இரண்டிற்கும் வைத்திருக்க வேண்டும்.
///
/// ## Derivable
///
/// இந்த trait ஐ `#[derive]` உடன் பயன்படுத்தலாம்.
/// கட்டமைப்புகளில் `பெறும்போது ', இது கட்டமைப்பின் உறுப்பினர்களின் மேல்-கீழ்-அறிவிப்பு வரிசையின் அடிப்படையில் ஒரு [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) வரிசையை உருவாக்கும்.
///
/// Enums இல் `பெறும்போது ', மாறுபாடுகள் அவற்றின் மேல்-கீழ்-பாகுபாடான வரிசையால் வரிசைப்படுத்தப்படுகின்றன.
///
/// ## லெக்சோகிராஃபிக்கல் ஒப்பீடு
///
/// லெக்சோகிராஃபிக்கல் ஒப்பீடு என்பது பின்வரும் பண்புகளைக் கொண்ட ஒரு செயல்பாடாகும்:
///  - இரண்டு வரிசைகள் உறுப்பு மூலம் உறுப்பு ஒப்பிடப்படுகின்றன.
///  - முதல் பொருந்தாத உறுப்பு எந்த வரிசையை லெக்சோகிராஃபிக்கலாக மற்றதை விட குறைவாகவோ அல்லது அதிகமாகவோ வரையறுக்கிறது.
///  - ஒரு வரிசை மற்றொன்றின் முன்னொட்டு என்றால், குறுகிய வரிசை மற்றொன்றை விட லெக்சோகிராஃபிக்கல் குறைவாக இருக்கும்.
///  - இரண்டு வரிசைகளுக்கு சமமான கூறுகள் இருந்தால், அவை ஒரே நீளமாக இருந்தால், அந்த வரிசைகள் அகராதி ரீதியாக சமமாக இருக்கும்.
///  - வெற்று வரிசை என்பது வெற்று அல்லாத எந்த வரிசையையும் விட லெக்சோகிராஃபிக்கல் குறைவாக உள்ளது.
///  - இரண்டு வெற்று காட்சிகள் சொற்பொழிவு ரீதியாக சமம்.
///
/// ## `Ord` ஐ எவ்வாறு செயல்படுத்தலாம்?
///
/// `Ord` வகை [`PartialOrd`] மற்றும் [`Eq`] ஆகவும் தேவைப்படுகிறது (இதற்கு [`PartialEq`] தேவைப்படுகிறது).
///
/// நீங்கள் [`cmp`] க்கான செயலாக்கத்தை வரையறுக்க வேண்டும்.உங்கள் வகை புலங்களில் [`cmp`] ஐப் பயன்படுத்துவது உங்களுக்கு பயனுள்ளதாக இருக்கும்.
///
/// [`PartialEq`], [`PartialOrd`] மற்றும் `Ord`*இன் செயல்பாடுகள்* ஒருவருக்கொருவர் உடன்பட வேண்டும்.
/// அதாவது, அனைத்து `a` மற்றும் `b` க்கும் `a == b` மற்றும் `Some(a.cmp(b)) == a.partial_cmp(b)` என்றால் மட்டுமே.
/// சில traits ஐப் பெறுவதன் மூலமும் மற்றவர்களை கைமுறையாக செயல்படுத்துவதன் மூலமும் தற்செயலாக அவர்களை உடன்பட வைப்பது எளிது.
///
/// `id` மற்றும் `name` ஐப் புறக்கணித்து, உயரத்தால் மட்டுமே மக்களை வரிசைப்படுத்த விரும்பும் ஒரு எடுத்துக்காட்டு இங்கே:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// இந்த முறை `self` மற்றும் `other` க்கு இடையில் ஒரு [`Ordering`] ஐ வழங்குகிறது.
    ///
    /// மாநாட்டின் படி, `self.cmp(&other)` உண்மையாக இருந்தால் `self <operator> other` வெளிப்பாட்டோடு பொருந்தக்கூடிய வரிசையை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// அதிகபட்சம் இரண்டு மதிப்புகளை ஒப்பிட்டு வழங்குகிறது.
    ///
    /// ஒப்பீடு அவற்றை சமமாக தீர்மானித்தால் இரண்டாவது வாதத்தை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// குறைந்தபட்சம் இரண்டு மதிப்புகளை ஒப்பிட்டுத் தருகிறது.
    ///
    /// ஒப்பீடு அவற்றை சமமாக தீர்மானித்தால் முதல் வாதத்தை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// ஒரு குறிப்பிட்ட இடைவெளியில் மதிப்பைக் கட்டுப்படுத்துங்கள்.
    ///
    /// `self` `max` ஐ விட அதிகமாக இருந்தால் `max` ஐயும், `self` `min` ஐ விட குறைவாக இருந்தால் `min` ஐ வழங்குகிறது.
    /// இல்லையெனில் இது `self` ஐ வழங்குகிறது.
    ///
    /// # Panics
    ///
    /// `min > max` என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` இன் ஒரு impl ஐ உருவாக்கும் மேக்ரோ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// ஒரு வரிசை-வரிசைக்கு ஒப்பிடக்கூடிய மதிப்புகளுக்கான Trait.
///
/// எல்லா `a`, `b` மற்றும் `c` க்கும் ஒப்பீடு பூர்த்தி செய்ய வேண்டும்:
///
/// - சமச்சீரற்ற தன்மை: `a < b` என்றால் `!(a > b)`, அதே போல் `a > b` `!(a < b)` ஐ குறிக்கிறது;மற்றும்
/// - பரிமாற்றம்: `a < b` மற்றும் `b < c` என்பது `a < c` ஐ குறிக்கிறது.இது `==` மற்றும் `>` இரண்டிற்கும் வைத்திருக்க வேண்டும்.
///
/// இந்த தேவைகள் trait ஐ சமச்சீராகவும், இடைவிடாது செயல்படுத்தப்பட வேண்டும் என்பதையும் நினைவில் கொள்க: `T: PartialOrd<U>` மற்றும் `U: PartialOrd<V>` என்றால் `U: PartialOrd<T>` மற்றும் `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// இந்த trait ஐ `#[derive]` உடன் பயன்படுத்தலாம்.கட்டமைப்புகளில் `பெறும்போது ', இது கட்டமைப்பின் உறுப்பினர்களின் மேல்-கீழ்-அறிவிப்பு வரிசையின் அடிப்படையில் ஒரு அகராதி வரிசையை உருவாக்கும்.
/// Enums இல் `பெறும்போது ', மாறுபாடுகள் அவற்றின் மேல்-கீழ்-பாகுபாடான வரிசையால் வரிசைப்படுத்தப்படுகின்றன.
///
/// ## `PartialOrd` ஐ எவ்வாறு செயல்படுத்தலாம்?
///
/// `PartialOrd` இயல்புநிலை செயலாக்கங்களிலிருந்து உருவாக்கப்படும் மற்றவற்றுடன், [`partial_cmp`] முறையை மட்டுமே செயல்படுத்த வேண்டும்.
///
/// இருப்பினும், மொத்த ஒழுங்கு இல்லாத வகைகளுக்கு மற்றவர்களை தனித்தனியாக செயல்படுத்த முடியும்.
/// எடுத்துக்காட்டாக, மிதக்கும் புள்ளி எண்களுக்கு, `NaN < 0 == false` மற்றும் `NaN >= 0 == false` (cf.
/// IEEE 754-2008 பிரிவு 5.11).
///
/// `PartialOrd` உங்கள் வகை [`PartialEq`] ஆக இருக்க வேண்டும்.
///
/// [`PartialEq`], `PartialOrd` மற்றும் [`Ord`]*இன் செயல்பாடுகள்* ஒருவருக்கொருவர் உடன்பட வேண்டும்.
/// சில traits ஐப் பெறுவதன் மூலமும் மற்றவர்களை கைமுறையாக செயல்படுத்துவதன் மூலமும் தற்செயலாக அவர்களை உடன்பட வைப்பது எளிது.
///
/// உங்கள் வகை [`Ord`] எனில், [`cmp`] ஐப் பயன்படுத்தி [`partial_cmp`] ஐ செயல்படுத்தலாம்:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// உங்கள் வகை புலங்களில் [`partial_cmp`] ஐப் பயன்படுத்துவது உங்களுக்கு பயனுள்ளதாக இருக்கும்.
/// மிதக்கும்-புள்ளி `height` புலத்தைக் கொண்ட `Person` வகைகளின் எடுத்துக்காட்டு இங்கே, வரிசைப்படுத்துவதற்குப் பயன்படுத்தப்படும் ஒரே புலம்:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// இந்த முறை `self` மற்றும் `other` மதிப்புகளுக்கு இடையில் ஒரு வரிசையை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// ஒப்பீடு சாத்தியமற்றது:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// இந்த முறை (`self` மற்றும் `other` க்கு) குறைவாக சோதிக்கிறது மற்றும் இது `<` ஆபரேட்டரால் பயன்படுத்தப்படுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// இந்த முறை (`self` மற்றும் `other` க்கு) குறைவாகவோ அல்லது சமமாகவோ சோதிக்கிறது மற்றும் இது `<=` ஆபரேட்டரால் பயன்படுத்தப்படுகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// இந்த முறை (`self` மற்றும் `other` க்கு) விட அதிகமாக சோதிக்கிறது மற்றும் இது `>` ஆபரேட்டரால் பயன்படுத்தப்படுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// இந்த முறை (`self` மற்றும் `other` க்கு) அதிகமாகவோ அல்லது சமமாகவோ சோதிக்கிறது மற்றும் இது `>=` ஆபரேட்டரால் பயன்படுத்தப்படுகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` இன் ஒரு impl ஐ உருவாக்கும் மேக்ரோ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// குறைந்தபட்சம் இரண்டு மதிப்புகளை ஒப்பிட்டுத் தருகிறது.
///
/// ஒப்பீடு அவற்றை சமமாக தீர்மானித்தால் முதல் வாதத்தை வழங்குகிறது.
///
/// [`Ord::min`] க்கு மாற்றுப்பெயரைப் பயன்படுத்துகிறது.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// குறிப்பிட்ட ஒப்பீட்டு செயல்பாட்டைப் பொறுத்தவரை குறைந்தபட்சம் இரண்டு மதிப்புகளை வழங்குகிறது.
///
/// ஒப்பீடு அவற்றை சமமாக தீர்மானித்தால் முதல் வாதத்தை வழங்குகிறது.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// குறிப்பிட்ட செயல்பாட்டிலிருந்து குறைந்தபட்ச மதிப்பைக் கொடுக்கும் உறுப்பை வழங்குகிறது.
///
/// ஒப்பீடு அவற்றை சமமாக தீர்மானித்தால் முதல் வாதத்தை வழங்குகிறது.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// அதிகபட்சம் இரண்டு மதிப்புகளை ஒப்பிட்டு வழங்குகிறது.
///
/// ஒப்பீடு அவற்றை சமமாக தீர்மானித்தால் இரண்டாவது வாதத்தை வழங்குகிறது.
///
/// [`Ord::max`] க்கு மாற்றுப்பெயரைப் பயன்படுத்துகிறது.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// குறிப்பிட்ட ஒப்பீட்டு செயல்பாட்டைப் பொறுத்து அதிகபட்சம் இரண்டு மதிப்புகளை வழங்குகிறது.
///
/// ஒப்பீடு அவற்றை சமமாக தீர்மானித்தால் இரண்டாவது வாதத்தை வழங்குகிறது.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// குறிப்பிட்ட செயல்பாட்டிலிருந்து அதிகபட்ச மதிப்பைக் கொடுக்கும் உறுப்பை வழங்குகிறது.
///
/// ஒப்பீடு அவற்றை சமமாக தீர்மானித்தால் இரண்டாவது வாதத்தை வழங்குகிறது.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// பழமையான வகைகளுக்கு PartialEq, Eq, PartialOrd மற்றும் Ord ஐ செயல்படுத்துதல்
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // மேலும் உகந்த சட்டசபையை உருவாக்க இங்கே வரிசை முக்கியமானது.
                    // மேலும் தகவலுக்கு <https://github.com/rust-lang/rust/issues/63758> ஐப் பார்க்கவும்.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // I8 க்கு அனுப்புவது மற்றும் வித்தியாசத்தை ஒரு ஆர்டரிங் என மாற்றுவது மிகவும் உகந்த சட்டசபையை உருவாக்குகிறது.
            //
            // மேலும் தகவலுக்கு <https://github.com/rust-lang/rust/issues/66780> ஐப் பார்க்கவும்.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // பாதுகாப்பு: i8 ஆக bool 0 அல்லது 1 ஐ வழங்குகிறது, எனவே வேறுபாடு வேறு எதுவும் இருக்க முடியாது
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &சுட்டிகள்

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}