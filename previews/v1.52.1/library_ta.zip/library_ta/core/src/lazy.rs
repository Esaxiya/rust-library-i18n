//! சோம்பேறி மதிப்புகள் மற்றும் நிலையான தரவின் ஒரு முறை துவக்கம்.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// ஒரு கலத்திற்கு ஒரு முறை மட்டுமே எழுத முடியும்.
///
/// `RefCell` போலல்லாமல், ஒரு `OnceCell` அதன் மதிப்புக்கு பகிரப்பட்ட `&T` குறிப்புகளை மட்டுமே வழங்குகிறது.
/// `Cell` போலல்லாமல், ஒரு `OnceCell` க்கு அதை அணுக மதிப்பை நகலெடுக்கவோ அல்லது மாற்றவோ தேவையில்லை.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // மாறாதது: ஒரே நேரத்தில் எழுதப்பட்டது.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// புதிய வெற்று கலத்தை உருவாக்குகிறது.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// அடிப்படை மதிப்பைக் குறிக்கும்.
    ///
    /// செல் காலியாக இருந்தால் `None` ஐ வழங்குகிறது.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // பாதுகாப்பு: `உள்` மாறுபாடு காரணமாக பாதுகாப்பானது
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// அடிப்படை மதிப்புக்கு மாற்றக்கூடிய குறிப்பைப் பெறுகிறது.
    ///
    /// செல் காலியாக இருந்தால் `None` ஐ வழங்குகிறது.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // பாதுகாப்பு: எங்களுக்கு தனிப்பட்ட அணுகல் இருப்பதால் பாதுகாப்பானது
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// கலத்தின் உள்ளடக்கங்களை `value` க்கு அமைக்கிறது.
    ///
    /// # Errors
    ///
    /// செல் காலியாக இருந்தால் இந்த முறை `Ok(())` மற்றும் அது நிரம்பியிருந்தால் `Err(value)` ஐ வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // பாதுகாப்பு: பாதுகாப்பானது, ஏனெனில் நாம் ஒன்றுக்கொன்று மாற்றக்கூடிய கடன்களை வைத்திருக்க முடியாது
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // பாதுகாப்பு: நாங்கள் ஸ்லாட்டை அமைக்கும் ஒரே இடம் இதுதான், இனங்கள் இல்லை
        // reentrancy/concurrency காரணமாக சாத்தியம் உள்ளது, மேலும் ஸ்லாட் தற்போது `None` என்பதை நாங்கள் சோதித்துள்ளோம், எனவே இந்த எழுத்து `உள்` மாற்றத்தை பராமரிக்கிறது.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// கலத்தின் உள்ளடக்கங்களைப் பெறுகிறது, செல் காலியாக இருந்தால் அதை `f` உடன் துவக்குகிறது.
    ///
    /// # Panics
    ///
    /// `f` panics எனில், panic அழைப்பாளருக்கு பிரச்சாரம் செய்யப்படுகிறது, மேலும் கலமானது ஆரம்பிக்கப்படாமல் உள்ளது.
    ///
    ///
    /// `f` இலிருந்து கலத்தை மீண்டும் தொடங்குவது பிழை.அவ்வாறு செய்வது panic இல் விளைகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// கலத்தின் உள்ளடக்கங்களைப் பெறுகிறது, செல் காலியாக இருந்தால் அதை `f` உடன் துவக்குகிறது.
    /// செல் காலியாக இருந்தால் மற்றும் `f` தோல்வியுற்றால், பிழை திரும்பும்.
    ///
    /// # Panics
    ///
    /// `f` panics எனில், panic அழைப்பாளருக்கு பிரச்சாரம் செய்யப்படுகிறது, மேலும் கலமானது ஆரம்பிக்கப்படாமல் உள்ளது.
    ///
    ///
    /// `f` இலிருந்து கலத்தை மீண்டும் தொடங்குவது பிழை.அவ்வாறு செய்வது panic இல் விளைகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // *சில* மறுபயன்பாட்டு துவக்கங்கள் UB க்கு வழிவகுக்கும் என்பதை நினைவில் கொள்க (`reentrant_init` சோதனையைப் பார்க்கவும்).
        // இந்த `assert` ஐ நீக்குவது, `set/get` ஐ வைத்திருப்பது ஒலியாக இருக்கும் என்று நான் நம்புகிறேன், ஆனால் பழைய மதிப்பை அமைதியாகப் பயன்படுத்துவதை விட panic க்கு இது நல்லது.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// கலத்தை நுகரும், மூடப்பட்ட மதிப்பைத் தருகிறது.
    ///
    /// செல் காலியாக இருந்தால் `None` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` ஆனது `self` ஐ மதிப்பால் எடுத்துக்கொள்வதால், அது தற்போது கடன் வாங்கப்படவில்லை என்பதை கம்பைலர் நிலையான முறையில் சரிபார்க்கிறது.
        // எனவே `Option<T>` ஐ வெளியேற்றுவது பாதுகாப்பானது.
        self.inner.into_inner()
    }

    /// இந்த `OnceCell` இலிருந்து மதிப்பை எடுத்து, அதை மீண்டும் ஆரம்பிக்கப்படாத நிலைக்கு நகர்த்துகிறது.
    ///
    /// எந்த விளைவும் இல்லை மற்றும் `OnceCell` துவக்கப்படவில்லை என்றால் `None` ஐ வழங்குகிறது.
    ///
    /// மாற்றக்கூடிய குறிப்பு தேவைப்படுவதன் மூலம் பாதுகாப்பு உறுதி செய்யப்படுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// முதல் அணுகலில் துவக்கப்பட்ட மதிப்பு.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   துவக்க தயாராக உள்ளது
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// கொடுக்கப்பட்ட துவக்க செயல்பாட்டுடன் புதிய சோம்பேறி மதிப்பை உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// இந்த சோம்பேறி மதிப்பின் மதிப்பீட்டை கட்டாயப்படுத்துகிறது மற்றும் முடிவுக்கு ஒரு குறிப்பை வழங்குகிறது.
    ///
    ///
    /// இது `Deref` impl க்கு சமம், ஆனால் வெளிப்படையானது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// துவக்க செயல்பாடாக `Default` ஐப் பயன்படுத்தி புதிய சோம்பேறி மதிப்பை உருவாக்குகிறது.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}