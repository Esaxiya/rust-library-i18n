//! பகிரக்கூடிய மாற்றக்கூடிய கொள்கலன்கள்.
//!
//! Rust நினைவக பாதுகாப்பு இந்த விதியை அடிப்படையாகக் கொண்டது: ஒரு பொருள் `T` கொடுக்கப்பட்டால், பின்வருவனவற்றில் ஒன்றை மட்டுமே கொண்டிருக்க முடியும்:
//!
//! - பொருளுக்கு பல மாறாத குறிப்புகள் (`&T`) (**மாற்றுப்பெயர்** என்றும் அழைக்கப்படுகிறது).
//! - பொருளுக்கு ஒரு மாற்றக்கூடிய குறிப்பு (`&மட் டி`) இருப்பது (**பிறழ்வு** என்றும் அழைக்கப்படுகிறது).
//!
//! இது Rust கம்பைலரால் செயல்படுத்தப்படுகிறது.இருப்பினும், இந்த விதி போதுமான நெகிழ்வு இல்லாத சூழ்நிலைகள் உள்ளன.சில நேரங்களில் ஒரு பொருளைப் பற்றி பல குறிப்புகள் இருக்க வேண்டும், ஆனால் அதை மாற்றியமைக்க வேண்டும்.
//!
//! மாற்றுப்பெயர்ச்சி முன்னிலையில் கூட, கட்டுப்படுத்தப்பட்ட முறையில் பிறழ்வை அனுமதிக்க பகிர்வு மாற்றக்கூடிய கொள்கலன்கள் உள்ளன.[`Cell<T>`] மற்றும் [`RefCell<T>`] இரண்டும் இதை ஒற்றை-திரிக்கப்பட்ட வழியில் செய்ய அனுமதிக்கின்றன.
//! இருப்பினும், `Cell<T>` அல்லது `RefCell<T>` ஆகியவை நூல் பாதுகாப்பானவை அல்ல (அவை [`Sync`] ஐ செயல்படுத்தாது).
//! பல நூல்களுக்கு இடையில் மாற்றுப்பெயர்ச்சி மற்றும் பிறழ்வை நீங்கள் செய்ய வேண்டியிருந்தால், [`Mutex<T>`], [`RwLock<T>`] அல்லது [`atomic`] வகைகளைப் பயன்படுத்த முடியும்.
//!
//! `Cell<T>` மற்றும் `RefCell<T>` வகைகளின் மதிப்புகள் பகிரப்பட்ட குறிப்புகள் மூலம் மாற்றப்படலாம் (அதாவது
//! பொதுவான `&T` வகை), பெரும்பாலான Rust வகைகளை தனித்துவமான (`&mut T`) குறிப்புகள் மூலம் மட்டுமே மாற்ற முடியும்.
//! `Cell<T>` மற்றும் `RefCell<T>` ஆகியவை 'உட்புற மாற்றத்தை' வழங்குகின்றன, வழக்கமான Rust வகைகளுக்கு மாறாக, 'மரபுரீதியான பிறழ்வை' வெளிப்படுத்துகின்றன.
//!
//! செல் வகைகள் இரண்டு சுவைகளில் வருகின்றன: `Cell<T>` மற்றும் `RefCell<T>`.`Cell<T>` `Cell<T>` க்கு வெளியேயும் வெளியேயும் மதிப்புகளை நகர்த்துவதன் மூலம் உள்துறை மாற்றத்தை செயல்படுத்துகிறது.
//! மதிப்புகளுக்கு பதிலாக குறிப்புகளைப் பயன்படுத்த, ஒருவர் `RefCell<T>` வகையைப் பயன்படுத்த வேண்டும், மாற்றுவதற்கு முன் எழுதும் பூட்டைப் பெற வேண்டும்.தற்போதைய உள்துறை மதிப்பை மீட்டெடுக்க மற்றும் மாற்றுவதற்கான வழிமுறைகளை `Cell<T>` வழங்குகிறது:
//!
//!  - [`Copy`] ஐ செயல்படுத்தும் வகைகளுக்கு, [`get`](Cell::get) முறை தற்போதைய உள்துறை மதிப்பை மீட்டெடுக்கிறது.
//!  - [`Default`] ஐ செயல்படுத்தும் வகைகளுக்கு, [`take`](Cell::take) முறை தற்போதைய உள்துறை மதிப்பை [`Default::default()`] உடன் மாற்றுகிறது மற்றும் மாற்றப்பட்ட மதிப்பை வழங்குகிறது.
//!  - எல்லா வகைகளுக்கும், [`replace`](Cell::replace) முறை தற்போதைய உள்துறை மதிப்பை மாற்றுகிறது மற்றும் மாற்றப்பட்ட மதிப்பை வழங்குகிறது மற்றும் [`into_inner`](Cell::into_inner) முறை `Cell<T>` ஐப் பயன்படுத்துகிறது மற்றும் உள்துறை மதிப்பை வழங்குகிறது.
//!  கூடுதலாக, [`set`](Cell::set) முறை உள்துறை மதிப்பை மாற்றுகிறது, மாற்றப்பட்ட மதிப்பைக் கைவிடுகிறது.
//!
//! `RefCell<T>` 'டைனமிக் கடன்' செயல்படுத்த Rust இன் வாழ்நாளைப் பயன்படுத்துகிறது, இதன் மூலம் உள் மதிப்புக்கு தற்காலிக, பிரத்தியேகமான, மாற்றக்கூடிய அணுகலை ஒருவர் கோர முடியும்.
//! `RefCell க்கான கடன்<T>Rust இன் சொந்த குறிப்பு வகைகளைப் போலல்லாமல், 'இயக்க நேரத்தில்' கண்காணிக்கப்படும், அவை தொகுக்கும் நேரத்தில் முற்றிலும் நிலையான முறையில் கண்காணிக்கப்படும்.
//! `RefCell<T>` கடன்கள் மாறும் என்பதால், ஏற்கனவே மாற்றத்தக்க வகையில் கடன் வாங்கிய மதிப்பை கடன் வாங்க முயற்சிக்க முடியும்;இது நிகழும்போது அது panic நூலில் விளைகிறது.
//!
//! # உள்துறை மாற்றத்தை எப்போது தேர்வு செய்ய வேண்டும்
//!
//! ஒரு மதிப்பை மாற்றுவதற்கான தனித்துவமான அணுகலை ஒருவர் கொண்டிருக்க வேண்டிய பொதுவான மரபுசார்ந்த பிறழ்வு, சுட்டிக்காட்டி மாற்றுப்பெயர்ச்சியைப் பற்றி வலுவாக நியாயப்படுத்த Rust ஐ இயக்கும் முக்கிய மொழி கூறுகளில் ஒன்றாகும், இது செயலிழப்பு பிழைகள் தடுக்கப்படுகிறது.
//! இதன் காரணமாக, மரபு ரீதியான பிறழ்வு தன்மை விரும்பப்படுகிறது, மேலும் உள்துறை பிறழ்வு என்பது ஒரு கடைசி முயற்சியாகும்.
//! செல் வகைகள் பிறழ்வை அனுமதிக்காததால், அது அனுமதிக்கப்படாது என்பதால், உள்துறை பிறழ்வு பொருத்தமானதாக இருக்கும் சந்தர்ப்பங்கள் உள்ளன, அல்லது *கூட* பயன்படுத்தப்பட வேண்டும், எ.கா.
//!
//! * மாறாத ஒன்றின் பிறழ்வு 'inside' ஐ அறிமுகப்படுத்துகிறது
//! * தர்க்கரீதியாக மாற்ற முடியாத முறைகளின் அமலாக்க விவரங்கள்.
//! * [`Clone`] இன் பிறழ்வு செயலாக்கங்கள்.
//!
//! ## மாறாத ஒன்றின் பிறழ்வு 'inside' ஐ அறிமுகப்படுத்துகிறது
//!
//! [`Rc<T>`] மற்றும் [`Arc<T>`] உட்பட பல பகிரப்பட்ட ஸ்மார்ட் சுட்டிக்காட்டி வகைகள், பல கட்சிகளுக்கு இடையில் குளோன் மற்றும் பகிரக்கூடிய கொள்கலன்களை வழங்குகின்றன.
//! அடங்கிய மதிப்புகள் பெருக்க-மாற்றுப்பெயராக இருக்கக்கூடும் என்பதால், அவை `&mut` அல்ல, `&` உடன் மட்டுமே கடன் வாங்க முடியும்.
//! செல்கள் இல்லாமல் இந்த ஸ்மார்ட் சுட்டிகள் உள்ளே தரவை மாற்ற முடியாது.
//!
//! பிறழ்வை மீண்டும் அறிமுகப்படுத்த பகிர்ந்த சுட்டிக்காட்டி வகைகளுக்குள் `RefCell<T>` ஐ வைப்பது மிகவும் பொதுவானது:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // டைனமிக் கடனின் நோக்கத்தைக் கட்டுப்படுத்த புதிய தொகுதியை உருவாக்கவும்
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // தற்காலிக சேமிப்பின் முந்தைய கடன் வரம்பிலிருந்து வெளியேற நாம் அனுமதிக்கவில்லை என்றால், அடுத்தடுத்த கடன் ஒரு மாறும் நூல் panic ஐ ஏற்படுத்தும் என்பதை நினைவில் கொள்க.
//!     //
//!     // இது `RefCell` ஐப் பயன்படுத்துவதற்கான பெரிய ஆபத்து.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! இந்த எடுத்துக்காட்டு `Rc<T>` ஐப் பயன்படுத்துகிறது மற்றும் `Arc<T>` அல்ல என்பதை நினைவில் கொள்க.`ரெஃப்செல்<T>`கள் ஒற்றை திரிக்கப்பட்ட காட்சிகளுக்கானவை.பல திரிக்கப்பட்ட சூழ்நிலையில் பகிரப்பட்ட பிறழ்வு தேவைப்பட்டால் [`RwLock<T>`] அல்லது [`Mutex<T>`] ஐப் பயன்படுத்துங்கள்.
//!
//! ## தர்க்கரீதியாக மாற்ற முடியாத முறைகளின் அமலாக்க விவரங்கள்
//!
//! எப்போதாவது "under the hood" இல் பிறழ்வு நடைபெறுகிறது என்பதை ஒரு API இல் வெளிப்படுத்தாமல் இருப்பது விரும்பத்தக்கதாக இருக்கலாம்.
//! இது தர்க்கரீதியாக செயல்பாடு மாறாதது என்பதால் இருக்கலாம், ஆனால் எ.கா., கேச்சிங் செயலாக்கத்தை பிறழ்வைச் செய்ய கட்டாயப்படுத்துகிறது;அல்லது `&self` ஐ எடுக்க முதலில் வரையறுக்கப்பட்ட trait முறையை செயல்படுத்த நீங்கள் பிறழ்வைப் பயன்படுத்த வேண்டும்.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // விலையுயர்ந்த கணக்கீடு இங்கே செல்கிறது
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` இன் பிறழ்வு செயலாக்கங்கள்
//!
//! இது வெறுமனே முந்தைய ஒரு சிறப்பு, ஆனால் பொதுவானது: மாறாததாகத் தோன்றும் செயல்பாடுகளுக்கான பிறழ்வை மறைத்தல்.
//! [`clone`](Clone::clone) முறை மூல மதிப்பை மாற்றாது என்று எதிர்பார்க்கப்படுகிறது, மேலும் இது `&mut self` அல்ல, `&self` ஐ எடுக்க அறிவிக்கப்பட்டுள்ளது.
//! எனவே, `clone` முறையில் நடக்கும் எந்த பிறழ்வும் செல் வகைகளைப் பயன்படுத்த வேண்டும்.
//! எடுத்துக்காட்டாக, [`Rc<T>`] அதன் குறிப்பு எண்ணிக்கையை `Cell<T>` க்குள் பராமரிக்கிறது.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// மாற்றக்கூடிய நினைவக இடம்.
///
/// # Examples
///
/// இந்த எடுத்துக்காட்டில், `Cell<T>` ஒரு மாறாத கட்டமைப்பிற்குள் பிறழ்வை செயல்படுத்துகிறது என்பதை நீங்கள் காணலாம்.
/// வேறு வார்த்தைகளில் கூறுவதானால், இது "interior mutability" ஐ இயக்குகிறது.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // பிழை: `my_struct` மாறாதது
/// // my_struct.regular_field =புதிய_ மதிப்பு;
///
/// // பணிகள்: `my_struct` மாறாதது என்றாலும், `special_field` ஒரு `Cell`,
/// // இது எப்போதும் மாற்றப்படலாம்
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// மேலும் அறிய [module-level documentation](self) ஐப் பார்க்கவும்.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// ஒரு `Cell<T>` ஐ உருவாக்குகிறது, T க்கான `Default` மதிப்புடன்.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// கொடுக்கப்பட்ட மதிப்பைக் கொண்ட புதிய `Cell` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// உள்ள மதிப்பை அமைக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// இரண்டு கலங்களின் மதிப்புகளை மாற்றுகிறது.
    /// `std::mem::swap` உடனான வேறுபாடு என்னவென்றால், இந்த செயல்பாட்டிற்கு `&mut` குறிப்பு தேவையில்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // பாதுகாப்பு: தனி நூல்களில் இருந்து அழைத்தால் இது ஆபத்தானது, ஆனால் `Cell`
        // `!Sync` எனவே இது நடக்காது.
        // `Cell` இந்த `செல்'களில் வேறு எதையும் சுட்டிக்காட்டாது என்பதை உறுதி செய்வதால் இது எந்த சுட்டிகளையும் செல்லாது.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// உள்ள மதிப்பை `val` உடன் மாற்றுகிறது, மேலும் பழைய மதிப்பை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // பாதுகாப்பு: இது ஒரு தனி நூலிலிருந்து அழைக்கப்பட்டால் தரவு பந்தயங்களை ஏற்படுத்தும்,
        // ஆனால் `Cell` என்பது `!Sync` எனவே இது நடக்காது.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// மதிப்பை அவிழ்த்து விடுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// உள்ள மதிப்பின் நகலை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // பாதுகாப்பு: இது ஒரு தனி நூலிலிருந்து அழைக்கப்பட்டால் தரவு பந்தயங்களை ஏற்படுத்தும்,
        // ஆனால் `Cell` என்பது `!Sync` எனவே இது நடக்காது.
        unsafe { *self.value.get() }
    }

    /// ஒரு செயல்பாட்டைப் பயன்படுத்தி அடங்கிய மதிப்பைப் புதுப்பித்து புதிய மதிப்பைத் தருகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// இந்த கலத்தின் அடிப்படை தரவுக்கு மூல சுட்டிக்காட்டி வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// அடிப்படை தரவுகளுக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// இந்த அழைப்பு `Cell` ஐ மாற்றத்தக்க வகையில் (தொகுக்கும் நேரத்தில்) கடன் பெறுகிறது, இது எங்களிடம் ஒரே குறிப்பைக் கொண்டுள்ளது என்பதை உறுதிப்படுத்துகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// ஒரு `&mut T` இலிருந்து ஒரு `&Cell<T>` ஐ வழங்குகிறது
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // பாதுகாப்பு: `&mut` தனிப்பட்ட அணுகலை உறுதி செய்கிறது.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// கலத்தின் மதிப்பை எடுத்து, `Default::default()` ஐ அதன் இடத்தில் விட்டுவிடுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// ஒரு `&Cell<[T]>` இலிருந்து ஒரு `&[Cell<T>]` ஐ வழங்குகிறது
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // பாதுகாப்பு: `Cell<T>` ஆனது `T` போன்ற நினைவக அமைப்பைக் கொண்டுள்ளது.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// மாறும் சரிபார்க்கப்பட்ட கடன் விதிகளுடன் மாற்றக்கூடிய நினைவக இடம்
///
/// மேலும் அறிய [module-level documentation](self) ஐப் பார்க்கவும்.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] ஆல் வழங்கப்பட்ட பிழை.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] ஆல் வழங்கப்பட்ட பிழை.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// நேர்மறை மதிப்புகள் `Ref` செயலில் உள்ள எண்ணிக்கையைக் குறிக்கும்.எதிர்மறை மதிப்புகள் `RefMut` செயலில் உள்ள எண்ணிக்கையைக் குறிக்கும்.
// ஒரு எக்ஸ் 100 எக்ஸ் (எ.கா., ஒரு துண்டின் வெவ்வேறு வரம்புகள்) இன் தனித்துவமான, மாற்றமடையாத கூறுகளைக் குறிப்பிட்டால் மட்டுமே பல `ரெஃப்மட்` கள் ஒரு நேரத்தில் செயலில் இருக்கும்.
//
// `Ref` மற்றும் `RefMut` இரண்டும் இரண்டு சொற்களாகும், எனவே `usize` வரம்பில் பாதி நிரம்பி வழிக போதுமான அளவு `Ref` கள் அல்லது`RefMut` கள் இருக்காது.
// எனவே, ஒரு `BorrowFlag` ஒருபோதும் நிரம்பி வழியாது அல்லது நிரம்பி வழியாது.
// இருப்பினும், இது ஒரு உத்தரவாதமல்ல, ஏனெனில் ஒரு நோயியல் நிரல் மீண்டும் மீண்டும் உருவாக்கி பின்னர் mem::forget `Ref` கள் அல்லது`RefMut` கள்.
// எனவே, பாதுகாப்பற்ற தன்மையைத் தவிர்ப்பதற்காக அனைத்து குறியீடுகளும் வழிதல் மற்றும் வழிதல் ஆகியவற்றை வெளிப்படையாகச் சரிபார்க்க வேண்டும், அல்லது நிரம்பி வழிகிறது அல்லது வழிதல் நடந்தால் குறைந்தபட்சம் சரியாக நடந்து கொள்ள வேண்டும் (எ.கா., BorrowRef::new ஐப் பார்க்கவும்).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` கொண்ட புதிய `RefCell` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` ஐப் பயன்படுத்துகிறது, மூடப்பட்ட மதிப்பைத் தருகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // இந்த செயல்பாடு `self` (`RefCell`) ஐ மதிப்பால் எடுத்துக்கொள்வதால், இது தற்போது கடன் வாங்கப்படவில்லை என்பதை கம்பைலர் நிலையான முறையில் சரிபார்க்கிறது.
        //
        self.value.into_inner()
    }

    /// மூடப்பட்ட மதிப்பை புதிய ஒன்றை மாற்றி, பழைய மதிப்பைத் திருப்பி, ஒன்றையும் வரையறுக்காமல்.
    ///
    ///
    /// இந்த செயல்பாடு [`std::mem::replace`](../mem/fn.replace.html) உடன் ஒத்துள்ளது.
    ///
    /// # Panics
    ///
    /// மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// மூடப்பட்ட மதிப்பை `f` இலிருந்து கணக்கிடப்பட்ட புதிய ஒன்றை மாற்றுகிறது, பழைய மதிப்பைத் தருகிறது, ஒன்றையும் வரையறுக்காமல்.
    ///
    ///
    /// # Panics
    ///
    /// மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self` இன் மூடப்பட்ட மதிப்பை `other` இன் மூடப்பட்ட மதிப்புடன் மாற்றுகிறது, ஒன்றையும் வரையறுக்காமல்.
    ///
    ///
    /// இந்த செயல்பாடு [`std::mem::swap`](../mem/fn.swap.html) உடன் ஒத்துள்ளது.
    ///
    /// # Panics
    ///
    /// `RefCell` இல் உள்ள மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// மூடப்பட்ட மதிப்பை மாற்றமுடியாமல் கடன் வாங்குகிறது.
    ///
    /// திரும்பிய `Ref` நோக்கத்திலிருந்து வெளியேறும் வரை கடன் நீடிக்கும்.
    /// பல மாறாத கடன்களை ஒரே நேரத்தில் எடுக்கலாம்.
    ///
    /// # Panics
    ///
    /// மதிப்பு தற்போது மாற்றாக கடன் வாங்கப்பட்டால் Panics.
    /// பயப்படாத மாறுபாட்டிற்கு, [`try_borrow`](#method.try_borrow) ஐப் பயன்படுத்தவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic இன் எடுத்துக்காட்டு:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// மூடப்பட்ட மதிப்பை மாற்றமுடியாமல் கடன் வாங்குகிறது, மதிப்பு தற்போது மாற்றாக கடன் வாங்கப்பட்டால் பிழையைத் தருகிறது.
    ///
    ///
    /// திரும்பிய `Ref` நோக்கத்திலிருந்து வெளியேறும் வரை கடன் நீடிக்கும்.
    /// பல மாறாத கடன்களை ஒரே நேரத்தில் எடுக்கலாம்.
    ///
    /// இது [`borrow`](#method.borrow) இன் பீதியற்ற மாறுபாடு.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // பாதுகாப்பு: மாறாத அணுகல் மட்டுமே இருப்பதை `BorrowRef` உறுதி செய்கிறது
            // கடன் வாங்கும்போது மதிப்பு.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// மூடப்பட்ட மதிப்பை மாற்றியமைக்கிறது.
    ///
    /// திரும்பப் பெறப்பட்ட `RefMut` அல்லது அதிலிருந்து பெறப்பட்ட அனைத்து `RefMut` களும் வெளியேறும் வரை கடன் நீடிக்கும்.
    ///
    /// இந்த கடன் செயலில் இருக்கும்போது மதிப்பை கடன் வாங்க முடியாது.
    ///
    /// # Panics
    ///
    /// மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    /// பயப்படாத மாறுபாட்டிற்கு, [`try_borrow_mut`](#method.try_borrow_mut) ஐப் பயன்படுத்தவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic இன் எடுத்துக்காட்டு:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// மூடப்பட்ட மதிப்பை மாற்றாக கடன் வாங்குகிறது, மதிப்பு தற்போது கடன் வாங்கப்பட்டால் பிழையைத் தருகிறது.
    ///
    ///
    /// திரும்பப் பெறப்பட்ட `RefMut` அல்லது அதிலிருந்து பெறப்பட்ட அனைத்து `RefMut` களும் வெளியேறும் வரை கடன் நீடிக்கும்.
    /// இந்த கடன் செயலில் இருக்கும்போது மதிப்பை கடன் வாங்க முடியாது.
    ///
    /// இது [`borrow_mut`](#method.borrow_mut) இன் பீதியற்ற மாறுபாடு.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // பாதுகாப்பு: `BorrowRef` தனிப்பட்ட அணுகலை உறுதி செய்கிறது.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// இந்த கலத்தின் அடிப்படை தரவுக்கு மூல சுட்டிக்காட்டி வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// அடிப்படை தரவுகளுக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// இந்த அழைப்பு `RefCell` ஐ மாற்றியமைக்கிறது (தொகுக்கும் நேரத்தில்) எனவே டைனமிக் காசோலைகள் தேவையில்லை.
    ///
    /// இருப்பினும் எச்சரிக்கையாக இருங்கள்: இந்த முறை `self` மாற்றக்கூடியதாக இருக்கும் என்று எதிர்பார்க்கிறது, இது பொதுவாக `RefCell` ஐப் பயன்படுத்தும் போது அப்படி இருக்காது.
    ///
    /// `self` மாற்ற முடியாதது என்றால் அதற்கு பதிலாக [`borrow_mut`] முறையைப் பாருங்கள்.
    ///
    /// மேலும், இந்த முறை சிறப்பு சூழ்நிலைகளுக்கு மட்டுமே என்பதை நினைவில் கொள்ளுங்கள், பொதுவாக நீங்கள் விரும்புவது இதுவல்ல.
    /// சந்தேகம் இருந்தால், அதற்கு பதிலாக [`borrow_mut`] ஐப் பயன்படுத்தவும்.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `RefCell` இன் கடன் நிலையில் கசிந்த காவலர்களின் விளைவைச் செயல்தவிர்க்கவும்.
    ///
    /// இந்த அழைப்பு [`get_mut`] ஐப் போன்றது, ஆனால் மிகவும் சிறப்பு வாய்ந்தது.
    /// எந்தவொரு கடனும் இல்லை என்பதை உறுதிப்படுத்த இது `RefCell` ஐ மாற்றாக கடன் வாங்குகிறது, பின்னர் பகிரப்பட்ட கடன்களை மாநில கண்காணிப்பு மீட்டமைக்கிறது.
    /// சில `Ref` அல்லது `RefMut` கடன்கள் கசிந்திருந்தால் இது பொருத்தமானது.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// மூடப்பட்ட மதிப்பை மாற்றமுடியாமல் கடன் வாங்குகிறது, மதிப்பு தற்போது மாற்றாக கடன் வாங்கப்பட்டால் பிழையைத் தருகிறது.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` ஐப் போலன்றி, இந்த முறை பாதுகாப்பற்றது, ஏனெனில் இது ஒரு `Ref` ஐ திருப்பித் தராது, இதனால் கடன் கொடியைத் தீண்டாமல் விடுகிறது.
    /// இந்த முறையால் வழங்கப்பட்ட குறிப்பு உயிருடன் இருக்கும்போது `RefCell` ஐ கடன் வாங்குவது வரையறுக்கப்படாத நடத்தை.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // பாதுகாப்பு: இப்போது யாரும் தீவிரமாக எழுதவில்லை என்பதை நாங்கள் சரிபார்க்கிறோம், ஆனால் அது
            // திரும்பிய குறிப்பு இனி பயன்பாட்டில் இல்லாத வரை யாரும் எழுதுவதில்லை என்பதை உறுதிசெய்வதற்கான அழைப்பாளரின் பொறுப்பு.
            // மேலும், `self.value.get()` என்பது `self` க்கு சொந்தமான மதிப்பைக் குறிக்கிறது, இதனால் `self` இன் வாழ்நாளில் செல்லுபடியாகும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// மூடப்பட்ட மதிப்பை எடுத்து, `Default::default()` ஐ அதன் இடத்தில் விட்டுவிடுகிறது.
    ///
    /// # Panics
    ///
    /// மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// மதிப்பு தற்போது மாற்றாக கடன் வாங்கப்பட்டால் Panics.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// ஒரு `RefCell<T>` ஐ உருவாக்குகிறது, T க்கான `Default` மதிப்புடன்.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` இல் உள்ள மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` இல் உள்ள மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// `RefCell` இல் உள்ள மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` இல் உள்ள மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` இல் உள்ள மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` இல் உள்ள மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` இல் உள்ள மதிப்பு தற்போது கடன் வாங்கப்பட்டால் Panics.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // கடனை அதிகரிப்பது இந்த சந்தர்ப்பங்களில் படிக்காத மதிப்பை (<=0) ஏற்படுத்தும்:
            // 1. இது <0, அதாவது எழுதும் கடன்கள் உள்ளன, எனவே Rust இன் குறிப்பு மாற்றுப்பெயர்ச்சி விதிகளின் காரணமாக ஒரு வாசிப்பு கடனை அனுமதிக்க முடியாது.
            // 2.
            // இது isize::MAX (வாசிப்பு கடன்களின் அதிகபட்ச அளவு) மற்றும் அது isize::MIN இல் நிரம்பி வழிகிறது (அதிகபட்சமாக எழுதும் கடன்களின் அளவு) எனவே கூடுதல் வாசிப்பு கடனை நாம் அனுமதிக்க முடியாது, ஏனெனில் ஐசைஸ் பல வாசிப்பு கடன்களை பிரதிநிதித்துவப்படுத்த முடியாது (இது நடந்தால் மட்டுமே நீங்கள் ஒரு சிறிய நிலையான அளவு `Ref` ஐ விட mem::forget அதிகம், இது நல்ல நடைமுறை அல்ல)
            //
            //
            //
            //
            None
        } else {
            // கடனை அதிகரிப்பது இந்த சந்தர்ப்பங்களில் வாசிப்பு மதிப்பை (> 0) ஏற்படுத்தும்:
            // 1. இது=0, அதாவது கடன் வாங்கப்படவில்லை, முதல் வாசிப்பு கடனை நாங்கள் எடுத்துக்கொள்கிறோம்
            // 2. இது> 0 மற்றும் <isize::MAX, அதாவது
            // வாசிப்பு கடன்கள் இருந்தன, மேலும் ஐசீஸ் இன்னும் ஒரு வாசிப்பு கடனைக் கொண்டிருப்பதைக் குறிக்கும் அளவுக்கு பெரியது
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // இந்த ரெஃப் இருப்பதால், கடன் கொடி ஒரு வாசிப்பு கடன் என்று எங்களுக்குத் தெரியும்.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // எழுதும் கடனில் கடன் கவுண்டர் நிரம்பி வழிவதைத் தடுக்கவும்.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// கடன் வாங்கிய குறிப்பை ஒரு `RefCell` பெட்டியில் ஒரு மதிப்புக்கு மடக்குகிறது.
/// ஒரு `RefCell<T>` இலிருந்து கடன் வாங்கிய மதிப்புக்கு ஒரு ரேப்பர் வகை.
///
/// மேலும் அறிய [module-level documentation](self) ஐப் பார்க்கவும்.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// ஒரு `Ref` ஐ நகலெடுக்கிறது.
    ///
    /// `RefCell` ஏற்கனவே மாறாமல் கடன் வாங்கப்பட்டுள்ளது, எனவே இது தோல்வியடைய முடியாது.
    ///
    /// இது ஒரு தொடர்புடைய செயல்பாடு, இது `Ref::clone(...)` ஆக பயன்படுத்தப்பட வேண்டும்.
    /// ஒரு `Clone` செயல்படுத்தல் அல்லது ஒரு முறை `RefCell` இன் உள்ளடக்கங்களை குளோன் செய்ய `r.borrow().clone()` இன் பரவலான பயன்பாட்டில் தலையிடும்.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// கடன் வாங்கிய தரவின் ஒரு கூறுக்கு புதிய `Ref` ஐ உருவாக்குகிறது.
    ///
    /// `RefCell` ஏற்கனவே மாறாமல் கடன் வாங்கப்பட்டுள்ளது, எனவே இது தோல்வியடைய முடியாது.
    ///
    /// இது ஒரு தொடர்புடைய செயல்பாடு, இது `Ref::map(...)` ஆக பயன்படுத்தப்பட வேண்டும்.
    /// ஒரு முறை `Deref` மூலம் பயன்படுத்தப்படும் `RefCell` இன் உள்ளடக்கங்களில் அதே பெயரின் முறைகளில் தலையிடும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// கடன் வாங்கிய தரவின் விருப்ப கூறுக்கு புதிய `Ref` ஐ உருவாக்குகிறது.
    /// மூடல் `None` ஐ வழங்கினால் அசல் காவலர் `Err(..)` ஆக திருப்பி அனுப்பப்படுவார்.
    ///
    /// `RefCell` ஏற்கனவே மாறாமல் கடன் வாங்கப்பட்டுள்ளது, எனவே இது தோல்வியடைய முடியாது.
    ///
    /// இது ஒரு தொடர்புடைய செயல்பாடு, இது `Ref::filter_map(...)` ஆக பயன்படுத்தப்பட வேண்டும்.
    /// ஒரு முறை `Deref` மூலம் பயன்படுத்தப்படும் `RefCell` இன் உள்ளடக்கங்களில் அதே பெயரின் முறைகளில் தலையிடும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// கடன் வாங்கிய தரவின் வெவ்வேறு கூறுகளுக்கு ஒரு `Ref` ஐ பல `Ref` களாகப் பிரிக்கிறது.
    ///
    /// `RefCell` ஏற்கனவே மாறாமல் கடன் வாங்கப்பட்டுள்ளது, எனவே இது தோல்வியடைய முடியாது.
    ///
    /// இது ஒரு தொடர்புடைய செயல்பாடு, இது `Ref::map_split(...)` ஆக பயன்படுத்தப்பட வேண்டும்.
    /// ஒரு முறை `Deref` மூலம் பயன்படுத்தப்படும் `RefCell` இன் உள்ளடக்கங்களில் அதே பெயரின் முறைகளில் தலையிடும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// அடிப்படை தரவுக்கான குறிப்பாக மாற்றவும்.
    ///
    /// அடிப்படை `RefCell` ஐ மீண்டும் ஒருபோதும் மாற்றமுடியாமல் கடன் வாங்க முடியாது, எப்போதும் மாறாமல் கடன் வாங்கியதாக எப்போதும் தோன்றும்.
    ///
    /// நிலையான எண்ணிக்கையிலான குறிப்புகளை விட அதிகமாக கசிவது நல்ல யோசனையல்ல.
    /// மொத்தத்தில் குறைந்த எண்ணிக்கையிலான கசிவுகள் ஏற்பட்டிருந்தால், `RefCell` ஐ மீண்டும் மாற்றமுடியாமல் கடன் வாங்க முடியும்.
    ///
    /// இது ஒரு தொடர்புடைய செயல்பாடு, இது `Ref::leak(...)` ஆக பயன்படுத்தப்பட வேண்டும்.
    /// ஒரு முறை `Deref` மூலம் பயன்படுத்தப்படும் `RefCell` இன் உள்ளடக்கங்களில் அதே பெயரின் முறைகளில் தலையிடும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // இந்த ரெஃப்பை மறப்பதன் மூலம், ரெஃப்செல்லில் கடன் கவுண்டர் வாழ்நாள் `'b` க்குள் UNUSED க்கு செல்ல முடியாது என்பதை உறுதிசெய்கிறோம்.
        // குறிப்பு கண்காணிப்பு நிலையை மீட்டமைக்க கடன் வாங்கிய ரெஃப்செல்லுக்கு தனிப்பட்ட குறிப்பு தேவைப்படும்.
        // அசல் கலத்திலிருந்து மேலும் மாற்றக்கூடிய குறிப்புகளை உருவாக்க முடியாது.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// கடன் வாங்கிய தரவின் ஒரு கூறுக்கு புதிய `RefMut` ஐ உருவாக்குகிறது, எ.கா., ஒரு enum மாறுபாடு.
    ///
    /// `RefCell` ஏற்கனவே மாற்றத்தக்க வகையில் கடன் வாங்கப்பட்டுள்ளது, எனவே இது தோல்வியடைய முடியாது.
    ///
    /// இது ஒரு தொடர்புடைய செயல்பாடு, இது `RefMut::map(...)` ஆக பயன்படுத்தப்பட வேண்டும்.
    /// ஒரு முறை `Deref` மூலம் பயன்படுத்தப்படும் `RefCell` இன் உள்ளடக்கங்களில் அதே பெயரின் முறைகளில் தலையிடும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): கடன்-காசோலையை சரிசெய்யவும்
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// கடன் வாங்கிய தரவின் விருப்ப கூறுக்கு புதிய `RefMut` ஐ உருவாக்குகிறது.
    /// மூடல் `None` ஐ வழங்கினால் அசல் காவலர் `Err(..)` ஆக திருப்பி அனுப்பப்படுவார்.
    ///
    /// `RefCell` ஏற்கனவே மாற்றத்தக்க வகையில் கடன் வாங்கப்பட்டுள்ளது, எனவே இது தோல்வியடைய முடியாது.
    ///
    /// இது ஒரு தொடர்புடைய செயல்பாடு, இது `RefMut::filter_map(...)` ஆக பயன்படுத்தப்பட வேண்டும்.
    /// ஒரு முறை `Deref` மூலம் பயன்படுத்தப்படும் `RefCell` இன் உள்ளடக்கங்களில் அதே பெயரின் முறைகளில் தலையிடும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): கடன்-காசோலையை சரிசெய்யவும்
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // பாதுகாப்பு: செயல்பாடு காலத்திற்கான பிரத்யேக குறிப்பைக் கொண்டுள்ளது
        // `orig` வழியாக அதன் அழைப்பின், மற்றும் சுட்டிக்காட்டி செயல்பாட்டு அழைப்பின் உள்ளே மட்டுமே குறிப்பிடப்படுகிறது, பிரத்தியேக குறிப்பை தப்பிக்க ஒருபோதும் அனுமதிக்காது.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // பாதுகாப்பு: மேலே உள்ளதைப் போன்றது.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// கடன் வாங்கிய தரவின் வெவ்வேறு கூறுகளுக்கு ஒரு `RefMut` ஐ பல `RefMut` களாகப் பிரிக்கிறது.
    ///
    /// திரும்பிய `ரெஃப்மட்'கள் வரம்பிலிருந்து வெளியேறும் வரை அடிப்படை `RefCell` கடனாக கடன் வாங்கப்படும்.
    ///
    /// `RefCell` ஏற்கனவே மாற்றத்தக்க வகையில் கடன் வாங்கப்பட்டுள்ளது, எனவே இது தோல்வியடைய முடியாது.
    ///
    /// இது ஒரு தொடர்புடைய செயல்பாடு, இது `RefMut::map_split(...)` ஆக பயன்படுத்தப்பட வேண்டும்.
    /// ஒரு முறை `Deref` மூலம் பயன்படுத்தப்படும் `RefCell` இன் உள்ளடக்கங்களில் அதே பெயரின் முறைகளில் தலையிடும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// அடிப்படை தரவுகளுக்கு மாற்றக்கூடிய குறிப்பாக மாற்றவும்.
    ///
    /// அடிப்படை `RefCell` ஐ மீண்டும் கடன் வாங்க முடியாது, எப்போதும் ஏற்கெனவே மாற்றியமைக்கப்பட்ட கடனாகத் தோன்றும், திரும்பி வந்த குறிப்பை உள்துறைக்கு மட்டுமே செய்யும்.
    ///
    ///
    /// இது ஒரு தொடர்புடைய செயல்பாடு, இது `RefMut::leak(...)` ஆக பயன்படுத்தப்பட வேண்டும்.
    /// ஒரு முறை `Deref` மூலம் பயன்படுத்தப்படும் `RefCell` இன் உள்ளடக்கங்களில் அதே பெயரின் முறைகளில் தலையிடும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // இந்த BorrowRefMut ஐ மறப்பதன் மூலம், RefCell இல் உள்ள கடன் கவுண்டர் `'b` வாழ்நாளில் UNUSED க்கு செல்ல முடியாது என்பதை உறுதிசெய்கிறோம்.
        // குறிப்பு கண்காணிப்பு நிலையை மீட்டமைக்க கடன் வாங்கிய ரெஃப்செல்லுக்கு தனிப்பட்ட குறிப்பு தேவைப்படும்.
        // அந்த வாழ்நாளில் அசல் கலத்திலிருந்து மேலதிக குறிப்புகள் எதுவும் உருவாக்கப்படாது, தற்போதைய கடன் மீதமுள்ள வாழ்நாளில் ஒரே குறிப்பை உருவாக்குகிறது.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone போலல்லாமல், தொடக்கத்தை உருவாக்க புதியது அழைக்கப்படுகிறது
        // மாற்றக்கூடிய குறிப்பு, எனவே தற்போது இருக்கும் குறிப்புகள் எதுவும் இருக்கக்கூடாது.
        // ஆகவே, குளோன் மாற்றக்கூடிய மறு கணக்கீட்டை அதிகரிக்கும் போது, இங்கே நாம் வெளிப்படையாக UNUSED இலிருந்து UNUSED க்கு செல்ல அனுமதிக்கிறோம், 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // ஒரு `BorrowRefMut` ஐ குளோன் செய்கிறது.
    //
    // அசல் பொருளின் தனித்துவமான, மாற்றமடையாத வரம்பிற்கு மாற்றக்கூடிய குறிப்பைக் கண்காணிக்க ஒவ்வொரு `BorrowRefMut` பயன்படுத்தப்பட்டால் மட்டுமே இது செல்லுபடியாகும்.
    //
    // இது ஒரு குளோன் இம்பில் இல்லை, எனவே குறியீடு இதை மறைமுகமாக அழைக்காது.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // கடன் கவுண்டரை நிரம்பி வழியாமல் தடுக்கவும்.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// ஒரு `RefCell<T>` இலிருந்து கடன் வாங்கிய மதிப்புக்கு ஒரு ரேப்பர் வகை.
///
/// மேலும் அறிய [module-level documentation](self) ஐப் பார்க்கவும்.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust இல் உள்துறை மாற்றத்திற்கான முக்கிய பழமையானது.
///
/// உங்களிடம் குறிப்பு `&T` இருந்தால், பொதுவாக Rust இல் கம்பைலர் `&T` மாறாத தரவை சுட்டிக்காட்டும் அறிவின் அடிப்படையில் தேர்வுமுறைகளை செய்கிறது.அந்த தரவை மாற்றுவது, எடுத்துக்காட்டாக ஒரு மாற்றுப்பெயர் வழியாக அல்லது ஒரு `&T` ஐ `&mut T` ஆக மாற்றுவதன் மூலம், வரையறுக்கப்படாத நடத்தை என்று கருதப்படுகிறது.
/// `UnsafeCell<T>` `&T` க்கான மாறாத உத்தரவாதத்தைத் தேர்வுசெய்கிறது: பகிரப்பட்ட குறிப்பு `&UnsafeCell<T>` மாற்றப்பட்ட தரவை சுட்டிக்காட்டக்கூடும்.இது "interior mutability" என அழைக்கப்படுகிறது.
///
/// `Cell<T>` மற்றும் `RefCell<T>` போன்ற உள் மாற்றத்தை அனுமதிக்கும் மற்ற அனைத்து வகைகளும், அவற்றின் தரவை மடிக்க `UnsafeCell` ஐ உள்நாட்டில் பயன்படுத்துகின்றன.
///
/// பகிரப்பட்ட குறிப்புகளுக்கான மாறாத உத்தரவாதம் மட்டுமே `UnsafeCell` ஆல் பாதிக்கப்படுகிறது என்பதை நினைவில் கொள்க.மாற்றக்கூடிய குறிப்புகளுக்கான தனித்துவ உத்தரவாதம் பாதிக்கப்படாது.`UnsafeCell<T>` உடன் மாற்றுப்பெயரைப் பெற *இல்லை* சட்ட வழி இல்லை, `UnsafeCell<T>` உடன் கூட இல்லை.
///
/// `UnsafeCell` API தானாக தொழில்நுட்ப ரீதியாக மிகவும் எளிதானது: [`.get()`] அதன் உள்ளடக்கங்களுக்கு ஒரு மூல சுட்டிக்காட்டி `*mut T` ஐ உங்களுக்கு வழங்குகிறது.அந்த மூல சுட்டிக்காட்டி சரியாகப் பயன்படுத்துவது சுருக்க வடிவமைப்பாளராக _you_ வரை உள்ளது.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// துல்லியமான Rust மாற்றுப்பெயர்ச்சி விதிகள் ஓரளவு பாய்ச்சலில் உள்ளன, ஆனால் முக்கிய புள்ளிகள் சர்ச்சைக்குரியவை அல்ல:
///
/// - பாதுகாப்பான குறியீட்டால் அணுகக்கூடிய (எடுத்துக்காட்டாக, நீங்கள் அதை திருப்பி அனுப்பியதால்) வாழ்நாள் `'a` (ஒரு `&T` அல்லது `&mut T` குறிப்பு) உடன் பாதுகாப்பான குறிப்பை உருவாக்கினால், மீதமுள்ள குறிப்புக்கு முரணான எந்த வகையிலும் நீங்கள் தரவை அணுகக்கூடாது. `'a` இன்.
/// எடுத்துக்காட்டாக, நீங்கள் ஒரு `UnsafeCell<T>` இலிருந்து `*mut T` ஐ எடுத்து ஒரு `&T` க்கு அனுப்பினால், `T` இல் உள்ள தரவு மாறாமல் இருக்க வேண்டும் (`T` க்குள் காணப்படும் எந்த `UnsafeCell` தரவையும் மட்டுப்படுத்தவும்), அந்த குறிப்பின் வாழ்நாள் காலாவதியாகும் வரை.
/// இதேபோல், நீங்கள் பாதுகாப்பான குறியீட்டிற்கு வெளியிடப்பட்ட ஒரு `&mut T` குறிப்பை உருவாக்கினால், அந்த குறிப்பு காலாவதியாகும் வரை நீங்கள் `UnsafeCell` க்குள் தரவை அணுகக்கூடாது.
///
/// - எல்லா நேரங்களிலும், நீங்கள் தரவு பந்தயங்களைத் தவிர்க்க வேண்டும்.பல XreadX க்கு ஒரே `UnsafeCell` க்கு அணுகல் இருந்தால், எந்தவொரு எழுத்தாளருக்கும் முறையான நிகழ்வுகள் இருக்க வேண்டும்-மற்ற எல்லா அணுகல்களுடனும் (அல்லது அணுக்களைப் பயன்படுத்துங்கள்).
///
/// சரியான வடிவமைப்பிற்கு உதவ, பின்வரும் காட்சிகள் ஒற்றை-திரிக்கப்பட்ட குறியீட்டிற்கு வெளிப்படையாக சட்டப்பூர்வமாக அறிவிக்கப்படுகின்றன:
///
/// 1. ஒரு `&T` குறிப்பு பாதுகாப்பான குறியீட்டிற்கு வெளியிடப்படலாம், மேலும் அது மற்ற `&T` குறிப்புகளுடன் இணைந்திருக்கலாம், ஆனால் `&mut T` உடன் அல்ல
///
/// 2. ஒரு `&mut T` குறிப்பு பாதுகாப்பான குறியீட்டிற்கு வெளியிடப்படலாம், இது வேறு `&mut T` அல்லது `&T` உடன் இணைந்திருக்கவில்லை.ஒரு `&mut T` எப்போதும் தனித்துவமாக இருக்க வேண்டும்.
///
/// ஒரு `&UnsafeCell<T>` இன் உள்ளடக்கங்களை மாற்றியமைக்கும் போது (பிற `&UnsafeCell<T>` குறிப்புகள் மாற்று கலமாக இருந்தாலும்) சரி (மேலே உள்ள மாற்றங்களை வேறு வழியில் செயல்படுத்தினால்), பல `&mut UnsafeCell<T>` மாற்றுப்பெயர்களைக் கொண்டிருப்பது இன்னும் வரையறுக்கப்படாத நடத்தை.
/// அதாவது, `UnsafeCell` என்பது _shared_ accesses (_i.e._ உடன் ஒரு சிறப்பு தொடர்பு கொள்ள வடிவமைக்கப்பட்ட ஒரு ரேப்பர், ஒரு `&UnsafeCell<_>` குறிப்பு மூலம்);_exclusive_ accesses (_e.g._ உடன், `&mut UnsafeCell<_>` மூலம் கையாளும் போது எந்த மந்திரமும் இல்லை): அந்த `&mut` கடனுக்கான காலத்திற்கு கலமோ அல்லது மூடப்பட்ட மதிப்போ மாற்றுப்பெயரிடக்கூடாது.
///
/// இது [`.get_mut()`] அணுகலால் காட்சிப்படுத்தப்படுகிறது, இது _safe_ getter ஆகும், இது `&mut T` ஐ வழங்குகிறது.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// கலத்தை மாற்றியமைக்கும் பல குறிப்புகள் இருந்தபோதிலும், `UnsafeCell<_>` இன் உள்ளடக்கங்களை எவ்வாறு மாற்றியமைப்பது என்பதைக் காட்டும் ஒரு எடுத்துக்காட்டு இங்கே:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // ஒரே `x` க்கு பல/ஒரே நேரத்தில்/பகிரப்பட்ட குறிப்புகளைப் பெறுங்கள்.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // பாதுகாப்பு: இந்த எல்லைக்குள் `x` இன் உள்ளடக்கங்களுக்கு வேறு குறிப்புகள் எதுவும் இல்லை,
///     // எனவே நம்முடையது திறம்பட தனித்துவமானது.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- கடன்-+
///     *p1_exclusive += 27; // |
/// } // <---------- இந்த கட்டத்திற்கு அப்பால் செல்ல முடியாது -------------------+
///
/// unsafe {
///     // பாதுகாப்பு: இந்த எல்லைக்குள் `x` இன் உள்ளடக்கங்களுக்கு பிரத்யேக அணுகலை யாரும் எதிர்பார்க்கவில்லை,
///     // எனவே ஒரே நேரத்தில் பல பகிரப்பட்ட அணுகல்களைக் கொண்டிருக்கலாம்.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// `UnsafeCell<T>` க்கான பிரத்யேக அணுகல் அதன் `T` க்கான பிரத்யேக அணுகலைக் குறிக்கிறது என்ற உண்மையை பின்வரும் எடுத்துக்காட்டு காட்டுகிறது:
///
/// ```rust
/// #![forbid(unsafe_code)] // பிரத்யேக அணுகல்களுடன்,
///                         // `UnsafeCell` ஒரு வெளிப்படையான நோ-ஒப் ரேப்பர், எனவே இங்கே `unsafe` தேவையில்லை.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` க்கு தொகுக்கப்பட்ட நேர-சரிபார்க்கப்பட்ட தனிப்பட்ட குறிப்பைப் பெறுங்கள்.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // பிரத்தியேக குறிப்புடன், உள்ளடக்கங்களை இலவசமாக மாற்றலாம்.
/// *p_unique.get_mut() = 0;
/// // அல்லது, சமமாக:
/// x = UnsafeCell::new(0);
///
/// // மதிப்பை நாங்கள் வைத்திருக்கும்போது, உள்ளடக்கங்களை இலவசமாகப் பிரித்தெடுக்கலாம்.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// `UnsafeCell` இன் புதிய நிகழ்வை உருவாக்குகிறது, இது குறிப்பிட்ட மதிப்பை மடிக்கும்.
    ///
    ///
    /// முறைகள் மூலம் உள் மதிப்பிற்கான அனைத்து அணுகலும் `unsafe` ஆகும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// மதிப்பை அவிழ்த்து விடுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// மூடப்பட்ட மதிப்புக்கு மாற்றக்கூடிய சுட்டிக்காட்டி பெறுகிறது.
    ///
    /// இதை எந்த வகையிலும் சுட்டிக்காட்டலாம்.
    /// `&mut T` க்கு அனுப்பும்போது அணுகல் தனித்துவமானது (செயலில் குறிப்புகள் இல்லை, மாற்றக்கூடியது அல்லது இல்லை) என்பதை உறுதிசெய்து, `&T` க்கு அனுப்பும்போது பிறழ்வுகள் அல்லது மாற்றக்கூடிய மாற்றுப்பெயர்கள் எதுவும் இல்லை என்பதை உறுதிப்படுத்தவும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] இன் காரணமாக நாம் சுட்டிக்காட்டி `UnsafeCell<T>` இலிருந்து `T` க்கு அனுப்பலாம்.
        // இது libstd இன் சிறப்பு நிலையைப் பயன்படுத்துகிறது, இது கம்பைலரின் future பதிப்புகளில் செயல்படும் என்பதற்கு பயனர் குறியீட்டிற்கு எந்த உத்தரவாதமும் இல்லை!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// அடிப்படை தரவுகளுக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// இந்த அழைப்பு `UnsafeCell` ஐ மாற்றத்தக்க வகையில் (தொகுக்கும் நேரத்தில்) கடன் பெறுகிறது, இது எங்களிடம் ஒரே குறிப்பைக் கொண்டுள்ளது என்பதை உறுதிப்படுத்துகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// மூடப்பட்ட மதிப்புக்கு மாற்றக்கூடிய சுட்டிக்காட்டி பெறுகிறது.
    /// [`get`] க்கு உள்ள வேறுபாடு என்னவென்றால், இந்த செயல்பாடு ஒரு மூல சுட்டிக்காட்டி ஏற்றுக்கொள்கிறது, இது தற்காலிக குறிப்புகளை உருவாக்குவதைத் தவிர்க்க பயனுள்ளதாக இருக்கும்.
    ///
    /// இதன் விளைவாக எந்த வகையிலும் சுட்டிக்காட்ட முடியும்.
    /// `&mut T` க்கு அனுப்பும்போது அணுகல் தனித்துவமானது (செயலில் குறிப்புகள் இல்லை, மாற்றக்கூடியது அல்லது இல்லை) என்பதை உறுதிசெய்து, `&T` க்கு அனுப்பும்போது பிறழ்வுகள் அல்லது மாற்றக்கூடிய மாற்றுப்பெயர்கள் எதுவும் இல்லை என்பதை உறுதிப்படுத்தவும்.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` இன் படிப்படியான துவக்கத்திற்கு `raw_get` தேவைப்படுகிறது, ஏனெனில் `get` ஐ அழைப்பது ஆரம்பிக்கப்படாத தரவிற்கான குறிப்பை உருவாக்க வேண்டும்:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] இன் காரணமாக நாம் சுட்டிக்காட்டி `UnsafeCell<T>` இலிருந்து `T` க்கு அனுப்பலாம்.
        // இது libstd இன் சிறப்பு நிலையைப் பயன்படுத்துகிறது, இது கம்பைலரின் future பதிப்புகளில் செயல்படும் என்பதற்கு பயனர் குறியீட்டிற்கு எந்த உத்தரவாதமும் இல்லை!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T க்கான `Default` மதிப்புடன், ஒரு `UnsafeCell` ஐ உருவாக்குகிறது.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}