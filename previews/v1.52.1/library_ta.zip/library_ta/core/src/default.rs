//! அர்த்தமுள்ள இயல்புநிலை மதிப்புகளைக் கொண்டிருக்கும் வகைகளுக்கான `Default` trait.

#![stable(feature = "rust1", since = "1.0.0")]

/// ஒரு வகைக்கு பயனுள்ள இயல்புநிலை மதிப்பைக் கொடுப்பதற்கான trait.
///
/// சில நேரங்களில், நீங்கள் ஒருவித இயல்புநிலை மதிப்புக்குத் திரும்ப விரும்புகிறீர்கள், குறிப்பாக அது என்னவென்று கவலைப்பட வேண்டாம்.
/// இது பெரும்பாலும் விருப்பங்களின் தொகுப்பை வரையறுக்கும் `struct` களுடன் வருகிறது:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// சில இயல்புநிலை மதிப்புகளை எவ்வாறு வரையறுக்கலாம்?நீங்கள் `Default` ஐப் பயன்படுத்தலாம்:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// இப்போது, நீங்கள் இயல்புநிலை மதிப்புகள் அனைத்தையும் பெறுவீர்கள்.Rust பல்வேறு பழமையான வகைகளுக்கு `Default` ஐ செயல்படுத்துகிறது.
///
/// நீங்கள் ஒரு குறிப்பிட்ட விருப்பத்தை மேலெழுத விரும்பினால், ஆனால் மற்ற இயல்புநிலைகளைத் தக்க வைத்துக் கொள்ளுங்கள்:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// அனைத்து வகை புலங்களும் `Default` ஐ செயல்படுத்தினால் இந்த trait ஐ `#[derive]` உடன் பயன்படுத்தலாம்.
/// `பெறப்பட்ட` போது, அது ஒவ்வொரு புலத்தின் வகைக்கும் இயல்புநிலை மதிப்பைப் பயன்படுத்தும்.
///
/// ## `Default` ஐ எவ்வாறு செயல்படுத்தலாம்?
///
/// இயல்புநிலையாக இருக்க வேண்டிய உங்கள் வகையின் மதிப்பை வழங்கும் `default()` முறைக்கு ஒரு செயல்படுத்தலை வழங்கவும்:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// ஒரு வகைக்கு "default value" ஐ வழங்குகிறது.
    ///
    /// இயல்புநிலை மதிப்புகள் பெரும்பாலும் ஒருவித ஆரம்ப மதிப்பு, அடையாள மதிப்பு அல்லது இயல்புநிலையாக அர்த்தமுள்ள வேறு எதையும்.
    ///
    ///
    /// # Examples
    ///
    /// உள்ளமைக்கப்பட்ட இயல்புநிலை மதிப்புகளைப் பயன்படுத்துதல்:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// உங்கள் சொந்தமாக்குதல்:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait இன் படி ஒரு வகையின் இயல்புநிலை மதிப்பைத் தரவும்.
///
/// திரும்புவதற்கான வகை சூழலில் இருந்து ஊகிக்கப்படுகிறது;இது `Default::default()` க்கு சமம், ஆனால் தட்டச்சு செய்ய குறைவு.
///
/// உதாரணத்திற்கு:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` இன் ஒரு impl ஐ உருவாக்கும் மேக்ரோ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }