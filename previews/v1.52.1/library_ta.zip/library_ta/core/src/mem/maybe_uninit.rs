use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` இன் ஆரம்பிக்கப்படாத நிகழ்வுகளை உருவாக்க ஒரு ரேப்பர் வகை.
///
/// # துவக்க மாற்றம்
///
/// கம்பைலர், பொதுவாக, மாறி வகையின் தேவைகளுக்கு ஏற்ப ஒரு மாறி சரியாக துவக்கப்படுகிறது என்று கருதுகிறது.எடுத்துக்காட்டாக, குறிப்பு வகையின் மாறி சீரமைக்கப்பட வேண்டும் மற்றும் NULL அல்லாததாக இருக்க வேண்டும்.
/// இது ஒரு மாறாதது, இது பாதுகாப்பற்ற குறியீட்டில் கூட *எப்போதும்* உறுதிப்படுத்தப்பட வேண்டும்.
/// இதன் விளைவாக, குறிப்பு வகையின் மாறியை பூஜ்ஜியமாக துவக்குவது உடனடி [undefined behavior][ub] ஐ ஏற்படுத்துகிறது, அந்த குறிப்பு நினைவகத்தை அணுக எப்போதாவது பயன்படுத்தப்படுகிறதா என்பது முக்கியமல்ல:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // வரையறுக்கப்படாத நடத்தை!⚠️
/// // `MaybeUninit<&i32>` உடன் சமமான குறியீடு:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // வரையறுக்கப்படாத நடத்தை!⚠️
/// ```
///
/// ரன்-டைம் காசோலைகளை நீக்குதல் மற்றும் `enum` தளவமைப்பை மேம்படுத்துதல் போன்ற பல்வேறு மேம்படுத்தல்களுக்காக இது கம்பைலரால் பயன்படுத்தப்படுகிறது.
///
/// இதேபோல், முற்றிலும் ஆரம்பிக்கப்படாத நினைவகம் எந்த உள்ளடக்கத்தையும் கொண்டிருக்கலாம், அதே நேரத்தில் ஒரு `bool` எப்போதும் `true` அல்லது `false` ஆக இருக்க வேண்டும்.எனவே, ஆரம்பிக்கப்படாத `bool` ஐ உருவாக்குவது வரையறுக்கப்படாத நடத்தை:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // வரையறுக்கப்படாத நடத்தை!⚠️
/// // `MaybeUninit<bool>` உடன் சமமான குறியீடு:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // வரையறுக்கப்படாத நடத்தை!⚠️
/// ```
///
/// மேலும், துவக்கப்படாத நினைவகம் சிறப்பு வாய்ந்தது, அதில் நிலையான மதிப்பு இல்லை ("fixed" என்றால் "it won't change without being written to").ஒரே துவக்கப்படாத பைட்டை பல முறை படித்தால் வெவ்வேறு முடிவுகளைத் தரலாம்.
/// இது மாறியில் ஒரு முழு எண் வகையைக் கொண்டிருந்தாலும் கூட, ஒரு மாறியில் துவக்கப்படாத தரவைக் கொண்டிருப்பது வரையறுக்கப்படாத நடத்தை செய்கிறது, இல்லையெனில் எந்த *நிலையான* பிட் வடிவத்தையும் வைத்திருக்க முடியும்:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // வரையறுக்கப்படாத நடத்தை!⚠️
/// // `MaybeUninit<i32>` உடன் சமமான குறியீடு:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // வரையறுக்கப்படாத நடத்தை!⚠️
/// ```
/// (ஆரம்பிக்கப்படாத முழு எண்களைச் சுற்றியுள்ள விதிகள் இன்னும் இறுதி செய்யப்படவில்லை என்பதைக் கவனியுங்கள், ஆனால் அவை இருக்கும் வரை அவற்றைத் தவிர்ப்பது நல்லது.)
///
/// அதற்கு மேல், வகை வகைகளில் துவக்கப்பட்டதாகக் கருதப்படுவதற்கு அப்பால் பெரும்பாலான வகைகளில் கூடுதல் மாற்றங்கள் உள்ளன என்பதை நினைவில் கொள்ளுங்கள்.
/// எடுத்துக்காட்டாக, ஒரு `1`-துவக்கப்பட்ட [`Vec<T>`] துவக்கமாகக் கருதப்படுகிறது (தற்போதைய செயல்பாட்டின் கீழ்; இது ஒரு நிலையான உத்தரவாதத்தை அளிக்காது) ஏனெனில் கம்பைலர் அதைப் பற்றி அறிந்த ஒரே தேவை தரவு சுட்டிக்காட்டி பூஜ்யமாக இருக்க வேண்டும்.
/// அத்தகைய `Vec<T>` ஐ உருவாக்குவது *உடனடி* வரையறுக்கப்படாத நடத்தையை ஏற்படுத்தாது, ஆனால் மிகவும் பாதுகாப்பான செயல்பாடுகளுடன் (அதை கைவிடுவது உட்பட) வரையறுக்கப்படாத நடத்தை ஏற்படுத்தும்.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` துவக்கப்படாத தரவைக் கையாள பாதுகாப்பற்ற குறியீட்டை இயக்க உதவுகிறது.
/// இது தொகுப்பிற்கான ஒரு சமிக்ஞையாகும், இது இங்குள்ள தரவு * துவக்கப்படக்கூடாது என்பதைக் குறிக்கிறது:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // வெளிப்படையாக ஆரம்பிக்கப்படாத குறிப்பை உருவாக்கவும்.
/// // `MaybeUninit<T>` க்குள் உள்ள தரவு செல்லாது என்று கம்பைலருக்குத் தெரியும், எனவே இது யுபி அல்ல:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // சரியான மதிப்புக்கு அமைக்கவும்.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // துவக்கப்பட்ட தரவைப் பிரித்தெடுக்கவும்-இது `x` ஐ சரியாக துவக்கிய பிறகு * மட்டுமே அனுமதிக்கப்படுகிறது!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// இந்த குறியீட்டில் தவறான அனுமானங்கள் அல்லது மேம்படுத்தல்கள் செய்யக்கூடாது என்று கம்பைலருக்குத் தெரியும்.
///
/// நீங்கள் `MaybeUninit<T>` ஐ `Option<T>` போன்றது என்று நினைக்கலாம், ஆனால் எந்த ரன்-டைம் டிராக்கிங் இல்லாமல் மற்றும் பாதுகாப்பு சோதனைகள் எதுவும் இல்லாமல்.
///
/// ## out-pointers
///
/// "out-pointers" ஐ செயல்படுத்த நீங்கள் `MaybeUninit<T>` ஐப் பயன்படுத்தலாம்: ஒரு செயல்பாட்டிலிருந்து தரவைத் திருப்புவதற்குப் பதிலாக, சில (uninitialized) நினைவகத்திற்கு ஒரு சுட்டிக்காட்டி அனுப்பவும்.
/// அழைப்பாளருக்கு முடிவு சேமிக்கப்படும் நினைவகம் எவ்வாறு ஒதுக்கப்படுகிறது என்பதைக் கட்டுப்படுத்துவது முக்கியம் போது இது பயனுள்ளதாக இருக்கும், மேலும் தேவையற்ற நகர்வுகளைத் தவிர்க்க விரும்புகிறீர்கள்.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` பழைய உள்ளடக்கங்களை கைவிடாது, இது முக்கியமானது.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // இப்போது `v` துவக்கப்பட்டது எங்களுக்குத் தெரியும்!இது vector சரியாக கைவிடப்படுவதையும் உறுதி செய்கிறது.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## ஒரு உறுப்பு உறுப்பு-மூலம்-உறுப்பு துவக்குகிறது
///
/// `MaybeUninit<T>` ஒரு பெரிய வரிசை உறுப்பு-மூலம்-உறுப்பு துவக்க பயன்படுத்தப்படலாம்:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` இன் துவக்கப்படாத வரிசையை உருவாக்கவும்.
///     // `assume_init` பாதுகாப்பானது, ஏனென்றால் நாங்கள் இங்கு துவக்கியதாகக் கூறும் வகை `ஒருவேளை யுனினிட்` இன் கொத்து, இது துவக்கம் தேவையில்லை.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // ஒரு `MaybeUninit` ஐ கைவிடுவது எதுவும் செய்யாது.
///     // இதனால் `ptr::write` க்கு பதிலாக மூல சுட்டிக்காட்டி ஒதுக்கீட்டைப் பயன்படுத்துவது பழைய ஆரம்பிக்கப்படாத மதிப்பைக் கைவிடாது.
/////
///     // இந்த வளையத்தின் போது ஒரு panic இருந்தால், எங்களுக்கு நினைவக கசிவு உள்ளது, ஆனால் நினைவக பாதுகாப்பு பிரச்சினை எதுவும் இல்லை.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // எல்லாம் துவக்கப்பட்டுள்ளது.
///     // துவக்கப்பட்ட வகைக்கு வரிசையை மாற்றவும்.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// ஓரளவு துவக்கப்பட்ட வரிசைகளுடன் நீங்கள் பணியாற்றலாம், அவை குறைந்த-நிலை தரவு கட்டமைப்புகளில் காணப்படுகின்றன.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` இன் துவக்கப்படாத வரிசையை உருவாக்கவும்.
/// // `assume_init` பாதுகாப்பானது, ஏனென்றால் நாங்கள் இங்கு துவக்கியதாகக் கூறும் வகை `ஒருவேளை யுனினிட்` இன் கொத்து, இது துவக்கம் தேவையில்லை.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // நாங்கள் ஒதுக்கிய உறுப்புகளின் எண்ணிக்கையை எண்ணுங்கள்.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // வரிசையில் உள்ள ஒவ்வொரு உருப்படிக்கும், நாங்கள் அதை ஒதுக்கினால் கைவிடவும்.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## ஒரு புலம்-மூலம்-புலத்தைத் தொடங்குதல்
///
/// புலங்கள் மூலம் structs புலத்தைத் தொடங்க நீங்கள் `MaybeUninit<T>` மற்றும் [`std::ptr::addr_of_mut`] மேக்ரோவைப் பயன்படுத்தலாம்:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` புலத்தைத் துவக்குகிறது
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` புலத்தைத் துவக்குதல் இங்கே ஒரு panic இருந்தால், `name` புலத்தில் உள்ள `String` கசிவு.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // எல்லா புலங்களும் துவக்கப்பட்டுள்ளன, எனவே துவக்கப்பட்ட Foo ஐப் பெற `assume_init` ஐ அழைக்கிறோம்.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` இன் அதே அளவு, சீரமைப்பு மற்றும் ஏபிஐ ஆகியவற்றைக் கொண்டிருப்பது உறுதி.
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// எவ்வாறாயினும், ஒரு `MaybeUninit<T>` ஐக் கொண்ட ஒரு வகை * ஒரே தளவமைப்பு அல்ல என்பதை நினைவில் கொள்ளுங்கள்;`T` மற்றும் `U` ஆகியவை ஒரே அளவு மற்றும் சீரமைப்பைக் கொண்டிருந்தாலும் கூட, `Foo<T>` இன் புலங்கள் `Foo<U>` ஐப் போலவே இருக்கும் என்று Rust பொதுவாக உத்தரவாதம் அளிக்காது.
///
/// மேலும், எந்த பிட் மதிப்பும் ஒரு `MaybeUninit<T>` க்கு செல்லுபடியாகும் என்பதால், கம்பைலர் non-zero/niche-filling தேர்வுமுறைகளைப் பயன்படுத்த முடியாது, இதன் விளைவாக பெரிய அளவு ஏற்படலாம்:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` FFI-பாதுகாப்பானது என்றால், `MaybeUninit<T>` உள்ளது.
///
/// `MaybeUninit` என்பது `#[repr(transparent)]` ஆக இருக்கும்போது (இது அதே அளவு, சீரமைப்பு மற்றும் ABI ஐ `T` என உத்தரவாதம் செய்கிறது என்பதைக் குறிக்கிறது), இது முந்தைய எச்சரிக்கைகள் எதையும் மாற்றாது.
/// `Option<T>` மற்றும் `Option<MaybeUninit<T>>` இன்னும் வெவ்வேறு அளவுகளைக் கொண்டிருக்கலாம், மேலும் `T` வகை ஒரு புலத்தைக் கொண்ட வகைகள் அந்த புலம் `MaybeUninit<T>` ஐ விட வித்தியாசமாக அமைக்கப்படலாம் (மற்றும் அளவு).
/// `MaybeUninit` ஒரு தொழிற்சங்க வகை, மற்றும் தொழிற்சங்கங்களில் `#[repr(transparent)]` நிலையற்றது ([the tracking issue](https://github.com/rust-lang/rust/issues/60405)) ஐப் பார்க்கவும்.
/// காலப்போக்கில், தொழிற்சங்கங்கள் மீதான `#[repr(transparent)]` இன் சரியான உத்தரவாதங்கள் உருவாகலாம், மேலும் `MaybeUninit` `#[repr(transparent)]` ஆக இருக்கலாம் அல்லது இல்லாமல் இருக்கலாம்.
/// `MaybeUninit<T>` ஆனது `T` க்கு ஒரே அளவு, சீரமைப்பு மற்றும் ஏபிஐ ஆகியவற்றைக் கொண்டிருப்பதாக *எப்போதும்* உத்தரவாதம் அளிக்கும்;`MaybeUninit` உத்தரவாதம் அளிக்கும் வழி உருவாகலாம் என்பது தான்.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// லாங் உருப்படி எனவே அதில் மற்ற வகைகளை மடிக்கலாம்.ஜெனரேட்டர்களுக்கு இது பயனுள்ளதாக இருக்கும்.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` ஐ அழைக்கவில்லை, அதற்காக நாங்கள் போதுமான அளவு துவக்கப்பட்டுள்ளோமா என்பதை அறிய முடியாது.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// கொடுக்கப்பட்ட மதிப்புடன் துவக்கப்பட்ட புதிய `MaybeUninit<T>` ஐ உருவாக்குகிறது.
    /// இந்த செயல்பாட்டின் வருவாய் மதிப்பில் [`assume_init`] ஐ அழைப்பது பாதுகாப்பானது.
    ///
    /// ஒரு `MaybeUninit<T>` ஐ கைவிடுவது ஒருபோதும் `T` இன் துளி குறியீட்டை அழைக்காது என்பதை நினைவில் கொள்க.
    /// துவக்கப்பட்டால் `T` கைவிடப்படுவதை உறுதி செய்வது உங்கள் பொறுப்பு.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// ஆரம்பிக்கப்படாத நிலையில் புதிய `MaybeUninit<T>` ஐ உருவாக்குகிறது.
    ///
    /// ஒரு `MaybeUninit<T>` ஐ கைவிடுவது ஒருபோதும் `T` இன் துளி குறியீட்டை அழைக்காது என்பதை நினைவில் கொள்க.
    /// துவக்கப்பட்டால் `T` கைவிடப்படுவதை உறுதி செய்வது உங்கள் பொறுப்பு.
    ///
    /// சில எடுத்துக்காட்டுகளுக்கு [type-level documentation][MaybeUninit] ஐப் பார்க்கவும்.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// ஆரம்பிக்கப்படாத நிலையில், `MaybeUninit<T>` உருப்படிகளின் புதிய வரிசையை உருவாக்கவும்.
    ///
    /// Note: ஒரு future Rust பதிப்பில், வரிசை எளிமையான தொடரியல் [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ஐ அனுமதிக்கும்போது இந்த முறை தேவையற்றதாகிவிடும்.
    ///
    /// கீழே உள்ள எடுத்துக்காட்டு பின்னர் `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` ஐப் பயன்படுத்தலாம்.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// உண்மையில் படித்த தரவின் (ஒருவேளை சிறிய) துண்டுகளை வழங்குகிறது
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // பாதுகாப்பு: ஆரம்பிக்கப்படாத `[MaybeUninit<_>; LEN]` செல்லுபடியாகும்.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// நினைவகம் `0` பைட்டுகளால் நிரப்பப்பட்ட நிலையில், ஒரு புதிய `MaybeUninit<T>` ஐ ஆரம்பிக்கப்படாத நிலையில் உருவாக்குகிறது.இது ஏற்கனவே சரியான துவக்கத்திற்கு வழிவகுக்கிறதா என்பது `T` ஐப் பொறுத்தது.
    ///
    /// எடுத்துக்காட்டாக, `MaybeUninit<usize>::zeroed()` துவக்கப்பட்டது, ஆனால் `MaybeUninit<&'static i32>::zeroed()` என்பது குறிப்புகள் பூஜ்யமாக இருக்கக்கூடாது என்பதால் அல்ல.
    ///
    /// ஒரு `MaybeUninit<T>` ஐ கைவிடுவது ஒருபோதும் `T` இன் துளி குறியீட்டை அழைக்காது என்பதை நினைவில் கொள்க.
    /// துவக்கப்பட்டால் `T` கைவிடப்படுவதை உறுதி செய்வது உங்கள் பொறுப்பு.
    ///
    /// # Example
    ///
    /// இந்த செயல்பாட்டின் சரியான பயன்பாடு: பூஜ்ஜியத்துடன் ஒரு கட்டமைப்பைத் துவக்குதல், அங்கு கட்டமைப்பின் அனைத்து புலங்களும் பிட்-முறை 0 ஐ சரியான மதிப்பாக வைத்திருக்க முடியும்.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// இந்த செயல்பாட்டின் *தவறான* பயன்பாடு: `0` வகைக்கு சரியான பிட்-முறை இல்லாதபோது `x.zeroed().assume_init()` ஐ அழைப்பது:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // ஒரு ஜோடிக்குள், சரியான பாகுபாடு இல்லாத `NotZero` ஐ உருவாக்குகிறோம்.
    /// // இது வரையறுக்கப்படாத நடத்தை.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // பாதுகாப்பு: ஒதுக்கப்பட்ட நினைவகத்திற்கு `u.as_mut_ptr()` புள்ளிகள்.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` இன் மதிப்பை அமைக்கிறது.
    /// இது முந்தைய எந்த மதிப்பையும் கைவிடாமல் மேலெழுதும், எனவே நீங்கள் டிஸ்ட்ரக்டரை இயக்குவதைத் தவிர்க்க விரும்பாவிட்டால் இதை இருமுறை பயன்படுத்த வேண்டாம்.
    ///
    /// உங்கள் வசதிக்காக, இது `self` இன் (இப்போது பாதுகாப்பாக தொடங்கப்பட்ட) உள்ளடக்கங்களுக்கும் மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // பாதுகாப்பு: இந்த மதிப்பை நாங்கள் தொடங்கினோம்.
        unsafe { self.assume_init_mut() }
    }

    /// அடங்கிய மதிப்புக்கு ஒரு சுட்டிக்காட்டி கிடைக்கிறது.
    /// இந்த சுட்டிக்காட்டியிலிருந்து படிப்பது அல்லது அதை ஒரு குறிப்பாக மாற்றுவது என்பது `MaybeUninit<T>` துவக்கப்படாவிட்டால் வரையறுக்கப்படாத நடத்தை.
    /// இந்த சுட்டிக்காட்டி (non-transitively) சுட்டிக்காட்டும் நினைவகத்திற்கு எழுதுவது வரையறுக்கப்படாத நடத்தை (ஒரு `UnsafeCell<T>` க்குள் தவிர).
    ///
    /// # Examples
    ///
    /// இந்த முறையின் சரியான பயன்பாடு:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` இல் ஒரு குறிப்பை உருவாக்கவும்.நாங்கள் இதை துவக்கியதால் இது பரவாயில்லை.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// இந்த முறையின் *தவறான* பயன்பாடு:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // ஆரம்பிக்கப்படாத vector க்கு ஒரு குறிப்பை உருவாக்கியுள்ளோம்!இது வரையறுக்கப்படாத நடத்தை.⚠️
    /// ```
    ///
    /// (ஆரம்பிக்கப்படாத தரவுகளுக்கான குறிப்புகளைச் சுற்றியுள்ள விதிகள் இன்னும் இறுதி செய்யப்படவில்லை என்பதைக் கவனியுங்கள், ஆனால் அவை இருக்கும் வரை அவற்றைத் தவிர்ப்பது நல்லது.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` மற்றும் `ManuallyDrop` இரண்டும் `repr(transparent)` ஆகும், எனவே நாம் சுட்டிக்காட்டி அனுப்பலாம்.
        self as *const _ as *const T
    }

    /// அடங்கிய மதிப்புக்கு மாற்றக்கூடிய சுட்டிக்காட்டி பெறுகிறது.
    /// இந்த சுட்டிக்காட்டியிலிருந்து படிப்பது அல்லது அதை ஒரு குறிப்பாக மாற்றுவது என்பது `MaybeUninit<T>` துவக்கப்படாவிட்டால் வரையறுக்கப்படாத நடத்தை.
    ///
    /// # Examples
    ///
    /// இந்த முறையின் சரியான பயன்பாடு:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` இல் ஒரு குறிப்பை உருவாக்கவும்.
    /// // நாங்கள் இதை துவக்கியதால் இது பரவாயில்லை.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// இந்த முறையின் *தவறான* பயன்பாடு:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // ஆரம்பிக்கப்படாத vector க்கு ஒரு குறிப்பை உருவாக்கியுள்ளோம்!இது வரையறுக்கப்படாத நடத்தை.⚠️
    /// ```
    ///
    /// (ஆரம்பிக்கப்படாத தரவுகளுக்கான குறிப்புகளைச் சுற்றியுள்ள விதிகள் இன்னும் இறுதி செய்யப்படவில்லை என்பதைக் கவனியுங்கள், ஆனால் அவை இருக்கும் வரை அவற்றைத் தவிர்ப்பது நல்லது.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` மற்றும் `ManuallyDrop` இரண்டும் `repr(transparent)` ஆகும், எனவே நாம் சுட்டிக்காட்டி அனுப்பலாம்.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` கொள்கலனில் இருந்து மதிப்பைப் பிரித்தெடுக்கிறது.தரவு கைவிடப்படும் என்பதை உறுதிப்படுத்த இது ஒரு சிறந்த வழியாகும், ஏனெனில் இதன் விளைவாக வரும் `T` வழக்கமான துளி கையாளுதலுக்கு உட்பட்டது.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளது என்பதை உத்தரவாதம் செய்வது அழைப்பாளரின் பொறுப்பாகும்.உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது உடனடி வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
    /// இந்த துவக்க மாற்றத்தைப் பற்றிய கூடுதல் தகவல்களை [type-level documentation][inv] கொண்டுள்ளது.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// அதற்கு மேல், வகை வகைகளில் துவக்கப்பட்டதாகக் கருதப்படுவதற்கு அப்பால் பெரும்பாலான வகைகளில் கூடுதல் மாற்றங்கள் உள்ளன என்பதை நினைவில் கொள்ளுங்கள்.
    /// எடுத்துக்காட்டாக, ஒரு `1`-துவக்கப்பட்ட [`Vec<T>`] துவக்கமாகக் கருதப்படுகிறது (தற்போதைய செயல்பாட்டின் கீழ்; இது ஒரு நிலையான உத்தரவாதத்தை அளிக்காது) ஏனெனில் கம்பைலர் அதைப் பற்றி அறிந்த ஒரே தேவை தரவு சுட்டிக்காட்டி பூஜ்யமாக இருக்க வேண்டும்.
    ///
    /// அத்தகைய `Vec<T>` ஐ உருவாக்குவது *உடனடி* வரையறுக்கப்படாத நடத்தையை ஏற்படுத்தாது, ஆனால் மிகவும் பாதுகாப்பான செயல்பாடுகளுடன் (அதை கைவிடுவது உட்பட) வரையறுக்கப்படாத நடத்தை ஏற்படுத்தும்.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// இந்த முறையின் சரியான பயன்பாடு:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// இந்த முறையின் *தவறான* பயன்பாடு:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` இன்னும் துவக்கப்படவில்லை, எனவே இந்த கடைசி வரி வரையறுக்கப்படாத நடத்தைக்கு காரணமாக அமைந்தது.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // பாதுகாப்பு: அழைப்பாளர் `self` துவக்கப்படுவதற்கு உத்தரவாதம் அளிக்க வேண்டும்.
        // `self` ஒரு `value` மாறுபாடாக இருக்க வேண்டும் என்பதும் இதன் பொருள்.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` கொள்கலனில் இருந்து மதிப்பைப் படிக்கிறது.இதன் விளைவாக `T` வழக்கமான துளி கையாளுதலுக்கு உட்பட்டது.
    ///
    /// எப்போது வேண்டுமானாலும், அதற்கு பதிலாக [`assume_init`] ஐப் பயன்படுத்துவது விரும்பத்தக்கது, இது `MaybeUninit<T>` இன் உள்ளடக்கத்தை நகலெடுப்பதைத் தடுக்கிறது.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளது என்பதை உத்தரவாதம் செய்வது அழைப்பாளரின் பொறுப்பாகும்.உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
    /// இந்த துவக்க மாற்றத்தைப் பற்றிய கூடுதல் தகவல்களை [type-level documentation][inv] கொண்டுள்ளது.
    ///
    /// மேலும், இது `MaybeUninit<T>` இல் அதே தரவின் நகலை விட்டுச்செல்கிறது.
    /// தரவின் பல நகல்களைப் பயன்படுத்தும் போது (`assume_init_read` ஐ பல முறை அழைப்பதன் மூலம், அல்லது முதலில் `assume_init_read` மற்றும் பின்னர் [`assume_init`] ஐ அழைப்பதன் மூலம்), அந்தத் தரவு உண்மையில் நகல் செய்யப்படலாம் என்பதை உறுதிப்படுத்துவது உங்கள் பொறுப்பு.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// இந்த முறையின் சரியான பயன்பாடு:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` ஆகும், எனவே நாம் பல முறை படிக்கலாம்.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` மதிப்பை நகலெடுப்பது சரி, எனவே நாம் பல முறை படிக்கலாம்.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// இந்த முறையின் *தவறான* பயன்பாடு:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // நாங்கள் இப்போது ஒரே vector இன் இரண்டு நகல்களை உருவாக்கியுள்ளோம், இது இரண்டும் இல்லாதது-அவை இரண்டும் கைவிடப்படும் போது!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // பாதுகாப்பு: அழைப்பாளர் `self` துவக்கப்படுவதற்கு உத்தரவாதம் அளிக்க வேண்டும்.
        // `self` ஐ துவக்க வேண்டும் என்பதால் `self.as_ptr()` இலிருந்து படித்தல் பாதுகாப்பானது.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// அடங்கிய மதிப்பை இடத்தில் சொட்டுகிறது.
    ///
    /// உங்களிடம் `MaybeUninit` இன் உரிமை இருந்தால், அதற்கு பதிலாக [`assume_init`] ஐப் பயன்படுத்தலாம்.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளது என்பதை உத்தரவாதம் செய்வது அழைப்பாளரின் பொறுப்பாகும்.உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
    ///
    /// அதற்கு மேல்,`T` வகையின் அனைத்து கூடுதல் மாற்றங்களும் திருப்தி அடைய வேண்டும், ஏனெனில் `T` இன் `Drop` செயல்படுத்தல் (அல்லது அதன் உறுப்பினர்கள்) இதை நம்பியிருக்கலாம்.
    /// எடுத்துக்காட்டாக, ஒரு `1`-துவக்கப்பட்ட [`Vec<T>`] துவக்கமாகக் கருதப்படுகிறது (தற்போதைய செயல்பாட்டின் கீழ்; இது ஒரு நிலையான உத்தரவாதத்தை அளிக்காது) ஏனெனில் கம்பைலர் அதைப் பற்றி அறிந்த ஒரே தேவை தரவு சுட்டிக்காட்டி பூஜ்யமாக இருக்க வேண்டும்.
    ///
    /// அத்தகைய `Vec<T>` ஐ கைவிடுவது வரையறுக்கப்படாத நடத்தைக்கு வழிவகுக்கும்.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // பாதுகாப்பு: அழைப்பாளர் `self` துவக்கப்பட்டுள்ளது என்பதற்கு உத்தரவாதம் அளிக்க வேண்டும்
        // `T` இன் அனைத்து மாற்றங்களையும் பூர்த்தி செய்கிறது.
        // அப்படியானால் மதிப்பை கைவிடுவது பாதுகாப்பானது.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// அடங்கிய மதிப்புக்கு பகிரப்பட்ட குறிப்பைப் பெறுகிறது.
    ///
    /// துவக்கப்பட்ட ஒரு `MaybeUninit` ஐ அணுக விரும்பும்போது இது பயனுள்ளதாக இருக்கும், ஆனால் `MaybeUninit` இன் உரிமையை கொண்டிருக்கவில்லை (`.assume_init()`) பயன்பாட்டைத் தடுக்கிறது.
    ///
    /// # Safety
    ///
    /// உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது: `MaybeUninit<T>` உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளது என்பதை உத்தரவாதம் செய்வது அழைப்பாளரின் பொறுப்பாகும்.
    ///
    ///
    /// # Examples
    ///
    /// ### இந்த முறையின் சரியான பயன்பாடு:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` ஐத் தொடங்கவும்:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // இப்போது எங்கள் `MaybeUninit<_>` துவக்கப்படுவதாக அறியப்பட்டதால், அதைப் பகிரப்பட்ட குறிப்பை உருவாக்குவது சரி:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // பாதுகாப்பு: `x` தொடங்கப்பட்டது.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### இந்த முறையின் *தவறான* பயன்பாடுகள்:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // ஆரம்பிக்கப்படாத vector க்கு ஒரு குறிப்பை உருவாக்கியுள்ளோம்!இது வரையறுக்கப்படாத நடத்தை.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` ஐப் பயன்படுத்தி `MaybeUninit` ஐத் தொடங்கவும்:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // ஆரம்பிக்கப்படாத `Cell<bool>` பற்றிய குறிப்பு: யுபி!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // பாதுகாப்பு: அழைப்பாளர் `self` துவக்கப்படுவதற்கு உத்தரவாதம் அளிக்க வேண்டும்.
        // `self` ஒரு `value` மாறுபாடாக இருக்க வேண்டும் என்பதும் இதன் பொருள்.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// அடங்கிய மதிப்புக்கு மாற்றக்கூடிய (unique) குறிப்பைப் பெறுகிறது.
    ///
    /// துவக்கப்பட்ட ஒரு `MaybeUninit` ஐ அணுக விரும்பும்போது இது பயனுள்ளதாக இருக்கும், ஆனால் `MaybeUninit` இன் உரிமையை கொண்டிருக்கவில்லை (`.assume_init()`) பயன்பாட்டைத் தடுக்கிறது.
    ///
    /// # Safety
    ///
    /// உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது: `MaybeUninit<T>` உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளது என்பதை உத்தரவாதம் செய்வது அழைப்பாளரின் பொறுப்பாகும்.
    /// உதாரணமாக, `MaybeUninit` ஐ துவக்க `.assume_init_mut()` ஐப் பயன்படுத்த முடியாது.
    ///
    /// # Examples
    ///
    /// ### இந்த முறையின் சரியான பயன்பாடு:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// உள்ளீட்டு இடையகத்தின் பைட்டுகள் *அனைத்தையும்* துவக்குகிறது.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` ஐத் தொடங்கவும்:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // இப்போது `buf` துவக்கப்பட்டுள்ளது என்பதை நாங்கள் அறிவோம், எனவே அதை `.assume_init()` செய்யலாம்.
    /// // இருப்பினும், `.assume_init()` ஐப் பயன்படுத்துவது 2048 பைட்டுகளின் `memcpy` ஐத் தூண்டக்கூடும்.
    /// // எங்கள் இடையகத்தை நகலெடுக்காமல் துவக்கியுள்ளதாக உறுதிப்படுத்த, நாங்கள் `&mut MaybeUninit<[u8; 2048]>` ஐ `&mut [u8; 2048]` க்கு மேம்படுத்துகிறோம்:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // பாதுகாப்பு: `buf` தொடங்கப்பட்டது.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // இப்போது நாம் `buf` ஐ சாதாரண துண்டுகளாகப் பயன்படுத்தலாம்:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### இந்த முறையின் *தவறான* பயன்பாடுகள்:
    ///
    /// மதிப்பைத் தொடங்க நீங்கள் `.assume_init_mut()` ஐப் பயன்படுத்த முடியாது:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // ஆரம்பிக்கப்படாத `bool` க்கு (mutable) குறிப்பை உருவாக்கியுள்ளோம்!
    ///     // இது வரையறுக்கப்படாத நடத்தை.⚠️
    /// }
    /// ```
    ///
    /// உதாரணமாக, நீங்கள் ஆரம்பிக்கப்படாத இடையகத்திற்கு [`Read`] செய்ய முடியாது:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ஆரம்பிக்கப்படாத நினைவகத்திற்கான குறிப்பு!
    ///                             // இது வரையறுக்கப்படாத நடத்தை.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// புலம் வாரியாக படிப்படியாக துவக்க நேரடி புல அணுகலைப் பயன்படுத்தவும் முடியாது:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ஆரம்பிக்கப்படாத நினைவகத்திற்கான குறிப்பு!
    ///                  // இது வரையறுக்கப்படாத நடத்தை.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ஆரம்பிக்கப்படாத நினைவகத்திற்கான குறிப்பு!
    ///                  // இது வரையறுக்கப்படாத நடத்தை.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): மேலே உள்ளவை தவறானவை என்பதை நாங்கள் தற்போது நம்பியுள்ளோம், அதாவது, ஆரம்பிக்கப்படாத தரவைப் பற்றிய குறிப்புகள் எங்களிடம் உள்ளன (எ.கா., `libcore/fmt/float.rs` இல்).
    // உறுதிப்படுத்தப்படுவதற்கு முன்னர் விதிகள் குறித்து இறுதி முடிவை எடுக்க வேண்டும்.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // பாதுகாப்பு: அழைப்பாளர் `self` துவக்கப்படுவதற்கு உத்தரவாதம் அளிக்க வேண்டும்.
        // `self` ஒரு `value` மாறுபாடாக இருக்க வேண்டும் என்பதும் இதன் பொருள்.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` கொள்கலன்களின் வரிசையிலிருந்து மதிப்புகளைப் பிரித்தெடுக்கிறது.
    ///
    /// # Safety
    ///
    /// வரிசையின் அனைத்து கூறுகளும் துவக்கப்பட்ட நிலையில் உள்ளன என்பதை உத்தரவாதம் செய்வது அழைப்பாளரின் பொறுப்பாகும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // பாதுகாப்பு: எல்லா உறுப்புகளையும் நாங்கள் துவக்கியதால் இப்போது பாதுகாப்பானது
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * வரிசையின் அனைத்து கூறுகளும் துவக்கப்பட்டுள்ளன என்று அழைப்பாளர் உத்தரவாதம் அளிக்கிறார்
        // * `MaybeUninit<T>` மற்றும் டி ஒரே அமைப்பைக் கொண்டிருப்பது உறுதி
        // * ஒருவேளை யுனிண்ட் கைவிடாது, எனவே இரட்டை-இலவசங்கள் எதுவும் இல்லை, இதனால் மாற்றம் பாதுகாப்பானது
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// அனைத்து கூறுகளும் துவக்கப்பட்டுள்ளன என்று கருதி, அவற்றுக்கு ஒரு துண்டு கிடைக்கும்.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` கூறுகள் உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளன என்பதை உத்தரவாதம் செய்வது அழைப்பாளரின் பொறுப்பாகும்.
    ///
    /// உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
    ///
    /// மேலும் விவரங்கள் மற்றும் எடுத்துக்காட்டுகளுக்கு [`assume_init_ref`] ஐப் பார்க்கவும்.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // பாதுகாப்பு: அழைப்பாளர் அதற்கு உத்தரவாதம் அளிப்பதால், ஒரு `*const [T]` க்கு துண்டுகளை அனுப்புவது பாதுகாப்பானது
        // `slice` துவக்கப்பட்டது, மற்றும் `மேபே யுனினிட்` `T` ஐப் போன்ற அமைப்பைக் கொண்டிருப்பது உறுதி.
        // பெறப்பட்ட சுட்டிக்காட்டி செல்லுபடியாகும், ஏனெனில் இது `slice` க்கு சொந்தமான நினைவகத்தைக் குறிக்கிறது, இது ஒரு குறிப்பு மற்றும் இதனால் வாசிப்புகளுக்கு செல்லுபடியாகும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// அனைத்து கூறுகளும் துவக்கப்பட்டுள்ளன என்று கருதி, அவற்றுக்கு ஒரு மாற்றக்கூடிய துண்டுகளைப் பெறுங்கள்.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` கூறுகள் உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளன என்பதை உத்தரவாதம் செய்வது அழைப்பாளரின் பொறுப்பாகும்.
    ///
    /// உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
    ///
    /// மேலும் விவரங்கள் மற்றும் எடுத்துக்காட்டுகளுக்கு [`assume_init_mut`] ஐப் பார்க்கவும்.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // பாதுகாப்பு: `slice_get_ref` க்கான பாதுகாப்புக் குறிப்புகளைப் போன்றது, ஆனால் எங்களிடம் உள்ளது
        // மாற்றத்தக்க குறிப்பு இது எழுத்துக்களுக்கு செல்லுபடியாகும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// வரிசையின் முதல் உறுப்புக்கு ஒரு சுட்டிக்காட்டி கிடைக்கிறது.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// வரிசையின் முதல் உறுப்புக்கு மாற்றக்கூடிய சுட்டிக்காட்டி பெறுகிறது.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` இலிருந்து `this` வரையிலான கூறுகளை நகலெடுக்கிறது, இப்போது `this` இன் தூண்டப்படாத உள்ளடக்கங்களுக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// `T` `Copy` ஐ செயல்படுத்தவில்லை என்றால், [`write_slice_cloned`] ஐப் பயன்படுத்தவும்
    ///
    /// இது [`slice::copy_from_slice`] ஐப் போன்றது.
    ///
    /// # Panics
    ///
    /// இரண்டு துண்டுகள் வெவ்வேறு நீளங்களைக் கொண்டிருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // பாதுகாப்பு: லென்ஸின் அனைத்து கூறுகளையும் உதிரி திறனில் நகலெடுத்துள்ளோம்
    /// // vec இன் முதல் src.len() கூறுகள் இப்போது செல்லுபடியாகும்.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // பாதுகாப்பு: &[டி] மற்றும்&[ஒருவேளை யுனினிட்<T>] ஒரே அமைப்பைக் கொண்டுள்ளன
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // பாதுகாப்பு: செல்லுபடியாகும் கூறுகள் இப்போது `this` இல் நகலெடுக்கப்பட்டுள்ளன, எனவே அது தூண்டப்படுகிறது
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` முதல் `this` வரையிலான கூறுகளை குளோன் செய்கிறது, இப்போது `this` இன் தூண்டப்படாத உள்ளடக்கங்களுக்கு மாற்றக்கூடிய குறிப்பைத் தருகிறது.
    /// ஏற்கனவே தூண்டப்படாத எந்த உறுப்புகளும் கைவிடப்படாது.
    ///
    /// `T` `Copy` ஐ செயல்படுத்தினால், [`write_slice`] ஐப் பயன்படுத்தவும்
    ///
    /// இது [`slice::clone_from_slice`] ஐப் போன்றது, ஆனால் இருக்கும் உறுப்புகளைக் கைவிடாது.
    ///
    /// # Panics
    ///
    /// இரண்டு துண்டுகள் வெவ்வேறு நீளங்களைக் கொண்டிருந்தால் அல்லது `Clone` panics ஐ செயல்படுத்தினால் இந்த செயல்பாடு panic ஆக இருக்கும்.
    ///
    /// panic இருந்தால், ஏற்கனவே குளோன் செய்யப்பட்ட கூறுகள் கைவிடப்படும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // பாதுகாப்பு: லென்ஸின் அனைத்து கூறுகளையும் உதிரி திறனில் குளோன் செய்துள்ளோம்
    /// // vec இன் முதல் src.len() கூறுகள் இப்போது செல்லுபடியாகும்.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Copy_from_slice போலல்லாமல், இது ஸ்லைனில் குளோன்_பிரோம்_ஸ்லைஸை அழைக்காது, ஏனென்றால் `MaybeUninit<T: Clone>` குளோனை செயல்படுத்தவில்லை.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // பாதுகாப்பு: இந்த மூல துண்டில் துவக்கப்பட்ட பொருள்கள் மட்டுமே இருக்கும்
                // அதனால்தான், அதை கைவிட அனுமதிக்கப்படுகிறது.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: நாம் அவற்றை ஒரே நீளத்திற்கு வெளிப்படையாக வெட்ட வேண்டும்
        // எல்லை சரிபார்ப்பு நீக்குவதற்கு, மற்றும் உகப்பாக்கி எளிய நிகழ்வுகளுக்கு மெம்கிபியை உருவாக்கும் (எடுத்துக்காட்டாக T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // பாதுகாப்பு தேவை b/c panic ஒரு குளோனின் போது நிகழக்கூடும்
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // பாதுகாப்பு: செல்லுபடியாகும் கூறுகள் இப்போது `this` இல் எழுதப்பட்டுள்ளன, எனவே அது தூண்டப்படுகிறது
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}