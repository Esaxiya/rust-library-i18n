use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// `T` இன் டிஸ்ட்ரக்டரை தானாக அழைப்பதில் இருந்து கம்பைலரைத் தடுக்க ஒரு ரேப்பர்.
/// இந்த ரேப்பர் 0-செலவு.
///
/// `ManuallyDrop<T>` `T` போன்ற அதே தளவமைப்பு மேம்படுத்தல்களுக்கு உட்பட்டது.
/// இதன் விளைவாக, அதன் உள்ளடக்கங்களைப் பற்றி தொகுப்பி செய்யும் அனுமானங்களில் இது * எந்த விளைவையும் ஏற்படுத்தாது.
/// எடுத்துக்காட்டாக, [`mem::zeroed`] உடன் `ManuallyDrop<&mut T>` ஐத் தொடங்குவது வரையறுக்கப்படாத நடத்தை.
/// நீங்கள் துவக்கப்படாத தரவைக் கையாள வேண்டும் என்றால், அதற்கு பதிலாக [`MaybeUninit<T>`] ஐப் பயன்படுத்தவும்.
///
/// `ManuallyDrop<T>` க்குள் மதிப்பை அணுகுவது பாதுகாப்பானது என்பதை நினைவில் கொள்க.
/// இதன் பொருள் ஒரு `ManuallyDrop<T>` இன் உள்ளடக்கம் கைவிடப்பட்டது பொது பாதுகாப்பான API மூலம் வெளிப்படுத்தப்படக்கூடாது.
/// அதற்கேற்ப, `ManuallyDrop::drop` பாதுகாப்பற்றது.
///
/// # `ManuallyDrop` மற்றும் ஒழுங்கு கைவிட.
///
/// Rust நன்கு வரையறுக்கப்பட்ட [drop order] மதிப்புகளைக் கொண்டுள்ளது.
/// புலங்கள் அல்லது உள்ளூர்வாசிகள் ஒரு குறிப்பிட்ட வரிசையில் கைவிடப்படுவதை உறுதிசெய்ய, மறைமுகமான துளி வரிசை சரியானது என்று அறிவிப்புகளை மறுவரிசைப்படுத்தவும்.
///
/// துளி வரிசையை கட்டுப்படுத்த `ManuallyDrop` ஐப் பயன்படுத்துவது சாத்தியம், ஆனால் இதற்கு பாதுகாப்பற்ற குறியீடு தேவைப்படுகிறது மற்றும் பிரிக்கப்படாத முன்னிலையில் சரியாகச் செய்வது கடினம்.
///
///
/// எடுத்துக்காட்டாக, ஒரு குறிப்பிட்ட புலம் மற்றவர்களுக்குப் பிறகு கைவிடப்படுவதை உறுதிப்படுத்த விரும்பினால், அதை ஒரு கட்டமைப்பின் கடைசி புலமாக மாற்றவும்:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` க்குப் பிறகு கைவிடப்படும்.
///     // Rust அறிவிப்பு வரிசையில் புலங்கள் கைவிடப்படுவதாக உத்தரவாதம் அளிக்கிறது.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// கைமுறையாக கைவிடப்பட வேண்டிய மதிப்பை மடக்கு.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // நீங்கள் இன்னும் பாதுகாப்பாக மதிப்பில் செயல்பட முடியும்
    /// assert_eq!(*x, "Hello");
    /// // ஆனால் `Drop` இங்கே இயங்காது
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` கொள்கலனில் இருந்து மதிப்பைப் பிரித்தெடுக்கிறது.
    ///
    /// இது மதிப்பை மீண்டும் கைவிட அனுமதிக்கிறது.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // இது `Box` ஐக் குறைக்கிறது.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` கொள்கலனில் இருந்து மதிப்பை எடுக்கிறது.
    ///
    /// இந்த முறை முதன்மையாக மதிப்பில் வீழ்ச்சியை நகர்த்துவதற்காக வடிவமைக்கப்பட்டுள்ளது.
    /// மதிப்பை கைமுறையாக கைவிட [`ManuallyDrop::drop`] ஐப் பயன்படுத்துவதற்குப் பதிலாக, இந்த முறையைப் பயன்படுத்தி மதிப்பை எடுத்து, விரும்பியபடி பயன்படுத்தலாம்.
    ///
    /// எப்போது வேண்டுமானாலும், அதற்கு பதிலாக [`into_inner`][`ManuallyDrop::into_inner`] ஐப் பயன்படுத்துவது விரும்பத்தக்கது, இது `ManuallyDrop<T>` இன் உள்ளடக்கத்தை நகலெடுப்பதைத் தடுக்கிறது.
    ///
    ///
    /// # Safety
    ///
    /// இந்த செயல்பாடு மேலும் பயன்பாட்டைத் தடுக்காமல் அடங்கிய மதிப்பை சொற்பொருளாக நகர்த்தி, இந்த கொள்கலனின் நிலையை மாற்றாமல் விட்டுவிடுகிறது.
    /// இந்த `ManuallyDrop` மீண்டும் பயன்படுத்தப்படாமல் இருப்பதை உறுதி செய்வது உங்கள் பொறுப்பு.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // பாதுகாப்பு: நாங்கள் ஒரு குறிப்பிலிருந்து படிக்கிறோம், இது உத்தரவாதம்
        // வாசிப்புகளுக்கு செல்லுபடியாகும்.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// அடங்கிய மதிப்பை கைமுறையாகக் குறைக்கிறது.அடங்கிய மதிப்புக்கு ஒரு சுட்டிக்காட்டி மூலம் [`ptr::drop_in_place`] ஐ அழைப்பதற்கு இது சரியாக சமம்.
    /// எனவே, அடங்கிய மதிப்பு ஒரு நிரம்பிய கட்டமைப்பாக இல்லாவிட்டால், மதிப்பை நகர்த்தாமல் டிஸ்ட்ரக்டர் இடத்தில் அழைக்கப்படும், இதனால் [pinned] தரவை பாதுகாப்பாக கைவிட பயன்படுத்தலாம்.
    ///
    /// உங்களிடம் மதிப்பின் உரிமை இருந்தால், அதற்கு பதிலாக நீங்கள் [`ManuallyDrop::into_inner`] ஐப் பயன்படுத்தலாம்.
    ///
    /// # Safety
    ///
    /// இந்த செயல்பாடு கொண்டிருக்கும் மதிப்பின் அழிப்பை இயக்குகிறது.
    /// டிஸ்ட்ரக்டரால் செய்யப்பட்ட மாற்றங்களைத் தவிர, நினைவகம் மாறாமல் உள்ளது, மேலும் கம்பைலரைப் பொருத்தவரை `T` வகைக்கு செல்லுபடியாகும் ஒரு பிட்-வடிவத்தை வைத்திருக்கிறது.
    ///
    ///
    /// இருப்பினும், இந்த "zombie" மதிப்பு பாதுகாப்பான குறியீட்டை வெளிப்படுத்தக்கூடாது, மேலும் இந்த செயல்பாட்டை ஒன்றுக்கு மேற்பட்ட முறை அழைக்கக்கூடாது.
    /// ஒரு மதிப்பைக் கைவிட்ட பிறகு அதைப் பயன்படுத்த அல்லது மதிப்பை பல முறை கைவிடுவது வரையறுக்கப்படாத நடத்தைக்கு வழிவகுக்கும் (`drop` என்ன செய்கிறது என்பதைப் பொறுத்து).
    /// இது பொதுவாக வகை அமைப்பால் தடுக்கப்படுகிறது, ஆனால் `ManuallyDrop` இன் பயனர்கள் அந்த உத்தரவாதங்களை தொகுப்பாளரின் உதவியின்றி ஆதரிக்க வேண்டும்.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // பாதுகாப்பு: மாற்றக்கூடிய குறிப்பால் சுட்டிக்காட்டப்பட்ட மதிப்பை நாங்கள் கைவிடுகிறோம்
        // இது எழுத்துக்களுக்கு செல்லுபடியாகும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
        // `slot` மீண்டும் கைவிடப்படவில்லை என்பதை உறுதிப்படுத்துவது அழைப்பாளரின் பொறுப்பாகும்.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}