use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // இது நிலையான மேற்பரப்பு அல்ல, ஆனால் எல்.எல்.வி.எம் எப்போதும் அதைப் பயன்படுத்த முடியாவிட்டாலும் கூட, அவற்றுக்கிடையே எக்ஸ் 100 எக்ஸ் மலிவாக வைக்க உதவுகிறது.
    //
    // (துரதிர்ஷ்டவசமாக முடிவு மற்றும் விருப்பம் சீரற்றவை, எனவே கண்ட்ரோல்ஃப்ளோ இரண்டையும் பொருத்த முடியாது.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}