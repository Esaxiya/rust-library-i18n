use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // மிரி மிகவும் மெதுவாக உள்ளது
fn exact_sanity_test() {
    // இந்த சோதனை `exp2` நூலக செயல்பாட்டின் சில மூலையில் உள்ளது என்று நான் மட்டுமே கருத முடியும், இது நாம் பயன்படுத்தும் எந்த சி இயக்க நேரத்திலும் வரையறுக்கப்படுகிறது.
    // விஎஸ் 2013 இல், இந்த சோதனை இணைக்கப்படும்போது தோல்வியுற்றதால் இந்த செயல்பாடு ஒரு பிழையைக் கொண்டிருந்தது, ஆனால் விஎஸ் 2015 உடன் சோதனை சரியாக இயங்குவதால் பிழை சரி செய்யப்பட்டது.
    //
    // பிழை `exp2(-1057)` இன் வருவாய் மதிப்பில் வித்தியாசமாகத் தெரிகிறது, அங்கு VS 2013 இல் இது பிட் முறை 0x2 உடன் இரட்டிப்பைத் தருகிறது மற்றும் VS 2015 இல் இது 0x20000 ஐ வழங்குகிறது.
    //
    //
    // இப்போது இந்த சோதனையை எம்.எஸ்.வி.சியில் முற்றிலும் புறக்கணிக்கவும், அது வேறு எங்கும் சோதிக்கப்பட்டதால், ஒவ்வொரு தளத்தின் exp2 செயல்படுத்தலையும் சோதிப்பதில் எங்களுக்கு அதிக ஆர்வம் இல்லை.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}