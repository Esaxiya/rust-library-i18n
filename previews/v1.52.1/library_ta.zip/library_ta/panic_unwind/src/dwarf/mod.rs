//! DWARF-குறியிடப்பட்ட தரவு ஸ்ட்ரீம்களை பாகுபடுத்துவதற்கான பயன்பாடுகள்.
//! <http://www.dwarfstd.org>, DWARF-4 தரநிலை, பிரிவு 7, "Data Representation" ஐப் பார்க்கவும்
//!

// இந்த தொகுதி இப்போது x86_64-pc-windows-gnu ஆல் மட்டுமே பயன்படுத்தப்படுகிறது, ஆனால் பின்னடைவுகளைத் தவிர்க்க எல்லா இடங்களிலும் இதைத் தொகுத்து வருகிறோம்.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF நீரோடைகள் நிரம்பியுள்ளன, எனவே எ.கா., ஒரு u32 4-பைட் எல்லையில் சீரமைக்கப்படாது.
    // இது கடுமையான சீரமைப்பு தேவைகளைக் கொண்ட தளங்களில் சிக்கல்களை ஏற்படுத்தக்கூடும்.
    // "packed" struct இல் தரவை மடக்குவதன் மூலம், "misalignment-safe" குறியீட்டை உருவாக்க பின்தளத்தில் சொல்கிறோம்.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 மற்றும் SLEB128 குறியாக்கங்கள் பிரிவு 7.6, "Variable Length Data" இல் வரையறுக்கப்பட்டுள்ளன.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}