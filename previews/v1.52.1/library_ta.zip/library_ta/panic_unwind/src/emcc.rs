//! *Emscripten* இலக்குக்கு விலக்குதல்.
//!
//! Unix இயங்குதளங்களுக்கான Rust இன் வழக்கமான அறியப்படாத செயலாக்கம் நேரடியாக லிபன்விண்ட் ஏபிஐகளுக்கு அழைக்கிறது, எம்ஸ்கிரிப்டனில் நாம் அதற்கு பதிலாக சி ++ பிரிக்காத ஏபிஐகளுக்கு அழைக்கிறோம்.
//! எம்ஸ்கிரிப்டனின் இயக்க நேரம் எப்போதும் அந்த ஏபிஐகளை செயல்படுத்துகிறது மற்றும் லிபன்விண்டை செயல்படுத்தாது என்பதால் இது ஒரு பயணமாகும்.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// இது C++ இல் std::type_info இன் தளவமைப்புடன் பொருந்துகிறது
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // இங்குள்ள முன்னணி `\x01` பைட் உண்மையில் எல்.எல்.வி.எம்-க்கு ஒரு மந்திர சமிக்ஞையாகும், இது `_` எழுத்துடன் முன்னொட்டு போன்ற வேறு எந்த மங்கலையும் பயன்படுத்தக்கூடாது.
    //
    //
    // இந்த சின்னம் C++ இன் `std::type_info` ஆல் பயன்படுத்தப்படும் vtable ஆகும்.
    // வகை `std::type_info` இன் பொருள்கள், வகை விளக்கங்கள், இந்த அட்டவணைக்கு ஒரு சுட்டிக்காட்டி உள்ளன.
    // வகை விளக்கங்கள் மேலே வரையறுக்கப்பட்ட C++ EH கட்டமைப்புகளால் குறிப்பிடப்படுகின்றன, மேலும் நாங்கள் கீழே கட்டமைக்கிறோம்.
    //
    // உண்மையான அளவு 3 பயன்பாட்டை விட பெரியது என்பதை நினைவில் கொள்க, ஆனால் மூன்றாவது உறுப்பை சுட்டிக்காட்டுவதற்கு எங்கள் vtable மட்டுமே தேவை.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info ஒரு துரு_பனிக் வகுப்பிற்கு
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // பொதுவாக நாம் .as_ptr().add(2) ஐப் பயன்படுத்துவோம், ஆனால் இது ஒரு நிலையான சூழலில் இயங்காது.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // இது வேண்டுமென்றே சாதாரண பெயர் மாங்லிங் திட்டத்தைப் பயன்படுத்தாது, ஏனெனில் C++ ஆனது Rust panics ஐ உருவாக்கவோ அல்லது பிடிக்கவோ விரும்பவில்லை.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // இது அவசியம், ஏனென்றால் சி ++ குறியீடு எங்கள் மரணதண்டனை std::exception_ptr உடன் கைப்பற்றி பல முறை மறுபரிசீலனை செய்யலாம், ஒருவேளை மற்றொரு நூலில் கூட இருக்கலாம்.
    //
    //
    caught: AtomicBool,

    // இது ஒரு விருப்பமாக இருக்க வேண்டும், ஏனெனில் பொருளின் வாழ்நாள் சி ++ சொற்பொருளைப் பின்பற்றுகிறது: கேட்ச்_அன்விண்ட் பெட்டியை விதிவிலக்குக்கு வெளியே நகர்த்தும்போது, அது விதிவிலக்கு பொருளை இன்னும் சரியான நிலையில் விட்டுவிட வேண்டும், ஏனெனில் அதன் அழிப்பான் இன்னும் __cxa_end_catch ஆல் அழைக்கப்பட உள்ளது.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try உண்மையில் இந்த கட்டமைப்பிற்கு ஒரு சுட்டிக்காட்டி தருகிறது.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // cleanup() panic க்கு அனுமதிக்கப்படாததால், அதற்கு பதிலாக நாங்கள் நிறுத்துகிறோம்.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}