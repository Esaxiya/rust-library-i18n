//! ஸ்டாக் பிரித்தல் வழியாக panics ஐ செயல்படுத்துதல்
//!
//! இந்த crate என்பது Rust இல் panics இன் செயல்பாடாகும், இது தொகுக்கப்பட்டுள்ள தளத்தின் "most native" ஸ்டாக் பிரிக்காத பொறிமுறையைப் பயன்படுத்துகிறது.
//! இது தற்போது மூன்று வாளிகளாக வகைப்படுத்தப்படுகிறது:
//!
//! 1. MSVC இலக்குகள் `seh.rs` கோப்பில் SEH ஐப் பயன்படுத்துகின்றன.
//! 2. `emcc.rs` கோப்பில் சி ++ விதிவிலக்குகளை எம்ஸ்கிரிப்டன் பயன்படுத்துகிறது.
//! 3. மற்ற எல்லா இலக்குகளும் `gcc.rs` கோப்பில் libunwind/libgcc ஐப் பயன்படுத்துகின்றன.
//!
//! ஒவ்வொரு செயலாக்கத்தையும் பற்றிய கூடுதல் ஆவணங்களை அந்தந்த தொகுதியில் காணலாம்.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` மிரியுடன் பயன்படுத்தப்படவில்லை, எனவே ம silence ன எச்சரிக்கைகள்.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust இயக்க நேரத்தின் தொடக்க பொருள்கள் இந்த சின்னங்களை சார்ந்துள்ளது, எனவே அவற்றை பொதுவில் வைக்கவும்.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // பிரிப்பதை ஆதரிக்காத இலக்குகள்.
        // - arch=wasm32
        // - os=எதுவுமில்லை ("bare metal" இலக்குகள்)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // மிரி இயக்க நேரத்தைப் பயன்படுத்தவும்.
        // மேலே உள்ள இயல்பான இயக்க நேரத்தையும் நாம் இன்னும் ஏற்ற வேண்டும், ஏனெனில் rustc அங்கிருந்து சில லாங் உருப்படிகள் வரையறுக்கப்படும் என்று எதிர்பார்க்கிறது.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // உண்மையான இயக்க நேரத்தைப் பயன்படுத்தவும்.
        use real_imp as imp;
    }
}

extern "C" {
    /// `catch_unwind` க்கு வெளியே ஒரு panic பொருள் கைவிடப்படும் போது libstd இல் கையாளுபவர் அழைக்கப்படுகிறார்.
    ///
    fn __rust_drop_panic() -> !;

    /// வெளிநாட்டு விதிவிலக்கு பிடிபடும் போது libstd இல் கையாளுபவர் அழைக்கப்படுகிறார்.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// விதிவிலக்கை உயர்த்துவதற்கான நுழைவு புள்ளி, மேடையில் குறிப்பிட்ட செயல்படுத்தலுக்கு பிரதிநிதிகள்.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}