//! மிரிக்கு panics ஐ நீக்குதல்.
use alloc::boxed::Box;
use core::any::Any;

// மிரி இயந்திரம் நமக்குத் தெரியாமலேயே பரப்புகின்ற பேலோட் வகை.
// சுட்டிக்காட்டி அளவிலானதாக இருக்க வேண்டும்.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// பிரிக்கத் தொடங்க மிரி வழங்கிய வெளிப்புற செயல்பாடு.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // `miri_start_panic` க்கு நாம் அனுப்பும் பேலோட் கீழே உள்ள `cleanup` இல் நாம் பெறும் வாதமாக இருக்கும்.
    // எனவே சுட்டிக்காட்டி அளவிலான ஒன்றைப் பெற அதை ஒரு முறை பெட்டியில் வைக்கிறோம்.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // அடிப்படை `Box` ஐ மீட்டெடுக்கவும்.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}