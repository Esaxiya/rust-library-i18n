//! libgcc/libunwind (சில வடிவத்தில்) ஆதரவுடன் panics ஐ செயல்படுத்துதல்.
//!
//! விதிவிலக்கு கையாளுதல் மற்றும் அடுக்கு பிரித்தல் பற்றிய பின்னணிக்கு தயவுசெய்து "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) மற்றும் அதிலிருந்து இணைக்கப்பட்ட ஆவணங்களைப் பார்க்கவும்.
//! இவை நல்ல வாசிப்புகள்:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## ஒரு சுருக்கமான சுருக்கம்
//!
//! விதிவிலக்கு கையாளுதல் இரண்டு கட்டங்களாக நடக்கிறது: ஒரு தேடல் கட்டம் மற்றும் தூய்மைப்படுத்தும் கட்டம்.
//!
//! இரண்டு கட்டங்களிலும், அடுக்கு, தற்போதைய செயல்முறையின் தொகுதிகளின் பிரிவுகளைப் பிரித்து, ஸ்டேக் பிரேமிலிருந்து தகவல்களைப் பயன்படுத்தி மேலிருந்து கீழாக ஸ்டேக் பிரேம்களை நடத்துகிறது (இங்கே "module" என்பது ஒரு OS தொகுதி, அதாவது, இயங்கக்கூடிய அல்லது டைனமிக் நூலகத்தைக் குறிக்கிறது).
//!
//!
//! ஒவ்வொரு ஸ்டேக் ஃபிரேமுக்கும், இது தொடர்புடைய "personality routine" ஐ அழைக்கிறது, அதன் முகவரி பிரிக்கப்படாத தகவல் பிரிவில் சேமிக்கப்படுகிறது.
//!
//! தேடல் கட்டத்தில், ஒரு ஆளுமை வழக்கத்தின் வேலை, விதிவிலக்கு பொருள் எறியப்படுவதை ஆராய்வதும், அந்த ஸ்டேக் சட்டகத்தில் பிடிக்கப்பட வேண்டுமா என்பதை தீர்மானிப்பதும் ஆகும்.கையாளுதல் சட்டகம் அடையாளம் காணப்பட்டவுடன், தூய்மைப்படுத்தும் கட்டம் தொடங்குகிறது.
//!
//! தூய்மைப்படுத்தும் கட்டத்தில், அவிழ்ப்பவர் ஒவ்வொரு ஆளுமை வழக்கத்தையும் மீண்டும் அழைக்கிறார்.
//! தற்போதைய ஸ்டேக் ஃபிரேமுக்கு எந்த (ஏதேனும் இருந்தால்) தூய்மைப்படுத்தும் குறியீட்டை இயக்க வேண்டும் என்பதை இது தீர்மானிக்கிறது.அப்படியானால், கட்டுப்பாடு செயல்பாட்டு உடலில் உள்ள ஒரு சிறப்பு branch க்கு மாற்றப்படுகிறது, இது "landing pad", இது அழிப்பவர்களை அழைக்கிறது, நினைவகத்தை விடுவிக்கிறது.
//! லேண்டிங் பேட்டின் முடிவில், கட்டுப்பாடு மீண்டும் அறியப்படாத மற்றும் அறியப்படாத பயோடேட்டாக்களுக்கு மாற்றப்படுகிறது.
//!
//! ஹேக்லர் ஃபிரேம் நிலைக்கு ஸ்டேக் குறைக்கப்படாதவுடன், பிரிக்கப்படாத நிறுத்தங்கள் மற்றும் கடைசி ஆளுமை வழக்கமானது கட்டுப்பாட்டைப் பிடிக்கும் தொகுதிக்கு மாற்றுகிறது.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust இன் விதிவிலக்கு வகுப்பு அடையாளங்காட்டி.
// விதிவிலக்கு அவர்களின் சொந்த இயக்க நேரத்தால் வீசப்பட்டதா என்பதை தீர்மானிக்க ஆளுமை நடைமுறைகளால் இது பயன்படுத்தப்படுகிறது.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-விற்பனையாளர், மொழி
    0x4d4f5a_00_52555354
}

// ஒவ்வொரு கட்டமைப்பிற்கும் LLVM இன் TargetLowering::getExceptionPointerRegister() மற்றும் TargetLowering::getExceptionSelectorRegister() இலிருந்து பதிவு ஐடிகள் உயர்த்தப்பட்டன, பின்னர் பதிவு வரையறை அட்டவணைகள் வழியாக DWARF பதிவு எண்களுக்கு மாற்றப்பட்டன (பொதுவாக<arch>RegisterInfo.td, "DwarfRegNum" ஐத் தேடுங்கள்).
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register ஐயும் காண்க.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// பின்வரும் குறியீடு GCC இன் சி மற்றும் சி ++ ஆளுமை நடைமுறைகளை அடிப்படையாகக் கொண்டது.குறிப்புக்கு, காண்க:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI ஆளுமை வழக்கம்.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS அதற்கு பதிலாக இயல்புநிலை வழக்கத்தை பயன்படுத்துகிறது, ஏனெனில் இது எஸ்.ஜே.எல்.ஜே.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM இல் உள்ள பின்னணிகள் ஆளுமை வழக்கத்தை நிலை==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // அந்த சந்தர்ப்பங்களில், அடுக்கைத் துண்டிக்கத் தொடர விரும்புகிறோம், இல்லையெனில் எங்கள் பின்னணிகள் அனைத்தும் __rust_try இல் முடிவடையும்
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // _Unwind_Context செயல்பாடு மற்றும் எல்.எஸ்.டி.ஏ சுட்டிகள் போன்றவற்றை வைத்திருப்பதாக DWARF அறியப்படாதது கருதுகிறது, இருப்பினும் ARM EHABI அவற்றை விதிவிலக்கு பொருளில் வைக்கிறது.
            // சூழல் சுட்டிக்காட்டி மட்டுமே எடுக்கும் _Unwind_GetLanguageSpecificData() போன்ற செயல்பாடுகளின் கையொப்பங்களைப் பாதுகாக்க, GCC ஆளுமை நடைமுறைகள் ARM இன் "scratch register" (r12) க்கு ஒதுக்கப்பட்ட இருப்பிடத்தைப் பயன்படுத்தி, சூழலில் விதிவிலக்கு_ஆப்ஜெக்டுக்கு ஒரு சுட்டிக்காட்டி வைக்கின்றன.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... எங்கள் கொள்கை ரீதியான பிணைப்புகளில் ARM இன் _Unwind_Context இன் முழு வரையறையை வழங்குவதும், தேவையான தரவை அங்கிருந்து நேரடியாகப் பெறுவதும், DWARF பொருந்தக்கூடிய செயல்பாடுகளைத் தவிர்ப்பதும் இன்னும் கொள்கை ரீதியான அணுகுமுறையாகும்.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // விதிவிலக்கு பொருளின் தடுப்பு தற்காலிக சேமிப்பில் SP மதிப்பை புதுப்பிக்க EHABI க்கு ஆளுமை வழக்கம் தேவைப்படுகிறது.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // ARM EHABI இல், திரும்புவதற்கு முன் ஒரு ஸ்டேக் சட்டகத்தை அவிழ்ப்பதற்கு ஆளுமை வழக்கம் பொறுப்பு (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc இல் வரையறுக்கப்பட்டுள்ளது
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // இயல்புநிலை ஆளுமை வழக்கம், இது பெரும்பாலான இலக்குகளில் நேரடியாகவும், மறைமுகமாக Windows x86_64 இல் SEH வழியாகவும் பயன்படுத்தப்படுகிறது.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW இலக்குகளில், பிரிக்கப்படாத வழிமுறை SEH ஆகும், இருப்பினும் பிரிக்கப்படாத கையாளுதல் தரவு (aka LSDA) GCC-இணக்கமான குறியாக்கத்தைப் பயன்படுத்துகிறது.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // எங்கள் பெரும்பாலான இலக்குகளுக்கான ஆளுமை வழக்கம்.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // எல்.எஸ்.டி.ஏ வரம்பு அட்டவணையில் அடுத்த ஐபி வரம்பில் இருக்கக்கூடிய அழைப்பு அறிவுறுத்தலைக் கடந்த 1 பைட் திரும்பும் முகவரி.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// ஃபிரேம் பிரிக்காத தகவல் பதிவு
//
// ஒவ்வொரு தொகுதியின் படத்திலும் ஒரு பிரேம் பிரிக்காத தகவல் பிரிவு உள்ளது (பொதுவாக ".eh_frame").ஒரு தொகுதி செயல்பாட்டில் loaded/unloaded ஆக இருக்கும்போது, நினைவகத்தில் இந்த பிரிவின் இருப்பிடம் பற்றி அறிவிக்கப்பட வேண்டும்.அதை அடைவதற்கான முறைகள் மேடையில் வேறுபடுகின்றன.
// சிலவற்றில் (எ.கா., Linux), பிரிக்கப்படாத தகவல் பிரிவுகளை அதன் சொந்தமாகக் கண்டறியலாம் (தற்போது ஏற்றப்பட்ட தொகுதிக்கூறுகளை dl_iterate_phdr() API and finding their ".eh_frame" sections) வழியாக மாறும் வகையில் கணக்கிடுவதன் மூலம்; Windows போன்ற மற்றவர்களுக்கு, அவிழ்த்துவிடும் தகவல் பிரிவுகளை சுறுசுறுப்பான API வழியாக தீவிரமாக பதிவு செய்ய தொகுதிகள் தேவைப்படுகின்றன.
//
//
// இந்த தொகுதி GCC இயக்க நேரத்துடன் எங்கள் தகவல்களை பதிவு செய்ய rsbegin.rs இலிருந்து குறிப்பிடப்பட்ட மற்றும் அழைக்கப்படும் இரண்டு சின்னங்களை வரையறுக்கிறது.
// ஸ்டாக் பிரிவைச் செயல்படுத்துவது (இப்போதைக்கு) libgcc_eh க்கு ஒத்திவைக்கப்பட்டுள்ளது, இருப்பினும் Rust crates இந்த Rust-குறிப்பிட்ட நுழைவு புள்ளிகளைப் பயன்படுத்தி எந்த GCC இயக்க நேரத்திலும் சாத்தியமான மோதல்களைத் தவிர்க்கிறது.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}