//! செயல்முறை நிறுத்தங்கள் வழியாக Rust panics ஐ செயல்படுத்துதல்
//!
//! பிரித்தெடுப்பதன் மூலம் செயல்படுத்தலுடன் ஒப்பிடும்போது, இந்த crate *மிகவும்* எளிமையானது!சொல்லப்பட்டால், இது மிகவும் பல்துறை அல்ல, ஆனால் இங்கே செல்கிறது!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" கேள்விக்குரிய மேடையில் தொடர்புடைய கருக்கலைப்புக்கு பேலோட் மற்றும் ஷிம்.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal ஐ அழைக்கவும்
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows இல், செயலி-குறிப்பிட்ட __fastfail பொறிமுறையைப் பயன்படுத்தவும்.Windows 8 மற்றும் அதற்குப் பிறகு, இது எந்தவொரு செயல்முறை விதிவிலக்கு கையாளுபவர்களையும் இயக்காமல் உடனடியாக செயல்முறையை நிறுத்திவிடும்.
            // Windows இன் முந்தைய பதிப்புகளில், இந்த வரிசை அறிவுறுத்தல்கள் அணுகல் மீறலாகக் கருதப்படும், இது செயல்முறையை நிறுத்துகிறது, ஆனால் எல்லா விதிவிலக்கு கையாளுபவர்களையும் தவிர்க்காமல்.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: இது libstd இன் `abort_internal` இல் உள்ள அதே செயல்பாடாகும்
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// இது ... கொஞ்சம் வித்தியாசமானது.த tl; dr;சரியாக இணைக்க இது தேவைப்படுகிறது, நீண்ட விளக்கம் கீழே உள்ளது.
//
// இப்போது நாம் அனுப்பும் libcore/libstd இன் பைனரிகள் அனைத்தும் `-C panic=unwind` உடன் தொகுக்கப்பட்டுள்ளன.இருமங்கள் முடிந்தவரை பல சூழ்நிலைகளுடன் இணக்கமாக இருப்பதை உறுதி செய்வதற்காக இது செய்யப்படுகிறது.
// இருப்பினும், கம்பைலருக்கு `-C panic=unwind` உடன் தொகுக்கப்பட்ட அனைத்து செயல்பாடுகளுக்கும் "personality function" தேவைப்படுகிறது.இந்த ஆளுமை செயல்பாடு `rust_eh_personality` சின்னத்திற்கு ஹார்ட்கோட் செய்யப்பட்டுள்ளது மற்றும் இது `eh_personality` லாங் உருப்படியால் வரையறுக்கப்படுகிறது.
//
// So...
// ஏன் அந்த லாங் உருப்படியை இங்கே வரையறுக்கக்கூடாது?நல்ல கேள்வி!panic இயக்க நேரங்கள் இணைக்கப்பட்டுள்ள விதம் உண்மையில் ஒரு சிறிய நுட்பமானது, அவை தொகுப்பாளரின் crate கடையில் "sort of" ஆக இருக்கின்றன, ஆனால் உண்மையில் உண்மையில் இணைக்கப்படவில்லை என்றால் மட்டுமே இணைக்கப்பட்டுள்ளது.
//
// இந்த crate மற்றும் panic_unwind crate இரண்டும் கம்பைலரின் crate கடையில் தோன்றக்கூடும் என்பதோடு, `eh_personality` lang உருப்படியை இரண்டுமே வரையறுத்தால் அது ஒரு பிழையைத் தாக்கும்.
//
// இதைக் கையாள, panic இயக்க நேரம் இணைக்கப்படாத இயக்க நேரமாக இருந்தால் மட்டுமே கம்பைலருக்கு `eh_personality` வரையறுக்கப்பட வேண்டும், இல்லையெனில் அதை வரையறுக்க தேவையில்லை (சரியாக).
// இருப்பினும், இந்த விஷயத்தில், இந்த நூலகம் இந்த சின்னத்தை வரையறுக்கிறது, எனவே எங்காவது குறைந்தது சில ஆளுமை உள்ளது.
//
// அடிப்படையில் இந்த சின்னம் libcore/libstd பைனரிகள் வரை கம்பி பெற வரையறுக்கப்பட்டுள்ளது, ஆனால் நாம் ஒருபோதும் அறியப்படாத இயக்க நேரத்தில் இணைக்காததால் இதை ஒருபோதும் அழைக்கக்கூடாது.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-windows-gnu இல், நாங்கள் எங்கள் சொந்த ஆளுமை செயல்பாட்டைப் பயன்படுத்துகிறோம், இது எங்கள் எல்லா பிரேம்களையும் கடந்து செல்லும்போது `ExceptionContinueSearch` ஐ திருப்பித் தர வேண்டும்.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // மேலே உள்ளதைப் போலவே, இது தற்போது எம்ஸ்கிரிப்டனில் மட்டுமே பயன்படுத்தப்படும் `eh_catch_typeinfo` லாங் உருப்படிக்கு ஒத்திருக்கிறது.
    //
    // panics விதிவிலக்குகளை உருவாக்கவில்லை என்பதால், வெளிநாட்டு விதிவிலக்குகள் தற்போது -C panic=abort உடன் UB ஆக உள்ளன (இது மாற்றத்திற்கு உட்பட்டது என்றாலும்), எந்த catch_unwind அழைப்புகளும் இந்த டைப் இன்ஃபோவை ஒருபோதும் பயன்படுத்தாது.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // இந்த இரண்டையும் i686-pc-windows-gnu இல் உள்ள எங்கள் தொடக்க பொருள்களால் அழைக்கப்படுகின்றன, ஆனால் அவை எதுவும் செய்யத் தேவையில்லை, எனவே உடல்கள் முதலிடத்தில் உள்ளன.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}