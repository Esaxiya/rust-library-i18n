//! புதிய மேக்ரோக்களை வரையறுக்கும்போது மேக்ரோ ஆசிரியர்களுக்கான ஆதரவு நூலகம்.
//!
//! நிலையான விநியோகத்தால் வழங்கப்பட்ட இந்த நூலகம், செயல்பாட்டு ரீதியாக வரையறுக்கப்பட்ட மேக்ரோ வரையறைகளின் இடைமுகங்களில் நுகரப்படும் வகைகளை வழங்குகிறது, அதாவது செயல்பாடு போன்ற மேக்ரோக்கள் `#[proc_macro]`, மேக்ரோ பண்புக்கூறுகள் `#[proc_macro_attribute]` மற்றும் தனிப்பயன் பெறப்பட்ட பண்புக்கூறுகள்`#[proc_macro_derive]`.
//!
//!
//! மேலும் அறிய [the book] ஐப் பார்க்கவும்.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// தற்போது இயங்கும் நிரலுக்கு proc_macro அணுக முடியுமா என்பதை தீர்மானிக்கிறது.
///
/// Proc_macro crate என்பது நடைமுறை மேக்ரோக்களை செயல்படுத்துவதற்குள் மட்டுமே பயன்படுத்தப்படுகிறது.இந்த crate panic இல் உள்ள அனைத்து செயல்பாடுகளும் ஒரு நடைமுறை மேக்ரோவுக்கு வெளியே இருந்து பயன்படுத்தப்பட்டால், அதாவது பில்ட் ஸ்கிரிப்ட் அல்லது யூனிட் டெஸ்ட் அல்லது சாதாரண Rust பைனரி போன்றவை.
///
/// மேக்ரோ மற்றும் மேக்ரோ அல்லாத பயன்பாட்டு நிகழ்வுகளை ஆதரிக்க வடிவமைக்கப்பட்ட Rust நூலகங்களைக் கருத்தில் கொண்டு, proc_macro இன் API ஐப் பயன்படுத்தத் தேவையான உள்கட்டமைப்பு தற்போது கிடைக்கிறதா என்பதைக் கண்டறிய `proc_macro::is_available()` ஒரு பீதியற்ற வழியை வழங்குகிறது.
/// ஒரு நடைமுறை மேக்ரோவின் உள்ளே இருந்து பயன்படுத்தப்பட்டால் உண்மை, வேறு எந்த பைனரியிலிருந்தும் பயன்படுத்தப்பட்டால் தவறானது.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// இந்த crate ஆல் வழங்கப்பட்ட முக்கிய வகை, tokens இன் சுருக்க ஸ்ட்ரீமை குறிக்கிறது, அல்லது, குறிப்பாக, token மரங்களின் வரிசையாகும்.
/// அந்த வகை அந்த token மரங்களின் மீது மீண்டும் செயல்படுவதற்கான இடைமுகங்களை வழங்குகிறது, மாறாக, பல token மரங்களை ஒரே ஸ்ட்ரீமில் சேகரிக்கிறது.
///
///
/// இது `#[proc_macro]`, `#[proc_macro_attribute]` மற்றும் `#[proc_macro_derive]` வரையறைகளின் உள்ளீடு மற்றும் வெளியீடு ஆகும்.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` இலிருந்து பிழை திரும்பியது.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token மரங்கள் இல்லாத வெற்று `TokenStream` ஐ வழங்குகிறது.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// இந்த `TokenStream` காலியாக இருந்தால் சரிபார்க்கிறது.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// சரத்தை tokens ஆக உடைத்து, அந்த tokens ஐ token ஸ்ட்ரீமில் அலச முயற்சிக்கிறது.
/// பல காரணங்களுக்காக தோல்வியடையக்கூடும், எடுத்துக்காட்டாக, சரம் சமநிலையற்ற டிலிமிட்டர்கள் அல்லது மொழியில் இல்லாத எழுத்துக்கள் இருந்தால்.
///
/// பாகுபடுத்தப்பட்ட ஸ்ட்ரீமில் உள்ள அனைத்து tokens க்கும் `Span::call_site()` ஸ்பான்ஸ் கிடைக்கும்.
///
/// NOTE: சில பிழைகள் `LexError` ஐ திருப்புவதற்கு பதிலாக panics ஐ ஏற்படுத்தக்கூடும்.இந்த பிழைகளை பின்னர் `லெக்ஸ் எர்ரராக 'மாற்றுவதற்கான உரிமையை நாங்கள் வைத்திருக்கிறோம்.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, பாலம் `to_string` ஐ மட்டுமே வழங்குகிறது, அதன் அடிப்படையில் `fmt::Display` ஐ செயல்படுத்துகிறது (இருவருக்கும் இடையிலான வழக்கமான உறவின் தலைகீழ்).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token ஸ்ட்ரீமை ஒரு சரம் என அச்சிடுகிறது, இது இழப்பு இல்லாமல் மீண்டும் அதே token ஸ்ட்ரீமுக்கு (மட்டு ஸ்பான்ஸ்) மாற்றப்படும், தவிர `00 டோக்கன் ட்ரீ: : X`X `Delimiter::None` டிலிமிட்டர்கள் மற்றும் எதிர்மறை எண் எழுத்தர்களுடன்.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// பிழைத்திருத்தத்திற்கு வசதியான வடிவத்தில் token ஐ அச்சிடுகிறது.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// ஒற்றை token மரத்தைக் கொண்ட token ஸ்ட்ரீமை உருவாக்குகிறது.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// ஒரே ஸ்ட்ரீமில் பல token மரங்களை சேகரிக்கிறது.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token ஸ்ட்ரீம்களில் ஒரு "flattening" செயல்பாடு, பல token ஸ்ட்ரீம்களிலிருந்து token மரங்களை ஒரே ஸ்ட்ரீமில் சேகரிக்கிறது.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) உகந்த செயல்படுத்தல் if/when ஐப் பயன்படுத்தவும்.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// ஐரேட்டர்கள் போன்ற `TokenStream` வகைக்கான பொது செயல்படுத்தல் விவரங்கள்.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `டோக்கன்ஸ்ட்ரீமின்`` டோக்கன் ட்ரீ'களில் ஒரு செயலாளர்.
    /// மறு செய்கை "shallow" ஆகும், எ.கா., ஈரேட்டர் பிரிக்கப்பட்ட குழுக்களாக மறுபரிசீலனை செய்யாது, மேலும் முழு குழுக்களையும் token மரங்களாக வழங்குகிறது.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` தன்னிச்சையான tokens ஐ ஏற்றுக்கொண்டு உள்ளீட்டை விவரிக்கும் `TokenStream` ஆக விரிவடைகிறது.
/// எடுத்துக்காட்டாக, `quote!(a + b)` ஒரு வெளிப்பாட்டை உருவாக்கும், இது மதிப்பீடு செய்யப்படும்போது, `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting என்பது `$` உடன் செய்யப்படுகிறது, மேலும் ஒற்றை அடுத்த அடையாளத்தை குறிப்பிடப்படாத காலமாக எடுத்துக்கொள்வதன் மூலம் செயல்படுகிறது.
/// `$` ஐ மேற்கோள் காட்ட, `$$` ஐப் பயன்படுத்தவும்.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// மேக்ரோ விரிவாக்கத் தகவலுடன் மூலக் குறியீட்டின் ஒரு பகுதி.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// கொடுக்கப்பட்ட `message` உடன் `self` இடைவெளியில் புதிய `Diagnostic` ஐ உருவாக்குகிறது.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// மேக்ரோ வரையறை தளத்தில் தீர்க்கும் ஒரு இடைவெளி.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// தற்போதைய நடைமுறை மேக்ரோவின் அழைப்பின் காலம்.
    /// இந்த இடைவெளியுடன் உருவாக்கப்பட்ட அடையாளங்காட்டிகள் மேக்ரோ அழைப்பு இருப்பிடத்தில் (அழைப்பு-தள சுகாதாரம்) நேரடியாக எழுதப்பட்டதைப் போல தீர்க்கப்படும், மேலும் மேக்ரோ அழைப்பு தளத்திலுள்ள பிற குறியீடுகளையும் அவற்றைக் குறிக்க முடியும்.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` சுகாதாரத்தை பிரதிநிதித்துவப்படுத்தும் ஒரு இடைவெளி, சில சமயங்களில் மேக்ரோ வரையறை தளத்திலும் (உள்ளூர் மாறிகள், லேபிள்கள், `$crate`) மற்றும் சில நேரங்களில் மேக்ரோ அழைப்பு தளத்திலும் (எல்லாவற்றையும்) தீர்க்கிறது.
    ///
    /// அழைப்பு தளத்திலிருந்து இடைவெளி இடம் எடுக்கப்பட்டது.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// இந்த இடைவெளி சுட்டிக்காட்டும் அசல் மூல கோப்பு.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// முந்தைய மேக்ரோ விரிவாக்கத்தில் tokens க்கான `Span`, அதில் இருந்து `self` உருவாக்கப்பட்டது.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` இலிருந்து உருவாக்கப்பட்ட மூல மூலக் குறியீட்டிற்கான இடைவெளி.
    /// இந்த `Span` மற்ற மேக்ரோ விரிவாக்கங்களிலிருந்து உருவாக்கப்படவில்லை என்றால், வருவாய் மதிப்பு `*self` ஐப் போன்றது.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// இந்த இடைவெளிக்கான மூல கோப்பில் தொடக்க line/column ஐப் பெறுகிறது.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// இந்த இடைவெளிக்கான மூல கோப்பில் முடிவடையும் line/column ஐப் பெறுகிறது.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` மற்றும் `other` ஐ உள்ளடக்கிய புதிய இடைவெளியை உருவாக்குகிறது.
    ///
    /// `self` மற்றும் `other` ஆகியவை வெவ்வேறு கோப்புகளிலிருந்து வந்தால் `None` ஐ வழங்குகிறது.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` போன்ற அதே line/column தகவலுடன் ஒரு புதிய இடைவெளியை உருவாக்குகிறது, ஆனால் இது `other` இல் இருந்ததைப் போலவே சின்னங்களையும் தீர்க்கிறது.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` போன்ற அதே பெயர் தீர்மானம் நடத்தை கொண்ட ஒரு புதிய இடைவெளியை உருவாக்குகிறது, ஆனால் `other` இன் line/column தகவலுடன்.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// அவை சமமாக இருக்கிறதா என்று பார்க்க ஸ்பான்களுடன் ஒப்பிடுகிறது.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// ஒரு இடைவெளியின் பின்னால் மூல உரையை வழங்குகிறது.
    /// இது இடைவெளிகள் மற்றும் கருத்துகள் உள்ளிட்ட அசல் மூலக் குறியீட்டைப் பாதுகாக்கிறது.
    /// உண்மையான மூலக் குறியீட்டிற்கு இடைவெளி ஒத்திருந்தால் மட்டுமே அது ஒரு முடிவைத் தரும்.
    ///
    /// Note: மேக்ரோவின் காணக்கூடிய முடிவு tokens ஐ மட்டுமே நம்பியிருக்க வேண்டும், ஆனால் இந்த மூல உரையில் அல்ல.
    ///
    /// இந்த செயல்பாட்டின் விளைவாக நோயறிதலுக்கு மட்டுமே பயன்படுத்த ஒரு சிறந்த முயற்சி.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// பிழைத்திருத்தத்திற்கு வசதியான வடிவத்தில் ஒரு இடைவெளியை அச்சிடுகிறது.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span` இன் தொடக்க அல்லது முடிவைக் குறிக்கும் வரி-நெடுவரிசை ஜோடி.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// (inclusive) ஐத் தொடங்கும் அல்லது முடிக்கும் மூலக் கோப்பில் 1-குறியீட்டு வரி.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// (inclusive) ஐத் தொடங்கும் அல்லது முடிக்கும் மூலக் கோப்பில் 0-குறியீட்டு நெடுவரிசை (UTF-8 எழுத்துகளில்).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// கொடுக்கப்பட்ட `Span` இன் மூல கோப்பு.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// இந்த மூலக் கோப்பிற்கான பாதையைப் பெறுகிறது.
    ///
    /// ### Note
    /// இந்த `SourceFile` உடன் தொடர்புடைய குறியீடு இடைவெளி வெளிப்புற மேக்ரோ, இந்த மேக்ரோவால் உருவாக்கப்பட்டது என்றால், இது கோப்பு முறைமையில் உண்மையான பாதையாக இருக்காது.
    /// சரிபார்க்க [`is_real`] ஐப் பயன்படுத்தவும்.
    ///
    /// `is_real` `true` ஐத் திருப்பினாலும், `--remap-path-prefix` கட்டளை வரியில் அனுப்பப்பட்டிருந்தால், கொடுக்கப்பட்ட பாதை உண்மையில் செல்லுபடியாகாது.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// இந்த மூல கோப்பு உண்மையான மூல கோப்பாக இருந்தால், வெளிப்புற மேக்ரோவின் விரிவாக்கத்தால் உருவாக்கப்படாவிட்டால் `true` ஐ வழங்குகிறது.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // இண்டர்கிரேட் ஸ்பான்ஸ் செயல்படுத்தப்படும் வரை இது ஒரு ஹேக் ஆகும், மேலும் வெளிப்புற மேக்ரோக்களில் உருவாக்கப்படும் ஸ்பான்களுக்கான உண்மையான மூல கோப்புகளை வைத்திருக்க முடியும்.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// ஒற்றை token அல்லது token மரங்களின் பிரிக்கப்பட்ட வரிசை (எ.கா., `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// அடைப்புக்குறி டிலிமிட்டர்களால் சூழப்பட்ட token ஸ்ட்ரீம்.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// ஒரு அடையாளங்காட்டி.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// ஒற்றை நிறுத்தற்குறி எழுத்து (`+`, `,`, `$`, முதலியன).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// (`'a'`), சரம் (`"hello"`), எண் (`2.3`), முதலியன.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// இந்த மரத்தின் இடைவெளியை வழங்குகிறது, இதில் உள்ள token அல்லது பிரிக்கப்பட்ட ஸ்ட்ரீமின் `span` முறைக்கு வழங்கப்படுகிறது.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *இந்த token* க்கு மட்டுமே இடைவெளியை உள்ளமைக்கிறது.
    ///
    /// இந்த token ஒரு `Group` ஆக இருந்தால், இந்த முறை ஒவ்வொரு உள் tokens இன் இடைவெளியை உள்ளமைக்காது என்பதை நினைவில் கொள்க, இது ஒவ்வொரு மாறுபாட்டின் `set_span` முறைக்கும் வழங்கப்படும்.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// பிழைத்திருத்தத்திற்கு வசதியான வடிவத்தில் token மரத்தை அச்சிடுகிறது.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // இவை ஒவ்வொன்றும் பெறப்பட்ட பிழைத்திருத்தத்தில் உள்ள struct வகைகளில் பெயரைக் கொண்டுள்ளன, எனவே கூடுதல் திசைதிருப்பலைப் பற்றி கவலைப்பட வேண்டாம்
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, பாலம் `to_string` ஐ மட்டுமே வழங்குகிறது, அதன் அடிப்படையில் `fmt::Display` ஐ செயல்படுத்துகிறது (இருவருக்கும் இடையிலான வழக்கமான உறவின் தலைகீழ்).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token மரத்தை ஒரு சரம் போல அச்சிடுகிறது, இது இழப்பு இல்லாமல் மீண்டும் அதே token மரமாக (மாடுலோ ஸ்பான்ஸ்) மாற்றப்படலாம், `Delimiter::None` டிலிமிட்டர்கள் மற்றும் எதிர்மறை எண் எழுத்தர்களுடன் `டோக்கன் ட்ரீ: : குழு` தவிர.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// பிரிக்கப்பட்ட token ஸ்ட்ரீம்.
///
/// ஒரு `Group` உள்நாட்டில் ஒரு `TokenStream` ஐ கொண்டுள்ளது, இது `டிலிமிட்டரால் சூழப்பட்டுள்ளது.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token மரங்களின் வரிசை எவ்வாறு பிரிக்கப்பட்டுள்ளது என்பதை விவரிக்கிறது.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// ஒரு உள்ளார்ந்த டிலிமிட்டர், எடுத்துக்காட்டாக, "macro variable" `$var` இலிருந்து வரும் tokens ஐச் சுற்றி தோன்றக்கூடும்.
    /// `$var` `1 + 2` இருக்கும் `$var * 3` போன்ற நிகழ்வுகளில் ஆபரேட்டர் முன்னுரிமைகளைப் பாதுகாப்பது முக்கியம்.
    /// மறைமுகமான டிலிமிட்டர்கள் ஒரு சரம் மூலம் token ஸ்ட்ரீமின் ரவுண்ட்டிரிப்பைத் தக்கவைக்கக்கூடாது.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// கொடுக்கப்பட்ட டிலிமிட்டர் மற்றும் token ஸ்ட்ரீமுடன் புதிய `Group` ஐ உருவாக்குகிறது.
    ///
    /// இந்த கட்டமைப்பாளருக்கு இந்த குழுவிற்கான இடைவெளியை `Span::call_site()` ஆக அமைக்கும்.
    /// இடைவெளியை மாற்ற நீங்கள் கீழே உள்ள `set_span` முறையைப் பயன்படுத்தலாம்.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// இந்த `Group` இன் டிலிமிட்டரை வழங்குகிறது
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// இந்த `Group` இல் பிரிக்கப்பட்ட tokens இன் `TokenStream` ஐ வழங்குகிறது.
    ///
    /// திரும்பிய token ஸ்ட்ரீமில் மேலே திரும்பிய டிலிமிட்டர் இல்லை என்பதை நினைவில் கொள்க.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// இந்த token ஸ்ட்ரீமின் டிலிமிட்டர்களுக்கான ஸ்பானை வழங்குகிறது, இது முழு `Group` க்கும் பரவுகிறது.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// இந்த குழுவின் தொடக்க டிலிமிட்டரை சுட்டிக்காட்டும் இடைவெளியை வழங்குகிறது.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// இந்த குழுவின் இறுதி டிலிமிட்டரை சுட்டிக்காட்டும் இடைவெளியை வழங்குகிறது.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// இந்த `குழுவின்` டிலிமிட்டர்களுக்கான இடைவெளியை உள்ளமைக்கிறது, ஆனால் அதன் உள் tokens அல்ல.
    ///
    /// இந்த முறை இந்த குழுவால் பரப்பப்பட்ட அனைத்து உள் tokens இன் இடைவெளியை ** அமைக்காது, மாறாக இது `Group` மட்டத்தில் tokens என்ற டிலிமிட்டரின் இடைவெளியை மட்டுமே அமைக்கும்.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, பாலம் `to_string` ஐ மட்டுமே வழங்குகிறது, அதன் அடிப்படையில் `fmt::Display` ஐ செயல்படுத்துகிறது (இருவருக்கும் இடையிலான வழக்கமான உறவின் தலைகீழ்).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// `Delimiter::None` டிலிமிட்டர்களுடன் `டோக்கன் ட்ரீ: : குரூப்` ஐத் தவிர, குழுவை ஒரு குழுவாக (மாடுலோ ஸ்பான்ஸ்) இழப்பின்றி மாற்றக்கூடிய ஒரு சரமாக அச்சிடுகிறது.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` என்பது `+`, `-` அல்லது `#` போன்ற ஒற்றை நிறுத்தற்குறி எழுத்து ஆகும்.
///
/// `+=` போன்ற மல்டி-கேரக்டர் ஆபரேட்டர்கள் `Punct` இன் இரண்டு நிகழ்வுகளாக குறிப்பிடப்படுகின்றன.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// ஒரு `Punct` ஐ மற்றொரு `Punct` உடனடியாகப் பின்தொடர்கிறதா அல்லது மற்றொரு token அல்லது இடைவெளியைப் பின்பற்றுகிறதா.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// எ.கா., `+` என்பது `+ =`, `+ident` அல்லது `+()` இல் `Alone` ஆகும்.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// எ.கா., `+` என்பது `+=` அல்லது `'#` இல் `Joint` ஆகும்.
    /// கூடுதலாக, ஒற்றை மேற்கோள் `'` அடையாளங்காட்டிகளுடன் இணைந்து வாழ்நாள் `'ident` ஐ உருவாக்கலாம்.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// கொடுக்கப்பட்ட எழுத்து மற்றும் இடைவெளியில் இருந்து புதிய `Punct` ஐ உருவாக்குகிறது.
    /// `ch` வாதம் மொழியால் அனுமதிக்கப்பட்ட செல்லுபடியாகும் நிறுத்தற்குறியாக இருக்க வேண்டும், இல்லையெனில் செயல்பாடு panic ஆக இருக்கும்.
    ///
    /// திரும்பிய `Punct` ஆனது `Span::call_site()` இன் இயல்புநிலை இடைவெளியைக் கொண்டிருக்கும், இது கீழே உள்ள `set_span` முறையுடன் மேலும் கட்டமைக்கப்படலாம்.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// இந்த நிறுத்தற்குறியின் மதிப்பை `char` ஆக வழங்குகிறது.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// இந்த நிறுத்தக்குறி எழுத்தின் இடைவெளியை வழங்குகிறது, இது உடனடியாக token ஸ்ட்ரீமில் மற்றொரு `Punct` ஐப் பின்பற்றுகிறதா என்பதைக் குறிக்கிறது, எனவே அவை பல-எழுத்து ஆபரேட்டர் (`Joint`) உடன் இணைக்கப்படலாம், அல்லது அதைத் தொடர்ந்து வேறு சில token அல்லது வைட்ஸ்பேஸ் (`Alone`) ஐப் பின்தொடர்கிறது, எனவே ஆபரேட்டர் நிச்சயமாக உள்ளது முடிந்தது.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// இந்த நிறுத்தற்குறி எழுத்துக்கான இடைவெளியை வழங்குகிறது.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// இந்த நிறுத்தற்குறி எழுத்துக்கான இடைவெளியை உள்ளமைக்கவும்.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, பாலம் `to_string` ஐ மட்டுமே வழங்குகிறது, அதன் அடிப்படையில் `fmt::Display` ஐ செயல்படுத்துகிறது (இருவருக்கும் இடையிலான வழக்கமான உறவின் தலைகீழ்).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// நிறுத்தற்குறியை ஒரு சரமாக அச்சிடுகிறது, அது இழப்பு இல்லாமல் மீண்டும் அதே எழுத்துக்குறி மாற்றப்பட வேண்டும்.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// ஒரு அடையாளங்காட்டி (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// கொடுக்கப்பட்ட `string` மற்றும் குறிப்பிட்ட `span` உடன் புதிய `Ident` ஐ உருவாக்குகிறது.
    /// `string` வாதம் மொழியால் அனுமதிக்கப்பட்ட செல்லுபடியாகும் அடையாளங்காட்டியாக இருக்க வேண்டும் (முக்கிய வார்த்தைகள் உட்பட, எ.கா. `self` அல்லது `fn`).இல்லையெனில், செயல்பாடு panic ஆக இருக்கும்.
    ///
    /// தற்போது rustc இல் உள்ள `span`, இந்த அடையாளங்காட்டிக்கான சுகாதார தகவலை உள்ளமைக்கிறது என்பதை நினைவில் கொள்க.
    ///
    /// இந்த நேரத்தில், `Span::call_site()` வெளிப்படையாக "call-site" சுகாதாரத்தை தேர்வுசெய்கிறது, அதாவது இந்த இடைவெளியுடன் உருவாக்கப்பட்ட அடையாளங்காட்டிகள் மேக்ரோ அழைப்பின் இருப்பிடத்தில் நேரடியாக எழுதப்பட்டவை போல் தீர்க்கப்படும், மேலும் மேக்ரோ அழைப்பு தளத்தில் உள்ள பிற குறியீடுகளை குறிப்பிட முடியும் அவர்களும்.
    ///
    ///
    /// `Span::def_site()` போன்ற பிற்கால இடைவெளிகள் "definition-site" சுகாதாரத்தைத் தேர்வுசெய்ய அனுமதிக்கும், அதாவது இந்த இடைவெளியுடன் உருவாக்கப்பட்ட அடையாளங்காட்டிகள் மேக்ரோ வரையறையின் இடத்தில் தீர்க்கப்படும் மற்றும் மேக்ரோ அழைப்பு தளத்தில் உள்ள பிற குறியீடு அவற்றைக் குறிப்பிட முடியாது.
    ///
    /// சுகாதாரத்தின் தற்போதைய முக்கியத்துவம் காரணமாக, இந்த கட்டமைப்பாளருக்கு, மற்ற tokens ஐப் போலன்றி, கட்டுமானத்தில் ஒரு `Span` குறிப்பிடப்பட வேண்டும்.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` போலவே, ஆனால் ஒரு மூல அடையாளங்காட்டி (`r#ident`) ஐ உருவாக்குகிறது.
    /// `string` வாதம் மொழியால் அனுமதிக்கப்பட்ட செல்லுபடியாகும் அடையாளங்காட்டியாக இருக்கும் (முக்கிய வார்த்தைகள் உட்பட, எ.கா. `fn`).
    /// பாதை பிரிவுகளில் பயன்படுத்தக்கூடிய முக்கிய வார்த்தைகள் (எ.கா.
    /// `self`, `சூப்பர்`) ஆதரிக்கப்படவில்லை, மேலும் இது panic ஐ ஏற்படுத்தும்.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// இந்த `Ident` இன் இடைவெளியை வழங்குகிறது, இது [`to_string`](Self::to_string) ஆல் வழங்கப்பட்ட முழு சரத்தையும் உள்ளடக்கியது.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// இந்த `Ident` இன் இடைவெளியை உள்ளமைக்கிறது, அதன் சுகாதார சூழலை மாற்றக்கூடும்.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, பாலம் `to_string` ஐ மட்டுமே வழங்குகிறது, அதன் அடிப்படையில் `fmt::Display` ஐ செயல்படுத்துகிறது (இருவருக்கும் இடையிலான வழக்கமான உறவின் தலைகீழ்).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// அடையாளங்காட்டியை ஒரு சரமாக அச்சிடுகிறது, அது இழப்பு இல்லாமல் மீண்டும் அதே அடையாளங்காட்டியாக மாற்றப்பட வேண்டும்.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// ஒரு நேரடி சரம் (`"hello"`), பைட் சரம் (`b"hello"`), எழுத்து (`'a'`), பைட் எழுத்து (`b'a'`), பின்னொட்டுடன் அல்லது இல்லாமல் ஒரு முழு எண் அல்லது மிதக்கும் புள்ளி எண் (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// `true` மற்றும் `false` போன்ற பூலியன் எழுத்தாளர்கள் இங்கு சேர்ந்தவர்கள் அல்ல, அவை `அடையாளங்கள் '.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// குறிப்பிட்ட மதிப்புடன் புதிய பின்னொட்டு முழு எண்ணை உருவாக்குகிறது.
        ///
        /// இந்த செயல்பாடு `1u32` போன்ற ஒரு முழு எண்ணை உருவாக்கும், அங்கு குறிப்பிடப்பட்ட முழு மதிப்பு token இன் முதல் பகுதியாகும், மேலும் ஒருங்கிணைப்பும் முடிவில் பின்னொட்டாக இருக்கும்.
        /// எதிர்மறை எண்களிலிருந்து உருவாக்கப்பட்ட எழுத்தாளர்கள் `TokenStream` அல்லது சரங்களின் வழியாக சுற்றுப் பயணங்களைத் தக்கவைக்காமல் போகலாம் மற்றும் அவை இரண்டு tokens (`-` மற்றும் நேர்மறை நேரடி) என உடைக்கப்படலாம்.
        ///
        ///
        /// இந்த முறையின் மூலம் உருவாக்கப்பட்ட எழுத்தாளர்கள் இயல்பாகவே `Span::call_site()` இடைவெளியைக் கொண்டுள்ளனர், அவை கீழே உள்ள `set_span` முறையுடன் கட்டமைக்கப்படலாம்.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// குறிப்பிட்ட மதிப்புடன் புதிய இணைக்கப்படாத முழு எண்ணை உருவாக்குகிறது.
        ///
        /// இந்த செயல்பாடு `1` போன்ற ஒரு முழு எண்ணை உருவாக்கும், அங்கு குறிப்பிடப்பட்ட முழு மதிப்பு token இன் முதல் பகுதியாகும்.
        /// இந்த token இல் எந்த பின்னொட்டும் குறிப்பிடப்படவில்லை, அதாவது `Literal::i8_unsuffixed(1)` போன்ற அழைப்புகள் `Literal::u32_unsuffixed(1)` க்கு சமமானவை.
        /// எதிர்மறை எண்களிலிருந்து உருவாக்கப்பட்ட எழுத்தாளர்கள் `TokenStream` அல்லது சரங்களின் மூலம் ரவுண்ட்ரிப்ஸைத் தக்கவைக்காமல் இருக்கலாம் மற்றும் இரண்டு tokens (`-` மற்றும் நேர்மறை நேரடி) ஆக உடைக்கப்படலாம்.
        ///
        ///
        /// இந்த முறையின் மூலம் உருவாக்கப்பட்ட எழுத்தாளர்கள் இயல்பாகவே `Span::call_site()` இடைவெளியைக் கொண்டுள்ளனர், அவை கீழே உள்ள `set_span` முறையுடன் கட்டமைக்கப்படலாம்.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// ஒரு புதிய இணைக்கப்படாத மிதக்கும் புள்ளியை உருவாக்குகிறது.
    ///
    /// இந்த கட்டமைப்பாளர் `Literal::i8_unsuffixed` போன்றதைப் போன்றது, அங்கு மிதவை மதிப்பு நேரடியாக token க்குள் வெளியேற்றப்படுகிறது, ஆனால் எந்த பின்னொட்டும் பயன்படுத்தப்படவில்லை, எனவே இது ஒரு `f64` ஆக பின்னர் கம்பைலரில் ஊகிக்கப்படலாம்.
    ///
    /// எதிர்மறை எண்களிலிருந்து உருவாக்கப்பட்ட எழுத்தாளர்கள் `TokenStream` அல்லது சரங்களின் மூலம் ரவுண்ட்ரிப்ஸைத் தக்கவைக்காமல் இருக்கலாம் மற்றும் இரண்டு tokens (`-` மற்றும் நேர்மறை நேரடி) ஆக உடைக்கப்படலாம்.
    ///
    /// # Panics
    ///
    /// இந்த செயல்பாட்டிற்கு குறிப்பிட்ட மிதவை வரையறுக்கப்பட்டதாக இருக்க வேண்டும், எடுத்துக்காட்டாக இது முடிவிலி அல்லது NaN ஆக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ஒரு புதிய பின்னொட்டு மிதக்கும் புள்ளியை உருவாக்குகிறது.
    ///
    /// இந்த கட்டமைப்பாளர் `1.0f32` போன்ற ஒரு எழுத்தை உருவாக்குவார், அங்கு குறிப்பிடப்பட்ட மதிப்பு token இன் முந்தைய பகுதியாகும் மற்றும் `f32` என்பது token இன் பின்னொட்டு ஆகும்.
    /// இந்த token எப்போதும் கம்பைலரில் ஒரு `f32` ஆக இருக்கும்.
    /// எதிர்மறை எண்களிலிருந்து உருவாக்கப்பட்ட எழுத்தாளர்கள் `TokenStream` அல்லது சரங்களின் மூலம் ரவுண்ட்ரிப்ஸைத் தக்கவைக்காமல் இருக்கலாம் மற்றும் இரண்டு tokens (`-` மற்றும் நேர்மறை நேரடி) ஆக உடைக்கப்படலாம்.
    ///
    ///
    /// # Panics
    ///
    /// இந்த செயல்பாட்டிற்கு குறிப்பிட்ட மிதவை வரையறுக்கப்பட்டதாக இருக்க வேண்டும், எடுத்துக்காட்டாக இது முடிவிலி அல்லது NaN ஆக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// ஒரு புதிய இணைக்கப்படாத மிதக்கும் புள்ளியை உருவாக்குகிறது.
    ///
    /// இந்த கட்டமைப்பாளர் `Literal::i8_unsuffixed` போன்றதைப் போன்றது, அங்கு மிதவை மதிப்பு நேரடியாக token க்குள் வெளியேற்றப்படுகிறது, ஆனால் எந்த பின்னொட்டும் பயன்படுத்தப்படவில்லை, எனவே இது ஒரு `f64` ஆக பின்னர் கம்பைலரில் ஊகிக்கப்படலாம்.
    ///
    /// எதிர்மறை எண்களிலிருந்து உருவாக்கப்பட்ட எழுத்தாளர்கள் `TokenStream` அல்லது சரங்களின் மூலம் ரவுண்ட்ரிப்ஸைத் தக்கவைக்காமல் இருக்கலாம் மற்றும் இரண்டு tokens (`-` மற்றும் நேர்மறை நேரடி) ஆக உடைக்கப்படலாம்.
    ///
    /// # Panics
    ///
    /// இந்த செயல்பாட்டிற்கு குறிப்பிட்ட மிதவை வரையறுக்கப்பட்டதாக இருக்க வேண்டும், எடுத்துக்காட்டாக இது முடிவிலி அல்லது NaN ஆக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ஒரு புதிய பின்னொட்டு மிதக்கும் புள்ளியை உருவாக்குகிறது.
    ///
    /// இந்த கட்டமைப்பாளர் `1.0f64` போன்ற ஒரு எழுத்தை உருவாக்குவார், அங்கு குறிப்பிடப்பட்ட மதிப்பு token இன் முந்தைய பகுதியாகும் மற்றும் `f64` என்பது token இன் பின்னொட்டு ஆகும்.
    /// இந்த token எப்போதும் கம்பைலரில் ஒரு `f64` ஆக இருக்கும்.
    /// எதிர்மறை எண்களிலிருந்து உருவாக்கப்பட்ட எழுத்தாளர்கள் `TokenStream` அல்லது சரங்களின் மூலம் ரவுண்ட்ரிப்ஸைத் தக்கவைக்காமல் இருக்கலாம் மற்றும் இரண்டு tokens (`-` மற்றும் நேர்மறை நேரடி) ஆக உடைக்கப்படலாம்.
    ///
    ///
    /// # Panics
    ///
    /// இந்த செயல்பாட்டிற்கு குறிப்பிட்ட மிதவை வரையறுக்கப்பட்டதாக இருக்க வேண்டும், எடுத்துக்காட்டாக இது முடிவிலி அல்லது NaN ஆக இருந்தால் இந்த செயல்பாடு panic ஆக இருக்கும்.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// சரம் நேரடி.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// எழுத்துக்குறி.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// பைட் சரம் நேரடி.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// இந்த மொழியை உள்ளடக்கிய இடைவெளியை வழங்குகிறது.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// இந்த மொழியுடன் தொடர்புடைய இடைவெளியை உள்ளமைக்கிறது.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span` ஐ வழங்குகிறது, இது `self.span()` இன் துணைக்குழுவாகும், இது `range` வரம்பில் மூல பைட்டுகளை மட்டுமே கொண்டுள்ளது.
    /// ஒழுங்கமைக்கப்பட்ட இடைவெளி `self` இன் எல்லைக்கு வெளியே இருந்தால் `None` ஐ வழங்குகிறது.
    ///
    // FIXME(SergioBenitez): பைட் வரம்பு மூலத்தின் UTF-8 எல்லையில் தொடங்கி முடிவடைகிறதா என்று சரிபார்க்கவும்.
    // இல்லையெனில், மூல உரை அச்சிடப்படும் போது வேறு எங்கும் panic ஏற்பட வாய்ப்புள்ளது.
    // FIXME(SergioBenitez): `self.span()` உண்மையில் எதை வரைபடமாக்குகிறது என்பதை பயனருக்கு அறிய வழி இல்லை, எனவே இந்த முறையை தற்போது கண்மூடித்தனமாக மட்டுமே அழைக்க முடியும்.
    // எடுத்துக்காட்டாக, 'c' எழுத்துக்குறி `to_string()` "'\u{63}'" ஐ வழங்குகிறது;மூல உரை 'c' ஆக இருந்ததா அல்லது அது '\u{63}' என்பதை பயனருக்கு அறிய வழி இல்லை.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` க்கு ஒத்த ஒன்று, ஆனால் `Bound<&T>` க்கு.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, பாலம் `to_string` ஐ மட்டுமே வழங்குகிறது, அதன் அடிப்படையில் `fmt::Display` ஐ செயல்படுத்துகிறது (இருவருக்கும் இடையிலான வழக்கமான உறவின் தலைகீழ்).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// அதே சரமாக (மிதக்கும் புள்ளி எழுத்தாளர்களுக்கான சாத்தியமான ரவுண்டிங் தவிர) இழப்பின்றி மாற்றக்கூடிய ஒரு சரம் என மொழியை அச்சிடுகிறது.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// சூழல் மாறிகள் கண்காணிக்கப்பட்ட அணுகல்.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// சூழல் மாறியை மீட்டெடுத்து சார்பு தகவலை உருவாக்க அதைச் சேர்க்கவும்.
    /// தொகுப்பினை இயக்கும் பில்ட் சிஸ்டம், தொகுப்பின் போது மாறி அணுகப்பட்டது என்பதை அறிந்து கொள்ளும், மேலும் அந்த மாறியின் மதிப்பு மாறும்போது கட்டமைப்பை மீண்டும் இயக்க முடியும்.
    ///
    /// சார்பு கண்காணிப்பைத் தவிர, இந்த செயல்பாடு நிலையான நூலகத்திலிருந்து `env::var` க்கு சமமாக இருக்க வேண்டும், தவிர வாதம் UTF-8 ஆக இருக்க வேண்டும்.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}