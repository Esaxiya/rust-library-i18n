use crate::Span;

/// கண்டறியும் அளவைக் குறிக்கும் ஒரு enum.
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
#[derive(Copy, Clone, Debug)]
#[non_exhaustive]
pub enum Level {
    /// ஒரு தவறு.
    Error,
    /// ஒரு எச்சரிக்கை.
    Warning,
    /// ஒரு குறிப்பு.
    Note,
    /// ஒரு உதவி செய்தி.
    Help,
}

/// Trait வகைகளால் செயல்படுத்தப்படுகிறது, அவை `ஸ்பானின் தொகுப்பாக மாற்றப்படலாம்.
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub trait MultiSpan {
    /// `self` ஐ `Vec<Span>` ஆக மாற்றுகிறது.
    fn into_spans(self) -> Vec<Span>;
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl MultiSpan for Span {
    fn into_spans(self) -> Vec<Span> {
        vec![self]
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl MultiSpan for Vec<Span> {
    fn into_spans(self) -> Vec<Span> {
        self
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl<'a> MultiSpan for &'a [Span] {
    fn into_spans(self) -> Vec<Span> {
        self.to_vec()
    }
}

/// கண்டறியும் செய்தி மற்றும் தொடர்புடைய குழந்தைகள் செய்திகளைக் குறிக்கும் அமைப்பு.
///
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
#[derive(Clone, Debug)]
pub struct Diagnostic {
    level: Level,
    message: String,
    spans: Vec<Span>,
    children: Vec<Diagnostic>,
}

macro_rules! diagnostic_child_methods {
    ($spanned:ident, $regular:ident, $level:expr) => {
        /// கொடுக்கப்பட்ட `spans` மற்றும் `message` உடன் இந்த முறையின் பெயரால் அடையாளம் காணப்பட்ட அளவைக் கொண்டு `self` இல் புதிய குழந்தை கண்டறியும் செய்தியைச் சேர்க்கிறது.
        ///
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $spanned<S, T>(mut self, spans: S, message: T) -> Diagnostic
        where
            S: MultiSpan,
            T: Into<String>,
        {
            self.children.push(Diagnostic::spanned(spans, $level, message));
            self
        }

        /// கொடுக்கப்பட்ட `message` உடன் இந்த முறையின் பெயரால் அடையாளம் காணப்பட்ட அளவைக் கொண்டு `self` இல் புதிய குழந்தை கண்டறியும் செய்தியைச் சேர்க்கிறது.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $regular<T: Into<String>>(mut self, message: T) -> Diagnostic {
            self.children.push(Diagnostic::new($level, message));
            self
        }
    };
}

/// ஒரு `Diagnostic` இன் குழந்தைகள் கண்டறியும் மீது ஈட்டரேட்டர்.
#[derive(Debug, Clone)]
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub struct Children<'a>(std::slice::Iter<'a, Diagnostic>);

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl<'a> Iterator for Children<'a> {
    type Item = &'a Diagnostic;

    fn next(&mut self) -> Option<Self::Item> {
        self.0.next()
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl Diagnostic {
    /// கொடுக்கப்பட்ட `level` மற்றும் `message` உடன் புதிய நோயறிதலை உருவாக்குகிறது.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn new<T: Into<String>>(level: Level, message: T) -> Diagnostic {
        Diagnostic { level, message: message.into(), spans: vec![], children: vec![] }
    }

    /// கொடுக்கப்பட்ட `spans` இன் தொகுப்பை சுட்டிக்காட்டி கொடுக்கப்பட்ட `level` மற்றும் `message` உடன் புதிய நோயறிதலை உருவாக்குகிறது.
    ///
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn spanned<S, T>(spans: S, level: Level, message: T) -> Diagnostic
    where
        S: MultiSpan,
        T: Into<String>,
    {
        Diagnostic { level, message: message.into(), spans: spans.into_spans(), children: vec![] }
    }

    diagnostic_child_methods!(span_error, error, Level::Error);
    diagnostic_child_methods!(span_warning, warning, Level::Warning);
    diagnostic_child_methods!(span_note, note, Level::Note);
    diagnostic_child_methods!(span_help, help, Level::Help);

    /// `self` க்கான கண்டறியும் `level` ஐ வழங்குகிறது.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn level(&self) -> Level {
        self.level
    }

    /// `self` முதல் `level` வரை அளவை அமைக்கிறது.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_level(&mut self, level: Level) {
        self.level = level;
    }

    /// `self` இல் செய்தியை வழங்குகிறது.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn message(&self) -> &str {
        &self.message
    }

    /// `self` முதல் `message` வரை செய்தியை அமைக்கிறது.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_message<T: Into<String>>(&mut self, message: T) {
        self.message = message.into();
    }

    /// `self` இல் `ஸ்பான்'களை வழங்குகிறது.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn spans(&self) -> &[Span] {
        &self.spans
    }

    /// `ஸ்பான்'களை `self` முதல் `spans` வரை அமைக்கிறது.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_spans<S: MultiSpan>(&mut self, spans: S) {
        self.spans = spans.into_spans();
    }

    /// `self` இன் குழந்தைகள் கண்டறிதலின் மீது ஒரு ஈரேட்டரை வழங்குகிறது.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn children(&self) -> Children<'_> {
        Children(self.children.iter())
    }

    /// நோயறிதலை வெளியிடுங்கள்.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn emit(self) {
        fn to_internal(spans: Vec<Span>) -> crate::bridge::client::MultiSpan {
            let mut multi_span = crate::bridge::client::MultiSpan::new();
            for span in spans {
                multi_span.push(span.0);
            }
            multi_span
        }

        let mut diag = crate::bridge::client::Diagnostic::new(
            self.level,
            &self.message[..],
            to_internal(self.spans),
        );
        for c in self.children {
            diag.sub(c.level, &c.message[..], to_internal(c.spans));
        }
        diag.emit();
    }
}