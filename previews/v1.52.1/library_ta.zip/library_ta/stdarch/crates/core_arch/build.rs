use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // எங்கள் `#[assert_instr]` சிறுகுறிப்புகளைக் கூறப் பயன்படுகிறது, அவற்றின் குறியீட்டைச் சோதிக்க அனைத்து சிமிட் உள்ளார்ந்தவைகளும் கிடைக்கின்றன, ஏனென்றால் சில கூடுதல் `-Ctarget-feature=+unimplemented-simd128` க்குப் பின்னால் அமைக்கப்பட்டிருக்கின்றன, அவை இப்போது `#[target_feature]` இல் சமமானவை இல்லை.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}