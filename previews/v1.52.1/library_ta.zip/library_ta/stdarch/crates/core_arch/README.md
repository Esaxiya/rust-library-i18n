`core::arch` - Rust இன் முக்கிய நூலக கட்டமைப்பு-குறிப்பிட்ட உள்ளார்ந்த
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` தொகுதி கட்டமைப்பு சார்ந்த சார்பு உள்ளார்ந்தவற்றை (எ.கா. சிம்டி) செயல்படுத்துகிறது.

# Usage 

`core::arch` `libcore` இன் ஒரு பகுதியாக கிடைக்கிறது, மேலும் இது `libstd` ஆல் மீண்டும் ஏற்றுமதி செய்யப்படுகிறது.இந்த crate வழியாக இருப்பதை விட `core::arch` அல்லது `std::arch` வழியாக இதைப் பயன்படுத்த விரும்புங்கள்.
நிலையற்ற அம்சங்கள் பெரும்பாலும் இரவு நேர Rust இல் `feature(stdsimd)` வழியாக கிடைக்கின்றன.

இந்த crate வழியாக `core::arch` ஐப் பயன்படுத்துவதற்கு இரவு Rust தேவைப்படுகிறது, மேலும் இது அடிக்கடி உடைக்கலாம் (செய்கிறது).இந்த crate வழியாக இதைப் பயன்படுத்த நீங்கள் கருத்தில் கொள்ள வேண்டிய ஒரே சந்தர்ப்பங்கள்:

* நீங்கள் `core::arch` ஐ மீண்டும் தொகுக்க வேண்டும் என்றால், எ.கா., `libcore`/`libstd` க்கு இயக்கப்பட்டிருக்காத குறிப்பிட்ட இலக்கு-அம்சங்கள் இயக்கப்பட்டன.
Note: தரமற்ற இலக்குக்கு நீங்கள் அதை மீண்டும் தொகுக்க வேண்டும் என்றால், தயவுசெய்து இந்த crate ஐப் பயன்படுத்துவதற்குப் பதிலாக `xargo` ஐப் பயன்படுத்தவும், `libcore`/`libstd` ஐ மீண்டும் தொகுக்கவும் விரும்பவும்.
  
* நிலையற்ற Rust அம்சங்களுக்குப் பின்னால் கூட கிடைக்காத சில அம்சங்களைப் பயன்படுத்துதல்.இவற்றை குறைந்தபட்சமாக வைக்க முயற்சிக்கிறோம்.
இந்த அம்சங்களில் சிலவற்றை நீங்கள் பயன்படுத்த வேண்டியிருந்தால், தயவுசெய்து ஒரு சிக்கலைத் திறக்கவும், இதன்மூலம் அவற்றை இரவுநேர Rust இல் நாங்கள் வெளிப்படுத்தலாம், மேலும் அவற்றை அங்கிருந்து பயன்படுத்தலாம்.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` முதன்மையாக MIT உரிமம் மற்றும் Apache உரிமம் (பதிப்பு 2.0) ஆகிய இரண்டின் விதிமுறைகளின் கீழ் விநியோகிக்கப்படுகிறது, இதில் பல்வேறு BSD போன்ற உரிமங்களால் மூடப்பட்டுள்ளது.

விவரங்களுக்கு LICENSE-APACHE, மற்றும் LICENSE-MIT ஐப் பார்க்கவும்.

# Contribution

நீங்கள் வேறுவிதமாக வெளிப்படையாகக் கூறாவிட்டால், Apache-2.0 உரிமத்தில் வரையறுக்கப்பட்டுள்ளபடி, நீங்கள் `core_arch` இல் சேர்ப்பதற்காக வேண்டுமென்றே சமர்ப்பிக்கப்பட்ட எந்தவொரு பங்களிப்பும் கூடுதல் விதிமுறைகள் அல்லது நிபந்தனைகள் இல்லாமல் மேலே குறிப்பிட்டபடி இரட்டை உரிமம் பெறும்.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












