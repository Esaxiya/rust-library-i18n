#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) ஐப் பார்க்கவும்.
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) ஐப் பார்க்கவும்.
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) ஐப் பார்க்கவும்.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) ஐப் பார்க்கவும்.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) ஐப் பார்க்கவும்.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) ஐப் பார்க்கவும்.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// கொடுக்கப்பட்ட `rw` மற்றும் `locality` ஐப் பயன்படுத்தி `p` முகவரியைக் கொண்ட கேச் வரியைப் பெறுங்கள்.
///
/// `rw` இதில் ஒன்றாக இருக்க வேண்டும்:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): முன்னொட்டு ஒரு வாசிப்புக்கு தயாராகி வருகிறது.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): முன்னொட்டு ஒரு எழுத்துக்கு தயாராகி வருகிறது.
///
/// `locality` இதில் ஒன்றாக இருக்க வேண்டும்:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): ஒரு முறை மட்டுமே பயன்படுத்தப்படும் தரவுகளுக்கு ஸ்ட்ரீமிங் அல்லது தற்காலிக அல்லாத முன்னொட்டு.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): நிலை 3 தற்காலிக சேமிப்பில் பெறவும்.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): நிலை 2 தற்காலிக சேமிப்பில் பெறவும்.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): நிலை 1 தற்காலிக சேமிப்பில் பெறவும்.
///
/// ஒரு குறிப்பிட்ட முகவரியிலிருந்து நினைவக அணுகல் அருகிலுள்ள future இல் நிகழக்கூடும் என்று நினைவக அமைப்பிற்கு முன்னரே நினைவக அறிவுறுத்தல்கள் சமிக்ஞை செய்கின்றன.
/// குறிப்பிட்ட முகவரியை ஒன்று அல்லது அதற்கு மேற்பட்ட தற்காலிக சேமிப்புகளில் முன்பே ஏற்றுவது போன்ற நினைவக அணுகல் ஏற்படும் போது அவை விரைவாக இருக்கும் என்று எதிர்பார்க்கப்படும் நடவடிக்கைகளை மேற்கொள்வதன் மூலம் நினைவக அமைப்பு பதிலளிக்க முடியும்.
///
/// இந்த சமிக்ஞைகள் குறிப்புகள் மட்டுமே என்பதால், ஒரு குறிப்பிட்ட CPU க்கு எந்தவொரு அல்லது எல்லா முன்னொட்டு வழிமுறைகளையும் ஒரு NOP ஆக கருதுவது செல்லுபடியாகும்.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // `cache type` =1 (தரவு கேச்) உடன் `llvm.prefetch` இன்ஸ்ட்ரினிக் பயன்படுத்துகிறோம்.
    // `rw` மற்றும் `strategy` செயல்பாடு அளவுருக்களை அடிப்படையாகக் கொண்டவை.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}