//! `#[assert_instr]` மேக்ரோவை செயல்படுத்துதல்
//!
//! இந்த மேக்ரோ `stdarch` crate ஐ சோதிக்கும்போது பயன்படுத்தப்படுகிறது, மேலும் செயல்பாடுகள் உண்மையில் அவற்றைக் கொண்டிருக்க வேண்டும் என்று நாங்கள் எதிர்பார்க்கும் வழிமுறைகளைக் கொண்டிருக்கின்றன என்பதை உறுதிப்படுத்த சோதனை நிகழ்வுகளை உருவாக்கப் பயன்படுகிறது.
//!
//! இங்குள்ள நடைமுறை மேக்ரோ ஒப்பீட்டளவில் எளிதானது, இது அசல் token ஸ்ட்ரீமுக்கு ஒரு `#[test]` செயல்பாட்டைச் சேர்க்கிறது, இது செயல்பாட்டில் தொடர்புடைய அறிவுறுத்தலைக் கொண்டுள்ளது என்று வலியுறுத்துகிறது.
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // ஏ.வி.எக்ஸ் இயக்கப்பட்டவுடன் தொகுக்கப்பட்ட x86 இலக்குகளுக்கான assert_instr ஐ முடக்கு, இது எல்.எல்.வி.எம் நாம் சோதிக்கும் வெவ்வேறு உள்ளார்ந்தவற்றை உருவாக்க காரணமாகிறது.
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // அறிவுறுத்தல் சோதனைகள் முடக்கப்பட்டிருந்தால், இந்த ஷிமை வெளியிடுவதைத் தவிர்க்கவும், எங்கள் பண்பு இல்லாமல் அசல் உருப்படியைத் திருப்பி விடுங்கள்.
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // இந்த பெயர் பின்னர் பிரித்தெடுப்பதில் கண்டுபிடிக்க போதுமானதாக இருக்க வேண்டும்:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // இயல்புநிலையாக Unix இல் என்ன நடக்கிறது (நான் நினைக்கிறேன்?) போன்ற பதிவேட்டில் SIMD மதிப்புகளை அனுப்பும் Windows இல் ABI ஐப் பயன்படுத்தவும்.
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // முன்னிருப்பாக உகந்த பயன்முறையில் உள்ள கம்பைலர் "mergefunc" எனப்படும் பாஸை இயக்குகிறது, அங்கு அது ஒத்ததாக இருக்கும் செயல்பாடுகளை ஒன்றிணைக்கும்.
            // சில உள்ளார்ந்தவை ஒரே மாதிரியான குறியீட்டை உருவாக்குகின்றன, அவை ஒன்றாக மடிக்கப்படுகின்றன, அதாவது ஒன்று மற்றொன்றுக்கு தாவுகிறது.
            // இந்த செயல்பாட்டின் பிரித்தெடுத்தல் பற்றிய எங்கள் ஆய்வை இது குழப்புகிறது, நாங்கள் அதற்கு பெரிய ரசிகர் அல்ல.
            //
            // இந்த பாஸைத் தடுக்கவும், செயல்பாடுகள் ஒன்றிணைவதைத் தடுக்கவும், குறியீட்டைப் பொறுத்தவரை மிகவும் இறுக்கமான சில குறியீட்டை உருவாக்குகிறோம், ஆனால் குறியீடு மடிக்கப்படுவதைத் தடுக்க தனித்துவமானது.
            //
            //
            // இந்த செயல்பாடுகள் இன்லைன் செய்யப்படாததால் இது இப்போது Wasm32 இல் தவிர்க்கப்படுகிறது, இது எங்கள் சோதனைகளை உடைக்கிறது, ஏனெனில் ஒவ்வொரு உள்ளார்ந்த செயல்பாடுகளையும் அழைப்பது போல் தெரிகிறது.
            // எப்படியும் wasm32 இல் ஒன்றிணைக்க போதுமான செயல்பாடுகள் இல்லை.
            // இந்த பிழை rust-lang/rust#74320 இல் கண்காணிக்கப்படுகிறது.
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}