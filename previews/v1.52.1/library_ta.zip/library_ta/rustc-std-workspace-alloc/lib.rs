#![feature(no_core)]
#![no_core]

// இந்த crate ஏன் தேவைப்படுகிறது என்பதற்கு rustc-std-workspace-core ஐப் பார்க்கவும்.

// லிபாலோக்கில் ஒதுக்கீடு தொகுதிக்கு முரண்படுவதைத் தவிர்க்க crate என மறுபெயரிடுக.
extern crate alloc as foo;

pub use foo::*;