//! `compiler-rt` நூலகத்தின் சுயவிவர பகுதியை தொகுக்கிறது.
//!
//! விவரங்களுக்கு libcompiler_builtins crate க்கான build.rs ஐப் பார்க்கவும்.

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` வழிமுறைகள் தற்போது வெளியிடப்படவில்லை மற்றும் உருவாக்க ஸ்கிரிப்ட்
    // இந்த மூல கோப்புகள் அல்லது அவற்றில் சேர்க்கப்பட்டுள்ள தலைப்புகளில் ஏற்படும் மாற்றங்களை மீண்டும் இயக்காது.
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // இந்த கோப்பு எல்.எல்.வி.எம் 10 இல் மறுபெயரிடப்பட்டது.
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // இந்த கோப்புகள் எல்.எல்.வி.எம் 11 இல் சேர்க்கப்பட்டன.
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // MSVC இல் கூடுதல் நூலகங்களை இழுக்க வேண்டாம்
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc இன் பல்வேறு அம்சங்களை அணைக்கவும், இது பெரும்பாலும் கம்பைலர்-rt இன் உருவாக்க அமைப்பை ஏற்கனவே நகலெடுக்கிறது
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // எக்ஸ் 00 எக்ஸ் கிடைப்பதற்காக இதை நாங்கள் உருவாக்கும் யூனிக்ஸ்ஸில் உள்ளது என்று வைத்துக் கொள்ளுங்கள்
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // COMPILER_RT_HAS_ATOMICS ஐ எப்போது அமைப்பது என்பதற்கு இது ஒரு நல்ல ஹூரிஸ்டிக் ஆக இருக்க வேண்டும்
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // நாம் இயக்கப் போகிறீர்கள் என்றால் இது இருக்க வேண்டும் என்பதை நினைவில் கொள்க (இல்லையெனில் நாங்கள் சுயவிவர பில்டின்களை உருவாக்க மாட்டோம்).
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}