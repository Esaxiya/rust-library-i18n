// `SetLenOnDrop` மதிப்பு வரம்பிலிருந்து வெளியேறும்போது vec இன் நீளத்தை அமைக்கவும்.
//
// யோசனை என்னவென்றால்: செட்லென்ஆன் டிராப்பில் உள்ள நீளம் புலம் என்பது ஒரு உள்ளூர் மாறி, இது வெக் தரவு சுட்டிக்காட்டி மூலம் எந்தக் கடைகளுடனும் மாற்றுப்பெயர் இல்லை.
// இது மாற்று பகுப்பாய்வு வெளியீடு #32155 க்கான ஒரு தீர்வாகும்
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}