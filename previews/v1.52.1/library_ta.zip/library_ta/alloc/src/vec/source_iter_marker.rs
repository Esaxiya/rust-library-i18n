use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// மூல ஒதுக்கீட்டை மீண்டும் பயன்படுத்தும் போது ஒரு Vec இல் ஒரு ஈரேட்டர் பைப்லைனை சேகரிப்பதற்கான சிறப்பு மார்க்கர், அதாவது
/// பைப்லைனை இடத்தில் செயல்படுத்துகிறது.
///
/// மீண்டும் பயன்படுத்தப்பட வேண்டிய ஒதுக்கீட்டை அணுக சிறப்பு செயல்பாட்டிற்கு SourceIter பெற்றோர் trait அவசியம்.
/// ஆனால் சிறப்பு செல்லுபடியாகும் அளவுக்கு இது போதாது.
/// Impl இல் கூடுதல் வரம்புகளைக் காண்க.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-உள் SourceIter/InPlaceIterable traits அடாப்டரின் சங்கிலிகளால் மட்டுமே செயல்படுத்தப்படுகிறது <Adapter<Adapter<IntoIter>>> (அனைத்தும் core/std க்கு சொந்தமானது).
// அடாப்டர் செயலாக்கங்களின் கூடுதல் வரம்புகள் (`impl<I: Trait> Trait for Adapter<I>` க்கு அப்பால்) ஏற்கனவே traits (நகலெடு, நம்பகமான ரேண்டம்அக்சஸ், ஃபியூஸ்இடரேட்டர்) சிறப்பு எனக் குறிக்கப்பட்ட பிற traits ஐ மட்டுமே சார்ந்துள்ளது.
//
// I.e. மார்க்கர் பயனர் வழங்கிய வகைகளின் ஆயுட்காலம் சார்ந்தது அல்ல.மாடுலோ நகல் துளை, இது ஏற்கனவே பல சிறப்புகளை சார்ந்துள்ளது.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds வழியாக வெளிப்படுத்த முடியாத கூடுதல் தேவைகள்.அதற்கு பதிலாக நாங்கள் const eval ஐ நம்புகிறோம்:
        // a) மறுபயன்பாட்டுக்கு எந்த ஒதுக்கீடும் இல்லாததால் ZST கள் இல்லை மற்றும் சுட்டிக்காட்டி எண்கணிதம் panic b) ஒதுக்கீடு ஒப்பந்தத்தின் தேவைக்கேற்ப அளவு பொருந்தும் c) ஒதுக்கீடு ஒப்பந்தத்தின் தேவைக்கேற்ப சீரமைப்புகள் பொருந்துகின்றன
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // மேலும் பொதுவான செயலாக்கங்களுக்கான குறைவு
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // பின்னர் முயற்சி-மடங்கு பயன்படுத்தவும்
        // - இது சில ஈரேட்டர் அடாப்டர்களுக்கு சிறந்த திசையன் செய்கிறது
        // - பெரும்பாலான உள் மறு செய்கை முறைகளைப் போலன்றி, இது ஒரு &mut சுயத்தை மட்டுமே எடுக்கும்
        // - இது எழுத்து சுட்டிக்காட்டி அதன் உட்புறங்கள் வழியாக நூல் செய்து இறுதியில் அதை திரும்பப் பெற உதவுகிறது
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // மறு செய்கை வெற்றி பெற்றது, தலை கைவிட வேண்டாம்
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // SourceIter ஒப்பந்தம் எச்சரிக்கையாக இருந்ததா என சரிபார்க்கவும்: அவை இல்லையென்றால் நாங்கள் இந்த நிலைக்கு கூட வரக்கூடாது
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable ஒப்பந்தத்தை சரிபார்க்கவும்.ஈரேட்டர் மூல சுட்டிக்காட்டி அனைத்தையும் மேம்படுத்தினால் மட்டுமே இது சாத்தியமாகும்.
        // இது TrustedRandomAccess வழியாக தேர்வு செய்யப்படாத அணுகலைப் பயன்படுத்தினால், மூல சுட்டிக்காட்டி அதன் ஆரம்ப நிலையில் இருக்கும், அதை நாம் குறிப்பாகப் பயன்படுத்த முடியாது
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // மீதமுள்ள மதிப்புகளை மூலத்தின் வால் கைவிடவும், ஆனால் panics துளி என்றால் IntoIter நோக்கம் இல்லாமல் போனால் ஒதுக்கீட்டைக் குறைப்பதைத் தடுக்கவும், பின்னர் dst_buf இல் சேகரிக்கப்பட்ட எந்த உறுப்புகளையும் கசிய விடுகிறோம்
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable ஒப்பந்தத்தை இங்கே துல்லியமாக சரிபார்க்க முடியாது, ஏனெனில் try_fold மூல சுட்டிக்காட்டிக்கு ஒரு பிரத்யேக குறிப்பு இருப்பதால், நாம் செய்யக்கூடியது, அது இன்னும் வரம்பில் இருக்கிறதா என்று சோதிக்க வேண்டும்
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}