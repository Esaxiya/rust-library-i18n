use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter க்கு பயன்படுத்தப்படும் trait சிறப்பு
///
/// ## பிரதிநிதித்துவ வரைபடம்:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // ஒரு பொதுவான வழக்கு ஒரு vector ஐ ஒரு செயல்பாட்டிற்கு அனுப்புகிறது, இது உடனடியாக vector இல் மீண்டும் சேகரிக்கிறது.
        // இன்டோஇட்டர் முன்னேறவில்லை என்றால் இதை நாம் குறுகிய சுற்று செய்யலாம்.
        // இது மேம்பட்டதும் நாம் நினைவகத்தை மீண்டும் பயன்படுத்தலாம் மற்றும் தரவை முன்னால் நகர்த்தலாம்.
        // ஆனால் அதன் விளைவாக வரும் Vec ஆனது பொதுவான FromIterator செயல்படுத்தல் மூலம் அதை உருவாக்குவதை விட பயன்படுத்தப்படாத திறனைக் கொண்டிருக்கவில்லை.
        //
        // வெக்கின் ஒதுக்கீட்டு நடத்தை வேண்டுமென்றே குறிப்பிடப்படாததால் அந்த வரம்பு கண்டிப்பாக தேவையில்லை.
        // ஆனால் அது பழமைவாத தேர்வு.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // extend() வெற்று Vec க்காக spec_from க்கு பிரதிநிதித்துவப்படுத்துவதால் spec_extend() க்கு பிரதிநிதித்துவம் செய்ய வேண்டும்
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// இது `iterator.as_slice().to_vec()` ஐப் பயன்படுத்துகிறது, ஏனெனில் ஸ்பெக்_எக்ஸ்டெண்ட் இறுதி திறன் + நீளம் குறித்து நியாயப்படுத்த கூடுதல் நடவடிக்கைகளை எடுக்க வேண்டும், இதனால் அதிக வேலை செய்ய வேண்டும்.
// `to_vec()` நேரடியாக சரியான தொகையை ஒதுக்குகிறது மற்றும் அதை சரியாக நிரப்புகிறது.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) உடன் இந்த முறை வரையறைக்கு தேவைப்படும் உள்ளார்ந்த `[T]::to_vec` முறை கிடைக்கவில்லை.
    // அதற்கு பதிலாக cfg(test) NB உடன் மட்டுமே கிடைக்கும் `slice::to_vec` செயல்பாட்டைப் பயன்படுத்தவும் மேலும் தகவலுக்கு slice.rs இல் slice::hack தொகுதியைப் பார்க்கவும்
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}