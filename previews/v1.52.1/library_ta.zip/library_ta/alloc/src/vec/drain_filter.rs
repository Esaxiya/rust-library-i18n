use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// ஒரு உறுப்பு அகற்றப்பட வேண்டுமா என்பதை தீர்மானிக்க மூடுதலைப் பயன்படுத்தும் ஒரு ஈரேட்டர்.
///
/// இந்த கட்டமைப்பு [`Vec::drain_filter`] ஆல் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// `next` க்கு அடுத்த அழைப்பின் மூலம் ஆய்வு செய்யப்படும் உருப்படியின் குறியீடு.
    pub(super) idx: usize,
    /// இதுவரை (removed) வடிகட்டிய பொருட்களின் எண்ணிக்கை.
    pub(super) del: usize,
    /// வடிகட்டுவதற்கு முன் `vec` இன் அசல் நீளம்.
    pub(super) old_len: usize,
    /// வடிகட்டி சோதனை முன்னறிவிக்கிறது.
    pub(super) pred: F,
    /// வடிகட்டி சோதனை முன்னறிவிப்பில் panic இருப்பதைக் குறிக்கும் கொடி.
    /// `DrainFilter` இன் மீதமுள்ள நுகர்வு தடுக்க இது துளி செயல்படுத்தலில் ஒரு குறிப்பாக பயன்படுத்தப்படுகிறது.
    /// எந்தவொரு பதப்படுத்தப்படாத உருப்படிகளும் `vec` இல் பின்னிணைப்பு செய்யப்படும், ஆனால் வடிகட்டி முன்கணிப்பால் மேலும் உருப்படிகள் கைவிடப்படாது அல்லது சோதிக்கப்படாது.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// அடிப்படை ஒதுக்கீட்டாளருக்கு ஒரு குறிப்பை வழங்குகிறது.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // முன்னறிவிப்பு அழைக்கப்பட்ட பிறகு குறியீட்டை * புதுப்பிக்கவும்.
                // குறியீட்டு முன் புதுப்பிக்கப்பட்டு panics ஐ முன்னறிவித்தால், இந்த குறியீட்டில் உள்ள உறுப்பு கசிந்துவிடும்.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // இது மிகவும் குழப்பமான நிலை, உண்மையில் வெளிப்படையாக சரியான விஷயம் இல்லை.
                        // `pred` ஐ இயக்க முயற்சிக்க நாங்கள் விரும்பவில்லை, எனவே பதப்படுத்தப்படாத அனைத்து கூறுகளையும் பின்னிணைத்து, அவை இன்னும் உள்ளன என்று vec க்கு சொல்கிறோம்.
                        //
                        // முன்னறிவிப்பில் ஒரு panic க்கு முன்னர் வெற்றிகரமாக வடிகட்டிய உருப்படியின் இரட்டை வீழ்ச்சியைத் தடுக்க பேக்ஷிப்ட் தேவைப்படுகிறது.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // வடிகட்டி முன்கணிப்பு இன்னும் பீதியடையவில்லை என்றால் மீதமுள்ள எந்த உறுப்புகளையும் நுகரும் முயற்சி.
        // நாங்கள் ஏற்கனவே பீதியடைந்திருந்தாலும் அல்லது இங்கே நுகர்வு panics ஆக இருந்தாலும் மீதமுள்ள எந்த உறுப்புகளையும் நாங்கள் மாற்றுவோம்.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}