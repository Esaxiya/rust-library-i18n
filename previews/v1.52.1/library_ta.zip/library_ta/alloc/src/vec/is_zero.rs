use crate::boxed::Box;

#[rustc_specialization_trait]
pub(super) unsafe trait IsZero {
    /// இந்த மதிப்பு பூஜ்ஜியமா என்பது
    fn is_zero(&self) -> bool;
}

macro_rules! impl_is_zero {
    ($t:ty, $is_zero:expr) => {
        unsafe impl IsZero for $t {
            #[inline]
            fn is_zero(&self) -> bool {
                $is_zero(*self)
            }
        }
    };
}

impl_is_zero!(i16, |x| x == 0);
impl_is_zero!(i32, |x| x == 0);
impl_is_zero!(i64, |x| x == 0);
impl_is_zero!(i128, |x| x == 0);
impl_is_zero!(isize, |x| x == 0);

impl_is_zero!(u16, |x| x == 0);
impl_is_zero!(u32, |x| x == 0);
impl_is_zero!(u64, |x| x == 0);
impl_is_zero!(u128, |x| x == 0);
impl_is_zero!(usize, |x| x == 0);

impl_is_zero!(bool, |x| x == false);
impl_is_zero!(char, |x| x == '\0');

impl_is_zero!(f32, |x: f32| x.to_bits() == 0);
impl_is_zero!(f64, |x: f64| x.to_bits() == 0);

unsafe impl<T> IsZero for *const T {
    #[inline]
    fn is_zero(&self) -> bool {
        (*self).is_null()
    }
}

unsafe impl<T> IsZero for *mut T {
    #[inline]
    fn is_zero(&self) -> bool {
        (*self).is_null()
    }
}

// `Option<&T>` மற்றும் `Option<Box<T>>` ஆனது `None` ஐ பூஜ்யமாகக் குறிக்கும்.
// கொழுப்பு சுட்டிகளுக்கு, `Some` மாறுபாட்டில் சுட்டிக்காட்டி மெட்டாடேட்டாவாக இருக்கும் பைட்டுகள் `None` மாறுபாட்டில் திணிக்கப்படுகின்றன, எனவே அவற்றைப் புறக்கணித்து அதற்கு பதிலாக பூஜ்ஜிய-துவக்கம் சரி.
//
// `Option<&mut T>` `Clone` ஐ ஒருபோதும் செயல்படுத்தாது, எனவே `SpecFromElem` இன் impl தேவை இல்லை.
//
//

unsafe impl<T: ?Sized> IsZero for Option<&T> {
    #[inline]
    fn is_zero(&self) -> bool {
        self.is_none()
    }
}

unsafe impl<T: ?Sized> IsZero for Option<Box<T>> {
    #[inline]
    fn is_zero(&self) -> bool {
        self.is_none()
    }
}