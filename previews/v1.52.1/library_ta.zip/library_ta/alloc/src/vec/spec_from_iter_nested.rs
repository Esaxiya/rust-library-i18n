use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// ஒன்றுடன் ஒன்று சிறப்பு கைமுறையாக முன்னுரிமை அளிக்க Vec::from_iter க்கான trait இன் மற்றொரு சிறப்பு விவரங்களுக்கு [`SpecFromIter`](super::SpecFromIter) ஐப் பார்க்கவும்.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // முதல் மறு செய்கையை அவிழ்த்து விடுங்கள், ஏனெனில் ஒவ்வொரு சந்தர்ப்பத்திலும் இந்த மறு செய்கையில் vector விரிவாக்கப் போகிறது, இது மீண்டும் காலியாக இல்லாதபோது, ஆனால் extend_desugared() இல் உள்ள லூப் சில அடுத்தடுத்த லூப் மறு செய்கைகளில் vector நிரம்பியிருப்பதைக் காணப்போவதில்லை.
        //
        // எனவே சிறந்த branch கணிப்பைப் பெறுகிறோம்.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // extend() வெற்று Vec க்காக spec_from க்கு பிரதிநிதித்துவப்படுத்துவதால் spec_extend() க்கு பிரதிநிதித்துவம் செய்ய வேண்டும்
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // extend() வெற்று Vec க்காக spec_from க்கு பிரதிநிதித்துவப்படுத்துவதால் spec_extend() க்கு பிரதிநிதித்துவம் செய்ய வேண்டும்
        //
        vector.spec_extend(iterator);
        vector
    }
}