use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// மரத்திலிருந்து ஒரு முக்கிய மதிப்பு ஜோடியை அகற்றி, அந்த ஜோடியையும், அதே ஜோடிக்கு முந்தைய edge இலைகளையும் வழங்குகிறது.
    /// இது உள் இருக்கும் ஒரு ரூட் முனையை காலியாக்குவது சாத்தியமாகும், இது அழைப்பவர் மரத்தை வைத்திருக்கும் வரைபடத்திலிருந்து பாப் செய்ய வேண்டும்.
    /// அழைப்பவர் வரைபடத்தின் நீளத்தையும் குறைக்க வேண்டும்.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // குழந்தை வகையை நாம் தற்காலிகமாக மறந்துவிட வேண்டும், ஏனென்றால் ஒரு இலையின் உடனடி பெற்றோருக்கு தனித்துவமான முனை வகை இல்லை.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // பாதுகாப்பு: `new_pos` என்பது நாம் தொடங்கிய இலை அல்லது ஒரு உடன்பிறப்பு.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // நாங்கள் ஒன்றிணைந்தால் மட்டுமே, பெற்றோர் (ஏதேனும் இருந்தால்) சுருங்கிவிட்டனர், ஆனால் பின்வரும் படிநிலையைத் தவிர்ப்பது இல்லையெனில் வரையறைகளில் செலுத்தாது.
            //
            // பாதுகாப்பு: `pos` இருக்கும் இலையை நாங்கள் அழிக்கவோ அல்லது மறுசீரமைக்கவோ மாட்டோம்
            // அதன் பெற்றோரை மீண்டும் மீண்டும் கையாள்வதன் மூலம்;மோசமான நிலையில், தாத்தா பாட்டி மூலம் பெற்றோரை அழிப்போம் அல்லது மறுசீரமைப்போம், இதனால் இலைக்குள் பெற்றோருக்கான இணைப்பை மாற்றுவோம்.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // அதன் இலையிலிருந்து அருகிலுள்ள கே.வி.யை அகற்றிவிட்டு, அதை அகற்றும்படி எங்களிடம் கூறப்பட்ட உறுப்புக்கு பதிலாக மீண்டும் வைக்கவும்.
        //
        // `choose_parent_kv` இல் பட்டியலிடப்பட்ட காரணங்களுக்காக, இடது அருகிலுள்ள கே.வி.க்கு விருப்பம் கொடுங்கள்.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // உள் முனை திருடப்பட்டிருக்கலாம் அல்லது இணைக்கப்பட்டிருக்கலாம்.
        // அசல் கே.வி எங்கு முடிந்தது என்பதைக் கண்டுபிடிக்க வலதுபுறம் செல்லுங்கள்.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}