use core::intrinsics;
use core::mem;
use core::ptr;

/// இது தொடர்புடைய செயல்பாட்டை அழைப்பதன் மூலம் `v` தனித்துவமான குறிப்புக்கு பின்னால் உள்ள மதிப்பை மாற்றுகிறது.
///
///
/// `change` மூடுதலில் ஒரு panic ஏற்பட்டால், முழு செயல்முறையும் நிறுத்தப்படும்.
#[allow(dead_code)] // விளக்கமாகவும் future பயன்பாட்டிற்காகவும் வைக்கவும்
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// இது தொடர்புடைய செயல்பாட்டை அழைப்பதன் மூலம் `v` தனித்துவமான குறிப்புக்கு பின்னால் உள்ள மதிப்பை மாற்றுகிறது, மேலும் வழியில் பெறப்பட்ட முடிவை வழங்குகிறது.
///
///
/// `change` மூடுதலில் ஒரு panic ஏற்பட்டால், முழு செயல்முறையும் நிறுத்தப்படும்.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}