use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ஒரு உடன்பிறப்புடன் ஒன்றிணைவதன் மூலம் அல்லது திருடுவதன் மூலம் ஒரு குறைவான முனையை சேமிக்கிறது.
    /// வெற்றிகரமாக இருந்தால், ஆனால் பெற்றோர் முனையை சுருக்கும் செலவில், சுருங்கிய பெற்றோர் முனையைத் தருகிறது.
    /// முனை வெற்று மூலமாக இருந்தால் `Err` ஐ வழங்குகிறது.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// சாத்தியமான குறைவான முனையை சேமிக்கிறது, மேலும் அது அதன் பெற்றோர் முனை சுருங்கினால், பெற்றோரை மீண்டும் மீண்டும் சேமிக்கிறது.
    /// மரத்தை சரிசெய்தால் `true` ஐ வழங்குகிறது, ரூட் முனை காலியாகிவிட்டதால் `false` முடியவில்லை என்றால்.
    ///
    /// இந்த முறை மூதாதையர்கள் ஏற்கனவே நுழைந்ததும், வெற்று மூதாதையரை எதிர்கொண்டால் panics ஆனதும் குறைவாக இருக்கும் என்று எதிர்பார்க்கவில்லை.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// மேலே உள்ள வெற்று நிலைகளை நீக்குகிறது, ஆனால் முழு மரமும் காலியாக இருந்தால் வெற்று இலையை வைத்திருக்கும்.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// மரத்தின் வலது எல்லையில் ஏதேனும் குறைவான முனைகளை சேமித்து வைக்கவும் அல்லது இணைக்கவும்.
    /// மற்ற முனைகள், வேர் அல்லது வலதுபுறம் edge இல்லாதவை, ஏற்கனவே குறைந்தது MIN_LEN கூறுகளைக் கொண்டிருக்க வேண்டும்.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` இன் சமச்சீர் குளோன்.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// மரத்தின் வலது எல்லையில் ஏதேனும் குறைவான முனைகளை சேமிக்கவும்.
    /// மற்ற முனைகள், வேர் அல்லது வலதுபுறம் edge இல்லாதவை, MIN_LEN கூறுகள் வரை திருட தயாராக இருக்க வேண்டும்.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // சரியான குழந்தை மிகவும் குறைவாக இருக்கிறதா என்று சோதிக்கவும்.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // நாம் திருட வேண்டும்.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // மேலும் கீழே செல்லுங்கள்.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// இடது குழந்தையை சேமித்து வைப்பது, சரியான குழந்தை குறைவானதல்ல என்று கருதி, அதன் குழந்தைகளை ஒன்றிணைக்க அனுமதிக்காமல் கூடுதல் உறுப்பை வழங்குகிறது.
    ///
    /// இடது குழந்தையை வழங்குகிறது.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` அடுத்த நிலை ஒன்றிணைந்தால் மறுசீரமைப்பைத் தவிர்க்க.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// சரியான குழந்தையை சேமித்து வைத்து, இடது குழந்தை முழுமையடையாது என்று கருதி, அதன் குழந்தைகளை ஒன்றிணைக்க அனுமதிக்காமல் கூடுதல் உறுப்பை வழங்குகிறது.
    ///
    /// சரியான குழந்தை முடிந்த இடமெல்லாம் திரும்பும்.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` அடுத்த நிலை ஒன்றிணைந்தால் மறுசீரமைப்பைத் தவிர்க்க.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}