use core::borrow::Borrow;
use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, RangeBounds};
use core::ptr;

use super::borrow::DormantMutRef;
use super::navigate::LeafRange;
use super::node::{self, marker, ForceResult::*, Handle, NodeRef, Root};
use super::search::SearchResult::*;

mod entry;
pub use entry::{Entry, OccupiedEntry, OccupiedError, VacantEntry};
use Entry::*;

/// ரூட் இல்லாத முனைகளில் உள்ள குறைந்தபட்ச உறுப்புகளின் எண்ணிக்கை.
/// முறைகளின் போது தற்காலிகமாக குறைவான கூறுகளைக் கொண்டிருக்கலாம்.
pub(super) const MIN_LEN: usize = node::MIN_LEN_AFTER_SPLIT;

// `BTreeMap` இல் உள்ள ஒரு மரம் கூடுதல் மாற்றங்களுடன் கூடிய `node` தொகுதியில் உள்ள ஒரு மரமாகும்:
// - விசைகள் ஏறுவரிசையில் தோன்ற வேண்டும் (விசையின் வகைக்கு ஏற்ப).
// - ரூட் முனை அகமாக இருந்தால், அதில் குறைந்தது 1 உறுப்பு இருக்க வேண்டும்.
// - ஒவ்வொரு ரூட் அல்லாத முனையிலும் குறைந்தது MIN_LEN கூறுகள் உள்ளன.
//
// ஒரு வெற்று வரைபடம் ரூட் முனை இல்லாததால் அல்லது வெற்று இலை என்று ஒரு ரூட் முனை மூலம் குறிப்பிடப்படலாம்.
//

/// [B-Tree] ஐ அடிப்படையாகக் கொண்ட வரைபடம்.
///
/// பி-மரங்கள் கேச்-செயல்திறனுக்கும் ஒரு தேடலில் செய்யப்படும் வேலையின் அளவைக் குறைப்பதற்கும் இடையிலான ஒரு அடிப்படை சமரசத்தைக் குறிக்கின்றன.கோட்பாட்டில், ஒரு பைனரி தேடல் மரம் (BST) என்பது வரிசைப்படுத்தப்பட்ட வரைபடத்திற்கான உகந்த தேர்வாகும், ஏனெனில் ஒரு முழுமையான சீரான பிஎஸ்டி ஒரு உறுப்பு (log<sub>2</sub>n) ஐக் கண்டுபிடிக்க தேவையான தத்துவார்த்த குறைந்தபட்ச ஒப்பீடுகளை செய்கிறது.
/// இருப்பினும், நடைமுறையில் இது செய்யப்படும் முறை நவீன கணினி கட்டமைப்புகளுக்கு *மிகவும்* திறமையற்றது.
/// குறிப்பாக, ஒவ்வொரு தனிமமும் தனித்தனியாக குவியல்-ஒதுக்கப்பட்ட முனையில் சேமிக்கப்படுகிறது.
/// இதன் பொருள் ஒவ்வொரு செருகலும் ஒரு குவியல்-ஒதுக்கீட்டைத் தூண்டுகிறது, மேலும் ஒவ்வொரு ஒப்பீடும் ஒரு கேச்-மிஸ் ஆக இருக்க வேண்டும்.
/// இவை இரண்டும் நடைமுறையில் செய்ய வேண்டிய விலையுயர்ந்த விஷயங்கள் என்பதால், பிஎஸ்டி மூலோபாயத்தை குறைந்தபட்சம் மறுபரிசீலனை செய்ய வேண்டிய கட்டாயத்தில் இருக்கிறோம்.
///
/// அதற்கு பதிலாக ஒரு பி-ட்ரீ ஒவ்வொரு முனையிலும் தொடர்ச்சியான வரிசையில் B-1 முதல் 2B-1 கூறுகளைக் கொண்டிருக்கிறது.இதைச் செய்வதன் மூலம், ஒதுக்கீட்டின் எண்ணிக்கையை B இன் காரணி மூலம் குறைக்கிறோம், மேலும் தேடல்களில் கேச் செயல்திறனை மேம்படுத்துகிறோம்.இருப்பினும், தேடல்கள் சராசரியாக *அதிக* ஒப்பீடுகளைச் செய்ய வேண்டும் என்று இது அர்த்தப்படுத்துகிறது.
/// ஒப்பீடுகளின் துல்லியமான எண்ணிக்கை பயன்படுத்தப்படும் முனை தேடல் மூலோபாயத்தைப் பொறுத்தது.உகந்த கேச் செயல்திறனுக்காக, ஒருவர் முனைகளை நேரியல் முறையில் தேடலாம்.உகந்த ஒப்பீடுகளுக்கு, பைனரி தேடலைப் பயன்படுத்தி முனையைத் தேடலாம்.ஒரு சமரசமாக, ஒரு நேர்கோட்டுத் தேடலையும் ஒருவர் செய்ய முடியும், இது ஆரம்பத்தில் ஒவ்வொரு i <sup>வது</sup> உறுப்புகளையும் மட்டுமே தேர்வுசெய்கிறது.
///
/// தற்போது, எங்கள் செயல்படுத்தல் வெறுமனே நேரியல் தேடலை செய்கிறது.ஒப்பிடுவதற்கு மலிவான உறுப்புகளின் *சிறிய* முனைகளில் இது சிறந்த செயல்திறனை வழங்குகிறது.எவ்வாறாயினும், future இல், B இன் தேர்வு மற்றும் பிற காரணிகளின் அடிப்படையில் உகந்த தேடல் மூலோபாயத்தைத் தேர்ந்தெடுப்பதை மேலும் ஆராய விரும்புகிறோம்.நேரியல் தேடலைப் பயன்படுத்தி, ஒரு சீரற்ற உறுப்பைத் தேடுவது O(B * log(n)) ஒப்பீடுகளை எடுக்கும் என்று எதிர்பார்க்கப்படுகிறது, இது பொதுவாக பிஎஸ்டியை விட மோசமானது.
///
/// இருப்பினும், நடைமுறையில், செயல்திறன் சிறந்தது.
///
/// ஒரு விசையை மாற்றியமைப்பது ஒரு தர்க்கப் பிழையாகும், இது வேறு எந்த விசையுடனும் தொடர்புடைய விசையின் வரிசைப்படுத்தல், [`Ord`] trait ஆல் தீர்மானிக்கப்படுகிறது, அது வரைபடத்தில் இருக்கும்போது மாறுகிறது.இது பொதுவாக [`Cell`], [`RefCell`], உலகளாவிய நிலை, I/O அல்லது பாதுகாப்பற்ற குறியீடு மூலம் மட்டுமே சாத்தியமாகும்.
/// அத்தகைய தர்க்கப் பிழையின் விளைவாக ஏற்படும் நடத்தை குறிப்பிடப்படவில்லை, ஆனால் வரையறுக்கப்படாத நடத்தை ஏற்படாது.இதில் panics, தவறான முடிவுகள், நிறுத்தங்கள், நினைவக கசிவுகள் மற்றும் நிறுத்தப்படாதவை ஆகியவை அடங்கும்.
///
/// [B-Tree]: https://en.wikipedia.org/wiki/B-tree
/// [`Cell`]: core::cell::Cell
/// [`RefCell`]: core::cell::RefCell
///
/// # Examples
///
/// ```
/// use std::collections::BTreeMap;
///
/// // வகை அனுமானம் ஒரு வெளிப்படையான வகை கையொப்பத்தைத் தவிர்க்க எங்களுக்கு உதவுகிறது (இது இந்த எடுத்துக்காட்டில் `BTreeMap<&str, &str>` ஆக இருக்கும்).
/////
/// let mut movie_reviews = BTreeMap::new();
///
/// // சில திரைப்படங்களை மதிப்பாய்வு செய்யவும்.
/// movie_reviews.insert("Office Space",       "Deals with real issues in the workplace.");
/// movie_reviews.insert("Pulp Fiction",       "Masterpiece.");
/// movie_reviews.insert("The Godfather",      "Very enjoyable.");
/// movie_reviews.insert("The Blues Brothers", "Eye lyked it a lot.");
///
/// // ஒரு குறிப்பிட்ட ஒன்றை சரிபார்க்கவும்.
/// if !movie_reviews.contains_key("Les Misérables") {
///     println!("We've got {} reviews, but Les Misérables ain't one.",
///              movie_reviews.len());
/// }
///
/// // அச்சச்சோ, இந்த மதிப்பாய்வில் நிறைய எழுத்துப்பிழைகள் உள்ளன, அதை நீக்குவோம்.
/// movie_reviews.remove("The Blues Brothers");
///
/// // சில விசைகளுடன் தொடர்புடைய மதிப்புகளைப் பாருங்கள்.
/// let to_find = ["Up!", "Office Space"];
/// for movie in &to_find {
///     match movie_reviews.get(movie) {
///        Some(review) => println!("{}: {}", movie, review),
///        None => println!("{} is unreviewed.", movie)
///     }
/// }
///
/// // ஒரு விசையின் மதிப்பைப் பாருங்கள் (விசை கிடைக்கவில்லை என்றால் panic இருக்கும்).
/// println!("Movie review: {}", movie_reviews["Office Space"]);
///
/// // எல்லாவற்றையும் மீண்டும் கூறுங்கள்.
/// for (movie, review) in &movie_reviews {
///     println!("{}: \"{}\"", movie, review);
/// }
/// ```
///
/// `BTreeMap` ஒரு [`Entry API`] ஐ செயல்படுத்துகிறது, இது விசைகள் மற்றும் அவற்றின் மதிப்புகளைப் பெறுதல், அமைத்தல், புதுப்பித்தல் மற்றும் நீக்குதல் போன்ற சிக்கலான முறைகளை அனுமதிக்கிறது:
///
/// [`Entry API`]: BTreeMap::entry
///
/// ```
/// use std::collections::BTreeMap;
///
/// // வகை அனுமானம் ஒரு வெளிப்படையான வகை கையொப்பத்தைத் தவிர்க்க எங்களுக்கு உதவுகிறது (இது இந்த எடுத்துக்காட்டில் `BTreeMap<&str, u8>` ஆக இருக்கும்).
/////
/// let mut player_stats = BTreeMap::new();
///
/// fn random_stat_buff() -> u8 {
///     // உண்மையில் இங்கே சில சீரற்ற மதிப்பைத் தரலாம், இப்போது சில நிலையான மதிப்பைத் தருகிறோம்
/////
///     42
/// }
///
/// // ஒரு விசையை ஏற்கனவே இல்லாவிட்டால் மட்டுமே செருகவும்
/// player_stats.entry("health").or_insert(100);
///
/// // ஏற்கனவே இல்லாதிருந்தால் மட்டுமே புதிய மதிப்பை வழங்கும் செயல்பாட்டைப் பயன்படுத்தி ஒரு விசையைச் செருகவும்
/////
/// player_stats.entry("defence").or_insert_with(random_stat_buff);
///
/// // ஒரு விசையை புதுப்பிக்கவும், விசையை அமைக்காமல் பாதுகாக்கவும்
/// let stat = player_stats.entry("attack").or_insert(100);
/// *stat += random_stat_buff();
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BTreeMap")]
pub struct BTreeMap<K, V> {
    root: Option<Root<K, V>>,
    length: usize,
}

#[stable(feature = "btree_drop", since = "1.7.0")]
unsafe impl<#[may_dangle] K, #[may_dangle] V> Drop for BTreeMap<K, V> {
    fn drop(&mut self) {
        if let Some(root) = self.root.take() {
            Dropper { front: root.into_dying().first_leaf_edge(), remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Clone, V: Clone> Clone for BTreeMap<K, V> {
    fn clone(&self) -> BTreeMap<K, V> {
        fn clone_subtree<'a, K: Clone, V: Clone>(
            node: NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal>,
        ) -> BTreeMap<K, V>
        where
            K: 'a,
            V: 'a,
        {
            match node.force() {
                Leaf(leaf) => {
                    let mut out_tree = BTreeMap { root: Some(Root::new()), length: 0 };

                    {
                        let root = out_tree.root.as_mut().unwrap(); // நாம் இப்போது போர்த்தப்பட்டதால் அவிழ்ப்பது வெற்றி பெறுகிறது
                        let mut out_node = match root.borrow_mut().force() {
                            Leaf(leaf) => leaf,
                            Internal(_) => unreachable!(),
                        };

                        let mut in_edge = leaf.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            out_node.push(k.clone(), v.clone());
                            out_tree.length += 1;
                        }
                    }

                    out_tree
                }
                Internal(internal) => {
                    let mut out_tree = clone_subtree(internal.first_edge().descend());

                    {
                        let out_root = BTreeMap::ensure_is_owned(&mut out_tree.root);
                        let mut out_node = out_root.push_internal_level();
                        let mut in_edge = internal.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            let k = (*k).clone();
                            let v = (*v).clone();
                            let subtree = clone_subtree(in_edge.descend());

                            // BTreeMap டிராப்பை செயல்படுத்துவதால் நாம் நேரடியாக சப்டிரீயை அழிக்க முடியாது
                            //
                            let (subroot, sublength) = unsafe {
                                let subtree = ManuallyDrop::new(subtree);
                                let root = ptr::read(&subtree.root);
                                let length = subtree.length;
                                (root, length)
                            };

                            out_node.push(k, v, subroot.unwrap_or_else(Root::new));
                            out_tree.length += 1 + sublength;
                        }
                    }

                    out_tree
                }
            }
        }

        if self.is_empty() {
            // வெறுமனே நாங்கள் இங்கே `BTreeMap::new` ஐ அழைக்கிறோம், ஆனால் அதற்கு `K:
            // இந்த முறை இல்லாத ஆர்ட்` கட்டுப்பாடு.
            BTreeMap { root: None, length: 0 }
        } else {
            clone_subtree(self.root.as_ref().unwrap().reborrow()) // அவிழ் வெற்றிடமாக இருப்பதால் வெற்றி பெறுகிறது
        }
    }
}

impl<K, Q: ?Sized> super::Recover<Q> for BTreeMap<K, ()>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Key = K;

    fn get(&self, key: &Q) -> Option<&K> {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().0),
            GoDown(_) => None,
        }
    }

    fn take(&mut self, key: &Q) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_kv().0)
            }
            GoDown(_) => None,
        }
    }

    fn replace(&mut self, key: K) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree::<K>(&key) {
            Found(mut kv) => Some(mem::replace(kv.key_mut(), key)),
            GoDown(handle) => {
                VacantEntry { key, handle, dormant_map, _marker: PhantomData }.insert(());
                None
            }
        }
    }
}

/// ஒரு `BTreeMap` இன் உள்ளீடுகளுக்கு மேல் ஒரு ஈரேட்டர்.
///
/// இந்த `struct` [`BTreeMap`] இல் [`iter`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`iter`]: BTreeMap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, K: 'a, V: 'a> {
    range: Range<'a, K, V>,
    length: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Iter<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// `BTreeMap` இன் உள்ளீடுகளுக்கு மேல் ஒரு மாற்றக்கூடிய மறு செய்கை.
///
/// இந்த `struct` [`BTreeMap`] இல் [`iter_mut`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`iter_mut`]: BTreeMap::iter_mut
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, K: 'a, V: 'a> {
    range: RangeMut<'a, K, V>,
    length: usize,
}

/// ஒரு `BTreeMap` இன் உள்ளீடுகளுக்கு சொந்தமான மறு செய்கை.
///
/// இந்த `struct` [`BTreeMap`] இல் [`into_iter`] முறையால் உருவாக்கப்பட்டது (`IntoIterator` trait ஆல் வழங்கப்படுகிறது).
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`into_iter`]: IntoIterator::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<K, V> {
    range: LeafRange<marker::Dying, K, V>,
    length: usize,
}

impl<K, V> IntoIter<K, V> {
    /// மீதமுள்ள உருப்படிகளின் குறிப்புகளின் மறு செய்கையை வழங்குகிறது.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        let range = Range { inner: self.range.reborrow() };
        Iter { range: range, length: self.length }
    }
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for IntoIter<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

/// `IntoIter` இன் எளிமைப்படுத்தப்பட்ட பதிப்பு இரட்டை முடிவடையாதது மற்றும் ஒரே ஒரு நோக்கத்தைக் கொண்டுள்ளது: ஒரு `IntoIter` இன் எஞ்சியதை கைவிட.
/// எனவே முதலில் ஒரு `back` இலை edge ஐப் பார்க்க வேண்டிய அவசியமின்றி ஒரு முழு மரத்தையும் கைவிட உதவுகிறது.
///
struct Dropper<K, V> {
    front: Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge>,
    remaining_length: usize,
}

/// ஒரு `BTreeMap` இன் விசைகளுக்கு மேல் ஒரு ஈரேட்டர்.
///
/// இந்த `struct` [`BTreeMap`] இல் [`keys`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`keys`]: BTreeMap::keys
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Keys<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V> fmt::Debug for Keys<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ஒரு `BTreeMap` இன் மதிப்புகள் மீது ஒரு ஈரேட்டர்.
///
/// இந்த `struct` [`BTreeMap`] இல் [`values`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`values`]: BTreeMap::values
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Values<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K, V: fmt::Debug> fmt::Debug for Values<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ஒரு `BTreeMap` இன் மதிப்புகள் மீது ஒரு மாற்றக்கூடிய மறு செய்கை.
///
/// இந்த `struct` [`BTreeMap`] இல் [`values_mut`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`values_mut`]: BTreeMap::values_mut
#[stable(feature = "map_values_mut", since = "1.10.0")]
pub struct ValuesMut<'a, K: 'a, V: 'a> {
    inner: IterMut<'a, K, V>,
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V: fmt::Debug> fmt::Debug for ValuesMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// ஒரு `BTreeMap` இன் விசைகளுக்கு மேல் ஒரு சொந்த ஈரேட்டர்.
///
/// இந்த `struct` [`BTreeMap`] இல் [`into_keys`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`into_keys`]: BTreeMap::into_keys
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoKeys<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K: fmt::Debug, V> fmt::Debug for IntoKeys<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(key, _)| key)).finish()
    }
}

/// ஒரு `BTreeMap` இன் மதிப்புகள் மீது சொந்தமான ஈரேட்டர்.
///
/// இந்த `struct` [`BTreeMap`] இல் [`into_values`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`into_values`]: BTreeMap::into_values
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoValues<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V: fmt::Debug> fmt::Debug for IntoValues<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// ஒரு `BTreeMap` இல் உள்ளீடுகளின் துணை வரம்பில் ஒரு ஈரேட்டர்.
///
/// இந்த `struct` [`BTreeMap`] இல் [`range`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`range`]: BTreeMap::range
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct Range<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::Immut<'a>, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Range<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ஒரு `BTreeMap` இல் உள்ள துணை வரம்புகளின் உள்ளீடுகளை மாற்றக்கூடிய மறு செய்கை.
///
/// இந்த `struct` [`BTreeMap`] இல் [`range_mut`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`range_mut`]: BTreeMap::range_mut
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct RangeMut<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::ValMut<'a>, K, V>,

    // `K` மற்றும் `V` இல் மாறாமல் இருங்கள்
    _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for RangeMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let range = Range { inner: self.inner.reborrow() };
        f.debug_list().entries(range).finish()
    }
}

impl<K, V> BTreeMap<K, V> {
    /// புதிய, வெற்று `BTreeMap` ஐ உருவாக்குகிறது.
    ///
    /// எதையும் சொந்தமாக ஒதுக்கவில்லை.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    ///
    /// // உள்ளீடுகளை இப்போது வெற்று வரைபடத்தில் செருகலாம்
    /// map.insert(1, "a");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn new() -> BTreeMap<K, V>
    where
        K: Ord,
    {
        BTreeMap { root: None, length: 0 }
    }

    /// எல்லா உறுப்புகளையும் நீக்கி, வரைபடத்தை அழிக்கிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.clear();
    /// assert!(a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = BTreeMap { root: None, length: 0 };
    }

    /// விசையுடன் தொடர்புடைய மதிப்புக்கு ஒரு குறிப்பை வழங்குகிறது.
    ///
    /// விசையானது வரைபடத்தின் முக்கிய வகையின் எந்தவொரு கடன் வாங்கிய வடிவமாக இருக்கலாம், ஆனால் கடன் வாங்கிய படிவத்தின் வரிசைப்படுத்தல் * முக்கிய வகையின் வரிசைப்படுத்தலுடன் பொருந்த வேண்டும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get(&1), Some(&"a"));
    /// assert_eq!(map.get(&2), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get<Q: ?Sized>(&self, key: &Q) -> Option<&V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().1),
            GoDown(_) => None,
        }
    }

    /// வழங்கப்பட்ட விசையுடன் தொடர்புடைய விசை-மதிப்பு ஜோடியை வழங்குகிறது.
    ///
    /// வழங்கப்பட்ட விசையானது வரைபடத்தின் முக்கிய வகையின் கடன் வாங்கிய வடிவமாக இருக்கலாம், ஆனால் கடன் வாங்கிய படிவத்தில் வரிசைப்படுத்துதல் * முக்கிய வகையின் வரிசைப்படுத்தலுடன் பொருந்த வேண்டும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get_key_value(&1), Some((&1, &"a")));
    /// assert_eq!(map.get_key_value(&2), None);
    /// ```
    #[stable(feature = "map_get_key_value", since = "1.40.0")]
    pub fn get_key_value<Q: ?Sized>(&self, k: &Q) -> Option<(&K, &V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(k) {
            Found(handle) => Some(handle.into_kv()),
            GoDown(_) => None,
        }
    }

    /// வரைபடத்தில் முதல் விசை மதிப்பு ஜோடியை வழங்குகிறது.
    /// இந்த ஜோடியின் விசை வரைபடத்தில் குறைந்தபட்ச விசையாகும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.first_key_value(), None);
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.first_key_value(), Some((&1, &"b")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.first_leaf_edge().right_kv().ok().map(Handle::into_kv)
    }

    /// இடத்திலுள்ள கையாளுதலுக்கான வரைபடத்தில் முதல் உள்ளீட்டை வழங்குகிறது.
    /// இந்த இடுகையின் திறவுகோல் வரைபடத்தில் குறைந்தபட்ச விசையாகும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.first_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("first");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "first");
    /// assert_eq!(*map.get(&2).unwrap(), "b");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.first_leaf_edge().right_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// வரைபடத்தில் முதல் உறுப்பை அகற்றி வழங்குகிறது.
    /// இந்த உறுப்பு முக்கியமானது வரைபடத்தில் இருந்த குறைந்தபட்ச விசையாகும்.
    ///
    /// # Examples
    ///
    /// ஒவ்வொரு மறு செய்கையையும் பயன்படுத்தக்கூடிய வரைபடத்தை வைத்திருக்கும்போது, உறுப்புகளை ஏறுவரிசையில் வடிகட்டுதல்.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_first() {
    ///     assert!(map.iter().all(|(k, _v)| *k > key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_first(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.first_entry().map(|entry| entry.remove_entry())
    }

    /// வரைபடத்தில் கடைசி விசை மதிப்பு ஜோடியை வழங்குகிறது.
    /// இந்த ஜோடியின் விசை வரைபடத்தில் அதிகபட்ச விசையாகும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.last_key_value(), Some((&2, &"a")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.last_leaf_edge().left_kv().ok().map(Handle::into_kv)
    }

    /// இடத்திலுள்ள கையாளுதலுக்கான வரைபடத்தின் கடைசி உள்ளீட்டை வழங்குகிறது.
    /// இந்த இடுகையின் முக்கிய வரைபடத்தில் அதிகபட்ச விசை.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.last_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("last");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "a");
    /// assert_eq!(*map.get(&2).unwrap(), "last");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.last_leaf_edge().left_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// வரைபடத்தின் கடைசி உறுப்பை அகற்றி திருப்பித் தருகிறது.
    /// இந்த உறுப்பு முக்கியமானது வரைபடத்தில் இருந்த அதிகபட்ச விசையாகும்.
    ///
    /// # Examples
    ///
    /// ஒவ்வொரு மறு செய்கையும் பயன்படுத்தக்கூடிய வரைபடத்தை வைத்திருக்கும்போது, உறுப்புகளை இறங்கு வரிசையில் வடிகட்டுதல்.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_last() {
    ///     assert!(map.iter().all(|(k, _v)| *k < key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_last(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.last_entry().map(|entry| entry.remove_entry())
    }

    /// குறிப்பிட்ட விசையின் வரைபடத்தில் மதிப்பு இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// விசையானது வரைபடத்தின் முக்கிய வகையின் எந்தவொரு கடன் வாங்கிய வடிவமாக இருக்கலாம், ஆனால் கடன் வாங்கிய படிவத்தின் வரிசைப்படுத்தல் * முக்கிய வகையின் வரிசைப்படுத்தலுடன் பொருந்த வேண்டும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.contains_key(&1), true);
    /// assert_eq!(map.contains_key(&2), false);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn contains_key<Q: ?Sized>(&self, key: &Q) -> bool
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.get(key).is_some()
    }

    /// விசையுடன் தொடர்புடைய மதிப்புக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// விசையானது வரைபடத்தின் முக்கிய வகையின் எந்தவொரு கடன் வாங்கிய வடிவமாக இருக்கலாம், ஆனால் கடன் வாங்கிய படிவத்தின் வரிசைப்படுத்தல் * முக்கிய வகையின் வரிசைப்படுத்தலுடன் பொருந்த வேண்டும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// if let Some(x) = map.get_mut(&1) {
    ///     *x = "b";
    /// }
    /// assert_eq!(map[&1], "b");
    /// ```
    // செயல்படுத்தல் குறிப்புகளுக்கு `get` ஐப் பார்க்கவும், இது அடிப்படையில் மட் சேர்க்கப்பட்ட நகல்-பேஸ்ட் ஆகும்
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut<Q: ?Sized>(&mut self, key: &Q) -> Option<&mut V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_val_mut()),
            GoDown(_) => None,
        }
    }

    /// ஒரு முக்கிய மதிப்பு ஜோடியை வரைபடத்தில் செருகும்.
    ///
    /// வரைபடத்தில் இந்த விசை இல்லை என்றால், `None` திரும்பும்.
    ///
    /// வரைபடத்தில் இந்த விசை இருந்தால், மதிப்பு புதுப்பிக்கப்பட்டு, பழைய மதிப்பு திரும்பப் பெறப்படும்.
    /// விசை புதுப்பிக்கப்படவில்லை;ஒரே மாதிரியாக இல்லாமல் `==` ஆக இருக்கும் வகைகளுக்கு இது முக்கியமானது.
    ///
    /// மேலும் அறிய [module-level documentation] ஐப் பார்க்கவும்.
    ///
    /// [module-level documentation]: index.html#insert-and-complex-keys
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.insert(37, "a"), None);
    /// assert_eq!(map.is_empty(), false);
    ///
    /// map.insert(37, "b");
    /// assert_eq!(map.insert(37, "c"), Some("b"));
    /// assert_eq!(map[&37], "c");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, key: K, value: V) -> Option<V>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(mut entry) => Some(entry.insert(value)),
            Vacant(entry) => {
                entry.insert(value);
                None
            }
        }
    }

    /// ஒரு முக்கிய மதிப்பு ஜோடியை வரைபடத்தில் செருக முயற்சிக்கிறது, மேலும் உள்ளீட்டின் மதிப்புக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// வரைபடத்தில் ஏற்கனவே இந்த விசை இருந்தால், எதுவும் புதுப்பிக்கப்படவில்லை, மேலும் ஆக்கிரமிக்கப்பட்ட நுழைவு மற்றும் மதிப்பைக் கொண்ட பிழை திரும்பப் பெறப்படும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(map_try_insert)]
    ///
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.try_insert(37, "a").unwrap(), &"a");
    ///
    /// let err = map.try_insert(37, "b").unwrap_err();
    /// assert_eq!(err.entry.key(), &37);
    /// assert_eq!(err.entry.get(), &"a");
    /// assert_eq!(err.value, "b");
    /// ```
    ///
    #[unstable(feature = "map_try_insert", issue = "82766")]
    pub fn try_insert(&mut self, key: K, value: V) -> Result<&mut V, OccupiedError<'_, K, V>>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(entry) => Err(OccupiedError { entry, value }),
            Vacant(entry) => Ok(entry.insert(value)),
        }
    }

    /// வரைபடத்திலிருந்து ஒரு விசையை நீக்கி, விசை முன்பு வரைபடத்தில் இருந்திருந்தால், விசையின் மதிப்பை திருப்பித் தருகிறது.
    ///
    /// விசையானது வரைபடத்தின் முக்கிய வகையின் எந்தவொரு கடன் வாங்கிய வடிவமாக இருக்கலாம், ஆனால் கடன் வாங்கிய படிவத்தின் வரிசைப்படுத்தல் * முக்கிய வகையின் வரிசைப்படுத்தலுடன் பொருந்த வேண்டும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove(&1), Some("a"));
    /// assert_eq!(map.remove(&1), None);
    /// ```
    ///
    #[doc(alias = "delete")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove<Q: ?Sized>(&mut self, key: &Q) -> Option<V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.remove_entry(key).map(|(_, v)| v)
    }

    /// வரைபடத்திலிருந்து ஒரு விசையை நீக்கி, சேமிக்கப்பட்ட விசையையும் மதிப்பையும் வரைபடத்தில் முன்பு வைத்திருந்தால் திருப்பித் தருகிறது.
    ///
    /// விசையானது வரைபடத்தின் முக்கிய வகையின் எந்தவொரு கடன் வாங்கிய வடிவமாக இருக்கலாம், ஆனால் கடன் வாங்கிய படிவத்தின் வரிசைப்படுத்தல் * முக்கிய வகையின் வரிசைப்படுத்தலுடன் பொருந்த வேண்டும்.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove_entry(&1), Some((1, "a")));
    /// assert_eq!(map.remove_entry(&1), None);
    /// ```
    ///
    #[stable(feature = "btreemap_remove_entry", since = "1.45.0")]
    pub fn remove_entry<Q: ?Sized>(&mut self, key: &Q) -> Option<(K, V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_entry())
            }
            GoDown(_) => None,
        }
    }

    /// முன்னறிவிப்பால் குறிப்பிடப்பட்ட கூறுகளை மட்டுமே வைத்திருக்கிறது.
    ///
    /// வேறு வார்த்தைகளில் கூறுவதானால், `f(&k, &mut v)` அனைத்து ஜோடிகளையும் அகற்றவும், அதாவது `f(&k, &mut v)` `false` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(btree_retain)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x*10)).collect();
    /// // சம எண்ணிக்கையிலான விசைகளைக் கொண்ட உறுப்புகளை மட்டும் வைத்திருங்கள்.
    /// map.retain(|&k, _| k % 2 == 0);
    /// assert!(map.into_iter().eq(vec![(0, 0), (2, 20), (4, 40), (6, 60)]));
    /// ```
    #[inline]
    #[unstable(feature = "btree_retain", issue = "79025")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        self.drain_filter(|k, v| !f(k, v));
    }

    /// எல்லா உறுப்புகளையும் `other` இலிருந்து `Self` க்கு நகர்த்தி, `other` காலியாக இருக்கும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    ///
    /// let mut b = BTreeMap::new();
    /// b.insert(3, "d");
    /// b.insert(4, "e");
    /// b.insert(5, "f");
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.len(), 5);
    /// assert_eq!(b.len(), 0);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    /// assert_eq!(a[&3], "d");
    /// assert_eq!(a[&4], "e");
    /// assert_eq!(a[&5], "f");
    /// ```
    #[stable(feature = "btree_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self)
    where
        K: Ord,
    {
        // நாம் எதையும் சேர்க்க வேண்டுமா?
        if other.is_empty() {
            return;
        }

        // `self` காலியாக இருந்தால் நாம் `self` மற்றும் `other` ஐ மாற்றலாம்.
        if self.is_empty() {
            mem::swap(self, other);
            return;
        }

        let self_iter = mem::take(self).into_iter();
        let other_iter = mem::take(other).into_iter();
        let root = BTreeMap::ensure_is_owned(&mut self.root);
        root.append_from_sorted_iters(self_iter, other_iter, &mut self.length)
    }

    /// வரைபடத்தில் உள்ள துணை-வரம்பு கூறுகளின் மீது இரட்டை-முடிவான ஐரேட்டரை உருவாக்குகிறது.
    /// `min..max` வரம்பைப் பயன்படுத்துவதே எளிய வழி, இதனால் `range(min..max)` நிமிடம் (inclusive) முதல் அதிகபட்சம் (exclusive) வரையிலான கூறுகளை வழங்கும்.
    /// வரம்பு `(Bound<T>, Bound<T>)` ஆகவும் உள்ளிடப்படலாம், எனவே எடுத்துக்காட்டாக `range((Excluded(4), Included(10)))` 4 முதல் 10 வரை இடது-பிரத்தியேக, வலது உள்ளடக்கிய வரம்பைக் கொடுக்கும்.
    ///
    ///
    /// # Panics
    ///
    /// `start > end` வரம்பில் இருந்தால் Panics.
    /// `start == end` வரம்பு மற்றும் இரு எல்லைகளும் `Excluded` என்றால் Panics.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::ops::Bound::Included;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "a");
    /// map.insert(5, "b");
    /// map.insert(8, "c");
    /// for (&key, &value) in map.range((Included(&4), Included(&8))) {
    ///     println!("{}: {}", key, value);
    /// }
    /// assert_eq!(Some((&5, &"b")), map.range(4..).next());
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range<T: ?Sized, R>(&self, range: R) -> Range<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &self.root {
            Range { inner: root.reborrow().range_search(range) }
        } else {
            Range { inner: LeafRange::none() }
        }
    }

    /// வரைபடத்தில் உள்ள துணை-வரம்புக் கூறுகளின் மீது மாற்றக்கூடிய இரட்டை-முடிவு ஈரேட்டரை உருவாக்குகிறது.
    /// `min..max` வரம்பைப் பயன்படுத்துவதே எளிய வழி, இதனால் `range(min..max)` நிமிடம் (inclusive) முதல் அதிகபட்சம் (exclusive) வரையிலான கூறுகளை வழங்கும்.
    /// வரம்பு `(Bound<T>, Bound<T>)` ஆகவும் உள்ளிடப்படலாம், எனவே எடுத்துக்காட்டாக `range((Excluded(4), Included(10)))` 4 முதல் 10 வரை இடது-பிரத்தியேக, வலது உள்ளடக்கிய வரம்பைக் கொடுக்கும்.
    ///
    ///
    /// # Panics
    ///
    /// `start > end` வரம்பில் இருந்தால் Panics.
    /// `start == end` வரம்பு மற்றும் இரு எல்லைகளும் `Excluded` என்றால் Panics.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, i32> = ["Alice", "Bob", "Carol", "Cheryl"]
    ///     .iter()
    ///     .map(|&s| (s, 0))
    ///     .collect();
    /// for (_, balance) in map.range_mut("B".."Cheryl") {
    ///     *balance += 100;
    /// }
    /// for (name, balance) in &map {
    ///     println!("{} => {}", name, balance);
    /// }
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range_mut<T: ?Sized, R>(&mut self, range: R) -> RangeMut<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &mut self.root {
            RangeMut { inner: root.borrow_valmut().range_search(range), _marker: PhantomData }
        } else {
            RangeMut { inner: LeafRange::none(), _marker: PhantomData }
        }
    }

    /// இடத்திலுள்ள கையாளுதலுக்காக வரைபடத்தில் கொடுக்கப்பட்ட விசையின் தொடர்புடைய பதிவைப் பெறுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut count: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// // vec இல் உள்ள எழுத்துக்களின் நிகழ்வுகளின் எண்ணிக்கையை எண்ணுங்கள்
    /// for x in vec!["a", "b", "a", "c", "a", "b"] {
    ///     *count.entry(x).or_insert(0) += 1;
    /// }
    ///
    /// assert_eq!(count["a"], 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn entry(&mut self, key: K) -> Entry<'_, K, V>
    where
        K: Ord,
    {
        // FIXME(@porglezomp) நாங்கள் செருகவில்லை என்றால் ஒதுக்குவதைத் தவிர்க்கவும்
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree(&key) {
            Found(handle) => Occupied(OccupiedEntry { handle, dormant_map, _marker: PhantomData }),
            GoDown(handle) => {
                Vacant(VacantEntry { key, handle, dormant_map, _marker: PhantomData })
            }
        }
    }

    /// கொடுக்கப்பட்ட விசையில் சேகரிப்பை இரண்டாகப் பிரிக்கிறது.
    /// விசை உட்பட கொடுக்கப்பட்ட விசைக்குப் பிறகு எல்லாவற்றையும் வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    /// a.insert(17, "d");
    /// a.insert(41, "e");
    ///
    /// let b = a.split_off(&3);
    ///
    /// assert_eq!(a.len(), 2);
    /// assert_eq!(b.len(), 3);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    ///
    /// assert_eq!(b[&3], "c");
    /// assert_eq!(b[&17], "d");
    /// assert_eq!(b[&41], "e");
    /// ```
    #[stable(feature = "btree_split_off", since = "1.11.0")]
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q> + Ord,
    {
        if self.is_empty() {
            return Self::new();
        }

        let total_num = self.len();
        let left_root = self.root.as_mut().unwrap(); // அவிழ் வெற்றிடமாக இருப்பதால் வெற்றி பெறுகிறது

        let right_root = left_root.split_off(key);

        let (new_left_len, right_len) = Root::calc_split_length(total_num, &left_root, &right_root);
        self.length = new_left_len;

        BTreeMap { root: Some(right_root), length: right_len }
    }

    /// ஏறும் விசை வரிசையில் அனைத்து உறுப்புகளையும் (விசை-மதிப்பு ஜோடிகள்) பார்வையிடும் ஒரு ஈரேட்டரை உருவாக்குகிறது மற்றும் ஒரு உறுப்பு அகற்றப்பட வேண்டுமா என்பதை தீர்மானிக்க ஒரு மூடுதலைப் பயன்படுத்துகிறது.
    /// மூடல் `true` ஐ வழங்கினால், உறுப்பு வரைபடத்திலிருந்து அகற்றப்பட்டு வழங்கப்படுகிறது.
    /// மூடல் `false`, அல்லது panics ஐ வழங்கினால், உறுப்பு வரைபடத்தில் இருக்கும், அது வழங்கப்படாது.
    ///
    /// மூடுதலில் உள்ள ஒவ்வொரு தனிமத்தின் மதிப்பையும் மாற்றியமைக்க நீங்கள் அதை அனுமதிக்கிறீர்களா என்பதை பொருட்படுத்தாமல், அதை மாற்றவும் அனுமதிக்கிறது.
    ///
    /// ஈரேட்டர் ஓரளவு மட்டுமே நுகரப்பட்டால் அல்லது நுகரப்படாவிட்டால், மீதமுள்ள உறுப்புகள் ஒவ்வொன்றும் இன்னும் மூடலுக்கு உட்படுத்தப்படுகின்றன, இது அதன் மதிப்பை மாற்றக்கூடும், மேலும் `true` ஐ திருப்புவதன் மூலம், உறுப்பு அகற்றப்பட்டு கைவிடப்படும்.
    ///
    ///
    /// மூடுதலில் ஒரு panic ஏற்பட்டால், அல்லது ஒரு உறுப்பைக் கைவிடும்போது panic ஏற்பட்டால் அல்லது `DrainFilter` மதிப்பு கசிந்தால் இன்னும் எத்தனை கூறுகள் மூடலுக்கு உட்படுத்தப்படும் என்பது குறிப்பிடப்படவில்லை.
    ///
    /// # Examples
    ///
    /// ஒரு வரைபடத்தை சமமான மற்றும் ஒற்றைப்படை விசைகளாகப் பிரித்தல், அசல் வரைபடத்தை மீண்டும் பயன்படுத்துதல்:
    ///
    /// ```
    /// #![feature(btree_drain_filter)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x)).collect();
    /// let evens: BTreeMap<_, _> = map.drain_filter(|k, _v| k % 2 == 0).collect();
    /// let odds = map;
    /// assert_eq!(evens.keys().copied().collect::<Vec<_>>(), vec![0, 2, 4, 6]);
    /// assert_eq!(odds.keys().copied().collect::<Vec<_>>(), vec![1, 3, 5, 7]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "btree_drain_filter", issue = "70530")]
    pub fn drain_filter<F>(&mut self, pred: F) -> DrainFilter<'_, K, V, F>
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        DrainFilter { pred, inner: self.drain_filter_inner() }
    }

    pub(super) fn drain_filter_inner(&mut self) -> DrainFilterInner<'_, K, V>
    where
        K: Ord,
    {
        if let Some(root) = self.root.as_mut() {
            let (root, dormant_root) = DormantMutRef::new(root);
            let front = root.borrow_mut().first_leaf_edge();
            DrainFilterInner {
                length: &mut self.length,
                dormant_root: Some(dormant_root),
                cur_leaf_edge: Some(front),
            }
        } else {
            DrainFilterInner { length: &mut self.length, dormant_root: None, cur_leaf_edge: None }
        }
    }

    /// வரிசைப்படுத்தப்பட்ட வரிசையில், அனைத்து விசைகளையும் பார்வையிடும் நுகர்வு ஈரேட்டரை உருவாக்குகிறது.
    /// இதை அழைத்த பிறகு வரைபடத்தைப் பயன்படுத்த முடியாது.
    /// ஈரேட்டர் உறுப்பு வகை `K` ஆகும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<i32> = a.into_keys().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_keys(self) -> IntoKeys<K, V> {
        IntoKeys { inner: self.into_iter() }
    }

    /// விசையின் அடிப்படையில், அனைத்து மதிப்புகளையும் பார்வையிடும் நுகர்வு ஈரேட்டரை உருவாக்குகிறது.
    /// இதை அழைத்த பிறகு வரைபடத்தைப் பயன்படுத்த முடியாது.
    /// ஈரேட்டர் உறுப்பு வகை `V` ஆகும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.into_values().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_values(self) -> IntoValues<K, V> {
        IntoValues { inner: self.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a BTreeMap<K, V> {
    type Item = (&'a K, &'a V);
    type IntoIter = Iter<'a, K, V>;

    fn into_iter(self) -> Iter<'a, K, V> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for Iter<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Iter<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for Iter<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Iter<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Iter<'_, K, V> {
    fn clone(&self) -> Self {
        Iter { range: self.range.clone(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a mut BTreeMap<K, V> {
    type Item = (&'a K, &'a mut V);
    type IntoIter = IterMut<'a, K, V>;

    fn into_iter(self) -> IterMut<'a, K, V> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for IterMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for IterMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IterMut<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IterMut<'_, K, V> {}

impl<'a, K, V> IterMut<'a, K, V> {
    /// மீதமுள்ள உருப்படிகளின் குறிப்புகளின் மறு செய்கையை வழங்குகிறது.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        Iter { range: self.range.iter(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> IntoIterator for BTreeMap<K, V> {
    type Item = (K, V);
    type IntoIter = IntoIter<K, V>;

    fn into_iter(self) -> IntoIter<K, V> {
        let mut me = ManuallyDrop::new(self);
        if let Some(root) = me.root.take() {
            let full_range = root.into_dying().full_range();

            IntoIter { range: full_range, length: me.length }
        } else {
            IntoIter { range: LeafRange::none(), length: 0 }
        }
    }
}

impl<K, V> Drop for Dropper<K, V> {
    fn drop(&mut self) {
        // இணைக்காத மறு செய்கையை முன்னேற்றுவதைப் போன்றது.
        fn next_or_end<K, V>(this: &mut Dropper<K, V>) -> Option<(K, V)> {
            if this.remaining_length == 0 {
                unsafe { ptr::read(&this.front).deallocating_end() }
                None
            } else {
                this.remaining_length -= 1;
                Some(unsafe { this.front.deallocating_next_unchecked() })
            }
        }

        struct DropGuard<'a, K, V>(&'a mut Dropper<K, V>);

        impl<'a, K, V> Drop for DropGuard<'a, K, V> {
            fn drop(&mut self) {
                // நாங்கள் கீழே செய்யும் அதே சுழற்சியைத் தொடரவும்.
                // இது பிரிக்கப்படும்போது மட்டுமே இயங்கும், எனவே இந்த நேரத்தில் panics ஐப் பற்றி நாம் கவலைப்பட வேண்டியதில்லை (அவை நிறுத்தப்படும்).
                while let Some(_pair) = next_or_end(&mut self.0) {}
            }
        }

        while let Some(pair) = next_or_end(self) {
            let guard = DropGuard(self);
            drop(pair);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "btree_drop", since = "1.7.0")]
impl<K, V> Drop for IntoIter<K, V> {
    fn drop(&mut self) {
        if let Some(front) = self.range.front.take() {
            Dropper { front, remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Iterator for IntoIter<K, V> {
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.front.as_mut().unwrap().deallocating_next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> DoubleEndedIterator for IntoIter<K, V> {
    fn next_back(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.back.as_mut().unwrap().deallocating_next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IntoIter<K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IntoIter<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Keys<'a, K, V> {
    type Item = &'a K;

    fn next(&mut self) -> Option<&'a K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a K> {
        self.next_back()
    }

    fn min(mut self) -> Option<&'a K> {
        self.next()
    }

    fn max(mut self) -> Option<&'a K> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Keys<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Keys<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Keys<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Keys<'_, K, V> {
    fn clone(&self) -> Self {
        Keys { inner: self.inner.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Values<'a, K, V> {
    type Item = &'a V;

    fn next(&mut self) -> Option<&'a V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a V> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Values<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Values<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Values<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Values<'_, K, V> {
    fn clone(&self) -> Self {
        Values { inner: self.inner.clone() }
    }
}

/// BTreeMap இல் `drain_filter` ஐ அழைப்பதன் மூலம் தயாரிக்கப்படும் ஒரு ஈரேட்டர்.
#[unstable(feature = "btree_drain_filter", issue = "70530")]
pub struct DrainFilter<'a, K, V, F>
where
    K: 'a,
    V: 'a,
    F: 'a + FnMut(&K, &mut V) -> bool,
{
    pred: F,
    inner: DrainFilterInner<'a, K, V>,
}
/// டிரைன்ஃபில்டரின் பெரும்பாலான செயல்பாடுகள் முன்கணிப்பு வகையை விட பொதுவானவை, இதனால் BTreeSet::DrainFilter க்கும் சேவை செய்கிறது.
///
pub(super) struct DrainFilterInner<'a, K: 'a, V: 'a> {
    /// கடன் வாங்கிய வரைபடத்தில் நீள புலத்தைப் பற்றிய குறிப்பு, நேரலையில் புதுப்பிக்கப்பட்டது.
    length: &'a mut usize,
    /// கடன் வாங்கிய வரைபடத்தில் ரூட் புலத்தைப் பற்றிய குறிப்பு.
    /// டிராப் ஹேண்ட்லரை `take` க்கு அனுமதிக்க `Option` இல் மூடப்பட்டிருக்கும்.
    dormant_root: Option<DormantMutRef<'a, Root<K, V>>>,
    /// அடுத்த உறுப்பு திரும்புவதற்கு முந்தைய edge அல்லது கடைசி இலை edge ஐக் கொண்டுள்ளது.
    /// வரைபடத்திற்கு வேர் இல்லாவிட்டால், மறு செய்கை கடைசி இலை edge ஐத் தாண்டிவிட்டால் அல்லது முன்னறிவிப்பில் panic ஏற்பட்டால் காலியாக இருக்கும்.
    ///
    cur_leaf_edge: Option<Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>>,
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Drop for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    fn drop(&mut self) {
        self.for_each(drop);
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> fmt::Debug for DrainFilter<'_, K, V, F>
where
    K: fmt::Debug,
    V: fmt::Debug,
    F: FnMut(&K, &mut V) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.inner.peek()).finish()
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Iterator for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        self.inner.next(&mut self.pred)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

impl<'a, K: 'a, V: 'a> DrainFilterInner<'a, K, V> {
    /// பிழைத்திருத்த செயலாக்கங்களை அடுத்த உறுப்பைக் கணிக்க அனுமதிக்கவும்.
    pub(super) fn peek(&self) -> Option<(&K, &V)> {
        let edge = self.cur_leaf_edge.as_ref()?;
        edge.reborrow().next_kv().ok().map(Handle::into_kv)
    }

    /// ஒரு பொதுவான `DrainFilter::next` முறையை செயல்படுத்துதல், முன்னறிவிப்பு கொடுக்கப்பட்டால்.
    pub(super) fn next<F>(&mut self, pred: &mut F) -> Option<(K, V)>
    where
        F: FnMut(&K, &mut V) -> bool,
    {
        while let Ok(mut kv) = self.cur_leaf_edge.take()?.next_kv() {
            let (k, v) = kv.kv_mut();
            if pred(k, v) {
                *self.length -= 1;
                let (kv, pos) = kv.remove_kv_tracking(|| {
                    // பாதுகாப்பு: வேரைத் தொடாத வகையில் தொடுவோம்
                    // திரும்பிய நிலையை செல்லாததாக்கு.
                    let root = unsafe { self.dormant_root.take().unwrap().awaken() };
                    root.pop_internal_level();
                    self.dormant_root = Some(DormantMutRef::new(root).1);
                });
                self.cur_leaf_edge = Some(pos);
                return Some(kv);
            }
            self.cur_leaf_edge = Some(kv.next_leaf_edge());
        }
        None
    }

    /// ஒரு பொதுவான `DrainFilter::size_hint` முறையை செயல்படுத்துதல்.
    pub(super) fn size_hint(&self) -> (usize, Option<usize>) {
        // பெரும்பாலான btree iterator களில், `self.length` என்பது இன்னும் பார்வையிட வேண்டிய உறுப்புகளின் எண்ணிக்கை.
        // இங்கே, இது பார்வையிட்ட கூறுகளை உள்ளடக்கியது மற்றும் drain வேண்டாம் என்று முன்னறிவிப்பு முடிவு செய்தது.
        // இந்த மேல் வரம்பை மிகவும் துல்லியமாக்குவதற்கு கூடுதல் புலத்தை பராமரிக்க வேண்டும், அதே நேரத்தில் மதிப்பு இல்லை.
        //
        (0, Some(*self.length))
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> FusedIterator for DrainFilter<'_, K, V, F> where F: FnMut(&K, &mut V) -> bool {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for Range<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> Iterator for ValuesMut<'a, K, V> {
    type Item = &'a mut V;

    fn next(&mut self) -> Option<&'a mut V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a mut V> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> DoubleEndedIterator for ValuesMut<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a mut V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V> ExactSizeIterator for ValuesMut<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for ValuesMut<'_, K, V> {}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoKeys<K, V> {
    type Item = K;

    fn next(&mut self) -> Option<K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<K> {
        self.next_back()
    }

    fn min(mut self) -> Option<K> {
        self.next()
    }

    fn max(mut self) -> Option<K> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoKeys<K, V> {
    fn next_back(&mut self) -> Option<K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoKeys<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoKeys<K, V> {}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoValues<K, V> {
    type Item = V;

    fn next(&mut self) -> Option<V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<V> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoValues<K, V> {
    fn next_back(&mut self) -> Option<V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoValues<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoValues<K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for Range<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Range<'_, K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<K, V> Clone for Range<'_, K, V> {
    fn clone(&self) -> Self {
        Range { inner: LeafRange { front: self.inner.front, back: self.inner.back } }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for RangeMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }

    /// மீதமுள்ள உருப்படிகளின் குறிப்புகளின் மறு செய்கையை வழங்குகிறது.
    #[inline]
    pub(super) fn iter(&self) -> Range<'_, K, V> {
        Range { inner: self.inner.reborrow() }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for RangeMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for RangeMut<'_, K, V> {}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> FromIterator<(K, V)> for BTreeMap<K, V> {
    fn from_iter<T: IntoIterator<Item = (K, V)>>(iter: T) -> BTreeMap<K, V> {
        let mut map = BTreeMap::new();
        map.extend(iter);
        map
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Extend<(K, V)> for BTreeMap<K, V> {
    #[inline]
    fn extend<T: IntoIterator<Item = (K, V)>>(&mut self, iter: T) {
        iter.into_iter().for_each(move |(k, v)| {
            self.insert(k, v);
        });
    }

    #[inline]
    fn extend_one(&mut self, (k, v): (K, V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, K: Ord + Copy, V: Copy> Extend<(&'a K, &'a V)> for BTreeMap<K, V> {
    fn extend<I: IntoIterator<Item = (&'a K, &'a V)>>(&mut self, iter: I) {
        self.extend(iter.into_iter().map(|(&key, &value)| (key, value)));
    }

    #[inline]
    fn extend_one(&mut self, (&k, &v): (&'a K, &'a V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Hash, V: Hash> Hash for BTreeMap<K, V> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        for elt in self {
            elt.hash(state);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Default for BTreeMap<K, V> {
    /// வெற்று `BTreeMap` ஐ உருவாக்குகிறது.
    fn default() -> BTreeMap<K, V> {
        BTreeMap::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialEq, V: PartialEq> PartialEq for BTreeMap<K, V> {
    fn eq(&self, other: &BTreeMap<K, V>) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a == b)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Eq, V: Eq> Eq for BTreeMap<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialOrd, V: PartialOrd> PartialOrd for BTreeMap<K, V> {
    #[inline]
    fn partial_cmp(&self, other: &BTreeMap<K, V>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V: Ord> Ord for BTreeMap<K, V> {
    #[inline]
    fn cmp(&self, other: &BTreeMap<K, V>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Debug, V: Debug> Debug for BTreeMap<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_map().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, Q: ?Sized, V> Index<&Q> for BTreeMap<K, V>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Output = V;

    /// வழங்கப்பட்ட விசையுடன் தொடர்புடைய மதிப்புக்கு ஒரு குறிப்பை வழங்குகிறது.
    ///
    /// # Panics
    ///
    /// `BTreeMap` இல் விசை இல்லை என்றால் Panics.
    #[inline]
    fn index(&self, key: &Q) -> &V {
        self.get(key).expect("no entry found for key")
    }
}

impl<K, V> BTreeMap<K, V> {
    /// விசையின் மூலம் வரிசைப்படுத்தப்பட்ட வரைபடத்தின் உள்ளீடுகளுக்கு மேல் ஒரு ஈரேட்டரைப் பெறுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "c");
    /// map.insert(2, "b");
    /// map.insert(1, "a");
    ///
    /// for (key, value) in map.iter() {
    ///     println!("{}: {}", key, value);
    /// }
    ///
    /// let (first_key, first_value) = map.iter().next().unwrap();
    /// assert_eq!((*first_key, *first_value), (1, "a"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, K, V> {
        if let Some(root) = &self.root {
            let full_range = root.reborrow().full_range();

            Iter { range: Range { inner: full_range }, length: self.length }
        } else {
            Iter { range: Range { inner: LeafRange::none() }, length: 0 }
        }
    }

    /// விசையின் மூலம் வரிசைப்படுத்தப்பட்ட வரைபடத்தின் உள்ளீடுகளுக்கு மேல் ஒரு மாற்றக்கூடிய ஈரேட்டரைப் பெறுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert("a", 1);
    /// map.insert("b", 2);
    /// map.insert("c", 3);
    ///
    /// // விசை "a" இல்லையென்றால் மதிப்பில் 10 ஐச் சேர்க்கவும்
    /// for (key, value) in map.iter_mut() {
    ///     if key != &"a" {
    ///         *value += 10;
    ///     }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, K, V> {
        if let Some(root) = &mut self.root {
            let full_range = root.borrow_valmut().full_range();

            IterMut {
                range: RangeMut { inner: full_range, _marker: PhantomData },
                length: self.length,
            }
        } else {
            IterMut {
                range: RangeMut { inner: LeafRange::none(), _marker: PhantomData },
                length: 0,
            }
        }
    }

    /// வரிசைப்படுத்தப்பட்ட வரிசையில், வரைபடத்தின் விசைகள் மீது ஒரு ஈரேட்டரைப் பெறுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<_> = a.keys().cloned().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn keys(&self) -> Keys<'_, K, V> {
        Keys { inner: self.iter() }
    }

    /// விசையின் அடிப்படையில், வரைபடத்தின் மதிப்புகள் மீது ஒரு ஈரேட்டரைப் பெறுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.values().cloned().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn values(&self) -> Values<'_, K, V> {
        Values { inner: self.iter() }
    }

    /// விசையின் அடிப்படையில், வரைபடத்தின் மதிப்புகள் மீது ஒரு மாற்றக்கூடிய ஈரேட்டரைப் பெறுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, String::from("hello"));
    /// a.insert(2, String::from("goodbye"));
    ///
    /// for value in a.values_mut() {
    ///     value.push_str("!");
    /// }
    ///
    /// let values: Vec<String> = a.values().cloned().collect();
    /// assert_eq!(values, [String::from("hello!"),
    ///                     String::from("goodbye!")]);
    /// ```
    #[stable(feature = "map_values_mut", since = "1.10.0")]
    pub fn values_mut(&mut self) -> ValuesMut<'_, K, V> {
        ValuesMut { inner: self.iter_mut() }
    }

    /// வரைபடத்தில் உள்ள உறுப்புகளின் எண்ணிக்கையை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert_eq!(a.len(), 0);
    /// a.insert(1, "a");
    /// assert_eq!(a.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn len(&self) -> usize {
        self.length
    }

    /// வரைபடத்தில் எந்த உறுப்புகளும் இல்லை என்றால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert!(a.is_empty());
    /// a.insert(1, "a");
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ரூட் முனை வெற்று (non-allocated) ரூட் முனை என்றால், எங்கள் சொந்த முனையை ஒதுக்குங்கள்.
    /// முழு BTreeMap ஐ கடன் வாங்குவதைத் தவிர்ப்பதற்கான தொடர்புடைய செயல்பாடு.
    fn ensure_is_owned(root: &mut Option<Root<K, V>>) -> &mut Root<K, V> {
        root.get_or_insert_with(Root::new)
    }
}

#[cfg(test)]
mod tests;