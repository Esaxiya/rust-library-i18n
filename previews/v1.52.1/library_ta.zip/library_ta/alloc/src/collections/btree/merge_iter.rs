use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// இரண்டு கண்டிப்பாக ஏறும் ஈரேட்டர்களின் வெளியீட்டை ஒன்றிணைக்கும் ஒரு ஈரேட்டரின் கோர், உதாரணமாக ஒரு தொழிற்சங்கம் அல்லது சமச்சீர் வேறுபாடு.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// இரண்டு ஈரேட்டர்களையும் ஒரு உன்னதமான இடத்தில் போடுவதை விட வேகமான வரையறைகள், ஒருவேளை நாம் ஒரு ஃபியூஸ்இடரேட்டரைக் கட்டுப்படுத்த முடியாது.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// ஒரு ஜோடி மூலங்களை ஒன்றிணைக்கும் ஒரு செயலிக்கு புதிய மையத்தை உருவாக்குகிறது.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// இணைக்கப்பட்ட மூலங்களின் ஜோடியிலிருந்து உருவாகும் அடுத்த ஜோடி உருப்படிகளை வழங்குகிறது.
    /// திரும்பிய இரண்டு விருப்பங்களும் ஒரு மதிப்பைக் கொண்டிருந்தால், அந்த மதிப்பு சமமானது மற்றும் இரு மூலங்களிலும் நிகழ்கிறது.
    /// திரும்பிய விருப்பங்களில் ஒன்று மதிப்பைக் கொண்டிருந்தால், அந்த மதிப்பு மற்ற மூலத்தில் ஏற்படாது (அல்லது ஆதாரங்கள் கண்டிப்பாக ஏறுவதில்லை).
    ///
    /// திரும்பிய விருப்பம் எதுவும் மதிப்பைக் கொண்டிருக்கவில்லை என்றால், மறு செய்கை முடிந்தது, அடுத்தடுத்த அழைப்புகள் அதே வெற்று ஜோடியைத் தரும்.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// இறுதி மறு செய்கையின் `size_hint` க்கான ஒரு ஜோடி மேல் எல்லைகளை வழங்குகிறது.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}