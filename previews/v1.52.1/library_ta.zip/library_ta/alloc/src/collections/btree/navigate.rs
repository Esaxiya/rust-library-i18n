use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// அதே வரம்பிற்கு சமமான மற்றொரு, மாறாத சமமானதை தற்காலிகமாக எடுக்கிறது.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ஒரு மரத்தில் ஒரு குறிப்பிட்ட வரம்பைக் குறிக்கும் தனித்துவமான இலை விளிம்புகளைக் காண்கிறது.
    /// ஒரே மரத்தில் ஒரு ஜோடி வெவ்வேறு கைப்பிடிகள் அல்லது ஒரு ஜோடி வெற்று விருப்பங்களை வழங்குகிறது.
    ///
    /// # Safety
    ///
    /// `BorrowType` என்பது `Immut` ஆக இல்லாவிட்டால், ஒரே கே.வி.யை இரண்டு முறை பார்வையிட நகல் கைப்பிடிகளைப் பயன்படுத்த வேண்டாம்.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())` க்கு சமம், ஆனால் மிகவும் திறமையானது.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ஒரு மரத்தில் ஒரு குறிப்பிட்ட வரம்பைக் குறிக்கும் இலை விளிம்புகளின் ஜோடியைக் காண்கிறது.
    ///
    /// ஒரு `BTreeMap` இல் உள்ள மரத்தைப் போல, மரம் விசையால் கட்டளையிடப்பட்டால் மட்டுமே இதன் விளைவாக அர்த்தமுள்ளதாக இருக்கும்.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // பாதுகாப்பு: எங்கள் கடன் வகை மாறாதது.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// ஒரு முழு மரத்தையும் வரையறுக்கும் இலை விளிம்புகளின் ஜோடியைக் காண்கிறது.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// ஒரு குறிப்பிட்ட வரம்பை வரையறுக்கும் ஒரு ஜோடி இலை விளிம்புகளில் ஒரு தனித்துவமான குறிப்பைப் பிரிக்கிறது.
    /// இதன் விளைவாக (some) பிறழ்வை அனுமதிக்கும் தனித்துவமற்ற குறிப்புகள் உள்ளன, அவை கவனமாக பயன்படுத்தப்பட வேண்டும்.
    ///
    /// ஒரு `BTreeMap` இல் உள்ள மரத்தைப் போல, மரம் விசையால் கட்டளையிடப்பட்டால் மட்டுமே இதன் விளைவாக அர்த்தமுள்ளதாக இருக்கும்.
    ///
    ///
    /// # Safety
    /// ஒரே கே.வி.யை இரண்டு முறை பார்வையிட நகல் கைப்பிடிகளைப் பயன்படுத்த வேண்டாம்.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// மரத்தின் முழு அளவையும் வரையறுக்கும் ஒரு ஜோடி இலை விளிம்புகளில் ஒரு தனித்துவமான குறிப்பைப் பிரிக்கிறது.
    /// முடிவுகள் பிறழ்வு (மதிப்புகளை மட்டும்) அனுமதிக்கும் தனித்துவமற்ற குறிப்புகள், எனவே கவனமாகப் பயன்படுத்த வேண்டும்.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // ரூட் நோட்ரீஃப் இங்கே நகல் செய்கிறோம்-ஒரே கே.வி.யை நாங்கள் ஒருபோதும் இரண்டு முறை பார்வையிட மாட்டோம், மேலும் ஒன்றுடன் ஒன்று மதிப்பு குறிப்புகளுடன் முடிவடையாது.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// மரத்தின் முழு அளவையும் வரையறுக்கும் ஒரு ஜோடி இலை விளிம்புகளில் ஒரு தனித்துவமான குறிப்பைப் பிரிக்கிறது.
    /// முடிவுகள் தனித்துவமான அழிவற்ற மாற்றங்களை அனுமதிக்கும் தனித்துவமான குறிப்புகள், எனவே மிகுந்த கவனத்துடன் பயன்படுத்தப்பட வேண்டும்.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // ரூட் நோட்ரீஃப் இங்கே நகல் செய்கிறோம்-ரூட்டிலிருந்து பெறப்பட்ட குறிப்புகளை ஒன்றுடன் ஒன்று இணைக்கும் வகையில் அதை ஒருபோதும் அணுக மாட்டோம்.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// ஒரு இலை edge கைப்பிடியைக் கொடுத்தால், [`Result::Ok`] ஐ ஒரு கைப்பிடியுடன் வலதுபுறத்தில் உள்ள அண்டை KV க்குத் தருகிறது, இது ஒரே இலை முனையிலோ அல்லது மூதாதையர் முனையிலோ இருக்கும்.
    ///
    /// மரத்தில் edge இலை கடைசியாக இருந்தால், ரூட் முனையுடன் [`Result::Err`] ஐ வழங்குகிறது.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// ஒரு இலை edge கைப்பிடியைக் கொடுத்தால், [`Result::Ok`] ஐ ஒரு கைப்பிடியுடன் இடதுபுறத்தில் உள்ள அண்டை KV க்கு திருப்பித் தருகிறது, இது ஒரே இலை முனையிலோ அல்லது மூதாதையர் முனையிலோ இருக்கும்.
    ///
    /// மரத்தில் edge இலை முதன்மையானது என்றால், ரூட் முனையுடன் [`Result::Err`] ஐ வழங்குகிறது.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ஒரு உள் edge கைப்பிடியைக் கொண்டு, [`Result::Ok`] ஐ ஒரு கைப்பிடியுடன் வலதுபுறத்தில் உள்ள அண்டை KV க்குத் தருகிறது, இது ஒரே உள் முனையிலோ அல்லது மூதாதையர் முனையிலோ இருக்கும்.
    ///
    /// உள் edge மரத்தில் கடைசியாக இருந்தால், ரூட் முனையுடன் [`Result::Err`] ஐ வழங்குகிறது.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// ஒரு இலை edge கைப்பிடியை ஒரு இறக்கும் மரத்தில் கொடுத்து, அடுத்த இலை edge ஐ வலது பக்கத்தில் தருகிறது, மற்றும் இடையில் உள்ள முக்கிய மதிப்பு ஜோடி, அதே இலை முனையிலோ, மூதாதையர் முனையிலோ அல்லது இல்லாதவையாகவோ இருக்கும்.
    ///
    ///
    /// இந்த முறை எந்த node(s) இன் முடிவையும் அடைகிறது.
    /// இது முக்கிய மதிப்பு-மதிப்பு ஜோடி இல்லாவிட்டால், மரத்தின் எஞ்சிய பகுதி முழுவதுமாக ஒதுக்கி வைக்கப்பட்டிருக்கும், மேலும் திரும்புவதற்கு எதுவும் இல்லை.
    ///
    /// # Safety
    /// கொடுக்கப்பட்ட edge முன்பு `deallocating_next_back` உடன் திரும்பியிருக்கக்கூடாது.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// ஒரு இலை edge கைப்பிடியை ஒரு இறக்கும் மரத்தில் கொடுத்து, அடுத்த இலை edge ஐ இடது பக்கத்தில் தருகிறது, மற்றும் இடையில் உள்ள முக்கிய மதிப்பு ஜோடி, அதே இலை முனையிலோ, மூதாதையர் முனையிலோ அல்லது இல்லாதவையாகவோ இருக்கும்.
    ///
    ///
    /// இந்த முறை எந்த node(s) இன் முடிவையும் அடைகிறது.
    /// இது முக்கிய மதிப்பு-மதிப்பு ஜோடி இல்லாவிட்டால், மரத்தின் எஞ்சிய பகுதி முழுவதுமாக ஒதுக்கி வைக்கப்பட்டிருக்கும், மேலும் திரும்புவதற்கு எதுவும் இல்லை.
    ///
    /// # Safety
    /// கொடுக்கப்பட்ட edge முன்பு `deallocating_next` உடன் திரும்பியிருக்கக்கூடாது.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// இலையிலிருந்து வேர் வரை முனைகளின் குவியலை நீக்குகிறது.
    /// `deallocating_next` மற்றும் `deallocating_next_back` ஆகியவை மரத்தின் இருபுறமும் நிப்பிள் செய்து, அதே edge ஐத் தாக்கிய பிறகு, ஒரு மரத்தின் எஞ்சிய பகுதியை நீக்குவதற்கான ஒரே வழி இதுதான்.
    /// அனைத்து விசைகள் மற்றும் மதிப்புகள் திரும்பப் பெறப்படும்போது மட்டுமே அழைக்கப்படுவதை நோக்கமாகக் கொண்டிருப்பதால், எந்த விசைகள் அல்லது மதிப்புகளிலும் தூய்மைப்படுத்தல் செய்யப்படுவதில்லை.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// இலை edge கைப்பிடியை அடுத்த இலை edge க்கு நகர்த்தி, இடையில் உள்ள விசை மற்றும் மதிப்பு பற்றிய குறிப்புகளை வழங்குகிறது.
    ///
    ///
    /// # Safety
    /// பயணித்த திசையில் மற்றொரு கே.வி இருக்க வேண்டும்.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// இலை edge கைப்பிடியை முந்தைய இலை edge க்கு நகர்த்தி, இடையில் உள்ள விசை மற்றும் மதிப்பு பற்றிய குறிப்புகளை வழங்குகிறது.
    ///
    ///
    /// # Safety
    /// பயணித்த திசையில் மற்றொரு கே.வி இருக்க வேண்டும்.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// இலை edge கைப்பிடியை அடுத்த இலை edge க்கு நகர்த்தி, இடையில் உள்ள விசை மற்றும் மதிப்பு பற்றிய குறிப்புகளை வழங்குகிறது.
    ///
    ///
    /// # Safety
    /// பயணித்த திசையில் மற்றொரு கே.வி இருக்க வேண்டும்.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // கடைசியாக இதைச் செய்வது வேகமானதாகும், வரையறைகளின் படி.
        kv.into_kv_valmut()
    }

    /// edge கைப்பிடியை முந்தைய இலைக்கு நகர்த்தி, இடையில் உள்ள விசை மற்றும் மதிப்பு குறித்த குறிப்புகளை வழங்குகிறது.
    ///
    ///
    /// # Safety
    /// பயணித்த திசையில் மற்றொரு கே.வி இருக்க வேண்டும்.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // கடைசியாக இதைச் செய்வது வேகமானதாகும், வரையறைகளின் படி.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// இலை edge கைப்பிடியை அடுத்த இலை edge க்கு நகர்த்தி, இடையில் உள்ள விசையையும் மதிப்பையும் திருப்பித் தருகிறது, அதனுடன் தொடர்புடைய edge ஐ அதன் பெற்றோர் முனை தொங்கவிடும்போது விட்டுச்செல்லும்.
    ///
    /// # Safety
    /// - பயணித்த திசையில் மற்றொரு கே.வி இருக்க வேண்டும்.
    /// - அந்த கே.வி முன்னர் மரத்தை கடந்து செல்ல பயன்படுத்தப்பட்ட கைப்பிடிகளின் எந்த நகலிலும் எதிர் `next_back_unchecked` ஆல் திருப்பி அனுப்பப்படவில்லை.
    ///
    /// புதுப்பிக்கப்பட்ட கைப்பிடியுடன் தொடர ஒரே பாதுகாப்பான வழி, அதை ஒப்பிடுவது, கைவிடுவது, அதன் பாதுகாப்பு நிலைமைகளுக்கு உட்பட்டு இந்த முறையை மீண்டும் அழைப்பது அல்லது அதன் பாதுகாப்பு நிலைமைகளுக்கு உட்பட்டு எதிர் `next_back_unchecked` ஐ அழைப்பது.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// இலை edge கைப்பிடியை முந்தைய இலை edge க்கு நகர்த்தி, இடையில் உள்ள விசையையும் மதிப்பையும் தருகிறது, அதனுடன் தொடர்புடைய edge ஐ அதன் பெற்றோர் முனை தொங்கவிடும்போது விட்டுச்செல்லும் எந்த முனையையும் இடமாற்றம் செய்கிறது.
    ///
    /// # Safety
    /// - பயணித்த திசையில் மற்றொரு கே.வி இருக்க வேண்டும்.
    /// - அந்த இலை edge முன்னர் மரத்தை கடந்து செல்ல பயன்படும் கைப்பிடிகளின் எந்த நகலிலும் எதிர் `next_unchecked` ஆல் திருப்பி அனுப்பப்படவில்லை.
    ///
    /// புதுப்பிக்கப்பட்ட கைப்பிடியுடன் தொடர ஒரே பாதுகாப்பான வழி, அதை ஒப்பிடுவது, கைவிடுவது, அதன் பாதுகாப்பு நிலைமைகளுக்கு உட்பட்டு இந்த முறையை மீண்டும் அழைப்பது அல்லது அதன் பாதுகாப்பு நிலைமைகளுக்கு உட்பட்டு எதிர் `next_unchecked` ஐ அழைப்பது.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// இடது முனையின் edge ஐ ஒரு முனையிலோ அல்லது அடியிலோ தருகிறது, வேறுவிதமாகக் கூறினால், முன்னோக்கி செல்லும்போது உங்களுக்கு முதலில் தேவைப்படும் edge (அல்லது பின்னோக்கி செல்லும்போது கடைசியாக).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// வலதுபுற இலை edge ஐ ஒரு முனைக்குள் அல்லது அடியில் தருகிறது, வேறுவிதமாகக் கூறினால், முன்னோக்கி செல்லும்போது உங்களுக்கு கடைசியாக தேவைப்படும் edge (அல்லது முதலில் பின்னோக்கி செல்லும்போது).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ஏறும் விசைகளின் வரிசையில் இலை முனைகள் மற்றும் உள் கே.வி.க்களைப் பார்வையிடுகிறது, மேலும் உள் முனைகளை ஒட்டுமொத்தமாக ஆழமான முதல் வரிசையில் பார்வையிடுகிறது, அதாவது உள் முனைகள் அவற்றின் தனிப்பட்ட கே.வி.க்கள் மற்றும் அவற்றின் குழந்தை முனைகளுக்கு முந்தியவை.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// ஒரு (துணை) மரத்தில் உள்ள உறுப்புகளின் எண்ணிக்கையை கணக்கிடுகிறது.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// முன்னோக்கி வழிசெலுத்தலுக்காக கே.வி.க்கு மிக நெருக்கமான edge இலையை வழங்குகிறது.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// பின்தங்கிய வழிசெலுத்தலுக்காக கே.வி.க்கு மிக நெருக்கமான edge இலையை வழங்குகிறது.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}