use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// குறிப்பிட்ட நிகழ்வுகளை கண்காணிக்கும் செயலிழப்பு சோதனை போலி நிகழ்வுகளுக்கான ஒரு வரைபடம்.
/// சில நிகழ்வுகள் சில கட்டத்தில் panic க்கு கட்டமைக்கப்படலாம்.
/// நிகழ்வுகள் `clone`, `drop` அல்லது சில அநாமதேய `query` ஆகும்.
///
/// செயலிழப்பு சோதனை டம்மிகள் ஒரு ஐடியால் அடையாளம் காணப்பட்டு ஆர்டர் செய்யப்படுகின்றன, எனவே அவை BTreeMap இல் விசைகளாகப் பயன்படுத்தப்படலாம்.
/// `Debug` trait ஐத் தவிர, crate இல் வரையறுக்கப்பட்ட எதையும் சார்ந்து வேண்டுமென்றே பயன்படுத்துவதில்லை.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// செயலிழப்பு சோதனை போலி வடிவமைப்பை உருவாக்குகிறது.`id` நிகழ்வுகளின் வரிசை மற்றும் சமத்துவத்தை தீர்மானிக்கிறது.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// செயலிழப்பு சோதனை டம்மியின் ஒரு நிகழ்வை உருவாக்குகிறது, அது என்ன நிகழ்வுகளை அனுபவிக்கிறது மற்றும் விருப்பமாக panics ஐ பதிவு செய்கிறது.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// டம்மியின் நிகழ்வுகள் எத்தனை முறை குளோன் செய்யப்பட்டன என்பதை வழங்குகிறது.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// டம்மியின் எத்தனை முறை நிகழ்வுகள் கைவிடப்பட்டன என்பதை வழங்குகிறது.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// டம்மியின் எக்ஸ் 100 எக்ஸ் உறுப்பினரை எத்தனை முறை பயன்படுத்தியிருக்கிறார் என்பதை வழங்குகிறது.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// சில அநாமதேய வினவல், இதன் விளைவாக ஏற்கனவே கொடுக்கப்பட்டுள்ளது.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}