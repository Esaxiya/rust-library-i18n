// இது இலட்சியத்தைத் தொடர்ந்து செயல்படுத்தும் முயற்சி
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust உண்மையில் சார்பு வகைகள் மற்றும் பாலிமார்பிக் மறுநிகழ்வைக் கொண்டிருக்கவில்லை என்பதால், நாங்கள் நிறைய பாதுகாப்பற்ற தன்மைகளைச் செய்கிறோம்.
//

// இந்த தொகுதியின் ஒரு முக்கிய குறிக்கோள், மரத்தை ஒரு பொதுவான (வித்தியாசமாக வடிவமைக்கப்பட்டிருந்தால்) கொள்கலனாகக் கருதி, பி-ட்ரீ மாற்றங்களுடன் கையாள்வதைத் தவிர்ப்பதன் மூலம் சிக்கலைத் தவிர்ப்பது.
//
// எனவே, உள்ளீடுகள் வரிசைப்படுத்தப்பட்டதா, எந்த முனைகள் குறைவானதாக இருக்கக்கூடும், அல்லது அண்டர்ஃபுல் என்றால் என்ன என்பதையும் இந்த தொகுதி பொருட்படுத்தாது.இருப்பினும், நாங்கள் ஒரு சில மாற்றங்களை நம்புகிறோம்:
//
// - மரங்கள் சீரான depth/height ஐ கொண்டிருக்க வேண்டும்.இதன் பொருள் கொடுக்கப்பட்ட முனையிலிருந்து ஒரு இலைக்கு கீழே செல்லும் ஒவ்வொரு பாதையும் ஒரே நீளத்தைக் கொண்டிருக்கும்.
// - `n` நீளமுள்ள ஒரு முனை `n` விசைகள், `n` மதிப்புகள் மற்றும் `n + 1` விளிம்புகளைக் கொண்டுள்ளது.
//   வெற்று முனைக்கு கூட குறைந்தது ஒரு edge இருப்பதை இது குறிக்கிறது.
//   ஒரு இலை முனையைப் பொறுத்தவரை, "having an edge" என்பது முனையின் ஒரு நிலையை நாம் அடையாளம் காண முடியும் என்பதையே குறிக்கிறது, ஏனெனில் இலை விளிம்புகள் காலியாக இருப்பதால் தரவு பிரதிநிதித்துவம் தேவையில்லை.
// உள் முனையில், ஒரு edge இரண்டும் ஒரு நிலையை அடையாளம் காணும் மற்றும் குழந்தை முனைக்கு ஒரு சுட்டிக்காட்டி உள்ளது.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// இலை முனைகளின் அடிப்படை பிரதிநிதித்துவம் மற்றும் உள் முனைகளின் பிரதிநிதித்துவத்தின் ஒரு பகுதி.
struct LeafNode<K, V> {
    /// நாங்கள் `K` மற்றும் `V` இல் இணைந்திருக்க விரும்புகிறோம்.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// பெற்றோர் முனையின் `edges` வரிசையில் இந்த முனையின் குறியீடு.
    /// `*node.parent.edges[node.parent_idx]` `node` போலவே இருக்க வேண்டும்.
    /// `parent` பூஜ்யமாக இருக்கும்போது மட்டுமே இது துவக்கப்படும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
    parent_idx: MaybeUninit<u16>,

    /// இந்த முனை சேமிக்கும் விசைகள் மற்றும் மதிப்புகளின் எண்ணிக்கை.
    len: u16,

    /// முனையின் உண்மையான தரவை சேமிக்கும் வரிசைகள்.
    /// ஒவ்வொரு வரிசையின் முதல் `len` கூறுகள் மட்டுமே துவக்கப்பட்டு செல்லுபடியாகும்.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// இடத்தில் ஒரு புதிய `LeafNode` ஐத் துவக்குகிறது.
    unsafe fn init(this: *mut Self) {
        // ஒரு பொதுவான கொள்கையாக, புலங்கள் இருக்க முடியுமானால் அவற்றை ஆரம்பிக்காமல் விட்டுவிடுகிறோம், ஏனெனில் இது வால்கிரைண்டில் சற்று வேகமாகவும் எளிதாகவும் கண்காணிக்க வேண்டும்.
        //
        unsafe {
            // பெற்றோர்_ஐடிஎக்ஸ், விசைகள் மற்றும் வால்ஸ் அனைத்தும் ஒரு வேளை யுனினிட்
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// புதிய பெட்டி `LeafNode` ஐ உருவாக்குகிறது.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// உள் முனைகளின் அடிப்படை பிரதிநிதித்துவம்.`லீஃப்நோட்'களைப் போலவே, ஆரம்பிக்கப்படாத விசைகள் மற்றும் மதிப்புகளைக் கைவிடுவதைத் தடுக்க` பாக்ஸ்நெட்'களின் பின்னால் இவை மறைக்கப்பட வேண்டும்.
/// ஒரு `InternalNode` க்கான எந்த சுட்டிக்காட்டி நேரடியாக முனையின் அடிப்படை `LeafNode` பகுதிக்கு ஒரு சுட்டிக்காட்டிக்கு அனுப்பப்படலாம், இது ஒரு சுட்டிக்காட்டி சுட்டிக்காட்டும் இரண்டில் எது என்பதைக் கூட சரிபார்க்காமல், இலை மற்றும் உள் முனைகளில் பொதுவாக குறியீட்டை செயல்பட அனுமதிக்கிறது.
///
/// இந்த சொத்து `repr(C)` பயன்பாட்டின் மூலம் இயக்கப்பட்டது.
///
#[repr(C)]
// gdb_providers.py உள்நோக்கத்திற்கு இந்த வகை பெயரைப் பயன்படுத்துகிறது.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// இந்த முனையின் குழந்தைகளுக்கு சுட்டிகள்.
    /// `len + 1` இவற்றில் துவக்க மற்றும் செல்லுபடியாகும் என்று கருதப்படுகிறது, தவிர, மரம் கடன் வகை `Dying` மூலம் வைத்திருக்கும் போது, இந்த சுட்டிகள் சில தொங்கும்.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// புதிய பெட்டி `InternalNode` ஐ உருவாக்குகிறது.
    ///
    /// # Safety
    /// உள் முனைகளின் மாறுபாடு என்னவென்றால், அவை குறைந்தது ஒரு துவக்கப்பட்ட மற்றும் செல்லுபடியாகும் edge ஐக் கொண்டுள்ளன.
    /// இந்த செயல்பாடு அத்தகைய edge ஐ அமைக்காது.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // நாங்கள் தரவை மட்டுமே துவக்க வேண்டும்;விளிம்புகள் ஒருவேளை யுனினிட் ஆகும்.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// ஒரு முனைக்கு நிர்வகிக்கப்பட்ட, பூஜ்யமற்ற சுட்டிக்காட்டி.இது `LeafNode<K, V>` க்கு சொந்தமான சுட்டிக்காட்டி அல்லது `InternalNode<K, V>` க்கு சொந்தமான சுட்டிக்காட்டி ஆகும்.
///
/// எவ்வாறாயினும், எக்ஸ் 100 எக்ஸ் எந்த இரண்டு வகை முனைகளில் உண்மையில் உள்ளது என்பதற்கான எந்த தகவலையும் கொண்டிருக்கவில்லை, மேலும், இந்த தகவல் பற்றாக்குறையால் ஓரளவு தனி வகை அல்ல, அழிப்பான் இல்லை.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// சொந்தமான மரத்தின் வேர் முனை.
///
/// இது ஒரு அழிப்பான் இல்லை என்பதை நினைவில் கொள்க, மேலும் கைமுறையாக சுத்தம் செய்யப்பட வேண்டும்.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// ஆரம்பத்தில் காலியாக இருக்கும் அதன் சொந்த ரூட் முனையுடன் புதிய சொந்தமான மரத்தை வழங்குகிறது.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` பூஜ்ஜியமாக இருக்கக்கூடாது.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// சொந்தமாக ரூட் முனையை கடன் வாங்குகிறது.
    /// `reborrow_mut` போலல்லாமல், இது பாதுகாப்பானது, ஏனெனில் மூலத்தை அழிக்க வருவாய் மதிப்பைப் பயன்படுத்த முடியாது, மேலும் மரத்தைப் பற்றி வேறு குறிப்புகள் இருக்க முடியாது.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// சொந்தமாக ரூட் முனையை சற்று மாற்றியமைக்கிறது.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// பயணத்தை அனுமதிக்கும் மற்றும் அழிவுகரமான முறைகளையும் வேறு சிலவற்றையும் வழங்கும் ஒரு குறிப்பிற்கு மாற்றமுடியாத மாற்றங்கள்.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// முந்தைய ரூட் முனையை சுட்டிக்காட்டி ஒற்றை edge உடன் புதிய உள் முனையைச் சேர்க்கிறது, அந்த புதிய முனையை ரூட் முனையாக மாற்றி, அதைத் திருப்பித் தரவும்.
    /// இது உயரத்தை 1 ஆல் அதிகரிக்கிறது மற்றும் இது `pop_internal_level` க்கு நேர் எதிரானது.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, நாங்கள் இப்போது உள் என்பதை மறந்துவிட்டோம் என்பதைத் தவிர:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// உள் ரூட் முனையை நீக்குகிறது, அதன் முதல் குழந்தையை புதிய ரூட் முனையாகப் பயன்படுத்துகிறது.
    /// ரூட் கணுவுக்கு ஒரே ஒரு குழந்தை இருக்கும்போது மட்டுமே அழைக்கப்படுவதை நோக்கமாகக் கொண்டிருப்பதால், எந்த விசைகள், மதிப்புகள் மற்றும் பிற குழந்தைகளிலும் தூய்மைப்படுத்தல் செய்யப்படுவதில்லை.
    ///
    /// இது உயரத்தை 1 குறைக்கிறது மற்றும் இது `push_internal_level` க்கு நேர் எதிரானது.
    ///
    /// `Root` பொருளுக்கு பிரத்யேக அணுகல் தேவை, ஆனால் ரூட் முனைக்கு அல்ல;
    /// இது ரூட் கணுக்கான பிற கைப்பிடிகள் அல்லது குறிப்புகளை செல்லாது.
    ///
    /// உள் நிலை இல்லை என்றால் Panics, அதாவது, ரூட் முனை ஒரு இலை என்றால்.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // பாதுகாப்பு: நாங்கள் உள் என்று வலியுறுத்தினோம்.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // பாதுகாப்பு: நாங்கள் `self` ஐ பிரத்தியேகமாக கடன் வாங்கினோம், அதன் கடன் வகை பிரத்தியேகமானது.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // பாதுகாப்பு: முதல் edge எப்போதும் துவக்கப்படும்.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` என்பது `K` மற்றும் `V` இல் எப்போதும் கோவாரியண்ட் ஆகும், `BorrowType` `Mut` ஆக இருந்தாலும் கூட.
// இது தொழில்நுட்ப ரீதியாக தவறானது, ஆனால் `NodeRef` இன் உள் பயன்பாடு காரணமாக எந்தவொரு பாதுகாப்பற்ற தன்மையையும் ஏற்படுத்த முடியாது, ஏனெனில் நாங்கள் `K` மற்றும் `V` ஐ விட முற்றிலும் பொதுவானதாக இருக்கிறோம்.
//
// இருப்பினும், ஒரு பொது வகை `NodeRef` ஐ மடக்கும் போதெல்லாம், அது சரியான மாறுபாட்டைக் கொண்டுள்ளது என்பதை உறுதிப்படுத்திக் கொள்ளுங்கள்.
//
/// ஒரு முனைக்கான குறிப்பு.
///
/// இந்த வகை பல அளவுருக்களைக் கொண்டுள்ளது, இது எவ்வாறு செயல்படுகிறது என்பதைக் கட்டுப்படுத்துகிறது:
/// - `BorrowType`: கடன் வகையை விவரிக்கும் மற்றும் வாழ்நாள் முழுவதும் கொண்டு செல்லும் போலி வகை.
///    - இது `Immut<'a>` ஆக இருக்கும்போது, `NodeRef` தோராயமாக `&'a Node` போல செயல்படுகிறது.
///    - இது `ValMut<'a>` ஆக இருக்கும்போது, விசைகள் மற்றும் மர அமைப்பைப் பொறுத்தவரை `NodeRef` தோராயமாக `&'a Node` போல செயல்படுகிறது, ஆனால் மரம் முழுவதும் உள்ள மதிப்புகள் குறித்து பல மாற்றத்தக்க குறிப்புகளை ஒன்றிணைக்க அனுமதிக்கிறது.
///    - இது `Mut<'a>` ஆக இருக்கும்போது, `NodeRef` தோராயமாக `&'a mut Node` போலவே செயல்படுகிறது, இருப்பினும் செருகும் முறைகள் ஒரு மாறக்கூடிய சுட்டிக்காட்டி ஒரு மதிப்பை ஒன்றிணைக்க அனுமதிக்கின்றன.
///    - இது `Owned` ஆக இருக்கும்போது, `NodeRef` தோராயமாக `Box<Node>` போலவே செயல்படுகிறது, ஆனால் ஒரு அழிப்பான் இல்லை, மேலும் கைமுறையாக சுத்தம் செய்யப்பட வேண்டும்.
///    - இது `Dying` ஆக இருக்கும்போது, `NodeRef` இன்னும் தோராயமாக `Box<Node>` போலவே செயல்படுகிறது, ஆனால் மரத்தை பிட் மூலம் அழிக்க முறைகள் உள்ளன, மேலும் சாதாரண முறைகள், அழைப்பது பாதுகாப்பற்றது எனக் குறிக்கப்படவில்லை என்றாலும், தவறாக அழைத்தால் UB ஐ அழைக்கலாம்.
///
///   எந்தவொரு `NodeRef` மரத்தின் வழியாக செல்லவும் அனுமதிப்பதால், `BorrowType` முழு மரத்திற்கும் திறம்பட பொருந்தும், கணுவுக்கு மட்டுமல்ல.
/// - `K` மற்றும் `V`: இவை முனைகளில் சேமிக்கப்பட்ட விசைகள் மற்றும் மதிப்புகள்.
/// - `Type`: இது `Leaf`, `Internal` அல்லது `LeafOrInternal` ஆக இருக்கலாம்.
/// இது `Leaf` ஆக இருக்கும்போது, `NodeRef` ஒரு இலை முனைக்கு சுட்டிக்காட்டுகிறது, இது `Internal` ஆக இருக்கும்போது `NodeRef` ஒரு உள் முனைக்கு சுட்டிக்காட்டுகிறது, மேலும் இது `LeafOrInternal` ஆக இருக்கும்போது `NodeRef` இரண்டு வகை முனைகளையும் சுட்டிக்காட்டுகிறது.
///   `Type` `NodeRef` க்கு வெளியே பயன்படுத்தும்போது `NodeType` என பெயரிடப்பட்டுள்ளது.
///
/// நிலையான வகை பாதுகாப்பைப் பயன்படுத்த `BorrowType` மற்றும் `NodeType` இரண்டும் நாம் எந்த முறைகளை செயல்படுத்துகிறோம் என்பதைக் கட்டுப்படுத்துகின்றன.அத்தகைய கட்டுப்பாடுகளை நாம் பயன்படுத்தக்கூடிய வழியில் வரம்புகள் உள்ளன:
/// - ஒவ்வொரு வகை அளவுருவுக்கும், ஒரு முறையை நாம் பொதுவாக அல்லது ஒரு குறிப்பிட்ட வகைக்கு மட்டுமே வரையறுக்க முடியும்.
/// எடுத்துக்காட்டாக, `into_kv` போன்ற ஒரு முறையை எல்லா `BorrowType` க்கும் பொதுவாக வரையறுக்க முடியாது, அல்லது ஒரு முறை வாழ்நாள் முழுவதும் செல்லும் அனைத்து வகைகளுக்கும், ஏனெனில் இது `&'a` குறிப்புகளைத் தர வேண்டும் என்று நாங்கள் விரும்புகிறோம்.
///   எனவே, குறைந்த சக்திவாய்ந்த வகை `Immut<'a>` க்கு மட்டுமே இதை வரையறுக்கிறோம்.
/// - `Mut<'a>` என்று சொல்வதிலிருந்து `Immut<'a>` வரை நாம் மறைமுகமான வற்புறுத்தலைப் பெற முடியாது.
///   எனவே, `into_kv` போன்ற ஒரு முறையை அடைய நாம் `reborrow` ஐ மிகவும் சக்திவாய்ந்த `NodeRef` இல் வெளிப்படையாக அழைக்க வேண்டும்.
///
/// `NodeRef` இல் உள்ள அனைத்து முறைகளும் ஒருவித குறிப்பைத் தருகின்றன:
/// - மதிப்பால் `self` ஐ எடுத்து, `BorrowType` ஆல் வாழ்நாள் முழுவதும் திரும்பவும்.
///   சில நேரங்களில், அத்தகைய முறையைப் பயன்படுத்த, நாம் `reborrow_mut` ஐ அழைக்க வேண்டும்.
/// - குறிப்பு மூலம் `self` ஐ எடுத்துக் கொள்ளுங்கள், மற்றும் (implicitly) அந்த குறிப்பின் வாழ்நாளை `BorrowType` கொண்டு செல்லும் வாழ்நாளுக்கு பதிலாக தருகிறது.
/// அந்த வகையில், திரும்பப் பெறப்பட்ட குறிப்பு பயன்படுத்தப்படும் வரை `NodeRef` கடன் வாங்கியிருப்பதாக கடன் சரிபார்ப்பு உத்தரவாதம் அளிக்கிறது.
///   செருகுவதை ஆதரிக்கும் முறைகள் இந்த விதியை ஒரு மூல சுட்டிக்காட்டி, அதாவது எந்தவொரு வாழ்நாளும் இல்லாமல் ஒரு குறிப்பைத் திருப்புவதன் மூலம் வளைக்கின்றன.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// கணு மற்றும் இலைகளின் நிலை ஆகியவை தனித்தனியாக உள்ளன, `Type` ஆல் முழுமையாக விவரிக்க முடியாத முனையின் மாறிலி, மற்றும் கணு தானே சேமிக்காது.
    /// நாம் ரூட் முனையின் உயரத்தை மட்டுமே சேமிக்க வேண்டும், மேலும் ஒவ்வொரு முனையின் உயரத்தையும் அதிலிருந்து பெற வேண்டும்.
    /// `Type` `Leaf` ஆக இருந்தால் பூஜ்ஜியமாகவும், `Type` `Internal` ஆக இருந்தால் பூஜ்ஜியமாகவும் இருக்க வேண்டும்.
    ///
    ///
    height: usize,
    /// இலை அல்லது உள் முனைக்கு சுட்டிக்காட்டி.
    /// `InternalNode` இன் வரையறை சுட்டிக்காட்டி எந்த வகையிலும் செல்லுபடியாகும் என்பதை உறுதி செய்கிறது.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` என நிரம்பிய ஒரு முனை குறிப்பைத் திறக்கவும்.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// உள் முனையின் தரவை வெளிப்படுத்துகிறது.
    ///
    /// இந்த முனைக்கான பிற குறிப்புகளை செல்லாததாக்குவதற்கு மூல ptr ஐ வழங்குகிறது.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // பாதுகாப்பு: நிலையான முனை வகை `Internal` ஆகும்.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// உள் முனையின் தரவுக்கான பிரத்யேக அணுகலைப் பெறுகிறது.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// முனையின் நீளத்தைக் காண்கிறது.இது விசைகள் அல்லது மதிப்புகளின் எண்ணிக்கை.
    /// விளிம்புகளின் எண்ணிக்கை `len() + 1` ஆகும்.
    /// பாதுகாப்பாக இருந்தபோதிலும், இந்த செயல்பாட்டை அழைப்பது பாதுகாப்பற்ற குறியீடு உருவாக்கிய மாற்றத்தக்க குறிப்புகளை செல்லாததாக்குவதன் பக்க விளைவை ஏற்படுத்தும் என்பதை நினைவில் கொள்க.
    ///
    pub fn len(&self) -> usize {
        // முக்கியமாக, நாங்கள் இங்கே `len` புலத்தை மட்டுமே அணுகுவோம்.
        // BorrowType marker::ValMut ஆக இருந்தால், நாம் செல்லாததாக இருக்கக் கூடாத மதிப்புகளுக்கு நிலுவையில் உள்ள மாற்றத்தக்க குறிப்புகள் இருக்கலாம்.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// முனை மற்றும் இலைகள் தனித்தனியாக இருக்கும் நிலைகளின் எண்ணிக்கையை வழங்குகிறது.
    /// பூஜ்ஜிய உயரம் என்றால் முனை ஒரு இலை என்று பொருள்.
    /// மேலே உள்ள வேருடன் மரங்களை நீங்கள் சித்தரித்தால், முனை எந்த உயரத்தில் தோன்றும் என்று எண் கூறுகிறது.
    /// மரங்களை மேலே இலைகளுடன் வைத்திருந்தால், மரம் முனைக்கு மேலே எவ்வளவு உயரமாக இருக்கும் என்று எண் கூறுகிறது.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// அதே முனைக்கு மற்றொரு, மாறாத குறிப்பை தற்காலிகமாக எடுக்கிறது.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// எந்த இலை அல்லது உள் முனையின் இலை பகுதியை வெளிப்படுத்துகிறது.
    ///
    /// இந்த முனைக்கான பிற குறிப்புகளை செல்லாததாக்குவதற்கு மூல ptr ஐ வழங்குகிறது.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // முனை குறைந்தபட்சம் லீஃப்நோட் பகுதிக்கு செல்லுபடியாகும்.
        // இது NodeRef வகையிலான குறிப்பு அல்ல, ஏனெனில் இது தனிப்பட்டதா அல்லது பகிரப்பட்டதா என்பது எங்களுக்குத் தெரியாது.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// தற்போதைய முனையின் பெற்றோரைக் காண்கிறது.
    /// தற்போதைய கணு உண்மையில் ஒரு பெற்றோரைக் கொண்டிருந்தால் `Ok(handle)` ஐ வழங்குகிறது, அங்கு `handle` தற்போதைய கணுவை சுட்டிக்காட்டும் பெற்றோரின் edge ஐ சுட்டிக்காட்டுகிறது.
    ///
    /// தற்போதைய முனைக்கு பெற்றோர் இல்லையென்றால் `Err(self)` ஐ வழங்குகிறது, அசல் `NodeRef` ஐ திருப்பி அளிக்கிறது.
    ///
    /// முறையின் பெயர் மேலே உள்ள ரூட் முனையுடன் மரங்களை சித்தரிக்கிறது.
    ///
    /// `edge.descend().ascend().unwrap()` மற்றும் `node.ascend().unwrap().descend()` இரண்டுமே வெற்றியின் மீது எதுவும் செய்யக்கூடாது.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // நாம் முனைகளுக்கு மூல சுட்டிகள் பயன்படுத்த வேண்டும், ஏனெனில், பரோ டைப் marker::ValMut ஆக இருந்தால், நாம் செல்லாததாக இருக்கக் கூடாத மதிப்புகளுக்கு நிலுவையில் உள்ள மாற்றத்தக்க குறிப்புகள் இருக்கலாம்.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` கட்டாயமாக இருக்க வேண்டும் என்பதை நினைவில் கொள்க.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` கட்டாயமாக இருக்க வேண்டும் என்பதை நினைவில் கொள்க.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// மாறாத மரத்தில் எந்த இலை அல்லது உள் முனையின் இலை பகுதியை வெளிப்படுத்துகிறது.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // பாதுகாப்பு: `Immut` என கடன் வாங்கிய இந்த மரத்தில் மாற்றத்தக்க குறிப்புகள் எதுவும் இருக்க முடியாது.
        unsafe { &*ptr }
    }

    /// முனையில் சேமிக்கப்பட்ட விசைகளில் ஒரு பார்வையைப் பெறுகிறது.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` ஐப் போலவே, ஒரு முனையின் பெற்றோர் முனைக்கு ஒரு குறிப்பைப் பெறுகிறது, ஆனால் செயல்பாட்டில் தற்போதைய முனையையும் நீக்குகிறது.
    /// இது பாதுகாப்பற்றது, ஏனென்றால் ஒதுக்கப்பட்டிருந்தாலும் தற்போதைய முனை இன்னும் அணுகப்படும்.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// இந்த முனை ஒரு `Leaf` என்று நிலையான தகவலை தொகுப்பாளருக்கு பாதுகாப்பற்ற முறையில் வலியுறுத்துகிறது.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// இந்த முனை ஒரு `Internal` என்று நிலையான தகவலை தொகுப்பாளருக்கு பாதுகாப்பற்ற முறையில் வலியுறுத்துகிறது.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// அதே முனைக்கு தற்காலிகமாக மாற்றக்கூடிய மற்றொரு குறிப்பை தற்காலிகமாக எடுக்கிறது.ஜாக்கிரதை, இந்த முறை மிகவும் ஆபத்தானது என்பதால், இரட்டிப்பாக இருப்பதால் அது உடனடியாக ஆபத்தானதாக தோன்றாது.
    ///
    /// மாற்றக்கூடிய சுட்டிகள் மரத்தை சுற்றி எங்கும் சுற்றித் திரிவதால், திரும்பிய சுட்டிக்காட்டி அசல் சுட்டிக்காட்டி தொங்கவிடவோ, எல்லைக்கு அப்பாற்பட்டதாகவோ அல்லது அடுக்கப்பட்ட கடன் விதிகளின் கீழ் செல்லாது எனவோ எளிதாகப் பயன்படுத்தலாம்.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` இல் மற்றொரு வகை அளவுருவைச் சேர்ப்பதைக் கருத்தில் கொள்ளுங்கள், இது மறுசீரமைக்கப்பட்ட சுட்டிகள் மீது வழிசெலுத்தல் முறைகளைப் பயன்படுத்துவதைக் கட்டுப்படுத்துகிறது, இந்த பாதுகாப்பற்ற தன்மையைத் தடுக்கிறது.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// எந்த இலை அல்லது உள் முனையின் இலை பகுதிக்கு பிரத்தியேக அணுகலைப் பெறுகிறது.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // பாதுகாப்பு: முழு முனைக்கும் பிரத்யேக அணுகல் எங்களிடம் உள்ளது.
        unsafe { &mut *ptr }
    }

    /// எந்த இலை அல்லது உள் முனையின் இலை பகுதிக்கு பிரத்யேக அணுகலை வழங்குகிறது.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // பாதுகாப்பு: முழு முனைக்கும் பிரத்யேக அணுகல் எங்களிடம் உள்ளது.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// முக்கிய சேமிப்பக பகுதியின் ஒரு உறுப்புக்கான பிரத்யேக அணுகலைப் பெறுகிறது.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY என்ற எல்லையில் உள்ளது
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // பாதுகாப்பு: அழைப்பவர் சுயமாக மேலதிக முறைகளை அழைக்க முடியாது
        // முக்கிய ஸ்லைஸ் குறிப்பு கைவிடப்படும் வரை, கடன் வாங்கிய வாழ்நாளில் எங்களுக்கு தனிப்பட்ட அணுகல் உள்ளது.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// முனையின் மதிப்பு சேமிப்பக பகுதியின் ஒரு உறுப்பு அல்லது துண்டுக்கான பிரத்யேக அணுகலைப் பெறுகிறது.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY என்ற எல்லையில் உள்ளது
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // பாதுகாப்பு: அழைப்பவர் சுயமாக மேலதிக முறைகளை அழைக்க முடியாது
        // கடன் ஸ்லைஸ் குறிப்பு கைவிடப்படும் வரை, கடன் வாங்கிய வாழ்நாளில் எங்களுக்கு தனிப்பட்ட அணுகல் உள்ளது.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge உள்ளடக்கங்களுக்கான முனையின் சேமிப்பக பகுதியின் ஒரு உறுப்பு அல்லது துண்டுக்கான பிரத்யேக அணுகலைப் பெறுகிறது.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY + 1 இன் எல்லையில் உள்ளது
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // பாதுகாப்பு: அழைப்பவர் சுயமாக மேலதிக முறைகளை அழைக்க முடியாது
        // edge ஸ்லைஸ் குறிப்பு கைவிடப்படும் வரை, கடன் வாங்கிய வாழ்நாளில் எங்களுக்கு தனிப்பட்ட அணுகல் உள்ளது.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - முனை `idx` க்கும் மேற்பட்ட துவக்கப்பட்ட கூறுகளைக் கொண்டுள்ளது.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // பிற கூறுகளுக்கு மிகச்சிறந்த குறிப்புகளுடன் மாற்றுப்பெயர்வைத் தவிர்ப்பதற்காக, நாங்கள் ஆர்வமாக உள்ள ஒரு உறுப்புக்கான குறிப்பை மட்டுமே உருவாக்குகிறோம், குறிப்பாக, முந்தைய மறு செய்கைகளில் அழைப்பாளருக்குத் திரும்பியவர்கள்.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust வெளியீடு #74679 காரணமாக அளவிடப்படாத வரிசை சுட்டிகளுக்கு நாம் கட்டாயப்படுத்த வேண்டும்.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// முனையின் நீளத்திற்கு பிரத்யேக அணுகலைப் பெறுகிறது.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// முனையின் பிற குறிப்புகளை செல்லாததாக்காமல், முனையின் இணைப்பை அதன் பெற்றோர் edge உடன் அமைக்கிறது.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// அதன் பெற்றோர் edge உடன் ரூட்டின் இணைப்பை அழிக்கிறது.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// முனையின் முடிவில் ஒரு முக்கிய மதிப்பு ஜோடியைச் சேர்க்கிறது.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` ஆல் திரும்பும் ஒவ்வொரு உருப்படியும் கணுக்கான செல்லுபடியாகும் edge குறியீடாகும்.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ஒரு முக்கிய மதிப்பு ஜோடி மற்றும் அந்த ஜோடியின் வலதுபுறம் செல்ல ஒரு edge ஐ முனையின் முடிவில் சேர்க்கிறது.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ஒரு முனை ஒரு `Internal` முனை அல்லது `Leaf` முனை என்பதை சரிபார்க்கிறது.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// ஒரு குறிப்பிட்ட விசை மதிப்பு ஜோடி அல்லது ஒரு முனைக்குள் edge பற்றிய குறிப்பு.
/// `Node` அளவுரு ஒரு `NodeRef` ஆக இருக்க வேண்டும், அதே நேரத்தில் `Type` `KV` ஆக இருக்கலாம் (ஒரு முக்கிய மதிப்பு ஜோடியில் ஒரு கைப்பிடியைக் குறிக்கிறது) அல்லது `Edge` (edge இல் ஒரு கைப்பிடியைக் குறிக்கிறது).
///
/// `Leaf` முனைகளில் கூட `Edge` கைப்பிடிகள் இருக்கக்கூடும் என்பதை நினைவில் கொள்க.
/// குழந்தை முனைக்கு ஒரு சுட்டிக்காட்டி குறிப்பதற்கு பதிலாக, இவை முக்கிய மதிப்புள்ள ஜோடிகளுக்கு இடையில் குழந்தை சுட்டிகள் செல்லும் இடங்களைக் குறிக்கின்றன.
/// எடுத்துக்காட்டாக, நீளம் 2 கொண்ட ஒரு முனையில், 3 சாத்தியமான edge இடங்கள் இருக்கும், ஒன்று முனையின் இடதுபுறம், இரண்டு ஜோடிகளுக்கு இடையில் ஒன்று, மற்றும் முனையின் வலதுபுறம்.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// `#[derive(Clone)]` இன் முழு பொதுத்தன்மையும் எங்களுக்குத் தேவையில்லை, ஏனெனில் `Node` ஆனது மாறாத குறிப்பு மற்றும் `Copy` ஆக இருக்கும்போது மட்டுமே `குளோன்` செய்யக்கூடியதாக இருக்கும்.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// இந்த கைப்பிடி சுட்டிக்காட்டும் edge அல்லது விசை மதிப்பு ஜோடியைக் கொண்டிருக்கும் முனையை மீட்டெடுக்கிறது.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// முனையில் இந்த கைப்பிடியின் நிலையை வழங்குகிறது.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` இல் ஒரு முக்கிய மதிப்பு ஜோடிக்கு புதிய கைப்பிடியை உருவாக்குகிறது.
    /// பாதுகாப்பற்றது, ஏனெனில் அழைப்பாளர் `idx < node.len()` என்பதை உறுதிப்படுத்த வேண்டும்.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq இன் பொது செயலாக்கமாக இருக்கலாம், ஆனால் இந்த தொகுதியில் மட்டுமே பயன்படுத்தப்படுகிறது.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// அதே இடத்தில் தற்காலிகமாக மாறாத மற்றொரு கைப்பிடியை தற்காலிகமாக எடுக்கிறது.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // எங்கள் வகை எங்களுக்குத் தெரியாததால் எங்களால் Handle::new_kv அல்லது Handle::new_edge ஐப் பயன்படுத்த முடியாது
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// கைப்பிடியின் முனை ஒரு `Leaf` என்று நிலையான தகவலை தொகுப்பாளருக்கு பாதுகாப்பற்ற முறையில் வலியுறுத்துகிறது.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// அதே இடத்தில் தற்காலிகமாக மற்றொரு, மாற்றக்கூடிய கைப்பிடியை எடுக்கிறது.
    /// ஜாக்கிரதை, இந்த முறை மிகவும் ஆபத்தானது என்பதால், இரட்டிப்பாக இருப்பதால் அது உடனடியாக ஆபத்தானதாக தோன்றாது.
    ///
    ///
    /// விவரங்களுக்கு, `NodeRef::reborrow_mut` ஐப் பார்க்கவும்.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // எங்கள் வகை எங்களுக்குத் தெரியாததால் எங்களால் Handle::new_kv அல்லது Handle::new_edge ஐப் பயன்படுத்த முடியாது
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` இல் edge க்கு புதிய கைப்பிடியை உருவாக்குகிறது.
    /// பாதுகாப்பற்றது, ஏனெனில் அழைப்பாளர் `idx <= node.len()` என்பதை உறுதிப்படுத்த வேண்டும்.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// ஒரு edge குறியீட்டைக் கொடுத்தால், அங்கு திறன் நிரப்பப்பட்ட ஒரு முனையில் நாம் செருக விரும்புகிறோம், ஒரு பிளவு புள்ளியின் விவேகமான கே.வி குறியீட்டைக் கணக்கிடுகிறது மற்றும் செருகலை எங்கு செய்ய வேண்டும்.
///
/// பிளவு புள்ளியின் குறிக்கோள் அதன் விசையும் மதிப்பும் பெற்றோர் முனையில் முடிவடைவதே;
/// பிளவு புள்ளியின் இடதுபுறத்தில் உள்ள விசைகள், மதிப்புகள் மற்றும் விளிம்புகள் இடது குழந்தையாகின்றன;
/// பிளவு புள்ளியின் வலதுபுறத்தில் உள்ள விசைகள், மதிப்புகள் மற்றும் விளிம்புகள் சரியான குழந்தையாகின்றன.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust வெளியீடு #74834 இந்த சமச்சீர் விதிகளை விளக்க முயற்சிக்கிறது.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// இந்த edge இன் வலது மற்றும் இடதுபுறத்தில் உள்ள முக்கிய மதிப்பு ஜோடிகளுக்கு இடையில் ஒரு புதிய விசை-மதிப்பு ஜோடியைச் செருகும்.
    /// இந்த முறை புதிய ஜோடிக்கு பொருந்துவதற்கு முனையில் போதுமான இடம் இருப்பதாக கருதுகிறது.
    ///
    /// திரும்பிய சுட்டிக்காட்டி செருகப்பட்ட மதிப்பை சுட்டிக்காட்டுகிறது.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// இந்த edge இன் வலது மற்றும் இடதுபுறத்தில் உள்ள முக்கிய மதிப்பு ஜோடிகளுக்கு இடையில் ஒரு புதிய விசை-மதிப்பு ஜோடியைச் செருகும்.
    /// போதுமான இடம் இல்லாவிட்டால் இந்த முறை முனையைப் பிரிக்கிறது.
    ///
    /// திரும்பிய சுட்டிக்காட்டி செருகப்பட்ட மதிப்பை சுட்டிக்காட்டுகிறது.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// இந்த edge இணைக்கும் குழந்தை முனையில் பெற்றோர் சுட்டிக்காட்டி மற்றும் குறியீட்டை சரிசெய்கிறது.
    /// விளிம்புகளின் வரிசைமுறை மாற்றப்பட்டபோது இது பயனுள்ளதாக இருக்கும்,
    fn correct_parent_link(self) {
        // கணுக்கான பிற குறிப்புகளை செல்லாதபடி பேக் பாயிண்டரை உருவாக்கவும்.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ஒரு புதிய விசை-மதிப்பு ஜோடி மற்றும் ஒரு edge ஐ செருகும், இது இந்த edge க்கும் இந்த edge இன் வலதுபுறத்தில் உள்ள முக்கிய மதிப்பு ஜோடிக்கும் இடையில் அந்த புதிய ஜோடியின் வலதுபுறம் செல்லும்.
    /// இந்த முறை புதிய ஜோடிக்கு பொருந்துவதற்கு முனையில் போதுமான இடம் இருப்பதாக கருதுகிறது.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// ஒரு புதிய விசை-மதிப்பு ஜோடி மற்றும் ஒரு edge ஐ செருகும், இது இந்த edge க்கும் இந்த edge இன் வலதுபுறத்தில் உள்ள முக்கிய மதிப்பு ஜோடிக்கும் இடையில் அந்த புதிய ஜோடியின் வலதுபுறம் செல்லும்.
    /// போதுமான இடம் இல்லாவிட்டால் இந்த முறை முனையைப் பிரிக்கிறது.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// இந்த edge இன் வலது மற்றும் இடதுபுறத்தில் உள்ள முக்கிய மதிப்பு ஜோடிகளுக்கு இடையில் ஒரு புதிய விசை-மதிப்பு ஜோடியைச் செருகும்.
    /// போதுமான இடம் இல்லாவிட்டால் இந்த முறை முனையைப் பிரிக்கிறது, மேலும் வேர் அடையும் வரை, பிளவுபட்ட பகுதியை பெற்றோர் முனையில் மீண்டும் மீண்டும் செருக முயற்சிக்கிறது.
    ///
    ///
    /// திரும்பிய முடிவு `Fit` ஆக இருந்தால், அதன் கைப்பிடியின் முனை இந்த edge இன் முனை அல்லது ஒரு மூதாதையராக இருக்கலாம்.
    /// திரும்பிய முடிவு `Split` ஆக இருந்தால், `left` புலம் ரூட் முனையாக இருக்கும்.
    /// திரும்பிய சுட்டிக்காட்டி செருகப்பட்ட மதிப்பை சுட்டிக்காட்டுகிறது.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// இந்த edge ஆல் சுட்டிக்காட்டப்பட்ட முனையைக் கண்டறிகிறது.
    ///
    /// முறையின் பெயர் மேலே உள்ள ரூட் முனையுடன் மரங்களை சித்தரிக்கிறது.
    ///
    /// `edge.descend().ascend().unwrap()` மற்றும் `node.ascend().unwrap().descend()` இரண்டுமே வெற்றியின் மீது எதுவும் செய்யக்கூடாது.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // நாம் முனைகளுக்கு மூல சுட்டிகள் பயன்படுத்த வேண்டும், ஏனெனில், பரோ டைப் marker::ValMut ஆக இருந்தால், நாம் செல்லாததாக இருக்கக் கூடாத மதிப்புகளுக்கு நிலுவையில் உள்ள மாற்றத்தக்க குறிப்புகள் இருக்கலாம்.
        // அந்த மதிப்பு நகலெடுக்கப்பட்டதால் உயர புலத்தை அணுகுவதில் எந்த கவலையும் இல்லை.
        // முனை சுட்டிக்காட்டி குறிப்பிடப்படாதவுடன், விளிம்புகளின் வரிசையை ஒரு குறிப்புடன் (Rust வெளியீடு #73987) அணுகுவோம், மேலும் வரிசைக்கு அல்லது அதற்குள் வேறு எந்த குறிப்புகளையும் செல்லாததாக்குகிறோம் என்பதில் கவனமாக இருங்கள்.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // நாங்கள் தனி விசை மற்றும் மதிப்பு முறைகளை அழைக்க முடியாது, ஏனென்றால் இரண்டாவதாக அழைப்பது முதல் வழங்கிய குறிப்பை செல்லாது.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// கே.வி கைப்பிடி குறிக்கும் விசை மற்றும் மதிப்பை மாற்றவும்.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// இலை தரவை கவனித்துக்கொள்வதன் மூலம், ஒரு குறிப்பிட்ட `NodeType` க்கான `split` ஐ செயல்படுத்த உதவுகிறது.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// அடிப்படை முனையை மூன்று பகுதிகளாகப் பிரிக்கிறது:
    ///
    /// - இந்த கைப்பிடியின் இடதுபுறத்தில் உள்ள முக்கிய மதிப்பு ஜோடிகளை மட்டுமே கொண்டிருக்கும் வகையில் முனை துண்டிக்கப்படுகிறது.
    /// - இந்த கைப்பிடியால் சுட்டிக்காட்டப்பட்ட விசையும் மதிப்பும் பிரித்தெடுக்கப்படுகின்றன.
    /// - இந்த கைப்பிடியின் வலதுபுறத்தில் உள்ள அனைத்து முக்கிய மதிப்பு ஜோடிகளும் புதிதாக ஒதுக்கப்பட்ட முனைக்குள் வைக்கப்படுகின்றன.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// இந்த கைப்பிடியால் சுட்டிக்காட்டப்பட்ட விசை-மதிப்பு ஜோடியை அகற்றி, முக்கிய மதிப்பு ஜோடி சரிந்த edge உடன் அதை வழங்குகிறது.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// அடிப்படை முனையை மூன்று பகுதிகளாகப் பிரிக்கிறது:
    ///
    /// - இந்த கைப்பிடியின் இடதுபுறத்தில் விளிம்புகள் மற்றும் விசை மதிப்பு ஜோடிகளை மட்டுமே கொண்டிருக்கும் வகையில் முனை துண்டிக்கப்படுகிறது.
    /// - இந்த கைப்பிடியால் சுட்டிக்காட்டப்பட்ட விசையும் மதிப்பும் பிரித்தெடுக்கப்படுகின்றன.
    /// - இந்த கைப்பிடியின் வலதுபுறத்தில் உள்ள அனைத்து விளிம்புகளும் விசை மதிப்பு ஜோடிகளும் புதிதாக ஒதுக்கப்பட்ட முனைக்குள் வைக்கப்படுகின்றன.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// உள் விசை மதிப்பு ஜோடியைச் சுற்றி சமநிலைப்படுத்தும் செயல்பாட்டை மதிப்பிடுவதற்கும் செய்வதற்கும் ஒரு அமர்வைக் குறிக்கிறது.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ஒரு குழந்தையாக முனை சம்பந்தப்பட்ட ஒரு சமநிலை சூழலைத் தேர்வுசெய்கிறது, இதனால் கே.வி.க்கு இடையில் உடனடியாக இடதுபுறம் அல்லது பெற்றோர் முனையில் வலதுபுறம்.
    /// பெற்றோர் இல்லாவிட்டால் `Err` ஐ வழங்குகிறது.
    /// பெற்றோர் காலியாக இருந்தால் Panics.
    ///
    /// கொடுக்கப்பட்ட முனை எப்படியாவது குறைவானதாக இருந்தால் உகந்ததாக இருக்க இடது பக்கத்தை விரும்புகிறது, அதாவது இங்கே இடது உடன்பிறப்பை விடவும், அதன் வலது உடன்பிறப்பை விடவும் குறைவான கூறுகள் உள்ளன.
    /// அவ்வாறான நிலையில், இடது உடன்பிறப்புடன் ஒன்றிணைவது வேகமானது, ஏனென்றால் நாம் முனையின் N கூறுகளை மட்டுமே நகர்த்த வேண்டும், அதற்கு பதிலாக அவற்றை வலதுபுறமாக மாற்றி, N உறுப்புகளை விட முன்னால் நகரும்.
    /// இடது உடன்பிறப்பிலிருந்து திருடுவதும் பொதுவாக வேகமானது, ஏனென்றால் உடன்பிறப்பின் உறுப்புகளில் குறைந்தபட்சம் N ஐ இடதுபுறமாக மாற்றுவதற்குப் பதிலாக, முனையின் N கூறுகளை மட்டுமே வலதுபுறமாக மாற்ற வேண்டும்.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// ஒன்றிணைப்பது சாத்தியமா என்பதை வழங்குகிறது, அதாவது, மத்திய கே.வி.யை அருகிலுள்ள குழந்தை முனைகளுடன் இணைக்க ஒரு முனையில் போதுமான இடம் இருக்கிறதா என்று.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// ஒன்றிணைப்பைச் செய்கிறது மற்றும் எதைத் திரும்பப் பெற வேண்டும் என்பதை மூடுவதற்கு அனுமதிக்கிறது.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // பாதுகாப்பு: ஒன்றிணைக்கப்படும் முனைகளின் உயரம் உயரத்திற்கு கீழே ஒன்றாகும்
                // இந்த edge இன் முனையின், இதனால் பூஜ்ஜியத்திற்கு மேலே, எனவே அவை உள்.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// பெற்றோரின் முக்கிய மதிப்பு ஜோடி மற்றும் அருகிலுள்ள குழந்தை முனைகள் இரண்டையும் இடது குழந்தை முனையுடன் ஒன்றிணைத்து சுருங்கிய பெற்றோர் முனையைத் தருகிறது.
    ///
    ///
    /// நாம் `.can_merge()` இல்லாவிட்டால் Panics.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// பெற்றோரின் முக்கிய மதிப்பு ஜோடி மற்றும் அருகிலுள்ள குழந்தை முனைகள் இரண்டையும் இடது குழந்தை முனையுடன் இணைத்து, அந்த குழந்தை முனையைத் தருகிறது.
    ///
    ///
    /// நாம் `.can_merge()` இல்லாவிட்டால் Panics.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// பெற்றோரின் முக்கிய மதிப்பு ஜோடி மற்றும் அருகிலுள்ள குழந்தை முனைகள் இரண்டையும் இடது குழந்தை முனையுடன் ஒன்றிணைத்து, கண்காணிக்கப்பட்ட குழந்தை edge முடிவடைந்த அந்த குழந்தை முனையில் edge கைப்பிடியை வழங்குகிறது,
    ///
    ///
    /// நாம் `.can_merge()` இல்லாவிட்டால் Panics.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// இடது குழந்தையிலிருந்து ஒரு முக்கிய மதிப்பு ஜோடியை அகற்றி, பெற்றோரின் முக்கிய மதிப்பு சேமிப்பகத்தில் வைக்கிறது, அதே நேரத்தில் பழைய பெற்றோர் விசை மதிப்பு ஜோடியை சரியான குழந்தைக்குள் தள்ளும்.
    ///
    /// `track_right_edge_idx` ஆல் குறிப்பிடப்பட்ட அசல் edge முடிவடைந்த இடத்திற்கு ஒத்த சரியான குழந்தையில் edge க்கு ஒரு கைப்பிடியை வழங்குகிறது.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// சரியான குழந்தையிலிருந்து ஒரு முக்கிய மதிப்பு ஜோடியை அகற்றி, பெற்றோரின் முக்கிய மதிப்பு சேமிப்பகத்தில் வைக்கிறது, அதே நேரத்தில் பழைய பெற்றோர் விசை மதிப்பு ஜோடியை இடது குழந்தைக்குத் தள்ளும்.
    ///
    /// `track_left_edge_idx` ஆல் குறிப்பிடப்பட்ட இடது குழந்தையில் edge க்கு ஒரு கைப்பிடியை வழங்குகிறது, அது நகரவில்லை.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// இது `steal_left` ஐப் போலவே திருடுகிறது, ஆனால் ஒரே நேரத்தில் பல கூறுகளைத் திருடுகிறது.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // நாங்கள் பாதுகாப்பாக திருடலாம் என்பதை உறுதிப்படுத்திக் கொள்ளுங்கள்.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // இலை தரவை நகர்த்தவும்.
            {
                // சரியான குழந்தையில் திருடப்பட்ட கூறுகளுக்கு இடமளிக்கவும்.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // உறுப்புகளை இடது குழந்தையிலிருந்து வலது பக்கம் நகர்த்தவும்.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // இடதுபுறமாக திருடப்பட்ட ஜோடியை பெற்றோருக்கு நகர்த்தவும்.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // பெற்றோரின் முக்கிய மதிப்பு ஜோடியை சரியான குழந்தைக்கு நகர்த்தவும்.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // திருடப்பட்ட விளிம்புகளுக்கு இடம் கொடுங்கள்.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // விளிம்புகளைத் திருடுங்கள்.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` இன் சமச்சீர் குளோன்.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // நாங்கள் பாதுகாப்பாக திருடலாம் என்பதை உறுதிப்படுத்திக் கொள்ளுங்கள்.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // இலை தரவை நகர்த்தவும்.
            {
                // வலதுபுறமாக திருடப்பட்ட ஜோடியை பெற்றோருக்கு நகர்த்தவும்.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // பெற்றோரின் முக்கிய மதிப்பு ஜோடியை இடது குழந்தைக்கு நகர்த்தவும்.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // உறுப்புகளை வலது குழந்தையிலிருந்து இடதுபுறமாக நகர்த்தவும்.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // திருடப்பட்ட கூறுகள் இருக்கும் இடைவெளியை நிரப்பவும்.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // விளிம்புகளைத் திருடுங்கள்.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // திருடப்பட்ட விளிம்புகள் இருந்த இடைவெளியை நிரப்பவும்.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// இந்த முனை ஒரு `Leaf` முனை என்று வலியுறுத்தும் எந்த நிலையான தகவலையும் நீக்குகிறது.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// இந்த முனை ஒரு `Internal` முனை என்று வலியுறுத்தும் எந்த நிலையான தகவலையும் நீக்குகிறது.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// அடிப்படை முனை ஒரு `Internal` முனை அல்லது `Leaf` முனை என்பதை சரிபார்க்கிறது.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` க்குப் பிறகு பின்னொட்டை ஒரு முனையிலிருந்து மற்றொன்றுக்கு நகர்த்தவும்.`right` காலியாக இருக்க வேண்டும்.
    /// `right` இன் முதல் edge மாறாமல் உள்ளது.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// செருகலின் முடிவு, ஒரு முனை அதன் திறனைத் தாண்டி விரிவாக்கத் தேவைப்படும்போது.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` இன் இடதுபுறத்தில் உள்ள உறுப்புகள் மற்றும் விளிம்புகளுடன் இருக்கும் மரத்தில் மாற்றப்பட்ட முனை.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // சில விசையும் மதிப்பும் பிரிக்கப்பட்டு, வேறு இடங்களில் செருகப்பட வேண்டும்.
    pub kv: (K, V),
    // `kv` இன் வலதுபுறம் உள்ள கூறுகள் மற்றும் விளிம்புகளுடன் சொந்தமான, இணைக்கப்படாத, புதிய முனை.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // இந்த கடன் வகையின் முனை குறிப்புகள் மரத்தின் பிற முனைகளுக்கு செல்ல அனுமதிக்கிறதா.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // டிராவர்சல் தேவையில்லை, இது `borrow_mut` இன் முடிவைப் பயன்படுத்தி நிகழ்கிறது.
        // டிராவர்சலை முடக்குவதன் மூலமும், வேர்களுக்கு புதிய குறிப்புகளை மட்டுமே உருவாக்குவதன் மூலமும், `Owned` வகையின் ஒவ்வொரு குறிப்பும் ரூட் கணுக்கானது என்பதை நாங்கள் அறிவோம்.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// துவக்கப்பட்ட உறுப்புகளின் ஒரு துண்டில் ஒரு மதிப்பைச் செருகும், பின்னர் ஒரு துவக்கப்படாத உறுப்பு.
///
/// # Safety
/// ஸ்லைஸில் `idx` க்கும் மேற்பட்ட கூறுகள் உள்ளன.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// துவக்கப்பட்ட அனைத்து உறுப்புகளின் துண்டுகளிலிருந்து ஒரு மதிப்பை அகற்றி திருப்பித் தருகிறது, இது துவக்கப்படாத ஒரு உறுப்புக்கு பின்னால் செல்கிறது.
///
///
/// # Safety
/// ஸ்லைஸில் `idx` க்கும் மேற்பட்ட கூறுகள் உள்ளன.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// ஒரு ஸ்லைஸ் `distance` நிலைகளில் உள்ள உறுப்புகளை இடதுபுறமாக மாற்றுகிறது.
///
/// # Safety
/// ஸ்லைஸில் குறைந்தது `distance` கூறுகள் உள்ளன.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// ஒரு துண்டு `distance` நிலைகளில் உள்ள உறுப்புகளை வலப்புறம் மாற்றுகிறது.
///
/// # Safety
/// ஸ்லைஸில் குறைந்தது `distance` கூறுகள் உள்ளன.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// அனைத்து மதிப்புகளையும் துவக்கப்பட்ட கூறுகளின் துண்டுகளிலிருந்து துவக்கப்படாத தனிமங்களின் துண்டுகளாக நகர்த்துகிறது, மேலும் `src` ஐ அனைத்து துவக்கப்படாதவையாகவும் விட்டுவிடுகிறது.
///
/// `dst.copy_from_slice(src)` போன்றது, ஆனால் `T` `Copy` ஆக தேவையில்லை.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;