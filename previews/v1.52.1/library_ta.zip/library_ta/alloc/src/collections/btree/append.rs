use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// இரண்டு ஏறுவரிசை ஐரேட்டர்களின் ஒன்றியத்திலிருந்து அனைத்து முக்கிய மதிப்பு ஜோடிகளையும் சேர்க்கிறது, வழியில் ஒரு `length` மாறியை அதிகரிக்கும்.பிந்தையது ஒரு சொட்டு கையாளுபவர் பீதியடையும்போது அழைப்பவர் கசிவைத் தவிர்ப்பதை எளிதாக்குகிறது.
    ///
    /// இரண்டு ஈரேட்டர்களும் ஒரே விசையை உருவாக்கினால், இந்த முறை ஜோடியை இடது ஐரேட்டரிலிருந்து இறக்கி, ஜோடியை வலது ஐரேட்டரிலிருந்து சேர்க்கிறது.
    ///
    /// ஒரு `BTreeMap` ஐப் போலவே, மரம் கண்டிப்பாக ஏறும் வரிசையில் முடிவடைய விரும்பினால், இரு செயலிகளும் விசைகளை கண்டிப்பாக ஏறும் வரிசையில் உருவாக்க வேண்டும், ஒவ்வொன்றும் மரத்தின் எல்லா விசைகளையும் விட பெரியது, ஏற்கனவே மரத்தில் நுழைந்த எந்த விசையும் உட்பட.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // `left` மற்றும் `right` ஐ நேரியல் நேரத்தில் வரிசைப்படுத்தப்பட்ட வரிசையில் இணைக்க நாங்கள் தயார் செய்கிறோம்.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // இதற்கிடையில், வரிசைப்படுத்தப்பட்ட வரிசையிலிருந்து நேரியல் நேரத்தில் ஒரு மரத்தை உருவாக்குகிறோம்.
        self.bulk_push(iter, length)
    }

    /// அனைத்து முக்கிய மதிப்பு ஜோடிகளையும் மரத்தின் முடிவில் தள்ளி, வழியில் ஒரு `length` மாறியை அதிகரிக்கும்.
    /// பிந்தையது, அழைப்பாளர் பீதியடையும்போது கசிவைத் தவிர்ப்பதை எளிதாக்குகிறது.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // அனைத்து முக்கிய மதிப்பு ஜோடிகளிலும் இட்ரேட் செய்து, அவற்றை சரியான மட்டத்தில் முனைகளில் தள்ளும்.
        for (key, value) in iter {
            // முக்கிய மதிப்பு ஜோடியை தற்போதைய இலை முனைக்குள் தள்ள முயற்சிக்கவும்.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // இடமில்லை, மேலே சென்று அங்கே தள்ளுங்கள்.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // இடத்தை விட்டு ஒரு முனை கிடைத்தது, இங்கே தள்ளவும்.
                                open_node = parent;
                                break;
                            } else {
                                // மீண்டும் மேலே செல்லுங்கள்.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // நாங்கள் மேலே இருக்கிறோம், ஒரு புதிய ரூட் முனையை உருவாக்கி அங்கு தள்ளுங்கள்.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // விசை மதிப்பு ஜோடி மற்றும் புதிய வலது சப்டிரீயை அழுத்தவும்.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // மீண்டும் வலதுபுறமாக இலைக்குச் செல்லுங்கள்.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // ஒவ்வொரு மறு செய்கையையும் அதிகரிக்கும் நீளம், மறு செய்கை பீதியை முன்னேற்றினாலும் வரைபடம் சேர்க்கப்பட்ட கூறுகளை குறைக்கிறதா என்பதை உறுதிப்படுத்தவும்.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// இரண்டு வரிசைப்படுத்தப்பட்ட காட்சிகளை ஒன்றில் இணைப்பதற்கான ஒரு செயலி
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// இரண்டு விசைகள் சமமாக இருந்தால், சரியான மூலத்திலிருந்து விசை மதிப்பு ஜோடியைத் தருகிறது.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}