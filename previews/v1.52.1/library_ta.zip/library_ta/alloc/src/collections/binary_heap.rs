//! பைனரி குவியலுடன் செயல்படுத்தப்படும் முன்னுரிமை வரிசை.
//!
//! மிகப்பெரிய உறுப்பைச் செருகுவதும் உறுத்துவதும் *O*(log(*n*)) நேர சிக்கலைக் கொண்டுள்ளது.
//! மிகப்பெரிய உறுப்பைச் சரிபார்க்கிறது *O*(1).vector ஐ பைனரி குவியலாக மாற்றுவது இடத்தில் செய்யப்படலாம், மேலும் *O*(*n*) சிக்கலைக் கொண்டுள்ளது.
//! ஒரு பைனரி குவியலை ஒரு வரிசைப்படுத்தப்பட்ட vector இடத்திலேயே மாற்றலாம், இது *O*(*n*\*log(* n*)) இன்-ப்ளேஸ் ஹெப்ஸோர்ட்டுக்கு பயன்படுத்த அனுமதிக்கிறது.
//!
//! # Examples
//!
//! இது ஒரு பெரிய எடுத்துக்காட்டு, இது [directed graph][dir_graph] இல் [shortest path problem][sssp] ஐ தீர்க்க [Dijkstra's algorithm][dijkstra] ஐ செயல்படுத்துகிறது.
//!
//! தனிப்பயன் வகைகளுடன் [`BinaryHeap`] ஐ எவ்வாறு பயன்படுத்துவது என்பதை இது காட்டுகிறது.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // முன்னுரிமை வரிசை `Ord` ஐப் பொறுத்தது.
//! // trait ஐ வெளிப்படையாக செயல்படுத்துங்கள், எனவே வரிசை அதிகபட்ச குவியலுக்கு பதிலாக ஒரு நிமிட குவியலாக மாறும்.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // செலவுகளின் வரிசையில் நாங்கள் புரட்டுவதை கவனியுங்கள்.
//!         // நாம் நிலைகளை ஒப்பிட்டுப் பார்த்தால், `PartialEq` மற்றும் `Ord` இன் செயல்பாடுகளை சீரானதாக மாற்ற இந்த படி அவசியம்.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` செயல்படுத்தப்பட வேண்டும்.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // ஒவ்வொரு முனையும் ஒரு குறுகிய செயல்படுத்தலுக்கு, `usize` ஆக குறிப்பிடப்படுகிறது.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // டிஜ்க்ஸ்ட்ராவின் குறுகிய பாதை வழிமுறை.
//!
//! // ஒவ்வொரு முனைக்கும் தற்போதைய குறுகிய தூரத்தைக் கண்டறிய `start` இல் தொடங்கி `dist` ஐப் பயன்படுத்தவும்.இந்த செயலாக்கம் நினைவக திறன் கொண்டதல்ல, ஏனெனில் இது போலி முனைகளை வரிசையில் விடக்கூடும்.
//! //
//! // இது எளிமையான செயலாக்கத்திற்காக `usize::MAX` ஐ ஒரு செண்டினல் மதிப்பாகப் பயன்படுத்துகிறது.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]= `start` இலிருந்து `node` க்கு தற்போதைய குறுகிய தூரம்
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // நாங்கள் `start` இல் இருக்கிறோம், பூஜ்ஜிய செலவில்
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // குறைந்த விலை முனைகளுடன் முதல் (min-heap) உடன் எல்லையை ஆராயுங்கள்
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // மாற்றாக அனைத்து குறுகிய பாதைகளையும் தொடர்ந்து கண்டுபிடித்திருக்கலாம்
//!         if position == goal { return Some(cost); }
//!
//!         // நாம் ஏற்கனவே ஒரு சிறந்த வழியைக் கண்டுபிடித்திருப்பது முக்கியம்
//!         if cost > dist[position] { continue; }
//!
//!         // நாம் அடையக்கூடிய ஒவ்வொரு கணுக்கும், இந்த முனை வழியாக குறைந்த செலவில் ஒரு வழியைக் கண்டுபிடிக்க முடியுமா என்று பாருங்கள்
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // அப்படியானால், அதை எல்லைப்புறத்தில் சேர்த்து தொடரவும்
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // தளர்வு, நாங்கள் இப்போது ஒரு சிறந்த வழியைக் கண்டுபிடித்துள்ளோம்
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // இலக்கை அடைய முடியாது
//!     None
//! }
//!
//! fn main() {
//!     // இது நாம் பயன்படுத்தப் போகும் இயக்கிய வரைபடம்.
//!     // முனை எண்கள் வெவ்வேறு மாநிலங்களுடன் ஒத்துப்போகின்றன, மேலும் edge எடைகள் ஒரு முனையிலிருந்து மற்றொன்றுக்கு நகரும் செலவைக் குறிக்கின்றன.
//!     //
//!     // விளிம்புகள் ஒரு வழி என்பதை நினைவில் கொள்க.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // ஒவ்வொரு குறியீடும், ஒரு முனை மதிப்புடன் தொடர்புடைய, வெளிச்செல்லும் விளிம்புகளின் பட்டியலைக் கொண்டிருக்கும் ஒரு வரைபடமாக வரைபடம் குறிப்பிடப்படுகிறது.
//!     // அதன் செயல்திறனுக்காக தேர்வு செய்யப்பட்டது.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // முனை 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // முனை 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // முனை 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // முனை 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // முனை 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// பைனரி குவியலுடன் செயல்படுத்தப்படும் முன்னுரிமை வரிசை.
///
/// இது அதிகபட்ச குவியலாக இருக்கும்.
///
/// `Ord` trait ஆல் நிர்ணயிக்கப்பட்டபடி, வேறு எந்த உருப்படியுடனும் தொடர்புடைய பொருளின் வரிசைப்படுத்தல் குவியலில் இருக்கும்போது மாறும் வகையில் ஒரு பொருளை மாற்றியமைப்பது ஒரு தர்க்கப் பிழையாகும்.
///
/// இது பொதுவாக `Cell`, `RefCell`, உலகளாவிய நிலை, I/O அல்லது பாதுகாப்பற்ற குறியீடு மூலம் மட்டுமே சாத்தியமாகும்.
/// அத்தகைய தர்க்கப் பிழையின் விளைவாக நடத்தை குறிப்பிடப்படவில்லை, ஆனால் வரையறுக்கப்படாத நடத்தை ஏற்படாது.
/// இதில் panics, தவறான முடிவுகள், நிறுத்தங்கள், நினைவக கசிவுகள் மற்றும் நிறுத்தப்படாதவை ஆகியவை அடங்கும்.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // வகை அனுமானம் ஒரு வெளிப்படையான வகை கையொப்பத்தை தவிர்க்க அனுமதிக்கிறது (இது இந்த எடுத்துக்காட்டில் `BinaryHeap<i32>` ஆக இருக்கும்).
/////
/// let mut heap = BinaryHeap::new();
///
/// // குவியலில் அடுத்த உருப்படியைப் பார்க்க நாம் கண்ணோட்டத்தைப் பயன்படுத்தலாம்.
/// // இந்த விஷயத்தில், இதுவரை எந்த உருப்படிகளும் இல்லை, எனவே எங்களுக்கு எதுவும் கிடைக்கவில்லை.
/// assert_eq!(heap.peek(), None);
///
/// // சில மதிப்பெண்களைச் சேர்ப்போம் ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // இப்போது கண்ணில் குவியலில் மிக முக்கியமான உருப்படியைக் காட்டுகிறது.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // ஒரு குவியலின் நீளத்தை நாம் சரிபார்க்கலாம்.
/// assert_eq!(heap.len(), 3);
///
/// // குவியலில் உள்ள உருப்படிகளை நாம் சீரற்ற வரிசையில் திருப்பி அனுப்பினாலும் அவற்றை மீண்டும் கூறலாம்.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // அதற்கு பதிலாக இந்த மதிப்பெண்களை நாங்கள் பாப் செய்தால், அவை மீண்டும் வரிசையில் வர வேண்டும்.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // மீதமுள்ள எந்தவொரு பொருட்களின் குவியலையும் நாம் அழிக்க முடியும்.
/// heap.clear();
///
/// // குவியல் இப்போது காலியாக இருக்க வேண்டும்.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `BinaryHeap` ஐ ஒரு நிமிட குவியலாக மாற்ற `std::cmp::Reverse` அல்லது தனிப்பயன் `Ord` செயல்படுத்தல் பயன்படுத்தப்படலாம்.
/// இது `heap.pop()` மிகப் பெரிய மதிப்புக்கு பதிலாக மிகச்சிறிய மதிப்பைத் தர வைக்கிறது.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // `Reverse` இல் மதிப்புகளை மடக்கு
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // இந்த மதிப்பெண்களை நாங்கள் இப்போது பாப் செய்தால், அவை தலைகீழ் வரிசையில் வர வேண்டும்.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # நேர சிக்கலானது
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` க்கான மதிப்பு எதிர்பார்க்கப்படும் செலவு;முறை ஆவணங்கள் இன்னும் விரிவான பகுப்பாய்வை அளிக்கிறது.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// ஒரு `BinaryHeap` இல் மிகப் பெரிய உருப்படிக்கு மாற்றக்கூடிய குறிப்பை மடக்கும் கட்டமைப்பு.
///
///
/// இந்த `struct` [`BinaryHeap`] இல் [`peek_mut`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // பாதுகாப்பு: வெற்று இல்லாத குவியல்களுக்கு மட்டுமே பீக்மட் உடனடிப்படுத்தப்படுகிறது.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // பாதுகாப்பானது: பீக்மட் காலியாக இல்லாத குவியல்களுக்கு மட்டுமே உடனடிப்படுத்தப்படுகிறது
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // பாதுகாப்பானது: பீக்மட் காலியாக இல்லாத குவியல்களுக்கு மட்டுமே உடனடிப்படுத்தப்படுகிறது
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// குவியலிலிருந்து எட்டிப் பார்த்த மதிப்பை அகற்றி திருப்பித் தருகிறது.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// வெற்று `BinaryHeap<T>` ஐ உருவாக்குகிறது.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// வெற்று `BinaryHeap` ஐ அதிகபட்ச குவியலாக உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// ஒரு குறிப்பிட்ட திறன் கொண்ட வெற்று `BinaryHeap` ஐ உருவாக்குகிறது.
    /// இது `capacity` உறுப்புகளுக்கு போதுமான நினைவகத்தை முன்கூட்டியே ஒதுக்குகிறது, இதனால் `BinaryHeap` குறைந்தது பல மதிப்புகளைக் கொண்டிருக்கும் வரை மறு ஒதுக்கீடு செய்ய வேண்டியதில்லை.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// பைனரி குவியலில் உள்ள மிகப் பெரிய உருப்படிக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது, அல்லது அது காலியாக இருந்தால் `None`.
    ///
    /// Note: `PeekMut` மதிப்பு கசிந்தால், குவியல் ஒரு சீரற்ற நிலையில் இருக்கலாம்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # நேர சிக்கலானது
    ///
    /// உருப்படி மாற்றியமைக்கப்பட்டால், மிக மோசமான நேர சிக்கலானது *O*(log(*n*)) ஆகும், இல்லையெனில் அது *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// பைனரி குவியலிலிருந்து மிகப் பெரிய உருப்படியை அகற்றி அதை திருப்பித் தருகிறது, அல்லது அது காலியாக இருந்தால் `None`.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # நேர சிக்கலானது
    ///
    /// *N* உறுப்புகளைக் கொண்ட ஒரு குவியலில் `pop` இன் மிக மோசமான செலவு *O*(log(*n*)) ஆகும்.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // பாதுகாப்பு: !self.is_empty() என்றால் self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// பைனரி குவியல் மீது ஒரு பொருளைத் தள்ளுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # நேர சிக்கலானது
    ///
    /// `push` இன் எதிர்பார்க்கப்படும் செலவு, உறுப்புகளின் ஒவ்வொரு வரிசைப்படுத்துதலுக்கும் சராசரியாக, மற்றும் போதுமான எண்ணிக்கையிலான தள்ளுதல்களுக்கு மேல் *O*(1) ஆகும்.
    ///
    /// ஏற்கனவே எந்த வரிசைப்படுத்தப்பட்ட வடிவத்திலும் *இல்லாத* கூறுகளைத் தள்ளும்போது இது மிகவும் அர்த்தமுள்ள செலவு மெட்ரிக் ஆகும்.
    ///
    /// உறுப்புகள் முக்கியமாக ஏறும் வரிசையில் தள்ளப்பட்டால் நேர சிக்கலானது குறைகிறது.
    /// மோசமான நிலையில், உறுப்புகள் ஏறுவரிசைப்படி வரிசைப்படுத்தப்பட்ட வரிசையில் தள்ளப்படுகின்றன மற்றும் *n* உறுப்புகளைக் கொண்ட ஒரு குவியலுக்கு எதிராக ஒரு உந்துதலுக்கான மன்னிப்பு செலவு *O*(log(*n*)) ஆகும்.
    ///
    /// `push` க்கு *ஒற்றை* அழைப்பின் மோசமான வழக்கு *O*(*n*) ஆகும்.திறன் தீர்ந்துவிட்டால், மறுஅளவிடுதல் தேவைப்படும்போது மோசமான நிலை ஏற்படுகிறது.
    /// மறுஅளவிடல் செலவு முந்தைய புள்ளிவிவரங்களில் மாற்றப்பட்டுள்ளது.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // பாதுகாப்பு: நாங்கள் ஒரு புதிய உருப்படியைத் தள்ளியதால், இதன் பொருள்
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` ஐப் பயன்படுத்துகிறது மற்றும் வரிசைப்படுத்தப்பட்ட (ascending) வரிசையில் ஒரு vector ஐ வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // பாதுகாப்பு: `end` `self.len() - 1` இலிருந்து 1 க்கு செல்கிறது (இரண்டும் சேர்க்கப்பட்டுள்ளது),
            //  எனவே இது எப்போதும் அணுகுவதற்கான சரியான குறியீடாகும்.
            //  குறியீட்டு 0 (அதாவது `ptr`) ஐ அணுகுவது பாதுகாப்பானது, ஏனெனில்
            //  1 <=முடிவு <self.len(), அதாவது self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // பாதுகாப்பு: `end` `self.len() - 1` இலிருந்து 1 க்கு செல்கிறது (இரண்டும் சேர்க்கப்பட்டுள்ளது) எனவே:
            //  0 <1 <=end <= self.len(), 1 <self.len() அதாவது 0 <end and end <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Sift_up மற்றும் sift_down இன் செயலாக்கங்கள் vector இலிருந்து ஒரு உறுப்பை நகர்த்துவதற்காக (ஒரு துளைக்கு பின்னால் விட்டு) பாதுகாப்பற்ற தொகுதிகளைப் பயன்படுத்துகின்றன, மற்றவற்றுடன் நகர்ந்து, அகற்றப்பட்ட உறுப்பை துளையின் இறுதி இடத்தில் vector க்கு நகர்த்தவும்.
    //
    // `Hole` வகை இதைக் குறிக்கப் பயன்படுகிறது, மேலும் panic இல் கூட, அதன் நோக்கம் முடிவில் துளை மீண்டும் நிரப்பப்பட்டிருப்பதை உறுதிசெய்க.
    // ஒரு துளை பயன்படுத்துவது இடமாற்றங்களைப் பயன்படுத்துவதோடு ஒப்பிடும்போது நிலையான காரணியைக் குறைக்கிறது, இது இரு மடங்கு நகர்வுகளை உள்ளடக்கியது.
    //
    //
    //
    //

    /// # Safety
    ///
    /// அழைப்பாளர் `pos < self.len()` என்று உத்தரவாதம் அளிக்க வேண்டும்.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos` இல் மதிப்பை எடுத்து ஒரு துளை உருவாக்கவும்.
        // பாதுகாப்பு: அழைப்பாளர் போஸ் <self.len() என்று உத்தரவாதம் அளிக்கிறார்
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // பாதுகாப்பு: hole.pos()> தொடக்க>=0, அதாவது hole.pos()> 0
            //  எனவே hole.pos(), 1 நிரம்பி வழிய முடியாது.
            //  இது பெற்றோர் <hole.pos() க்கு உத்தரவாதம் அளிக்கிறது, எனவே இது சரியான குறியீடாகும்!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // பாதுகாப்பு: மேலே உள்ள அதே
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos` இல் ஒரு உறுப்பை எடுத்து குவியலின் கீழே நகர்த்தவும், அதன் குழந்தைகள் பெரியதாக இருக்கும்.
    ///
    ///
    /// # Safety
    ///
    /// அழைப்பாளர் `pos < end <= self.len()` என்று உத்தரவாதம் அளிக்க வேண்டும்.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // பாதுகாப்பு: அழைப்பாளர் போஸ் <முடிவு <= self.len() என்று உத்தரவாதம் அளிக்கிறார்.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // வளைய மாறுபாடு: குழந்தை==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // இரண்டு குழந்தைகளில் அதிகமானவர்களுடன் ஒப்பிடுக: குழந்தை <முடிவு, 1 <self.len() மற்றும் குழந்தை + 1 <முடிவு <= self.len(), எனவே அவை சரியான குறியீடுகளாகும்.
            //
            //  குழந்தை==2 *hole.pos() + 1!= hole.pos() மற்றும் குழந்தை + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: T என்பது ஒரு ZST ஆக இருந்தால் 2 *hole.pos() + 1 அல்லது 2* hole.pos() + 2 நிரம்பி வழியும்
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // நாங்கள் ஏற்கனவே வரிசையில் இருந்தால், நிறுத்துங்கள்.
            // பாதுகாப்பு: குழந்தை இப்போது பழைய குழந்தை அல்லது பழைய குழந்தை + 1
            //  இரண்டும் <self.len() மற்றும்!= hole.pos() என்பதை நாங்கள் ஏற்கனவே நிரூபித்துள்ளோம்
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // பாதுகாப்பு: மேலே உள்ளதைப் போன்றது.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // பாதுகாப்பு: &&குறுகிய சுற்று, அதாவது
        //  இரண்டாவது நிபந்தனை குழந்தை==முடிவு, 1 <self.len() என்பது ஏற்கனவே உண்மை.
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // பாதுகாப்பு: குழந்தை ஏற்கனவே செல்லுபடியாகும் குறியீடாக நிரூபிக்கப்பட்டுள்ளது
            //  குழந்தை==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// அழைப்பாளர் `pos < self.len()` என்று உத்தரவாதம் அளிக்க வேண்டும்.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // பாதுகாப்பு: போஸ் <லென் அழைப்பாளரால் உத்தரவாதம் அளிக்கப்படுகிறது
        //  வெளிப்படையாக len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos` இல் ஒரு உறுப்பை எடுத்து குவியலின் கீழே நகர்த்தவும், பின்னர் அதை அதன் நிலைக்கு உயர்த்தவும்.
    ///
    ///
    /// Note: உறுப்பு பெரியது என்று அறியப்படும் போது இது வேகமாக இருக்கும்/கீழே நெருக்கமாக இருக்க வேண்டும்.
    ///
    /// # Safety
    ///
    /// அழைப்பாளர் `pos < self.len()` என்று உத்தரவாதம் அளிக்க வேண்டும்.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // பாதுகாப்பு: அழைப்பாளர் போஸ் <self.len() என்று உத்தரவாதம் அளிக்கிறார்.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // வளைய மாறுபாடு: குழந்தை==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // பாதுகாப்பு: குழந்தை <முடிவு, 1 <self.len() மற்றும்
            //  குழந்தை + 1 <முடிவு <= self.len(), எனவே அவை சரியான குறியீடுகளாகும்.
            //  குழந்தை==2 *hole.pos() + 1!= hole.pos() மற்றும் குழந்தை + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: T என்பது ஒரு ZST ஆக இருந்தால் 2 *hole.pos() + 1 அல்லது 2* hole.pos() + 2 நிரம்பி வழியும்
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // பாதுகாப்பு: மேலே உள்ள அதே
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // பாதுகாப்பு: குழந்தை==முடிவு, 1 <self.len(), எனவே இது சரியான குறியீடாகும்
            //  மற்றும் குழந்தை==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // பாதுகாப்பு: pos என்பது துளையில் உள்ள நிலை மற்றும் ஏற்கனவே நிரூபிக்கப்பட்டது
        //  சரியான குறியீடாக இருக்க வேண்டும்.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // பாதுகாப்பு: n self.len()/2 இலிருந்து தொடங்கி 0 ஆக குறைகிறது.
            //  எப்போதுதான்! (N <self.len()) என்பது self.len() ==0 என்றால், ஆனால் அது லூப் நிபந்தனையால் நிராகரிக்கப்படுகிறது.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other` இன் அனைத்து கூறுகளையும் `self` க்கு நகர்த்தி, `other` காலியாக இருக்கும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` O(len1 + len2) செயல்பாடுகள் மற்றும் மோசமான நிலையில் சுமார் 2 *(len1 + len2) ஒப்பீடுகளை எடுக்கிறது, அதே நேரத்தில் `extend` O(len2* log(len1)) செயல்பாடுகளையும், சுமார் 1 *len2* log_2(len1) ஒப்பீடுகளையும் எடுக்கும், len1>= len2 என்று கருதுகிறது.
        // பெரிய குவியல்களுக்கு, குறுக்குவழி புள்ளி இனி இந்த பகுத்தறிவைப் பின்பற்றாது மற்றும் அனுபவ ரீதியாக தீர்மானிக்கப்பட்டது.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// குவியல் வரிசையில் உள்ள உறுப்புகளை மீட்டெடுக்கும் ஒரு ஈரேட்டரை வழங்குகிறது.
    /// மீட்டெடுக்கப்பட்ட கூறுகள் அசல் குவியலில் இருந்து அகற்றப்படுகின்றன.
    /// மீதமுள்ள கூறுகள் குவியல் வரிசையில் வீழ்ச்சியிலிருந்து அகற்றப்படும்.
    ///
    /// Note:
    /// * `.drain_sorted()` *O*(*n*\*log(* n*)); `.drain()` ஐ விட மிக மெதுவானது.
    ///   பெரும்பாலான சந்தர்ப்பங்களில் நீங்கள் பிந்தையதைப் பயன்படுத்த வேண்டும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // குவியல் வரிசையில் அனைத்து கூறுகளையும் நீக்குகிறது
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// முன்னறிவிப்பால் குறிப்பிடப்பட்ட கூறுகளை மட்டுமே வைத்திருக்கிறது.
    ///
    /// வேறு வார்த்தைகளில் கூறுவதானால், `e` அனைத்து உறுப்புகளையும் அகற்றவும், அதாவது `f(&e)` `false` ஐ வழங்குகிறது.
    /// கூறுகள் வரிசைப்படுத்தப்படாத (மற்றும் குறிப்பிடப்படாத) வரிசையில் பார்வையிடப்படுகின்றன.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // எண்களை மட்டுமே வைத்திருங்கள்
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// vector இன் அனைத்து மதிப்புகளையும் தன்னிச்சையான வரிசையில் பார்வையிடும் ஒரு ஈரேட்டரை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 ஐ தன்னிச்சையான வரிசையில் அச்சிடுங்கள்
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// குவியல் வரிசையில் உள்ள உறுப்புகளை மீட்டெடுக்கும் ஒரு ஈரேட்டரை வழங்குகிறது.
    /// இந்த முறை அசல் குவியலைப் பயன்படுத்துகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// பைனரி குவியலில் மிகப் பெரிய உருப்படி அல்லது காலியாக இருந்தால் `None` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # நேர சிக்கலானது
    ///
    /// மிக மோசமான நிலையில் செலவு *O*(1).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// மறு ஒதுக்கீடு செய்யாமல் பைனரி குவியல் வைத்திருக்கக்கூடிய உறுப்புகளின் எண்ணிக்கையை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// கொடுக்கப்பட்ட `BinaryHeap` இல் சரியாக `additional` கூடுதல் கூறுகளைச் செருகுவதற்கான குறைந்தபட்ச திறனை வைத்திருக்கிறது.
    /// திறன் ஏற்கனவே போதுமானதாக இருந்தால் எதுவும் செய்யாது.
    ///
    /// ஒதுக்கீடு செய்பவர் கோருவதை விட அதிக இடத்தை கொடுக்கக்கூடும் என்பதை நினைவில் கொள்க.
    /// எனவே திறனை துல்லியமாக மிகக் குறைவாக நம்ப முடியாது.
    /// future செருகல்கள் எதிர்பார்க்கப்பட்டால் [`reserve`] ஐ விரும்பவும்.
    ///
    /// # Panics
    ///
    /// புதிய திறன் `usize` ஐ நிரம்பி வழிகிறது என்றால் Panics.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap` இல் செருகுவதற்கு குறைந்தபட்சம் `additional` கூடுதல் உறுப்புகளுக்கான இருப்பு திறன்.
    /// அடிக்கடி மறு ஒதுக்கீடு செய்வதைத் தவிர்ப்பதற்கு சேகரிப்பு அதிக இடத்தை ஒதுக்கக்கூடும்.
    ///
    /// # Panics
    ///
    /// புதிய திறன் `usize` ஐ நிரம்பி வழிகிறது என்றால் Panics.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// முடிந்தவரை கூடுதல் திறனை நிராகரிக்கிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// குறைந்த வரம்புடன் திறனை நிராகரிக்கிறது.
    ///
    /// திறன் நீளம் மற்றும் வழங்கப்பட்ட மதிப்பு இரண்டையும் விட பெரியதாக இருக்கும்.
    ///
    ///
    /// தற்போதைய திறன் குறைந்த வரம்பை விட குறைவாக இருந்தால், இது ஒரு விருப்பம் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` ஐப் பயன்படுத்துகிறது மற்றும் அடிப்படை vector ஐ தன்னிச்சையான வரிசையில் தருகிறது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // சில வரிசையில் அச்சிடும்
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// பைனரி குவியலின் நீளத்தை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// பைனரி குவியல் காலியாக இருந்தால் சரிபார்க்கிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// பைனரி குவியலை அழிக்கிறது, அகற்றப்பட்ட உறுப்புகளின் மீது ஒரு ஈரேட்டரைத் தருகிறது.
    ///
    /// கூறுகள் தன்னிச்சையான வரிசையில் அகற்றப்படுகின்றன.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// பைனரி குவியலிலிருந்து அனைத்து பொருட்களையும் கைவிடுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// துளை ஒரு துண்டில் ஒரு துளையை குறிக்கிறது, அதாவது சரியான மதிப்பு இல்லாத ஒரு குறியீடு (ஏனெனில் அது நகர்த்தப்பட்டது அல்லது நகல் செய்யப்பட்டது).
///
/// துளியில், `Hole` துளை நிலையை முதலில் அகற்றப்பட்ட மதிப்புடன் நிரப்புவதன் மூலம் துண்டுகளை மீட்டமைக்கும்.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// குறியீட்டு `pos` இல் புதிய `Hole` ஐ உருவாக்கவும்.
    ///
    /// பாதுகாப்பற்றது ஏனெனில் போஸ் தரவு துண்டுக்குள் இருக்க வேண்டும்.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // பாதுகாப்பானது: போஸ் ஸ்லைஸுக்குள் இருக்க வேண்டும்
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// அகற்றப்பட்ட உறுப்புக்கான குறிப்பை வழங்குகிறது.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index` இல் உள்ள உறுப்புக்கான குறிப்பை வழங்குகிறது.
    ///
    /// பாதுகாப்பற்றது, ஏனெனில் குறியீட்டு தரவு துண்டுகளாக இருக்க வேண்டும் மற்றும் போஸுக்கு சமமாக இருக்கக்கூடாது.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// துளை புதிய இடத்திற்கு நகர்த்தவும்
    ///
    /// பாதுகாப்பற்றது, ஏனெனில் குறியீட்டு தரவு துண்டுகளாக இருக்க வேண்டும் மற்றும் போஸுக்கு சமமாக இருக்கக்கூடாது.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // மீண்டும் துளை நிரப்பவும்
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// ஒரு `BinaryHeap` இன் கூறுகளின் மீது ஒரு ஈரேட்டர்.
///
/// இந்த `struct` ஆனது [`BinaryHeap::iter()`] ஆல் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` க்கு ஆதரவாக அகற்று
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// ஒரு `BinaryHeap` இன் உறுப்புகளுக்கு மேல் ஒரு சொந்த ஈரேட்டர்.
///
/// இந்த `struct` ஆனது [`BinaryHeap::into_iter()`] ஆல் உருவாக்கப்பட்டது (`IntoIterator` trait ஆல் வழங்கப்படுகிறது).
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// ஒரு `BinaryHeap` இன் உறுப்புகளின் மீது வடிகட்டும் ஈரேட்டர்.
///
/// இந்த `struct` ஆனது [`BinaryHeap::drain()`] ஆல் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// ஒரு `BinaryHeap` இன் உறுப்புகளின் மீது வடிகட்டும் ஈரேட்டர்.
///
/// இந்த `struct` ஆனது [`BinaryHeap::drain_sorted()`] ஆல் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// குவியல் வரிசையில் குவியல் கூறுகளை நீக்குகிறது.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// ஒரு `Vec<T>` ஐ `BinaryHeap<T>` ஆக மாற்றுகிறது.
    ///
    /// இந்த மாற்றம் இடத்தில் நிகழ்கிறது, மேலும் *O*(*n*) நேர சிக்கலைக் கொண்டுள்ளது.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// ஒரு `BinaryHeap<T>` ஐ `Vec<T>` ஆக மாற்றுகிறது.
    ///
    /// இந்த மாற்றத்திற்கு தரவு இயக்கம் அல்லது ஒதுக்கீடு தேவையில்லை, மேலும் நிலையான நேர சிக்கலைக் கொண்டுள்ளது.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// நுகரும் ஈரேட்டரை உருவாக்குகிறது, அதாவது, பைனரி குவியலிலிருந்து ஒவ்வொரு மதிப்பையும் தன்னிச்சையான வரிசையில் நகர்த்தும் ஒன்று.
    /// இதை அழைத்த பிறகு பைனரி குவியலைப் பயன்படுத்த முடியாது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 ஐ தன்னிச்சையான வரிசையில் அச்சிடுங்கள்
    /// for x in heap.into_iter() {
    ///     // x வகை i32, &i32 அல்ல
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}