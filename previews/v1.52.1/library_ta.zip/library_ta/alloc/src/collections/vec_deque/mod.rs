//! வளரக்கூடிய மோதிர இடையகத்துடன் செயல்படுத்தப்பட்ட இரட்டை முனை வரிசை.
//!
//! இந்த வரிசையில் கொள்கலனின் இரு முனைகளிலிருந்தும் *O*(1) மன்னிப்புச் செருகல்கள் மற்றும் நீக்குதல்கள் உள்ளன.
//! இது vector போன்ற *O*(1) குறியீட்டையும் கொண்டுள்ளது.
//! உள்ள கூறுகள் நகலெடுக்கப்பட வேண்டிய அவசியமில்லை, மற்றும் கொண்டிருக்கும் வகை அனுப்பக்கூடியதாக இருந்தால் வரிசை அனுப்பப்படும்.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // இரண்டின் மிகப்பெரிய சக்தி

/// வளரக்கூடிய மோதிர இடையகத்துடன் செயல்படுத்தப்பட்ட இரட்டை முனை வரிசை.
///
/// இந்த வகையின் "default" பயன்பாடு வரிசையில் சேர்க்க [`push_back`] ஐயும், வரிசையில் இருந்து அகற்ற [`pop_front`] ஐப் பயன்படுத்துவதும் ஆகும்.
///
/// [`extend`] மற்றும் [`append`] இந்த முறையில் பின்புறத்தில் தள்ளப்படுகிறது, மேலும் `VecDeque` க்கு மேல் மீண்டும் செயல்படுவது முன்னால் பின்னால் செல்கிறது.
///
/// `VecDeque` ஒரு மோதிர இடையகமாக இருப்பதால், அதன் கூறுகள் நினைவகத்தில் தொடர்ச்சியாக இருக்காது.
/// திறமையான வரிசையாக்கம் போன்ற உறுப்புகளை ஒற்றை துண்டாக அணுக விரும்பினால், நீங்கள் [`make_contiguous`] ஐப் பயன்படுத்தலாம்.
/// இது `VecDeque` ஐ சுழற்றுகிறது, இதனால் அதன் கூறுகள் மடக்காது, மேலும் இப்போது மாறக்கூடிய உறுப்பு வரிசைக்கு ஒரு மாற்றக்கூடிய துண்டுகளை வழங்குகிறது.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // வால் மற்றும் தலை ஆகியவை இடையகத்திற்குள் சுட்டிகள்.
    // வால் எப்போதும் படிக்கக்கூடிய முதல் உறுப்பை சுட்டிக்காட்டுகிறது, தலை எப்போதும் தரவு எழுதப்பட வேண்டிய இடத்தை சுட்டிக்காட்டுகிறது.
    //
    // வால்==தலை என்றால் இடையக காலியாக உள்ளது.ரிங்பஃப்பரின் நீளம் இரண்டிற்கும் இடையிலான தூரம் என வரையறுக்கப்படுகிறது.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// ஸ்லைஸில் உள்ள அனைத்து பொருட்களுக்கும் டிஸ்ட்ரக்டரை அது கைவிடும்போது இயக்குகிறது (பொதுவாக அல்லது பிரிக்கப்படாத போது).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T] க்கு துளி பயன்படுத்தவும்
            ptr::drop_in_place(front);
        }
        // ராவ் டெக்லோகேஷனைக் கையாளுகிறது
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// வெற்று `VecDeque<T>` ஐ உருவாக்குகிறது.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// ஓரளவு வசதியானது
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// ஓரளவு வசதியானது
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // பூஜ்ஜிய அளவிலான வகைகளுக்கு, நாங்கள் எப்போதும் அதிகபட்ச திறனில் இருக்கிறோம்
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Ptr ஐ ஒரு துண்டுகளாக மாற்றவும்
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Ptr ஐ ஒரு மட் ஸ்லைஸாக மாற்றவும்
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// இடையகத்திலிருந்து ஒரு உறுப்பை நகர்த்துகிறது
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// ஒரு உறுப்பை இடையகத்திற்குள் எழுதி, அதை நகர்த்தும்.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// இடையக முழு திறன் இருந்தால் `true` ஐ வழங்குகிறது.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// கொடுக்கப்பட்ட தருக்க உறுப்பு குறியீட்டுக்கான அடிப்படை இடையகத்தில் குறியீட்டை வழங்குகிறது.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// கொடுக்கப்பட்ட தருக்க உறுப்பு குறியீட்டு + சேர்க்கைக்கு அடிப்படை இடையகத்தில் குறியீட்டை வழங்குகிறது.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// கொடுக்கப்பட்ட தருக்க உறுப்பு குறியீட்டிற்கான துணை தாங்கியில் உள்ள குறியீட்டை வழங்குகிறது, சப்ட்ராஹெண்ட்.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src முதல் dst வரை நீளமான மெமரி லென் நகலை நகலெடுக்கிறது
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src முதல் dst வரை நீளமான மெமரி லென் நகலை நகலெடுக்கிறது
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src இலிருந்து டெஸ்ட்டுக்கு நீளமான மெமரி லென் தொகுப்பை நகலெடுக்கிறது.
    /// (abs(dst - src) + லென்) cap() ஐ விட பெரியதாக இருக்கக்கூடாது (src மற்றும் dest க்கு இடையில் ஒரு தொடர்ச்சியான ஒன்றுடன் ஒன்று இருக்க வேண்டும்).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src மடக்குவதில்லை, dst மடக்குவதில்லை
                //
                //        எஸ்...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] டி.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // src க்கு முன் dst, src மடக்குவதில்லை, dst மடக்குகிறது
                //
                //
                //    எஸ்...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. டி.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // Dst க்கு முன் src, src மடக்குவதில்லை, dst மடக்குகிறது
                //
                //
                //              எஸ்...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. டி.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // src க்கு முன் dst, src மடக்குகிறது, dst மடக்குவதில்லை
                //
                //
                //    .. எஸ்.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] டி...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // Dst க்கு முன் src, src மடக்கு, dst மடக்குவதில்லை
                //
                //
                //    .. எஸ்.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] டி...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // src க்கு முன் dst, src மறைப்புகள், dst மறைப்புகள்
                //
                //
                //    ... எஸ்.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. டி..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // Dst க்கு முன் src, src மடக்கு, dst மடக்கு
                //
                //
                //    .. எஸ்..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... டி.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// நாங்கள் மறு ஒதுக்கீடு செய்துள்ளோம் என்பதைக் கையாள தலை மற்றும் வால் பிரிவுகளைச் சுற்றிலும்.
    /// பாதுகாப்பற்றது ஏனெனில் இது பழைய_ திறனை நம்புகிறது.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // ரிங் பஃபர் TH இன் குறுகிய தொடர்ச்சியான பகுதியை நகர்த்தவும்
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // ஒரு நோப்
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// வெற்று `VecDeque` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// குறைந்தது `capacity` உறுப்புகளுக்கான இடத்துடன் வெற்று `VecDeque` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // ரிங்பஃபர் எப்போதும் ஒரு இடத்தை காலியாக வைத்திருப்பதால் +1
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// கொடுக்கப்பட்ட குறியீட்டில் உள்ள உறுப்புக்கான குறிப்பை வழங்குகிறது.
    ///
    /// குறியீட்டு 0 இல் உள்ள உறுப்பு வரிசையின் முன் பகுதி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// கொடுக்கப்பட்ட குறியீட்டில் உள்ள உறுப்புக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// குறியீட்டு 0 இல் உள்ள உறுப்பு வரிசையின் முன் பகுதி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// `i` மற்றும் `j` குறியீடுகளில் கூறுகளை மாற்றுகிறது.
    ///
    /// `i` மற்றும் `j` சமமாக இருக்கலாம்.
    ///
    /// குறியீட்டு 0 இல் உள்ள உறுப்பு வரிசையின் முன் பகுதி.
    ///
    /// # Panics
    ///
    /// குறியீட்டு எல்லைக்கு அப்பாற்பட்டால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// மறு ஒதுக்கீடு செய்யாமல் `VecDeque` வைத்திருக்கக்கூடிய உறுப்புகளின் எண்ணிக்கையை வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// கொடுக்கப்பட்ட `VecDeque` இல் சரியாக `additional` கூடுதல் கூறுகளைச் செருகுவதற்கான குறைந்தபட்ச திறனை வைத்திருக்கிறது.
    /// திறன் ஏற்கனவே போதுமானதாக இருந்தால் எதுவும் செய்யாது.
    ///
    /// ஒதுக்கீடு செய்பவர் கோருவதை விட அதிக இடத்தை கொடுக்கக்கூடும் என்பதை நினைவில் கொள்க.
    /// எனவே திறனை துல்லியமாக மிகக் குறைவாக நம்ப முடியாது.
    /// future செருகல்கள் எதிர்பார்க்கப்பட்டால் [`reserve`] ஐ விரும்பவும்.
    ///
    /// # Panics
    ///
    /// புதிய திறன் `usize` ஐ நிரம்பி வழிகிறது என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// கொடுக்கப்பட்ட `VecDeque` இல் செருகப்பட குறைந்தபட்சம் `additional` கூடுதல் உறுப்புகளுக்கான இருப்பு திறன்.
    /// அடிக்கடி மறு ஒதுக்கீடு செய்வதைத் தவிர்ப்பதற்கு சேகரிப்பு அதிக இடத்தை ஒதுக்கக்கூடும்.
    ///
    /// # Panics
    ///
    /// புதிய திறன் `usize` ஐ நிரம்பி வழிகிறது என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// கொடுக்கப்பட்ட `VecDeque<T>` இல் சரியாக `additional` கூடுதல் கூறுகளைச் செருகுவதற்கான குறைந்தபட்ச திறனை ஒதுக்க முயற்சிக்கிறது.
    ///
    /// `try_reserve_exact` ஐ அழைத்த பிறகு, திறன் `self.len() + additional` ஐ விட அதிகமாகவோ அல்லது சமமாகவோ இருக்கும்.
    /// திறன் ஏற்கனவே போதுமானதாக இருந்தால் எதுவும் செய்யாது.
    ///
    /// ஒதுக்கீடு செய்பவர் கோருவதை விட அதிக இடத்தை கொடுக்கக்கூடும் என்பதை நினைவில் கொள்க.
    /// எனவே, திறனை துல்லியமாக மிகக் குறைவாக நம்ப முடியாது.
    /// future செருகல்கள் எதிர்பார்க்கப்பட்டால் `reserve` ஐ விரும்புங்கள்.
    ///
    /// # Errors
    ///
    /// திறன் `usize` ஐ நிரம்பி வழிகிறது அல்லது ஒதுக்கீட்டாளர் தோல்வியைப் புகாரளித்தால், பிழை திரும்பும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // நினைவகத்தை முன்பதிவு செய்யுங்கள், முடியாவிட்டால் வெளியேறும்
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // எங்கள் சிக்கலான வேலையின் நடுவில் இது OOM(Out-Of-Memory) முடியாது என்பதை இப்போது அறிவோம்
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // மிகவும் சிக்கலான
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// கொடுக்கப்பட்ட `VecDeque<T>` இல் செருகுவதற்கு குறைந்தபட்சம் `additional` கூடுதல் உறுப்புகளுக்கான திறனை முன்பதிவு செய்ய முயற்சிக்கிறது.
    /// அடிக்கடி மறு ஒதுக்கீடு செய்வதைத் தவிர்ப்பதற்கு சேகரிப்பு அதிக இடத்தை ஒதுக்கக்கூடும்.
    /// `try_reserve` ஐ அழைத்த பிறகு, திறன் `self.len() + additional` ஐ விட அதிகமாகவோ அல்லது சமமாகவோ இருக்கும்.
    /// திறன் ஏற்கனவே போதுமானதாக இருந்தால் எதுவும் செய்யாது.
    ///
    /// # Errors
    ///
    /// திறன் `usize` ஐ நிரம்பி வழிகிறது அல்லது ஒதுக்கீட்டாளர் தோல்வியைப் புகாரளித்தால், பிழை திரும்பும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // நினைவகத்தை முன்பதிவு செய்யுங்கள், முடியாவிட்டால் வெளியேறும்
    ///     output.try_reserve(data.len())?;
    ///
    ///     // எங்கள் சிக்கலான வேலைக்கு நடுவில் இது OOM முடியாது என்று இப்போது எங்களுக்குத் தெரியும்
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // மிகவும் சிக்கலான
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// `VecDeque` இன் திறனை முடிந்தவரை சுருங்குகிறது.
    ///
    /// இது நீளத்திற்கு முடிந்தவரை கீழே இறங்கும், ஆனால் இன்னும் சில உறுப்புகளுக்கு இடம் இருப்பதாக ஒதுக்கீட்டாளர் இன்னும் `VecDeque` க்கு தெரிவிக்கலாம்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// `VecDeque` இன் திறனை குறைந்த வரம்புடன் சுருக்கி விடுகிறது.
    ///
    /// திறன் நீளம் மற்றும் வழங்கப்பட்ட மதிப்பு இரண்டையும் விட பெரியதாக இருக்கும்.
    ///
    ///
    /// தற்போதைய திறன் குறைந்த வரம்பை விட குறைவாக இருந்தால், இது ஒரு விருப்பம் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // `self.len()` அல்லது `self.capacity()` ஆகியவை எப்போதும் `usize::MAX` ஆக இருக்க முடியாது என்பதால் நாம் ஒரு வழிதல் பற்றி கவலைப்பட வேண்டியதில்லை.
        // ரிங்பஃபர் எப்போதும் ஒரு இடத்தை காலியாக விட்டுவிடுவதால் +1.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // மூன்று வட்டி வழக்குகள் உள்ளன:
            //   அனைத்து உறுப்புகளும் விரும்பிய எல்லைக்கு அப்பாற்பட்டவை கூறுகள் தொடர்ச்சியாக இருக்கின்றன, மேலும் தலை விரும்பிய எல்லைக்கு அப்பாற்பட்டது கூறுகள் இடைவிடாது, மற்றும் வால் விரும்பிய எல்லைகளுக்கு வெளியே உள்ளது
            //
            //
            // மற்ற எல்லா நேரங்களிலும், உறுப்பு நிலைகள் பாதிக்கப்படாது.
            //
            // தலையில் உள்ள கூறுகளை நகர்த்த வேண்டும் என்பதைக் குறிக்கிறது.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // விரும்பிய எல்லைகளுக்கு வெளியே உறுப்புகளை நகர்த்தவும் (இலக்கு_காப்பிற்குப் பிறகு நிலைகள்)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// `VecDeque` ஐக் குறைக்கிறது, முதல் `len` கூறுகளை வைத்து மீதமுள்ளவற்றைக் கைவிடுகிறது.
    ///
    ///
    /// `len` `VecDeque` இன் தற்போதைய நீளத்தை விட அதிகமாக இருந்தால், இது எந்த விளைவையும் ஏற்படுத்தாது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// ஸ்லைஸில் உள்ள அனைத்து பொருட்களுக்கும் டிஸ்ட்ரக்டரை அது கைவிடும்போது இயக்குகிறது (பொதுவாக அல்லது பிரிக்கப்படாத போது).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // பாதுகாப்பான ஏனெனில்:
        //
        // * `drop_in_place` க்கு அனுப்பப்பட்ட எந்த துண்டுகளும் செல்லுபடியாகும்;இரண்டாவது வழக்கு `len <= front.len()` ஐக் கொண்டுள்ளது மற்றும் `len > self.len()` இல் திரும்புவது முதல் வழக்கில் `begin <= back.len()` ஐ உறுதி செய்கிறது
        //
        // * `drop_in_place` ஐ அழைப்பதற்கு முன்பு VecDeque இன் தலை நகர்த்தப்படுகிறது, எனவே `drop_in_place` panics என்றால் எந்த மதிப்பும் இரண்டு முறை கைவிடப்படாது
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // முதல் ஒரு panics இல் ஒரு அழிக்கும் போது கூட இரண்டாவது பாதி கைவிடப்படுவதை உறுதிசெய்க.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// முன்-பின்-பின் ஐரேட்டரை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// மாற்றக்கூடிய குறிப்புகளைத் தரும் முன்-பின்-பின் ஐரேட்டரை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // பாதுகாப்பு: உள் `IterMut` பாதுகாப்பு மாறுபாடு நிறுவப்பட்டுள்ளது, ஏனெனில்
        // `ring` நாங்கள் உருவாக்குவது வாழ்நாள் முழுவதும் வரையறுக்க முடியாத துண்டு '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` இன் உள்ளடக்கங்களைக் கொண்டிருக்கும் ஒரு ஜோடி துண்டுகளை வழங்குகிறது.
    ///
    /// [`make_contiguous`] முன்பு அழைக்கப்பட்டிருந்தால், `VecDeque` இன் அனைத்து கூறுகளும் முதல் ஸ்லைஸில் இருக்கும், இரண்டாவது ஸ்லைஸ் காலியாக இருக்கும்.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// `VecDeque` இன் உள்ளடக்கங்களைக் கொண்டிருக்கும் ஒரு ஜோடி துண்டுகளை வழங்குகிறது.
    ///
    /// [`make_contiguous`] முன்பு அழைக்கப்பட்டிருந்தால், `VecDeque` இன் அனைத்து கூறுகளும் முதல் ஸ்லைஸில் இருக்கும், இரண்டாவது ஸ்லைஸ் காலியாக இருக்கும்.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` இல் உள்ள உறுப்புகளின் எண்ணிக்கையை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// `VecDeque` காலியாக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// `VecDeque` இல் குறிப்பிட்ட வரம்பை உள்ளடக்கிய ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// # Panics
    ///
    /// தொடக்க புள்ளி இறுதி புள்ளியை விட அதிகமாக இருந்தால் அல்லது இறுதி புள்ளி vector இன் நீளத்தை விட அதிகமாக இருந்தால் Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // ஒரு முழு வரம்பு அனைத்து உள்ளடக்கங்களையும் உள்ளடக்கியது
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // &self இல் எங்களிடம் உள்ள பகிரப்பட்ட குறிப்பு '_ ஐட்டரில் பராமரிக்கப்படுகிறது.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// `VecDeque` இல் குறிப்பிட்ட மாற்றக்கூடிய வரம்பை உள்ளடக்கிய ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// # Panics
    ///
    /// தொடக்க புள்ளி இறுதி புள்ளியை விட அதிகமாக இருந்தால் அல்லது இறுதி புள்ளி vector இன் நீளத்தை விட அதிகமாக இருந்தால் Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // ஒரு முழு வரம்பு அனைத்து உள்ளடக்கங்களையும் உள்ளடக்கியது
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // பாதுகாப்பு: உள் `IterMut` பாதுகாப்பு மாறுபாடு நிறுவப்பட்டுள்ளது, ஏனெனில்
        // `ring` நாங்கள் உருவாக்குவது வாழ்நாள் முழுவதும் வரையறுக்க முடியாத துண்டு '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` இல் குறிப்பிட்ட வரம்பை அகற்றி, அகற்றப்பட்ட உருப்படிகளை வழங்கும் வடிகட்டிய ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// குறிப்பு 1: இறுதி வரை ஈரேட்டர் நுகரப்படாவிட்டாலும் உறுப்பு வரம்பு அகற்றப்படும்.
    ///
    /// குறிப்பு 2: எக்ஸ் 100 எக்ஸ் மதிப்பு கைவிடப்படாவிட்டால், எத்தனை கூறுகள் டெக்கிலிருந்து அகற்றப்படுகின்றன என்பது குறிப்பிடப்படவில்லை, ஆனால் அது வைத்திருக்கும் கடன் காலாவதியாகிறது (எ.கா., எக்ஸ் 01 எக்ஸ் காரணமாக).
    ///
    ///
    /// # Panics
    ///
    /// தொடக்க புள்ளி இறுதி புள்ளியை விட அதிகமாக இருந்தால் அல்லது இறுதி புள்ளி vector இன் நீளத்தை விட அதிகமாக இருந்தால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // ஒரு முழு வீச்சு அனைத்து உள்ளடக்கங்களையும் அழிக்கிறது
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // நினைவக பாதுகாப்பு
        //
        // Drain முதன்முதலில் உருவாக்கப்படும் போது, Drain இன் அழிப்பான் ஒருபோதும் இயங்கவில்லை என்றால், துவக்கப்படாத அல்லது நகர்த்தப்பட்ட உறுப்புகள் எதையும் அணுக முடியாது என்பதை உறுதிப்படுத்த மூல டெக் சுருக்கப்பட்டது.
        //
        //
        // Drain அகற்றுவதற்கான மதிப்புகளை ptr::read செய்யும்.
        // முடிந்ததும், மீதமுள்ள தரவு துளை மறைக்க மீண்டும் நகலெடுக்கப்படும், மேலும் head/tail மதிப்புகள் சரியாக மீட்டமைக்கப்படும்.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // டெக்கின் கூறுகள் மூன்று பிரிவுகளாக பிரிக்கப்பட்டுள்ளன:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // டி=எக்ஸ் 100 எக்ஸ்;எச்=எக்ஸ் 01 எக்ஸ்;t=drain_tail;h=drain_head
        //
        // நாங்கள் drain_tail ஐ self.head ஆகவும், drain_head மற்றும் self.head ஐ முறையே after0tail ஆகவும், after_head ஆகவும் Drain இல் சேமிக்கிறோம்.
        // இது Drain கசிந்தால், drain இன் தொடக்கத்திற்குப் பிறகு நகர்த்தக்கூடிய மதிப்புகளைப் பற்றி நாம் மறந்துவிட்டோம்.
        //
        //
        //        டி வது எச்
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain இன் தொடக்கத்திற்குப் பிறகு drain முடிந்ததும் Drain அழிப்பான் இயங்கும் வரை மதிப்புகள் பற்றி.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // முக்கியமாக, நாங்கள் இங்கே `self` இலிருந்து பகிரப்பட்ட குறிப்புகளை மட்டுமே உருவாக்கி அதிலிருந்து படிக்கிறோம்.
                // நாங்கள் `self` க்கு எழுதவோ அல்லது மாற்றக்கூடிய குறிப்புக்கு மறுபிரவேசம் செய்யவோ இல்லை.
                // எனவே `deque` க்கு நாம் மேலே உருவாக்கிய மூல சுட்டிக்காட்டி செல்லுபடியாகும்.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// `VecDeque` ஐ அழிக்கிறது, எல்லா மதிப்புகளையும் நீக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// கொடுக்கப்பட்ட மதிப்புக்கு சமமான ஒரு உறுப்பை `VecDeque` கொண்டிருந்தால் `true` ஐ வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// முன் உறுப்புக்கான குறிப்பை வழங்குகிறது, அல்லது `VecDeque` காலியாக இருந்தால் `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// முன் உறுப்புக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது, அல்லது `VecDeque` காலியாக இருந்தால் `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// பின்புற உறுப்புக்கான குறிப்பை வழங்குகிறது, அல்லது `VecDeque` காலியாக இருந்தால் `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// பின்புற உறுப்புக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது, அல்லது `VecDeque` காலியாக இருந்தால் `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// முதல் உறுப்பை அகற்றி அதை திருப்பித் தருகிறது, அல்லது `VecDeque` காலியாக இருந்தால் `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque` இலிருந்து கடைசி உறுப்பை அகற்றி அதை திருப்பித் தருகிறது, அல்லது `None` காலியாக இருந்தால்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// `VecDeque` க்கு ஒரு உறுப்பை தயார் செய்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` இன் பின்புறத்தில் ஒரு உறுப்பைச் சேர்க்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: `head == 0` ஐ நாம் கருத்தில் கொள்ள வேண்டுமா
        // `self` தொடர்ச்சியாக இருக்கிறதா?
        self.tail <= self.head
    }

    /// `VecDeque` இல் எங்கிருந்தும் ஒரு உறுப்பை அகற்றி அதை திருப்பி, முதல் உறுப்புடன் மாற்றுகிறது.
    ///
    ///
    /// இது வரிசைப்படுத்தலைப் பாதுகாக்காது, ஆனால் *O*(1).
    ///
    /// `index` எல்லைக்கு அப்பாற்பட்டால் `None` ஐ வழங்குகிறது.
    ///
    /// குறியீட்டு 0 இல் உள்ள உறுப்பு வரிசையின் முன் பகுதி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// `VecDeque` இல் எங்கிருந்தும் ஒரு உறுப்பை அகற்றி அதை திருப்பி, கடைசி உறுப்புடன் மாற்றுகிறது.
    ///
    ///
    /// இது வரிசைப்படுத்தலைப் பாதுகாக்காது, ஆனால் *O*(1).
    ///
    /// `index` எல்லைக்கு அப்பாற்பட்டால் `None` ஐ வழங்குகிறது.
    ///
    /// குறியீட்டு 0 இல் உள்ள உறுப்பு வரிசையின் முன் பகுதி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// `VecDeque` க்குள் `index` இல் ஒரு உறுப்பைச் செருகுகிறது, எல்லா உறுப்புகளையும் `index` ஐ விட அதிகமாகவோ அல்லது சமமாகவோ குறியீடுகளுடன் பின்னால் நோக்கி மாற்றுகிறது.
    ///
    ///
    /// குறியீட்டு 0 இல் உள்ள உறுப்பு வரிசையின் முன் பகுதி.
    ///
    /// # Panics
    ///
    /// `VecDeque` இன் நீளத்தை விட `index` அதிகமாக இருந்தால் Panics
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // ரிங் பஃப்பரில் குறைந்த எண்ணிக்கையிலான உறுப்புகளை நகர்த்தி, கொடுக்கப்பட்ட பொருளை செருகவும்
        //
        // அதிகபட்சம் len/2 இல், 1 கூறுகள் நகர்த்தப்படும். O(min(n, n-i))
        //
        // மூன்று முக்கிய வழக்குகள் உள்ளன:
        //  கூறுகள் தொடர்ச்சியாக உள்ளன
        //      - வால் 0 ஆக இருக்கும்போது சிறப்பு வழக்கு கூறுகள் இடைவிடாது மற்றும் செருகல் வால் பிரிவில் இருக்கும் கூறுகள் இடைவிடாது மற்றும் செருகல் தலை பிரிவில் இருக்கும்
        //
        //
        // அவை ஒவ்வொன்றிற்கும் மேலும் இரண்டு வழக்குகள் உள்ளன:
        //  செருகு வால் நெருக்கமாக உள்ளது செருகு தலைக்கு நெருக்கமாக உள்ளது
        //
        // விசை: H, self.head
        //      T, self.tail o, செல்லுபடியாகும் உறுப்பு I, செருகும் உறுப்பு A, செருகும் புள்ளி M க்குப் பிறகு இருக்க வேண்டிய உறுப்பு, உறுப்பு நகர்த்தப்பட்டதைக் குறிக்கிறது
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [ஒரு oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // தொடர்ச்சியான, வால் நெருக்கமாக செருக:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // தொடர்ச்சியான, வால் மற்றும் வால் நெருக்கமாக செருக 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       எம்.எம்

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // ஏற்கனவே வால் நகர்த்தப்பட்டது, எனவே நாங்கள் `index - 1` கூறுகளை மட்டுமே நகலெடுக்கிறோம்.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // தொடர்ச்சியான, தலைக்கு நெருக்கமாக செருகவும்:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       எம்.எம்.எம்

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // இடைவிடாத, வால், வால் பிரிவுக்கு நெருக்கமாக செருகவும்:
                    //
                    //                   எச்.டி.ஐ.
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // இடைவிடாத, தலைக்கு நெருக்கமாக செருக, வால் பிரிவு:
                    //
                    //           எச்.டி.ஐ.
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       எம்.எம்.எம்.எம்

                    // புதிய தலை வரை கூறுகளை நகலெடுக்கவும்
                    self.copy(1, 0, self.head);

                    // கடைசி உறுப்பை இடையகத்தின் அடிப்பகுதியில் வெற்று இடத்தில் நகலெடுக்கவும்
                    self.copy(0, self.cap() - 1, 1);

                    // id உறுப்பு உட்பட ஐடெக்ஸிலிருந்து உறுப்புகளை முன்னோக்கி நகர்த்தவும்
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // இடைவிடாத, செருகல் வால், தலை பிரிவுக்கு நெருக்கமாக உள்ளது, மேலும் உள் இடையகத்தில் குறியீட்டு பூஜ்ஜியத்தில் உள்ளது:
                    //
                    //
                    //       ஐ.எச்.டி.
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               எம்.எம்.எம்

                    // புதிய வால் வரை கூறுகளை நகலெடுக்கவும்
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // கடைசி உறுப்பை இடையகத்தின் அடிப்பகுதியில் வெற்று இடத்தில் நகலெடுக்கவும்
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // இடைவிடாத, வால், தலை பிரிவுக்கு நெருக்கமாக செருகவும்:
                    //
                    //             ஐ.எச்.டி.
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       எம்.எம்.எம்.எம்.எம்.எம்

                    // புதிய வால் வரை கூறுகளை நகலெடுக்கவும்
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // கடைசி உறுப்பை இடையகத்தின் அடிப்பகுதியில் வெற்று இடத்தில் நகலெடுக்கவும்
                    self.copy(self.cap() - 1, 0, 1);

                    // X உறுப்பு உட்பட idx-1 இலிருந்து உறுப்புகளை முன்னோக்கி நகர்த்தவும்
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // இடைவிடாத, தலைக்கு நெருக்கமாக செருக, தலை பிரிவு:
                    //
                    //               ஐ.எச்.டி.
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 எம்.எம்.எம்

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // வால் மாற்றப்பட்டிருக்கலாம், எனவே நாம் மீண்டும் கணக்கிட வேண்டும்
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `VecDeque` இலிருந்து `index` இல் உள்ள உறுப்பை அகற்றி வழங்குகிறது.
    /// எந்த முடிவை அகற்றும் இடத்திற்கு நெருக்கமாக இருந்தாலும் அறை செய்ய நகர்த்தப்படும், மேலும் பாதிக்கப்பட்ட அனைத்து கூறுகளும் புதிய நிலைகளுக்கு நகர்த்தப்படும்.
    ///
    /// `index` எல்லைக்கு அப்பாற்பட்டால் `None` ஐ வழங்குகிறது.
    ///
    /// குறியீட்டு 0 இல் உள்ள உறுப்பு வரிசையின் முன் பகுதி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // மூன்று முக்கிய வழக்குகள் உள்ளன:
        //  கூறுகள் தொடர்ச்சியானவை கூறுகள் இடைவிடாதவை மற்றும் அகற்றுதல் வால் பிரிவில் உள்ளது கூறுகள் இடைவிடாது மற்றும் அகற்றுதல் தலைப் பிரிவில் உள்ளது
        //
        //      - கூறுகள் தொழில்நுட்ப ரீதியாக தொடர்ச்சியாக இருக்கும்போது சிறப்பு வழக்கு, ஆனால் self.head =0
        //
        // அவை ஒவ்வொன்றிற்கும் மேலும் இரண்டு வழக்குகள் உள்ளன:
        //  செருகு வால் நெருக்கமாக உள்ளது செருகு தலைக்கு நெருக்கமாக உள்ளது
        //
        // விசை: H, self.head
        //      T, self.tail o, செல்லுபடியாகும் உறுப்பு x, R ஐ அகற்றுவதற்காக குறிக்கப்பட்ட உறுப்பு, அகற்றப்படும் உறுப்பைக் குறிக்கிறது M, உறுப்பு நகர்த்தப்பட்டது என்பதைக் குறிக்கிறது
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // தொடர்ச்சியான, வால் நெருக்கமாக நீக்க:
                    //
                    //             டி.ஆர்.எச்
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // தொடர்ச்சியான, தலைக்கு நெருக்கமாக அகற்றவும்:
                    //
                    //             டி.ஆர்.எச்
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // இடைவிடாத, வால், வால் பிரிவுக்கு நெருக்கமாக அகற்றவும்:
                    //
                    //                   எச்.டி.ஆர்
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // இடைவிடாத, தலைக்கு நெருக்கமாக அகற்றவும், தலை பிரிவு:
                    //
                    //               ஆர்.எச்.டி.
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // இடைவிடாத, தலைக்கு நெருக்கமாக அகற்றவும், வால் பிரிவு:
                    //
                    //             எச்.டி.ஆர்
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       எம்.எம்.எம்.எம்
                    //
                    // அல்லது அரை-இடைவிடாத, தலை, வால் பிரிவுக்கு அடுத்ததாக அகற்று:
                    //
                    //       எச்.டி.ஆர்
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // வால் பிரிவில் உள்ள கூறுகளை வரையவும்
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // வழிதல் தடுக்கிறது.
                    if self.head != 0 {
                        // முதல் உறுப்பை வெற்று இடத்தில் நகலெடுக்கவும்
                        self.copy(self.cap() - 1, 0, 1);

                        // தலை பிரிவில் உள்ள கூறுகளை பின்னோக்கி நகர்த்தவும்
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // இடைவிடாத, வால், தலை பிரிவுக்கு நெருக்கமாக அகற்றவும்:
                    //
                    //           ஆர்.எச்.டி.
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       எம்.எம்.எம்.எம்.எம்

                    // ஐடிஎக்ஸ் வரை உறுப்புகளில் வரையவும்
                    self.copy(1, 0, idx);

                    // கடைசி உறுப்பை வெற்று இடத்தில் நகலெடுக்கவும்
                    self.copy(0, self.cap() - 1, 1);

                    // கடைசி ஒன்றைத் தவிர்த்து, வால் இருந்து உறுப்புகளை முன்னோக்கி நகர்த்தவும்
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// கொடுக்கப்பட்ட குறியீட்டில் `VecDeque` ஐ இரண்டாகப் பிரிக்கிறது.
    ///
    /// புதிதாக ஒதுக்கப்பட்ட `VecDeque` ஐ வழங்குகிறது.
    /// `self` `[0, at)` கூறுகளைக் கொண்டுள்ளது, மேலும் திரும்பிய `VecDeque` இல் `[at, len)` கூறுகள் உள்ளன.
    ///
    /// `self` இன் திறன் மாறாது என்பதை நினைவில் கொள்க.
    ///
    /// குறியீட்டு 0 இல் உள்ள உறுப்பு வரிசையின் முன் பகுதி.
    ///
    /// # Panics
    ///
    /// `at > len` என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` முதல் பாதியில் உள்ளது.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // இரண்டாவது பாதியில் அனைத்தையும் எடுத்துக் கொள்ளுங்கள்.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` இரண்டாவது பாதியில் உள்ளது, முதல் பாதியில் நாம் தவிர்த்த கூறுகளுக்கு காரணியாக இருக்க வேண்டும்.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // இடையகங்களின் முனைகள் இருக்கும் இடத்தில் துப்புரவு
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other` இன் அனைத்து கூறுகளையும் `self` க்கு நகர்த்தி, `other` காலியாக இருக்கும்.
    ///
    /// # Panics
    ///
    /// சுயத்தில் உள்ள புதிய எண்ணிக்கையிலான கூறுகள் ஒரு `usize` ஐ நிரம்பி வழிகிறது என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // அப்பாவியாக impl
        self.extend(other.drain(..));
    }

    /// முன்னறிவிப்பால் குறிப்பிடப்பட்ட கூறுகளை மட்டுமே வைத்திருக்கிறது.
    ///
    /// வேறு வார்த்தைகளில் கூறுவதானால்,`e` அனைத்து உறுப்புகளையும் அகற்றவும், அதாவது `f(&e)` தவறானது.
    /// இந்த முறை இடத்தில் இயங்குகிறது, ஒவ்வொரு உறுப்புகளையும் அசல் வரிசையில் ஒரு முறை பார்வையிடுகிறது, மேலும் தக்கவைக்கப்பட்ட உறுப்புகளின் வரிசையை பாதுகாக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// ஒரு குறியீட்டைப் போல வெளிப்புற நிலையைக் கண்காணிக்க சரியான வரிசை பயனுள்ளதாக இருக்கும்.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // இது panic அல்லது நிறுத்தப்படலாம்
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // இடையக அளவை இரட்டிப்பாக்குங்கள்.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` இன் இடத்தில் மாற்றியமைக்கிறது, இதனால் `len()` `new_len` க்கு சமமாக இருக்கும், பின்புறத்திலிருந்து அதிகப்படியான கூறுகளை அகற்றுவதன் மூலமாகவோ அல்லது `generator` ஐ பின்புறத்திற்கு அழைப்பதன் மூலம் உருவாக்கப்படும் கூறுகளை சேர்ப்பதன் மூலமாகவோ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// இந்த டெக்கின் உள் சேமிப்பிடத்தை மறுசீரமைக்கிறது, எனவே இது ஒரு தொடர்ச்சியான துண்டு, பின்னர் அது திரும்பும்.
    ///
    /// இந்த முறை ஒதுக்கவில்லை மற்றும் செருகப்பட்ட உறுப்புகளின் வரிசையை மாற்றாது.இது ஒரு மாற்றக்கூடிய துண்டைத் தரும்போது, இது ஒரு டெக் வரிசைப்படுத்த பயன்படுத்தப்படலாம்.
    ///
    /// உள் சேமிப்பிடம் தொடர்ச்சியாகிவிட்டால், [`as_slices`] மற்றும் [`as_mut_slices`] முறைகள் `VecDeque` இன் முழு உள்ளடக்கங்களையும் ஒரே துண்டாக வழங்கும்.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// ஒரு டெக்கின் உள்ளடக்கத்தை வரிசைப்படுத்துதல்.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // deque வரிசைப்படுத்துதல்
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // தலைகீழ் வரிசையில் வரிசைப்படுத்துதல்
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// தொடர்ச்சியான துண்டுக்கு மாறாத அணுகலைப் பெறுதல்.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // X001 க்கு மாறாத அணுகலைக் கொண்டிருக்கும்போது, `slice` டெக்கின் அனைத்து கூறுகளையும் கொண்டுள்ளது என்பதை இப்போது நாம் உறுதியாக நம்பலாம்.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // ஒரே நேரத்தில் வால் நகலெடுக்க போதுமான இடம் உள்ளது, இதன் பொருள் நாம் முதலில் தலையை பின்னோக்கி மாற்றி, பின்னர் வால் சரியான நிலைக்கு நகலெடுக்கிறோம்.
            //
            //
            // இருந்து: DEFGH .... ABC
            // க்கு: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: நாங்கள் தற்போது கருத்தில் கொள்ளவில்லை .... ABCDEFGH
            // இந்த விஷயத்தில் `head` `0` ஆக இருப்பதால் தொடர்ச்சியாக இருக்க வேண்டும்.
            // நாம் இதை மாற்ற விரும்பினால், இது அற்பமானதல்ல, ஏனெனில் ஒரு சில இடங்கள் `is_contiguous` ஐ `buf[tail..head]` ஐப் பயன்படுத்தி வெட்டலாம் என்று எதிர்பார்க்கலாம்.
            //
            //

            // ஒரே நேரத்தில் தலையை நகலெடுக்க போதுமான இலவச இடம் உள்ளது, இதன் பொருள் நாம் முதலில் வால் முன்னோக்கி மாற்றுவோம், பின்னர் தலையை சரியான நிலைக்கு நகலெடுக்கிறோம்.
            //
            //
            // இருந்து: FGH .... ABCDE
            // க்கு: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // இலவசம் என்பது தலை மற்றும் வால் இரண்டையும் விட சிறியது, இதன் பொருள் நாம் மெதுவாக "swap" வால் மற்றும் தலை.
            //
            //
            // இருந்து: EFGHI ... ABCD அல்லது HIJK.ABCDEFG
            // க்கு: ABCDEFGHI ... அல்லது ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // பொதுவான சிக்கல் இந்த GHIJKLM ... ABCDEF, ஏதேனும் இடமாற்றம் செய்வதற்கு முன்பு ABCDEFM ... GHIJKL, 1 பாஸ் பரிமாற்றங்களுக்குப் பிறகு ABCDEFGHIJM ... KL, இடது edge தற்காலிக கடையை அடையும் வரை இடமாற்று
                //                  - புதிய (smaller) கடையுடன் வழிமுறையை மறுதொடக்கம் செய்யுங்கள் சில நேரங்களில் சரியான edge இடையகத்தின் முடிவில் இருக்கும்போது தற்காலிக கடை எட்டப்படும், இதன் பொருள் நாம் சரியான மாற்றத்தை குறைவான இடமாற்றங்களுடன் அடித்திருக்கிறோம்!
                //
                // E.g
                // EF..ABCD ABCDEF .., நான்கு இடமாற்றங்களுக்குப் பிறகு நாங்கள் முடித்துவிட்டோம்
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// இரட்டை முனை வரிசை `mid` இடங்களை இடதுபுறமாக சுழற்றுகிறது.
    ///
    /// Equivalently,
    /// - உருப்படி `mid` ஐ முதல் நிலைக்கு சுழற்றுகிறது.
    /// - முதல் `mid` உருப்படிகளை பாப் செய்து அவற்றை இறுதிவரை தள்ளுகிறது.
    /// - `len() - mid` இடங்களை வலப்புறம் சுழற்றுகிறது.
    ///
    /// # Panics
    ///
    /// `mid` `len()` ஐ விட அதிகமாக இருந்தால்.
    /// `mid == len()` _not_ panic ஐ செய்கிறது மற்றும் இது ஒரு விருப்பமற்ற சுழற்சி என்பதை நினைவில் கொள்க.
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` நேரம் எடுக்கும் மற்றும் கூடுதல் இடம் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// இரட்டை முனை வரிசை `k` இடங்களை வலப்புறம் சுழற்றுகிறது.
    ///
    /// Equivalently,
    /// - முதல் உருப்படியை `k` நிலைக்கு சுழற்றுகிறது.
    /// - கடைசி `k` உருப்படிகளை பாப் செய்து அவற்றை முன்னால் தள்ளுகிறது.
    /// - `len() - k` இடங்களை இடதுபுறமாக சுழற்றுகிறது.
    ///
    /// # Panics
    ///
    /// `k` `len()` ஐ விட அதிகமாக இருந்தால்.
    /// `k == len()` _not_ panic ஐ செய்கிறது மற்றும் இது ஒரு விருப்பமற்ற சுழற்சி என்பதை நினைவில் கொள்க.
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` நேரம் எடுக்கும் மற்றும் கூடுதல் இடம் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // பாதுகாப்பு: பின்வரும் இரண்டு முறைகளுக்கு சுழற்சி அளவு தேவைப்படுகிறது
    // டெக்கின் நீளத்தின் பாதிக்கும் குறைவாக இருக்க வேண்டும்.
    //
    // `wrap_copy` `min(x, cap() - x) + copy_len <= cap()` தேவைப்படுகிறது, ஆனால் `min` ஐ விட ஒருபோதும் பாதிக்கும் மேற்பட்ட திறன் இல்லை, x ஐப் பொருட்படுத்தாமல், இங்கு அழைப்பது ஒலியாக இருக்கிறது, ஏனென்றால் நாங்கள் அரை நீளத்திற்கும் குறைவான எதையாவது அழைக்கிறோம், இது ஒருபோதும் பாதி திறனுக்கு மேல் இல்லை.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// கொடுக்கப்பட்ட உறுப்புக்காக இந்த வரிசைப்படுத்தப்பட்ட `VecDeque` ஐ பைனரி தேடுகிறது.
    ///
    /// மதிப்பு கண்டறியப்பட்டால், பொருந்தும் உறுப்பின் குறியீட்டைக் கொண்ட [`Result::Ok`] திரும்பும்.
    /// பல போட்டிகள் இருந்தால், ஏதேனும் ஒரு போட்டியைத் திருப்பித் தரலாம்.
    /// மதிப்பு கண்டுபிடிக்கப்படவில்லை எனில், வரிசைப்படுத்தப்பட்ட வரிசையை பராமரிக்கும் போது பொருந்தக்கூடிய உறுப்பு செருகக்கூடிய குறியீட்டைக் கொண்ட [`Result::Err`] திரும்பும்.
    ///
    ///
    /// # Examples
    ///
    /// நான்கு கூறுகளின் வரிசையைத் தேடுகிறது.
    /// முதலாவது தனித்துவமாக நிர்ணயிக்கப்பட்ட நிலையில் காணப்படுகிறது;இரண்டாவது மற்றும் மூன்றாவது காணப்படவில்லை;நான்காவது `[1, 4]` இல் எந்த நிலைக்கும் பொருந்தக்கூடும்.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// வரிசைப்படுத்தப்பட்ட `VecDeque` இல் ஒரு பொருளைச் செருக விரும்பினால், வரிசை வரிசையைப் பராமரிக்கும்போது:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// பைனரி இந்த வரிசைப்படுத்தப்பட்ட `VecDeque` ஐ ஒரு ஒப்பீட்டு செயல்பாட்டுடன் தேடுகிறது.
    ///
    /// ஒப்பீட்டாளர் செயல்பாடு, அடிப்படை `VecDeque` இன் வரிசை வரிசைக்கு ஒத்த ஒரு வரிசையை செயல்படுத்த வேண்டும், அதன் வாதம் விரும்பிய இலக்கை விட `Less`, `Equal` அல்லது `Greater` என்பதைக் குறிக்கும் வரிசைக் குறியீட்டைத் தருகிறது.
    ///
    ///
    /// மதிப்பு கண்டறியப்பட்டால், பொருந்தும் உறுப்பின் குறியீட்டைக் கொண்ட [`Result::Ok`] திரும்பும்.பல போட்டிகள் இருந்தால், ஏதேனும் ஒரு போட்டியைத் திருப்பித் தரலாம்.
    /// மதிப்பு கண்டுபிடிக்கப்படவில்லை எனில், வரிசைப்படுத்தப்பட்ட வரிசையை பராமரிக்கும் போது பொருந்தக்கூடிய உறுப்பு செருகக்கூடிய குறியீட்டைக் கொண்ட [`Result::Err`] திரும்பும்.
    ///
    /// # Examples
    ///
    /// நான்கு கூறுகளின் வரிசையைத் தேடுகிறது.முதலாவது தனித்துவமாக நிர்ணயிக்கப்பட்ட நிலையில் காணப்படுகிறது;இரண்டாவது மற்றும் மூன்றாவது காணப்படவில்லை;நான்காவது `[1, 4]` இல் எந்த நிலைக்கும் பொருந்தக்கூடும்.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// பைனரி இந்த வரிசைப்படுத்தப்பட்ட `VecDeque` ஐ ஒரு முக்கிய பிரித்தெடுத்தல் செயல்பாட்டுடன் தேடுகிறது.
    ///
    /// `VecDeque` விசையால் வரிசைப்படுத்தப்படுகிறது என்று கருதுகிறது, உதாரணமாக [`make_contiguous().sort_by_key()`](#method.make_contiguous) உடன் அதே விசை பிரித்தெடுத்தல் செயல்பாட்டைப் பயன்படுத்துகிறது.
    ///
    ///
    /// மதிப்பு கண்டறியப்பட்டால், பொருந்தும் உறுப்பின் குறியீட்டைக் கொண்ட [`Result::Ok`] திரும்பும்.
    /// பல போட்டிகள் இருந்தால், ஏதேனும் ஒரு போட்டியைத் திருப்பித் தரலாம்.
    /// மதிப்பு கண்டுபிடிக்கப்படவில்லை எனில், வரிசைப்படுத்தப்பட்ட வரிசையை பராமரிக்கும் போது பொருந்தக்கூடிய உறுப்பு செருகக்கூடிய குறியீட்டைக் கொண்ட [`Result::Err`] திரும்பும்.
    ///
    /// # Examples
    ///
    /// அவற்றின் இரண்டாவது உறுப்புகளால் வரிசைப்படுத்தப்பட்ட ஜோடிகளின் துண்டுகளாக நான்கு கூறுகளின் வரிசையைத் தேடுகிறது.
    /// முதலாவது தனித்துவமாக நிர்ணயிக்கப்பட்ட நிலையில் காணப்படுகிறது;இரண்டாவது மற்றும் மூன்றாவது காணப்படவில்லை;நான்காவது `[1, 4]` இல் எந்த நிலைக்கும் பொருந்தக்கூடும்.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` இன் இடத்தில் மாற்றியமைக்கிறது, இதனால் `len()` புதிய_லெனுக்கு சமமாக இருக்கும், பின்புறத்திலிருந்து அதிகப்படியான கூறுகளை அகற்றுவதன் மூலமாகவோ அல்லது `value` இன் குளோன்களை பின்புறமாக சேர்ப்பதன் மூலமாகவோ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// கொடுக்கப்பட்ட தருக்க உறுப்பு குறியீட்டுக்கான அடிப்படை இடையகத்தில் குறியீட்டை வழங்குகிறது.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // அளவு எப்போதும் 2 சக்தி
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// இடையகத்தில் படிக்க மீதமுள்ள உறுப்புகளின் எண்ணிக்கையைக் கணக்கிடுங்கள்
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // அளவு எப்போதும் 2 சக்தி
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // எப்போதும் மூன்று பிரிவுகளாகப் பிரிக்கலாம், எடுத்துக்காட்டாக: சுய: [a b c|d e f] மற்றவை: [0 1 2 3|4 5] முன்=3, நடுப்பகுதி=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // As_slices முறையால் திரும்பிய துண்டுகளில் Hash::hash_slice ஐப் பயன்படுத்த முடியாது, ஏனெனில் அவற்றின் நீளம் இல்லையெனில் ஒரே மாதிரியான டெக்ஸில் மாறுபடும்.
        //
        //
        // ஹாஷர் அதன் முறைகளுக்கான அதே அழைப்புகளின் சமநிலைக்கு மட்டுமே உத்தரவாதம் அளிக்கிறது.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// மதிப்பின் அடிப்படையில் உறுப்புகளை வழங்கும் முன்-பின்-பின் ஐரேட்டராக `VecDeque` ஐ பயன்படுத்துகிறது.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // இந்த செயல்பாடு தார்மீக சமமானதாக இருக்க வேண்டும்:
        //
        //      iter.into_iter() in இல் உள்ள உருப்படிக்கு
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// ஒரு [`Vec<T>`] ஐ [`VecDeque<T>`] ஆக மாற்றவும்.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// இது சாத்தியமான இடங்களில் மறு ஒதுக்கீடு செய்வதைத் தவிர்க்கிறது, ஆனால் அதற்கான நிபந்தனைகள் கண்டிப்பானவை, மாற்றத்திற்கு உட்பட்டவை, எனவே `Vec<T>` `From<VecDeque<T>>` இலிருந்து வந்து மறு ஒதுக்கீடு செய்யப்படாவிட்டால் நம்பியிருக்கக்கூடாது.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // ZST களுக்கு திறன் பற்றி கவலைப்பட உண்மையான ஒதுக்கீடு எதுவும் இல்லை, ஆனால் `VecDeque` க்கு `Vec` அளவுக்கு நீளத்தை கையாள முடியாது.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // திறன் இரண்டு சக்தியாக இல்லாவிட்டால், மிகச் சிறியதாக இருந்தால் அல்லது குறைந்தபட்சம் ஒரு இலவச இடத்தைக் கொண்டிருக்கவில்லை என்றால் நாம் அளவை மாற்ற வேண்டும்.
            // இது `Vec` இல் இருக்கும்போது இதைச் செய்கிறோம், எனவே உருப்படிகள் panic இல் கைவிடப்படும்.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// ஒரு [`VecDeque<T>`] ஐ [`Vec<T>`] ஆக மாற்றவும்.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// இது ஒருபோதும் மறு ஒதுக்கீடு செய்யத் தேவையில்லை, ஆனால் ஒதுக்கீட்டின் தொடக்கத்தில் வட்ட இடையகம் நிகழவில்லை என்றால் *O*(*n*) தரவு இயக்கம் செய்ய வேண்டும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // இது *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // இதற்கு தரவு மறுசீரமைப்பு தேவை.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}