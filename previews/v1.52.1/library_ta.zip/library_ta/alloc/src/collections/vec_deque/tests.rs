use super::*;

#[bench]
#[cfg_attr(miri, ignore)] // தனிமைப்படுத்தப்பட்ட மிரி வரையறைகளை ஆதரிக்கவில்லை
fn bench_push_back_100(b: &mut test::Bencher) {
    let mut deq = VecDeque::with_capacity(101);
    b.iter(|| {
        for i in 0..100 {
            deq.push_back(i);
        }
        deq.head = 0;
        deq.tail = 0;
    })
}

#[bench]
#[cfg_attr(miri, ignore)] // தனிமைப்படுத்தப்பட்ட மிரி வரையறைகளை ஆதரிக்கவில்லை
fn bench_push_front_100(b: &mut test::Bencher) {
    let mut deq = VecDeque::with_capacity(101);
    b.iter(|| {
        for i in 0..100 {
            deq.push_front(i);
        }
        deq.head = 0;
        deq.tail = 0;
    })
}

#[bench]
#[cfg_attr(miri, ignore)] // தனிமைப்படுத்தப்பட்ட மிரி வரையறைகளை ஆதரிக்கவில்லை
fn bench_pop_back_100(b: &mut test::Bencher) {
    let mut deq = VecDeque::<i32>::with_capacity(101);

    b.iter(|| {
        deq.head = 100;
        deq.tail = 0;
        while !deq.is_empty() {
            test::black_box(deq.pop_back());
        }
    })
}

#[bench]
#[cfg_attr(miri, ignore)] // தனிமைப்படுத்தப்பட்ட மிரி வரையறைகளை ஆதரிக்கவில்லை
fn bench_pop_front_100(b: &mut test::Bencher) {
    let mut deq = VecDeque::<i32>::with_capacity(101);

    b.iter(|| {
        deq.head = 100;
        deq.tail = 0;
        while !deq.is_empty() {
            test::black_box(deq.pop_front());
        }
    })
}

#[test]
fn test_swap_front_back_remove() {
    fn test(back: bool) {
        // இந்த சோதனை வால் நிலை மற்றும் நீளத்தின் ஒவ்வொரு கலவையும் சோதிக்கப்படுகிறதா என்பதை சரிபார்க்கிறது.
        // திறன் 15 ஒவ்வொரு வழக்கையும் உள்ளடக்கும் அளவுக்கு பெரியதாக இருக்க வேண்டும்.
        let mut tester = VecDeque::with_capacity(15);
        let usable_cap = tester.capacity();
        let final_len = usable_cap / 2;

        for len in 0..final_len {
            let expected: VecDeque<_> =
                if back { (0..len).collect() } else { (0..len).rev().collect() };
            for tail_pos in 0..usable_cap {
                tester.tail = tail_pos;
                tester.head = tail_pos;
                if back {
                    for i in 0..len * 2 {
                        tester.push_front(i);
                    }
                    for i in 0..len {
                        assert_eq!(tester.swap_remove_back(i), Some(len * 2 - 1 - i));
                    }
                } else {
                    for i in 0..len * 2 {
                        tester.push_back(i);
                    }
                    for i in 0..len {
                        let idx = tester.len() - 1 - i;
                        assert_eq!(tester.swap_remove_front(idx), Some(len * 2 - 1 - i));
                    }
                }
                assert!(tester.tail < tester.cap());
                assert!(tester.head < tester.cap());
                assert_eq!(tester, expected);
            }
        }
    }
    test(true);
    test(false);
}

#[test]
fn test_insert() {
    // இந்த நிலை வால் நிலை, நீளம் மற்றும் செருகும் நிலை ஆகியவற்றின் ஒவ்வொரு கலவையும் சோதிக்கப்படுகிறதா என்பதை சரிபார்க்கிறது.
    // திறன் 15 ஒவ்வொரு வழக்கையும் உள்ளடக்கும் அளவுக்கு பெரியதாக இருக்க வேண்டும்.

    let mut tester = VecDeque::with_capacity(15);
    // எங்களுக்கு 15 கிடைத்தது என்று உத்தரவாதம் அளிக்க முடியாது, எனவே எங்களுக்கு கிடைத்ததைப் பெற வேண்டும்.
    // 15 நன்றாக இருக்கும், ஆனால் நாம் நிச்சயமாக k>=4 க்கு 2 ^ k, 1 ஐப் பெறுவோம், இல்லையெனில் இந்த சோதனை அது விரும்புவதை மறைக்காது
    //
    let cap = tester.capacity();

    // லென் என்பது *செருகப்பட்ட பின்*
    let minlen = if cfg!(miri) { cap - 1 } else { 1 }; // மிரி மிகவும் மெதுவாக உள்ளது
    for len in minlen..cap {
        // 0, 1, 2, .., லென், 1
        let expected = (0..).take(len).collect::<VecDeque<_>>();
        for tail_pos in 0..cap {
            for to_insert in 0..len {
                tester.tail = tail_pos;
                tester.head = tail_pos;
                for i in 0..len {
                    if i != to_insert {
                        tester.push_back(i);
                    }
                }
                tester.insert(to_insert, to_insert);
                assert!(tester.tail < tester.cap());
                assert!(tester.head < tester.cap());
                assert_eq!(tester, expected);
            }
        }
    }
}

#[test]
fn make_contiguous_big_tail() {
    let mut tester = VecDeque::with_capacity(15);

    for i in 0..3 {
        tester.push_back(i);
    }

    for i in 3..10 {
        tester.push_front(i);
    }

    // 012......9876543
    assert_eq!(tester.capacity(), 15);
    assert_eq!((&[9, 8, 7, 6, 5, 4, 3] as &[_], &[0, 1, 2] as &[_]), tester.as_slices());

    let expected_start = tester.head;
    tester.make_contiguous();
    assert_eq!(tester.tail, expected_start);
    assert_eq!((&[9, 8, 7, 6, 5, 4, 3, 0, 1, 2] as &[_], &[] as &[_]), tester.as_slices());
}

#[test]
fn make_contiguous_big_head() {
    let mut tester = VecDeque::with_capacity(15);

    for i in 0..8 {
        tester.push_back(i);
    }

    for i in 8..10 {
        tester.push_front(i);
    }

    // 01234567......98
    let expected_start = 0;
    tester.make_contiguous();
    assert_eq!(tester.tail, expected_start);
    assert_eq!((&[9, 8, 0, 1, 2, 3, 4, 5, 6, 7] as &[_], &[] as &[_]), tester.as_slices());
}

#[test]
fn make_contiguous_small_free() {
    let mut tester = VecDeque::with_capacity(15);

    for i in 'A' as u8..'I' as u8 {
        tester.push_back(i as char);
    }

    for i in 'I' as u8..'N' as u8 {
        tester.push_front(i as char);
    }

    // ABCDEFGH...MLKJI
    let expected_start = 0;
    tester.make_contiguous();
    assert_eq!(tester.tail, expected_start);
    assert_eq!(
        (&['M', 'L', 'K', 'J', 'I', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'] as &[_], &[] as &[_]),
        tester.as_slices()
    );

    tester.clear();
    for i in 'I' as u8..'N' as u8 {
        tester.push_back(i as char);
    }

    for i in 'A' as u8..'I' as u8 {
        tester.push_front(i as char);
    }

    // IJKLM...HGFEDCBA
    let expected_start = 0;
    tester.make_contiguous();
    assert_eq!(tester.tail, expected_start);
    assert_eq!(
        (&['H', 'G', 'F', 'E', 'D', 'C', 'B', 'A', 'I', 'J', 'K', 'L', 'M'] as &[_], &[] as &[_]),
        tester.as_slices()
    );
}

#[test]
fn make_contiguous_head_to_end() {
    let mut dq = VecDeque::with_capacity(3);
    dq.push_front('B');
    dq.push_front('A');
    dq.push_back('C');
    dq.make_contiguous();
    let expected_tail = 0;
    let expected_head = 3;
    assert_eq!(expected_tail, dq.tail);
    assert_eq!(expected_head, dq.head);
    assert_eq!((&['A', 'B', 'C'] as &[_], &[] as &[_]), dq.as_slices());
}

#[test]
fn make_contiguous_head_to_end_2() {
    // #79808 க்கான மற்றொரு சோதனை வழக்கு, #80293 இலிருந்து எடுக்கப்பட்டது.

    let mut dq = VecDeque::from_iter(0..6);
    dq.pop_front();
    dq.pop_front();
    dq.push_back(6);
    dq.push_back(7);
    dq.push_back(8);
    dq.make_contiguous();
    let collected: Vec<_> = dq.iter().copied().collect();
    assert_eq!(dq.as_slices(), (&collected[..], &[] as &[_]));
}

#[test]
fn test_remove() {
    // வால் நிலை, நீளம் மற்றும் அகற்றும் நிலை ஆகியவற்றின் ஒவ்வொரு கலவையும் சோதிக்கப்படுகிறதா என்பதை இந்த சோதனை சரிபார்க்கிறது.
    // திறன் 15 ஒவ்வொரு வழக்கையும் உள்ளடக்கும் அளவுக்கு பெரியதாக இருக்க வேண்டும்.

    let mut tester = VecDeque::with_capacity(15);
    // எங்களுக்கு 15 கிடைத்தது என்று உத்தரவாதம் அளிக்க முடியாது, எனவே எங்களுக்கு கிடைத்ததைப் பெற வேண்டும்.
    // 15 நன்றாக இருக்கும், ஆனால் நாம் நிச்சயமாக k>=4 க்கு 2 ^ k, 1 ஐப் பெறுவோம், இல்லையெனில் இந்த சோதனை அது விரும்புவதை மறைக்காது
    //
    let cap = tester.capacity();

    // லென் என்பது நீக்கப்பட்ட பிறகு *நீளம்*
    let minlen = if cfg!(miri) { cap - 2 } else { 0 }; // மிரி மிகவும் மெதுவாக உள்ளது
    for len in minlen..cap - 1 {
        // 0, 1, 2, .., லென், 1
        let expected = (0..).take(len).collect::<VecDeque<_>>();
        for tail_pos in 0..cap {
            for to_remove in 0..=len {
                tester.tail = tail_pos;
                tester.head = tail_pos;
                for i in 0..len {
                    if i == to_remove {
                        tester.push_back(1234);
                    }
                    tester.push_back(i);
                }
                if to_remove == len {
                    tester.push_back(1234);
                }
                tester.remove(to_remove);
                assert!(tester.tail < tester.cap());
                assert!(tester.head < tester.cap());
                assert_eq!(tester, expected);
            }
        }
    }
}

#[test]
fn test_range() {
    let mut tester: VecDeque<usize> = VecDeque::with_capacity(7);

    let cap = tester.capacity();
    let minlen = if cfg!(miri) { cap - 1 } else { 0 }; // மிரி மிகவும் மெதுவாக உள்ளது
    for len in minlen..=cap {
        for tail in 0..=cap {
            for start in 0..=len {
                for end in start..=len {
                    tester.tail = tail;
                    tester.head = tail;
                    for i in 0..len {
                        tester.push_back(i);
                    }

                    // சரியான மதிப்புகளை நாங்கள் மீண்டும் செய்கிறோம் என்பதை சரிபார்க்கவும்
                    let range: VecDeque<_> = tester.range(start..end).copied().collect();
                    let expected: VecDeque<_> = (start..end).collect();
                    assert_eq!(range, expected);
                }
            }
        }
    }
}

#[test]
fn test_range_mut() {
    let mut tester: VecDeque<usize> = VecDeque::with_capacity(7);

    let cap = tester.capacity();
    for len in 0..=cap {
        for tail in 0..=cap {
            for start in 0..=len {
                for end in start..=len {
                    tester.tail = tail;
                    tester.head = tail;
                    for i in 0..len {
                        tester.push_back(i);
                    }

                    let head_was = tester.head;
                    let tail_was = tester.tail;

                    // சரியான மதிப்புகளை நாங்கள் மீண்டும் செய்கிறோம் என்பதை சரிபார்க்கவும்
                    let range: VecDeque<_> = tester.range_mut(start..end).map(|v| *v).collect();
                    let expected: VecDeque<_> = (start..end).collect();
                    assert_eq!(range, expected);

                    // நாம் திறனை மாற்றியிருக்கக்கூடாது அல்லது தலை அல்லது வால் எல்லைக்கு அப்பாற்பட்டதாக இருக்கக்கூடாது
                    //
                    assert_eq!(tester.capacity(), cap);
                    assert_eq!(tester.tail, tail_was);
                    assert_eq!(tester.head, head_was);
                }
            }
        }
    }
}

#[test]
fn test_drain() {
    let mut tester: VecDeque<usize> = VecDeque::with_capacity(7);

    let cap = tester.capacity();
    for len in 0..=cap {
        for tail in 0..=cap {
            for drain_start in 0..=len {
                for drain_end in drain_start..=len {
                    tester.tail = tail;
                    tester.head = tail;
                    for i in 0..len {
                        tester.push_back(i);
                    }

                    // நாம் சரியான மதிப்புகளை drain என்று சரிபார்க்கவும்
                    let drained: VecDeque<_> = tester.drain(drain_start..drain_end).collect();
                    let drained_expected: VecDeque<_> = (drain_start..drain_end).collect();
                    assert_eq!(drained, drained_expected);

                    // நாம் திறனை மாற்றியிருக்கக்கூடாது அல்லது தலை அல்லது வால் எல்லைக்கு அப்பாற்பட்டதாக இருக்கக்கூடாது
                    //
                    assert_eq!(tester.capacity(), cap);
                    assert!(tester.tail < tester.cap());
                    assert!(tester.head < tester.cap());

                    // VecDeque இல் சரியான மதிப்புகளைக் காண வேண்டும்
                    let expected: VecDeque<_> = (0..drain_start).chain(drain_end..len).collect();
                    assert_eq!(expected, tester);
                }
            }
        }
    }
}

#[test]
fn test_shrink_to_fit() {
    // இந்த சோதனை தலை மற்றும் வால் நிலையின் ஒவ்வொரு கலவையும் சோதிக்கப்படுகிறதா என்பதை சரிபார்க்கிறது.
    // திறன் 15 ஒவ்வொரு வழக்கையும் உள்ளடக்கும் அளவுக்கு பெரியதாக இருக்க வேண்டும்.

    let mut tester = VecDeque::with_capacity(15);
    // எங்களுக்கு 15 கிடைத்தது என்று உத்தரவாதம் அளிக்க முடியாது, எனவே எங்களுக்கு கிடைத்ததைப் பெற வேண்டும்.
    // 15 நன்றாக இருக்கும், ஆனால் நாம் நிச்சயமாக k>=4 க்கு 2 ^ k, 1 ஐப் பெறுவோம், இல்லையெனில் இந்த சோதனை அது விரும்புவதை மறைக்காது
    //
    let cap = tester.capacity();
    tester.reserve(63);
    let max_cap = tester.capacity();

    for len in 0..=cap {
        // 0, 1, 2, .., லென், 1
        let expected = (0..).take(len).collect::<VecDeque<_>>();
        for tail_pos in 0..=max_cap {
            tester.tail = tail_pos;
            tester.head = tail_pos;
            tester.reserve(63);
            for i in 0..len {
                tester.push_back(i);
            }
            tester.shrink_to_fit();
            assert!(tester.capacity() <= cap);
            assert!(tester.tail < tester.cap());
            assert!(tester.head < tester.cap());
            assert_eq!(tester, expected);
        }
    }
}

#[test]
fn test_split_off() {
    // இந்த நிலை வால் நிலை, நீளம் மற்றும் பிளவு நிலை ஆகியவற்றின் ஒவ்வொரு கலவையும் சோதிக்கப்படுகிறதா என்பதை சரிபார்க்கிறது.
    // திறன் 15 ஒவ்வொரு வழக்கையும் உள்ளடக்கும் அளவுக்கு பெரியதாக இருக்க வேண்டும்.

    let mut tester = VecDeque::with_capacity(15);
    // எங்களுக்கு 15 கிடைத்தது என்று உத்தரவாதம் அளிக்க முடியாது, எனவே எங்களுக்கு கிடைத்ததைப் பெற வேண்டும்.
    // 15 நன்றாக இருக்கும், ஆனால் நாம் நிச்சயமாக k>=4 க்கு 2 ^ k, 1 ஐப் பெறுவோம், இல்லையெனில் இந்த சோதனை அது விரும்புவதை மறைக்காது
    //
    let cap = tester.capacity();

    // லென் என்பது *பிரிப்பதற்கு முன்*
    let minlen = if cfg!(miri) { cap - 1 } else { 0 }; // மிரி மிகவும் மெதுவாக உள்ளது
    for len in minlen..cap {
        // இல் பிரிக்க குறியீடு
        for at in 0..=len {
            // 0, 1, 2, .., இல், 1 (காலியாக இருக்கலாம்)
            let expected_self = (0..).take(at).collect::<VecDeque<_>>();
            // at, + 1, .., லென், 1 (காலியாக இருக்கலாம்)
            let expected_other = (at..).take(len - at).collect::<VecDeque<_>>();

            for tail_pos in 0..cap {
                tester.tail = tail_pos;
                tester.head = tail_pos;
                for i in 0..len {
                    tester.push_back(i);
                }
                let result = tester.split_off(at);
                assert!(tester.tail < tester.cap());
                assert!(tester.head < tester.cap());
                assert!(result.tail < result.cap());
                assert!(result.head < result.cap());
                assert_eq!(tester, expected_self);
                assert_eq!(result, expected_other);
            }
        }
    }
}

#[test]
fn test_from_vec() {
    use crate::vec::Vec;
    for cap in 0..35 {
        for len in 0..=cap {
            let mut vec = Vec::with_capacity(cap);
            vec.extend(0..len);

            let vd = VecDeque::from(vec.clone());
            assert!(vd.cap().is_power_of_two());
            assert_eq!(vd.len(), vec.len());
            assert!(vd.into_iter().eq(vec));
        }
    }

    let vec = Vec::from([(); MAXIMUM_ZST_CAPACITY - 1]);
    let vd = VecDeque::from(vec.clone());
    assert!(vd.cap().is_power_of_two());
    assert_eq!(vd.len(), vec.len());
}

#[test]
#[should_panic = "capacity overflow"]
fn test_from_vec_zst_overflow() {
    use crate::vec::Vec;
    let vec = Vec::from([(); MAXIMUM_ZST_CAPACITY]);
    let vd = VecDeque::from(vec.clone()); // +1 க்கு இடமில்லை
    assert!(vd.cap().is_power_of_two());
    assert_eq!(vd.len(), vec.len());
}

#[test]
fn test_vec_from_vecdeque() {
    use crate::vec::Vec;

    fn create_vec_and_test_convert(capacity: usize, offset: usize, len: usize) {
        let mut vd = VecDeque::with_capacity(capacity);
        for _ in 0..offset {
            vd.push_back(0);
            vd.pop_front();
        }
        vd.extend(0..len);

        let vec: Vec<_> = Vec::from(vd.clone());
        assert_eq!(vec.len(), vd.len());
        assert!(vec.into_iter().eq(vd));
    }

    // மிரி மிகவும் மெதுவாக உள்ளது
    let max_pwr = if cfg!(miri) { 5 } else { 7 };

    for cap_pwr in 0..max_pwr {
        // திறனை ஒரு (2 ^ x)-1 ஆக மாற்றவும், இதனால் வளையத்தின் அளவு 2 ^ x ஆக இருக்கும்
        let cap = (2i32.pow(cap_pwr) - 1) as usize;

        // இந்த சந்தர்ப்பங்களில் அதை நகல்களுடன் தீர்க்க போதுமான இலவச இடம் உள்ளது
        for len in 0..((cap + 1) / 2) {
            // தொடர்ச்சியான நிகழ்வுகளை சோதிக்கவும்
            for offset in 0..(cap - len) {
                create_vec_and_test_convert(cap, offset, len)
            }

            // தொடக்கத் தொகுதியை விட இடையகத்தின் முடிவில் தடுப்பு பெரியதாக இருக்கும் சோதனை வழக்குகள்
            for offset in (cap - len)..(cap - (len / 2)) {
                create_vec_and_test_convert(cap, offset, len)
            }

            // சோதனை நிகழ்வுகள் இடையகத்தின் தொடக்கத்தில் தடுப்பு இறுதியில் தடுப்பை விட பெரியதாக இருக்கும்
            for offset in (cap - (len / 2))..cap {
                create_vec_and_test_convert(cap, offset, len)
            }
        }

        // எளிய நகல்களுடன் மோதிரத்தை நேராக்க இப்போது (necessarily) இடம் இல்லை, மோதிரம் எப்போது இடமாற்றம் செய்யும்:
        // (தொப்பி + 1, ஆஃப்செட்)> (தொப்பி + 1, லென்)&&(லென், (தொப்பி + 1, ஆஃப்செட்))> (தொப்பி + 1, லென்)) வலது தொகுதி அளவு> இலவச இடம்&&இடது தொகுதி அளவு> இலவச இடம்
        //
        //
        for len in ((cap + 1) / 2)..cap {
            // தொடர்ச்சியான நிகழ்வுகளை சோதிக்கவும்
            for offset in 0..(cap - len) {
                create_vec_and_test_convert(cap, offset, len)
            }

            // தொடக்கத் தொகுதியை விட இடையகத்தின் முடிவில் தடுப்பு பெரியதாக இருக்கும் சோதனை வழக்குகள்
            for offset in (cap - len)..(cap - (len / 2)) {
                create_vec_and_test_convert(cap, offset, len)
            }

            // சோதனை நிகழ்வுகள் இடையகத்தின் தொடக்கத்தில் தடுப்பு இறுதியில் தடுப்பை விட பெரியதாக இருக்கும்
            for offset in (cap - (len / 2))..cap {
                create_vec_and_test_convert(cap, offset, len)
            }
        }
    }
}

#[test]
fn test_clone_from() {
    let m = vec![1; 8];
    let n = vec![2; 12];
    let limit = if cfg!(miri) { 4 } else { 8 }; // மிரி மிகவும் மெதுவாக உள்ளது
    for pfv in 0..limit {
        for pfu in 0..limit {
            for longer in 0..2 {
                let (vr, ur) = if longer == 0 { (&m, &n) } else { (&n, &m) };
                let mut v = VecDeque::from(vr.clone());
                for _ in 0..pfv {
                    v.push_front(1);
                }
                let mut u = VecDeque::from(ur.clone());
                for _ in 0..pfu {
                    u.push_front(2);
                }
                v.clone_from(&u);
                assert_eq!(&v, &u);
            }
        }
    }
}

#[test]
fn test_vec_deque_truncate_drop() {
    static mut DROPS: u32 = 0;
    #[derive(Clone)]
    struct Elem(i32);
    impl Drop for Elem {
        fn drop(&mut self) {
            unsafe {
                DROPS += 1;
            }
        }
    }

    let v = vec![Elem(1), Elem(2), Elem(3), Elem(4), Elem(5)];
    for push_front in 0..=v.len() {
        let v = v.clone();
        let mut tester = VecDeque::with_capacity(5);
        for (index, elem) in v.into_iter().enumerate() {
            if index < push_front {
                tester.push_front(elem);
            } else {
                tester.push_back(elem);
            }
        }
        assert_eq!(unsafe { DROPS }, 0);
        tester.truncate(3);
        assert_eq!(unsafe { DROPS }, 2);
        tester.truncate(0);
        assert_eq!(unsafe { DROPS }, 5);
        unsafe {
            DROPS = 0;
        }
    }
}

#[test]
fn issue_53529() {
    use crate::boxed::Box;

    let mut dst = VecDeque::new();
    dst.push_front(Box::new(1));
    dst.push_front(Box::new(2));
    assert_eq!(*dst.pop_back().unwrap(), 1);

    let mut src = VecDeque::new();
    src.push_front(Box::new(2));
    dst.append(&mut src);
    for a in dst {
        assert_eq!(*a, 2);
    }
}

#[test]
fn issue_80303() {
    use core::iter;
    use core::num::Wrapping;

    // மோசமான ஹாஷ் செயல்பாடு செயல்படுத்தல் என்றாலும் இது செல்லுபடியாகும்.
    struct SimpleHasher(Wrapping<u64>);

    impl Hasher for SimpleHasher {
        fn finish(&self) -> u64 {
            self.0.0
        }

        fn write(&mut self, bytes: &[u8]) {
            // இந்த குறிப்பிட்ட செயல்படுத்தல் பைட்டுகளுக்கு கூடுதலாக மதிப்பு 24 ஐக் கொண்டுள்ளது.
            // ஹாஷர் அதன் முறைகளுக்கு ஒரே மாதிரியான அழைப்புகளுக்கு சமமான உத்தரவாதத்தை அளிப்பதால் இதுபோன்ற செயல்படுத்தல் செல்லுபடியாகும்.
            //
            for &v in iter::once(&24).chain(bytes) {
                self.0 = Wrapping(31) * self.0 + Wrapping(u64::from(v));
            }
        }
    }

    fn hash_code(value: impl Hash) -> u64 {
        let mut hasher = SimpleHasher(Wrapping(1));
        value.hash(&mut hasher);
        hasher.finish()
    }

    // இது இரண்டு டெக்குகளை உருவாக்குகிறது, அதற்காக as_slices முறையால் வழங்கப்பட்ட மதிப்புகள் வேறுபடுகின்றன.
    //
    let vda: VecDeque<u8> = (0..10).collect();
    let mut vdb = VecDeque::with_capacity(10);
    vdb.extend(5..10);
    (0..5).rev().for_each(|elem| vdb.push_front(elem));
    assert_ne!(vda.as_slices(), vdb.as_slices());
    assert_eq!(vda, vdb);
    assert_eq!(hash_code(vda), hash_code(vdb));
}