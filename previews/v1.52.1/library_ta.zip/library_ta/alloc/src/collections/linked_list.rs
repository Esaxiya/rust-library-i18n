//! சொந்தமான முனைகளுடன் இரட்டிப்பாக இணைக்கப்பட்ட பட்டியல்.
//!
//! `LinkedList` நிலையான நேரத்தில் இரு முனைகளிலும் உறுப்புகளைத் தள்ளவும் உறுத்தும் அனுமதிக்கிறது.
//!
//! NOTE: [`Vec`] அல்லது [`VecDeque`] ஐப் பயன்படுத்துவது எப்போதுமே சிறந்தது, ஏனென்றால் வரிசை அடிப்படையிலான கொள்கலன்கள் பொதுவாக வேகமானவை, அதிக நினைவக திறன் கொண்டவை, மேலும் CPU தற்காலிக சேமிப்பை சிறப்பாகப் பயன்படுத்துகின்றன.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// சொந்தமான முனைகளுடன் இரட்டிப்பாக இணைக்கப்பட்ட பட்டியல்.
///
/// `LinkedList` நிலையான நேரத்தில் இரு முனைகளிலும் உறுப்புகளைத் தள்ளவும் உறுத்தும் அனுமதிக்கிறது.
///
/// NOTE: `Vec` அல்லது `VecDeque` ஐப் பயன்படுத்துவது எப்போதுமே சிறந்தது, ஏனென்றால் வரிசை அடிப்படையிலான கொள்கலன்கள் பொதுவாக வேகமானவை, அதிக நினைவக திறன் கொண்டவை, மேலும் CPU தற்காலிக சேமிப்பை சிறப்பாகப் பயன்படுத்துகின்றன.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// ஒரு `LinkedList` இன் கூறுகளின் மீது ஒரு ஈரேட்டர்.
///
/// இந்த `struct` ஆனது [`LinkedList::iter()`] ஆல் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` க்கு ஆதரவாக அகற்று
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// ஒரு `LinkedList` இன் உறுப்புகளின் மீது ஒரு மாற்றக்கூடிய மறு செய்கை.
///
/// இந்த `struct` ஆனது [`LinkedList::iter_mut()`] ஆல் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // இங்கே முழு பட்டியலையும் நாங்கள் * சொந்தமாக வைத்திருக்கவில்லை, முனையின் `element` பற்றிய குறிப்புகள் ஐரேட்டரால் வழங்கப்பட்டுள்ளன!எனவே இதைப் பயன்படுத்தும் போது கவனமாக இருங்கள்;`element` க்கு மாற்றுப்பெயர்கள் இருக்கலாம் என்பதை அழைக்கப்படும் முறைகள் அறிந்திருக்க வேண்டும்.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// ஒரு `LinkedList` இன் உறுப்புகளுக்கு மேல் ஒரு சொந்த ஈரேட்டர்.
///
/// இந்த `struct` [`LinkedList`] இல் [`into_iter`] முறையால் உருவாக்கப்பட்டது (`IntoIterator` trait ஆல் வழங்கப்படுகிறது).
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// தனியார் முறைகள்
impl<T> LinkedList<T> {
    /// கொடுக்கப்பட்ட முனையை பட்டியலின் முன் சேர்க்கிறது.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // இந்த முறை முழு முனைகளுக்கும் மாற்றத்தக்க குறிப்புகளை உருவாக்காமல் பார்த்துக் கொள்கிறது, `element` இல் மாற்றுப்பெயர்ச்சிகளின் சுட்டிகளின் செல்லுபடியை பராமரிக்க.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // `element` ஐ ஒன்றுடன் ஒன்று புதிய மாற்றக்கூடிய (unique!) குறிப்புகளை உருவாக்கவில்லை.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// பட்டியலின் முன்புறத்தில் உள்ள முனையை அகற்றி திருப்பித் தருகிறது.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // இந்த முறை முழு முனைகளுக்கும் மாற்றத்தக்க குறிப்புகளை உருவாக்காமல் பார்த்துக் கொள்கிறது, `element` இல் மாற்றுப்பெயர்ச்சிகளின் சுட்டிகளின் செல்லுபடியை பராமரிக்க.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // `element` ஐ ஒன்றுடன் ஒன்று புதிய மாற்றக்கூடிய (unique!) குறிப்புகளை உருவாக்கவில்லை.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// கொடுக்கப்பட்ட முனையை பட்டியலின் பின்புறத்தில் சேர்க்கிறது.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // இந்த முறை முழு முனைகளுக்கும் மாற்றத்தக்க குறிப்புகளை உருவாக்காமல் பார்த்துக் கொள்கிறது, `element` இல் மாற்றுப்பெயர்ச்சிகளின் சுட்டிகளின் செல்லுபடியை பராமரிக்க.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // `element` ஐ ஒன்றுடன் ஒன்று புதிய மாற்றக்கூடிய (unique!) குறிப்புகளை உருவாக்கவில்லை.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// பட்டியலின் பின்புறத்தில் உள்ள முனையை அகற்றி திருப்பித் தருகிறது.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // இந்த முறை முழு முனைகளுக்கும் மாற்றத்தக்க குறிப்புகளை உருவாக்காமல் பார்த்துக் கொள்கிறது, `element` இல் மாற்றுப்பெயர்ச்சிகளின் சுட்டிகளின் செல்லுபடியை பராமரிக்க.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // `element` ஐ ஒன்றுடன் ஒன்று புதிய மாற்றக்கூடிய (unique!) குறிப்புகளை உருவாக்கவில்லை.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// தற்போதைய பட்டியலிலிருந்து குறிப்பிட்ட முனையை நீக்குகிறது.
    ///
    /// எச்சரிக்கை: வழங்கப்பட்ட முனை தற்போதைய பட்டியலுக்கு சொந்தமானது என்பதை இது சரிபார்க்காது.
    ///
    /// மாற்று முறை சுட்டிகளின் செல்லுபடியைப் பராமரிக்க, `element` க்கு மாற்றக்கூடிய குறிப்புகளை உருவாக்காமல் இந்த முறை கவனித்துக்கொள்கிறது.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // இது இப்போது நம்முடையது, நாம் ஒரு &mut ஐ உருவாக்கலாம்.

        // `element` ஐ ஒன்றுடன் ஒன்று புதிய மாற்றக்கூடிய (unique!) குறிப்புகளை உருவாக்கவில்லை.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // இந்த முனை தலை முனை
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // இந்த முனை வால் முனை
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// தற்போதுள்ள இரண்டு முனைகளுக்கு இடையில் தொடர் முனைகளைப் பிரிக்கிறது.
    ///
    /// எச்சரிக்கை: வழங்கப்பட்ட முனை தற்போதுள்ள இரண்டு பட்டியல்களுக்கு சொந்தமானது என்பதை இது சரிபார்க்காது.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // இந்த முறை முழு முனைகளுக்கும் ஒரே நேரத்தில் பல மாற்றக்கூடிய குறிப்புகளை உருவாக்காமல் பார்த்துக் கொள்கிறது, `element` இல் மாற்றுப்பெயர் சுட்டிகளின் செல்லுபடியை பராமரிக்க.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// இணைக்கப்பட்ட பட்டியலிலிருந்து அனைத்து முனைகளையும் தொடர் முனைகளாக பிரிக்கிறது.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // பிளவு முனை என்பது இரண்டாவது பகுதியின் புதிய தலை முனை ஆகும்
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // இரண்டாவது பகுதியின் தலை ptr ஐ சரிசெய்யவும்
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // பிளவு முனை என்பது முதல் பகுதியின் புதிய வால் முனை மற்றும் இரண்டாவது பகுதியின் தலைக்கு சொந்தமானது.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // முதல் பகுதியின் வால் பி.டி.ஆரை சரிசெய்யவும்
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// வெற்று `LinkedList<T>` ஐ உருவாக்குகிறது.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// வெற்று `LinkedList` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// அனைத்து கூறுகளையும் `other` இலிருந்து பட்டியலின் இறுதி வரை நகர்த்துகிறது.
    ///
    /// இது `other` இலிருந்து அனைத்து முனைகளையும் மீண்டும் பயன்படுத்துகிறது மற்றும் அவற்றை `self` க்கு நகர்த்துகிறது.
    /// இந்த செயல்பாட்டிற்குப் பிறகு, `other` காலியாகிறது.
    ///
    /// இந்த செயல்பாடு *O*(1) நேரம் மற்றும் *O*(1) நினைவகத்தில் கணக்கிடப்பட வேண்டும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` இங்கே பரவாயில்லை, ஏனென்றால் இரண்டு பட்டியல்களுக்கும் முழுமையான அணுகல் எங்களிடம் உள்ளது.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// அனைத்து கூறுகளையும் `other` இலிருந்து பட்டியலின் தொடக்கத்திற்கு நகர்த்துகிறது.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` இங்கே பரவாயில்லை, ஏனென்றால் இரண்டு பட்டியல்களுக்கும் முழுமையான அணுகல் எங்களிடம் உள்ளது.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// முன்னோக்கி ஈரேட்டரை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// மாற்றக்கூடிய குறிப்புகளுடன் முன்னோக்கி ஈரேட்டரை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// முன் உறுப்பில் கர்சரை வழங்குகிறது.
    ///
    /// பட்டியல் காலியாக இருந்தால் கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டுகிறது.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// முன் உறுப்பில் எடிட்டிங் செயல்பாடுகளுடன் கர்சரை வழங்குகிறது.
    ///
    /// பட்டியல் காலியாக இருந்தால் கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டுகிறது.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// பின் உறுப்பில் கர்சரை வழங்குகிறது.
    ///
    /// பட்டியல் காலியாக இருந்தால் கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டுகிறது.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// பின்புற உறுப்பில் எடிட்டிங் செயல்பாடுகளுடன் கர்சரை வழங்குகிறது.
    ///
    /// பட்டியல் காலியாக இருந்தால் கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டுகிறது.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// `LinkedList` காலியாக இருந்தால் `true` ஐ வழங்குகிறது.
    ///
    /// இந்த செயல்பாடு *O*(1) நேரத்தில் கணக்கிடப்பட வேண்டும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// `LinkedList` இன் நீளத்தை வழங்குகிறது.
    ///
    /// இந்த செயல்பாடு *O*(1) நேரத்தில் கணக்கிடப்பட வேண்டும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// `LinkedList` இலிருந்து அனைத்து கூறுகளையும் நீக்குகிறது.
    ///
    /// இந்த செயல்பாடு *O*(*n*) நேரத்தில் கணக்கிடப்பட வேண்டும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// கொடுக்கப்பட்ட மதிப்புக்கு சமமான ஒரு உறுப்பை `LinkedList` கொண்டிருந்தால் `true` ஐ வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// முன் உறுப்புக்கு ஒரு குறிப்பை வழங்குகிறது, அல்லது பட்டியல் காலியாக இருந்தால் `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// முன் உறுப்புக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது, அல்லது பட்டியல் காலியாக இருந்தால் `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// பின் உறுப்புக்கான குறிப்பை வழங்குகிறது, அல்லது பட்டியல் காலியாக இருந்தால் `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// பின் உறுப்புக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது, அல்லது பட்டியல் காலியாக இருந்தால் `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// பட்டியலில் முதலில் ஒரு உறுப்பைச் சேர்க்கிறது.
    ///
    /// இந்த செயல்பாடு *O*(1) நேரத்தில் கணக்கிடப்பட வேண்டும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// முதல் உறுப்பை அகற்றி அதைத் தருகிறது, அல்லது பட்டியல் காலியாக இருந்தால் `None`.
    ///
    ///
    /// இந்த செயல்பாடு *O*(1) நேரத்தில் கணக்கிடப்பட வேண்டும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// பட்டியலின் பின்புறத்தில் ஒரு உறுப்பைச் சேர்க்கிறது.
    ///
    /// இந்த செயல்பாடு *O*(1) நேரத்தில் கணக்கிடப்பட வேண்டும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// ஒரு பட்டியலிலிருந்து கடைசி உறுப்பை அகற்றி அதை திருப்பித் தருகிறது, அல்லது அது காலியாக இருந்தால் `None`.
    ///
    ///
    /// இந்த செயல்பாடு *O*(1) நேரத்தில் கணக்கிடப்பட வேண்டும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// கொடுக்கப்பட்ட குறியீட்டில் பட்டியலை இரண்டாகப் பிரிக்கிறது.
    /// கொடுக்கப்பட்ட குறியீட்டுக்குப் பிறகு எல்லாவற்றையும் வழங்குகிறது.
    ///
    /// இந்த செயல்பாடு *O*(*n*) நேரத்தில் கணக்கிடப்பட வேண்டும்.
    ///
    /// # Panics
    ///
    /// `at > len` என்றால் Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // கீழே, தொடக்கத்திலிருந்தோ அல்லது முடிவிலிருந்தோ `i-1` வது முனை நோக்கிச் செல்கிறோம், இது வேகமாக இருக்கும் என்பதைப் பொறுத்து.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // .skip() ஐப் பயன்படுத்துவதைத் தவிர்ப்பதற்குப் பதிலாக (இது ஒரு புதிய கட்டமைப்பை உருவாக்குகிறது), நாங்கள் கைமுறையாகத் தவிர்த்து விடுகிறோம், எனவே ஸ்கிப்பின் செயல்பாட்டு விவரங்களைப் பொறுத்து இல்லாமல் தலை புலத்தை அணுகலாம்.
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // முடிவில் இருந்து தொடங்குவது நல்லது
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// கொடுக்கப்பட்ட குறியீட்டில் உள்ள உறுப்பை அகற்றி அதை திருப்பித் தருகிறது.
    ///
    /// இந்த செயல்பாடு *O*(*n*) நேரத்தில் கணக்கிடப்பட வேண்டும்.
    ///
    /// # Panics
    /// Panics என்றால்>=லென்
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // கீழே, கொடுக்கப்பட்ட குறியீட்டில் உள்ள முனை நோக்கி, தொடக்கத்திலிருந்தோ அல்லது முடிவிலிருந்தோ, இது வேகமாக இருக்கும் என்பதைப் பொறுத்து மீண்டும் சொல்கிறோம்.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// ஒரு உறுப்பு அகற்றப்பட வேண்டுமா என்பதை தீர்மானிக்க மூடுதலைப் பயன்படுத்தும் ஒரு ஈரேட்டரை உருவாக்குகிறது.
    ///
    /// மூடல் உண்மைக்குத் திரும்பினால், உறுப்பு அகற்றப்பட்டு வழங்கப்படுகிறது.
    /// மூடல் தவறானது எனில், உறுப்பு பட்டியலில் இருக்கும், மேலும் அது ஈரேட்டரால் வழங்கப்படாது.
    ///
    /// வடிகட்டி மூடுதலில் உள்ள ஒவ்வொரு உறுப்புகளையும் மாற்றியமைக்க `drain_filter` உங்களை அனுமதிக்கிறது என்பதை நினைவில் கொள்க.
    ///
    ///
    /// # Examples
    ///
    /// ஒரு பட்டியலை மாலை மற்றும் முரண்பாடுகளாகப் பிரித்தல், அசல் பட்டியலை மீண்டும் பயன்படுத்துதல்:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // கடன் சிக்கல்களைத் தவிர்க்கவும்.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // நாம் கீழே செய்யும் அதே சுழற்சியைத் தொடரவும்.ஒரு அழிப்பான் பீதியடைந்தால் மட்டுமே இது இயங்கும்.
                // இன்னொன்று panics என்றால் இது நிறுத்தப்படும்.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'A ஐப் பெற வரம்பற்ற வாழ்நாள் தேவை
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'A ஐப் பெற வரம்பற்ற வாழ்நாள் தேவை
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'A ஐப் பெற வரம்பற்ற வாழ்நாள் தேவை
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'A ஐப் பெற வரம்பற்ற வாழ்நாள் தேவை
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// `LinkedList` க்கு மேல் கர்சர்.
///
/// ஒரு `Cursor` என்பது ஒரு ஈரேட்டரைப் போன்றது, தவிர அது சுதந்திரமாக முன்னும் பின்னுமாக தேட முடியும்.
///
/// கர்சர்கள் எப்போதும் பட்டியலில் உள்ள இரண்டு கூறுகளுக்கு இடையில் ஓய்வெடுக்கும், மற்றும் குறியீட்டு தர்க்கரீதியாக வட்ட வழியில் இருக்கும்.
/// இதற்கு இடமளிக்க, பட்டியலின் தலைக்கும் வால்க்கும் இடையில் `None` ஐ வழங்கும் "ghost" அல்லாத உறுப்பு உள்ளது.
///
///
/// உருவாக்கப்படும் போது, கர்சர்கள் பட்டியலின் முன்புறத்தில் தொடங்குகின்றன, அல்லது பட்டியல் காலியாக இருந்தால் "ghost" அல்லாத உறுப்பு.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// எடிட்டிங் செயல்பாடுகளுடன் `LinkedList` க்கு மேல் கர்சர்.
///
/// ஒரு `Cursor` என்பது ஒரு ஈரேட்டரைப் போன்றது, இது சுதந்திரமாக முன்னும் பின்னுமாக தேடலாம், மற்றும் மறு செய்கையின் போது பட்டியலை பாதுகாப்பாக மாற்ற முடியும்.
/// ஏனென்றால், அதன் விளைந்த குறிப்புகளின் வாழ்நாள் அடிப்படை பட்டியலுக்குப் பதிலாக அதன் சொந்த வாழ்நாளுடன் பிணைக்கப்பட்டுள்ளது.
/// இதன் பொருள் கர்சர்களால் ஒரே நேரத்தில் பல கூறுகளை வழங்க முடியாது.
///
/// கர்சர்கள் எப்போதும் பட்டியலில் உள்ள இரண்டு கூறுகளுக்கு இடையில் ஓய்வெடுக்கும், மற்றும் குறியீட்டு தர்க்கரீதியாக வட்ட வழியில் இருக்கும்.
/// இதற்கு இடமளிக்க, பட்டியலின் தலைக்கும் வால்க்கும் இடையில் `None` ஐ வழங்கும் "ghost" அல்லாத உறுப்பு உள்ளது.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// `LinkedList` க்குள் கர்சர் நிலை குறியீட்டை வழங்குகிறது.
    ///
    /// கர்சர் தற்போது "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால் இது `None` ஐ வழங்குகிறது.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// கர்சரை `LinkedList` இன் அடுத்த உறுப்புக்கு நகர்த்துகிறது.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால், இது `LinkedList` இன் முதல் உறுப்புக்கு நகரும்.
    /// இது `LinkedList` இன் கடைசி உறுப்பை சுட்டிக்காட்டினால், இது "ghost" அல்லாத உறுப்புக்கு நகரும்.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // எங்களிடம் தற்போதைய உறுப்பு இல்லை;கர்சர் தொடக்க நிலையில் அமர்ந்திருந்தது அடுத்த உறுப்பு பட்டியலின் தலைவராக இருக்க வேண்டும்
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // எங்களிடம் முந்தைய உறுப்பு இருந்தது, எனவே அதன் அடுத்த நிலைக்குச் செல்வோம்
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// கர்சரை `LinkedList` இன் முந்தைய உறுப்புக்கு நகர்த்துகிறது.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால், இது `LinkedList` இன் கடைசி உறுப்புக்கு நகரும்.
    /// இது `LinkedList` இன் முதல் உறுப்பை சுட்டிக்காட்டினால், இது "ghost" அல்லாத உறுப்புக்கு நகரும்.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // நடப்பு இல்லை.நாங்கள் பட்டியலின் தொடக்கத்தில் இருக்கிறோம்.எதுவுமில்லை, கடைசியில் குதிக்கவும்.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // ஒரு முந்தைய வேண்டும்.மகசூல் மற்றும் முந்தைய உறுப்புக்குச் செல்லவும்.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// கர்சர் தற்போது சுட்டிக்காட்டும் உறுப்புக்கான குறிப்பை வழங்குகிறது.
    ///
    /// கர்சர் தற்போது "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால் இது `None` ஐ வழங்குகிறது.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// அடுத்த உறுப்புக்கான குறிப்பை வழங்குகிறது.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால், இது `LinkedList` இன் முதல் உறுப்பை வழங்குகிறது.
    /// இது `LinkedList` இன் கடைசி உறுப்பை சுட்டிக்காட்டினால், இது `None` ஐ வழங்குகிறது.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// முந்தைய உறுப்புக்கான குறிப்பை வழங்குகிறது.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால், இது `LinkedList` இன் கடைசி உறுப்பை வழங்குகிறது.
    /// இது `LinkedList` இன் முதல் உறுப்பை சுட்டிக்காட்டினால், இது `None` ஐ வழங்குகிறது.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// `LinkedList` க்குள் கர்சர் நிலை குறியீட்டை வழங்குகிறது.
    ///
    /// கர்சர் தற்போது "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால் இது `None` ஐ வழங்குகிறது.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// கர்சரை `LinkedList` இன் அடுத்த உறுப்புக்கு நகர்த்துகிறது.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால், இது `LinkedList` இன் முதல் உறுப்புக்கு நகரும்.
    /// இது `LinkedList` இன் கடைசி உறுப்பை சுட்டிக்காட்டினால், இது "ghost" அல்லாத உறுப்புக்கு நகரும்.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // எங்களிடம் தற்போதைய உறுப்பு இல்லை;கர்சர் தொடக்க நிலையில் அமர்ந்திருந்தது அடுத்த உறுப்பு பட்டியலின் தலைவராக இருக்க வேண்டும்
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // எங்களிடம் முந்தைய உறுப்பு இருந்தது, எனவே அதன் அடுத்த நிலைக்குச் செல்வோம்
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// கர்சரை `LinkedList` இன் முந்தைய உறுப்புக்கு நகர்த்துகிறது.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால், இது `LinkedList` இன் கடைசி உறுப்புக்கு நகரும்.
    /// இது `LinkedList` இன் முதல் உறுப்பை சுட்டிக்காட்டினால், இது "ghost" அல்லாத உறுப்புக்கு நகரும்.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // நடப்பு இல்லை.நாங்கள் பட்டியலின் தொடக்கத்தில் இருக்கிறோம்.எதுவுமில்லை, கடைசியில் குதிக்கவும்.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // ஒரு முந்தைய வேண்டும்.மகசூல் மற்றும் முந்தைய உறுப்புக்குச் செல்லவும்.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// கர்சர் தற்போது சுட்டிக்காட்டும் உறுப்புக்கான குறிப்பை வழங்குகிறது.
    ///
    /// கர்சர் தற்போது "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால் இது `None` ஐ வழங்குகிறது.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// அடுத்த உறுப்புக்கான குறிப்பை வழங்குகிறது.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால், இது `LinkedList` இன் முதல் உறுப்பை வழங்குகிறது.
    /// இது `LinkedList` இன் கடைசி உறுப்பை சுட்டிக்காட்டினால், இது `None` ஐ வழங்குகிறது.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// முந்தைய உறுப்புக்கான குறிப்பை வழங்குகிறது.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால், இது `LinkedList` இன் கடைசி உறுப்பை வழங்குகிறது.
    /// இது `LinkedList` இன் முதல் உறுப்பை சுட்டிக்காட்டினால், இது `None` ஐ வழங்குகிறது.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// தற்போதைய உறுப்பை சுட்டிக்காட்டும் படிக்க மட்டும் கர்சரை வழங்குகிறது.
    ///
    /// திரும்பிய `Cursor` இன் வாழ்நாள் `CursorMut` உடன் பிணைக்கப்பட்டுள்ளது, அதாவது இது `CursorMut` ஐ விட அதிகமாக வாழ முடியாது, மேலும் `CursorMut` `Cursor` இன் வாழ்நாளில் உறைந்திருக்கும்.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// இப்போது பட்டியல் திருத்துதல் செயல்பாடுகள்

impl<'a, T> CursorMut<'a, T> {
    /// தற்போதைய ஒன்றிற்குப் பிறகு `LinkedList` இல் புதிய உறுப்பைச் செருகும்.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்பை சுட்டிக்காட்டினால், புதிய உறுப்பு `LinkedList` இன் முன்புறத்தில் செருகப்படுகிறது.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // "ghost" அல்லாத உறுப்பு குறியீட்டு மாறிவிட்டது.
                self.index = self.list.len;
            }
        }
    }

    /// நடப்புக்கு முன் `LinkedList` இல் புதிய உறுப்பைச் செருகும்.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்பை சுட்டிக்காட்டினால், புதிய உறுப்பு `LinkedList` இன் இறுதியில் செருகப்படுகிறது.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// `LinkedList` இலிருந்து தற்போதைய உறுப்பை நீக்குகிறது.
    ///
    /// அகற்றப்பட்ட உறுப்பு திரும்பப் பெறப்படுகிறது, மேலும் கர்சர் `LinkedList` இன் அடுத்த உறுப்புக்கு சுட்டிக்காட்டப்படுகிறது.
    ///
    ///
    /// கர்சர் தற்போது "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால், எந்த உறுப்பு அகற்றப்படாது மற்றும் `None` திரும்பும்.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// பட்டியல் முனையை நீக்காமல் `LinkedList` இலிருந்து தற்போதைய உறுப்பை நீக்குகிறது.
    ///
    /// அகற்றப்பட்ட முனை இந்த முனை மட்டுமே கொண்ட புதிய `LinkedList` ஆக திருப்பி அனுப்பப்படுகிறது.
    /// தற்போதைய `LinkedList` இன் அடுத்த உறுப்புக்கு சுட்டிக்காட்ட கர்சர் நகர்த்தப்படுகிறது.
    ///
    /// கர்சர் தற்போது "ghost" அல்லாத உறுப்புக்கு சுட்டிக்காட்டினால், எந்த உறுப்பு அகற்றப்படாது மற்றும் `None` திரும்பும்.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// தற்போதைய ஒன்றிற்குப் பிறகு கொடுக்கப்பட்ட `LinkedList` இலிருந்து உறுப்புகளைச் செருகும்.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்பை சுட்டிக்காட்டினால், புதிய கூறுகள் `LinkedList` இன் தொடக்கத்தில் செருகப்படுகின்றன.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // "ghost" அல்லாத உறுப்பு குறியீட்டு மாறிவிட்டது.
                self.index = self.list.len;
            }
        }
    }

    /// கொடுக்கப்பட்ட `LinkedList` இலிருந்து உறுப்புகளை தற்போதைய ஒன்றிற்கு முன் செருகும்.
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்பை சுட்டிக்காட்டினால், புதிய கூறுகள் `LinkedList` இன் இறுதியில் செருகப்படுகின்றன.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// தற்போதைய உறுப்புக்குப் பிறகு பட்டியலை இரண்டாகப் பிரிக்கிறது.
    /// இது கர்சருக்குப் பிறகு எல்லாவற்றையும் உள்ளடக்கிய புதிய பட்டியலைத் தரும், அசல் பட்டியல் எல்லாவற்றையும் முன்பு வைத்திருக்கும்.
    ///
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்பை சுட்டிக்காட்டினால், `LinkedList` இன் முழு உள்ளடக்கங்களும் நகர்த்தப்படும்.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // "ghost" அல்லாத உறுப்பு குறியீடு 0 ஆக மாற்றப்பட்டுள்ளது.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// தற்போதைய உறுப்புக்கு முன் பட்டியலை இரண்டாகப் பிரிக்கிறது.
    /// இது கர்சருக்கு முன் எல்லாவற்றையும் உள்ளடக்கிய ஒரு புதிய பட்டியலைத் தரும், அசல் பட்டியல் எல்லாவற்றையும் தக்க வைத்துக் கொள்ளும்.
    ///
    ///
    /// கர்சர் "ghost" அல்லாத உறுப்பை சுட்டிக்காட்டினால், `LinkedList` இன் முழு உள்ளடக்கங்களும் நகர்த்தப்படும்.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// சென்டர் பட்டியலில் `drain_filter` ஐ அழைப்பதன் மூலம் தயாரிக்கப்படும் ஒரு ஈரேட்டர்.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` `element` குறிப்புகளை மாற்றுவதில் பரவாயில்லை.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// மதிப்பின் அடிப்படையில் உறுப்புகளை வழங்கும் ஒரு ஈரேட்டராக பட்டியலைப் பயன்படுத்துகிறது.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// `LinkedList` மற்றும் அதன் படிக்க-மட்டும் ஐரேட்டர்கள் அவற்றின் வகை அளவுருக்களில் இணக்கமாக இருப்பதை உறுதிசெய்க.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}