//! குவியல் ஒதுக்கீட்டிற்கான ஒரு சுட்டிக்காட்டி வகை.
//!
//! [`Box<T>`], பொதுவாக 'box' என குறிப்பிடப்படுகிறது, இது Rust இல் குவியல் ஒதுக்கீட்டின் எளிய வடிவத்தை வழங்குகிறது.பெட்டிகள் இந்த ஒதுக்கீட்டிற்கான உரிமையை வழங்குகின்றன, மேலும் அவை உள்ளடக்கத்திற்கு வெளியே செல்லும்போது அவற்றின் உள்ளடக்கங்களை கைவிடுகின்றன.பெட்டிகள் `isize::MAX` பைட்டுகளுக்கு மேல் ஒருபோதும் ஒதுக்கவில்லை என்பதையும் உறுதி செய்கின்றன.
//!
//! # Examples
//!
//! ஒரு [`Box`] ஐ உருவாக்குவதன் மூலம் அடுக்கிலிருந்து குவியலுக்கு ஒரு மதிப்பை நகர்த்தவும்:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! ஒரு மதிப்பை [`Box`] இலிருந்து [dereferencing] ஆல் அடுக்கிற்கு நகர்த்தவும்:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! ஒரு சுழல்நிலை தரவு கட்டமைப்பை உருவாக்குதல்:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! இது `Cons (1, Cons(2, Nil))`.
//!
//! சுழல்நிலை கட்டமைப்புகள் பெட்டியில் வைக்கப்பட வேண்டும், ஏனென்றால் `Cons` இன் வரையறை இப்படி இருந்தால்:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! அது வேலை செய்யாது.ஏனென்றால், ஒரு `List` இன் அளவு பட்டியலில் எத்தனை கூறுகள் உள்ளன என்பதைப் பொறுத்தது, எனவே ஒரு `Cons` க்கு எவ்வளவு நினைவகத்தை ஒதுக்க வேண்டும் என்பது எங்களுக்குத் தெரியாது.வரையறுக்கப்பட்ட அளவைக் கொண்ட [`Box<T>`] ஐ அறிமுகப்படுத்துவதன் மூலம், `Cons` எவ்வளவு பெரியதாக இருக்க வேண்டும் என்பது எங்களுக்குத் தெரியும்.
//!
//! # நினைவக தளவமைப்பு
//!
//! பூஜ்ஜியமற்ற அளவிலான மதிப்புகளுக்கு, ஒரு [`Box`] அதன் ஒதுக்கீட்டிற்கு [`Global`] ஒதுக்கீட்டைப் பயன்படுத்தும்.[`Box`] மற்றும் [`Global`] ஒதுக்கீட்டாளருடன் ஒதுக்கப்பட்ட மூல சுட்டிக்காட்டிக்கு இடையில் இரு வழிகளையும் மாற்றுவது செல்லுபடியாகும், ஒதுக்கீட்டாளருடன் பயன்படுத்தப்படும் [`Layout`] வகைக்கு சரியானது.
//!
//! இன்னும் துல்லியமாக, `Layout::for_value(&*value)` உடன் [`Global`] ஒதுக்கீட்டாளருடன் ஒதுக்கப்பட்ட `value:* mut T` ஆனது [`Box::<T>::from_raw(value)`] ஐப் பயன்படுத்தி ஒரு பெட்டியாக மாற்றப்படலாம்.
//! மாறாக, [`Box::<T>::into_raw`] இலிருந்து பெறப்பட்ட `value:*mut T` ஐ ஆதரிக்கும் நினைவகம் [`Layout::for_value(&* value)`] உடன் [`Global`] ஒதுக்கீட்டைப் பயன்படுத்தி ஒதுக்கப்படலாம்.
//!
//! பூஜ்ஜிய அளவிலான மதிப்புகளுக்கு, `Box` சுட்டிக்காட்டி இன்னும் படிக்க மற்றும் எழுதுவதற்கு [valid] ஆக இருக்க வேண்டும் மற்றும் போதுமான அளவு சீரமைக்கப்பட்டது.
//! குறிப்பாக, எந்த சீரமைக்கப்பட்ட பூஜ்ஜியமற்ற முழு எண்ணையும் மூல சுட்டிக்காட்டிக்கு அனுப்புவது சரியான சுட்டிக்காட்டி ஒன்றை உருவாக்குகிறது, ஆனால் விடுவிக்கப்பட்டதிலிருந்து முன்பே ஒதுக்கப்பட்ட நினைவகத்தை சுட்டிக்காட்டும் ஒரு சுட்டிக்காட்டி செல்லுபடியாகாது.
//! `Box::new` ஐப் பயன்படுத்த முடியாவிட்டால் ஒரு ZST க்கு ஒரு பெட்டியை உருவாக்க பரிந்துரைக்கப்பட்ட வழி [`ptr::NonNull::dangling`] ஐப் பயன்படுத்துவதாகும்.
//!
//! `T: Sized` இருக்கும் வரை, ஒரு `Box<T>` ஒற்றை சுட்டிக்காட்டி எனக் குறிப்பிடப்படுவது உறுதி மற்றும் சி சுட்டிகளுடன் (அதாவது சி வகை `T*`) ஏபிஐ-இணக்கமானது.
//! இதன் பொருள் உங்களிடம் C இலிருந்து அழைக்கப்படும் வெளிப்புற "C" Rust செயல்பாடுகள் இருந்தால், நீங்கள் `Box<T>` வகைகளைப் பயன்படுத்தி அந்த Rust செயல்பாடுகளை வரையறுக்கலாம், மேலும் C0 பக்கத்தில் `T*` ஐ தொடர்புடைய வகையாகப் பயன்படுத்தலாம்.
//! உதாரணமாக, சில வகையான `Foo` மதிப்பை உருவாக்கி அழிக்கும் செயல்பாடுகளை அறிவிக்கும் இந்த சி தலைப்பைக் கவனியுங்கள்:
//!
//! ```c
//! /* சி தலைப்பு */
//!
//! /* அழைப்பவருக்கு உரிமையை வழங்குகிறது */
//! struct Foo* foo_new(void);
//!
//! /* அழைப்பாளரிடமிருந்து உரிமையை எடுக்கிறது;NULL உடன் பயன்படுத்தப்படும்போது இல்லை */
//! void foo_delete(struct Foo*);
//! ```
//!
//! இந்த இரண்டு செயல்பாடுகளும் பின்வருமாறு Rust இல் செயல்படுத்தப்படலாம்.இங்கே, C இலிருந்து `struct Foo*` வகை `Box<Foo>` க்கு மொழிபெயர்க்கப்பட்டுள்ளது, இது உரிமைக் கட்டுப்பாடுகளைப் பிடிக்கிறது.
//! `foo_delete` க்கு செல்லமுடியாத வாதம் X0Rust0Z இல் `Option<Box<Foo>>` ஆக குறிப்பிடப்படுகிறது, ஏனெனில் `Box<Foo>` பூஜ்யமாக இருக்க முடியாது.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! `Box<T>` க்கு சி பிரதிநிதித்துவமாக அதே பிரதிநிதித்துவம் மற்றும் சி ஏபிஐ இருந்தாலும், நீங்கள் ஒரு தன்னிச்சையான `T*` ஐ `Box<T>` ஆக மாற்றலாம் மற்றும் விஷயங்கள் செயல்படும் என்று எதிர்பார்க்கலாம்.
//! `Box<T>` மதிப்புகள் எப்போதும் முழுமையாக சீரமைக்கப்படும், பூஜ்யமற்ற சுட்டிகள்.மேலும், `Box<T>` க்கான அழிப்பான் உலகளாவிய ஒதுக்கீட்டாளருடன் மதிப்பை விடுவிக்க முயற்சிக்கும்.பொதுவாக, உலகளாவிய ஒதுக்கீட்டாளரிடமிருந்து தோன்றிய சுட்டிகளுக்கு `Box<T>` ஐ மட்டுமே பயன்படுத்துவது சிறந்த நடைமுறை.
//!
//! **முக்கியமானது.** குறைந்தபட்சம் தற்போது, C இல் வரையறுக்கப்பட்ட ஆனால் Rust இலிருந்து செயல்படுத்தப்படும் செயல்பாடுகளுக்கு `Box<T>` வகைகளைப் பயன்படுத்துவதைத் தவிர்க்க வேண்டும்.அந்த சந்தர்ப்பங்களில், நீங்கள் சி வகைகளை முடிந்தவரை நெருக்கமாக பிரதிபலிக்க வேண்டும்.
//! சி வரையறை `T*` ஐப் பயன்படுத்தும் இடத்தில் `Box<T>` போன்ற வகைகளைப் பயன்படுத்துவது [rust-lang/unsafe-code-guidelines#198][ucg#198] இல் விவரிக்கப்பட்டுள்ளபடி வரையறுக்கப்படாத நடத்தைக்கு வழிவகுக்கும்.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// குவியல் ஒதுக்கீட்டிற்கான ஒரு சுட்டிக்காட்டி வகை.
///
/// மேலும் அறிய [module-level documentation](../../std/boxed/index.html) ஐப் பார்க்கவும்.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// குவியலில் நினைவகத்தை ஒதுக்குகிறது, பின்னர் அதில் `x` ஐ வைக்கிறது.
    ///
    /// `T` பூஜ்ஜிய அளவிலானதாக இருந்தால் இது உண்மையில் ஒதுக்கப்படாது.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய பெட்டியை உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// நினைவகம் `0` பைட்டுகளால் நிரப்பப்பட்ட நிலையில், ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய `Box` ஐ உருவாக்குகிறது.
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// புதிய `Pin<Box<T>>` ஐ உருவாக்குகிறது.
    /// `T` `Unpin` ஐ செயல்படுத்தவில்லை என்றால், `x` நினைவகத்தில் பொருத்தப்பட்டு நகர்த்த முடியாது.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// குவியலில் நினைவகத்தை ஒதுக்குகிறது, பின்னர் அதில் `x` ஐ வைக்கிறது, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது
    ///
    ///
    /// `T` பூஜ்ஜிய அளவிலானதாக இருந்தால் இது உண்மையில் ஒதுக்கப்படாது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// குவியலில் ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய பெட்டியை உருவாக்குகிறது, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// ஒரு புதிய `Box` ஐ ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் உருவாக்குகிறது, நினைவகம் குவியலில் `0` பைட்டுகளால் நிரப்பப்படுகிறது
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// கொடுக்கப்பட்ட ஒதுக்கீட்டில் நினைவகத்தை ஒதுக்குகிறது, பின்னர் அதில் `x` ஐ வைக்கிறது.
    ///
    /// `T` பூஜ்ஜிய அளவிலானதாக இருந்தால் இது உண்மையில் ஒதுக்கப்படாது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// கொடுக்கப்பட்ட ஒதுக்கீட்டில் நினைவகத்தை ஒதுக்குகிறது, பின்னர் அதில் `x` ஐ வைக்கிறது, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது
    ///
    ///
    /// `T` பூஜ்ஜிய அளவிலானதாக இருந்தால் இது உண்மையில் ஒதுக்கப்படாது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// வழங்கப்பட்ட ஒதுக்கீட்டில் ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய பெட்டியை உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: மூடல் சிலநேரங்களில் ஒத்துப்போகாததால், unrap_or_else ஐ விட போட்டியை விரும்புங்கள்.
        // அது குறியீடு அளவை பெரிதாக்கும்.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// வழங்கப்பட்ட ஒதுக்கீட்டில் துவக்கப்படாத உள்ளடக்கங்களுடன் புதிய பெட்டியை உருவாக்குகிறது, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// வழங்கப்பட்ட ஒதுக்கீட்டில் நினைவகம் `0` பைட்டுகளால் நிரப்பப்பட்ட நிலையில், ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய `Box` ஐ உருவாக்குகிறது.
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: மூடல் சிலநேரங்களில் ஒத்துப்போகாததால், unrap_or_else ஐ விட போட்டியை விரும்புங்கள்.
        // அது குறியீடு அளவை பெரிதாக்கும்.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய `Box` ஐ உருவாக்குகிறது, வழங்கப்பட்ட ஒதுக்கீட்டில் நினைவகம் `0` பைட்டுகளால் நிரப்பப்படுகிறது, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது,
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// புதிய `Pin<Box<T, A>>` ஐ உருவாக்குகிறது.
    /// `T` `Unpin` ஐ செயல்படுத்தவில்லை என்றால், `x` நினைவகத்தில் பொருத்தப்பட்டு நகர்த்த முடியாது.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// ஒரு `Box<T>` ஐ `Box<[T]>` ஆக மாற்றுகிறது
    ///
    /// இந்த மாற்றம் குவியலில் ஒதுக்கப்படாது, இடத்தில் நடக்கிறது.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// `Box` ஐப் பயன்படுத்துகிறது, மூடப்பட்ட மதிப்பைத் தருகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய பெட்டி துண்டுகளை உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// நினைவகம் `0` பைட்டுகளால் நிரப்பப்பட்ட நிலையில், ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய பெட்டி துண்டுகளை உருவாக்குகிறது.
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// வழங்கப்பட்ட ஒதுக்கீட்டில் துவக்கப்படாத உள்ளடக்கங்களுடன் புதிய பெட்டி துண்டுகளை உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// வழங்கப்பட்ட ஒதுக்கீட்டில் ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய பெட்டி துண்டுகளை உருவாக்குகிறது, நினைவகம் `0` பைட்டுகளால் நிரப்பப்படுகிறது.
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>` ஆக மாற்றுகிறது.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ஐப் போலவே, மதிப்பு உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளது என்பதை உறுதிப்படுத்துவது அழைப்பாளரின் பொறுப்பாகும்.
    ///
    /// உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது உடனடி வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>` ஆக மாற்றுகிறது.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ஐப் போலவே, மதிப்புகள் உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளன என்பதை உத்தரவாதம் செய்வது அழைப்பாளரின் பொறுப்பாகும்.
    ///
    /// உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது உடனடி வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// மூல சுட்டிக்காட்டி ஒரு பெட்டியை உருவாக்குகிறது.
    ///
    /// இந்த செயல்பாட்டை அழைத்த பிறகு, மூல சுட்டிக்காட்டி விளைவாக வரும் `Box` க்கு சொந்தமானது.
    /// குறிப்பாக, `Box` அழிப்பான் `T` இன் அழிப்பாளரை அழைக்கும் மற்றும் ஒதுக்கப்பட்ட நினைவகத்தை விடுவிக்கும்.
    /// இது பாதுகாப்பாக இருக்க, `Box` பயன்படுத்தும் [memory layout] க்கு ஏற்ப நினைவகம் ஒதுக்கப்பட்டிருக்க வேண்டும்.
    ///
    ///
    /// # Safety
    ///
    /// இந்த செயல்பாடு பாதுகாப்பற்றது, ஏனெனில் முறையற்ற பயன்பாடு நினைவக சிக்கல்களுக்கு வழிவகுக்கும்.
    /// எடுத்துக்காட்டாக, ஒரே மூல சுட்டிக்காட்டி மீது செயல்பாடு இரண்டு முறை அழைக்கப்பட்டால் இரட்டை-இலவசம் ஏற்படலாம்.
    ///
    /// பாதுகாப்பு நிலைமைகள் [memory layout] பிரிவில் விவரிக்கப்பட்டுள்ளன.
    ///
    /// # Examples
    ///
    /// முன்பு [`Box::into_raw`] ஐப் பயன்படுத்தி மூல சுட்டிக்காட்டிக்கு மாற்றப்பட்ட `Box` ஐ மீண்டும் உருவாக்கவும்:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// உலகளாவிய ஒதுக்கீட்டைப் பயன்படுத்தி புதிதாக ஒரு `Box` ஐ கைமுறையாக உருவாக்கவும்:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // `ptr` இன் (uninitialized) முந்தைய உள்ளடக்கங்களை அழிக்க முயற்சிப்பதைத் தவிர்க்க பொதுவாக .write தேவைப்படுகிறது, இருப்பினும் இந்த எளிய எடுத்துக்காட்டுக்கு `*ptr = 5` அதேபோல் செயல்பட்டிருக்கும்.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// கொடுக்கப்பட்ட ஒதுக்கீட்டில் ஒரு மூல சுட்டிக்காட்டி ஒரு பெட்டியை உருவாக்குகிறது.
    ///
    /// இந்த செயல்பாட்டை அழைத்த பிறகு, மூல சுட்டிக்காட்டி விளைவாக வரும் `Box` க்கு சொந்தமானது.
    /// குறிப்பாக, `Box` அழிப்பான் `T` இன் அழிப்பாளரை அழைக்கும் மற்றும் ஒதுக்கப்பட்ட நினைவகத்தை விடுவிக்கும்.
    /// இது பாதுகாப்பாக இருக்க, `Box` பயன்படுத்தும் [memory layout] க்கு ஏற்ப நினைவகம் ஒதுக்கப்பட்டிருக்க வேண்டும்.
    ///
    ///
    /// # Safety
    ///
    /// இந்த செயல்பாடு பாதுகாப்பற்றது, ஏனெனில் முறையற்ற பயன்பாடு நினைவக சிக்கல்களுக்கு வழிவகுக்கும்.
    /// எடுத்துக்காட்டாக, ஒரே மூல சுட்டிக்காட்டி மீது செயல்பாடு இரண்டு முறை அழைக்கப்பட்டால் இரட்டை-இலவசம் ஏற்படலாம்.
    ///
    /// # Examples
    ///
    /// முன்பு [`Box::into_raw_with_allocator`] ஐப் பயன்படுத்தி மூல சுட்டிக்காட்டிக்கு மாற்றப்பட்ட `Box` ஐ மீண்டும் உருவாக்கவும்:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// கணினி ஒதுக்கீட்டைப் பயன்படுத்தி புதிதாக ஒரு `Box` ஐ கைமுறையாக உருவாக்கவும்:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // `ptr` இன் (uninitialized) முந்தைய உள்ளடக்கங்களை அழிக்க முயற்சிப்பதைத் தவிர்க்க பொதுவாக .write தேவைப்படுகிறது, இருப்பினும் இந்த எளிய எடுத்துக்காட்டுக்கு `*ptr = 5` அதேபோல் செயல்பட்டிருக்கும்.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// `Box` ஐப் பயன்படுத்துகிறது, ஒரு மூடப்பட்ட மூல சுட்டிக்காட்டி திருப்பித் தருகிறது.
    ///
    /// சுட்டிக்காட்டி சரியாக சீரமைக்கப்பட்டு பூஜ்யமற்றதாக இருக்கும்.
    ///
    /// இந்த செயல்பாட்டை அழைத்த பிறகு, முன்பு `Box` ஆல் நிர்வகிக்கப்பட்ட நினைவகத்திற்கு அழைப்பாளர் பொறுப்பு.
    /// குறிப்பாக, அழைப்பாளர் `T` ஐ சரியாக அழித்து நினைவகத்தை வெளியிட வேண்டும், `Box` பயன்படுத்தும் [memory layout] ஐ கணக்கில் எடுத்துக்கொள்ள வேண்டும்.
    /// இதைச் செய்வதற்கான எளிதான வழி, மூல சுட்டிக்காட்டி [`Box::from_raw`] செயல்பாட்டுடன் மீண்டும் `Box` ஆக மாற்றுவது, இது `Box` அழிப்பான் தூய்மைப்படுத்தலை அனுமதிக்கிறது.
    ///
    ///
    /// Note: இது ஒரு தொடர்புடைய செயல்பாடு, அதாவது நீங்கள் அதை `b.into_raw()` க்கு பதிலாக `Box::into_raw(b)` என அழைக்க வேண்டும்.
    /// உள் வகைகளில் ஒரு முறையுடன் எந்த மோதலும் இல்லை என்பதே இது.
    ///
    /// # Examples
    /// தானியங்கு தூய்மைப்படுத்துதலுக்காக மூல சுட்டிக்காட்டி மீண்டும் `Box` ஆக [`Box::from_raw`] உடன் மாற்றுகிறது:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// அழிப்பாளரை வெளிப்படையாக இயக்குவதன் மூலமும் நினைவகத்தை நீக்குவதன் மூலமும் கையேடு சுத்தம் செய்தல்:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box` ஐப் பயன்படுத்துகிறது, ஒரு மூடப்பட்ட மூல சுட்டிக்காட்டி மற்றும் ஒதுக்கீட்டைத் தருகிறது.
    ///
    /// சுட்டிக்காட்டி சரியாக சீரமைக்கப்பட்டு பூஜ்யமற்றதாக இருக்கும்.
    ///
    /// இந்த செயல்பாட்டை அழைத்த பிறகு, முன்பு `Box` ஆல் நிர்வகிக்கப்பட்ட நினைவகத்திற்கு அழைப்பாளர் பொறுப்பு.
    /// குறிப்பாக, அழைப்பாளர் `T` ஐ சரியாக அழித்து நினைவகத்தை வெளியிட வேண்டும், `Box` பயன்படுத்தும் [memory layout] ஐ கணக்கில் எடுத்துக்கொள்ள வேண்டும்.
    /// இதைச் செய்வதற்கான எளிதான வழி, மூல சுட்டிக்காட்டி [`Box::from_raw_in`] செயல்பாட்டுடன் மீண்டும் `Box` ஆக மாற்றுவது, இது `Box` அழிப்பான் தூய்மைப்படுத்தலை அனுமதிக்கிறது.
    ///
    ///
    /// Note: இது ஒரு தொடர்புடைய செயல்பாடு, அதாவது நீங்கள் அதை `b.into_raw_with_allocator()` க்கு பதிலாக `Box::into_raw_with_allocator(b)` என அழைக்க வேண்டும்.
    /// உள் வகைகளில் ஒரு முறையுடன் எந்த மோதலும் இல்லை என்பதே இது.
    ///
    /// # Examples
    /// தானியங்கு தூய்மைப்படுத்துதலுக்காக மூல சுட்டிக்காட்டி மீண்டும் `Box` ஆக [`Box::from_raw_in`] உடன் மாற்றுகிறது:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// அழிப்பாளரை வெளிப்படையாக இயக்குவதன் மூலமும் நினைவகத்தை நீக்குவதன் மூலமும் கையேடு சுத்தம் செய்தல்:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // பெட்டி "unique pointer" ஆக அடுக்கப்பட்ட கடன் மூலம் அங்கீகரிக்கப்பட்டுள்ளது, ஆனால் உள்நாட்டில் இது வகை முறைக்கு ஒரு மூல சுட்டிக்காட்டி.
        // மூல சுட்டிக்காட்டிக்கு நேரடியாக மாற்றுவது மாற்றுப்பெயர்ந்த மூல அணுகல்களை அனுமதிக்கும் தனித்துவமான சுட்டிக்காட்டி "releasing" ஆக அங்கீகரிக்கப்படாது, எனவே அனைத்து மூல சுட்டிக்காட்டி முறைகளும் `Box::leak` வழியாக செல்ல வேண்டும்.
        //
        // மூல சுட்டிக்காட்டிக்கு *அது* திருப்புவது சரியாக செயல்படுகிறது.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// அடிப்படை ஒதுக்கீட்டாளருக்கு ஒரு குறிப்பை வழங்குகிறது.
    ///
    /// Note: இது ஒரு தொடர்புடைய செயல்பாடு, அதாவது நீங்கள் அதை `b.allocator()` க்கு பதிலாக `Box::allocator(&b)` என அழைக்க வேண்டும்.
    /// உள் வகைகளில் ஒரு முறையுடன் எந்த மோதலும் இல்லை என்பதே இது.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// `Box` ஐ உட்கொண்டு கசிந்து, மாற்றக்கூடிய குறிப்பைத் தருகிறது, `&'a mut T`.
    /// `T` வகை தேர்ந்தெடுக்கப்பட்ட வாழ்நாள் `'a` ஐ விட அதிகமாக இருக்க வேண்டும் என்பதை நினைவில் கொள்க.
    /// வகைக்கு நிலையான குறிப்புகள் மட்டுமே இருந்தால், அல்லது எதுவுமில்லை என்றால், இது `'static` ஆக தேர்ந்தெடுக்கப்படலாம்.
    ///
    /// இந்த செயல்பாடு முக்கியமாக திட்டத்தின் வாழ்நாள் முழுவதும் வாழும் தரவுகளுக்கு பயனுள்ளதாக இருக்கும்.
    /// திரும்பிய குறிப்பை கைவிடுவது நினைவக கசிவை ஏற்படுத்தும்.
    /// இது ஏற்றுக்கொள்ளப்படாவிட்டால், குறிப்பு முதலில் `Box` ஐ உருவாக்கும் [`Box::from_raw`] செயல்பாட்டுடன் மூடப்பட்டிருக்க வேண்டும்.
    ///
    /// இந்த `Box` ஐ கைவிடலாம், இது `T` ஐ சரியாக அழித்து ஒதுக்கப்பட்ட நினைவகத்தை வெளியிடும்.
    ///
    /// Note: இது ஒரு தொடர்புடைய செயல்பாடு, அதாவது நீங்கள் அதை `b.leak()` க்கு பதிலாக `Box::leak(b)` என அழைக்க வேண்டும்.
    /// உள் வகைகளில் ஒரு முறையுடன் எந்த மோதலும் இல்லை என்பதே இது.
    ///
    /// # Examples
    ///
    /// எளிய பயன்பாடு:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// அளவிடப்படாத தரவு:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// ஒரு `Box<T>` ஐ `Pin<Box<T>>` ஆக மாற்றுகிறது
    ///
    /// இந்த மாற்றம் குவியலில் ஒதுக்கப்படாது, இடத்தில் நடக்கிறது.
    ///
    /// இது [`From`] வழியாகவும் கிடைக்கிறது.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // `T: !Unpin` போது `Pin<Box<T>>` இன் இன்சைடுகளை நகர்த்தவோ மாற்றவோ முடியாது, எனவே கூடுதல் தேவைகள் இல்லாமல் அதை நேரடியாக பின் செய்வது பாதுகாப்பானது.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: எதுவும் செய்ய வேண்டாம், துளி தற்போது தொகுப்பால் செய்யப்படுகிறது.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// ஒரு `Box<T>` ஐ உருவாக்குகிறது, T க்கான `Default` மதிப்புடன்.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// இந்த பெட்டியின் உள்ளடக்கங்களின் `clone()` உடன் புதிய பெட்டியை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // மதிப்பு ஒன்றே
    /// assert_eq!(x, y);
    ///
    /// // ஆனால் அவை தனித்துவமான பொருள்கள்
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // குளோன் செய்யப்பட்ட மதிப்பை நேரடியாக எழுத அனுமதிக்க நினைவகத்தை முன்கூட்டியே ஒதுக்கவும்.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// புதிய ஒதுக்கீட்டை உருவாக்காமல் `மூலத்தின் உள்ளடக்கங்களை `self` இல் நகலெடுக்கிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // மதிப்பு ஒன்றே
    /// assert_eq!(x, y);
    ///
    /// // மேலும் எந்த ஒதுக்கீடும் ஏற்படவில்லை
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // இது தரவின் நகலை உருவாக்குகிறது
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// பொதுவான வகை `T` ஐ `Box<T>` ஆக மாற்றுகிறது
    ///
    /// மாற்றம் குவியலில் ஒதுக்குகிறது மற்றும் அடுக்கிலிருந்து `t` ஐ நகர்த்துகிறது.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// ஒரு `Box<T>` ஐ `Pin<Box<T>>` ஆக மாற்றுகிறது
    ///
    /// இந்த மாற்றம் குவியலில் ஒதுக்கப்படாது, இடத்தில் நடக்கிறது.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// ஒரு `&[T]` ஐ `Box<[T]>` ஆக மாற்றுகிறது
    ///
    /// இந்த மாற்றம் குவியலில் ஒதுக்குகிறது மற்றும் `slice` இன் நகலை செய்கிறது.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // ஒரு&[u8] ஐ உருவாக்கவும், இது ஒரு பெட்டியை உருவாக்க பயன்படும் <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// ஒரு `&str` ஐ `Box<str>` ஆக மாற்றுகிறது
    ///
    /// இந்த மாற்றம் குவியலில் ஒதுக்குகிறது மற்றும் `s` இன் நகலை செய்கிறது.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// ஒரு `Box<str>` ஐ `Box<[u8]>` ஆக மாற்றுகிறது
    /// இந்த மாற்றம் குவியலில் ஒதுக்கப்படாது, இடத்தில் நடக்கிறது.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // ஒரு பெட்டியை உருவாக்கவும்<str>இது ஒரு பெட்டியை உருவாக்க பயன்படும் <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // ஒரு&[u8] ஐ உருவாக்கவும், இது ஒரு பெட்டியை உருவாக்க பயன்படும் <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// ஒரு `[T; N]` ஐ `Box<[T]>` ஆக மாற்றுகிறது
    /// இந்த மாற்றம் வரிசையை புதிதாக குவியல்-ஒதுக்கப்பட்ட நினைவகத்திற்கு நகர்த்துகிறது.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// பெட்டியை ஒரு கான்கிரீட் வகைக்குக் குறைக்கும் முயற்சி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// பெட்டியை ஒரு கான்கிரீட் வகைக்குக் குறைக்கும் முயற்சி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// பெட்டியை ஒரு கான்கிரீட் வகைக்குக் குறைக்கும் முயற்சி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // பெட்டியிலிருந்து நேரடியாக உள் யூனிக் பிரித்தெடுக்க முடியாது, அதற்கு பதிலாக அதை ஒரு * const க்கு அனுப்புகிறோம், இது தனித்துவத்தை மாற்றியமைக்கிறது
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// இயல்புநிலைக்கு பதிலாக `last()` ஐ `I செயல்படுத்துவதை பயன்படுத்தும் அளவிலான` I` களுக்கான சிறப்பு.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}