//! யுடிஎஃப்-8-குறியிடப்பட்ட, வளரக்கூடிய சரம்.
//!
//! இந்த தொகுதியில் [`String`] வகை, சரங்களுக்கு மாற்றுவதற்கான [`ToString`] trait மற்றும் [`சரம்`] களுடன் வேலை செய்வதால் ஏற்படக்கூடிய பல பிழை வகைகள் உள்ளன.
//!
//!
//! # Examples
//!
//! ஒரு சரம் மொழியிலிருந்து புதிய [`String`] ஐ உருவாக்க பல வழிகள் உள்ளன:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! நீங்கள் ஒன்றிணைப்பதன் மூலம் ஏற்கனவே இருக்கும் ஒன்றிலிருந்து புதிய [`String`] ஐ உருவாக்கலாம்
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! உங்களிடம் செல்லுபடியாகும் UTF-8 பைட்டுகளின் vector இருந்தால், நீங்கள் ஒரு [`String`] ஐ உருவாக்கலாம்.நீங்கள் தலைகீழ் செய்ய முடியும்.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // இந்த பைட்டுகள் செல்லுபடியாகும் என்று எங்களுக்குத் தெரியும், எனவே நாங்கள் `unwrap()` ஐப் பயன்படுத்துவோம்.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// யுடிஎஃப்-8-குறியிடப்பட்ட, வளரக்கூடிய சரம்.
///
/// `String` வகை என்பது மிகவும் பொதுவான சரம் வகையாகும், இது சரத்தின் உள்ளடக்கங்களுக்கு உரிமையைக் கொண்டுள்ளது.இது கடன் வாங்கிய எதிரணியான பழமையான [`str`] உடன் நெருங்கிய உறவைக் கொண்டுள்ளது.
///
/// # Examples
///
/// [`String::from`] உடன் [a literal string][`str`] இலிருந்து `String` ஐ உருவாக்கலாம்:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// நீங்கள் [`push`] முறையுடன் `String` உடன் [`char`] ஐ சேர்க்கலாம், மேலும் [`push_str`] முறையுடன் [`&str`] ஐ சேர்க்கலாம்:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// உங்களிடம் UTF-8 பைட்டுகளின் vector இருந்தால், அதிலிருந்து [`from_utf8`] முறையுடன் `String` ஐ உருவாக்கலாம்:
///
/// ```
/// // சில பைட்டுகள், ஒரு vector இல்
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // இந்த பைட்டுகள் செல்லுபடியாகும் என்று எங்களுக்குத் தெரியும், எனவே நாங்கள் `unwrap()` ஐப் பயன்படுத்துவோம்.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `சரம்` எப்போதும் செல்லுபடியாகும் UTF-8.இது ஒரு சில தாக்கங்களைக் கொண்டுள்ளது, அவற்றில் முதலாவது உங்களுக்கு யுடிஎஃப்-8 அல்லாத சரம் தேவைப்பட்டால், எக்ஸ் 02 எக்ஸ் கருதுங்கள்.இது ஒத்ததாக இருக்கிறது, ஆனால் UTF-8 தடை இல்லாமல்.இரண்டாவது உட்குறிப்பு என்னவென்றால், நீங்கள் ஒரு `String` இல் குறியிட முடியாது:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// அட்டவணைப்படுத்தல் ஒரு நிலையான நேர செயல்பாடாக கருதப்படுகிறது, ஆனால் UTF-8 குறியாக்கம் இதைச் செய்ய எங்களை அனுமதிக்காது.மேலும், குறியீட்டு எந்த வகையான விஷயத்தைத் தர வேண்டும் என்பது தெளிவாகத் தெரியவில்லை: ஒரு பைட், ஒரு குறியீட்டு புள்ளி அல்லது ஒரு கிராஃபீம் கிளஸ்டர்.
/// [`bytes`] மற்றும் [`chars`] முறைகள் முறையே முதல் இரண்டில் ஐரேட்டர்களைத் தருகின்றன.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `சரம்` செயல்படுத்துகிறது [`டெரெஃப்`] `<Target=str>`, எனவே [`str`] இன் அனைத்து முறைகளையும் வாரிசாகப் பெறுங்கள்.கூடுதலாக, இதன் பொருள் நீங்கள் ஒரு ஆம்பர்சண்ட் (`&`) ஐப் பயன்படுத்தி [`&str`] எடுக்கும் ஒரு செயல்பாட்டிற்கு `String` ஐ அனுப்பலாம்:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// இது `String` இலிருந்து ஒரு [`&str`] ஐ உருவாக்கி அதை கடந்து செல்லும். இந்த மாற்றம் மிகவும் மலிவானது, எனவே பொதுவாக, செயல்பாடுகள் சில குறிப்பிட்ட காரணங்களுக்காக ஒரு `String` தேவைப்படாவிட்டால் [`&str`] களை வாதங்களாக ஏற்றுக் கொள்ளும்.
///
/// சில சந்தர்ப்பங்களில், [`Deref`] வற்புறுத்தல் எனப்படும் இந்த மாற்றத்தை உருவாக்க Rust க்கு போதுமான தகவல்கள் இல்லை.பின்வரும் எடுத்துக்காட்டில் ஒரு சரம் துண்டு [`&'a str`][`&str`] trait `TraitExample` ஐ செயல்படுத்துகிறது, மேலும் `example_func` செயல்பாடு trait ஐ செயல்படுத்தும் எதையும் எடுக்கும்.
/// இந்த வழக்கில் Rust இரண்டு மறைமுக மாற்றங்களை செய்ய வேண்டும், இது Rust க்கு செய்ய வழி இல்லை.
/// அந்த காரணத்திற்காக, பின்வரும் எடுத்துக்காட்டு தொகுக்காது.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// அதற்கு பதிலாக இரண்டு விருப்பங்கள் உள்ளன.முதலாவதாக, `example_func(&example_string);` வரியை `example_func(example_string.as_str());` ஆக மாற்றுவது, [`as_str()`] முறையைப் பயன்படுத்தி சரம் கொண்ட சரம் துண்டுகளை வெளிப்படையாக பிரித்தெடுக்க வேண்டும்.
/// இரண்டாவது வழி `example_func(&example_string);` ஐ `example_func(&*example_string);` ஆக மாற்றுகிறது.
/// இந்த வழக்கில் நாம் ஒரு `String` ஐ ஒரு [`str`][`&str`] க்கு குறிப்பிடுகிறோம், பின்னர் [`str`][`&str`] ஐ [`&str`] க்கு மீண்டும் குறிப்பிடுகிறோம்.
/// இரண்டாவது வழி மிகவும் முட்டாள்தனமானது, இருப்பினும் இருவரும் மறைமுகமான மாற்றத்தை நம்புவதை விட வெளிப்படையாக மாற்றத்தை செய்ய வேலை செய்கிறார்கள்.
///
/// # Representation
///
/// ஒரு `String` மூன்று கூறுகளால் ஆனது: சில பைட்டுகளுக்கு ஒரு சுட்டிக்காட்டி, ஒரு நீளம் மற்றும் திறன்.சுட்டிக்காட்டி அதன் தரவைச் சேமிக்க `String` பயன்படுத்தும் உள் இடையகத்தை சுட்டிக்காட்டுகிறது.நீளம் என்பது தற்போது இடையகத்தில் சேமிக்கப்பட்டுள்ள பைட்டுகளின் எண்ணிக்கை, மற்றும் திறன் என்பது பைட்டுகளில் உள்ள இடையகத்தின் அளவு.
///
/// எனவே, நீளம் எப்போதும் திறனை விட குறைவாகவோ அல்லது சமமாகவோ இருக்கும்.
///
/// இந்த இடையக எப்போதும் குவியலில் சேமிக்கப்படுகிறது.
///
/// [`as_ptr`], [`len`] மற்றும் [`capacity`] முறைகள் மூலம் இவற்றைப் பார்க்கலாம்:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME vec_into_raw_parts உறுதிப்படுத்தப்படும்போது இதைப் புதுப்பிக்கவும்.
/// // சரத்தின் தரவை தானாக கைவிடுவதைத் தடுக்கவும்
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // கதையில் பத்தொன்பது பைட்டுகள் உள்ளன
/// assert_eq!(19, len);
///
/// // பி.டி.ஆர், லென் மற்றும் திறன் ஆகியவற்றிலிருந்து ஒரு சரத்தை மீண்டும் உருவாக்க முடியும்.
/// // இவை அனைத்தும் பாதுகாப்பற்றவை, ஏனென்றால் கூறுகள் செல்லுபடியாகும் என்பதை உறுதிசெய்வதற்கு நாங்கள் பொறுப்பு:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// ஒரு `String` க்கு போதுமான திறன் இருந்தால், அதில் கூறுகளைச் சேர்ப்பது மீண்டும் ஒதுக்கப்படாது.எடுத்துக்காட்டாக, இந்த நிரலைக் கவனியுங்கள்:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// இது பின்வருவனவற்றை வெளியிடும்:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// முதலில், எங்களிடம் எந்த நினைவகமும் ஒதுக்கப்படவில்லை, ஆனால் நாம் சரத்துடன் சேர்க்கும்போது, அது அதன் திறனை சரியான முறையில் அதிகரிக்கிறது.ஆரம்பத்தில் சரியான திறனை ஒதுக்க [`with_capacity`] முறையைப் பயன்படுத்தினால்:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// நாங்கள் வேறுபட்ட வெளியீட்டில் முடிவடைகிறோம்:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// இங்கே, வளையத்திற்குள் அதிக நினைவகத்தை ஒதுக்க வேண்டிய அவசியமில்லை.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// UTF-8 பைட் vector இலிருந்து `String` ஐ மாற்றும்போது சாத்தியமான பிழை மதிப்பு.
///
/// இந்த வகை [`String`] இல் [`from_utf8`] முறைக்கான பிழை வகை.
/// மறு ஒதுக்கீடுகளை கவனமாகத் தவிர்ப்பதற்காக இது வடிவமைக்கப்பட்டுள்ளது: [`into_bytes`] முறை மாற்று முயற்சியில் பயன்படுத்தப்பட்ட vector பைட்டை திருப்பித் தரும்.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] வழங்கிய [`Utf8Error`] வகை [`u8`] களின் துண்டுகளை [`&str`] ஆக மாற்றும்போது ஏற்படக்கூடிய பிழையைக் குறிக்கிறது.
/// இந்த அர்த்தத்தில், இது `FromUtf8Error` க்கு ஒரு அனலாக் ஆகும், மேலும் நீங்கள் `FromUtf8Error` இலிருந்து [`utf8_error`] முறை மூலம் ஒன்றைப் பெறலாம்.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// // vector இல் சில தவறான பைட்டுகள்
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 பைட் துண்டுகளிலிருந்து `String` ஐ மாற்றும்போது சாத்தியமான பிழை மதிப்பு.
///
/// இந்த வகை [`String`] இல் [`from_utf16`] முறைக்கான பிழை வகை.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// புதிய வெற்று `String` ஐ உருவாக்குகிறது.
    ///
    /// `String` காலியாக இருப்பதால், இது எந்த ஆரம்ப இடையகத்தையும் ஒதுக்காது.இந்த ஆரம்ப செயல்பாடு மிகவும் மலிவானது என்று அர்த்தம் என்றாலும், நீங்கள் தரவைச் சேர்க்கும்போது அது அதிகப்படியான ஒதுக்கீட்டை ஏற்படுத்தக்கூடும்.
    ///
    /// `String` எவ்வளவு தரவை வைத்திருக்கும் என்பது பற்றி உங்களுக்கு ஒரு யோசனை இருந்தால், அதிகப்படியான மறு ஒதுக்கீட்டைத் தடுக்க [`with_capacity`] முறையைக் கவனியுங்கள்.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// ஒரு குறிப்பிட்ட திறனுடன் புதிய வெற்று `String` ஐ உருவாக்குகிறது.
    ///
    /// `சரம் 'அவர்களின் தரவை வைத்திருக்க உள் இடையகத்தைக் கொண்டுள்ளது.
    /// திறன் என்பது அந்த இடையகத்தின் நீளம், மேலும் [`capacity`] முறை மூலம் வினவலாம்.
    /// இந்த முறை வெற்று `String` ஐ உருவாக்குகிறது, ஆனால் ஆரம்ப இடையகத்துடன் `capacity` பைட்டுகளை வைத்திருக்க முடியும்.
    /// நீங்கள் `String` இல் ஒரு சில தரவைச் சேர்க்கும்போது இது பயனுள்ளதாக இருக்கும், இது செய்ய வேண்டிய மறு ஒதுக்கீடுகளின் எண்ணிக்கையைக் குறைக்கிறது.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// கொடுக்கப்பட்ட திறன் `0` ஆக இருந்தால், எந்த ஒதுக்கீடும் ஏற்படாது, இந்த முறை [`new`] முறைக்கு ஒத்ததாக இருக்கும்.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // சரம் அதிக எழுத்துக்களைக் கொண்டிருக்கவில்லை என்றாலும், அதில் எழுத்துக்கள் இல்லை
    /// assert_eq!(s.len(), 0);
    ///
    /// // இவை அனைத்தும் மறு ஒதுக்கீடு செய்யப்படாமல் செய்யப்படுகின்றன ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ஆனால் இது சரம் மறு ஒதுக்கீடு செய்யக்கூடும்
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) உடன் இந்த முறை வரையறைக்கு தேவைப்படும் உள்ளார்ந்த `[T]::to_vec` முறை கிடைக்கவில்லை.
    // சோதனை நோக்கங்களுக்காக இந்த முறை எங்களுக்குத் தேவையில்லை என்பதால், கூடுதல் தகவலுக்கு slice.rs இல் slice::hack தொகுதியைப் பார்க்கிறேன்.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector பைட்டுகளை `String` ஆக மாற்றுகிறது.
    ///
    /// ஒரு சரம் ([`String`]) பைட்டுகள் ([`u8`]) ஆல் ஆனது, மற்றும் vector பைட்டுகள் ([`Vec<u8>`]) பைட்டுகளால் ஆனது, எனவே இந்த செயல்பாடு இரண்டிற்கும் இடையில் மாறுகிறது.
    /// எல்லா பைட் துண்டுகளும் செல்லுபடியாகாது `சரம்`, எனினும்: `String` க்கு அது செல்லுபடியாகும் UTF-8 என்று தேவைப்படுகிறது.
    /// `from_utf8()` பைட்டுகள் செல்லுபடியாகும் UTF-8 என்பதை உறுதிசெய்கிறது, பின்னர் மாற்றும்.
    ///
    /// பைட் ஸ்லைஸ் செல்லுபடியாகும் UTF-8 என்பது உங்களுக்கு உறுதியாகத் தெரிந்தால், செல்லுபடியாகும் காசோலையின் மேல்நிலைக்கு நீங்கள் வர விரும்பவில்லை என்றால், இந்த செயல்பாட்டின் பாதுகாப்பற்ற பதிப்பு, [`from_utf8_unchecked`] உள்ளது, இது அதே நடத்தை கொண்டது, ஆனால் காசோலையைத் தவிர்க்கிறது.
    ///
    ///
    /// இந்த முறை செயல்திறன் பொருட்டு, vector ஐ நகலெடுக்காமல் பார்த்துக் கொள்ளும்.
    ///
    /// உங்களுக்கு `String` க்கு பதிலாக [`&str`] தேவைப்பட்டால், [`str::from_utf8`] ஐ கருத்தில் கொள்ளுங்கள்.
    ///
    /// இந்த முறையின் தலைகீழ் [`into_bytes`] ஆகும்.
    ///
    /// # Errors
    ///
    /// வழங்கப்பட்ட பைட்டுகள் ஏன் UTF-8 இல்லை என்பதற்கான விளக்கத்துடன் ஸ்லைஸ் UTF-8 ஆக இல்லாவிட்டால் [`Err`] ஐ வழங்குகிறது.நீங்கள் நகர்த்திய vector மேலும் சேர்க்கப்பட்டுள்ளது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// // சில பைட்டுகள், ஒரு vector இல்
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // இந்த பைட்டுகள் செல்லுபடியாகும் என்று எங்களுக்குத் தெரியும், எனவே நாங்கள் `unwrap()` ஐப் பயன்படுத்துவோம்.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// தவறான பைட்டுகள்:
    ///
    /// ```
    /// // vector இல் சில தவறான பைட்டுகள்
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// இந்த பிழையால் நீங்கள் என்ன செய்ய முடியும் என்பது குறித்த கூடுதல் விவரங்களுக்கு [`FromUtf8Error`] க்கான டாக்ஸைப் பார்க்கவும்.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// பைட்டுகளின் ஒரு துண்டை தவறான எழுத்துக்கள் உட்பட ஒரு சரத்திற்கு மாற்றுகிறது.
    ///
    /// சரங்கள் ([`u8`]) பைட்டுகளால் ஆனவை, மற்றும் பைட்டுகள் ([`&[u8]`][byteslice]) ஒரு துண்டு பைட்டுகளால் ஆனது, எனவே இந்த செயல்பாடு இரண்டிற்கும் இடையில் மாறுகிறது.எல்லா பைட் துண்டுகளும் செல்லுபடியாகும் சரங்கள் அல்ல, இருப்பினும்: சரங்கள் செல்லுபடியாகும் UTF-8 ஆக இருக்க வேண்டும்.
    /// இந்த மாற்றத்தின் போது, `from_utf8_lossy()` எந்த தவறான UTF-8 காட்சிகளையும் [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] உடன் மாற்றும், இது இதுபோல் தெரிகிறது:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// பைட் ஸ்லைஸ் செல்லுபடியாகும் UTF-8 என்பது உங்களுக்கு உறுதியாகத் தெரிந்தால், மாற்றத்தின் மேல்நிலைக்கு நீங்கள் வர விரும்பவில்லை என்றால், இந்த செயல்பாட்டின் பாதுகாப்பற்ற பதிப்பு, [`from_utf8_unchecked`] உள்ளது, இது அதே நடத்தை கொண்டது, ஆனால் காசோலைகளைத் தவிர்க்கிறது.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// இந்த செயல்பாடு ஒரு [`Cow<'a, str>`] ஐ வழங்குகிறது.எங்கள் பைட் ஸ்லைஸ் தவறான UTF-8 ஆக இருந்தால், மாற்று எழுத்துக்களை நாம் செருக வேண்டும், இது சரத்தின் அளவை மாற்றிவிடும், எனவே, ஒரு `String` தேவைப்படுகிறது.
    /// ஆனால் இது ஏற்கனவே செல்லுபடியாகும் UTF-8 என்றால், எங்களுக்கு புதிய ஒதுக்கீடு தேவையில்லை.
    /// இந்த வருவாய் வகை இரண்டு நிகழ்வுகளையும் கையாள அனுமதிக்கிறது.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// // சில பைட்டுகள், ஒரு vector இல்
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// தவறான பைட்டுகள்:
    ///
    /// ```
    /// // சில தவறான பைட்டுகள்
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// யுடிஎஃப்-16-குறியிடப்பட்ட vector `v` ஐ ஒரு `String` ஆக டிகோட் செய்து, `v` இல் தவறான தரவு ஏதேனும் இருந்தால் [`Err`] ஐ வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // இது சேகரிப்பு வழியாக செய்யப்படவில்லை: : <Result<_, _>> () செயல்திறன் காரணங்களுக்காக.
        // FIXME: #48994 மூடப்படும் போது செயல்பாட்டை மீண்டும் எளிமைப்படுத்தலாம்.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// UTF-16-குறியிடப்பட்ட ஸ்லைஸ் `v` ஐ `String` ஆக டிகோட் செய்து, தவறான தரவை [the replacement character (`U+FFFD`)][U+FFFD] உடன் மாற்றும்.
    ///
    /// ஒரு [`Cow<'a, str>`] ஐ வழங்கும் [`from_utf8_lossy`] போலல்லாமல், `from_utf16_lossy` ஒரு `String` ஐ வழங்குகிறது, ஏனெனில் UTF-16 முதல் UTF-8 மாற்றத்திற்கு நினைவக ஒதுக்கீடு தேவைப்படுகிறது.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// ஒரு `String` ஐ அதன் மூல கூறுகளாக சிதைக்கிறது.
    ///
    /// மூல சுட்டிக்காட்டி அடிப்படை தரவு, சரத்தின் நீளம் (பைட்டுகளில்) மற்றும் தரவின் ஒதுக்கப்பட்ட திறன் (பைட்டுகளில்) ஆகியவற்றை வழங்குகிறது.
    /// இவை [`from_raw_parts`] க்கான வாதங்களின் அதே வரிசையில் அதே வாதங்கள்.
    ///
    /// இந்த செயல்பாட்டை அழைத்த பிறகு, முன்பு `String` ஆல் நிர்வகிக்கப்பட்ட நினைவகத்திற்கு அழைப்பாளர் பொறுப்பு.
    /// இதைச் செய்வதற்கான ஒரே வழி, மூல சுட்டிக்காட்டி, நீளம் மற்றும் திறனை மீண்டும் `String` ஆக [`from_raw_parts`] செயல்பாட்டுடன் மாற்றுவதே ஆகும், இது அழிப்பான் தூய்மைப்படுத்தலை அனுமதிக்கிறது.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// நீளம், திறன் மற்றும் சுட்டிக்காட்டி ஆகியவற்றிலிருந்து புதிய `String` ஐ உருவாக்குகிறது.
    ///
    /// # Safety
    ///
    /// சரிபார்க்கப்படாத மாற்றங்களின் எண்ணிக்கை காரணமாக இது மிகவும் பாதுகாப்பற்றது:
    ///
    /// * `buf` இல் உள்ள நினைவகம் முன்பு நிலையான நூலகம் பயன்படுத்தும் அதே ஒதுக்கீட்டாளரால் ஒதுக்கப்பட்டிருக்க வேண்டும், தேவையான 1 சீரமைப்புடன்.
    /// * `length` `capacity` ஐ விட குறைவாகவோ அல்லது சமமாகவோ இருக்க வேண்டும்.
    /// * `capacity` சரியான மதிப்பாக இருக்க வேண்டும்.
    /// * `buf` இல் முதல் `length` பைட்டுகள் செல்லுபடியாகும் UTF-8 ஆக இருக்க வேண்டும்.
    ///
    /// இவற்றை மீறுவது ஒதுக்கீட்டாளரின் உள் தரவு கட்டமைப்புகளை சிதைப்பது போன்ற சிக்கல்களை ஏற்படுத்தக்கூடும்.
    ///
    /// `buf` இன் உரிமையானது `String` க்கு திறம்பட மாற்றப்படுகிறது, பின்னர் விருப்பப்படி சுட்டிக்காட்டி சுட்டிக்காட்டிய நினைவகத்தின் உள்ளடக்கங்களை ஒதுக்கி வைக்கலாம், மறு ஒதுக்கீடு செய்யலாம் அல்லது மாற்றலாம்.
    /// இந்த செயல்பாட்டை அழைத்த பிறகு வேறு எதுவும் சுட்டிக்காட்டி பயன்படுத்தவில்லை என்பதை உறுதிப்படுத்தவும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME vec_into_raw_parts உறுதிப்படுத்தப்படும்போது இதைப் புதுப்பிக்கவும்.
    ///     // சரத்தின் தரவை தானாக கைவிடுவதைத் தடுக்கவும்
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// சரம் செல்லுபடியாகும் UTF-8 ஐக் கொண்டிருக்கிறதா என்று சோதிக்காமல் vector பைட்டுகளை `String` ஆக மாற்றுகிறது.
    ///
    /// மேலும் விவரங்களுக்கு, பாதுகாப்பான பதிப்பான [`from_utf8`] ஐப் பார்க்கவும்.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// இந்த செயல்பாடு பாதுகாப்பற்றது, ஏனெனில் அதற்கு அனுப்பப்பட்ட பைட்டுகள் செல்லுபடியாகும் UTF-8 என்பதை சரிபார்க்கவில்லை.
    /// இந்த கட்டுப்பாடு மீறப்பட்டால், இது `String` இன் future பயனர்களுடன் நினைவக பாதுகாப்பற்ற சிக்கல்களை ஏற்படுத்தக்கூடும், ஏனென்றால் நிலையான நூலகத்தின் மீதமுள்ளவை `சரம்` செல்லுபடியாகும் UTF-8 என்று கருதுகின்றன.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// // சில பைட்டுகள், ஒரு vector இல்
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// ஒரு `String` ஐ பைட் vector ஆக மாற்றுகிறது.
    ///
    /// இது `String` ஐப் பயன்படுத்துகிறது, எனவே அதன் உள்ளடக்கங்களை நாங்கள் நகலெடுக்க தேவையில்லை.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// முழு `String` ஐக் கொண்ட ஒரு சரம் துண்டுகளை பிரித்தெடுக்கிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// ஒரு `String` ஐ மாற்றக்கூடிய சரம் துண்டுகளாக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// இந்த `String` இன் முடிவில் கொடுக்கப்பட்ட சரம் துண்டுகளை சேர்க்கிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// இந்த `சரத்தின்` திறனை பைட்டுகளில் வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// இந்த `சரம்` திறன் அதன் நீளத்தை விட குறைந்தது `additional` பைட்டுகள் என்பதை உறுதி செய்கிறது.
    ///
    /// அடிக்கடி மறு ஒதுக்கீடு செய்வதைத் தடுக்க, தேர்வுசெய்தால், திறன் `additional` பைட்டுகளுக்கு மேல் அதிகரிக்கப்படலாம்.
    ///
    ///
    /// இந்த "at least" நடத்தை நீங்கள் விரும்பவில்லை என்றால், [`reserve_exact`] முறையைப் பார்க்கவும்.
    ///
    /// # Panics
    ///
    /// புதிய திறன் [`usize`] ஐ நிரம்பி வழிகிறது என்றால் Panics.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// இது உண்மையில் திறனை அதிகரிக்காது:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // கள் இப்போது 2 நீளம் மற்றும் 10 திறன் கொண்டது
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // எங்களிடம் ஏற்கனவே கூடுதல் 8 திறன் இருப்பதால், இதை அழைக்கிறோம் ...
    /// s.reserve(8);
    ///
    /// // ... உண்மையில் அதிகரிக்காது.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// இந்த `சரம்` திறன் அதன் நீளத்தை விட `additional` பைட்டுகள் பெரியது என்பதை உறுதி செய்கிறது.
    ///
    /// ஒதுக்கீட்டாளரை விட உங்களுக்கு நன்றாகத் தெரியாவிட்டால், [`reserve`] முறையைப் பயன்படுத்துவதைக் கவனியுங்கள்.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// புதிய திறன் `usize` ஐ நிரம்பி வழிகிறது என்றால் Panics.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// இது உண்மையில் திறனை அதிகரிக்காது:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // கள் இப்போது 2 நீளம் மற்றும் 10 திறன் கொண்டது
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // எங்களிடம் ஏற்கனவே கூடுதல் 8 திறன் இருப்பதால், இதை அழைக்கிறோம் ...
    /// s.reserve_exact(8);
    ///
    /// // ... உண்மையில் அதிகரிக்காது.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// கொடுக்கப்பட்ட `String` இல் செருகுவதற்கு குறைந்தபட்சம் `additional` கூடுதல் உறுப்புகளுக்கான திறனை முன்பதிவு செய்ய முயற்சிக்கிறது.
    /// அடிக்கடி மறு ஒதுக்கீடு செய்வதைத் தவிர்ப்பதற்கு சேகரிப்பு அதிக இடத்தை ஒதுக்கக்கூடும்.
    /// `reserve` ஐ அழைத்த பிறகு, திறன் `self.len() + additional` ஐ விட அதிகமாகவோ அல்லது சமமாகவோ இருக்கும்.
    /// திறன் ஏற்கனவே போதுமானதாக இருந்தால் எதுவும் செய்யாது.
    ///
    /// # Errors
    ///
    /// திறன் நிரம்பி வழிகிறது அல்லது ஒதுக்கீட்டாளர் தோல்வியைப் புகாரளித்தால், பிழை திரும்பும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // நினைவகத்தை முன்பதிவு செய்யுங்கள், முடியாவிட்டால் வெளியேறும்
    ///     output.try_reserve(data.len())?;
    ///
    ///     // எங்கள் சிக்கலான வேலைக்கு நடுவில் இது OOM முடியாது என்று இப்போது எங்களுக்குத் தெரியும்
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// கொடுக்கப்பட்ட `String` இல் சரியாக `additional` கூடுதல் கூறுகளைச் செருகுவதற்கான குறைந்தபட்ச திறனை ஒதுக்க முயற்சிக்கிறது.
    ///
    /// `reserve_exact` ஐ அழைத்த பிறகு, திறன் `self.len() + additional` ஐ விட அதிகமாகவோ அல்லது சமமாகவோ இருக்கும்.
    /// திறன் ஏற்கனவே போதுமானதாக இருந்தால் எதுவும் செய்யாது.
    ///
    /// ஒதுக்கீடு செய்பவர் கோருவதை விட அதிக இடத்தை கொடுக்கக்கூடும் என்பதை நினைவில் கொள்க.
    /// எனவே, திறனை துல்லியமாக மிகக் குறைவாக நம்ப முடியாது.
    /// future செருகல்கள் எதிர்பார்க்கப்பட்டால் `reserve` ஐ விரும்புங்கள்.
    ///
    /// # Errors
    ///
    /// திறன் நிரம்பி வழிகிறது அல்லது ஒதுக்கீட்டாளர் தோல்வியைப் புகாரளித்தால், பிழை திரும்பும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // நினைவகத்தை முன்பதிவு செய்யுங்கள், முடியாவிட்டால் வெளியேறும்
    ///     output.try_reserve(data.len())?;
    ///
    ///     // எங்கள் சிக்கலான வேலைக்கு நடுவில் இது OOM முடியாது என்று இப்போது எங்களுக்குத் தெரியும்
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// இந்த `String` இன் நீளத்துடன் பொருந்தக்கூடிய திறனை சுருக்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// இந்த `String` இன் திறனை குறைந்த வரம்புடன் சுருக்கி விடுகிறது.
    ///
    /// திறன் நீளம் மற்றும் வழங்கப்பட்ட மதிப்பு இரண்டையும் விட பெரியதாக இருக்கும்.
    ///
    ///
    /// தற்போதைய திறன் குறைந்த வரம்பை விட குறைவாக இருந்தால், இது ஒரு விருப்பம் இல்லை.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// கொடுக்கப்பட்ட [`char`] ஐ இந்த `String` இன் இறுதியில் சேர்க்கிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// இந்த `சரத்தின்` உள்ளடக்கங்களின் பைட் துண்டுகளை வழங்குகிறது.
    ///
    /// இந்த முறையின் தலைகீழ் [`from_utf8`] ஆகும்.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// இந்த `String` ஐ குறிப்பிட்ட நீளத்திற்கு குறைக்கிறது.
    ///
    /// `new_len` சரத்தின் தற்போதைய நீளத்தை விட அதிகமாக இருந்தால், இது எந்த விளைவையும் ஏற்படுத்தாது.
    ///
    ///
    /// இந்த முறை சரத்தின் ஒதுக்கப்பட்ட திறனில் எந்த விளைவையும் ஏற்படுத்தாது என்பதை நினைவில் கொள்க
    ///
    /// # Panics
    ///
    /// `new_len` ஒரு [`char`] எல்லையில் பொய் சொல்லாவிட்டால் Panics.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// சரம் இடையகத்திலிருந்து கடைசி எழுத்தை அகற்றி அதை வழங்குகிறது.
    ///
    /// இந்த `String` காலியாக இருந்தால் [`None`] ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// இந்த `String` இலிருந்து ஒரு [`char`] ஐ பைட் நிலையில் அகற்றி திருப்பித் தருகிறது.
    ///
    /// இது ஒரு *O*(*n*) செயல்பாடாகும், ஏனெனில் இது இடையகத்தின் ஒவ்வொரு உறுப்புகளையும் நகலெடுக்க வேண்டும்.
    ///
    /// # Panics
    ///
    /// `idx` `சரம்` நீளத்தை விட பெரியதாகவோ அல்லது சமமாகவோ இருந்தால் அல்லது அது [`char`] எல்லையில் பொய் சொல்லாவிட்டால் Panics.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` இல் `pat` வடிவத்தின் அனைத்து பொருத்தங்களையும் அகற்று.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// போட்டிகள் கண்டறியப்பட்டு மீண்டும் மீண்டும் அகற்றப்படும், எனவே வடிவங்கள் ஒன்றுடன் ஒன்று இருக்கும் சந்தர்ப்பங்களில், முதல் முறை மட்டுமே அகற்றப்படும்:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // பாதுகாப்பு: தொடக்கமும் முடிவும் ஒன்றுக்கு utf8 பைட் எல்லைகளில் இருக்கும்
        // தேடுபவர் டாக்ஸ்
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// முன்னறிவிப்பால் குறிப்பிடப்பட்ட எழுத்துக்களை மட்டுமே வைத்திருக்கிறது.
    ///
    /// வேறு வார்த்தைகளில் கூறுவதானால், `c` அனைத்து எழுத்துக்களையும் அகற்றவும், அதாவது `f(c)` `false` ஐ வழங்குகிறது.
    /// இந்த முறை இடத்தில் இயங்குகிறது, ஒவ்வொரு எழுத்தையும் அசல் வரிசையில் ஒரு முறை பார்வையிடுகிறது, மேலும் தக்கவைத்த எழுத்துக்களின் வரிசையை பாதுகாக்கிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// ஒரு குறியீட்டைப் போல வெளிப்புற நிலையைக் கண்காணிக்க சரியான வரிசை பயனுள்ளதாக இருக்கும்.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // அடுத்த கரிக்கு ஐடிஎக்ஸ் புள்ளி
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// இந்த `String` இல் ஒரு எழுத்தை ஒரு பைட் நிலையில் செருகும்.
    ///
    /// இது ஒரு *O*(*n*) செயல்பாடாகும், ஏனெனில் இது இடையகத்தின் ஒவ்வொரு உறுப்புகளையும் நகலெடுக்க வேண்டும்.
    ///
    /// # Panics
    ///
    /// `idx` `சரம்` நீளத்தை விட பெரியதாக இருந்தால் அல்லது அது [`char`] எல்லையில் இல்லை என்றால் Panics.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// இந்த `String` இல் ஒரு சரம் துண்டுகளை ஒரு பைட் நிலையில் செருகும்.
    ///
    /// இது ஒரு *O*(*n*) செயல்பாடாகும், ஏனெனில் இது இடையகத்தின் ஒவ்வொரு உறுப்புகளையும் நகலெடுக்க வேண்டும்.
    ///
    /// # Panics
    ///
    /// `idx` `சரம்` நீளத்தை விட பெரியதாக இருந்தால் அல்லது அது [`char`] எல்லையில் இல்லை என்றால் Panics.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// இந்த `String` இன் உள்ளடக்கங்களுக்கு மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// # Safety
    ///
    /// இந்த செயல்பாடு பாதுகாப்பற்றது, ஏனெனில் அதற்கு அனுப்பப்பட்ட பைட்டுகள் செல்லுபடியாகும் UTF-8 என்பதை சரிபார்க்கவில்லை.
    /// இந்த கட்டுப்பாடு மீறப்பட்டால், இது `String` இன் future பயனர்களுடன் நினைவக பாதுகாப்பற்ற சிக்கல்களை ஏற்படுத்தக்கூடும், ஏனென்றால் நிலையான நூலகத்தின் மீதமுள்ளவை `சரம்` செல்லுபடியாகும் UTF-8 என்று கருதுகின்றன.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// இந்த `String` இன் நீளத்தை பைட்டுகளில் தருகிறது, [`char`] கள் அல்லது கிராபீம்கள் அல்ல.
    /// வேறு வார்த்தைகளில் கூறுவதானால், சரத்தின் நீளத்தை ஒரு மனிதன் கருதுவது இதுவல்ல.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// இந்த `String` பூஜ்ஜியத்தின் நீளத்தைக் கொண்டிருந்தால் `true` ஐ வழங்குகிறது, இல்லையெனில் `false` ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// கொடுக்கப்பட்ட பைட் குறியீட்டில் சரத்தை இரண்டாகப் பிரிக்கிறது.
    ///
    /// புதிதாக ஒதுக்கப்பட்ட `String` ஐ வழங்குகிறது.
    /// `self` `[0, at)` பைட்டுகள் உள்ளன, மற்றும் திரும்பிய `String` பைட்டுகள் `[at, len)` ஐக் கொண்டுள்ளது.
    /// `at` ஒரு UTF-8 குறியீடு புள்ளியின் எல்லையில் இருக்க வேண்டும்.
    ///
    /// `self` இன் திறன் மாறாது என்பதை நினைவில் கொள்க.
    ///
    /// # Panics
    ///
    /// `at` ஒரு `UTF-8` குறியீடு புள்ளி எல்லையில் இல்லாவிட்டால் அல்லது அது சரத்தின் கடைசி குறியீடு புள்ளிக்கு அப்பால் இருந்தால் Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// இந்த `String` ஐக் குறைத்து, எல்லா உள்ளடக்கங்களையும் நீக்குகிறது.
    ///
    /// இதன் பொருள் `String` பூஜ்ஜியத்தின் நீளத்தைக் கொண்டிருக்கும், அது அதன் திறனைத் தொடாது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String` இல் குறிப்பிட்ட வரம்பை அகற்றி, அகற்றப்பட்ட `chars` ஐ வழங்கும் வடிகட்டிய ஈரேட்டரை உருவாக்குகிறது.
    ///
    ///
    /// Note: ஈரேட்டர் இறுதி வரை நுகரப்படாவிட்டாலும் உறுப்பு வரம்பு அகற்றப்படும்.
    ///
    /// # Panics
    ///
    /// தொடக்க புள்ளி அல்லது இறுதிப் புள்ளி ஒரு [`char`] எல்லையில் இல்லை என்றால், அல்லது அவை எல்லைக்கு அப்பாற்பட்டால் Panics.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // சரத்திலிருந்து β வரை வரம்பை அகற்று
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // ஒரு முழு வீச்சு சரத்தை அழிக்கிறது
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // நினைவக பாதுகாப்பு
        //
        // Drain இன் சரம் பதிப்பில் vector பதிப்பின் நினைவக பாதுகாப்பு சிக்கல்கள் இல்லை.
        // தரவு வெறும் பைட்டுகள் மட்டுமே.
        // வரம்பை அகற்றுதல் டிராப்பில் நடப்பதால், Drain ஐரேட்டர் கசிந்தால், அகற்றுதல் நடக்காது.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // ஒரே நேரத்தில் இரண்டு கடன்களை எடுத்துக் கொள்ளுங்கள்.
        // டிராப்பில், மறு செய்கை முடியும் வரை &mut சரம் அணுகப்படாது.
        let self_ptr = self as *mut _;
        // பாதுகாப்பு: `slice::range` மற்றும் `is_char_boundary` ஆகியவை பொருத்தமான எல்லை சோதனைகளை செய்கின்றன.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// சரத்தில் குறிப்பிட்ட வரம்பை நீக்கி, கொடுக்கப்பட்ட சரத்துடன் அதை மாற்றுகிறது.
    /// கொடுக்கப்பட்ட சரம் வரம்பின் அதே நீளமாக இருக்க தேவையில்லை.
    ///
    /// # Panics
    ///
    /// தொடக்க புள்ளி அல்லது இறுதிப் புள்ளி ஒரு [`char`] எல்லையில் இல்லை என்றால், அல்லது அவை எல்லைக்கு அப்பாற்பட்டால் Panics.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // சரத்திலிருந்து β வரை வரம்பை மாற்றவும்
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // நினைவக பாதுகாப்பு
        //
        // Replace_range இல் vector Splice இன் நினைவக பாதுகாப்பு சிக்கல்கள் இல்லை.
        // vector பதிப்பின்.தரவு வெறும் பைட்டுகள் மட்டுமே.

        // எச்சரிக்கை: இந்த மாறியை இன்லைன் செய்வது தவறான (#81138) ஆக இருக்கும்
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // எச்சரிக்கை: இந்த மாறியை இன்லைன் செய்வது தவறான (#81138) ஆக இருக்கும்
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` ஐ மீண்டும் பயன்படுத்துவது (#81138) ஆனது `range` ஆல் அறிவிக்கப்பட்ட வரம்புகள் அப்படியே இருக்கும் என்று நாங்கள் கருதுகிறோம், ஆனால் அழைப்புகளுக்கு இடையில் ஒரு எதிர்மறையான செயலாக்கம் மாறக்கூடும்
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// இந்த `String` ஐ [`பெட்டி`]`<`[`str`] `>` ஆக மாற்றுகிறது.
    ///
    /// இது அதிகப்படியான திறனைக் குறைக்கும்.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// `String` க்கு மாற்ற முயற்சித்த [`u8`] பைட்டுகளின் ஒரு பகுதியை வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// // vector இல் சில தவறான பைட்டுகள்
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` ஆக மாற்ற முயற்சித்த பைட்டுகளை வழங்குகிறது.
    ///
    /// ஒதுக்கீட்டைத் தவிர்க்க இந்த முறை கவனமாக கட்டப்பட்டுள்ளது.
    /// இது பிழையை நுகரும், பைட்டுகளை நகர்த்தும், இதனால் பைட்டுகளின் நகலை உருவாக்க தேவையில்லை.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// // vector இல் சில தவறான பைட்டுகள்
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// மாற்று தோல்வி குறித்த கூடுதல் விவரங்களைப் பெற `Utf8Error` ஐப் பெறுக.
    ///
    /// [`std::str`] வழங்கிய [`Utf8Error`] வகை [`u8`] களின் துண்டுகளை [`&str`] ஆக மாற்றும்போது ஏற்படக்கூடிய பிழையைக் குறிக்கிறது.
    /// இந்த அர்த்தத்தில், இது `FromUtf8Error` க்கு ஒரு அனலாக்.
    /// அதைப் பயன்படுத்துவது பற்றிய கூடுதல் விவரங்களுக்கு அதன் ஆவணங்களைப் பார்க்கவும்.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// // vector இல் சில தவறான பைட்டுகள்
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // முதல் பைட் இங்கே தவறானது
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // நாங்கள் `சரம் 'மீது மீண்டும் செயல்படுவதால், மறுசெயலாளரிடமிருந்து முதல் சரத்தைப் பெற்று, அடுத்தடுத்த அனைத்து சரங்களையும் சேர்ப்பதன் மூலம் குறைந்தது ஒரு ஒதுக்கீட்டையாவது தவிர்க்கலாம்.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // நாங்கள் CoW களில் மீண்டும் செயல்படுவதால், முதல் உருப்படியைப் பெறுவதன் மூலமும், அடுத்தடுத்த அனைத்து பொருட்களையும் சேர்ப்பதன் மூலமும் (potentially) குறைந்தது ஒரு ஒதுக்கீட்டையாவது தவிர்க்கலாம்.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` க்கான impl க்கு பிரதிநிதித்துவப்படுத்தும் ஒரு வசதி impl.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// வெற்று `String` ஐ உருவாக்குகிறது.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// இரண்டு சரங்களை ஒன்றிணைக்க `+` ஆபரேட்டரை செயல்படுத்துகிறது.
///
/// இது இடது புறத்தில் உள்ள `String` ஐப் பயன்படுத்துகிறது மற்றும் அதன் இடையகத்தை மீண்டும் பயன்படுத்துகிறது (தேவைப்பட்டால் அதை வளர்ப்பது).
/// ஒரு புதிய `String` ஐ ஒதுக்குவதையும், ஒவ்வொரு செயல்பாட்டிலும் முழு உள்ளடக்கங்களையும் நகலெடுப்பதையும் தவிர்ப்பதற்காக இது செய்யப்படுகிறது, இது *O*(*n*^ 2) இயங்கும் நேரத்திற்கு வழிவகுக்கும், இது *n*-பைட் சரத்தை மீண்டும் மீண்டும் இணைப்பதன் மூலம் உருவாக்கும்.
///
///
/// வலது புறத்தில் உள்ள சரம் கடன் வாங்கப்படுகிறது;அதன் உள்ளடக்கங்கள் திரும்பிய `String` இல் நகலெடுக்கப்படுகின்றன.
///
/// # Examples
///
/// இரண்டு `சரங்களை` இணைப்பது முதல் மதிப்பை எடுத்து இரண்டாவது கடன் வாங்குகிறது:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` நகர்த்தப்பட்டது, இனி இங்கு பயன்படுத்த முடியாது.
/// ```
///
/// நீங்கள் முதல் `String` ஐப் பயன்படுத்த விரும்பினால், நீங்கள் அதை குளோன் செய்து அதற்கு பதிலாக குளோனுடன் சேர்க்கலாம்:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` இன்னும் இங்கே செல்லுபடியாகும்.
/// ```
///
/// முதல் `String` ஆக மாற்றுவதன் மூலம் `&str` துண்டுகளை ஒன்றிணைக்கலாம்:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` உடன் சேர்ப்பதற்கான `+=` ஆபரேட்டரை செயல்படுத்துகிறது.
///
/// இது [`push_str`][String::push_str] முறையைப் போலவே இருக்கும்.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] க்கான ஒரு மாற்று மாற்று.
///
/// இந்த மாற்றுப்பெயர் பின்னோக்கி பொருந்தக்கூடிய தன்மைக்கு உள்ளது, மேலும் இறுதியில் அது நீக்கப்படலாம்.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// ஒரு மதிப்பை `String` ஆக மாற்றுவதற்கான trait.
///
/// இந்த trait தானாகவே [`Display`] trait ஐ செயல்படுத்தும் எந்த வகையிலும் செயல்படுத்தப்படுகிறது.
/// எனவே, `ToString` நேரடியாக செயல்படுத்தப்படக்கூடாது:
/// [`Display`] அதற்கு பதிலாக செயல்படுத்தப்பட வேண்டும், மேலும் நீங்கள் `ToString` செயல்படுத்தலை இலவசமாகப் பெறுவீர்கள்.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// கொடுக்கப்பட்ட மதிப்பை `String` ஆக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// இந்த செயல்பாட்டில், `Display` செயல்படுத்தல் பிழையை அளித்தால் `to_string` முறை panics.
/// `fmt::Write for String` ஒருபோதும் பிழையைத் தராது என்பதால் இது தவறான `Display` செயல்படுத்தலைக் குறிக்கிறது.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // பொதுவான செயல்பாடுகளை இன்லைன் செய்யக்கூடாது என்பது ஒரு பொதுவான வழிகாட்டுதலாகும்.
    // இருப்பினும், இந்த முறையிலிருந்து `#[inline]` ஐ அகற்றுவது புறக்கணிக்க முடியாத பின்னடைவுகளை ஏற்படுத்துகிறது.
    // அதை அகற்ற முயற்சிக்கும் கடைசி முயற்சியான <https://github.com/rust-lang/rust/pull/74852> ஐப் பார்க்கவும்.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// ஒரு `&mut str` ஐ `String` ஆக மாற்றுகிறது.
    ///
    /// இதன் விளைவாக குவியலில் ஒதுக்கப்படுகிறது.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: சோதனை libstd இல் இழுக்கிறது, இது இங்கே பிழைகளை ஏற்படுத்துகிறது
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// கொடுக்கப்பட்ட பெட்டி `str` ஸ்லைஸை `String` ஆக மாற்றுகிறது.
    /// `str` ஸ்லைஸ் சொந்தமானது என்பது குறிப்பிடத்தக்கது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// கொடுக்கப்பட்ட `String` ஐ சொந்தமான ஒரு பெட்டி `str` துண்டுக்கு மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// ஒரு சரம் துண்டுகளை கடன் வாங்கிய மாறுபாடாக மாற்றுகிறது.
    /// குவியல் ஒதுக்கீடு எதுவும் செய்யப்படவில்லை, மற்றும் சரம் நகலெடுக்கப்படவில்லை.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// ஒரு சரத்தை சொந்தமான மாறுபாடாக மாற்றுகிறது.
    /// குவியல் ஒதுக்கீடு எதுவும் செய்யப்படவில்லை, மற்றும் சரம் நகலெடுக்கப்படவில்லை.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// ஒரு சரம் குறிப்பை கடன் வாங்கிய மாறுபாடாக மாற்றுகிறது.
    /// குவியல் ஒதுக்கீடு எதுவும் செய்யப்படவில்லை, மற்றும் சரம் நகலெடுக்கப்படவில்லை.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// கொடுக்கப்பட்ட `String` ஐ vector `Vec` ஆக மாற்றுகிறது, இது `u8` வகை மதிப்புகளைக் கொண்டுள்ளது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` க்கான வடிகட்டும் செயலி.
///
/// இந்த கட்டமைப்பு [`String`] இல் [`drain`] முறையால் உருவாக்கப்பட்டது.
/// மேலும் அதன் ஆவணங்களைக் காண்க.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// டிஸ்ட்ரக்டரில்&'ஒரு மட் சரமாக பயன்படுத்தப்படும்
    string: *mut String,
    /// அகற்ற பகுதியின் தொடக்கம்
    start: usize,
    /// அகற்ற வேண்டிய பகுதியின் முடிவு
    end: usize,
    /// அகற்ற தற்போதைய வரம்பு
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain ஐப் பயன்படுத்தவும்.
            // "Reaffirm" panic குறியீடு மீண்டும் செருகப்படுவதைத் தவிர்க்க எல்லைகள் சரிபார்க்கின்றன.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// இந்த ஈரேட்டரின் மீதமுள்ள (துணை) சரத்தை ஒரு துண்டாக வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: உறுதியற்ற போது AsRef கீழே தூண்டுகிறது.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` ஐ உறுதிப்படுத்தும் போது அச om கரியம்.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain <'a> {fn as_ref(&self)-> &str for க்கு
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// Drain <'a> {fn as_ref(&self)->&[u8] for க்கான impl <' a> AsRef <[u8]>
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}