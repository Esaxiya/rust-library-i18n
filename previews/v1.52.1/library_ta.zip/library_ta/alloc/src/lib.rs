//! # Rust மைய ஒதுக்கீடு மற்றும் வசூல் நூலகம்
//!
//! இந்த நூலகம் குவியல்-ஒதுக்கப்பட்ட மதிப்புகளை நிர்வகிப்பதற்கான ஸ்மார்ட் சுட்டிகள் மற்றும் சேகரிப்புகளை வழங்குகிறது.
//!
//! இந்த நூலகம், லிப்கோர் போன்றது, பொதுவாக அதன் உள்ளடக்கங்கள் [`std` crate](../std/index.html) இல் மீண்டும் ஏற்றுமதி செய்யப்படுவதால் நேரடியாகப் பயன்படுத்தத் தேவையில்லை.
//! `#![no_std]` பண்புகளைப் பயன்படுத்தும் Crates பொதுவாக `std` ஐ சார்ந்து இருக்காது, எனவே அவர்கள் அதற்கு பதிலாக இந்த crate ஐப் பயன்படுத்துவார்கள்.
//!
//! ## பெட்டி மதிப்புகள்
//!
//! [`Box`] வகை ஸ்மார்ட் சுட்டிக்காட்டி வகை.ஒரு [`Box`] இன் ஒரு உரிமையாளர் மட்டுமே இருக்க முடியும், மேலும் உரிமையாளர் உள்ளடக்கங்களை மாற்றியமைக்க முடிவு செய்யலாம், அவை குவியலில் வாழ்கின்றன.
//!
//! ஒரு `Box` மதிப்பின் அளவு ஒரு சுட்டிக்காட்டிக்கு சமமாக இருப்பதால் இந்த வகையை நூல்களிடையே திறமையாக அனுப்ப முடியும்.
//! மரம் போன்ற தரவு கட்டமைப்புகள் பெரும்பாலும் பெட்டிகளுடன் கட்டமைக்கப்படுகின்றன, ஏனெனில் ஒவ்வொரு கணுக்கும் பெரும்பாலும் ஒரே ஒரு உரிமையாளர் மட்டுமே பெற்றோர்.
//!
//! ## குறிப்பு எண்ணப்பட்ட சுட்டிகள்
//!
//! [`Rc`] வகை என்பது ஒரு நூலுக்குள் நினைவகத்தைப் பகிர்வதற்கு நோக்கம் கொண்ட ஒரு நூல் அல்லாத பாதுகாப்பான குறிப்பு-கணக்கிடப்பட்ட சுட்டிக்காட்டி வகை.
//! ஒரு [`Rc`] சுட்டிக்காட்டி ஒரு வகை, `T` ஐ மூடுகிறது, மேலும் பகிரப்பட்ட குறிப்பு `&T` ஐ மட்டுமே அணுக அனுமதிக்கிறது.
//!
//! பரம்பரை மாற்றத்தை ([`Box`] ஐப் பயன்படுத்துவது போன்றவை) ஒரு பயன்பாட்டிற்கு மிகவும் கட்டுப்படுத்தும்போது இந்த வகை பயனுள்ளதாக இருக்கும், மேலும் பிறழ்வை அனுமதிக்க பெரும்பாலும் [`Cell`] அல்லது [`RefCell`] வகைகளுடன் இணைக்கப்படுகிறது.
//!
//!
//! ## அணுக்கரு குறிப்பு எண்ணப்பட்ட சுட்டிகள்
//!
//! [`Arc`] வகை என்பது [`Rc`] வகைக்கு சமமான த்ரெட் சேஃப் ஆகும்.இது [`Rc`] இன் ஒரே மாதிரியான செயல்பாட்டை வழங்குகிறது, தவிர, இதில் உள்ள வகை `T` பகிரக்கூடியது.
//! கூடுதலாக, [`Rc<T>`][`Rc`] இல்லாதபோது [`Arc<T>`][`Arc`] தானே அனுப்பக்கூடியது.
//!
//! இந்த வகை கொண்ட தரவுகளுக்கு பகிரப்பட்ட அணுகலை அனுமதிக்கிறது, மேலும் பகிரப்பட்ட வளங்களின் பிறழ்வை அனுமதிக்க மியூடெக்ஸ் போன்ற ஒத்திசைவு ஆதிமூலங்களுடன் பெரும்பாலும் இணைக்கப்படுகிறது.
//!
//! ## Collections
//!
//! இந்த நூலகத்தில் மிகவும் பொதுவான பொது நோக்க தரவு கட்டமைப்புகளின் செயல்பாடுகள் வரையறுக்கப்பட்டுள்ளன.அவை [standard collections library](../std/collections/index.html) மூலம் மீண்டும் ஏற்றுமதி செய்யப்படுகின்றன.
//!
//! ## குவியல் இடைமுகங்கள்
//!
//! [`alloc`](alloc/index.html) தொகுதி இயல்புநிலை உலகளாவிய ஒதுக்கீட்டாளருக்கு குறைந்த-நிலை இடைமுகத்தை வரையறுக்கிறது.இது libc ஒதுக்கீடு API உடன் பொருந்தாது.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// தொழில்நுட்ப ரீதியாக, இது ரஸ்ட்டோக்கில் ஒரு பிழை: ரஸ்ட்டாக் `#[lang = slice_alloc]` தொகுதிகளில் உள்ள ஆவணங்களை `&[T]` க்காகக் காண்கிறது, இது `core` இல் இந்த அம்சத்தைப் பயன்படுத்தி ஆவணங்களைக் கொண்டுள்ளது, மேலும் அம்ச-கேட் இயக்கப்படவில்லை என்று பைத்தியம் அடைகிறது.
// வெறுமனே, இது மற்ற crates இலிருந்து டாக்ஸிற்கான அம்ச வாயிலை சரிபார்க்காது, ஆனால் இது லாங் உருப்படிகளுக்கு மட்டுமே தோன்றும் என்பதால், அதை சரிசெய்வது மதிப்புக்குரியதாகத் தெரியவில்லை.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// இந்த நூலகத்தை சோதிக்க அனுமதிக்கவும்

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// பிற தொகுதிகள் பயன்படுத்தும் உள் மேக்ரோக்களுடன் கூடிய தொகுதி (பிற தொகுதிகளுக்கு முன் சேர்க்கப்பட வேண்டும்).
#[macro_use]
mod macros;

// குறைந்த அளவிலான ஒதுக்கீட்டு உத்திகளுக்கு குவியல்கள் வழங்கப்படுகின்றன

pub mod alloc;

// மேலே உள்ள குவியல்களைப் பயன்படுத்தி பழமையான வகைகள்

// சோதனை cfg இல் கட்டமைக்கும்போது லாங்-உருப்படிகளை நகலெடுப்பதைத் தவிர்ப்பதற்கு `boxed.rs` இலிருந்து மோட்டை நிபந்தனையுடன் வரையறுக்க வேண்டும்;ஆனால் குறியீட்டை `use boxed::Box;` அறிவிப்புகளைக் கொண்டிருக்க அனுமதிக்க வேண்டும்.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}