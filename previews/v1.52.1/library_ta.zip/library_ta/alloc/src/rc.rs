//! ஒற்றை-திரிக்கப்பட்ட குறிப்பு-எண்ணும் சுட்டிகள்.'Rc' என்பது 'குறிப்பு
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] வகை `T` வகை மதிப்பின் பகிரப்பட்ட உரிமையை வழங்குகிறது, இது குவியலில் ஒதுக்கப்பட்டுள்ளது.
//! [`Rc`] இல் [`clone`][clone] ஐத் தொடங்குவது குவியலில் அதே ஒதுக்கீட்டிற்கு ஒரு புதிய சுட்டிக்காட்டி உருவாக்குகிறது.
//! கொடுக்கப்பட்ட ஒதுக்கீட்டிற்கான கடைசி [`Rc`] சுட்டிக்காட்டி அழிக்கப்படும் போது, அந்த ஒதுக்கீட்டில் சேமிக்கப்பட்ட மதிப்பும் (பெரும்பாலும் "inner value" என குறிப்பிடப்படுகிறது) கைவிடப்படும்.
//!
//! Rust இல் பகிரப்பட்ட குறிப்புகள் இயல்புநிலையாக பிறழ்வை அனுமதிக்காது, மற்றும் [`Rc`] விதிவிலக்கல்ல: நீங்கள் பொதுவாக ஒரு [`Rc`] க்குள் ஏதேனும் ஒரு மாற்றக்கூடிய குறிப்பைப் பெற முடியாது.
//! உங்களுக்கு பிறழ்வு தேவைப்பட்டால், [`Rc`] க்குள் [`Cell`] அல்லது [`RefCell`] ஐ வைக்கவும்;[an example of mutability inside an `Rc`][mutability] ஐப் பார்க்கவும்.
//!
//! [`Rc`] அணு அல்லாத குறிப்பு எண்ணிக்கையைப் பயன்படுத்துகிறது.
//! இதன் பொருள் மேல்நிலை மிகவும் குறைவாக உள்ளது, ஆனால் நூல்களுக்கு இடையில் ஒரு [`Rc`] ஐ அனுப்ப முடியாது, இதன் விளைவாக [`Rc`] [`Send`][send] ஐ செயல்படுத்தாது.
//! இதன் விளைவாக, Rust கம்பைலர் நீங்கள் தொகுக்கும் நேரத்தில் *சரிபார்க்கும்* நீங்கள் நூல்களுக்கு இடையில் [`Rc`] ஐ அனுப்பவில்லை.
//! உங்களுக்கு பல-திரிக்கப்பட்ட, அணு குறிப்பு எண்ணுதல் தேவைப்பட்டால், [`sync::Arc`][arc] ஐப் பயன்படுத்தவும்.
//!
//! சொந்தமில்லாத [`Weak`] சுட்டிக்காட்டி உருவாக்க [`downgrade`][downgrade] முறையைப் பயன்படுத்தலாம்.
//! ஒரு [`Weak`] சுட்டிக்காட்டி ஒரு [`Rc`] க்கு [`மேம்படுத்தல்`][மேம்படுத்தல்] ஆக இருக்கலாம், ஆனால் ஒதுக்கீட்டில் சேமிக்கப்பட்ட மதிப்பு ஏற்கனவே கைவிடப்பட்டிருந்தால் இது [`None`] ஐ வழங்கும்.
//! வேறு வார்த்தைகளில் கூறுவதானால், `Weak` சுட்டிகள் ஒதுக்கீட்டின் உள்ளே மதிப்பை உயிருடன் வைத்திருக்காது;இருப்பினும், அவை ஒதுக்கீட்டை (உள் மதிப்பிற்கான ஆதரவுக் கடை) உயிருடன் வைத்திருக்கின்றன.
//!
//! [`Rc`] சுட்டிகள் இடையே ஒரு சுழற்சி ஒருபோதும் ஒதுக்கப்படாது.
//! இந்த காரணத்திற்காக, சுழற்சிகளை உடைக்க [`Weak`] பயன்படுத்தப்படுகிறது.
//! எடுத்துக்காட்டாக, ஒரு மரத்தில் பெற்றோர் முனைகளிலிருந்து குழந்தைகளுக்கு வலுவான [`Rc`] சுட்டிகள் இருக்கக்கூடும், மேலும் குழந்தைகளிடமிருந்து [`Weak`] சுட்டிகள் பெற்றோரிடமிருந்து திரும்பலாம்.
//!
//! `Rc<T>` `T` ([`Deref`] trait வழியாக) தானாகவே குறைகிறது, எனவே நீங்கள் [`Rc<T>`][`Rc`] வகை மதிப்பில் `T` இன் முறைகளை அழைக்கலாம்.
//! `T` இன் முறைகளுடன் பெயர் மோதல்களைத் தவிர்க்க, [`Rc<T>`][`Rc`] இன் முறைகள் தொடர்புடைய செயல்பாடுகளாகும், அவை [fully qualified syntax] ஐப் பயன்படுத்துகின்றன:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `ஆர்.சி.<T>`Clone` போன்ற traits இன் செயலாக்கங்களும் முழு தகுதி வாய்ந்த தொடரியல் பயன்படுத்தி அழைக்கப்படலாம்.
//! சிலர் முழு தகுதி வாய்ந்த தொடரியல் பயன்படுத்த விரும்புகிறார்கள், மற்றவர்கள் முறை-அழைப்பு தொடரியல் பயன்படுத்த விரும்புகிறார்கள்.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // முறை-அழைப்பு தொடரியல்
//! let rc2 = rc.clone();
//! // முழு தகுதி வாய்ந்த தொடரியல்
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` க்கு தானாக விலகல் இல்லை, ஏனெனில் உள் மதிப்பு ஏற்கனவே கைவிடப்பட்டிருக்கலாம்.
//!
//! # குளோனிங் குறிப்புகள்
//!
//! ஏற்கனவே உள்ள குறிப்பு கணக்கிடப்பட்ட சுட்டிக்காட்டி அதே ஒதுக்கீட்டில் ஒரு புதிய குறிப்பை உருவாக்குவது [`Rc<T>`][`Rc`] மற்றும் [`Weak<T>`][`Weak`] க்கு செயல்படுத்தப்பட்ட `Clone` trait ஐப் பயன்படுத்தி செய்யப்படுகிறது.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // கீழே உள்ள இரண்டு தொடரியல் சமம்.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a மற்றும் b இரண்டும் foo போன்ற ஒரே நினைவக இருப்பிடத்தை சுட்டிக்காட்டுகின்றன.
//! ```
//!
//! `Rc::clone(&from)` தொடரியல் மிகவும் முட்டாள்தனமானது, ஏனெனில் இது குறியீட்டின் அர்த்தத்தை மிகவும் வெளிப்படையாக தெரிவிக்கிறது.
//! மேலே உள்ள எடுத்துக்காட்டில், இந்த தொடரியல் foo இன் முழு உள்ளடக்கத்தையும் நகலெடுப்பதை விட புதிய குறிப்பை உருவாக்குகிறது என்பதைக் காண்பதை எளிதாக்குகிறது.
//!
//! # Examples
//!
//! கொடுக்கப்பட்ட `Owner` க்கு `கேஜெட்டின் தொகுப்பு சொந்தமான ஒரு காட்சியைக் கவனியுங்கள்.
//! எங்கள் `கேஜெட்டின் புள்ளியை அவற்றின் `Owner` க்கு வைத்திருக்க விரும்புகிறோம்.தனித்துவமான உரிமையுடன் இதை நாங்கள் செய்ய முடியாது, ஏனென்றால் ஒன்றுக்கு மேற்பட்ட கேஜெட்டுகள் ஒரே `Owner` க்கு சொந்தமானவை.
//! [`Rc`] பல `கேஜெட்களுக்கு இடையில் ஒரு `Owner` ஐப் பகிர்ந்து கொள்ள எங்களை அனுமதிக்கிறது, மேலும் `Owner` எந்த `Gadget` புள்ளிகளும் இருக்கும் வரை ஒதுக்கப்பட வேண்டும்.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... பிற துறைகள்
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... பிற துறைகள்
//! }
//!
//! fn main() {
//!     // குறிப்பு-எண்ணப்பட்ட `Owner` ஐ உருவாக்கவும்.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` க்கு சொந்தமான `கேஜெட்டை` உருவாக்கவும்.
//!     // `Rc<Owner>` ஐ குளோனிங் செய்வது அதே `Owner` ஒதுக்கீட்டிற்கு ஒரு புதிய சுட்டிக்காட்டி அளிக்கிறது, இது செயல்பாட்டில் குறிப்பு எண்ணிக்கையை அதிகரிக்கும்.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // எங்கள் உள்ளூர் மாறி `gadget_owner` ஐ அப்புறப்படுத்துங்கள்.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` ஐ கைவிட்ட போதிலும், `கேஜெட்டின் `Owner` இன் பெயரை இன்னும் அச்சிட முடிகிறது.
//!     // ஏனென்றால், நாங்கள் சுட்டிக்காட்டும் `Owner` அல்ல, ஒரு `Rc<Owner>` ஐ மட்டுமே கைவிட்டோம்.
//!     // அதே `Owner` ஒதுக்கீட்டில் மற்ற `Rc<Owner>` சுட்டிக்காட்டும் வரை, அது நேரலையில் இருக்கும்.
//!     // புலம் திட்டம் `gadget1.owner.name` இயங்குகிறது, ஏனெனில் `Rc<Owner>` தானாகவே `Owner` ஐக் குறிக்கிறது.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // செயல்பாட்டின் முடிவில், `gadget1` மற்றும் `gadget2` ஆகியவை அழிக்கப்படுகின்றன, அவற்றுடன் எங்கள் `Owner` க்கு கடைசியாக எண்ணப்பட்ட குறிப்புகள் உள்ளன.
//!     // கேஜெட் மேன் இப்போது அழிக்கப்படுகிறது.
//!     //
//! }
//! ```
//!
//! எங்கள் தேவைகள் மாறினால், நாங்கள் `Owner` இலிருந்து `Gadget` வரை பயணிக்க முடியும் என்றால், நாங்கள் சிக்கல்களில் சிக்குவோம்.
//! `Owner` முதல் `Gadget` வரையிலான [`Rc`] சுட்டிக்காட்டி ஒரு சுழற்சியை அறிமுகப்படுத்துகிறது.
//! இதன் பொருள் அவற்றின் குறிப்பு எண்ணிக்கைகள் ஒருபோதும் 0 ஐ அடைய முடியாது, மற்றும் ஒதுக்கீடு ஒருபோதும் அழிக்கப்படாது:
//! நினைவக கசிவு.இதைச் சுற்றிப் பார்க்க, நாம் [`Weak`] சுட்டிகள் பயன்படுத்தலாம்.
//!
//! Rust உண்மையில் இந்த வளையத்தை முதலில் உருவாக்குவது சற்று கடினமாக்குகிறது.ஒருவருக்கொருவர் சுட்டிக்காட்டும் இரண்டு மதிப்புகளுடன் முடிவடைய, அவற்றில் ஒன்று மாறக்கூடியதாக இருக்க வேண்டும்.
//! இது கடினம், ஏனெனில் [`Rc`] நினைவக பாதுகாப்பை அது போர்த்திய மதிப்புக்கு பகிரப்பட்ட குறிப்புகளை மட்டுமே அளிப்பதன் மூலம் செயல்படுத்துகிறது, மேலும் இவை நேரடி பிறழ்வை அனுமதிக்காது.
//! [`RefCell`] இல் நாம் மாற்ற விரும்பும் மதிப்பின் பகுதியை நாம் மடிக்க வேண்டும், இது *உள்துறை மாற்றத்தை* வழங்குகிறது: பகிரப்பட்ட குறிப்பு மூலம் பிறழ்வை அடைய ஒரு முறை.
//! [`RefCell`] இயக்க நேரத்தில் Rust இன் கடன் விதிகளை செயல்படுத்துகிறது.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... பிற துறைகள்
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... பிற துறைகள்
//! }
//!
//! fn main() {
//!     // குறிப்பு-எண்ணப்பட்ட `Owner` ஐ உருவாக்கவும்.
//!     // `கேஜெட்டின்` உரிமையாளரின் vector ஐ ஒரு `RefCell` க்குள் வைத்திருக்கிறோம் என்பதை நினைவில் கொள்க, இதன் மூலம் பகிரப்பட்ட குறிப்பு மூலம் அதை மாற்றலாம்.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // முன்பு போல, `gadget_owner` க்கு சொந்தமான `கேஜெட்டை உருவாக்கவும்.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // அவற்றின் `Owner` இல் `கேஜெட்டை` சேர்க்கவும்.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` டைனமிக் கடன் இங்கே முடிகிறது.
//!     }
//!
//!     // எங்கள் `கேஜெட்'களைப் பற்றி விவரிக்கவும், அவற்றின் விவரங்களை அச்சிடவும்.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ஒரு `Weak<Gadget>` ஆகும்.
//!         // `Weak` சுட்டிகள் ஒதுக்கீடு இன்னும் இருப்பதை உறுதிப்படுத்த முடியாது என்பதால், நாம் `upgrade` ஐ அழைக்க வேண்டும், இது ஒரு `Option<Rc<Gadget>>` ஐ வழங்குகிறது.
//!         //
//!         //
//!         // இந்த விஷயத்தில் ஒதுக்கீடு இன்னும் உள்ளது என்பதை நாங்கள் அறிவோம், எனவே நாம் வெறுமனே `unwrap` `Option`.
//!         // மிகவும் சிக்கலான நிரலில், `None` முடிவுக்கு உங்களுக்கு அழகான பிழை கையாளுதல் தேவைப்படலாம்.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // செயல்பாட்டின் முடிவில், `gadget_owner`, `gadget1` மற்றும் `gadget2` ஆகியவை அழிக்கப்படுகின்றன.
//!     // கேஜெட்களுக்கு இப்போது வலுவான (`Rc`) சுட்டிகள் இல்லை, எனவே அவை அழிக்கப்படுகின்றன.
//!     // இது கேஜெட் மேன் பற்றிய குறிப்பு எண்ணிக்கையை பூஜ்ஜியமாக்குகிறது, எனவே அவரும் அழிக்கப்படுகிறார்.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// இது சாத்தியமான புலம்-மறுசீரமைப்பிற்கு எதிராக repr(C) முதல் future-ஆதாரம் ஆகும், இது பரிமாற்றக்கூடிய உள் வகைகளின் பாதுகாப்பான [into|from]_raw() உடன் தலையிடும்.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// ஒற்றை-திரிக்கப்பட்ட குறிப்பு-எண்ணும் சுட்டிக்காட்டி.'Rc' என்பது 'குறிப்பு
/// Counted'.
///
/// மேலும் விவரங்களுக்கு [module-level documentation](./index.html) ஐப் பார்க்கவும்.
///
/// `Rc` இன் உள்ளார்ந்த முறைகள் அனைத்தும் தொடர்புடைய செயல்பாடுகளாகும், அதாவது நீங்கள் அவற்றை எ.கா., `value.get_mut()` க்கு பதிலாக [`Rc::get_mut(&mut value)`][get_mut] என அழைக்க வேண்டும்.
/// இது உள் வகை `T` இன் முறைகளுடனான மோதல்களைத் தவிர்க்கிறது.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // இந்த பாதுகாப்பற்றது சரி, ஏனென்றால் இந்த ஆர்.சி உயிருடன் இருக்கும்போது உள் சுட்டிக்காட்டி செல்லுபடியாகும் என்று எங்களுக்கு உத்தரவாதம் அளிக்கப்படுகிறது.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// புதிய `Rc<T>` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // அனைத்து வலுவான சுட்டிகளுக்கும் சொந்தமான ஒரு உள்ளார்ந்த பலவீனமான சுட்டிக்காட்டி உள்ளது, இது பலவீனமான அழிப்பான் இயங்கும் போது பலவீனமான அழிப்பான் ஒருபோதும் ஒதுக்கீட்டை விடுவிப்பதில்லை என்பதை உறுதி செய்கிறது, பலவீனமான சுட்டிக்காட்டி வலுவான ஒன்றின் உள்ளே சேமிக்கப்பட்டிருந்தாலும் கூட.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// ஒரு பலவீனமான குறிப்பைப் பயன்படுத்தி புதிய `Rc<T>` ஐ உருவாக்குகிறது.
    /// இந்த செயல்பாடு திரும்புவதற்கு முன் பலவீனமான குறிப்பை மேம்படுத்த முயற்சித்தால் `None` மதிப்பு கிடைக்கும்.
    ///
    /// இருப்பினும், பலவீனமான குறிப்பு சுதந்திரமாக குளோன் செய்யப்பட்டு பின்னர் பயன்படுத்தப்படலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... மேலும் புலங்கள்
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // ஒற்றை பலவீனமான குறிப்புடன் "uninitialized" நிலையில் உட்புறத்தை உருவாக்குங்கள்.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // பலவீனமான சுட்டிக்காட்டி உரிமையை நாங்கள் விட்டுவிடாதது முக்கியம், இல்லையெனில் `data_fn` திரும்பும் நேரத்தில் நினைவகம் விடுவிக்கப்படலாம்.
        // நாங்கள் உண்மையிலேயே உரிமையை அனுப்ப விரும்பினால், எங்களுக்காக கூடுதல் பலவீனமான சுட்டிக்காட்டி ஒன்றை உருவாக்க முடியும், ஆனால் இது பலவீனமான குறிப்பு எண்ணிக்கையில் கூடுதல் புதுப்பிப்புகளை ஏற்படுத்தும், இல்லையெனில் தேவையில்லை.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // வலுவான குறிப்புகள் கூட்டாக பகிரப்பட்ட பலவீனமான குறிப்பை வைத்திருக்க வேண்டும், எனவே எங்கள் பழைய பலவீனமான குறிப்பிற்கான அழிப்பாளரை இயக்க வேண்டாம்.
        //
        mem::forget(weak);
        strong
    }

    /// ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய `Rc` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// நினைவகம் `0` பைட்டுகளால் நிரப்பப்பட்ட நிலையில், ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய `Rc` ஐ உருவாக்குகிறது.
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// புதிய `Rc<T>` ஐ உருவாக்குகிறது, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // அனைத்து வலுவான சுட்டிகளுக்கும் சொந்தமான ஒரு உள்ளார்ந்த பலவீனமான சுட்டிக்காட்டி உள்ளது, இது பலவீனமான அழிப்பான் இயங்கும் போது பலவீனமான அழிப்பான் ஒருபோதும் ஒதுக்கீட்டை விடுவிப்பதில்லை என்பதை உறுதி செய்கிறது, பலவீனமான சுட்டிக்காட்டி வலுவான ஒன்றின் உள்ளே சேமிக்கப்பட்டிருந்தாலும் கூட.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய `Rc` ஐ உருவாக்குகிறது, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய `Rc` ஐ உருவாக்குகிறது, நினைவகம் `0` பைட்டுகளால் நிரப்பப்பட்டு, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// புதிய `Pin<Rc<T>>` ஐ உருவாக்குகிறது.
    /// `T` `Unpin` ஐ செயல்படுத்தவில்லை என்றால், `value` நினைவகத்தில் பொருத்தப்பட்டு நகர்த்த முடியாது.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// `Rc` சரியாக ஒரு வலுவான குறிப்பைக் கொண்டிருந்தால், உள் மதிப்பை வழங்குகிறது.
    ///
    /// இல்லையெனில், ஒரு [`Err`] அனுப்பப்பட்ட அதே `Rc` உடன் திரும்பும்.
    ///
    ///
    /// சிறந்த பலவீனமான குறிப்புகள் இருந்தாலும் இது வெற்றி பெறும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // உள்ள பொருளை நகலெடுக்கவும்

                // வலுவான எண்ணிக்கையைக் குறைப்பதன் மூலம் அவற்றை விளம்பரப்படுத்த முடியாது என்பதைக் குறிக்கவும், பின்னர் ஒரு போலி பலவீனத்தை வடிவமைப்பதன் மூலம் துளி தர்க்கத்தையும் கையாளும் போது மறைமுகமான "strong weak" சுட்டிக்காட்டி அகற்றவும்.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய குறிப்பு-எண்ணப்பட்ட துண்டுகளை உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// நினைவகம் `0` பைட்டுகளால் நிரப்பப்பட்ட நிலையில், ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய குறிப்பு-எண்ணப்பட்ட துண்டுகளை உருவாக்குகிறது.
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` ஆக மாற்றுகிறது.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ஐப் போலவே, உள் மதிப்பு உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளது என்பதை உறுதிப்படுத்துவது அழைப்பாளரின் பொறுப்பாகும்.
    ///
    /// உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது உடனடி வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` ஆக மாற்றுகிறது.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ஐப் போலவே, உள் மதிப்பு உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளது என்பதை உறுதிப்படுத்துவது அழைப்பாளரின் பொறுப்பாகும்.
    ///
    /// உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது உடனடி வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `Rc` ஐப் பயன்படுத்துகிறது, மூடப்பட்ட சுட்டிக்காட்டி திருப்பித் தருகிறது.
    ///
    /// நினைவக கசிவைத் தவிர்க்க, சுட்டிக்காட்டி [`Rc::from_raw`][from_raw] ஐப் பயன்படுத்தி `Rc` க்கு மாற்றப்பட வேண்டும்.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// தரவுக்கு மூல சுட்டிக்காட்டி வழங்குகிறது.
    ///
    /// எண்ணிக்கைகள் எந்த வகையிலும் பாதிக்கப்படுவதில்லை மற்றும் `Rc` நுகரப்படுவதில்லை.
    /// `Rc` இல் வலுவான எண்ணிக்கைகள் இருக்கும் வரை சுட்டிக்காட்டி செல்லுபடியாகும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // பாதுகாப்பு: இது Deref::deref அல்லது Rc::inner வழியாக செல்ல முடியாது, ஏனெனில்
        // எ.கா. போன்ற raw/mut ஆதாரத்தைத் தக்க வைத்துக் கொள்ள இது தேவைப்படுகிறது
        // `get_mut` `from_raw` மூலம் Rc மீட்டெடுக்கப்பட்ட பிறகு சுட்டிக்காட்டி மூலம் எழுத முடியும்.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// மூல சுட்டிக்காட்டி இருந்து ஒரு `Rc<T>` ஐ உருவாக்குகிறது.
    ///
    /// மூல சுட்டிக்காட்டி முன்பு [`Rc<U>::into_raw`][into_raw] க்கு அழைப்பின் மூலம் திருப்பி அனுப்பப்பட்டிருக்க வேண்டும், அங்கு `U` ஆனது `T` இன் அதே அளவு மற்றும் சீரமைப்பைக் கொண்டிருக்க வேண்டும்.
    /// `U` `T` ஆக இருந்தால் இது அற்பமான உண்மை.
    /// `U` என்பது `T` அல்ல, அதே அளவு மற்றும் சீரமைப்பு இருந்தால், இது அடிப்படையில் வெவ்வேறு வகைகளின் குறிப்புகளை மாற்றுவதைப் போன்றது என்பதை நினைவில் கொள்க.
    /// இந்த வழக்கில் என்ன கட்டுப்பாடுகள் பொருந்தும் என்பது பற்றிய கூடுதல் தகவலுக்கு [`mem::transmute`][transmute] ஐப் பார்க்கவும்.
    ///
    /// `from_raw` இன் பயனர் `T` இன் ஒரு குறிப்பிட்ட மதிப்பு ஒரு முறை மட்டுமே கைவிடப்படுவதை உறுதி செய்ய வேண்டும்.
    ///
    /// இந்த செயல்பாடு பாதுகாப்பற்றது, ஏனெனில் முறையற்ற பயன்பாடு நினைவக பாதுகாப்பிற்கு வழிவகுக்கும், திரும்பிய `Rc<T>` ஒருபோதும் அணுகப்படாவிட்டாலும் கூட.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // கசிவைத் தடுக்க `Rc` க்கு மாற்றவும்.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` க்கான கூடுதல் அழைப்புகள் நினைவகம்-பாதுகாப்பற்றதாக இருக்கும்.
    /// }
    ///
    /// // `x` மேலே உள்ள நோக்கத்திலிருந்து வெளியேறும்போது நினைவகம் விடுவிக்கப்பட்டது, எனவே `x_ptr` இப்போது தொங்கிக்கொண்டிருக்கிறது!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // அசல் RcBox ஐக் கண்டுபிடிக்க ஆஃப்செட்டை மாற்றியமைக்கவும்.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// இந்த ஒதுக்கீட்டில் புதிய [`Weak`] சுட்டிக்காட்டி உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // தொங்கும் பலவீனத்தை நாங்கள் உருவாக்கவில்லை என்பதை உறுதிப்படுத்திக் கொள்ளுங்கள்
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// இந்த ஒதுக்கீட்டிற்கு [`Weak`] சுட்டிகளின் எண்ணிக்கையைப் பெறுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// இந்த ஒதுக்கீட்டில் வலுவான (`Rc`) சுட்டிகளின் எண்ணிக்கையைப் பெறுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// இந்த ஒதுக்கீட்டில் வேறு `Rc` அல்லது [`Weak`] சுட்டிகள் இல்லாவிட்டால் `true` ஐ வழங்குகிறது.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// அதே ஒதுக்கீட்டில் வேறு `Rc` அல்லது [`Weak`] சுட்டிகள் இல்லாவிட்டால், கொடுக்கப்பட்ட `Rc` இல் மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    ///
    /// இல்லையெனில் [`None`] ஐ வழங்குகிறது, ஏனெனில் பகிரப்பட்ட மதிப்பை மாற்றுவது பாதுகாப்பானது அல்ல.
    ///
    /// [`make_mut`][make_mut] ஐயும் காண்க, இது மற்ற சுட்டிகள் இருக்கும்போது உள் மதிப்பை [`clone`][clone] செய்யும்.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// எந்தவொரு காசோலையும் இல்லாமல், கொடுக்கப்பட்ட `Rc` இல் மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// [`get_mut`] ஐயும் காண்க, இது பாதுகாப்பானது மற்றும் பொருத்தமான காசோலைகளை செய்கிறது.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// அதே ஒதுக்கீட்டிற்கான வேறு எந்த `Rc` அல்லது [`Weak`] சுட்டிகள் திரும்பப் பெறப்பட்ட கடனுக்கான காலத்திற்கு குறிப்பிடப்படக்கூடாது.
    ///
    /// இதுபோன்ற சுட்டிகள் எதுவும் இல்லாவிட்டால் இது அற்பமான விஷயமாகும், எடுத்துக்காட்டாக `Rc::new` க்குப் பிறகு உடனடியாக.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" புலங்களை உள்ளடக்கிய ஒரு குறிப்பை * உருவாக்க வேண்டாம் என்பதில் நாங்கள் கவனமாக இருக்கிறோம், ஏனெனில் இது குறிப்பு எண்ணிக்கைகளுக்கான அணுகலுடன் முரண்படும் (எ.கா.
        // வழங்கியது `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// இரண்டு `Rc` கள் ஒரே ஒதுக்கீட்டை சுட்டிக்காட்டினால் ([`ptr::eq`] ஐ ஒத்த ஒரு நரம்பில்) `true` ஐ வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// கொடுக்கப்பட்ட `Rc` இல் மாற்றக்கூடிய குறிப்பை உருவாக்குகிறது.
    ///
    /// அதே ஒதுக்கீட்டில் பிற `Rc` சுட்டிகள் இருந்தால், தனித்துவமான உரிமையை உறுதிப்படுத்த `make_mut` ஒரு புதிய ஒதுக்கீட்டின் உள் மதிப்பை [`clone`] செய்யும்.
    /// இது குளோன்-ஆன்-ரைட் என்றும் குறிப்பிடப்படுகிறது.
    ///
    /// இந்த ஒதுக்கீட்டில் வேறு `Rc` சுட்டிகள் இல்லை என்றால், இந்த ஒதுக்கீட்டிற்கான [`Weak`] சுட்டிகள் பிரிக்கப்படும்.
    ///
    /// [`get_mut`] ஐயும் காண்க, இது குளோனிங் செய்வதை விட தோல்வியடையும்.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // எதையும் குளோன் செய்ய மாட்டேன்
    /// let mut other_data = Rc::clone(&data);    // உள் தரவை குளோன் செய்ய மாட்டேன்
    /// *Rc::make_mut(&mut data) += 1;        // உள் தரவை குளோன் செய்கிறது
    /// *Rc::make_mut(&mut data) += 1;        // எதையும் குளோன் செய்ய மாட்டேன்
    /// *Rc::make_mut(&mut other_data) *= 2;  // எதையும் குளோன் செய்ய மாட்டேன்
    ///
    /// // இப்போது `data` மற்றும் `other_data` ஆகியவை வெவ்வேறு ஒதுக்கீடுகளை சுட்டிக்காட்டுகின்றன.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] சுட்டிகள் பிரிக்கப்படும்:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // தரவை குளோன் செய்ய வேண்டும், பிற Rc கள் உள்ளன.
            // குளோன் செய்யப்பட்ட மதிப்பை நேரடியாக எழுத அனுமதிக்க நினைவகத்தை முன்கூட்டியே ஒதுக்கவும்.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // தரவைத் திருட முடியும், மீதமுள்ளவை பலவீனமானவை
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // மறைமுகமான வலுவான-பலவீனமான ref ஐ அகற்று (இங்கே ஒரு போலி பலவீனத்தை உருவாக்க தேவையில்லை-மற்ற பலவீனங்கள் எங்களுக்கு சுத்தம் செய்ய முடியும் என்பது எங்களுக்குத் தெரியும்)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // இந்த பாதுகாப்பற்றது பரவாயில்லை, ஏனென்றால் திரும்பிய சுட்டிக்காட்டி *ஒரே* சுட்டிக்காட்டி என்பது எப்போதுமே T க்குத் திருப்பித் தரப்படும்.
        // இந்த கட்டத்தில் எங்கள் குறிப்பு எண்ணிக்கை 1 ஆக இருக்கும் என்று உத்தரவாதம் அளிக்கப்படுகிறது, மேலும் `Rc<T>` தானே `mut` ஆக இருக்க வேண்டும், எனவே ஒதுக்கீட்டிற்கான சாத்தியமான ஒரே குறிப்பை நாங்கள் திருப்பித் தருகிறோம்.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` ஐ ஒரு கான்கிரீட் வகைக்குக் குறைக்கும் முயற்சி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// மதிப்பு வழங்கப்பட்ட தளவமைப்பு இருக்கும் இடத்தில் அளவிடப்படாத உள் மதிப்புக்கு போதுமான இடவசதியுடன் ஒரு `RcBox<T>` ஐ ஒதுக்குகிறது.
    ///
    /// `mem_to_rcbox` செயல்பாடு தரவு சுட்டிக்காட்டி மூலம் அழைக்கப்படுகிறது, மேலும் `RcBox<T>` க்கு ஒரு (கொழுப்பு சாத்தியமான)-பாயிண்டரை திருப்பித் தர வேண்டும்.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // கொடுக்கப்பட்ட மதிப்பு தளவமைப்பைப் பயன்படுத்தி தளவமைப்பைக் கணக்கிடுங்கள்.
        // முன்னதாக, தளவமைப்பு `&*(ptr as* const RcBox<T>)` வெளிப்பாட்டில் கணக்கிடப்பட்டது, ஆனால் இது தவறாக வடிவமைக்கப்பட்ட குறிப்பை உருவாக்கியது (#54908 ஐப் பார்க்கவும்).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// மதிப்பிடப்படாத உள் மதிப்புக்கு போதுமான இடவசதியுடன் ஒரு `RcBox<T>` ஐ ஒதுக்குகிறது, அங்கு மதிப்பு தளவமைப்பு வழங்கியுள்ளது, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது.
    ///
    ///
    /// `mem_to_rcbox` செயல்பாடு தரவு சுட்டிக்காட்டி மூலம் அழைக்கப்படுகிறது, மேலும் `RcBox<T>` க்கு ஒரு (கொழுப்பு சாத்தியமான)-பாயிண்டரை திருப்பித் தர வேண்டும்.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // கொடுக்கப்பட்ட மதிப்பு தளவமைப்பைப் பயன்படுத்தி தளவமைப்பைக் கணக்கிடுங்கள்.
        // முன்னதாக, தளவமைப்பு `&*(ptr as* const RcBox<T>)` வெளிப்பாட்டில் கணக்கிடப்பட்டது, ஆனால் இது தவறாக வடிவமைக்கப்பட்ட குறிப்பை உருவாக்கியது (#54908 ஐப் பார்க்கவும்).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // தளவமைப்புக்கு ஒதுக்க.
        let ptr = allocate(layout)?;

        // RcBox ஐத் தொடங்கவும்
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// அளவிடப்படாத உள் மதிப்புக்கு போதுமான இடவசதியுடன் ஒரு `RcBox<T>` ஐ ஒதுக்குகிறது
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // கொடுக்கப்பட்ட மதிப்பைப் பயன்படுத்தி `RcBox<T>` க்கு ஒதுக்கவும்.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // மதிப்பை பைட்டுகளாக நகலெடுக்கவும்
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // ஒதுக்கீட்டை அதன் உள்ளடக்கங்களை கைவிடாமல் விடுவிக்கவும்
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// கொடுக்கப்பட்ட நீளத்துடன் ஒரு `RcBox<[T]>` ஐ ஒதுக்குகிறது.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// துண்டுகளிலிருந்து உறுப்புகளை புதிதாக ஒதுக்கப்பட்ட Rc <\[T\]> இல் நகலெடுக்கவும்
    ///
    /// பாதுகாப்பற்றது, ஏனெனில் அழைப்பவர் உரிமையை எடுக்க வேண்டும் அல்லது `T: Copy` ஐ பிணைக்க வேண்டும்
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// ஒரு குறிப்பிட்ட அளவு என்று அறியப்படும் ஒரு ஈரேட்டரிலிருந்து ஒரு `Rc<[T]>` ஐ உருவாக்குகிறது.
    ///
    /// அளவு தவறாக இருக்க வேண்டும் என்றால் நடத்தை வரையறுக்கப்படவில்லை.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // டி கூறுகளை குளோனிங் செய்யும் போது Panic காவலர்.
        // panic ஏற்பட்டால், புதிய RcBox இல் எழுதப்பட்ட கூறுகள் கைவிடப்படும், பின்னர் நினைவகம் விடுவிக்கப்படும்.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // முதல் உறுப்புக்கான சுட்டிக்காட்டி
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // அனைத்தும் தெளிவாக.புதிய RcBox ஐ விடுவிக்காததால் காவலரை மறந்து விடுங்கள்.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` க்கு பயன்படுத்தப்படும் trait சிறப்பு.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` ஐ கைவிடுகிறது.
    ///
    /// இது வலுவான குறிப்பு எண்ணிக்கையை குறைக்கும்.
    /// வலுவான குறிப்பு எண்ணிக்கை பூஜ்ஜியத்தை அடைந்தால், மற்ற குறிப்புகள் (ஏதேனும் இருந்தால்) [`Weak`] மட்டுமே, எனவே நாம் உள் மதிப்பை `drop` செய்கிறோம்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // எதையும் அச்சிடவில்லை
    /// drop(foo2);   // "dropped!" ஐ அச்சிடுகிறது
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // உள்ள பொருளை அழிக்கவும்
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // உள்ளடக்கங்களை அழித்துவிட்டதால் இப்போது உள்ளார்ந்த "strong weak" சுட்டிக்காட்டி அகற்றவும்.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` சுட்டிக்காட்டி ஒரு குளோன் செய்கிறது.
    ///
    /// இது அதே ஒதுக்கீட்டிற்கு மற்றொரு சுட்டிக்காட்டி உருவாக்குகிறது, இது வலுவான குறிப்பு எண்ணிக்கையை அதிகரிக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` க்கான `Default` மதிப்புடன் புதிய `Rc<T>` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` க்கு ஒரு முறை இருந்தாலும் `Eq` இல் நிபுணத்துவம் பெற அனுமதிக்க ஹேக்.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// இந்த நிபுணத்துவத்தை நாங்கள் இங்கே செய்கிறோம், ஆனால் `&T` இல் பொதுவான தேர்வுமுறை அல்ல, ஏனென்றால் இது ரெஃப்ஸில் உள்ள அனைத்து சமத்துவ காசோலைகளுக்கும் செலவை சேர்க்கும்.
/// `Rc` கள் பெரிய மதிப்புகளைச் சேமிக்கப் பயன்படுகின்றன, அவை குளோன் செய்ய மெதுவானவை, ஆனால் சமத்துவத்தை சரிபார்க்கவும் கனமானவை, இதனால் இந்த செலவு மிக எளிதாக செலுத்தப்படும்.
///
/// இது இரண்டு எக்ஸ்&எக்ஸ் குளோன்களைக் கொண்டிருப்பதற்கான வாய்ப்புகள் அதிகம், அவை இரண்டு `&டி`க்களை விட ஒரே மதிப்பைக் குறிக்கும்.
///
/// `T: Eq` ஒரு `PartialEq` ஆக வேண்டுமென்றே பொருத்தமற்றதாக இருக்கும்போது மட்டுமே இதை நாம் செய்ய முடியும்.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// இரண்டு `Rc` களுக்கு சமத்துவம்.
    ///
    /// வெவ்வேறு ஒதுக்கீட்டில் சேமிக்கப்பட்டிருந்தாலும், அவற்றின் உள் மதிப்புகள் சமமாக இருந்தால் இரண்டு `ஆர்.சி'க்கள் சமம்.
    ///
    /// `T` ஆனது `Eq` ஐ (சமத்துவத்தின் நிர்பந்தத்தை குறிக்கிறது) செயல்படுத்தினால், ஒரே ஒதுக்கீட்டை சுட்டிக்காட்டும் இரண்டு `Rc` கள் எப்போதும் சமமாக இருக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// இரண்டு `Rc` களுக்கு ஏற்றத்தாழ்வு.
    ///
    /// இரண்டு `ஆர்.சி'க்கள் அவற்றின் உள் மதிப்புகள் சமமற்றதாக இருந்தால் சமமற்றவை.
    ///
    /// `T` ஆனது `Eq` ஐ (சமத்துவத்தின் நிர்பந்தத்தன்மையைக் குறிக்கிறது) செயல்படுத்தினால், ஒரே ஒதுக்கீட்டை சுட்டிக்காட்டும் இரண்டு `Rc` கள் ஒருபோதும் சமமற்றவை அல்ல.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// இரண்டு `Rc` களுக்கான பகுதி ஒப்பீடு.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `partial_cmp()` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// இரண்டு `Rc` களுடன் ஒப்பிடுகையில் குறைவாக.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `<` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// இரண்டு `Rc` களுக்கான ஒப்பீடு 'குறைவாகவோ அல்லது சமமாகவோ'.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `<=` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// இரண்டு `Rc` களுடன் ஒப்பிடுவதை விட பெரியது.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `>` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// இரண்டு `Rc` களுடன் ஒப்பிடுவதை 'விட பெரியது அல்லது சமம்'.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `>=` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// இரண்டு `Rc` களுக்கான ஒப்பீடு.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `cmp()` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// குறிப்பு-எண்ணப்பட்ட துண்டுகளை ஒதுக்கி, `v` இன் உருப்படிகளை குளோன் செய்வதன் மூலம் நிரப்பவும்.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// குறிப்பு-எண்ணப்பட்ட சரம் துண்டுகளை ஒதுக்கி, அதில் `v` ஐ நகலெடுக்கவும்.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// குறிப்பு-எண்ணப்பட்ட சரம் துண்டுகளை ஒதுக்கி, அதில் `v` ஐ நகலெடுக்கவும்.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// ஒரு பெட்டி பொருளை புதிய, குறிப்பு எண்ணப்பட்ட, ஒதுக்கீட்டிற்கு நகர்த்தவும்.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// குறிப்பு-எண்ணப்பட்ட துண்டுகளை ஒதுக்கி, அதில் `v` இன் உருப்படிகளை நகர்த்தவும்.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec அதன் நினைவகத்தை விடுவிக்க அனுமதிக்கவும், ஆனால் அதன் உள்ளடக்கங்களை அழிக்க வேண்டாம்
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` இல் உள்ள ஒவ்வொரு உறுப்புகளையும் எடுத்து அதை `Rc<[T]>` இல் சேகரிக்கிறது.
    ///
    /// # செயல்திறன் பண்புகள்
    ///
    /// ## பொது வழக்கு
    ///
    /// பொதுவான வழக்கில், `Rc<[T]>` இல் சேகரிப்பது முதலில் `Vec<T>` இல் சேகரிப்பதன் மூலம் செய்யப்படுகிறது.அதாவது, பின்வருவனவற்றை எழுதும்போது:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// இது நாங்கள் எழுதியது போல் செயல்படுகிறது:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // முதல் ஒதுக்கீடு இங்கே நடக்கிறது.
    ///     .into(); // `Rc<[T]>` க்கான இரண்டாவது ஒதுக்கீடு இங்கே நடக்கிறது.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// இது `Vec<T>` ஐ நிர்மாணிக்க தேவையான பல மடங்கு ஒதுக்குகிறது, பின்னர் இது `Vec<T>` ஐ `Rc<[T]>` ஆக மாற்ற ஒரு முறை ஒதுக்கப்படும்.
    ///
    ///
    /// ## அறியப்பட்ட நீளத்தை உருவாக்குபவர்கள்
    ///
    /// உங்கள் `Iterator` `TrustedLen` ஐ செயல்படுத்தி சரியான அளவைக் கொண்டிருக்கும்போது, `Rc<[T]>` க்கு ஒற்றை ஒதுக்கீடு செய்யப்படும்.உதாரணத்திற்கு:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // ஒரே ஒரு ஒதுக்கீடு இங்கே நடக்கிறது.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>` இல் சேகரிக்கப் பயன்படும் சிறப்பு trait.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // ஒரு `TrustedLen` ஐரேட்டருக்கு இதுதான்.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // பாதுகாப்பு: ஈரேட்டருக்கு சரியான நீளம் இருப்பதை உறுதி செய்ய வேண்டும், எங்களிடம் உள்ளது.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // இயல்பான செயலாக்கத்திற்கு மீண்டும் விழவும்.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` நிர்வகிக்கப்பட்ட ஒதுக்கீட்டிற்கு சொந்தமில்லாத குறிப்பைக் கொண்ட [`Rc`] இன் பதிப்பாகும்.`Weak` சுட்டிக்காட்டிக்கு [`upgrade`] ஐ அழைப்பதன் மூலம் ஒதுக்கீடு அணுகப்படுகிறது, இது ஒரு [`விருப்பம்`]`<`[`Rc`] `<T>>`.
///
/// ஒரு `Weak` குறிப்பு உரிமையை நோக்கி எண்ணாததால், ஒதுக்கீட்டில் சேமிக்கப்பட்ட மதிப்பு கைவிடப்படுவதை இது தடுக்காது, மேலும் `Weak` தானே இன்னும் இருக்கும் மதிப்பு குறித்து எந்த உத்தரவாதமும் அளிக்காது.
/// [`மேம்படுத்தல்`] போது இது [`None`] ஐத் தரக்கூடும்.
/// எவ்வாறாயினும், ஒரு `Weak` குறிப்பு * ஒதுக்கீட்டைத் தானே (ஆதரவுக் கடை) ஒதுக்குவதைத் தடுக்கிறது என்பதை நினைவில் கொள்க.
///
/// `Weak` சுட்டிக்காட்டி அதன் உள் மதிப்பு கைவிடப்படுவதைத் தடுக்காமல் [`Rc`] ஆல் நிர்வகிக்கப்படும் ஒதுக்கீட்டின் தற்காலிக குறிப்பை வைத்திருக்க பயனுள்ளதாக இருக்கும்.
/// [`Rc`] சுட்டிகள் இடையே வட்ட குறிப்புகளைத் தடுக்கவும் இது பயன்படுத்தப்படுகிறது, ஏனெனில் பரஸ்பர சொந்தமான குறிப்புகள் ஒருபோதும் [`Rc`] ஐ கைவிட அனுமதிக்காது.
/// எடுத்துக்காட்டாக, ஒரு மரத்தில் பெற்றோர் முனைகளிலிருந்து குழந்தைகளுக்கு வலுவான [`Rc`] சுட்டிகள் இருக்கக்கூடும், மேலும் குழந்தைகளிடமிருந்து `Weak` சுட்டிகள் பெற்றோரிடமிருந்து திரும்பலாம்.
///
/// `Weak` சுட்டிக்காட்டி பெறுவதற்கான பொதுவான வழி [`Rc::downgrade`] ஐ அழைப்பதாகும்.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // என்யூம்களில் இந்த வகையின் அளவை மேம்படுத்த அனுமதிக்க இது ஒரு `NonNull` ஆகும், ஆனால் இது சரியான சுட்டிக்காட்டி அல்ல.
    //
    // `Weak::new` இதை `usize::MAX` ஆக அமைக்கிறது, இதனால் குவியலில் இடத்தை ஒதுக்க தேவையில்லை.
    // RcBox க்கு குறைந்தது 2 சீரமைப்பு இருப்பதால் உண்மையான சுட்டிக்காட்டி எப்போதும் வைத்திருக்கும் மதிப்பு இதுவல்ல.
    // `T: Sized` போது மட்டுமே இது சாத்தியமாகும்;அளவிடப்படாத `T` ஒருபோதும் தொங்கவிடாது.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// எந்த நினைவகத்தையும் ஒதுக்காமல், புதிய `Weak<T>` ஐ உருவாக்குகிறது.
    /// வருவாய் மதிப்பில் [`upgrade`] ஐ அழைப்பது எப்போதும் [`None`] ஐ வழங்குகிறது.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// தரவுத் துறையைப் பற்றி எந்தவொரு கூற்றும் செய்யாமல் குறிப்பு எண்ணிக்கையை அணுக அனுமதிக்க உதவி வகை.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// இந்த `Weak<T>` ஆல் சுட்டிக்காட்டப்பட்ட `T` பொருளுக்கு மூல சுட்டிக்காட்டி வழங்குகிறது.
    ///
    /// சில வலுவான குறிப்புகள் இருந்தால் மட்டுமே சுட்டிக்காட்டி செல்லுபடியாகும்.
    /// சுட்டிக்காட்டி தொங்கும், வரிசைப்படுத்தப்படாத அல்லது [`null`] இல்லையெனில் இருக்கலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // இரண்டும் ஒரே பொருளை சுட்டிக்காட்டுகின்றன
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // இங்கே வலுவானவர்கள் அதை உயிரோடு வைத்திருக்கிறார்கள், எனவே நாம் இன்னும் பொருளை அணுக முடியும்.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // ஆனால் இனி இல்லை.
    /// // நாம் weak.as_ptr() செய்ய முடியும், ஆனால் சுட்டிக்காட்டி அணுகுவது வரையறுக்கப்படாத நடத்தைக்கு வழிவகுக்கும்.
    /// // assert_eq! ("ஹலோ", பாதுகாப்பற்றது {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // சுட்டிக்காட்டி தொங்கிக்கொண்டிருந்தால், நாங்கள் சென்டினலை நேரடியாக திருப்பித் தருகிறோம்.
            // இது செல்லுபடியாகும் பேலோட் முகவரியாக இருக்க முடியாது, ஏனெனில் பேலோட் குறைந்தபட்சம் RcBox (usize) என சீரமைக்கப்பட்டுள்ளது.
            ptr as *const T
        } else {
            // பாதுகாப்பு: is_dangling தவறானது எனில், சுட்டிக்காட்டி குறைக்க முடியாதது.
            // இந்த கட்டத்தில் பேலோட் கைவிடப்படலாம், மேலும் நாம் ஆதாரத்தை பராமரிக்க வேண்டும், எனவே மூல சுட்டிக்காட்டி கையாளுதலைப் பயன்படுத்தவும்.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` ஐ உட்கொண்டு அதை ஒரு மூல சுட்டிக்காட்டியாக மாற்றுகிறது.
    ///
    /// இது பலவீனமான சுட்டிக்காட்டி மூல சுட்டிக்காட்டியாக மாற்றுகிறது, அதே நேரத்தில் ஒரு பலவீனமான குறிப்பின் உரிமையை பாதுகாக்கிறது (பலவீனமான எண்ணிக்கை இந்த செயல்பாட்டால் மாற்றப்படவில்லை).
    /// இதை [`from_raw`] உடன் `Weak<T>` ஆக மாற்றலாம்.
    ///
    /// [`as_ptr`] உடன் சுட்டிக்காட்டி இலக்கை அணுகுவதற்கான அதே கட்டுப்பாடுகள் பொருந்தும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// முன்பு [`into_raw`] ஆல் உருவாக்கப்பட்ட மூல சுட்டிக்காட்டி மீண்டும் `Weak<T>` ஆக மாற்றுகிறது.
    ///
    /// இது ஒரு வலுவான குறிப்பைப் பாதுகாப்பாகப் பெற (பின்னர் [`upgrade`] ஐ அழைப்பதன் மூலம்) அல்லது `Weak<T>` ஐ கைவிடுவதன் மூலம் பலவீனமான எண்ணிக்கையை நீக்குவதற்குப் பயன்படுத்தப்படலாம்.
    ///
    /// இது ஒரு பலவீனமான குறிப்பின் உரிமையை எடுக்கும் ([`new`] ஆல் உருவாக்கிய சுட்டிகள் தவிர, இவை எதுவும் சொந்தமாக இல்லை; முறை இன்னும் அவற்றில் இயங்குகிறது).
    ///
    /// # Safety
    ///
    /// சுட்டிக்காட்டி [`into_raw`] இலிருந்து தோன்றியிருக்க வேண்டும், மேலும் அதன் பலவீனமான குறிப்பை இன்னும் வைத்திருக்க வேண்டும்.
    ///
    /// இதை அழைக்கும் நேரத்தில் வலுவான எண்ணிக்கை 0 ஆக இருக்க அனுமதிக்கப்படுகிறது.
    /// ஆயினும்கூட, இது தற்போது ஒரு மூல சுட்டிக்காட்டி என குறிப்பிடப்பட்டுள்ள ஒரு பலவீனமான குறிப்பின் உரிமையை எடுத்துக்கொள்கிறது (இந்த செயல்பாட்டால் பலவீனமான எண்ணிக்கை மாற்றப்படவில்லை) எனவே இது [`into_raw`] க்கு முந்தைய அழைப்போடு இணைக்கப்பட வேண்டும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // கடைசி பலவீனமான எண்ணிக்கையை குறைத்தல்.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // உள்ளீட்டு சுட்டிக்காட்டி எவ்வாறு பெறப்பட்டது என்பதற்கான சூழலுக்கு Weak::as_ptr ஐப் பார்க்கவும்.

        let ptr = if is_dangling(ptr as *mut T) {
            // இது ஒரு பலவீனமான பலவீனமாகும்.
            ptr as *mut RcBox<T>
        } else {
            // இல்லையெனில், சுட்டிக்காட்டி ஒரு பலவீனமான பலவீனத்திலிருந்து வந்தது என்று எங்களுக்கு உத்தரவாதம்.
            // பாதுகாப்பு: தரவு_ஆஃப்செட் அழைப்பது பாதுகாப்பானது, ஏனெனில் பி.டி.ஆர் ஒரு உண்மையான (சாத்தியமான கைவிடப்பட்ட) டி.
            let offset = unsafe { data_offset(ptr) };
            // இதனால், முழு RcBox ஐப் பெற ஆஃப்செட்டை மாற்றியமைக்கிறோம்.
            // பாதுகாப்பு: சுட்டிக்காட்டி பலவீனத்திலிருந்து தோன்றியது, எனவே இந்த ஆஃப்செட் பாதுகாப்பானது.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // பாதுகாப்பு: அசல் பலவீன சுட்டிக்காட்டினை இப்போது மீட்டெடுத்துள்ளோம், எனவே பலவீனத்தை உருவாக்க முடியும்.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` சுட்டிக்காட்டி ஒரு [`Rc`] க்கு மேம்படுத்த முயற்சிக்கிறது, வெற்றிகரமாக இருந்தால் உள் மதிப்பைக் கைவிடுவதை தாமதப்படுத்துகிறது.
    ///
    ///
    /// உள் மதிப்பு கைவிடப்பட்டிருந்தால் [`None`] ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // அனைத்து வலுவான சுட்டிகளையும் அழிக்கவும்.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// இந்த ஒதுக்கீட்டை சுட்டிக்காட்டும் வலுவான (`Rc`) சுட்டிகளின் எண்ணிக்கையைப் பெறுகிறது.
    ///
    /// [`Weak::new`] ஐப் பயன்படுத்தி `self` உருவாக்கப்பட்டது என்றால், இது 0 ஐத் தரும்.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// இந்த ஒதுக்கீட்டை சுட்டிக்காட்டும் `Weak` சுட்டிகளின் எண்ணிக்கையைப் பெறுகிறது.
    ///
    /// வலுவான சுட்டிகள் எதுவும் இல்லை என்றால், இது பூஜ்ஜியத்தைத் தரும்.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // மறைமுகமான பலவீனமான ptr ஐக் கழிக்கவும்
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// சுட்டிக்காட்டி தொங்கும் போது `None` ஐ வழங்குகிறது மற்றும் ஒதுக்கப்பட்ட `RcBox` இல்லை, (அதாவது, இந்த `Weak` `Weak::new` ஆல் உருவாக்கப்பட்டபோது).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // "data" புலத்தை உள்ளடக்கிய ஒரு குறிப்பை * உருவாக்க வேண்டாம் என்பதில் நாங்கள் கவனமாக இருக்கிறோம், ஏனெனில் புலம் ஒரே நேரத்தில் மாற்றப்படலாம் (எடுத்துக்காட்டாக, கடைசி `Rc` கைவிடப்பட்டால், தரவு புலம் இடத்தில் கைவிடப்படும்).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// இரண்டு `பலவீனமானவர்கள் ஒரே ஒதுக்கீட்டை ([`ptr::eq`] ஐப் போன்றது) சுட்டிக்காட்டினால் அல்லது இருவரும் எந்த ஒதுக்கீட்டையும் சுட்டிக்காட்டவில்லை என்றால் (அவை `Weak::new()`) உடன் உருவாக்கப்பட்டதால்) `true` ஐ வழங்குகிறது.
    ///
    ///
    /// # Notes
    ///
    /// இது சுட்டிகளை ஒப்பிடுவதால், எந்த ஒதுக்கீட்டையும் சுட்டிக்காட்டாவிட்டாலும், `Weak::new()` ஒருவருக்கொருவர் சமமாக இருக்கும் என்று அர்த்தம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` ஐ ஒப்பிடுகிறது.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` சுட்டிக்காட்டி குறைகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // எதையும் அச்சிடவில்லை
    /// drop(foo);        // "dropped!" ஐ அச்சிடுகிறது
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // பலவீனமான எண்ணிக்கை 1 இல் தொடங்குகிறது, மேலும் அனைத்து வலுவான சுட்டிகளும் மறைந்துவிட்டால் மட்டுமே பூஜ்ஜியத்திற்கு செல்லும்.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// அதே ஒதுக்கீட்டை சுட்டிக்காட்டும் `Weak` சுட்டிக்காட்டி ஒரு குளோனை உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// ஒரு புதிய `Weak<T>` ஐ உருவாக்குகிறது, `T` க்கு நினைவகத்தை துவக்காமல் ஒதுக்குகிறது.
    /// வருவாய் மதிப்பில் [`upgrade`] ஐ அழைப்பது எப்போதும் [`None`] ஐ வழங்குகிறது.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget ஐ பாதுகாப்பாக சமாளிக்க நாங்கள் இங்கு சோதனை செய்தோம்.குறிப்பாக
// நீங்கள் mem::forget Rcs (அல்லது பலவீனமாக) இருந்தால், ref-எண்ணிக்கை நிரம்பி வழியும், பின்னர் நிலுவையில் உள்ள Rc கள் (அல்லது பலவீனங்கள்) இருக்கும்போது ஒதுக்கீட்டை விடுவிக்கலாம்.
//
// நாங்கள் கருக்கலைப்பு செய்கிறோம், ஏனெனில் இது ஒரு சீரழிந்த சூழ்நிலை என்பதால் என்ன நடக்கிறது என்பதைப் பற்றி நாங்கள் கவலைப்படவில்லை-எந்த உண்மையான நிரலும் இதை அனுபவிக்கக்கூடாது.
//
// Rust இல் உரிமையாளர் மற்றும் நகர்வு-சொற்பொருள்களுக்கு நன்றி செலுத்துவதற்கு நீங்கள் உண்மையில் இவற்றைக் குளோன் செய்யத் தேவையில்லை என்பதால் இது மிகக் குறைவான மேல்நிலைகளைக் கொண்டிருக்க வேண்டும்.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // மதிப்பைக் கைவிடுவதற்குப் பதிலாக வழிதல் நிறுத்தப்பட வேண்டும்.
        // இது அழைக்கப்படும்போது குறிப்பு எண்ணிக்கை ஒருபோதும் பூஜ்ஜியமாக இருக்காது;
        // ஆயினும்கூட, எல்.எல்.வி.எம் இல்லையெனில் தவறவிட்ட தேர்வுமுறைக்கு குறிக்க ஒரு கருக்கலைப்பை இங்கு செருகுவோம்.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // மதிப்பைக் கைவிடுவதற்குப் பதிலாக வழிதல் நிறுத்தப்பட வேண்டும்.
        // இது அழைக்கப்படும்போது குறிப்பு எண்ணிக்கை ஒருபோதும் பூஜ்ஜியமாக இருக்காது;
        // ஆயினும்கூட, எல்.எல்.வி.எம் இல்லையெனில் தவறவிட்ட தேர்வுமுறைக்கு குறிக்க ஒரு கருக்கலைப்பை இங்கு செருகுவோம்.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// ஒரு சுட்டிக்காட்டிக்குப் பின்னால் செலுத்தும் சுமைக்கு `RcBox` க்குள் ஆஃப்செட்டைப் பெறுங்கள்.
///
/// # Safety
///
/// சுட்டிக்காட்டி T இன் முன்னர் செல்லுபடியாகும் நிகழ்வை சுட்டிக்காட்ட வேண்டும் (மற்றும் சரியான மெட்டாடேட்டாவைக் கொண்டிருக்க வேண்டும்), ஆனால் T ஐ கைவிட அனுமதிக்கப்படுகிறது.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // அளவிடப்படாத மதிப்பை RcBox இன் இறுதியில் சீரமைக்கவும்.
    // RcBox repr(C) என்பதால், இது எப்போதும் நினைவகத்தின் கடைசி புலமாக இருக்கும்.
    // பாதுகாப்பு: அளவிடப்படாத வகைகள் மட்டுமே துண்டுகள், trait பொருள்கள்,
    // மற்றும் வெளிப்புற வகைகள், align_of_val_raw இன் தேவைகளை பூர்த்தி செய்ய உள்ளீட்டு பாதுகாப்பு தேவை தற்போது போதுமானது;இது std க்கு வெளியே நம்பப்படாத மொழியின் செயல்படுத்தல் விவரம்.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}