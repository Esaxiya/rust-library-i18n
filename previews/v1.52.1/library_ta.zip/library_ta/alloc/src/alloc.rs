//! நினைவக ஒதுக்கீடு API கள்

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // உலகளாவிய ஒதுக்கீட்டாளரை அழைப்பதற்கான மந்திர அடையாளங்கள் இவை.rustc `__rg_alloc` போன்றவற்றை அழைக்க அவற்றை உருவாக்குகிறது.
    // ஒரு `#[global_allocator]` பண்புக்கூறு இருந்தால் (அந்த பண்புகளை மேக்ரோ உருவாக்கும் குறியீடு விரிவடைகிறது), அல்லது இயல்புநிலை செயலாக்கங்களை libstd (`__rdl_alloc` போன்றவை) இல் அழைக்கவும்.
    //
    // `library/std/src/alloc.rs` இல்) இல்லையெனில்.
    // எல்.எல்.வி.எம் இன் rustc fork இந்த செயல்பாட்டு பெயர்களை முறையே `malloc`, `realloc` மற்றும் `free` போன்றவற்றை மேம்படுத்தக்கூடிய சிறப்பு நிகழ்வுகளாகும்.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// உலகளாவிய நினைவக ஒதுக்கீடு.
///
/// இந்த வகை [`Allocator`] trait ஐ `#[global_allocator]` பண்புக்கூறுடன் பதிவுசெய்த ஒதுக்கீட்டாளருக்கு ஒன்று இருந்தால், அல்லது `std` crate இன் இயல்புநிலைக்கு அனுப்புவதன் மூலம் செயல்படுத்துகிறது.
///
///
/// Note: இந்த வகை நிலையற்றதாக இருக்கும்போது, அது வழங்கும் செயல்பாட்டை [free functions in `alloc`](self#functions) வழியாக அணுகலாம்.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// உலகளாவிய ஒதுக்கீட்டாளருடன் நினைவகத்தை ஒதுக்கவும்.
///
/// இந்த செயல்பாடு `#[global_allocator]` பண்புக்கூறுடன் பதிவுசெய்யப்பட்ட ஒதுக்கீட்டாளரின் [`GlobalAlloc::alloc`] முறைக்கு ஒன்று இருந்தால், அல்லது `std` crate இன் இயல்புநிலைக்கு அழைக்கிறது.
///
///
/// இந்த செயல்பாடு [`Global`] வகையின் `alloc` முறைக்கு ஆதரவாகவும், [`Allocator`] trait நிலையானதாகவும் இருக்கும்போது நீக்கப்படும் என்று எதிர்பார்க்கப்படுகிறது.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] ஐப் பார்க்கவும்.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// உலகளாவிய ஒதுக்கீட்டாளருடன் நினைவகத்தை ஒதுக்குங்கள்.
///
/// இந்த செயல்பாடு `#[global_allocator]` பண்புக்கூறுடன் பதிவுசெய்யப்பட்ட ஒதுக்கீட்டாளரின் [`GlobalAlloc::dealloc`] முறைக்கு ஒன்று இருந்தால், அல்லது `std` crate இன் இயல்புநிலைக்கு அழைக்கிறது.
///
///
/// இந்த செயல்பாடு [`Global`] வகையின் `dealloc` முறைக்கு ஆதரவாகவும், [`Allocator`] trait நிலையானதாகவும் இருக்கும்போது நீக்கப்படும் என்று எதிர்பார்க்கப்படுகிறது.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] ஐப் பார்க்கவும்.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// உலகளாவிய ஒதுக்கீட்டாளருடன் நினைவகத்தை மறு ஒதுக்கீடு செய்யுங்கள்.
///
/// இந்த செயல்பாடு `#[global_allocator]` பண்புக்கூறுடன் பதிவுசெய்யப்பட்ட ஒதுக்கீட்டாளரின் [`GlobalAlloc::realloc`] முறைக்கு ஒன்று இருந்தால், அல்லது `std` crate இன் இயல்புநிலைக்கு அழைக்கிறது.
///
///
/// இந்த செயல்பாடு [`Global`] வகையின் `realloc` முறைக்கு ஆதரவாகவும், [`Allocator`] trait நிலையானதாகவும் இருக்கும்போது நீக்கப்படும் என்று எதிர்பார்க்கப்படுகிறது.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] ஐப் பார்க்கவும்.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// உலகளாவிய ஒதுக்கீட்டாளருடன் பூஜ்ஜிய-துவக்கப்பட்ட நினைவகத்தை ஒதுக்கவும்.
///
/// இந்த செயல்பாடு `#[global_allocator]` பண்புக்கூறுடன் பதிவுசெய்யப்பட்ட ஒதுக்கீட்டாளரின் [`GlobalAlloc::alloc_zeroed`] முறைக்கு ஒன்று இருந்தால், அல்லது `std` crate இன் இயல்புநிலைக்கு அழைக்கிறது.
///
///
/// இந்த செயல்பாடு [`Global`] வகையின் `alloc_zeroed` முறைக்கு ஆதரவாகவும், [`Allocator`] trait நிலையானதாகவும் இருக்கும்போது நீக்கப்படும் என்று எதிர்பார்க்கப்படுகிறது.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] ஐப் பார்க்கவும்.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // பாதுகாப்பு: `layout` அளவு பூஜ்ஜியமற்றது,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // பாதுகாப்பு: `Allocator::grow` போலவே
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // பாதுகாப்பு: `new_size` என்பது பூஜ்ஜியமற்றது, ஏனெனில் `old_size` `new_size` ஐ விட அதிகமாகவோ அல்லது சமமாகவோ இருக்கும்
            // பாதுகாப்பு நிலைமைகளின்படி தேவை.பிற நிபந்தனைகளை அழைப்பவர் உறுதிப்படுத்த வேண்டும்
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` `new_size >= old_layout.size()` அல்லது அதைப் போன்ற ஏதாவது ஒன்றைச் சரிபார்க்கலாம்.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // பாதுகாப்பு: ஏனெனில் `new_layout.size()` `old_size` ஐ விட அதிகமாகவோ அல்லது சமமாகவோ இருக்க வேண்டும்,
            // பழைய மற்றும் புதிய நினைவக ஒதுக்கீடு இரண்டும் `old_size` பைட்டுகளுக்கான வாசிப்புகளுக்கும் எழுதுதலுக்கும் செல்லுபடியாகும்.
            // மேலும், பழைய ஒதுக்கீடு இன்னும் ஒதுக்கப்படவில்லை என்பதால், இது `new_ptr` ஐ ஒன்றுடன் ஒன்று சேர்க்க முடியாது.
            // இதனால், `copy_nonoverlapping` க்கான அழைப்பு பாதுகாப்பானது.
            // `dealloc` க்கான பாதுகாப்பு ஒப்பந்தத்தை அழைப்பவர் உறுதிப்படுத்த வேண்டும்.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // பாதுகாப்பு: `layout` அளவு பூஜ்ஜியமற்றது,
            // பிற நிபந்தனைகளை அழைப்பவர் உறுதிப்படுத்த வேண்டும்
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // பாதுகாப்பு: எல்லா நிபந்தனைகளும் அழைப்பாளரால் உறுதிப்படுத்தப்பட வேண்டும்
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // பாதுகாப்பு: எல்லா நிபந்தனைகளும் அழைப்பாளரால் உறுதிப்படுத்தப்பட வேண்டும்
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // பாதுகாப்பு: அழைப்பாளரால் நிபந்தனைகள் உறுதிப்படுத்தப்பட வேண்டும்
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // பாதுகாப்பு: `new_size` பூஜ்ஜியமற்றது.பிற நிபந்தனைகளை அழைப்பவர் உறுதிப்படுத்த வேண்டும்
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` `new_size <= old_layout.size()` அல்லது அதைப் போன்ற ஏதாவது ஒன்றைச் சரிபார்க்கலாம்.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // பாதுகாப்பு: ஏனெனில் `new_size` `old_layout.size()` ஐ விட சிறியதாகவோ அல்லது சமமாகவோ இருக்க வேண்டும்,
            // பழைய மற்றும் புதிய நினைவக ஒதுக்கீடு இரண்டுமே `new_size` பைட்டுகளுக்கான வாசிப்புகளுக்கும் எழுதுதலுக்கும் செல்லுபடியாகும்.
            // மேலும், பழைய ஒதுக்கீடு இன்னும் ஒதுக்கப்படவில்லை என்பதால், இது `new_ptr` ஐ ஒன்றுடன் ஒன்று சேர்க்க முடியாது.
            // இதனால், `copy_nonoverlapping` க்கான அழைப்பு பாதுகாப்பானது.
            // `dealloc` க்கான பாதுகாப்பு ஒப்பந்தத்தை அழைப்பவர் உறுதிப்படுத்த வேண்டும்.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// தனிப்பட்ட சுட்டிகள் ஒதுக்கீடு.
// இந்த செயல்பாடு பிரிக்கப்படக்கூடாது.அவ்வாறு செய்தால், எம்.ஐ.ஆர் கோட்ஜென் தோல்வியடையும்.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// இந்த கையொப்பம் `Box` ஐப் போலவே இருக்க வேண்டும், இல்லையெனில் ஒரு ICE நடக்கும்.
// `Box` க்கு கூடுதல் அளவுரு சேர்க்கப்படும் போது (`A: Allocator` போன்றது), இது இங்கேயும் சேர்க்கப்பட வேண்டும்.
// எடுத்துக்காட்டாக, `Box` ஐ `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` ஆக மாற்றினால், இந்த செயல்பாடு `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` ஆகவும் மாற்றப்பட வேண்டும்.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # ஒதுக்கீடு பிழை கையாளுதல்

extern "Rust" {
    // உலகளாவிய ஒதுக்கீடு பிழை கையாளுபவர் என்று அழைக்க இது மேஜிக் சின்னம்.
    // rustc ஒரு `#[alloc_error_handler]` இருந்தால் `__rg_oom` ஐ அழைக்க அல்லது (`__rdl_oom`) க்குக் கீழே இயல்புநிலை செயலாக்கங்களை அழைக்க அதை உருவாக்குகிறது.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// நினைவக ஒதுக்கீடு பிழை அல்லது தோல்வி நிறுத்தவும்.
///
/// ஒதுக்கீட்டுப் பிழையின் பிரதிபலிப்பாக கணக்கீட்டை நிறுத்த விரும்பும் நினைவக ஒதுக்கீடு ஏபிஐகளின் அழைப்பாளர்கள் இந்த செயல்பாட்டை அழைக்க ஊக்குவிக்கப்படுகிறார்கள், இது நேரடியாக `panic!` அல்லது அதற்கு ஒத்ததாக இருப்பதைக் காட்டிலும்.
///
///
/// இந்தச் செயல்பாட்டின் இயல்புநிலை நடத்தை ஒரு செய்தியை நிலையான பிழைக்கு அச்சிட்டு செயல்முறையை நிறுத்துவதாகும்.
/// இதை [`set_alloc_error_hook`] மற்றும் [`take_alloc_error_hook`] உடன் மாற்றலாம்.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// ஒதுக்கீடு சோதனைக்கு `std::alloc::handle_alloc_error` ஐ நேரடியாகப் பயன்படுத்தலாம்.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // உருவாக்கப்பட்ட `__rust_alloc_error_handler` வழியாக அழைக்கப்படுகிறது

    // `#[alloc_error_handler]` இல்லை என்றால்
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // ஒரு `#[alloc_error_handler]` இருந்தால்
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// முன்பே ஒதுக்கப்பட்ட, ஆரம்பிக்கப்படாத நினைவகத்தில் குளோன்களை நிபுணத்துவம் செய்யுங்கள்.
/// `Box::clone` மற்றும் `Rc`/`Arc::make_mut` ஆல் பயன்படுத்தப்படுகிறது.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *முதலில்* ஒதுக்கப்பட்டிருப்பதால், குளோன் செய்யப்பட்ட மதிப்பை இடத்தில் உருவாக்க உகப்பாக்கி அனுமதிக்கலாம், உள்ளூர் தவிர்த்து நகர்த்தலாம்.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // உள்ளூர் மதிப்பில் ஈடுபடாமல், நாங்கள் எப்போதும் இடத்தில் நகலெடுக்க முடியும்.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}