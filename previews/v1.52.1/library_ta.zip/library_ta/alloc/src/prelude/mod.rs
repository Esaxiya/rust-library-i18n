//! ஒதுக்கீடு Prelude
//!
//! இந்த தொகுதியின் நோக்கம், தொகுதிகளின் மேல் ஒரு குளோப் இறக்குமதியைச் சேர்ப்பதன் மூலம் `alloc` crate இன் பொதுவாகப் பயன்படுத்தப்படும் பொருட்களின் இறக்குமதியைத் தணிப்பதாகும்:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;