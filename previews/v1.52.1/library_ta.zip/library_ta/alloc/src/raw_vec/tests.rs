use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // மூன்றாம் தரப்பு ஒதுக்கீட்டாளர்களுக்கும் `RawVec` க்கும் இடையில் ஒருங்கிணைப்புக்கான சோதனையை எழுதுவது கொஞ்சம் தந்திரமானது, ஏனெனில் `RawVec` API தவறான ஒதுக்கீட்டு முறைகளை வெளிப்படுத்தாது, எனவே ஒதுக்கீடு தீர்ந்துவிட்டால் என்ன நடக்கிறது என்பதை நாங்கள் சரிபார்க்க முடியாது (ஒரு panic ஐக் கண்டறிவதற்கு அப்பால்).
    //
    //
    // அதற்கு பதிலாக, இது `RawVec` முறைகள் சேமிப்பகத்தை முன்பதிவு செய்யும் போது குறைந்தபட்சம் ஒதுக்கீடு ஏபிஐ வழியாகச் செல்கிறதா என்பதை சரிபார்க்கிறது.
    //
    //
    //
    //
    //

    // ஒதுக்கீடு முயற்சிகள் தோல்வியடையத் தொடங்குவதற்கு முன் ஒரு நிலையான அளவு எரிபொருளைப் பயன்படுத்தும் ஊமை ஒதுக்கீட்டாளர்.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (ஒரு மறு ஒதுக்கீட்டை ஏற்படுத்துகிறது, இதனால் 50 + 150=200 யூனிட் எரிபொருளைப் பயன்படுத்துகிறது)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // முதலில், `reserve` `reserve_exact` போன்றது.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 என்பது 7 ஐ விட இரண்டு மடங்கு அதிகம், எனவே `reserve` `reserve_exact` போல வேலை செய்ய வேண்டும்.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 என்பது 12 இல் பாதிக்கும் குறைவானது, எனவே `reserve` அதிவேகமாக வளர வேண்டும்.
        // இந்த சோதனை வளர்ச்சி காரணி எழுதும் நேரத்தில் 2 ஆகும், எனவே புதிய திறன் 24 ஆகும், இருப்பினும், 1.5 இன் வளரும் காரணியும் சரி.
        //
        // எனவே உறுதிப்படுத்தலில் `>= 18`.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}