#![stable(feature = "rust1", since = "1.0.0")]

//! நூல்-பாதுகாப்பான குறிப்பு-எண்ணும் சுட்டிகள்.
//!
//! மேலும் விவரங்களுக்கு [`Arc<T>`][Arc] ஆவணங்களைப் பார்க்கவும்.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc` இல் செய்யக்கூடிய குறிப்புகளின் அளவுக்கான மென்மையான வரம்பு.
///
/// இந்த வரம்பை மீறி _exactly_ `MAX_REFCOUNT + 1` குறிப்புகளில் உங்கள் நிரலை (அவசியமில்லை என்றாலும்) நிறுத்திவிடும்.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer நினைவக வேலிகளை ஆதரிக்காது.
// ஆர்க்/பலவீனமான செயலாக்கத்தில் தவறான நேர்மறையான அறிக்கைகளைத் தவிர்க்க ஒத்திசைவுக்கு பதிலாக அணு சுமைகளைப் பயன்படுத்துங்கள்.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// ஒரு நூல்-பாதுகாப்பான குறிப்பு-எண்ணும் சுட்டிக்காட்டி.'Arc' என்பது 'அணுக்கரு குறிப்பு கணக்கிடப்பட்டது'.
///
/// `Arc<T>` வகை `T` வகை மதிப்பின் பகிரப்பட்ட உரிமையை வழங்குகிறது, இது குவியலில் ஒதுக்கப்பட்டுள்ளது.`Arc` இல் [`clone`][clone] ஐத் தொடங்குவது ஒரு புதிய `Arc` நிகழ்வை உருவாக்குகிறது, இது குவியலின் மூல `Arc` இன் அதே ஒதுக்கீட்டை சுட்டிக்காட்டுகிறது, அதே நேரத்தில் குறிப்பு எண்ணிக்கையை அதிகரிக்கும்.
/// கொடுக்கப்பட்ட ஒதுக்கீட்டிற்கான கடைசி `Arc` சுட்டிக்காட்டி அழிக்கப்படும் போது, அந்த ஒதுக்கீட்டில் சேமிக்கப்பட்ட மதிப்பும் (பெரும்பாலும் "inner value" என குறிப்பிடப்படுகிறது) கைவிடப்படும்.
///
/// Rust இல் பகிரப்பட்ட குறிப்புகள் இயல்புநிலையாக பிறழ்வை அனுமதிக்காது, மற்றும் `Arc` விதிவிலக்கல்ல: நீங்கள் பொதுவாக ஒரு `Arc` க்குள் ஏதேனும் ஒரு மாற்றக்கூடிய குறிப்பைப் பெற முடியாது.நீங்கள் ஒரு `Arc` மூலம் மாற்ற வேண்டும் என்றால், [`Mutex`][mutex], [`RwLock`][rwlock] அல்லது [`Atomic`][atomic] வகைகளில் ஒன்றைப் பயன்படுத்தவும்.
///
/// ## நூல் பாதுகாப்பு
///
/// [`Rc<T>`] போலல்லாமல், `Arc<T>` அதன் குறிப்பு எண்ணிக்கையில் அணு செயல்பாடுகளைப் பயன்படுத்துகிறது.இது நூல் பாதுகாப்பானது என்று பொருள்.குறைபாடு என்னவென்றால், சாதாரண நினைவக அணுகல்களை விட அணு செயல்பாடுகள் அதிக விலை கொண்டவை.நீங்கள் நூல்களுக்கு இடையில் குறிப்பு-கணக்கிடப்பட்ட ஒதுக்கீடுகளைப் பகிரவில்லை என்றால், குறைந்த மேல்நிலைக்கு [`Rc<T>`] ஐப் பயன்படுத்துங்கள்.
/// [`Rc<T>`] ஒரு பாதுகாப்பான இயல்புநிலை, ஏனெனில் நூல்களுக்கு இடையில் ஒரு [`Rc<T>`] ஐ அனுப்பும் எந்த முயற்சியையும் கம்பைலர் பிடிக்கும்.
/// இருப்பினும், நூலக நுகர்வோருக்கு அதிக நெகிழ்வுத்தன்மையைக் கொடுப்பதற்காக ஒரு நூலகம் `Arc<T>` ஐத் தேர்வுசெய்யலாம்.
///
/// `Arc<T>` `T` [`Send`] மற்றும் [`Sync`] ஐ செயல்படுத்தும் வரை [`Send`] மற்றும் [`Sync`] ஐ செயல்படுத்தும்.
/// நூல்-பாதுகாப்பான வகை `T` ஐ `Arc<T>` இல் ஏன் நூல்-பாதுகாப்பாக வைக்க முடியாது?இது முதலில் சற்று எதிர் உள்ளுணர்வாக இருக்கலாம்: எல்லாவற்றிற்கும் மேலாக, `Arc<T>` நூல் பாதுகாப்பின் புள்ளி இல்லையா?முக்கியமானது இதுதான்: ஒரே தரவின் பல உரிமையைக் கொண்டிருப்பதை `Arc<T>` நூல் பாதுகாப்பாக ஆக்குகிறது, ஆனால் அது அதன் தரவில் நூல் பாதுகாப்பைச் சேர்க்காது.
///
/// `ஆர்க் <` [`ரெஃப்செல்<T>`]`>`.
/// [`RefCell<T>`] [`Sync`] அல்ல, மற்றும் `Arc<T>` எப்போதும் [`Send`] ஆக இருந்தால், `ஆர்க் <` [`RefCell<T>`]`>`அப்படியே இருக்கும்.
/// ஆனால் எங்களுக்கு ஒரு சிக்கல் இருக்கும்:
/// [`RefCell<T>`] நூல் பாதுகாப்பானது அல்ல;இது அணு அல்லாத செயல்பாடுகளைப் பயன்படுத்தி கடன் வாங்கும் எண்ணிக்கையை கண்காணிக்கும்.
///
/// முடிவில், நீங்கள் `Arc<T>` ஐ ஒருவித [`std::sync`] வகையுடன் இணைக்க வேண்டும், அதாவது பொதுவாக [`Mutex<T>`][mutex].
///
/// ## `Weak` உடன் சுழற்சிகளை உடைத்தல்
///
/// சொந்தமில்லாத [`Weak`] சுட்டிக்காட்டி உருவாக்க [`downgrade`][downgrade] முறையைப் பயன்படுத்தலாம்.ஒரு [`Weak`] சுட்டிக்காட்டி ஒரு `Arc` க்கு [`மேம்படுத்தல்`][மேம்படுத்தல்] ஆக இருக்கலாம், ஆனால் ஒதுக்கீட்டில் சேமிக்கப்பட்ட மதிப்பு ஏற்கனவே கைவிடப்பட்டிருந்தால் இது [`None`] ஐ வழங்கும்.
/// வேறு வார்த்தைகளில் கூறுவதானால், `Weak` சுட்டிகள் ஒதுக்கீட்டின் உள்ளே மதிப்பை உயிருடன் வைத்திருக்காது;இருப்பினும், அவர்கள் ஒதுக்கீட்டை (மதிப்பிற்கான ஆதரவுக் கடை) உயிருடன் வைத்திருக்கிறார்கள்.
///
/// `Arc` சுட்டிகள் இடையே ஒரு சுழற்சி ஒருபோதும் ஒதுக்கப்படாது.
/// இந்த காரணத்திற்காக, சுழற்சிகளை உடைக்க [`Weak`] பயன்படுத்தப்படுகிறது.எடுத்துக்காட்டாக, ஒரு மரத்தில் பெற்றோர் முனைகளிலிருந்து குழந்தைகளுக்கு வலுவான `Arc` சுட்டிகள் இருக்கக்கூடும், மேலும் குழந்தைகளிடமிருந்து [`Weak`] சுட்டிகள் பெற்றோரிடமிருந்து திரும்பலாம்.
///
/// # குளோனிங் குறிப்புகள்
///
/// ஏற்கனவே உள்ள குறிப்பு-எண்ணப்பட்ட சுட்டிக்காட்டி இருந்து புதிய குறிப்பை உருவாக்குவது [`Arc<T>`][Arc] மற்றும் [`Weak<T>`][Weak] க்கு செயல்படுத்தப்பட்ட `Clone` trait ஐப் பயன்படுத்தி செய்யப்படுகிறது.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // கீழே உள்ள இரண்டு தொடரியல் சமம்.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, மற்றும் foo அனைத்தும் ஒரே நினைவக இருப்பிடத்தை சுட்டிக்காட்டும் வளைவுகள்
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` `T` ([`Deref`][deref] trait வழியாக) தானாகவே குறைகிறது, எனவே நீங்கள் `Arc<T>` வகை மதிப்பில் `T` இன் முறைகளை அழைக்கலாம்.`T` இன் முறைகளுடன் பெயர் மோதல்களைத் தவிர்க்க, `Arc<T>` இன் முறைகள் தொடர்புடைய செயல்பாடுகளாகும், அவை [fully qualified syntax] ஐப் பயன்படுத்துகின்றன:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `ஆர்க்<T>`Clone` போன்ற traits இன் செயலாக்கங்களும் முழு தகுதி வாய்ந்த தொடரியல் பயன்படுத்தி அழைக்கப்படலாம்.
/// சிலர் முழு தகுதி வாய்ந்த தொடரியல் பயன்படுத்த விரும்புகிறார்கள், மற்றவர்கள் முறை-அழைப்பு தொடரியல் பயன்படுத்த விரும்புகிறார்கள்.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // முறை-அழைப்பு தொடரியல்
/// let arc2 = arc.clone();
/// // முழு தகுதி வாய்ந்த தொடரியல்
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T` க்கு தானாக விலகல் இல்லை, ஏனெனில் உள் மதிப்பு ஏற்கனவே கைவிடப்பட்டிருக்கலாம்.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// நூல்களுக்கு இடையில் மாறாத சில தரவைப் பகிர்தல்:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// இந்த சோதனைகளை நாங்கள் ** இங்கு இயக்கவில்லை என்பதை நினைவில் கொள்க.
// ஒரு நூல் பிரதான நூலைக் காட்டிலும், அதே நேரத்தில் வெளியேறினால் (ஏதோ டெட்லாக்ஸ்) windows பில்டர்கள் அதிருப்தி அடைவார்கள், எனவே இந்த சோதனைகளை இயக்காமல் இதை முற்றிலும் தவிர்க்கிறோம்.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// மாற்றக்கூடிய [`AtomicUsize`] ஐப் பகிர்தல்:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// பொதுவாக குறிப்பு எண்ணிக்கையின் கூடுதல் எடுத்துக்காட்டுகளுக்கு [`rc` documentation][rc_examples] ஐப் பார்க்கவும்.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` நிர்வகிக்கப்பட்ட ஒதுக்கீட்டிற்கு சொந்தமில்லாத குறிப்பைக் கொண்ட [`Arc`] இன் பதிப்பாகும்.
/// `Weak` சுட்டிக்காட்டிக்கு [`upgrade`] ஐ அழைப்பதன் மூலம் ஒதுக்கீடு அணுகப்படுகிறது, இது ஒரு [`விருப்பம்`]`<`[`ஆர்க்`] `<T>>`.
///
/// ஒரு `Weak` குறிப்பு உரிமையை நோக்கி எண்ணாததால், ஒதுக்கீட்டில் சேமிக்கப்பட்ட மதிப்பு கைவிடப்படுவதை இது தடுக்காது, மேலும் `Weak` தானே இன்னும் இருக்கும் மதிப்பு குறித்து எந்த உத்தரவாதமும் அளிக்காது.
///
/// [`மேம்படுத்தல்`] போது இது [`None`] ஐத் தரக்கூடும்.
/// எவ்வாறாயினும், ஒரு `Weak` குறிப்பு * ஒதுக்கீட்டைத் தானே (ஆதரவுக் கடை) ஒதுக்குவதைத் தடுக்கிறது என்பதை நினைவில் கொள்க.
///
/// `Weak` சுட்டிக்காட்டி அதன் உள் மதிப்பு கைவிடப்படுவதைத் தடுக்காமல் [`Arc`] ஆல் நிர்வகிக்கப்படும் ஒதுக்கீட்டின் தற்காலிக குறிப்பை வைத்திருக்க பயனுள்ளதாக இருக்கும்.
/// [`Arc`] சுட்டிகள் இடையே வட்ட குறிப்புகளைத் தடுக்கவும் இது பயன்படுத்தப்படுகிறது, ஏனெனில் பரஸ்பர சொந்தமான குறிப்புகள் ஒருபோதும் [`Arc`] ஐ கைவிட அனுமதிக்காது.
/// எடுத்துக்காட்டாக, ஒரு மரத்தில் பெற்றோர் முனைகளிலிருந்து குழந்தைகளுக்கு வலுவான [`Arc`] சுட்டிகள் இருக்கக்கூடும், மேலும் குழந்தைகளிடமிருந்து `Weak` சுட்டிகள் பெற்றோரிடமிருந்து திரும்பலாம்.
///
/// `Weak` சுட்டிக்காட்டி பெறுவதற்கான பொதுவான வழி [`Arc::downgrade`] ஐ அழைப்பதாகும்.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // என்யூம்களில் இந்த வகையின் அளவை மேம்படுத்த அனுமதிக்க இது ஒரு `NonNull` ஆகும், ஆனால் இது சரியான சுட்டிக்காட்டி அல்ல.
    //
    // `Weak::new` இதை `usize::MAX` ஆக அமைக்கிறது, இதனால் குவியலில் இடத்தை ஒதுக்க தேவையில்லை.
    // RcBox க்கு குறைந்தது 2 சீரமைப்பு இருப்பதால் உண்மையான சுட்டிக்காட்டி எப்போதும் வைத்திருக்கும் மதிப்பு இதுவல்ல.
    // `T: Sized` போது மட்டுமே இது சாத்தியமாகும்;அளவிடப்படாத `T` ஒருபோதும் தொங்கவிடாது.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// இது சாத்தியமான புலம்-மறுசீரமைப்பிற்கு எதிராக repr(C) முதல் future-ஆதாரம் ஆகும், இது பரிமாற்றக்கூடிய உள் வகைகளின் பாதுகாப்பான [into|from]_raw() உடன் தலையிடும்.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX மதிப்பு தற்காலிகமாக "locking" க்கு ஒரு சென்டினலாக செயல்படுகிறது, பலவீனமான சுட்டிகள் மேம்படுத்த அல்லது வலுவானவற்றை தரமிறக்கும் திறன்;இது `make_mut` மற்றும் `get_mut` இல் பந்தயங்களைத் தவிர்க்க பயன்படுகிறது.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// புதிய `Arc<T>` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // பலவீனமான சுட்டிக்காட்டி எண்ணிக்கையை 1 ஆகத் தொடங்கவும், இது அனைத்து வலுவான சுட்டிகள் (kinda) ஆல் வைத்திருக்கும் பலவீனமான சுட்டிக்காட்டி, மேலும் தகவலுக்கு std/rc.rs ஐப் பார்க்கவும்
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// ஒரு பலவீனமான குறிப்பைப் பயன்படுத்தி புதிய `Arc<T>` ஐ உருவாக்குகிறது.
    /// இந்த செயல்பாடு திரும்புவதற்கு முன் பலவீனமான குறிப்பை மேம்படுத்த முயற்சித்தால் `None` மதிப்பு கிடைக்கும்.
    /// இருப்பினும், பலவீனமான குறிப்பு சுதந்திரமாக குளோன் செய்யப்பட்டு பின்னர் பயன்படுத்தப்படலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // ஒற்றை பலவீனமான குறிப்புடன் "uninitialized" நிலையில் உட்புறத்தை உருவாக்குங்கள்.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // பலவீனமான சுட்டிக்காட்டி உரிமையை நாங்கள் விட்டுவிடாதது முக்கியம், இல்லையெனில் `data_fn` திரும்பும் நேரத்தில் நினைவகம் விடுவிக்கப்படலாம்.
        // நாங்கள் உண்மையிலேயே உரிமையை அனுப்ப விரும்பினால், எங்களுக்காக கூடுதல் பலவீனமான சுட்டிக்காட்டி ஒன்றை உருவாக்க முடியும், ஆனால் இது பலவீனமான குறிப்பு எண்ணிக்கையில் கூடுதல் புதுப்பிப்புகளை ஏற்படுத்தும், இல்லையெனில் தேவையில்லை.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // இப்போது நாம் உள் மதிப்பை சரியாக துவக்கி, பலவீனமான குறிப்பை வலுவான குறிப்பாக மாற்றலாம்.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // தரவு புலத்திற்கு மேலே உள்ள எழுத்து பூஜ்ஜியமற்ற வலுவான எண்ணிக்கையைக் கவனிக்கும் எந்த நூல்களுக்கும் தெரியும்.
            // எனவே `Weak::upgrade` இல் `compare_exchange_weak` உடன் ஒத்திசைக்க எங்களுக்கு குறைந்தபட்சம் "Release" வரிசைப்படுத்தல் தேவை.
            //
            // "Acquire" வரிசைப்படுத்துதல் தேவையில்லை.
            // `data_fn` இன் சாத்தியமான நடத்தைகளைக் கருத்தில் கொள்ளும்போது, மேம்படுத்த முடியாத `Weak` பற்றிய குறிப்புடன் அது என்ன செய்ய முடியும் என்பதை மட்டுமே நாம் பார்க்க வேண்டும்:
            //
            // - இது `Weak` ஐ * குளோன் செய்யலாம், பலவீனமான குறிப்பு எண்ணிக்கையை அதிகரிக்கும்.
            // - இது அந்த குளோன்களை கைவிடலாம், பலவீனமான குறிப்பு எண்ணிக்கையை குறைக்கிறது (ஆனால் ஒருபோதும் பூஜ்ஜியத்திற்கு).
            //
            // இந்த பக்க விளைவுகள் எந்த வகையிலும் நம்மை பாதிக்காது, பாதுகாப்பான குறியீட்டால் மட்டும் வேறு எந்த பக்க விளைவுகளும் சாத்தியமில்லை.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // வலுவான குறிப்புகள் கூட்டாக பகிரப்பட்ட பலவீனமான குறிப்பை வைத்திருக்க வேண்டும், எனவே எங்கள் பழைய பலவீனமான குறிப்பிற்கான அழிப்பாளரை இயக்க வேண்டாம்.
        //
        mem::forget(weak);
        strong
    }

    /// ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய `Arc` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// நினைவகம் `0` பைட்டுகளால் நிரப்பப்பட்ட நிலையில், ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய `Arc` ஐ உருவாக்குகிறது.
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// புதிய `Pin<Arc<T>>` ஐ உருவாக்குகிறது.
    /// `T` `Unpin` ஐ செயல்படுத்தவில்லை என்றால், `data` நினைவகத்தில் பொருத்தப்பட்டு நகர்த்த முடியாது.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// புதிய `Arc<T>` ஐ உருவாக்குகிறது, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // பலவீனமான சுட்டிக்காட்டி எண்ணிக்கையை 1 ஆகத் தொடங்கவும், இது அனைத்து வலுவான சுட்டிகள் (kinda) ஆல் வைத்திருக்கும் பலவீனமான சுட்டிக்காட்டி, மேலும் தகவலுக்கு std/rc.rs ஐப் பார்க்கவும்
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய `Arc` ஐ உருவாக்குகிறது, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய `Arc` ஐ உருவாக்குகிறது, நினைவகம் `0` பைட்டுகளால் நிரப்பப்பட்டு, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது.
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Arc` சரியாக ஒரு வலுவான குறிப்பைக் கொண்டிருந்தால், உள் மதிப்பை வழங்குகிறது.
    ///
    /// இல்லையெனில், ஒரு [`Err`] அனுப்பப்பட்ட அதே `Arc` உடன் திரும்பும்.
    ///
    ///
    /// சிறந்த பலவீனமான குறிப்புகள் இருந்தாலும் இது வெற்றி பெறும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // மறைமுகமான வலுவான-பலவீனமான குறிப்பை சுத்தம் செய்ய பலவீனமான சுட்டிக்காட்டி செய்யுங்கள்
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய அணு குறிப்பு-எண்ணப்பட்ட துண்டுகளை உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// நினைவகம் `0` பைட்டுகளால் நிரப்பப்பட்ட நிலையில், ஆரம்பிக்கப்படாத உள்ளடக்கங்களுடன் புதிய அணு குறிப்பு-கணக்கிடப்பட்ட துண்டுகளை உருவாக்குகிறது.
    ///
    ///
    /// இந்த முறையின் சரியான மற்றும் தவறான பயன்பாட்டின் எடுத்துக்காட்டுகளுக்கு [`MaybeUninit::zeroed`][zeroed] ஐப் பார்க்கவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` ஆக மாற்றுகிறது.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ஐப் போலவே, உள் மதிப்பு உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளது என்பதை உறுதிப்படுத்துவது அழைப்பாளரின் பொறுப்பாகும்.
    ///
    /// உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது உடனடி வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` ஆக மாற்றுகிறது.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ஐப் போலவே, உள் மதிப்பு உண்மையில் துவக்கப்பட்ட நிலையில் உள்ளது என்பதை உறுதிப்படுத்துவது அழைப்பாளரின் பொறுப்பாகும்.
    ///
    /// உள்ளடக்கம் இன்னும் முழுமையாக துவக்கப்படாதபோது இதை அழைப்பது உடனடி வரையறுக்கப்படாத நடத்தைக்கு காரணமாகிறது.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ஒத்திவைக்கப்பட்ட துவக்கம்:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// `Arc` ஐப் பயன்படுத்துகிறது, மூடப்பட்ட சுட்டிக்காட்டி திருப்பித் தருகிறது.
    ///
    /// நினைவக கசிவைத் தவிர்க்க, சுட்டிக்காட்டி [`Arc::from_raw`] ஐப் பயன்படுத்தி `Arc` க்கு மாற்றப்பட வேண்டும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// தரவுக்கு மூல சுட்டிக்காட்டி வழங்குகிறது.
    ///
    /// எண்ணிக்கைகள் எந்த வகையிலும் பாதிக்கப்படுவதில்லை மற்றும் `Arc` நுகரப்படுவதில்லை.
    /// `Arc` இல் வலுவான எண்ணிக்கைகள் இருக்கும் வரை சுட்டிக்காட்டி செல்லுபடியாகும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // பாதுகாப்பு: இது Deref::deref அல்லது RcBoxPtr::inner வழியாக செல்ல முடியாது, ஏனெனில்
        // எ.கா. போன்ற raw/mut ஆதாரத்தைத் தக்க வைத்துக் கொள்ள இது தேவைப்படுகிறது
        // `get_mut` `from_raw` மூலம் Rc மீட்டெடுக்கப்பட்ட பிறகு சுட்டிக்காட்டி மூலம் எழுத முடியும்.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// மூல சுட்டிக்காட்டி இருந்து ஒரு `Arc<T>` ஐ உருவாக்குகிறது.
    ///
    /// மூல சுட்டிக்காட்டி முன்பு [`Arc<U>::into_raw`][into_raw] க்கு அழைப்பின் மூலம் திருப்பி அனுப்பப்பட்டிருக்க வேண்டும், அங்கு `U` ஆனது `T` இன் அதே அளவு மற்றும் சீரமைப்பைக் கொண்டிருக்க வேண்டும்.
    /// `U` `T` ஆக இருந்தால் இது அற்பமான உண்மை.
    /// `U` என்பது `T` அல்ல, அதே அளவு மற்றும் சீரமைப்பு இருந்தால், இது அடிப்படையில் வெவ்வேறு வகைகளின் குறிப்புகளை மாற்றுவதைப் போன்றது என்பதை நினைவில் கொள்க.
    /// இந்த வழக்கில் என்ன கட்டுப்பாடுகள் பொருந்தும் என்பது பற்றிய கூடுதல் தகவலுக்கு [`mem::transmute`][transmute] ஐப் பார்க்கவும்.
    ///
    /// `from_raw` இன் பயனர் `T` இன் ஒரு குறிப்பிட்ட மதிப்பு ஒரு முறை மட்டுமே கைவிடப்படுவதை உறுதி செய்ய வேண்டும்.
    ///
    /// இந்த செயல்பாடு பாதுகாப்பற்றது, ஏனெனில் முறையற்ற பயன்பாடு நினைவக பாதுகாப்பிற்கு வழிவகுக்கும், திரும்பிய `Arc<T>` ஒருபோதும் அணுகப்படாவிட்டாலும் கூட.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // கசிவைத் தடுக்க `Arc` க்கு மாற்றவும்.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` க்கான கூடுதல் அழைப்புகள் நினைவகம்-பாதுகாப்பற்றதாக இருக்கும்.
    /// }
    ///
    /// // `x` மேலே உள்ள நோக்கத்திலிருந்து வெளியேறும்போது நினைவகம் விடுவிக்கப்பட்டது, எனவே `x_ptr` இப்போது தொங்கிக்கொண்டிருக்கிறது!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // அசல் ஆர்க்இன்னரைக் கண்டுபிடிக்க ஆஃப்செட்டை மாற்றியமைக்கவும்.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// இந்த ஒதுக்கீட்டில் புதிய [`Weak`] சுட்டிக்காட்டி உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // இந்த தளர்வானது சரி, ஏனென்றால் கீழே உள்ள CAS இல் உள்ள மதிப்பை நாங்கள் சரிபார்க்கிறோம்.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // பலவீனமான கவுண்டர் தற்போது "locked" ஆக இருக்கிறதா என்று சோதிக்கவும்;அப்படியானால், சுழற்று.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: இந்த குறியீடு தற்போது வழிதல் சாத்தியத்தை புறக்கணிக்கிறது
            // usize::MAX க்குள்;பொதுவாக Rc மற்றும் Arc இரண்டையும் வழிதல் சமாளிக்க சரிசெய்ய வேண்டும்.
            //

            // Clone() உடன் போலல்லாமல், இது `is_unique` இலிருந்து வரும் எழுத்துடன் ஒத்திசைக்க ஒரு அக்வைர் வாசிப்பாக இருக்க வேண்டும், இதனால் அந்த எழுத்துக்கு முந்தைய நிகழ்வுகள் இந்த வாசிப்புக்கு முன்பே நடக்கும்.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // தொங்கும் பலவீனத்தை நாங்கள் உருவாக்கவில்லை என்பதை உறுதிப்படுத்திக் கொள்ளுங்கள்
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// இந்த ஒதுக்கீட்டிற்கு [`Weak`] சுட்டிகளின் எண்ணிக்கையைப் பெறுகிறது.
    ///
    /// # Safety
    ///
    /// இந்த முறை தானே பாதுகாப்பானது, ஆனால் அதை சரியாகப் பயன்படுத்துவதற்கு கூடுதல் கவனிப்பு தேவை.
    /// மற்றொரு நூல் எந்த நேரத்திலும் பலவீனமான எண்ணிக்கையை மாற்றலாம், இந்த முறையை அழைப்பதற்கும் அதன் விளைவாக செயல்படுவதற்கும் இடையில் சாத்தியம் உள்ளது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // இந்த கூற்று தீர்மானகரமானது, ஏனெனில் நாங்கள் நூல்களுக்கு இடையில் `Arc` அல்லது `Weak` ஐப் பகிரவில்லை.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // பலவீனமான எண்ணிக்கை தற்போது பூட்டப்பட்டிருந்தால், பூட்டை எடுப்பதற்கு முன்பு எண்ணிக்கையின் மதிப்பு 0 ஆக இருந்தது.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// இந்த ஒதுக்கீட்டில் வலுவான (`Arc`) சுட்டிகளின் எண்ணிக்கையைப் பெறுகிறது.
    ///
    /// # Safety
    ///
    /// இந்த முறை தானே பாதுகாப்பானது, ஆனால் அதை சரியாகப் பயன்படுத்துவதற்கு கூடுதல் கவனிப்பு தேவை.
    /// மற்றொரு நூல் எந்த நேரத்திலும் வலுவான எண்ணிக்கையை மாற்றலாம், இந்த முறையை அழைப்பதற்கும் அதன் விளைவாக செயல்படுவதற்கும் இடையில் சாத்தியம் உள்ளது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // இந்த கூற்று தீர்மானகரமானது, ஏனெனில் நாங்கள் நூல்களுக்கு இடையில் `Arc` ஐப் பகிரவில்லை.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// வழங்கப்பட்ட சுட்டிக்காட்டிடன் தொடர்புடைய `Arc<T>` இல் வலுவான குறிப்பு எண்ணிக்கையை ஒவ்வொன்றாக அதிகரிக்கிறது.
    ///
    /// # Safety
    ///
    /// சுட்டிக்காட்டி `Arc::into_raw` மூலம் பெறப்பட்டிருக்க வேண்டும், மேலும் அதனுடன் தொடர்புடைய `Arc` நிகழ்வு செல்லுபடியாகும் (அதாவது
    /// இந்த முறையின் காலத்திற்கு வலுவான எண்ணிக்கை குறைந்தது 1 ஆக இருக்க வேண்டும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // இந்த கூற்று தீர்மானகரமானது, ஏனெனில் நாங்கள் நூல்களுக்கு இடையில் `Arc` ஐப் பகிரவில்லை.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // ஆர்க்கைத் தக்க வைத்துக் கொள்ளுங்கள், ஆனால் மேனுவலி டிராப்பில் போர்த்துவதன் மூலம் மறு கணக்கைத் தொடாதீர்கள்
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // இப்போது மறு கணக்கீட்டை அதிகரிக்கவும், ஆனால் புதிய மறு கணக்கையும் கைவிட வேண்டாம்
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// வழங்கப்பட்ட சுட்டிக்காட்டிடன் தொடர்புடைய `Arc<T>` இல் வலுவான குறிப்பு எண்ணிக்கையை ஒவ்வொன்றாகக் குறைக்கிறது.
    ///
    /// # Safety
    ///
    /// சுட்டிக்காட்டி `Arc::into_raw` மூலம் பெறப்பட்டிருக்க வேண்டும், மேலும் அதனுடன் தொடர்புடைய `Arc` நிகழ்வு செல்லுபடியாகும் (அதாவது
    /// வலுவான எண்ணிக்கையானது குறைந்தபட்சம் 1) இந்த முறையைத் தொடங்கும்போது இருக்க வேண்டும்.
    /// இறுதி `Arc` மற்றும் ஆதரவு சேமிப்பிடத்தை வெளியிட இந்த முறையைப் பயன்படுத்தலாம், ஆனால் இறுதி `Arc` வெளியிடப்பட்ட பிறகு ** அழைக்கப்படக்கூடாது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // `Arc` ஐ நூல்களுக்கு இடையில் நாங்கள் பகிர்ந்து கொள்ளாததால் அந்த கூற்றுக்கள் தீர்மானகரமானவை.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // இந்த பாதுகாப்பற்றது பரவாயில்லை, ஏனெனில் இந்த வில் உயிருடன் இருக்கும்போது உள் சுட்டிக்காட்டி செல்லுபடியாகும் என்று எங்களுக்கு உத்தரவாதம் அளிக்கப்படுகிறது.
        // மேலும், `ArcInner` கட்டமைப்பே `Sync` என்பதை நாங்கள் அறிவோம், ஏனெனில் உள் தரவு `Sync` ஆகவும் உள்ளது, எனவே இந்த உள்ளடக்கங்களுக்கு மாறாத சுட்டிக்காட்டிக்கு நாங்கள் கடன் வழங்குகிறோம்.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` இன் இன்லைன் பகுதி.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // பெட்டி ஒதுக்கீட்டை நாங்கள் விடுவிக்காவிட்டாலும், இந்த நேரத்தில் தரவை அழிக்கவும் (பலவீனமான சுட்டிகள் இன்னும் சுற்றி இருக்கலாம்).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // அனைத்து வலுவான குறிப்புகளால் கூட்டாக வைத்திருக்கும் பலவீனமான ref ஐ கைவிடவும்
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// இரண்டு `ஆர்க்`களும் ஒரே ஒதுக்கீட்டை சுட்டிக்காட்டினால் ([`ptr::eq`] ஐ ஒத்த நரம்பில்) `true` ஐ வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// மதிப்பு வழங்கப்பட்ட தளவமைப்பு இருக்கும் இடத்தில் அளவிடப்படாத உள் மதிப்புக்கு போதுமான இடவசதியுடன் ஒரு `ArcInner<T>` ஐ ஒதுக்குகிறது.
    ///
    /// `mem_to_arcinner` செயல்பாடு தரவு சுட்டிக்காட்டி மூலம் அழைக்கப்படுகிறது, மேலும் `ArcInner<T>` க்கு ஒரு (கொழுப்பு சாத்தியமான)-பாயிண்டரை திருப்பித் தர வேண்டும்.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // கொடுக்கப்பட்ட மதிப்பு தளவமைப்பைப் பயன்படுத்தி தளவமைப்பைக் கணக்கிடுங்கள்.
        // முன்னதாக, தளவமைப்பு `&*(ptr as* const ArcInner<T>)` வெளிப்பாட்டில் கணக்கிடப்பட்டது, ஆனால் இது தவறாக வடிவமைக்கப்பட்ட குறிப்பை உருவாக்கியது (#54908 ஐப் பார்க்கவும்).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// மதிப்பிடப்படாத உள் மதிப்புக்கு போதுமான இடவசதியுடன் ஒரு `ArcInner<T>` ஐ ஒதுக்குகிறது, அங்கு மதிப்பு தளவமைப்பு வழங்கியுள்ளது, ஒதுக்கீடு தோல்வியுற்றால் பிழையைத் தருகிறது.
    ///
    ///
    /// `mem_to_arcinner` செயல்பாடு தரவு சுட்டிக்காட்டி மூலம் அழைக்கப்படுகிறது, மேலும் `ArcInner<T>` க்கு ஒரு (கொழுப்பு சாத்தியமான)-பாயிண்டரை திருப்பித் தர வேண்டும்.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // கொடுக்கப்பட்ட மதிப்பு தளவமைப்பைப் பயன்படுத்தி தளவமைப்பைக் கணக்கிடுங்கள்.
        // முன்னதாக, தளவமைப்பு `&*(ptr as* const ArcInner<T>)` வெளிப்பாட்டில் கணக்கிடப்பட்டது, ஆனால் இது தவறாக வடிவமைக்கப்பட்ட குறிப்பை உருவாக்கியது (#54908 ஐப் பார்க்கவும்).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ஆர்க்இன்னரைத் தொடங்கவும்
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// அளவிடப்படாத உள் மதிப்புக்கு போதுமான இடவசதியுடன் ஒரு `ArcInner<T>` ஐ ஒதுக்குகிறது.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // கொடுக்கப்பட்ட மதிப்பைப் பயன்படுத்தி `ArcInner<T>` க்கு ஒதுக்கவும்.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // மதிப்பை பைட்டுகளாக நகலெடுக்கவும்
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // ஒதுக்கீட்டை அதன் உள்ளடக்கங்களை கைவிடாமல் விடுவிக்கவும்
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// கொடுக்கப்பட்ட நீளத்துடன் ஒரு `ArcInner<[T]>` ஐ ஒதுக்குகிறது.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// துண்டுகளிலிருந்து உறுப்புகளை புதிதாக ஒதுக்கப்பட்ட ஆர்க் <\[T\]> இல் நகலெடுக்கவும்
    ///
    /// பாதுகாப்பற்றது, ஏனெனில் அழைப்பவர் உரிமையை எடுக்க வேண்டும் அல்லது `T: Copy` ஐ பிணைக்க வேண்டும்.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// ஒரு குறிப்பிட்ட அளவு என்று அறியப்படும் ஒரு ஈரேட்டரிலிருந்து ஒரு `Arc<[T]>` ஐ உருவாக்குகிறது.
    ///
    /// அளவு தவறாக இருக்க வேண்டும் என்றால் நடத்தை வரையறுக்கப்படவில்லை.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // டி கூறுகளை குளோனிங் செய்யும் போது Panic காவலர்.
        // panic ஏற்பட்டால், புதிய ஆர்க்இன்னரில் எழுதப்பட்ட கூறுகள் கைவிடப்படும், பின்னர் நினைவகம் விடுவிக்கப்படும்.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // முதல் உறுப்புக்கான சுட்டிக்காட்டி
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // அனைத்தும் தெளிவாக.புதிய ஆர்க்இன்னரை விடுவிக்காததால் காவலரை மறந்து விடுங்கள்.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` க்கு பயன்படுத்தப்படும் trait சிறப்பு.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` சுட்டிக்காட்டி ஒரு குளோன் செய்கிறது.
    ///
    /// இது அதே ஒதுக்கீட்டிற்கு மற்றொரு சுட்டிக்காட்டி உருவாக்குகிறது, இது வலுவான குறிப்பு எண்ணிக்கையை அதிகரிக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // அசல் குறிப்பைப் பற்றிய அறிவு பிற நூல்களைப் பொருளை தவறாக நீக்குவதைத் தடுப்பதால், தளர்வான வரிசையைப் பயன்படுத்துவது இங்கே சரி.
        //
        // [Boost documentation][1] இல் விளக்கப்பட்டுள்ளபடி, குறிப்பு கவுண்டரை அதிகரிப்பது எப்போதுமே memory_order_relaxed உடன் செய்யப்படலாம்: ஒரு பொருளின் புதிய குறிப்புகள் ஏற்கனவே இருக்கும் குறிப்பிலிருந்து மட்டுமே உருவாக்கப்பட முடியும், மேலும் ஏற்கனவே உள்ள ஒரு குறிப்பை ஒரு நூலிலிருந்து இன்னொரு நூலுக்கு அனுப்புவது ஏற்கனவே தேவையான ஒத்திசைவை வழங்க வேண்டும்.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // எவ்வாறாயினும், யாராவது `மெம்: : மறந்துவிடும் ஆர்க்ஸ் 'ஆக இருந்தால், பாரிய மறுதொடக்கங்களுக்கு எதிராக நாம் பாதுகாக்க வேண்டும்.
        // நாங்கள் இதைச் செய்யாவிட்டால், எண்ணிக்கை நிரம்பி வழிகிறது மற்றும் பயனர்கள் இலவசமாகப் பயன்படுத்துவார்கள்.
        // குறிப்பு எண்ணிக்கையை ஒரே நேரத்தில் அதிகரிக்கும் ~2 பில்லியன் நூல்கள் இல்லை என்ற அனுமானத்தின் அடிப்படையில் நாங்கள் `isize::MAX` க்கு இனரீதியாக நிறைவு செய்கிறோம்.
        //
        // இந்த branch எந்தவொரு யதார்த்தமான நிரலிலும் ஒருபோதும் எடுக்கப்படாது.
        //
        // அத்தகைய திட்டம் நம்பமுடியாத அளவிற்கு சீரழிந்துவிட்டதால் நாங்கள் அதை நிறுத்துகிறோம், அதை ஆதரிக்க நாங்கள் கவலைப்படவில்லை.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// கொடுக்கப்பட்ட `Arc` இல் மாற்றக்கூடிய குறிப்பை உருவாக்குகிறது.
    ///
    /// அதே ஒதுக்கீட்டில் பிற `Arc` அல்லது [`Weak`] சுட்டிகள் இருந்தால், `make_mut` ஒரு புதிய ஒதுக்கீட்டை உருவாக்கி, தனித்துவமான உரிமையை உறுதிப்படுத்த உள் மதிப்பில் [`clone`][clone] ஐ அழைக்கும்.
    /// இது குளோன்-ஆன்-ரைட் என்றும் குறிப்பிடப்படுகிறது.
    ///
    /// இது [`Rc::make_mut`] இன் நடத்தையிலிருந்து வேறுபடுகிறது என்பதை நினைவில் கொள்க, இது மீதமுள்ள `Weak` சுட்டிகள் பிரிக்கிறது.
    ///
    /// [`get_mut`][get_mut] ஐயும் காண்க, இது குளோனிங்கை விட தோல்வியடையும்.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // எதையும் குளோன் செய்ய மாட்டேன்
    /// let mut other_data = Arc::clone(&data); // உள் தரவை குளோன் செய்ய மாட்டேன்
    /// *Arc::make_mut(&mut data) += 1;         // உள் தரவை குளோன் செய்கிறது
    /// *Arc::make_mut(&mut data) += 1;         // எதையும் குளோன் செய்ய மாட்டேன்
    /// *Arc::make_mut(&mut other_data) *= 2;   // எதையும் குளோன் செய்ய மாட்டேன்
    ///
    /// // இப்போது `data` மற்றும் `other_data` ஆகியவை வெவ்வேறு ஒதுக்கீடுகளை சுட்டிக்காட்டுகின்றன.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // வலுவான குறிப்பு மற்றும் பலவீனமான குறிப்பு இரண்டையும் நாங்கள் வைத்திருக்கிறோம் என்பதை நினைவில் கொள்க.
        // எனவே, எங்கள் வலுவான குறிப்பை வெளியிடுவது, தானாகவே, நினைவகத்தை ஒதுக்கி வைக்காது.
        //
        // X001 க்கு வெளியீடு எழுதுவதற்கு முன்பு (அதாவது குறைவுகள்) `weak` க்கு ஏதேனும் எழுதுகிறோம் என்பதை உறுதிப்படுத்த அக்வைர் பயன்படுத்தவும்.
        // நாங்கள் பலவீனமான எண்ணிக்கையை வைத்திருப்பதால், ஆர்க்இன்னர் தன்னை ஒதுக்கி வைக்க வாய்ப்பில்லை.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // மற்றொரு வலுவான சுட்டிக்காட்டி உள்ளது, எனவே நாம் குளோன் செய்ய வேண்டும்.
            // குளோன் செய்யப்பட்ட மதிப்பை நேரடியாக எழுத அனுமதிக்க நினைவகத்தை முன்கூட்டியே ஒதுக்கவும்.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // மேற்சொன்னவற்றில் தளர்வானது போதுமானது, ஏனெனில் இது அடிப்படையில் ஒரு தேர்வுமுறை: பலவீனமான சுட்டிகள் கைவிடப்படுவதால் நாங்கள் எப்போதும் பந்தயத்தில் ஈடுபடுகிறோம்.
            // மோசமான வழக்கு, தேவையில்லாமல் ஒரு புதிய ஆர்க்கை ஒதுக்குகிறோம்.
            //

            // கடைசி வலுவான ரெஃப்பை நாங்கள் அகற்றினோம், ஆனால் கூடுதல் பலவீனமான குறிப்புகள் உள்ளன.
            // உள்ளடக்கங்களை புதிய ஆர்க்கிற்கு நகர்த்துவோம், மற்ற பலவீனமான குறிப்புகளை செல்லாததாக்குவோம்.
            //

            // பலவீனமான எண்ணிக்கையை ஒரு வலுவான குறிப்பைக் கொண்ட ஒரு நூலால் மட்டுமே பூட்ட முடியும் என்பதால், `weak` இன் வாசிப்பு usize::MAX (அதாவது பூட்டப்பட்ட) ஐ வழங்க முடியாது என்பதை நினைவில் கொள்க.
            //
            //

            // எங்கள் சொந்த உள்ளார்ந்த பலவீனமான சுட்டிக்காட்டிக்கு பொருள் கொடுங்கள், இதனால் ஆர்க்இன்னரை தேவைக்கேற்ப சுத்தம் செய்யலாம்.
            //
            let _weak = Weak { ptr: this.ptr };

            // தரவைத் திருட முடியும், மீதமுள்ளவை பலவீனமானவை
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // நாங்கள் எந்தவொரு வகையிலும் ஒரே குறிப்பாக இருந்தோம்;வலுவான ref எண்ணிக்கையை மீண்டும் மேலேறவும்.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` ஐப் போலவே, பாதுகாப்பற்ற தன்மையும் சரி, ஏனென்றால் எங்கள் குறிப்பு தொடங்குவதற்கு தனித்துவமானது, அல்லது உள்ளடக்கங்களை குளோன் செய்தபின் ஒன்றாக மாறியது.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// அதே ஒதுக்கீட்டில் வேறு `Arc` அல்லது [`Weak`] சுட்டிகள் இல்லாவிட்டால், கொடுக்கப்பட்ட `Arc` இல் மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    ///
    /// இல்லையெனில் [`None`] ஐ வழங்குகிறது, ஏனெனில் பகிரப்பட்ட மதிப்பை மாற்றுவது பாதுகாப்பானது அல்ல.
    ///
    /// [`make_mut`][make_mut] ஐயும் காண்க, இது மற்ற சுட்டிகள் இருக்கும்போது உள் மதிப்பை [`clone`][clone] செய்யும்.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // இந்த பாதுகாப்பற்றது பரவாயில்லை, ஏனென்றால் திரும்பிய சுட்டிக்காட்டி *ஒரே* சுட்டிக்காட்டி என்பது எப்போதுமே T க்குத் திருப்பித் தரப்படும்.
            // எங்கள் குறிப்பு எண்ணிக்கை இந்த கட்டத்தில் 1 ஆக இருக்கும் என்று உத்தரவாதம் அளிக்கப்படுகிறது, மேலும் ஆர்க் தன்னை `mut` ஆக இருக்க வேண்டும், எனவே உள் தரவுக்கான சாத்தியமான ஒரே குறிப்பை நாங்கள் திருப்பித் தருகிறோம்.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// எந்தவொரு காசோலையும் இல்லாமல், கொடுக்கப்பட்ட `Arc` இல் மாற்றக்கூடிய குறிப்பை வழங்குகிறது.
    ///
    /// [`get_mut`] ஐயும் காண்க, இது பாதுகாப்பானது மற்றும் பொருத்தமான காசோலைகளை செய்கிறது.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// அதே ஒதுக்கீட்டிற்கான வேறு எந்த `Arc` அல்லது [`Weak`] சுட்டிகள் திரும்பப் பெறப்பட்ட கடனுக்கான காலத்திற்கு குறிப்பிடப்படக்கூடாது.
    ///
    /// இதுபோன்ற சுட்டிகள் எதுவும் இல்லாவிட்டால் இது அற்பமான விஷயமாகும், எடுத்துக்காட்டாக `Arc::new` க்குப் பிறகு உடனடியாக.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" புலங்களை உள்ளடக்கிய ஒரு குறிப்பை * உருவாக்க வேண்டாம் என்பதில் நாங்கள் கவனமாக இருக்கிறோம், ஏனெனில் இது குறிப்பு எண்ணிக்கைகளுக்கு ஒரே நேரத்தில் அணுகலுடன் மாற்றுப்பெயராகும் (எ.கா.
        // வழங்கியது `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// இது அடிப்படை தரவிற்கான தனித்துவமான குறிப்பு (பலவீனமான குறிப்புகள் உட்பட) என்பதை தீர்மானிக்கவும்.
    ///
    ///
    /// இதற்கு பலவீனமான ref எண்ணிக்கையைப் பூட்ட வேண்டும் என்பதை நினைவில் கொள்க.
    fn is_unique(&mut self) -> bool {
        // பலவீனமான சுட்டிக்காட்டி வைத்திருப்பவராக நாங்கள் தோன்றினால் பலவீனமான சுட்டிக்காட்டி எண்ணிக்கையை பூட்டவும்.
        //
        // `weak` எண்ணிக்கையின் குறைவுகளுக்கு முன்னர் (வெளியீட்டைப் பயன்படுத்தும் `Weak::drop` வழியாக) `strong` க்கு (குறிப்பாக `Weak::upgrade` இல்) எந்தவொரு எழுதுதலுடனும் நடக்கும் முன் உறவை இங்கே கையகப்படுத்துதல் லேபிள் உறுதி செய்கிறது.
        // மேம்படுத்தப்பட்ட பலவீனமான ref ஒருபோதும் கைவிடப்படாவிட்டால், இங்குள்ள CAS தோல்வியடையும், எனவே ஒத்திசைக்க நாங்கள் கவலைப்படுவதில்லை.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // `drop` இல் `strong` கவுண்டரின் குறைவுடன் ஒத்திசைக்க இது ஒரு `Acquire` ஆக இருக்க வேண்டும்-கடைசி குறிப்பு கைவிடப்பட்டாலும் நிகழும் ஒரே அணுகல்.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // இங்கே வெளியீட்டு எழுத்து `downgrade` இல் ஒரு வாசிப்புடன் ஒத்திசைக்கிறது, இது `strong` இன் மேலே படித்ததை எழுதுவதற்குப் பிறகு நடப்பதைத் தடுக்கிறது.
            //
            //
            self.inner().weak.store(1, Release); // பூட்டை விடுவிக்கவும்
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` ஐ கைவிடுகிறது.
    ///
    /// இது வலுவான குறிப்பு எண்ணிக்கையை குறைக்கும்.
    /// வலுவான குறிப்பு எண்ணிக்கை பூஜ்ஜியத்தை அடைந்தால், மற்ற குறிப்புகள் (ஏதேனும் இருந்தால்) [`Weak`] மட்டுமே, எனவே நாம் உள் மதிப்பை `drop` செய்கிறோம்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // எதையும் அச்சிடவில்லை
    /// drop(foo2);   // "dropped!" ஐ அச்சிடுகிறது
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` ஏற்கனவே அணு என்பதால், நாம் பொருளை நீக்கப் போகிறார்களே ஒழிய மற்ற நூல்களுடன் ஒத்திசைக்க தேவையில்லை.
        // இதே தர்க்கம் கீழே உள்ள `fetch_sub` க்கு `weak` எண்ணிக்கைக்கு பொருந்தும்.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // தரவின் பயன்பாட்டை மறுவரிசைப்படுத்துவதையும் தரவை நீக்குவதையும் தடுக்க இந்த வேலி தேவைப்படுகிறது.
        // இது `Release` எனக் குறிக்கப்பட்டுள்ளதால், குறிப்பு எண்ணிக்கை குறைவது இந்த `Acquire` வேலியுடன் ஒத்திசைகிறது.
        // தரவின் பயன்பாடு குறிப்பு எண்ணிக்கையைக் குறைப்பதற்கு முன்பு நிகழ்கிறது, இது இந்த வேலிக்கு முன் நிகழ்கிறது, இது தரவை நீக்குவதற்கு முன்பு நிகழ்கிறது.
        //
        // [Boost documentation][1] இல் விளக்கப்பட்டுள்ளபடி,
        //
        // > பொருளில் எந்தவொரு அணுகலையும் ஒன்றில் செயல்படுத்துவது முக்கியம்
        // > நீக்குவதற்கு முன் * நிகழும் நூல் (ஏற்கனவே உள்ள குறிப்பு மூலம்)
        // > வேறு நூலில் உள்ள பொருள்.இது ஒரு "release" ஆல் அடையப்படுகிறது
        // > ஒரு குறிப்பைக் கைவிட்ட பிறகு செயல்பாடு (பொருளுக்கு ஏதேனும் அணுகல்
        // > இந்த குறிப்பு மூலம் வெளிப்படையாக இதற்கு முன்னர் நடந்திருக்க வேண்டும்), மற்றும் ஒரு
        // > "acquire" பொருளை நீக்குவதற்கு முன் செயல்பாடு.
        //
        // குறிப்பாக, ஒரு ஆர்க்கின் உள்ளடக்கங்கள் வழக்கமாக மாறாதவை என்றாலும், உள்துறை ஒரு முடெக்ஸ் போன்றவற்றிற்கு எழுதுவது சாத்தியமாகும்<T>.
        // ஒரு முடெக்ஸ் நீக்கப்படும் போது அது பெறப்படவில்லை என்பதால், நூலில் எழுதுவதற்கு அதன் ஒத்திசைவு தர்க்கத்தை நாம் நம்ப முடியாது. நூல் B இல் இயங்கும் ஒரு அழிப்பாளருக்கு இது தெரியும்.
        //
        //
        // இங்குள்ள அக்வைர் வேலி அநேகமாக அக்வைர் சுமை மூலம் மாற்றப்படலாம் என்பதையும் கவனத்தில் கொள்ளுங்கள், இது அதிக போட்டி சூழ்நிலைகளில் செயல்திறனை மேம்படுத்தக்கூடும்.[2] ஐப் பார்க்கவும்.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` ஐ ஒரு கான்கிரீட் வகைக்குக் குறைக்கும் முயற்சி.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// எந்த நினைவகத்தையும் ஒதுக்காமல், புதிய `Weak<T>` ஐ உருவாக்குகிறது.
    /// வருவாய் மதிப்பில் [`upgrade`] ஐ அழைப்பது எப்போதும் [`None`] ஐ வழங்குகிறது.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// தரவுத் துறையைப் பற்றி எந்தவொரு கூற்றும் செய்யாமல் குறிப்பு எண்ணிக்கையை அணுக அனுமதிக்க உதவி வகை.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// இந்த `Weak<T>` ஆல் சுட்டிக்காட்டப்பட்ட `T` பொருளுக்கு மூல சுட்டிக்காட்டி வழங்குகிறது.
    ///
    /// சில வலுவான குறிப்புகள் இருந்தால் மட்டுமே சுட்டிக்காட்டி செல்லுபடியாகும்.
    /// சுட்டிக்காட்டி தொங்கும், வரிசைப்படுத்தப்படாத அல்லது [`null`] இல்லையெனில் இருக்கலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // இரண்டும் ஒரே பொருளை சுட்டிக்காட்டுகின்றன
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // இங்கே வலுவானவர்கள் அதை உயிரோடு வைத்திருக்கிறார்கள், எனவே நாம் இன்னும் பொருளை அணுக முடியும்.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // ஆனால் இனி இல்லை.
    /// // நாம் weak.as_ptr() செய்ய முடியும், ஆனால் சுட்டிக்காட்டி அணுகுவது வரையறுக்கப்படாத நடத்தைக்கு வழிவகுக்கும்.
    /// // assert_eq! ("ஹலோ", பாதுகாப்பற்றது {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // சுட்டிக்காட்டி தொங்கிக்கொண்டிருந்தால், நாங்கள் சென்டினலை நேரடியாக திருப்பித் தருகிறோம்.
            // இது செல்லுபடியாகும் பேலோட் முகவரியாக இருக்க முடியாது, ஏனெனில் பேலோட் குறைந்தபட்சம் ஆர்க்இன்னர் எக்ஸ் 100 எக்ஸ் என சீரமைக்கப்பட்டுள்ளது.
            ptr as *const T
        } else {
            // பாதுகாப்பு: is_dangling தவறானது எனில், சுட்டிக்காட்டி குறைக்க முடியாதது.
            // இந்த கட்டத்தில் பேலோட் கைவிடப்படலாம், மேலும் நாம் ஆதாரத்தை பராமரிக்க வேண்டும், எனவே மூல சுட்டிக்காட்டி கையாளுதலைப் பயன்படுத்தவும்.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` ஐ உட்கொண்டு அதை ஒரு மூல சுட்டிக்காட்டியாக மாற்றுகிறது.
    ///
    /// இது பலவீனமான சுட்டிக்காட்டி மூல சுட்டிக்காட்டியாக மாற்றுகிறது, அதே நேரத்தில் ஒரு பலவீனமான குறிப்பின் உரிமையை பாதுகாக்கிறது (பலவீனமான எண்ணிக்கை இந்த செயல்பாட்டால் மாற்றப்படவில்லை).
    /// இதை [`from_raw`] உடன் `Weak<T>` ஆக மாற்றலாம்.
    ///
    /// [`as_ptr`] உடன் சுட்டிக்காட்டி இலக்கை அணுகுவதற்கான அதே கட்டுப்பாடுகள் பொருந்தும்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// முன்பு [`into_raw`] ஆல் உருவாக்கப்பட்ட மூல சுட்டிக்காட்டி மீண்டும் `Weak<T>` ஆக மாற்றுகிறது.
    ///
    /// இது ஒரு வலுவான குறிப்பைப் பாதுகாப்பாகப் பெற (பின்னர் [`upgrade`] ஐ அழைப்பதன் மூலம்) அல்லது `Weak<T>` ஐ கைவிடுவதன் மூலம் பலவீனமான எண்ணிக்கையை நீக்குவதற்குப் பயன்படுத்தப்படலாம்.
    ///
    /// இது ஒரு பலவீனமான குறிப்பின் உரிமையை எடுக்கும் ([`new`] ஆல் உருவாக்கிய சுட்டிகள் தவிர, இவை எதுவும் சொந்தமாக இல்லை; முறை இன்னும் அவற்றில் இயங்குகிறது).
    ///
    /// # Safety
    ///
    /// சுட்டிக்காட்டி [`into_raw`] இலிருந்து தோன்றியிருக்க வேண்டும், மேலும் அதன் பலவீனமான குறிப்பை இன்னும் வைத்திருக்க வேண்டும்.
    ///
    /// இதை அழைக்கும் நேரத்தில் வலுவான எண்ணிக்கை 0 ஆக இருக்க அனுமதிக்கப்படுகிறது.
    /// ஆயினும்கூட, இது தற்போது ஒரு மூல சுட்டிக்காட்டி என குறிப்பிடப்பட்டுள்ள ஒரு பலவீனமான குறிப்பின் உரிமையை எடுத்துக்கொள்கிறது (இந்த செயல்பாட்டால் பலவீனமான எண்ணிக்கை மாற்றப்படவில்லை) எனவே இது [`into_raw`] க்கு முந்தைய அழைப்போடு இணைக்கப்பட வேண்டும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // கடைசி பலவீனமான எண்ணிக்கையை குறைத்தல்.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // உள்ளீட்டு சுட்டிக்காட்டி எவ்வாறு பெறப்பட்டது என்பதற்கான சூழலுக்கு Weak::as_ptr ஐப் பார்க்கவும்.

        let ptr = if is_dangling(ptr as *mut T) {
            // இது ஒரு பலவீனமான பலவீனமாகும்.
            ptr as *mut ArcInner<T>
        } else {
            // இல்லையெனில், சுட்டிக்காட்டி ஒரு பலவீனமான பலவீனத்திலிருந்து வந்தது என்று எங்களுக்கு உத்தரவாதம்.
            // பாதுகாப்பு: தரவு_ஆஃப்செட் அழைப்பது பாதுகாப்பானது, ஏனெனில் பி.டி.ஆர் ஒரு உண்மையான (சாத்தியமான கைவிடப்பட்ட) டி.
            let offset = unsafe { data_offset(ptr) };
            // இதனால், முழு RcBox ஐப் பெற ஆஃப்செட்டை மாற்றியமைக்கிறோம்.
            // பாதுகாப்பு: சுட்டிக்காட்டி பலவீனத்திலிருந்து தோன்றியது, எனவே இந்த ஆஃப்செட் பாதுகாப்பானது.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // பாதுகாப்பு: அசல் பலவீன சுட்டிக்காட்டினை இப்போது மீட்டெடுத்துள்ளோம், எனவே பலவீனத்தை உருவாக்க முடியும்.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` சுட்டிக்காட்டி ஒரு [`Arc`] க்கு மேம்படுத்த முயற்சிக்கிறது, வெற்றிகரமாக இருந்தால் உள் மதிப்பைக் கைவிடுவதை தாமதப்படுத்துகிறது.
    ///
    ///
    /// உள் மதிப்பு கைவிடப்பட்டிருந்தால் [`None`] ஐ வழங்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // அனைத்து வலுவான சுட்டிகளையும் அழிக்கவும்.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // இந்த செயல்பாடு ஒருபோதும் குறிப்பு எண்ணிக்கையை பூஜ்ஜியத்திலிருந்து ஒன்றிற்கு எடுத்துக்கொள்ளக்கூடாது என்பதால், ஒரு ஃபெட்ச்_ஆடிக்கு பதிலாக வலுவான எண்ணிக்கையை அதிகரிக்க ஒரு CAS லூப்பைப் பயன்படுத்துகிறோம்.
        //
        //
        let inner = self.inner()?;

        // தளர்வான சுமை, ஏனெனில் நாம் கவனிக்கக்கூடிய 0 இன் எந்தவொரு எழுத்தும் நிரலை பூஜ்ஜிய நிலையில் விட்டுவிடுகிறது (எனவே 0 இன் "stale" வாசிப்பு நன்றாக உள்ளது), மற்றும் வேறு எந்த மதிப்பும் கீழே உள்ள CAS வழியாக உறுதிப்படுத்தப்படுகிறது.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // நாங்கள் இதை ஏன் செய்கிறோம் என்பதற்கான `Arc::clone` இல் கருத்துகளைப் பார்க்கவும் (`mem::forget` க்கு).
            if n > MAX_REFCOUNT {
                abort();
            }

            // புதிய மாநிலத்தைப் பற்றி எங்களுக்கு எந்த எதிர்பார்ப்பும் இல்லாததால் தோல்வி வழக்குக்கு ரிலாக்ஸ் சிறந்தது.
            // `Arc::new_cyclic` உடன் ஒத்திசைக்க வெற்றி வழக்கு அவசியம், `Weak` குறிப்புகள் ஏற்கனவே உருவாக்கப்பட்ட பின்னர் உள் மதிப்பை துவக்க முடியும்.
            // அவ்வாறான நிலையில், முழுமையாக துவக்கப்பட்ட மதிப்பை அவதானிக்க எதிர்பார்க்கிறோம்.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // மேலே பூஜ்யம் சரிபார்க்கப்பட்டது
                Err(old) => n = old,
            }
        }
    }

    /// இந்த ஒதுக்கீட்டை சுட்டிக்காட்டும் வலுவான (`Arc`) சுட்டிகளின் எண்ணிக்கையைப் பெறுகிறது.
    ///
    /// [`Weak::new`] ஐப் பயன்படுத்தி `self` உருவாக்கப்பட்டது என்றால், இது 0 ஐத் தரும்.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// இந்த ஒதுக்கீட்டை சுட்டிக்காட்டும் `Weak` சுட்டிகள் எண்ணிக்கையின் தோராயத்தைப் பெறுகிறது.
    ///
    /// [`Weak::new`] ஐப் பயன்படுத்தி `self` உருவாக்கப்பட்டது அல்லது மீதமுள்ள வலுவான சுட்டிகள் இல்லை என்றால், இது 0 ஐத் தரும்.
    ///
    /// # Accuracy
    ///
    /// செயல்படுத்தல் விவரங்கள் காரணமாக, மற்ற நூல்கள் ஏதேனும் `ஆர்க்'களைக் கையாளும் போது அல்லது அதே ஒதுக்கீட்டை சுட்டிக்காட்டும்` பலவீனமானவை 'கையாளும் போது திரும்பிய மதிப்பு இரு திசைகளிலும் 1 ஆக இருக்கும்.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // பலவீனமான எண்ணிக்கையைப் படித்த பிறகு குறைந்தது ஒரு வலுவான சுட்டிக்காட்டி இருப்பதை நாங்கள் கவனித்ததால், பலவீனமான எண்ணிக்கையை நாம் கவனிக்கும்போது மறைமுகமான பலவீனமான குறிப்பு (எந்தவொரு வலுவான குறிப்புகளும் உயிருடன் இருக்கும்போதெல்லாம் உள்ளது) இன்னும் இருப்பதை நாங்கள் அறிவோம்.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// சுட்டிக்காட்டி தொங்கும் போது `None` ஐ வழங்குகிறது மற்றும் ஒதுக்கப்பட்ட `ArcInner` இல்லை, (அதாவது, இந்த `Weak` `Weak::new` ஆல் உருவாக்கப்பட்டபோது).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // "data" புலத்தை உள்ளடக்கிய ஒரு குறிப்பை * உருவாக்க வேண்டாம் என்பதில் நாங்கள் கவனமாக இருக்கிறோம், ஏனெனில் புலம் ஒரே நேரத்தில் மாற்றப்படலாம் (எடுத்துக்காட்டாக, கடைசி `Arc` கைவிடப்பட்டால், தரவு புலம் இடத்தில் கைவிடப்படும்).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// இரண்டு `பலவீனமானவர்கள் ஒரே ஒதுக்கீட்டை ([`ptr::eq`] ஐப் போன்றது) சுட்டிக்காட்டினால் அல்லது இருவரும் எந்த ஒதுக்கீட்டையும் சுட்டிக்காட்டவில்லை என்றால் (அவை `Weak::new()`) உடன் உருவாக்கப்பட்டதால்) `true` ஐ வழங்குகிறது.
    ///
    ///
    /// # Notes
    ///
    /// இது சுட்டிகளை ஒப்பிடுவதால், எந்த ஒதுக்கீட்டையும் சுட்டிக்காட்டாவிட்டாலும், `Weak::new()` ஒருவருக்கொருவர் சமமாக இருக்கும் என்று அர்த்தம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` ஐ ஒப்பிடுகிறது.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// அதே ஒதுக்கீட்டை சுட்டிக்காட்டும் `Weak` சுட்டிக்காட்டி ஒரு குளோனை உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // இது ஏன் தளர்வானது என்பதற்கு Arc::clone() இல் கருத்துகளைப் பார்க்கவும்.
        // இது ஒரு ஃபெட்ச்_ஆட் (பூட்டைப் புறக்கணித்து) பயன்படுத்தலாம், ஏனெனில் பலவீனமான எண்ணிக்கை பூட்டப்பட்டிருக்கும் இடத்தில் *வேறு* பலவீனமான சுட்டிகள் இல்லை.
        //
        // (எனவே இந்த விஷயத்தில் இந்த குறியீட்டை இயக்க முடியாது).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // நாங்கள் இதை ஏன் செய்கிறோம் என்பதற்கான Arc::clone() இல் கருத்துகளைப் பார்க்கவும் (mem::forget க்கு).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// நினைவகத்தை ஒதுக்காமல், புதிய `Weak<T>` ஐ உருவாக்குகிறது.
    /// வருவாய் மதிப்பில் [`upgrade`] ஐ அழைப்பது எப்போதும் [`None`] ஐ வழங்குகிறது.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` சுட்டிக்காட்டி குறைகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // எதையும் அச்சிடவில்லை
    /// drop(foo);        // "dropped!" ஐ அச்சிடுகிறது
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // நாங்கள் கடைசியாக பலவீனமான சுட்டிக்காட்டி என்பதைக் கண்டறிந்தால், தரவை முழுவதுமாக ஒதுக்கி வைப்பதற்கான நேரம் இது.நினைவக வரிசைகளைப் பற்றி Arc::drop() இல் விவாதத்தைக் காண்க
        //
        // இங்கே பூட்டப்பட்ட நிலையைச் சரிபார்க்க வேண்டிய அவசியமில்லை, ஏனென்றால் துல்லியமாக ஒரு பலவீனமான ரெஃப் இருந்தால் மட்டுமே பலவீனமான எண்ணிக்கையை பூட்ட முடியும், அதாவது துளி பின்னர் மீதமுள்ள பலவீனமான ரெஃப்பில் மட்டுமே இயக்க முடியும், இது பூட்டு வெளியான பின்னரே நிகழும்.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// இந்த நிபுணத்துவத்தை நாங்கள் இங்கே செய்கிறோம், ஆனால் `&T` இல் பொதுவான தேர்வுமுறை அல்ல, ஏனென்றால் இது ரெஃப்ஸில் உள்ள அனைத்து சமத்துவ காசோலைகளுக்கும் செலவை சேர்க்கும்.
/// `ஆர்க்` கள் பெரிய மதிப்புகளைச் சேமிக்கப் பயன்படுகின்றன, அவை குளோன் செய்ய மெதுவானவை, ஆனால் சமத்துவத்தை சரிபார்க்க கனமானவை, இதனால் இந்த செலவு மிகவும் எளிதாக செலுத்தப்படும்.
///
/// இது இரண்டு எக்ஸ்&எக்ஸ் குளோன்களைக் கொண்டிருப்பதற்கான வாய்ப்புகள் அதிகம், அவை இரண்டு `&டி`க்களை விட ஒரே மதிப்பைக் குறிக்கும்.
///
/// `T: Eq` ஒரு `PartialEq` ஆக வேண்டுமென்றே பொருத்தமற்றதாக இருக்கும்போது மட்டுமே இதை நாம் செய்ய முடியும்.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// இரண்டு `ஆர்க்'களுக்கான சமத்துவம்.
    ///
    /// வெவ்வேறு ஒதுக்கீட்டில் சேமிக்கப்பட்டிருந்தாலும், அவற்றின் உள் மதிப்புகள் சமமாக இருந்தால் இரண்டு `ஆர்க்'கள் சமம்.
    ///
    /// `T` மேலும் `Eq` ஐ செயல்படுத்தினால் (சமத்துவத்தின் நிர்பந்தத்தை குறிக்கிறது), ஒரே ஒதுக்கீட்டை சுட்டிக்காட்டும் இரண்டு `ஆர்க்` கள் எப்போதும் சமமாக இருக்கும்.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// இரண்டு `ஆர்க்'களுக்கான சமத்துவமின்மை.
    ///
    /// இரண்டு `ஆர்க்'களின் உள் மதிப்புகள் சமமற்றதாக இருந்தால் அவை சமமற்றவை.
    ///
    /// `T` ஆனது `Eq` ஐ (சமத்துவத்தின் நிர்பந்தத்தன்மையைக் குறிக்கிறது) செயல்படுத்தினால், ஒரே மதிப்பை சுட்டிக்காட்டும் இரண்டு `ஆர்க்'க்கள் ஒருபோதும் சமமற்றவை அல்ல.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// இரண்டு `ஆர்க்'களுக்கான பகுதி ஒப்பீடு.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `partial_cmp()` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// இரண்டு `ஆர்க்'களுடன் ஒப்பிடுகையில் குறைவாக.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `<` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// இரண்டு `ஆர்க்'களுக்கான ஒப்பீடு 'குறைவாகவோ அல்லது சமமாகவோ'.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `<=` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// இரண்டு `ஆர்க்'களுடன் ஒப்பிடுவதை விட பெரியது.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `>` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// இரண்டு `ஆர்க்'களுக்கான ஒப்பீடு 'விட பெரியது அல்லது சமம்'.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `>=` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// இரண்டு `ஆர்க்'களுக்கான ஒப்பீடு.
    ///
    /// இரண்டையும் அவற்றின் உள் மதிப்புகளில் `cmp()` ஐ அழைப்பதன் மூலம் ஒப்பிடலாம்.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` க்கான `Default` மதிப்புடன் புதிய `Arc<T>` ஐ உருவாக்குகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// குறிப்பு-எண்ணப்பட்ட துண்டுகளை ஒதுக்கி, `v` இன் உருப்படிகளை குளோன் செய்வதன் மூலம் நிரப்பவும்.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// குறிப்பு-எண்ணப்பட்ட `str` ஐ ஒதுக்கி, அதில் `v` ஐ நகலெடுக்கவும்.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// குறிப்பு-எண்ணப்பட்ட `str` ஐ ஒதுக்கி, அதில் `v` ஐ நகலெடுக்கவும்.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// ஒரு பெட்டி பொருளை புதிய, குறிப்பு-கணக்கிடப்பட்ட ஒதுக்கீட்டிற்கு நகர்த்தவும்.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// குறிப்பு-எண்ணப்பட்ட துண்டுகளை ஒதுக்கி, அதில் `v` இன் உருப்படிகளை நகர்த்தவும்.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec அதன் நினைவகத்தை விடுவிக்க அனுமதிக்கவும், ஆனால் அதன் உள்ளடக்கங்களை அழிக்க வேண்டாம்
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator` இல் உள்ள ஒவ்வொரு உறுப்புகளையும் எடுத்து அதை `Arc<[T]>` இல் சேகரிக்கிறது.
    ///
    /// # செயல்திறன் பண்புகள்
    ///
    /// ## பொது வழக்கு
    ///
    /// பொதுவான வழக்கில், `Arc<[T]>` இல் சேகரிப்பது முதலில் `Vec<T>` இல் சேகரிப்பதன் மூலம் செய்யப்படுகிறது.அதாவது, பின்வருவனவற்றை எழுதும்போது:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// இது நாங்கள் எழுதியது போல் செயல்படுகிறது:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // முதல் ஒதுக்கீடு இங்கே நடக்கிறது.
    ///     .into(); // `Arc<[T]>` க்கான இரண்டாவது ஒதுக்கீடு இங்கே நடக்கிறது.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// இது `Vec<T>` ஐ நிர்மாணிக்க தேவையான பல மடங்கு ஒதுக்குகிறது, பின்னர் இது `Vec<T>` ஐ `Arc<[T]>` ஆக மாற்ற ஒரு முறை ஒதுக்கப்படும்.
    ///
    ///
    /// ## அறியப்பட்ட நீளத்தை உருவாக்குபவர்கள்
    ///
    /// உங்கள் `Iterator` `TrustedLen` ஐ செயல்படுத்தி சரியான அளவைக் கொண்டிருக்கும்போது, `Arc<[T]>` க்கு ஒற்றை ஒதுக்கீடு செய்யப்படும்.உதாரணத்திற்கு:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // ஒரே ஒரு ஒதுக்கீடு இங்கே நடக்கிறது.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>` இல் சேகரிக்கப் பயன்படும் சிறப்பு trait.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // ஒரு `TrustedLen` ஐரேட்டருக்கு இதுதான்.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // பாதுகாப்பு: ஈரேட்டருக்கு சரியான நீளம் இருப்பதை உறுதி செய்ய வேண்டும், எங்களிடம் உள்ளது.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // இயல்பான செயலாக்கத்திற்கு மீண்டும் விழவும்.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// ஒரு சுட்டிக்காட்டிக்குப் பின்னால் செலுத்தும் சுமைக்கு `ArcInner` க்குள் ஆஃப்செட்டைப் பெறுங்கள்.
///
/// # Safety
///
/// சுட்டிக்காட்டி T இன் முன்னர் செல்லுபடியாகும் நிகழ்வை சுட்டிக்காட்ட வேண்டும் (மற்றும் சரியான மெட்டாடேட்டாவைக் கொண்டிருக்க வேண்டும்), ஆனால் T ஐ கைவிட அனுமதிக்கப்படுகிறது.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // அளவிடப்படாத மதிப்பை ஆர்க்இன்னரின் முடிவில் சீரமைக்கவும்.
    // RcBox repr(C) என்பதால், இது எப்போதும் நினைவகத்தின் கடைசி புலமாக இருக்கும்.
    // பாதுகாப்பு: அளவிடப்படாத வகைகள் மட்டுமே துண்டுகள், trait பொருள்கள்,
    // மற்றும் வெளிப்புற வகைகள், align_of_val_raw இன் தேவைகளை பூர்த்தி செய்ய உள்ளீட்டு பாதுகாப்பு தேவை தற்போது போதுமானது;இது std க்கு வெளியே நம்பப்படாத மொழியின் செயல்படுத்தல் விவரம்.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}