#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// புதிய நினைவகத்தின் உள்ளடக்கங்கள் ஆரம்பிக்கப்படவில்லை.
    Uninitialized,
    /// புதிய நினைவகம் பூஜ்ஜியமாக இருக்கும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
    Zeroed,
}

/// சம்பந்தப்பட்ட அனைத்து மூலையில் உள்ள வழக்குகள் பற்றியும் கவலைப்படாமல், குவியலில் நினைவக இடையகத்தை அதிக பணிச்சூழலியல் ரீதியாக ஒதுக்குதல், மறு ஒதுக்கீடு செய்தல் மற்றும் ஒதுக்குதல் ஆகியவற்றிற்கான குறைந்த-நிலை பயன்பாடு.
///
/// Vec மற்றும் VecDeque போன்ற உங்கள் சொந்த தரவு கட்டமைப்புகளை உருவாக்க இந்த வகை சிறந்தது.
/// குறிப்பாக:
///
/// * `Unique::dangling()` ஐ பூஜ்ஜிய அளவிலான வகைகளில் உருவாக்குகிறது.
/// * பூஜ்ஜிய நீள ஒதுக்கீட்டில் `Unique::dangling()` ஐ உருவாக்குகிறது.
/// * `Unique::dangling()` ஐ விடுவிப்பதைத் தவிர்க்கிறது.
/// * திறன் கணக்கீடுகளில் அனைத்து வழிதல்களையும் பிடிக்கிறது (அவற்றை "capacity overflow" panics க்கு ஊக்குவிக்கிறது).
/// * isize::MAX பைட்டுகளுக்கு மேல் ஒதுக்கும் 32-பிட் அமைப்புகளுக்கு எதிராக காவலர்கள்.
/// * உங்கள் நீளத்தை நிரப்புவதற்கு எதிராக காவலர்கள்.
/// * தவறான ஒதுக்கீடுகளுக்கு `handle_alloc_error` ஐ அழைக்கிறது.
/// * ஒரு `ptr::Unique` ஐக் கொண்டுள்ளது, இதனால் பயனருக்கு அனைத்து தொடர்புடைய நன்மைகளையும் வழங்குகிறது.
/// * கிடைக்கக்கூடிய மிகப்பெரிய திறனைப் பயன்படுத்த, ஒதுக்கீட்டாளரிடமிருந்து திரும்பியதைப் பயன்படுத்துகிறது.
///
/// இந்த வகை எப்படியிருந்தாலும் அது நிர்வகிக்கும் நினைவகத்தை ஆய்வு செய்யாது.அதை கைவிடும்போது *அதன் நினைவகத்தை* விடுவிக்கும், ஆனால் அது * அதன் உள்ளடக்கங்களை கைவிட முயற்சிக்காது.
/// ஒரு `RawVec` இன் உள்ளே *சேமிக்கப்பட்ட* உண்மையான விஷயங்களை கையாளுவது `RawVec` இன் பயனரின் பொறுப்பாகும்.
///
/// பூஜ்ஜிய அளவிலான வகைகளின் அதிகரிப்பு எப்போதும் எல்லையற்றது என்பதை நினைவில் கொள்க, எனவே `capacity()` எப்போதும் `usize::MAX` ஐ வழங்குகிறது.
/// `capacity()` நீளத்தை வழங்காது என்பதால், இந்த வகையை `Box<[T]>` உடன் வட்டமிடும் போது நீங்கள் கவனமாக இருக்க வேண்டும் என்பதே இதன் பொருள்.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): இது உள்ளது, ஏனெனில் `#[unstable]` `const fn` கள் `min_const_fn` உடன் ஒத்துப்போக தேவையில்லை, எனவே அவற்றை`min_const_fn` களில் அழைக்கவும் முடியாது.
    ///
    /// நீங்கள் `RawVec<T>::new` அல்லது சார்புகளை மாற்றினால், தயவுசெய்து `min_const_fn` ஐ மீறும் எதையும் அறிமுகப்படுத்தாமல் பார்த்துக் கொள்ளுங்கள்.
    ///
    /// NOTE: இந்த ஹேக்கைத் தவிர்த்து, சில `#[rustc_force_min_const_fn]` பண்புக்கூறுடன் இணக்கத்தை சரிபார்க்கலாம், இது `min_const_fn` உடன் இணக்கம் தேவைப்படுகிறது, ஆனால் `stable(...) const fn`/பயனர் குறியீட்டில் அதை அழைக்க அனுமதிக்காது, `#[rustc_const_unstable(feature = "foo", issue = "01234")]` இருக்கும்போது `foo` ஐ இயக்காது.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// ஒதுக்காமல் மிகப்பெரிய `RawVec` (கணினி குவியலில்) உருவாக்குகிறது.
    /// `T` நேர்மறை அளவைக் கொண்டிருந்தால், இது `0` திறன் கொண்ட `RawVec` ஐ உருவாக்குகிறது.
    /// `T` பூஜ்ஜிய அளவிலானதாக இருந்தால், அது `usize::MAX` திறன் கொண்ட `RawVec` ஐ உருவாக்குகிறது.
    /// தாமதமான ஒதுக்கீட்டை செயல்படுத்த பயனுள்ளதாக இருக்கும்.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// ஒரு `[T; capacity]` க்கான திறன் மற்றும் சீரமைப்பு தேவைகளுடன் ஒரு `RawVec` (கணினி குவியலில்) உருவாக்குகிறது.
    /// இது `capacity` `0` ஆகவோ அல்லது `T` பூஜ்ஜிய அளவிலானதாகவோ இருக்கும்போது `RawVec::new` ஐ அழைப்பதற்கு சமம்.
    /// `T` பூஜ்ஜிய அளவிலானதாக இருந்தால், நீங்கள் கோரிய திறனுடன் `RawVec` ஐப் பெற மாட்டீர்கள் என்பதாகும்.
    ///
    /// # Panics
    ///
    /// கோரப்பட்ட திறன் `isize::MAX` பைட்டுகளை தாண்டினால் Panics.
    ///
    /// # Aborts
    ///
    /// OOM இல் நிறுத்தப்படுகிறது.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` ஐப் போலவே, ஆனால் இடையகமும் பூஜ்ஜியமாக இருப்பதை உறுதி செய்கிறது.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// ஒரு சுட்டிக்காட்டி மற்றும் திறனில் இருந்து ஒரு `RawVec` ஐ மறுகட்டமைக்கிறது.
    ///
    /// # Safety
    ///
    /// `ptr` ஒதுக்கப்பட வேண்டும் (கணினி குவியலில்), மற்றும் கொடுக்கப்பட்ட `capacity` உடன்.
    /// `capacity` அளவு வகைகளுக்கு `isize::MAX` ஐ தாண்டக்கூடாது.(32-பிட் கணினிகளில் மட்டுமே கவலை).
    /// ZST vectors க்கு `usize::MAX` வரை திறன் இருக்கலாம்.
    /// `ptr` மற்றும் `capacity` ஒரு `RawVec` இலிருந்து வந்தால், இது உத்தரவாதம்.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // சிறிய வெக்ஸ் ஊமை.இதற்குச் செல்க:
    // - உறுப்பு அளவு 1 எனில் 8, ஏனெனில் எந்த குவியல் ஒதுக்கீட்டாளர்களும் 8 பைட்டுகளுக்குக் குறைவான கோரிக்கையை குறைந்தது 8 பைட்டுகள் வரை சுற்றி வளைக்க வாய்ப்புள்ளது.
    //
    // - 4 கூறுகள் மிதமான அளவிலானதாக இருந்தால் (<=1 KiB).
    // - 1 இல்லையெனில், மிகக் குறுகிய Vec களுக்கு அதிக இடத்தை வீணாக்குவதைத் தவிர்க்க.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` ஐப் போலவே, ஆனால் திரும்பிய `RawVec` க்கான ஒதுக்கீட்டாளரைத் தேர்ந்தெடுப்பதில் அளவுருவாக்கப்பட்டுள்ளது.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" என்று பொருள்.பூஜ்ஜிய அளவிலான வகைகள் புறக்கணிக்கப்படுகின்றன.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` ஐப் போலவே, ஆனால் திரும்பிய `RawVec` க்கான ஒதுக்கீட்டாளரைத் தேர்ந்தெடுப்பதில் அளவுருவாக்கப்பட்டுள்ளது.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` ஐப் போலவே, ஆனால் திரும்பிய `RawVec` க்கான ஒதுக்கீட்டாளரைத் தேர்ந்தெடுப்பதில் அளவுருவாக்கப்பட்டுள்ளது.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// ஒரு `Box<[T]>` ஐ `RawVec<T>` ஆக மாற்றுகிறது.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// முழு இடையகத்தையும் குறிப்பிட்ட `len` உடன் `Box<[MaybeUninit<T>]>` ஆக மாற்றுகிறது.
    ///
    /// நிகழ்த்தப்பட்ட எந்த `cap` மாற்றங்களையும் இது சரியாக மாற்றியமைக்கும் என்பதை நினைவில் கொள்க.(விவரங்களுக்கு வகை விளக்கத்தைக் காண்க.)
    ///
    /// # Safety
    ///
    /// * `len` மிக சமீபத்தில் கோரப்பட்ட திறனை விட அதிகமாகவோ அல்லது சமமாகவோ இருக்க வேண்டும், மற்றும்
    /// * `len` `self.capacity()` ஐ விட குறைவாகவோ அல்லது சமமாகவோ இருக்க வேண்டும்.
    ///
    /// குறிப்பு, கோரப்பட்ட திறன் மற்றும் `self.capacity()` ஆகியவை வேறுபடக்கூடும், ஏனெனில் ஒரு ஒதுக்கீட்டாளர் ஒட்டுமொத்தமாக ஒதுக்கி, கோரப்பட்டதை விட அதிக மெமரி தொகுதியை வழங்க முடியும்.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // பாதுகாப்புத் தேவையின் ஒரு பாதியை நல்லறிவு-சரிபார்க்கவும் (மற்ற பாதியை எங்களால் சரிபார்க்க முடியாது).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // நாங்கள் இங்கே `unwrap_or_else` ஐத் தவிர்க்கிறோம், ஏனெனில் இது உருவாக்கப்படும் எல்.எல்.வி.எம் ஐ.ஆரின் அளவை அதிகரிக்கிறது.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// ஒரு சுட்டிக்காட்டி, திறன் மற்றும் ஒதுக்கீட்டாளரிடமிருந்து ஒரு `RawVec` ஐ மறுகட்டமைக்கிறது.
    ///
    /// # Safety
    ///
    /// `ptr` ஒதுக்கப்பட வேண்டும் (கொடுக்கப்பட்ட ஒதுக்கீட்டாளர் `alloc` வழியாக), மற்றும் கொடுக்கப்பட்ட `capacity` உடன்.
    /// `capacity` அளவு வகைகளுக்கு `isize::MAX` ஐ தாண்டக்கூடாது.
    /// (32-பிட் கணினிகளில் மட்டுமே கவலை).
    /// ZST vectors க்கு `usize::MAX` வரை திறன் இருக்கலாம்.
    /// `ptr` மற்றும் `capacity` ஆகியவை `alloc` வழியாக உருவாக்கப்பட்ட `RawVec` இலிருந்து வந்தால், இது உத்தரவாதம்.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// ஒதுக்கீட்டின் தொடக்கத்திற்கு ஒரு மூல சுட்டிக்காட்டி கிடைக்கிறது.
    /// `capacity == 0` அல்லது `T` பூஜ்ஜிய அளவிலானதாக இருந்தால் இது `Unique::dangling()` என்பதை நினைவில் கொள்க.
    /// முந்தைய வழக்கில், நீங்கள் கவனமாக இருக்க வேண்டும்.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// ஒதுக்கீட்டின் திறனைப் பெறுகிறது.
    ///
    /// `T` பூஜ்ஜிய அளவிலானதாக இருந்தால் இது எப்போதும் `usize::MAX` ஆக இருக்கும்.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// இந்த `RawVec` ஐ ஆதரிக்கும் ஒதுக்கீட்டாளருக்கு பகிரப்பட்ட குறிப்பை வழங்குகிறது.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // எங்களிடம் ஒதுக்கப்பட்ட நினைவகம் உள்ளது, எனவே எங்கள் தற்போதைய தளவமைப்பைப் பெற இயக்க நேர காசோலைகளைத் தவிர்க்கலாம்.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// `len + additional` உறுப்புகளை வைத்திருக்க இடையகத்தில் குறைந்தபட்சம் போதுமான இடம் இருப்பதை உறுதி செய்கிறது.
    /// இது ஏற்கனவே போதுமான திறனைக் கொண்டிருக்கவில்லை எனில்,*O*(1) நடத்தை பெற போதுமான இடத்தையும் வசதியான மந்தமான இடத்தையும் மறு ஒதுக்கீடு செய்யும்.
    ///
    /// தேவையில்லாமல் panic க்கு தன்னை ஏற்படுத்தினால் இந்த நடத்தை கட்டுப்படுத்தப்படும்.
    ///
    /// `len` `self.capacity()` ஐத் தாண்டினால், இது உண்மையில் கோரப்பட்ட இடத்தை ஒதுக்கத் தவறியிருக்கலாம்.
    /// இது உண்மையில் பாதுகாப்பற்றது அல்ல, ஆனால் இந்த செயல்பாட்டின் நடத்தை சார்ந்திருக்கும் *நீங்கள்* எழுதும் பாதுகாப்பற்ற குறியீடு உடைக்கப்படலாம்.
    ///
    /// `extend` போன்ற மொத்த-புஷ் செயல்பாட்டை செயல்படுத்த இது ஏற்றது.
    ///
    /// # Panics
    ///
    /// புதிய திறன் `isize::MAX` பைட்டுகளை தாண்டினால் Panics.
    ///
    /// # Aborts
    ///
    /// OOM இல் நிறுத்தப்படுகிறது.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // லென் `isize::MAX` ஐத் தாண்டினால் இருப்பு நிறுத்தப்பட்டிருக்கலாம் அல்லது பீதியடைந்திருக்கும், எனவே இது இப்போது சரிபார்க்கப்படாமல் பாதுகாப்பானது.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` போன்றது, ஆனால் பீதி அல்லது கருக்கலைப்புக்கு பதிலாக பிழைகள் மீது திரும்பும்.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// `len + additional` உறுப்புகளை வைத்திருக்க இடையகத்தில் குறைந்தபட்சம் போதுமான இடம் இருப்பதை உறுதி செய்கிறது.
    /// இது ஏற்கனவே இல்லையென்றால், தேவையான குறைந்தபட்ச நினைவகத்தை மறு ஒதுக்கீடு செய்யும்.
    /// பொதுவாக இது தேவையான நினைவகத்தின் அளவாகவே இருக்கும், ஆனால் கொள்கையளவில் ஒதுக்கீட்டாளர் நாம் கேட்டதை விட அதிகமாக திருப்பித் தர இலவசம்.
    ///
    ///
    /// `len` `self.capacity()` ஐத் தாண்டினால், இது உண்மையில் கோரப்பட்ட இடத்தை ஒதுக்கத் தவறியிருக்கலாம்.
    /// இது உண்மையில் பாதுகாப்பற்றது அல்ல, ஆனால் இந்த செயல்பாட்டின் நடத்தை சார்ந்திருக்கும் *நீங்கள்* எழுதும் பாதுகாப்பற்ற குறியீடு உடைக்கப்படலாம்.
    ///
    /// # Panics
    ///
    /// புதிய திறன் `isize::MAX` பைட்டுகளை தாண்டினால் Panics.
    ///
    /// # Aborts
    ///
    /// OOM இல் நிறுத்தப்படுகிறது.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` போன்றது, ஆனால் பீதி அல்லது கருக்கலைப்புக்கு பதிலாக பிழைகள் மீது திரும்பும்.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// ஒதுக்கீட்டை குறிப்பிட்ட தொகைக்குக் குறைக்கிறது.
    /// கொடுக்கப்பட்ட தொகை 0 எனில், உண்மையில் முற்றிலும் விலகிவிடும்.
    ///
    /// # Panics
    ///
    /// கொடுக்கப்பட்ட தொகை தற்போதைய திறனை விட * பெரியதாக இருந்தால் Panics.
    ///
    /// # Aborts
    ///
    /// OOM இல் நிறுத்தப்படுகிறது.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// தேவையான கூடுதல் திறனை பூர்த்தி செய்ய இடையக வளர வேண்டும் என்றால் திரும்பும்.
    /// `grow` இன்லைன் செய்யாமல் இன்லைனிங் ரிசர்வ்-அழைப்புகளை சாத்தியமாக்க முக்கியமாகப் பயன்படுகிறது.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // இந்த முறை பொதுவாக பல முறை உடனடிப்படுத்தப்படுகிறது.எனவே தொகுக்கும் நேரங்களை மேம்படுத்த இது முடிந்தவரை சிறியதாக இருக்க வேண்டும் என்று நாங்கள் விரும்புகிறோம்.
    // ஆனால் உருவாக்கப்பட்ட குறியீட்டை விரைவாக இயக்க, அதன் உள்ளடக்கங்கள் முடிந்தவரை நிலையான முறையில் கணக்கிடப்பட வேண்டும் என்றும் நாங்கள் விரும்புகிறோம்.
    // ஆகையால், இந்த முறை கவனமாக எழுதப்பட்டுள்ளது, இதனால் `T` ஐ சார்ந்து இருக்கும் குறியீடு அனைத்தும் அதற்குள் இருக்கும், அதே நேரத்தில் `T` ஐ சார்ந்து இல்லாத குறியீட்டின் பெரும்பகுதி `T` ஐ விட பொதுவானதாக இல்லாத செயல்பாடுகளில் உள்ளது.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // அழைப்பு சூழல்களால் இது உறுதி செய்யப்படுகிறது.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` இருக்கும்போது `usize::MAX` இன் திறனை நாங்கள் தருகிறோம்
            // 0, இங்கு செல்வது என்பது `RawVec` அதிகமாக உள்ளது என்பதாகும்.
            return Err(CapacityOverflow);
        }

        // இந்த காசோலைகளைப் பற்றி நாம் உண்மையில் எதுவும் செய்ய முடியாது, துரதிர்ஷ்டவசமாக.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // இது அதிவேக வளர்ச்சிக்கு உத்தரவாதம் அளிக்கிறது.
        // `cap <= isize::MAX` மற்றும் `cap` வகை `usize` என்பதால் இரட்டிப்பாகும்.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` ஐ விட பொதுவானது அல்ல.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // இந்த முறையின் தடைகள் `grow_amortized` இல் உள்ளதைப் போலவே இருக்கின்றன, ஆனால் இந்த முறை வழக்கமாக குறைவாக அடிக்கடி நிறுவப்படுகிறது, எனவே இது குறைவான முக்கியமானதாகும்.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // வகை அளவு இருக்கும்போது நாம் `usize::MAX` இன் திறனைத் தருகிறோம்
            // 0, இங்கு செல்வது என்பது `RawVec` அதிகமாக உள்ளது என்பதாகும்.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` ஐ விட பொதுவானது அல்ல.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// தொகுக்கும் நேரங்களைக் குறைக்க இந்த செயல்பாடு `RawVec` க்கு வெளியே உள்ளது.விவரங்களுக்கு `RawVec::grow_amortized` க்கு மேலே உள்ள கருத்தைப் பார்க்கவும்.
// (`A` அளவுரு குறிப்பிடத்தக்கதாக இல்லை, ஏனென்றால் நடைமுறையில் காணப்படும் வெவ்வேறு `A` வகைகளின் எண்ணிக்கை `T` வகைகளின் எண்ணிக்கையை விட மிகச் சிறியது.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` அளவைக் குறைக்க இங்கே பிழையைப் பார்க்கவும்.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // ஒதுக்கீட்டாளர் சீரமைப்பு சமத்துவத்தை சரிபார்க்கிறார்
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*க்கு சொந்தமான நினைவகத்தை* அதன் உள்ளடக்கங்களை கைவிட முயற்சிக்காமல் விடுவிக்கிறது.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// இருப்பு பிழை கையாளுதலுக்கான மைய செயல்பாடு.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// பின்வருவனவற்றை நாங்கள் உத்தரவாதம் செய்ய வேண்டும்:
// * நாங்கள் எப்போதும் `> isize::MAX` பைட் அளவு பொருள்களை ஒதுக்கவில்லை.
// * நாங்கள் `usize::MAX` ஐ நிரம்பி வழிவதில்லை, உண்மையில் மிகக் குறைவாக ஒதுக்குகிறோம்.
//
// 64-பிட்டில், எக்ஸ் 00 எக்ஸ் பைட்டுகளை ஒதுக்க முயற்சிப்பது நிச்சயமாக தோல்வியடையும் என்பதால், வழிதல் என்பதை சரிபார்க்க வேண்டும்.
// 32-பிட் மற்றும் 16-பிட்டில், நாங்கள் ஒரு மேடையில் இயங்கினால், கூடுதல் 4 ஜி.பியை பயனர் இடைவெளியில் பயன்படுத்தலாம், எ.கா., PAE அல்லது x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// திறன் வழிதல் புகாரளிக்கும் ஒரு மைய செயல்பாடு.
// இந்த panics தொடர்பான குறியீடு உருவாக்கம் மிகக் குறைவு என்பதை இது உறுதி செய்யும், ஏனெனில் தொகுதி முழுவதும் ஒரு கொத்துக்கு பதிலாக panics இருக்கும் ஒரே ஒரு இடம் மட்டுமே உள்ளது.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}