//! யூனிகோட் சரம் துண்டுகள்.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` வகை இரண்டு முக்கிய சரம் வகைகளில் ஒன்றாகும், மற்றொன்று `String`.
//! அதன் `String` எண்ணைப் போலன்றி, அதன் உள்ளடக்கங்கள் கடன் வாங்கப்படுகின்றன.
//!
//! # அடிப்படை பயன்பாடு
//!
//! `&str` வகையின் அடிப்படை சரம் அறிவிப்பு:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! இங்கே நாம் ஒரு சரம் சொற்பொழிவு என்று அறிவித்துள்ளோம், இது ஒரு சரம் துண்டு என்றும் அழைக்கப்படுகிறது.
//! சரம் எழுத்தாளர்கள் நிலையான வாழ்நாளைக் கொண்டுள்ளனர், அதாவது `hello_world` சரம் முழு நிரலின் காலத்திற்கும் செல்லுபடியாகும் என்று உத்தரவாதம் அளிக்கப்படுகிறது.
//!
//! `ஹலோ_வொர்ல்ட்` இன் வாழ்நாளையும் வெளிப்படையாகக் குறிப்பிடலாம்:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// இந்த தொகுதியில் உள்ள பல பயன்பாடுகள் சோதனை உள்ளமைவில் மட்டுமே பயன்படுத்தப்படுகின்றன.
// அவற்றை சரிசெய்வதை விட பயன்படுத்தப்படாத_ இறக்குமதி எச்சரிக்கையை முடக்குவது தூய்மையானது.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>` இல் உள்ள `str` இங்கே அர்த்தமுள்ளதாக இல்லை.
/// trait இன் இந்த வகை அளவுரு மற்றொரு impl ஐ இயக்க மட்டுமே உள்ளது.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // ஹார்ட்கோட் அளவுகள் கொண்ட சுழல்கள் மிக விரைவாக இயங்கும் சிறிய பிரிப்பான் நீளங்களைக் கொண்ட வழக்குகளை நிபுணத்துவம் செய்கின்றன
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // தன்னிச்சையான பூஜ்ஜியமற்ற அளவு குறைவு
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Vec இரண்டிற்கும் வேலை செய்யும் உகந்த சேரல் செயல்படுத்தல்<T>(டி: நகலெடு) மற்றும் ஸ்ட்ரிங்கின் உள் வெக் தற்போது எக்ஸ் 00 எக்ஸ் வகை அனுமானம் மற்றும் சிறப்புடன் ஒரு பிழை உள்ளது (வெளியீடு #36262 ஐப் பார்க்கவும்) இந்த காரணத்திற்காக ஸ்லைஸ் கான்காட்<T>T க்கு சிறப்பு இல்லை: நகல் மற்றும் ஸ்லைஸ் கான்காட்<str>இந்த செயல்பாட்டின் ஒரே பயனர்.
// அது சரி செய்யப்படும் நேரத்திற்கு அது இடத்தில் விடப்படுகிறது.
//
// சரம்-சேருவதற்கான வரம்புகள் எஸ்: கடன்<str>மற்றும் Vec-join Borrow <[T]> [T] மற்றும் str இரண்டையும் AsRef <[T]> சில T க்கு
// => s.borrow().as_ref() எங்களிடம் எப்போதும் துண்டுகள் உள்ளன
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // முதல் துண்டு அதற்கு முன்னால் ஒரு பிரிப்பான் இல்லாமல் மட்டுமே உள்ளது
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // `len` கணக்கீடு நிரம்பி வழிகிறது என்றால் இணைந்த Vec இன் சரியான மொத்த நீளத்தைக் கணக்கிடுங்கள், நாம் panic ஐ எப்படியாவது நினைவகம் இல்லாமல் போயிருப்போம், மீதமுள்ள செயல்பாட்டிற்கு முழு Vec முன்பதிவு தேவைப்படுகிறது
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // ஆரம்பிக்கப்படாத இடையகத்தைத் தயாரிக்கவும்
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // நகல் பிரிப்பான் மற்றும் துண்டுகள் எல்லைகள் இல்லாமல் காசோலைகள் சிறிய பிரிப்பான்களுக்கான ஹார்ட்கோட் செய்யப்பட்ட ஆஃப்செட்களுடன் சுழல்களை உருவாக்குகின்றன பாரிய மேம்பாடுகள் சாத்தியமாகும் (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // ஒரு வித்தியாசமான கடன் செயல்படுத்தல் நீளம் கணக்கீடு மற்றும் உண்மையான நகலுக்கு வெவ்வேறு துண்டுகளை வழங்கக்கூடும்.
        //
        // அழைப்பாளருக்கு ஆரம்பிக்கப்படாத பைட்டுகளை நாங்கள் வெளிப்படுத்தவில்லை என்பதை உறுதிப்படுத்திக் கொள்ளுங்கள்.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// சரம் துண்டுகளுக்கான முறைகள்.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// நகலெடுக்கவோ அல்லது ஒதுக்கவோ இல்லாமல் ஒரு `Box<str>` ஐ `Box<[u8]>` ஆக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// ஒரு வடிவத்தின் அனைத்து பொருத்தங்களையும் மற்றொரு சரத்துடன் மாற்றுகிறது.
    ///
    /// `replace` ஒரு புதிய [`String`] ஐ உருவாக்குகிறது, மேலும் இந்த சரம் துண்டுகளிலிருந்து தரவை நகலெடுக்கிறது.
    /// அவ்வாறு செய்யும்போது, இது ஒரு வடிவத்தின் பொருத்தங்களைக் கண்டறிய முயற்சிக்கிறது.
    /// அது ஏதேனும் இருந்தால், அது அவற்றை மாற்று சரம் துண்டுடன் மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// முறை பொருந்தாதபோது:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// ஒரு வடிவத்தின் முதல் N போட்டிகளை மற்றொரு சரத்துடன் மாற்றுகிறது.
    ///
    /// `replacen` ஒரு புதிய [`String`] ஐ உருவாக்குகிறது, மேலும் இந்த சரம் துண்டுகளிலிருந்து தரவை நகலெடுக்கிறது.
    /// அவ்வாறு செய்யும்போது, இது ஒரு வடிவத்தின் பொருத்தங்களைக் கண்டறிய முயற்சிக்கிறது.
    /// இது ஏதேனும் இருப்பதைக் கண்டால், அது அவற்றை அதிகபட்சமாக `count` நேரங்களில் மாற்று சரம் துண்டுடன் மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// முறை பொருந்தாதபோது:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // மறு ஒதுக்கீட்டு நேரங்களைக் குறைக்கும் என்று நம்புகிறேன்
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// புதிய [`String`] ஆக, இந்த சரம் துண்டுக்கு சமமான சிறிய எழுத்துக்களை வழங்குகிறது.
    ///
    /// 'Lowercase' யூனிகோட் பெறப்பட்ட கோர் சொத்து `Lowercase` இன் விதிமுறைகளின்படி வரையறுக்கப்படுகிறது.
    ///
    /// வழக்கை மாற்றும்போது சில எழுத்துக்கள் பல எழுத்துகளாக விரிவடையக்கூடும் என்பதால், இந்த செயல்பாடு அளவுருவை இடத்தில் மாற்றுவதற்கு பதிலாக [`String`] ஐ வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// சிக்மாவுடன் ஒரு தந்திரமான எடுத்துக்காட்டு:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // ஆனால் ஒரு வார்த்தையின் முடிவில், அது ς, அல்ல:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// வழக்கு இல்லாத மொழிகள் மாற்றப்படவில்லை:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Word to க்கு வரைபடம், ஒரு வார்த்தையின் முடிவில் தவிர வரைபடம் except.
                // இது `SpecialCasing.txt` இல் உள்ள ஒரே நிபந்தனை (contextual) ஆனால் மொழி-சுயாதீன மேப்பிங் ஆகும், எனவே பொதுவான "condition" பொறிமுறையைக் காட்டிலும் கடின குறியீடு.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` இன் வரையறைக்கு.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// இந்த சரம் துண்டுக்கு சமமான பெரிய எழுத்தை புதிய [`String`] ஆக வழங்குகிறது.
    ///
    /// 'Uppercase' யூனிகோட் பெறப்பட்ட கோர் சொத்து `Uppercase` இன் விதிமுறைகளின்படி வரையறுக்கப்படுகிறது.
    ///
    /// வழக்கை மாற்றும்போது சில எழுத்துக்கள் பல எழுத்துகளாக விரிவடையக்கூடும் என்பதால், இந்த செயல்பாடு அளவுருவை இடத்தில் மாற்றுவதற்கு பதிலாக [`String`] ஐ வழங்குகிறது.
    ///
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// வழக்கு இல்லாத ஸ்கிரிப்ட்கள் மாற்றப்படவில்லை:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// ஒரு எழுத்து பலவாகலாம்:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// நகலெடுக்கவோ அல்லது ஒதுக்கவோ இல்லாமல் ஒரு [`Box<str>`] ஐ [`String`] ஆக மாற்றுகிறது.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// ஒரு சரம் `n` முறை மீண்டும் செய்வதன் மூலம் புதிய [`String`] ஐ உருவாக்குகிறது.
    ///
    /// # Panics
    ///
    /// திறன் நிரம்பி வழிகிறது என்றால் இந்த செயல்பாடு panic ஆக இருக்கும்.
    ///
    /// # Examples
    ///
    /// அடிப்படை பயன்பாடு:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// வழிதல் மீது ஒரு panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// ஒவ்வொரு எழுத்தும் அதன் ASCII மேல் வழக்குக்கு சமமானதாக மாற்றப்படும் இந்த சரத்தின் நகலை வழங்குகிறது.
    ///
    ///
    /// ASCII எழுத்துக்கள் 'a' முதல் 'z' வரை 'A' முதல் 'Z' வரை மாற்றப்படுகின்றன, ஆனால் ASCII அல்லாத எழுத்துக்கள் மாறாமல் உள்ளன.
    ///
    /// இடத்தில் உள்ள மதிப்பை உயர்த்த, [`make_ascii_uppercase`] ஐப் பயன்படுத்தவும்.
    ///
    /// ASCII அல்லாத எழுத்துக்களுக்கு மேலதிகமாக ASCII எழுத்துக்களை பெரிய எழுப்ப, [`to_uppercase`] ஐப் பயன்படுத்தவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 மாற்றத்தை பாதுகாக்கிறது.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// இந்த சரத்தின் நகலை ஒவ்வொரு எழுத்தும் அதன் ASCII லோயர் கேஸ் சமமானதாக மாற்றப்படும்.
    ///
    ///
    /// ASCII எழுத்துக்கள் 'A' முதல் 'Z' வரை 'a' முதல் 'z' வரை மாற்றப்படுகின்றன, ஆனால் ASCII அல்லாத எழுத்துக்கள் மாறாமல் உள்ளன.
    ///
    /// இடத்தில் மதிப்பைக் குறைக்க, [`make_ascii_lowercase`] ஐப் பயன்படுத்தவும்.
    ///
    /// ASCII அல்லாத எழுத்துகளுக்கு கூடுதலாக ASCII எழுத்துக்களைக் குறைக்க, [`to_lowercase`] ஐப் பயன்படுத்தவும்.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 மாற்றத்தை பாதுகாக்கிறது.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// சரம் செல்லுபடியாகும் UTF-8 ஐக் கொண்டிருக்கிறதா என்று சோதிக்காமல், பெட்டி செய்யப்பட்ட பைட்டுகளை ஒரு பெட்டி சரம் துண்டுகளாக மாற்றுகிறது.
///
///
/// # Examples
///
/// அடிப்படை பயன்பாடு:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}