// rsbegin.o மற்றும் rsend.o என்பது "compiler runtime startup objects" என அழைக்கப்படுகின்றன.
// கம்பைலர் இயக்க நேரத்தை சரியாக துவக்க தேவையான குறியீடு அவற்றில் உள்ளது.
//
// இயங்கக்கூடிய அல்லது டைலிப் படம் இணைக்கப்படும்போது, அனைத்து பயனர் குறியீடு மற்றும் நூலகங்கள் இந்த இரண்டு பொருள் கோப்புகளுக்கு இடையில் "sandwiched" ஆகும், எனவே rsbegin.o இலிருந்து குறியீடு அல்லது தரவு படத்தின் அந்தந்த பிரிவுகளில் முதலிடம் பெறுகிறது, அதேசமயம் rsend.o இலிருந்து குறியீடு மற்றும் தரவு கடைசியாக இருக்கும்.
// இந்த விளைவு சின்னங்களை தொடக்கத்தில் அல்லது ஒரு பிரிவின் முடிவில் வைக்கவும், தேவையான தலைப்புகள் அல்லது அடிக்குறிப்புகளை செருகவும் பயன்படுத்தப்படலாம்.
//
// உண்மையான தொகுதி நுழைவு புள்ளி சி இயக்க நேர தொடக்க பொருளில் (வழக்கமாக `crtX.o` என அழைக்கப்படுகிறது) அமைந்துள்ளது என்பதை நினைவில் கொள்க, பின்னர் இது பிற இயக்கநேர கூறுகளின் துவக்க கால்பேக்குகளை (மற்றொரு சிறப்பு பட பிரிவு வழியாக பதிவு செய்யப்பட்டுள்ளது) அழைக்கிறது.
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // ஸ்டாக் ஃபிரேமின் தொடக்க குறிப்புகள் தகவல் பிரிவை பிரிக்கவும்
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // பிரிக்கப்படாத உள் புத்தகத்தை வைத்திருப்பதற்கான இடத்தை கீறவும்.
    // இது 00 GCC/undind-dw2-fde.h இல் `struct object` என வரையறுக்கப்படுகிறது.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // தகவல் பிரிக்கவும் registration/deregistration நடைமுறைகள்.
    // Libpanic_unwind இன் ஆவணங்களைக் காண்க.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // தொகுதி தொடக்கத்தில் தகவலைப் பிரிக்கவும்
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // பணிநிறுத்தத்தில் பதிவுசெய்தல்
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-குறிப்பிட்ட init/uninit வழக்கமான பதிவு
    pub mod mingw_init {
        // MinGW இன் தொடக்க பொருள்கள் (crt0.o/dllcrt0.o) தொடக்க மற்றும் வெளியேறும் போது .ctors மற்றும் .dtors பிரிவுகளில் உலகளாவிய கட்டமைப்பாளர்களை அழைக்கும்.
        // டி.எல்.எல் விஷயங்களைப் பொறுத்தவரை, டி.எல்.எல் ஏற்றப்பட்டு இறக்கப்படும்போது இது செய்யப்படுகிறது.
        //
        // இணைப்பாளர் பிரிவுகளை வரிசைப்படுத்துவார், இது எங்கள் கால்பேக்குகள் பட்டியலின் முடிவில் அமைந்திருப்பதை உறுதி செய்கிறது.
        // கட்டமைப்பாளர்கள் தலைகீழ் வரிசையில் இயங்குவதால், இது எங்கள் கால்பேக்குகள் முதல் மற்றும் கடைசியாக செயல்படுத்தப்படுவதை உறுதி செய்கிறது.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: சி துவக்க கால்பேக்குகள்
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: சி முடித்தல் கால்பேக்குகள்
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}