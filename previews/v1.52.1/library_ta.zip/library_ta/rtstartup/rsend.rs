// விவரங்களுக்கு rsbegin.rs ஐப் பார்க்கவும்.

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
trait Sync {}
impl<T> Sync for T {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    // ஃபிரேம் பிரிக்காத தகவல் பகுதியை 0 உடன் சென்டினலாக நிறுத்தவும்;
    // இது ஒரு உண்மையான FDE இல் 'length' புலமாக இருக்கும்.
    #[no_mangle]
    #[link_section = ".eh_frame"]
    pub static __EH_FRAME_END__: u32 = 0;
}