/// Membuat [`Vec`] yang mengandungi argumen.
///
/// `vec!` membolehkan `Vec`s ditakrifkan dengan sintaks yang sama dengan ungkapan array.
/// Terdapat dua bentuk makro ini:
///
/// - Buat [`Vec`] yang mengandungi senarai elemen yang diberikan:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Buat [`Vec`] dari elemen dan ukuran tertentu:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Perhatikan bahawa tidak seperti ungkapan array sintaks ini menyokong semua elemen yang menerapkan [`Clone`] dan bilangan elemen tidak harus menjadi pemalar.
///
/// Ini akan menggunakan `clone` untuk menggandakan ekspresi, jadi seseorang harus berhati-hati menggunakannya dengan jenis yang mempunyai implementasi `Clone` yang tidak standard.
/// Contohnya, `vec![Rc::new(1);5] `akan membuat vector dari lima rujukan ke nilai bilangan bulat yang sama, bukan lima rujukan yang menunjuk pada bilangan bulat secara bebas.
///
///
/// Juga, perhatikan bahawa `vec![expr; 0]` dibenarkan, dan menghasilkan vector kosong.
/// Ini akan tetap menilai `expr`, bagaimanapun, dan segera menjatuhkan nilai yang dihasilkan, jadi ingatlah kesan sampingan.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): dengan cfg(test) kaedah `[T]::into_vec` yang wujud, yang diperlukan untuk definisi makro ini, tidak tersedia.
// Sebaliknya gunakan fungsi `slice::into_vec` yang hanya tersedia dengan cfg(test) NB lihat modul slice::hack di slice.rs untuk maklumat lebih lanjut
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Membuat `String` menggunakan interpolasi ungkapan runtime.
///
/// Argumen pertama yang diterima `format!` adalah rentetan format.Ini mestilah harfiah rentetan.Kekuatan rentetan pemformatan ada di `{}` s yang terkandung.
///
/// Parameter tambahan yang diteruskan ke `format!` menggantikan `{}` s dalam rentetan pemformatan dalam urutan yang diberikan kecuali parameter bernama atau kedudukan digunakan;lihat [`std::fmt`] untuk maklumat lebih lanjut.
///
///
/// Penggunaan biasa untuk `format!` adalah penggabungan dan interpolasi rentetan.
/// Konvensyen yang sama digunakan dengan makro [`print!`] dan [`write!`], bergantung pada tujuan rentetan yang diinginkan.
///
/// Untuk menukar satu nilai menjadi rentetan, gunakan kaedah [`to_string`].Ini akan menggunakan format [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics jika pelaksanaan pemformatan trait mengembalikan ralat.
/// Ini menunjukkan pelaksanaan yang salah kerana `fmt::Write for String` tidak pernah mengembalikan kesalahan itu sendiri.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Paksa simpul AST ke ungkapan untuk meningkatkan diagnostik dalam kedudukan corak.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}