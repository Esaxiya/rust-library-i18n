//! Potongan rentetan unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Jenis `&str` adalah salah satu daripada dua jenis rentetan utama, yang lain adalah `String`.
//! Tidak seperti rakan `String`, kandungannya dipinjam.
//!
//! # Penggunaan Asas
//!
//! Deklarasi rentetan asas jenis `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Di sini kita telah menyatakan literal string, juga dikenal sebagai irisan string.
//! String literal mempunyai jangka hayat yang statik, yang bermaksud tali `hello_world` dijamin sah selama keseluruhan program.
//!
//! Kami juga dapat secara jelas menentukan jangka hayat `hello_world ':
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Sebilangan besar penggunaan dalam modul ini hanya digunakan dalam konfigurasi ujian.
// Lebih mudah untuk mematikan amaran_import yang tidak digunakan daripada memperbaikinya.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` di `Concat<str>` tidak bermakna di sini.
/// Parameter jenis trait ini hanya wujud untuk membolehkan impl lain.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // gelung dengan saiz kod keras berjalan lebih pantas dan mengkhususkan kes dengan panjang pemisah kecil
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // penggantian saiz bukan sifar sewenang-wenangnya
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Pelaksanaan gabungan yang dioptimumkan yang berfungsi untuk kedua-dua Vec<T>(T: Copy) dan String's vec dalaman (2018-05-13) Pada masa ini terdapat bug dengan jenis inferensi dan pengkhususan (lihat isu #36262) Atas sebab ini SliceConcat<T>tidak khusus untuk T: Copy dan SliceConcat<str>adalah satu-satunya pengguna fungsi ini.
// Ia dibiarkan di tempat untuk masa yang betul.
//
// had untuk String-join adalah S: Pinjam<str>dan untuk Vec-join Borrow <[T]> [T] dan kedua-duanya menggunakan AsRef <[T]> untuk beberapa T
// => s.borrow().as_ref() dan kami selalu mempunyai kepingan
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // hirisan pertama adalah satu-satunya tanpa pemisah yang mendahuluinya
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // hitung jumlah panjang tepat Vec bergabung jika pengiraan `len` melimpah, kita akan panic kita akan kehabisan memori pula dan fungsi selebihnya memerlukan keseluruhan Vec yang diperuntukkan terlebih dahulu untuk keselamatan
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // sediakan penyangga yang belum dimulakan
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // salin pemisah dan kepingan tanpa pemeriksaan had menghasilkan gelung dengan offset kod keras untuk pemisah kecil peningkatan besar mungkin (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Pelaksanaan pinjaman yang pelik dapat mengembalikan potongan yang berbeza untuk pengiraan panjang dan salinan sebenarnya.
        //
        // Pastikan kita tidak mendedahkan bait yang belum dimulakan kepada pemanggil.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Kaedah untuk irisan tali.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Menukar `Box<str>` menjadi `Box<[u8]>` tanpa menyalin atau memperuntukkan.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Menggantikan semua padanan corak dengan rentetan lain.
    ///
    /// `replace` membuat [`String`] baru, dan menyalin data dari potongan rentetan ini ke dalamnya.
    /// Semasa melakukannya, ia berusaha mencari padanan corak.
    /// Sekiranya terdapat, ia akan menggantikannya dengan irisan tali gantian.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Apabila corak tidak sepadan:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Menggantikan padanan N pertama corak dengan rentetan lain.
    ///
    /// `replacen` membuat [`String`] baru, dan menyalin data dari potongan rentetan ini ke dalamnya.
    /// Semasa melakukannya, ia berusaha mencari padanan corak.
    /// Sekiranya terdapat, ia menggantikannya dengan irisan rentetan pengganti paling banyak `count` kali.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Apabila corak tidak sepadan:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Harap dapat mengurangkan masa peruntukan semula
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Mengembalikan setara huruf kecil dari potongan rentetan ini, sebagai [`String`] baru.
    ///
    /// 'Lowercase' ditakrifkan mengikut syarat-syarat Unicode Derived Core Property `Lowercase`.
    ///
    /// Oleh kerana beberapa watak boleh berkembang menjadi beberapa watak ketika mengubah casing, fungsi ini mengembalikan [`String`] dan bukannya mengubah parameter di tempat.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Contoh yang sukar, dengan sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // tetapi pada akhir kata, itu, bukan σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Bahasa tanpa huruf tidak diubah:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ memetakan ke σ, kecuali pada akhir perkataan di mana ia memetakan ke.
                // Ini adalah satu-satunya (contextual) bersyarat tetapi pemetaan bebas bahasa di `SpecialCasing.txt`, jadi kodkannya lebih keras daripada mempunyai mekanisme "condition" generik.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // untuk definisi `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Mengembalikan setara huruf besar dari potongan rentetan ini, sebagai [`String`] baru.
    ///
    /// 'Uppercase' ditakrifkan mengikut syarat-syarat Unicode Derived Core Property `Uppercase`.
    ///
    /// Oleh kerana beberapa watak boleh berkembang menjadi beberapa watak ketika mengubah casing, fungsi ini mengembalikan [`String`] dan bukannya mengubah parameter di tempat.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Skrip tanpa kes tidak diubah:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Satu watak boleh menjadi pelbagai:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Menukar [`Box<str>`] menjadi [`String`] tanpa menyalin atau memperuntukkan.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Membuat [`String`] baru dengan mengulang rentetan `n` kali.
    ///
    /// # Panics
    ///
    /// Fungsi ini akan panic jika kapasiti akan meluap.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic semasa limpahan:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Mengembalikan salinan rentetan ini di mana setiap watak dipetakan ke setara huruf besar ASCII.
    ///
    ///
    /// Huruf ASCII 'a' hingga 'z' dipetakan ke 'A' hingga 'Z', tetapi huruf bukan ASCII tidak berubah.
    ///
    /// Untuk huruf besar nilai di tempat, gunakan [`make_ascii_uppercase`].
    ///
    /// Untuk huruf besar ASCII selain watak bukan ASCII, gunakan [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() memelihara invarian UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Mengembalikan salinan rentetan ini di mana setiap watak dipetakan ke setara huruf kecil ASCII.
    ///
    ///
    /// Huruf ASCII 'A' hingga 'Z' dipetakan ke 'a' hingga 'z', tetapi huruf bukan ASCII tidak berubah.
    ///
    /// Untuk mengecilkan nilai di tempat, gunakan [`make_ascii_lowercase`].
    ///
    /// Untuk huruf kecil ASCII selain watak bukan ASCII, gunakan [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() memelihara invarian UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Menukarkan potongan byte berkotak menjadi potongan rentetan kotak tanpa memeriksa bahawa rentetan mengandungi UTF-8 yang sah.
///
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}