//! Rentetan UTF-8 - dikodkan dan boleh ditanam.
//!
//! Modul ini mengandungi jenis [`String`], [`ToString`] trait untuk menukar ke rentetan, dan beberapa jenis ralat yang mungkin disebabkan oleh bekerja dengan [`String`] s.
//!
//!
//! # Examples
//!
//! Terdapat pelbagai cara untuk membuat [`String`] baru dari literal rentetan:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Anda boleh membuat [`String`] baru dari yang sedia ada dengan bergabung dengan
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Sekiranya anda mempunyai vector sah UTF-8 bait, anda boleh membuat [`String`] dari itu.Anda juga boleh melakukan sebaliknya.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Kami tahu bait ini sah, jadi kami akan menggunakan `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Rentetan UTF-8 - dikodkan dan boleh ditanam.
///
/// Jenis `String` adalah jenis rentetan yang paling biasa yang mempunyai hak milik atas kandungan rentetan.Ia mempunyai hubungan rapat dengan rakan sejawatnya yang dipinjam, [`str`] primitif.
///
/// # Examples
///
/// Anda boleh membuat `String` dari [a literal string][`str`] dengan [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Anda boleh menambahkan [`char`] ke `String` dengan kaedah [`push`], dan menambahkan [`&str`] dengan kaedah [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Sekiranya anda mempunyai vector of UTF-8 byte, anda boleh membuat `String` darinya dengan kaedah [`from_utf8`]:
///
/// ```
/// // sebilangan bait, dalam vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Kami tahu bait ini sah, jadi kami akan menggunakan `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// String selalu sah UTF-8.Ini mempunyai beberapa implikasi, yang pertama adalah jika anda memerlukan rentetan bukan UTF-8, pertimbangkan [`OsString`].Ia serupa, tetapi tanpa kekangan UTF-8.Implikasi kedua ialah anda tidak dapat mengindeks ke `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Pengindeksan dimaksudkan untuk operasi tetap, tetapi pengekodan UTF-8 tidak membenarkan kami melakukan ini.Selain itu, tidak jelas perkara seperti apa yang harus dikembalikan oleh indeks: bait, titik titik, atau kelompok grafik.
/// Kaedah [`bytes`] dan [`chars`] mengembalikan lelaran masing-masing selama dua yang pertama.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s implement [`Deref`] `<Target=str>`, dan mewarisi semua kaedah [`str`].Di samping itu, ini bermaksud bahawa anda dapat meneruskan `String` ke fungsi yang memerlukan [`&str`] dengan menggunakan ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Ini akan membuat [`&str`] dari `String` dan meneruskannya. Penukaran ini sangat murah, dan secara amnya, fungsi akan menerima [`&str`] sebagai argumen melainkan mereka memerlukan `String` untuk beberapa alasan tertentu.
///
/// Dalam kes tertentu Rust tidak mempunyai maklumat yang mencukupi untuk melakukan penukaran ini, yang dikenali sebagai pemaksaan [`Deref`].Dalam contoh berikut, potongan rentetan [`&'a str`][`&str`] mengimplementasikan trait `TraitExample`, dan fungsi `example_func` mengambil apa sahaja yang menerapkan trait.
/// Dalam hal ini Rust perlu membuat dua penukaran tersirat, yang mana Rust tidak mempunyai cara untuk dilakukan.
/// Atas sebab itu, contoh berikut tidak akan disusun.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Terdapat dua pilihan yang akan berfungsi sebagai gantinya.Yang pertama adalah menukar garis `example_func(&example_string);` menjadi `example_func(example_string.as_str());`, menggunakan kaedah [`as_str()`] untuk secara eksplisit mengekstrak potongan tali yang mengandungi tali.
/// Cara kedua menukar `example_func(&example_string);` menjadi `example_func(&*example_string);`.
/// Dalam kes ini, kita tidak merujuk `String` ke [`str`][`&str`], kemudian merujuk [`str`][`&str`] kembali ke [`&str`].
/// Cara kedua lebih idiomatik, namun kedua-duanya berfungsi untuk melakukan penukaran secara eksplisit daripada bergantung pada penukaran tersirat.
///
/// # Representation
///
/// `String` terdiri dari tiga komponen: penunjuk ke beberapa bait, panjang, dan kapasiti.Penunjuk menunjukkan penyangga dalaman yang digunakan `String` untuk menyimpan datanya.Panjangnya adalah jumlah bait yang disimpan dalam penyangga, dan kapasitasnya adalah ukuran penyangga dalam bait.
///
/// Oleh itu, panjangnya selalu kurang atau sama dengan kapasiti.
///
/// Penyangga ini selalu disimpan di timbunan.
///
/// Anda boleh melihatnya dengan kaedah [`as_ptr`], [`len`], dan [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Kemas kini ini apabila vec_into_raw_parts distabilkan.
/// // Cegah menjatuhkan data String secara automatik
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // cerita mempunyai sembilan belas bait
/// assert_eq!(19, len);
///
/// // Kita dapat membina semula String out dari ptr, len, dan kapasitas.
/// // Ini semua tidak selamat kerana kami bertanggungjawab memastikan komponennya sah:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Sekiranya `String` mempunyai kapasiti yang mencukupi, penambahan elemen ke dalamnya tidak akan diperuntukkan semula.Sebagai contoh, pertimbangkan program ini:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Ini akan menghasilkan perkara berikut:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Pada mulanya, kami tidak memiliki memori yang dialokasikan sama sekali, tetapi ketika kami menambahkan tali, ia meningkatkan kapasitinya dengan tepat.Sekiranya kita menggunakan kaedah [`with_capacity`] untuk memperuntukkan kapasiti yang betul pada mulanya:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Kami berakhir dengan output yang berbeza:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Di sini, tidak perlu memperuntukkan lebih banyak memori di dalam gelung.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Nilai ralat yang mungkin berlaku semasa menukar `String` dari byte UTF-8 vector.
///
/// Jenis ini adalah jenis ralat untuk kaedah [`from_utf8`] pada [`String`].
/// Ia dirancang sedemikian rupa untuk mengelakkan penempatan semula dengan hati-hati: kaedah [`into_bytes`] akan mengembalikan bait vector yang digunakan dalam percubaan penukaran.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Jenis [`Utf8Error`] yang disediakan oleh [`std::str`] menunjukkan ralat yang mungkin berlaku ketika menukar sepotong [`u8`] s ke [`&str`].
/// Dalam pengertian ini, ini adalah analog untuk `FromUtf8Error`, dan anda boleh mendapatkannya dari `FromUtf8Error` melalui kaedah [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// // sebilangan bait tidak sah, dalam vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Nilai ralat yang mungkin berlaku semasa menukar `String` dari potongan UTF-16 bait.
///
/// Jenis ini adalah jenis ralat untuk kaedah [`from_utf16`] pada [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Membuat `String` kosong baru.
    ///
    /// Memandangkan `String` kosong, ini tidak akan memperuntukkan penyangga awal.Walaupun ini bermaksud bahawa operasi awal ini sangat murah, ia mungkin menyebabkan peruntukan yang berlebihan ketika anda menambahkan data.
    ///
    /// Sekiranya anda mempunyai idea tentang berapa banyak data yang akan disimpan oleh `String`, pertimbangkan kaedah [`with_capacity`] untuk mengelakkan peruntukan semula yang berlebihan.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Membuat `String` kosong baru dengan kapasiti tertentu.
    ///
    /// String mempunyai penyangga dalaman untuk menyimpan data mereka.
    /// Kapasiti adalah panjang penyangga itu, dan dapat ditanyakan dengan kaedah [`capacity`].
    /// Kaedah ini membuat `String` kosong, tetapi satu dengan penyangga awal yang dapat menahan bait `capacity`.
    /// Ini berguna apabila anda mungkin menambahkan sekumpulan data ke `String`, mengurangkan jumlah peruntukan semula yang perlu dilakukan.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Sekiranya kapasiti yang diberikan adalah `0`, tidak ada peruntukan yang akan berlaku, dan kaedah ini sama dengan kaedah [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // String tidak mengandungi karakter, walaupun memiliki kapasitas untuk lebih banyak
    /// assert_eq!(s.len(), 0);
    ///
    /// // Ini semua dilakukan tanpa mengalokasikan semula ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... tetapi ini mungkin membuat rentetan dialokasikan semula
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): dengan cfg(test) kaedah `[T]::to_vec` yang wujud, yang diperlukan untuk definisi kaedah ini, tidak tersedia.
    // Oleh kerana kami tidak memerlukan kaedah ini untuk tujuan pengujian, saya hanya akan mencubanya NB melihat modul slice::hack di slice.rs untuk maklumat lebih lanjut
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Menukar vector byte ke `String`.
    ///
    /// Rentetan ([`String`]) terbuat dari byte ([`u8`]), dan vector byte ([`Vec<u8>`]) terbuat dari bait, jadi fungsi ini menukar antara keduanya.
    /// Tidak semua kepingan bait adalah `String` yang sah, namun: `String` memerlukannya adalah UTF-8 yang sah.
    /// `from_utf8()` memeriksa untuk memastikan bahawa bait itu sah UTF-8, dan kemudian melakukan penukaran.
    ///
    /// Sekiranya anda yakin bahawa potongan byte itu sah UTF-8, dan anda tidak mahu menanggung overhead dari pemeriksaan kesahan, terdapat versi fungsi ini yang tidak selamat, [`from_utf8_unchecked`], yang mempunyai tingkah laku yang sama tetapi melewatkan pemeriksaan.
    ///
    ///
    /// Kaedah ini berhati-hati untuk tidak menyalin vector, demi kecekapan.
    ///
    /// Sekiranya anda memerlukan [`&str`] dan bukannya `String`, pertimbangkan [`str::from_utf8`].
    ///
    /// Kebalikan kaedah ini ialah [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Mengembalikan [`Err`] jika potongan tidak UTF-8 dengan keterangan mengapa bait yang diberikan bukan UTF-8.vector yang anda pindahkan juga disertakan.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // sebilangan bait, dalam vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Kami tahu bait ini sah, jadi kami akan menggunakan `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bait yang tidak betul:
    ///
    /// ```
    /// // sebilangan bait tidak sah, dalam vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Lihat dokumen untuk [`FromUtf8Error`] untuk maklumat lebih lanjut mengenai perkara yang boleh anda lakukan dengan ralat ini.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Menukar potongan bait ke rentetan, termasuk aksara yang tidak sah.
    ///
    /// String terbuat dari byte ([`u8`]), dan potongan byte ([`&[u8]`][byteslice]) terbuat dari byte, jadi fungsi ini menukar antara keduanya.Walau bagaimanapun, tidak semua irisan bait adalah rentetan yang sah: rentetan mesti sah UTF-8.
    /// Semasa penukaran ini, `from_utf8_lossy()` akan menggantikan urutan UTF-8 yang tidak sah dengan [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], yang kelihatan seperti ini:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Sekiranya anda yakin bahawa potongan byte itu sah UTF-8, dan anda tidak mahu menanggung overhead penukaran, terdapat versi fungsi ini yang tidak selamat, [`from_utf8_unchecked`], yang mempunyai tingkah laku yang sama tetapi melewatkan pemeriksaan.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Fungsi ini mengembalikan [`Cow<'a, str>`].Sekiranya potongan byte kami tidak sah UTF-8, maka kami perlu memasukkan watak pengganti, yang akan mengubah ukuran rentetan, dan oleh itu, memerlukan `String`.
    /// Tetapi jika sudah sah UTF-8, kami tidak memerlukan peruntukan baru.
    /// Jenis pengembalian ini membolehkan kita menangani kedua-dua kes tersebut.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // sebilangan bait, dalam vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bait yang tidak betul:
    ///
    /// ```
    /// // sebilangan bait tidak sah
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Menyahkodkan vector `v` yang dikodkan UTF-16 menjadi `String`, mengembalikan [`Err`] jika `v` mengandungi data yang tidak sah.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Ini tidak dilakukan melalui koleksi: : <Result<_, _>> () atas sebab prestasi.
        // FIXME: fungsinya dapat dipermudahkan lagi apabila #48994 ditutup.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Nyatakan kepingan XT2X yang dikodkan UTF-16 menjadi `String`, menggantikan data yang tidak sah dengan [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Tidak seperti [`from_utf8_lossy`] yang mengembalikan [`Cow<'a, str>`], `from_utf16_lossy` mengembalikan `String` kerana penukaran UTF-16 ke UTF-8 memerlukan peruntukan memori.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Menguraikan `String` ke dalam komponen mentahnya.
    ///
    /// Mengembalikan penunjuk mentah ke data yang mendasari, panjang rentetan (dalam bait), dan kapasiti data yang diperuntukkan (dalam bait).
    /// Ini adalah argumen yang sama dalam urutan yang sama dengan argumen untuk [`from_raw_parts`].
    ///
    /// Setelah memanggil fungsi ini, pemanggil bertanggungjawab untuk memori yang sebelumnya dikendalikan oleh `String`.
    /// Satu-satunya cara untuk melakukan ini adalah dengan menukar pointer mentah, panjang, dan kapasiti kembali menjadi `String` dengan fungsi [`from_raw_parts`], yang memungkinkan pemusnah melakukan pembersihan.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Membuat `String` baru dari panjang, kapasiti, dan penunjuk.
    ///
    /// # Safety
    ///
    /// Ini sangat tidak selamat, kerana bilangan invarian yang tidak diperiksa:
    ///
    /// * Memori di `buf` sebelumnya mesti dialokasikan oleh alokasi yang sama yang digunakan perpustakaan standard, dengan penjajaran yang diperlukan tepat 1.
    /// * `length` perlu kurang daripada atau sama dengan `capacity`.
    /// * `capacity` perlu nilai yang betul.
    /// * Bait `length` pertama pada `buf` mesti sah UTF-8.
    ///
    /// Melanggar ini boleh menyebabkan masalah seperti merosakkan struktur data dalaman pengagihan.
    ///
    /// Kepemilikan `buf` secara efektif dipindahkan ke `String` yang kemudian dapat menyahpindah, mengalokasikan semula atau mengubah isi memori yang ditunjukkan oleh penunjuk sesuka hati.
    /// Pastikan tiada yang lain menggunakan penunjuk selepas memanggil fungsi ini.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Kemas kini ini apabila vec_into_raw_parts distabilkan.
    ///     // Cegah menjatuhkan data String secara automatik
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Menukar vector byte ke `String` tanpa memeriksa bahawa rentetan mengandungi UTF-8 yang sah.
    ///
    /// Lihat versi selamat, [`from_utf8`], untuk maklumat lebih lanjut.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat kerana tidak memastikan bait yang diteruskan kepadanya adalah UTF-8 yang sah.
    /// Sekiranya kekangan ini dilanggar, ia mungkin menyebabkan masalah memori tidak selamat dengan pengguna future `String`, kerana seluruh pustaka standard menganggap bahawa `String`s adalah UTF-8 yang sah.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // sebilangan bait, dalam vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Menukar `String` menjadi vector bait.
    ///
    /// Ini memakan `String`, jadi kami tidak perlu menyalin kandungannya.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Ekstrak potongan tali yang mengandungi keseluruhan `String`.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Menukar `String` menjadi irisan rentetan yang boleh berubah.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Menambah potongan rentetan yang diberikan ke hujung `String` ini.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Mengembalikan kapasiti String ini, dalam bait.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Memastikan bahawa kapasiti String ini sekurang-kurangnya `additional` byte lebih besar dari panjangnya.
    ///
    /// Kapasiti dapat ditingkatkan lebih dari `additional` bait jika memilihnya, untuk mengelakkan penyetempatan semula yang kerap.
    ///
    ///
    /// Sekiranya anda tidak mahu tingkah laku "at least" ini, lihat kaedah [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics jika kapasiti baru melimpah [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ini sebenarnya tidak dapat meningkatkan kapasiti:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s sekarang mempunyai panjang 2 dan kapasiti 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Oleh kerana kami sudah mempunyai kapasiti tambahan 8, memanggil ini ...
    /// s.reserve(8);
    ///
    /// // ... sebenarnya tidak meningkat.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Memastikan bahawa kapasiti String ini adalah `additional` byte lebih besar dari panjangnya.
    ///
    /// Pertimbangkan untuk menggunakan kaedah [`reserve`] melainkan anda benar-benar tahu lebih baik daripada pengedar.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics jika kapasiti baru melimpah `usize`.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ini sebenarnya tidak dapat meningkatkan kapasiti:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s sekarang mempunyai panjang 2 dan kapasiti 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Oleh kerana kami sudah mempunyai kapasiti tambahan 8, memanggil ini ...
    /// s.reserve_exact(8);
    ///
    /// // ... sebenarnya tidak meningkat.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Mencuba untuk menyimpan kapasiti sekurang-kurangnya `additional` lebih banyak elemen yang akan dimasukkan ke dalam `String` yang diberikan.
    /// Koleksi mungkin menyimpan lebih banyak ruang untuk mengelakkan penempatan semula yang kerap.
    /// Setelah memanggil `reserve`, kapasiti akan lebih besar daripada atau sama dengan `self.len() + additional`.
    /// Tidak ada apa-apa jika kapasiti sudah mencukupi.
    ///
    /// # Errors
    ///
    /// Sekiranya kapasiti meluap, atau pengagihan melaporkan kegagalan, maka ralat dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pra-simpanan memori, keluar jika kita tidak dapat
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Sekarang kita tahu ini tidak dapat dilakukan OOM di tengah-tengah kerja kita yang kompleks
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Cuba untuk menyimpan kapasiti minimum untuk `additional` lebih banyak elemen yang akan dimasukkan ke dalam `String` yang diberikan.
    ///
    /// Setelah memanggil `reserve_exact`, kapasiti akan lebih besar daripada atau sama dengan `self.len() + additional`.
    /// Tidak ada apa-apa jika kapasiti sudah mencukupi.
    ///
    /// Perhatikan bahawa pengagihan mungkin memberikan koleksi lebih banyak ruang daripada yang diminta.
    /// Oleh itu, kapasiti tidak dapat diandalkan dengan tepat.
    /// Lebih suka `reserve` jika diharapkan penyisipan future.
    ///
    /// # Errors
    ///
    /// Sekiranya kapasiti meluap, atau pengagihan melaporkan kegagalan, maka ralat dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pra-simpanan memori, keluar jika kita tidak dapat
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Sekarang kita tahu ini tidak dapat dilakukan OOM di tengah-tengah kerja kita yang kompleks
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Mengecilkan kapasiti `String` ini agar sepadan dengan panjangnya.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Mengecilkan kapasiti `String` ini dengan had bawah.
    ///
    /// Kapasiti akan kekal sekurang-kurangnya sebesar kedua dan nilai yang dibekalkan.
    ///
    ///
    /// Sekiranya kapasiti semasa kurang dari had bawah, ini adalah op-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Menambah [`char`] yang diberikan hingga akhir `String` ini.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Mengembalikan potongan bait kandungan `String 'ini.
    ///
    /// Kebalikan kaedah ini ialah [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Memendekkan `String` ini ke panjang yang ditentukan.
    ///
    /// Sekiranya `new_len` lebih besar daripada panjang tali semasa, ini tidak akan memberi kesan.
    ///
    ///
    /// Perhatikan bahawa kaedah ini tidak mempengaruhi keupayaan rentetan yang diperuntukkan
    ///
    /// # Panics
    ///
    /// Panics jika `new_len` tidak terletak pada batas [`char`].
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Mengeluarkan watak terakhir dari penyangga rentetan dan mengembalikannya.
    ///
    /// Mengembalikan [`None`] jika `String` ini kosong.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Mengeluarkan [`char`] dari `String` ini pada kedudukan bait dan mengembalikannya.
    ///
    /// Ini adalah operasi *O*(*n*), kerana ia memerlukan penyalinan setiap elemen dalam penyangga.
    ///
    /// # Panics
    ///
    /// Panics jika `idx` lebih besar daripada atau sama dengan panjang String, atau jika tidak terletak pada batas [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Keluarkan semua padanan corak `pat` di `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Pertandingan akan dikesan dan dihapus secara berulang, jadi jika corak bertindih, hanya corak pertama yang akan dikeluarkan:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // KESELAMATAN: permulaan dan akhir akan berada pada had utf8 bait per
        // dokumen Pencari
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Hanya mengekalkan watak yang ditentukan oleh predikat.
    ///
    /// Dengan kata lain, buang semua aksara `c` sehingga `f(c)` mengembalikan `false`.
    /// Kaedah ini beroperasi di tempat, melawat setiap watak tepat sekali dalam susunan asal, dan mengekalkan susunan watak yang dikekalkan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Urutan tepat mungkin berguna untuk mengesan keadaan luaran, seperti indeks.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Arahkan idx ke aras seterusnya
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Memasukkan watak ke dalam `String` ini pada kedudukan bait.
    ///
    /// Ini adalah operasi *O*(*n*) kerana memerlukan penyalinan setiap elemen dalam penyangga.
    ///
    /// # Panics
    ///
    /// Panics jika `idx` lebih besar daripada panjang String, atau jika tidak terletak pada batas [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Memasukkan potongan rentetan ke `String` ini pada kedudukan bait.
    ///
    /// Ini adalah operasi *O*(*n*) kerana memerlukan penyalinan setiap elemen dalam penyangga.
    ///
    /// # Panics
    ///
    /// Panics jika `idx` lebih besar daripada panjang String, atau jika tidak terletak pada batas [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Mengembalikan rujukan yang boleh berubah ke kandungan `String` ini.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat kerana tidak memastikan bait yang diteruskan kepadanya adalah UTF-8 yang sah.
    /// Sekiranya kekangan ini dilanggar, ia mungkin menyebabkan masalah memori tidak selamat dengan pengguna future `String`, kerana seluruh pustaka standard menganggap bahawa `String`s adalah UTF-8 yang sah.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Mengembalikan panjang `String` ini, dalam bait, bukan [`char`] atau grafik.
    /// Dengan kata lain, manusia mungkin tidak menganggap panjang tali itu.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Mengembalikan `true` jika `String` ini mempunyai panjang sifar, dan `false` sebaliknya.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Membahagi rentetan menjadi dua pada indeks bait yang diberikan.
    ///
    /// Mengembalikan `String` yang baru diperuntukkan.
    /// `self` mengandungi byte `[0, at)`, dan `String` yang dikembalikan mengandungi byte `[at, len)`.
    /// `at` mesti berada di had titik kod UTF-8.
    ///
    /// Perhatikan bahawa kapasiti `self` tidak berubah.
    ///
    /// # Panics
    ///
    /// Panics jika `at` tidak berada pada batas titik kod `UTF-8`, atau jika berada di luar titik kod terakhir tali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Memotong `String` ini, membuang semua kandungan.
    ///
    /// Walaupun ini bermaksud `String` akan mempunyai panjang sifar, ia tidak menyentuh kapasitinya.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Membuat iterator pengeringan yang menghilangkan julat yang ditentukan dalam `String` dan menghasilkan `chars` yang dikeluarkan.
    ///
    ///
    /// Note: Julat elemen dikeluarkan walaupun iterator tidak habis digunakan hingga akhir.
    ///
    /// # Panics
    ///
    /// Panics jika titik permulaan atau titik akhir tidak terletak pada batas [`char`], atau jika mereka berada di luar batas.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Keluarkan julat hingga β dari tali
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Julat penuh membersihkan rentetan
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Keselamatan ingatan
        //
        // Versi String Drain tidak mempunyai masalah keselamatan memori versi vector.
        // Data hanya bait biasa.
        // Kerana penyingkiran julat berlaku di Drop, jika iterator Drain bocor, penghapusan tidak akan berlaku.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Keluarkan dua pinjaman serentak.
        // String &mut tidak akan dapat diakses sehingga iterasi selesai, dalam Drop.
        let self_ptr = self as *mut _;
        // KESELAMATAN: `slice::range` dan `is_char_boundary` melakukan pemeriksaan had yang sesuai.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Mengeluarkan julat yang ditentukan dalam rentetan, dan menggantikannya dengan rentetan yang diberikan.
    /// Rentetan yang diberikan tidak perlu panjang sama dengan julat.
    ///
    /// # Panics
    ///
    /// Panics jika titik permulaan atau titik akhir tidak terletak pada batas [`char`], atau jika mereka berada di luar batas.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Ganti julat hingga β dari rentetan
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Keselamatan ingatan
        //
        // Replace_range tidak mempunyai masalah keselamatan memori vector Splice.
        // versi vector.Data hanya bait biasa.

        // PERINGATAN: Menyertakan pemboleh ubah ini adalah (#81138) yang tidak tepat
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // PERINGATAN: Menyertakan pemboleh ubah ini adalah (#81138) yang tidak tepat
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Menggunakan `range` sekali lagi tidak akan betul (#81138) Kami menganggap batas yang dilaporkan oleh `range` tetap sama, tetapi pelaksanaan lawan dapat berubah antara panggilan
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Menukarkan `String` ini menjadi [`Box`]`<`[`str`] `>`.
    ///
    /// Ini akan menurunkan kapasiti berlebihan.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Mengembalikan sepotong byte [`u8`] yang cuba ditukar menjadi `String`.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // sebilangan bait tidak sah, dalam vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Mengembalikan bait yang cuba ditukar menjadi `String`.
    ///
    /// Kaedah ini dibina dengan teliti untuk mengelakkan peruntukan.
    /// Ini akan menyebabkan kesalahan, mengeluarkan bait, sehingga salinan bait tidak perlu dibuat.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // sebilangan bait tidak sah, dalam vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Ambil `Utf8Error` untuk mendapatkan lebih banyak maklumat mengenai kegagalan penukaran.
    ///
    /// Jenis [`Utf8Error`] yang disediakan oleh [`std::str`] menunjukkan ralat yang mungkin berlaku ketika menukar sepotong [`u8`] s ke [`&str`].
    /// Dalam pengertian ini, ia adalah analog `FromUtf8Error`.
    /// Lihat dokumentasinya untuk lebih jelas mengenai penggunaannya.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // sebilangan bait tidak sah, dalam vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // bait pertama tidak sah di sini
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Kerana kita melakukan lelang pada `String`s, kita dapat menghindari sekurang-kurangnya satu peruntukan dengan mendapatkan rentetan pertama dari iterator dan menambahkannya ke semua rentetan berikutnya.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Kerana kami melakukan iterasi melalui CoWs, kita dapat (potentially) menghindari sekurang-kurangnya satu peruntukan dengan mendapatkan item pertama dan menambahkan semua item berikutnya.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Kemudahan yang memberi perwakilan kepada impl untuk `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Membuat `String` kosong.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Menggunakan operator `+` untuk menggabungkan dua rentetan.
///
/// Ini menggunakan `String` di sebelah kiri dan menggunakan semula buffernya (mengembangkannya jika perlu).
/// Ini dilakukan untuk mengelakkan mengalokasikan `String` baru dan menyalin keseluruhan kandungan pada setiap operasi, yang akan membawa kepada *O*(*n*^ 2) masa berjalan ketika membina rentetan *n*-byte dengan gabungan berulang.
///
///
/// Tali di sebelah kanan hanya dipinjam;kandungannya disalin ke `String` yang dikembalikan.
///
/// # Examples
///
/// Menggabungkan dua `String`s mengambil yang pertama dengan nilai dan meminjam yang kedua:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` dipindahkan dan tidak lagi boleh digunakan di sini.
/// ```
///
/// Sekiranya anda ingin terus menggunakan `String` pertama, anda boleh mengklonnya dan menambahkannya ke klon sebagai gantinya:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` masih berlaku di sini.
/// ```
///
/// Sepotong `&str` yang bersambung dapat dilakukan dengan menukar yang pertama menjadi `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Melaksanakan pengendali `+=` untuk menambahkan `String`.
///
/// Ini mempunyai tingkah laku yang sama dengan kaedah [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Jenis alias untuk [`Infallible`].
///
/// Alias ini wujud untuk keserasian kebelakang, dan akhirnya tidak dapat digunakan lagi.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait untuk menukar nilai ke `String`.
///
/// trait ini secara automatik dilaksanakan untuk semua jenis yang menerapkan [`Display`] trait.
/// Oleh itu, `ToString` tidak boleh dilaksanakan secara langsung:
/// [`Display`] harus dilaksanakan sebagai gantinya, dan anda mendapat pelaksanaan `ToString` secara percuma.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Menukar nilai yang diberikan kepada `String`.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Dalam pelaksanaan ini, kaedah `to_string` panics jika pelaksanaan `Display` mengembalikan kesalahan.
/// Ini menunjukkan pelaksanaan `Display` yang salah kerana `fmt::Write for String` tidak pernah mengembalikan ralat itu sendiri.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Garis panduan umum adalah untuk tidak menyelaraskan fungsi generik.
    // Walau bagaimanapun, mengeluarkan `#[inline]` dari kaedah ini menyebabkan regresi yang tidak dapat diabaikan.
    // Lihat <https://github.com/rust-lang/rust/pull/74852>, percubaan terakhir untuk mencubanya.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Menukar `&mut str` menjadi `String`.
    ///
    /// Hasilnya diperuntukkan di timbunan.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: ujian menarik dalam libstd, yang menyebabkan kesilapan di sini
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Menukar kepingan `str` kotak yang diberi ke `String`.
    /// Perlu diperhatikan bahawa kepingan `str` dimiliki.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Menukarkan `String` yang diberikan ke kepingan `str` kotak yang dimiliki.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Menukar irisan rentetan menjadi varian Borrowed.
    /// Tiada peruntukan timbunan dilakukan, dan rentetan tidak disalin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Menukar String menjadi varian Dimiliki.
    /// Tiada peruntukan timbunan dilakukan, dan rentetan tidak disalin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Menukarkan rujukan String menjadi varian Pinjam.
    /// Tiada peruntukan timbunan dilakukan, dan rentetan tidak disalin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Menukar `String` yang diberikan ke vector `Vec` yang memegang nilai jenis `u8`.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Iterator penyaliran untuk `String`.
///
/// Struktur ini dibuat dengan kaedah [`drain`] pada [`String`].
/// Lihat dokumentasinya untuk lebih lanjut.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Akan digunakan sebagai&'mut String dalam pemusnah
    string: *mut String,
    /// Mula bahagian untuk dibuang
    start: usize,
    /// Akhir bahagian untuk dibuang
    end: usize,
    /// Julat yang tinggal untuk dikeluarkan
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Gunakan Vec::drain.
            // "Reaffirm" pemeriksaan had untuk mengelakkan kod panic dimasukkan lagi.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Mengembalikan baki (sub) rentetan iterator ini sebagai potongan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: ketidakpuasan yang ditunjukkan oleh AsRef di bawah semasa menstabilkan.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Tidak berpuas hati semasa menstabilkan `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>untuk Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> untuk Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}