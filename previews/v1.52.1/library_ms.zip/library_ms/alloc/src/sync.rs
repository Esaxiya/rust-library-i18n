#![stable(feature = "rust1", since = "1.0.0")]

//! Petunjuk pengiraan rujukan selamat.
//!
//! Lihat dokumentasi [`Arc<T>`][Arc] untuk maklumat lebih lanjut.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Had lembut pada jumlah rujukan yang mungkin dibuat untuk `Arc`.
///
/// Melepasi had ini akan membatalkan program anda (walaupun tidak semestinya) pada rujukan _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer tidak menyokong pagar memori.
// Untuk mengelakkan laporan positif palsu dalam pelaksanaan Arc/Weak, gunakan beban atom untuk penyegerakan.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Penunjuk pengiraan rujukan yang selamat untuk utas.'Arc' bermaksud 'Atomically Reference Counted'.
///
/// Jenis `Arc<T>` memberikan pemilikan bersama bagi nilai jenis `T`, yang diperuntukkan dalam timbunan.Memohon [`clone`][clone] pada `Arc` menghasilkan contoh `Arc` baru, yang menunjukkan peruntukan yang sama pada timbunan dengan sumber `Arc`, sambil meningkatkan jumlah rujukan.
/// Apabila penunjuk `Arc` terakhir ke peruntukan tertentu dimusnahkan, nilai yang tersimpan dalam peruntukan tersebut (sering disebut sebagai "inner value") juga akan dijatuhkan.
///
/// Rujukan bersama dalam Rust tidak membenarkan mutasi secara lalai, dan `Arc` tidak terkecuali: anda secara amnya tidak dapat memperoleh rujukan yang dapat diubah untuk sesuatu di dalam `Arc`.Sekiranya anda perlu bermutasi melalui `Arc`, gunakan [`Mutex`][mutex], [`RwLock`][rwlock], atau salah satu jenis [`Atomic`][atomic].
///
/// ## Keselamatan Benang
///
/// Tidak seperti [`Rc<T>`], `Arc<T>` menggunakan operasi atom untuk pengiraan rujukannya.Ini bermaksud ia selamat di dalam benang.Kelemahannya ialah operasi atom lebih mahal daripada akses memori biasa.Sekiranya anda tidak berkongsi peruntukan yang dikira rujukan antara utas, pertimbangkan untuk menggunakan [`Rc<T>`] untuk overhead yang lebih rendah.
/// [`Rc<T>`] adalah lalai yang selamat, kerana penyusun akan melakukan sebarang percubaan untuk menghantar [`Rc<T>`] antara utas.
/// Walau bagaimanapun, perpustakaan mungkin memilih `Arc<T>` untuk memberi pengguna fleksibiliti lebih banyak.
///
/// `Arc<T>` akan melaksanakan [`Send`] dan [`Sync`] selagi `T` melaksanakan [`Send`] dan [`Sync`].
/// Mengapa anda tidak boleh memasukkan `T` jenis non-thread-safe dalam `Arc<T>` untuk menjadikannya thread-safe?Ini mungkin agak intuitif pada mulanya: bagaimanapun, bukankah titik keselamatan benang `Arc<T>`?Kuncinya adalah ini: `Arc<T>` menjadikan thread selamat untuk memiliki banyak pemilikan data yang sama, tetapi ia tidak menambahkan keselamatan thread pada datanya.
///
/// Pertimbangkan `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] bukan [`Sync`], dan jika `Arc<T>` selalu [`Send`], `Arc <` [`RefCell<T>"]"> juga akan.
/// Tetapi kita akan menghadapi masalah:
/// [`RefCell<T>`] tidak benang selamat;ia memantau jumlah pinjaman menggunakan operasi bukan atom.
///
/// Pada akhirnya, ini bermaksud bahawa anda mungkin perlu memasangkan `Arc<T>` dengan jenis [`std::sync`], biasanya [`Mutex<T>`][mutex].
///
/// ## Putaran putaran dengan `Weak`
///
/// Kaedah [`downgrade`][downgrade] boleh digunakan untuk membuat penunjuk [`Weak`] yang tidak dimiliki.Penunjuk [`Weak`] boleh menjadi [`upgrade`][upgrade] d ke `Arc`, tetapi ini akan mengembalikan [`None`] jika nilai yang tersimpan dalam peruntukan telah dijatuhkan.
/// Dengan kata lain, penunjuk `Weak` tidak mengekalkan nilai di dalam peruntukan;namun, mereka * tetap menyimpan peruntukan (kedai sokongan untuk nilai).
///
/// Kitaran antara penunjuk `Arc` tidak akan pernah dialihkan.
/// Atas sebab ini, [`Weak`] digunakan untuk memecahkan kitaran.Contohnya, pokok boleh mempunyai penunjuk `Arc` yang kuat dari nod ibu bapa kepada anak-anak, dan penunjuk [`Weak`] dari anak-anak kembali ke ibu bapa mereka.
///
/// # Rujukan pengklonan
///
/// Membuat rujukan baru dari penunjuk yang dikira rujukan yang ada dilakukan menggunakan `Clone` trait yang dilaksanakan untuk [`Arc<T>`][Arc] dan [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Dua sintaksis di bawah adalah setara.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, dan foo adalah semua busur yang menunjuk ke lokasi memori yang sama
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` penghapusan secara automatik ke `T` (melalui [`Deref`][deref] trait), jadi anda boleh memanggil kaedah `T 'pada nilai jenis `Arc<T>`.Untuk mengelakkan pertembungan nama dengan kaedah`T`, kaedah `Arc<T>` itu sendiri adalah fungsi yang berkaitan, disebut menggunakan [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Pelaksanaan traits seperti `Clone` juga boleh dipanggil menggunakan sintaks yang berkelayakan sepenuhnya.
/// Sebilangan orang lebih suka menggunakan sintaks yang memenuhi syarat sepenuhnya, sementara yang lain lebih suka menggunakan sintaks kaedah panggilan.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintaks kaedah-panggilan
/// let arc2 = arc.clone();
/// // Sintaks yang berkelayakan sepenuhnya
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] tidak memberikan penghapusan automatik kepada `T`, kerana nilai dalamannya mungkin sudah jatuh.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Berkongsi beberapa data yang tidak berubah antara utas:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Perhatikan bahawa kami **tidak** menjalankan ujian ini di sini.
// Pembangun windows menjadi sangat tidak senang jika benang melebihi benang utama dan kemudian keluar pada masa yang sama (sesuatu kebuntuan) jadi kami menghindarinya sepenuhnya dengan tidak menjalankan ujian ini.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Berkongsi [`AtomicUsize`] yang boleh berubah:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Lihat [`rc` documentation][rc_examples] untuk lebih banyak contoh pengiraan rujukan secara umum.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` adalah versi [`Arc`] yang menyimpan rujukan bukan milik terhadap peruntukan yang diuruskan.
/// Peruntukan diakses dengan memanggil [`upgrade`] pada penunjuk `Weak`, yang mengembalikan [`Option`]`<`[`Arc`] `<T>>`
///
/// Oleh kerana rujukan `Weak` tidak termasuk dalam pemilikan, ia tidak akan menghalang nilai yang tersimpan dalam peruntukan dijatuhkan, dan `Weak` sendiri tidak memberikan jaminan mengenai nilai yang masih ada.
///
/// Oleh itu ia mungkin mengembalikan [`None`] ketika [`upgrade`] d.
/// Walau bagaimanapun, perhatikan bahawa rujukan `Weak` * menghalang peruntukan itu sendiri (kedai penyokong) daripada dinyahalokasikan.
///
/// Penunjuk `Weak` berguna untuk menyimpan rujukan sementara terhadap peruntukan yang dikendalikan oleh [`Arc`] tanpa menghalang nilai dalamannya jatuh.
/// Ia juga digunakan untuk mencegah rujukan pekeliling antara penunjuk [`Arc`], kerana rujukan yang dimiliki sendiri tidak akan membenarkan [`Arc`] dijatuhkan.
/// Sebagai contoh, pokok boleh mempunyai penunjuk [`Arc`] yang kuat dari nod ibu bapa kepada anak-anak, dan penunjuk `Weak` dari anak-anak kembali ke ibu bapa mereka.
///
/// Cara khas untuk mendapatkan penunjuk `Weak` adalah memanggil [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ini adalah `NonNull` untuk membolehkan mengoptimumkan ukuran jenis ini dalam enum, tetapi tidak semestinya penunjuk yang sah.
    //
    // `Weak::new` menetapkan ini ke `usize::MAX` sehingga tidak perlu memperuntukkan ruang di timbunan.
    // Itu bukan nilai yang dapat dimiliki penunjuk sebenar kerana RcBox mempunyai penjajaran sekurang-kurangnya 2.
    // Ini hanya boleh dilakukan apabila `T: Sized`;`T` yang tidak bersaiz tidak pernah menjuntai.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Ini adalah bukti repr(C) hingga future terhadap kemungkinan penyusunan semula medan, yang akan mengganggu [into|from]_raw() jika tidak selamat dari jenis dalaman yang dapat dipindah.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // nilai usize::MAX bertindak sebagai pengawal untuk sementara "locking" kemampuan untuk menaik taraf titik lemah atau menurunkan yang kuat;ini digunakan untuk mengelakkan perlumbaan di `make_mut` dan `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Membina `Arc<T>` baru.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Mulakan kiraan penunjuk lemah sebagai 1 yang merupakan penunjuk lemah yang dipegang oleh semua penunjuk kuat (kinda), lihat std/rc.rs untuk maklumat lebih lanjut
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Membina `Arc<T>` baru menggunakan rujukan yang lemah untuk dirinya sendiri.
    /// Mencuba untuk meningkatkan rujukan yang lemah sebelum fungsi ini kembali akan menghasilkan nilai `None`.
    /// Walau bagaimanapun, rujukan yang lemah dapat diklon secara bebas dan disimpan untuk digunakan di lain waktu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Bentukkan bahagian dalam dalam keadaan "uninitialized" dengan satu rujukan lemah.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Penting agar kita tidak melepaskan kepemilikan pointer yang lemah, jika tidak, memori mungkin akan dibebaskan pada saat `data_fn` kembali.
        // Sekiranya kita benar-benar ingin melepaskan hak milik, kita dapat membuat penunjuk lemah tambahan untuk diri kita sendiri, tetapi ini akan menghasilkan kemas kini tambahan pada jumlah rujukan lemah yang mungkin tidak diperlukan sebaliknya.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Sekarang kita dapat menginisialisasi nilai dalaman dengan betul dan mengubah rujukan lemah kita menjadi rujukan yang kuat.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Penulisan di atas ke medan data mesti dapat dilihat oleh sebarang utas yang memperhatikan kiraan kuat bukan sifar.
            // Oleh itu, kita memerlukan sekurang-kurangnya pesanan "Release" agar dapat diselaraskan dengan `compare_exchange_weak` di `Weak::upgrade`.
            //
            // "Acquire" pesanan tidak diperlukan.
            // Semasa mempertimbangkan kemungkinan tingkah laku `data_fn`, kita hanya perlu melihat apa yang boleh dilakukannya dengan merujuk kepada `Weak` yang tidak dapat ditingkatkan:
            //
            // - Ia dapat *mengklon*`Weak`, meningkatkan jumlah rujukan yang lemah.
            // - Ia dapat menjatuhkan klon tersebut, mengurangkan jumlah rujukan yang lemah (tetapi tidak pernah menjadi sifar).
            //
            // Kesan sampingan ini tidak memberi kesan kepada kita dengan cara apa pun, dan kesan sampingan lain tidak mungkin berlaku dengan kod selamat sahaja.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Rujukan kuat secara kolektif harus memiliki rujukan lemah bersama, jadi jangan jalankan pemusnah untuk rujukan lemah lama kami.
        //
        mem::forget(weak);
        strong
    }

    /// Membina `Arc` baru dengan kandungan yang tidak dimulakan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Permulaan tertunda:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Membina `Arc` baru dengan kandungan yang tidak dimulakan, dengan memori diisi dengan bait `0`.
    ///
    ///
    /// Lihat [`MaybeUninit::zeroed`][zeroed] untuk contoh penggunaan kaedah ini dengan betul dan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Membina `Pin<Arc<T>>` baru.
    /// Sekiranya `T` tidak melaksanakan `Unpin`, maka `data` akan disematkan dalam memori dan tidak dapat dipindahkan.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Membina `Arc<T>` baru, mengembalikan ralat jika peruntukan gagal.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Mulakan kiraan penunjuk lemah sebagai 1 yang merupakan penunjuk lemah yang dipegang oleh semua penunjuk kuat (kinda), lihat std/rc.rs untuk maklumat lebih lanjut
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Membina `Arc` baru dengan kandungan yang tidak dimulakan, mengembalikan ralat jika peruntukan gagal.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Permulaan tertunda:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Membina `Arc` baru dengan kandungan yang tidak dimulakan, dengan memori diisi dengan bait `0`, mengembalikan ralat jika peruntukan gagal.
    ///
    ///
    /// Lihat [`MaybeUninit::zeroed`][zeroed] untuk contoh penggunaan kaedah ini dengan betul dan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Mengembalikan nilai dalaman, jika `Arc` mempunyai tepat satu rujukan kuat.
    ///
    /// Jika tidak, [`Err`] dikembalikan dengan `Arc` yang sama yang diteruskan.
    ///
    ///
    /// Ini akan berjaya walaupun terdapat rujukan lemah yang luar biasa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Buat penunjuk yang lemah untuk membersihkan rujukan kuat-lemah yang tersirat
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Membina potongan baru yang dikira secara rujukan atom dengan kandungan yang tidak dimulakan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Permulaan tertunda:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Membina potongan baru yang dikira secara rujukan atom dengan kandungan yang tidak dimulakan, dengan memori diisi dengan bait `0`.
    ///
    ///
    /// Lihat [`MaybeUninit::zeroed`][zeroed] untuk contoh penggunaan kaedah ini dengan betul dan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Menukar kepada `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Seperti [`MaybeUninit::assume_init`], terserah kepada pemanggil untuk menjamin bahawa nilai dalaman benar-benar berada dalam keadaan yang diinisialisasi.
    ///
    /// Menyebutnya ketika kandungan belum diinisialisasi sepenuhnya menyebabkan tingkah laku tidak ditentukan langsung.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Permulaan tertunda:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Menukar kepada `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Seperti [`MaybeUninit::assume_init`], terserah kepada pemanggil untuk menjamin bahawa nilai dalaman benar-benar berada dalam keadaan yang diinisialisasi.
    ///
    /// Menyebutnya ketika kandungan belum diinisialisasi sepenuhnya menyebabkan tingkah laku tidak ditentukan langsung.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Permulaan tertunda:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Menggunakan `Arc`, mengembalikan penunjuk yang dibungkus.
    ///
    /// Untuk mengelakkan kebocoran memori, penunjuk mesti ditukar kembali ke `Arc` menggunakan [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Menyediakan penunjuk mentah ke data.
    ///
    /// Kiraan tidak akan terjejas dengan cara apa pun dan `Arc` tidak habis.
    /// Penunjuk berlaku selama terdapat bilangan yang kuat di `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // KESELAMATAN: Ini tidak boleh melalui Deref::deref atau RcBoxPtr::inner kerana
        // ini diperlukan untuk mengekalkan asalnya raw/mut seperti misalnya
        // `get_mut` boleh menulis melalui penunjuk selepas Rc dipulihkan melalui `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Membina `Arc<T>` dari penunjuk mentah.
    ///
    /// Penunjuk mentah mesti dikembalikan sebelumnya dengan panggilan ke [`Arc<U>::into_raw`][into_raw] di mana `U` mesti mempunyai ukuran dan penjajaran yang sama dengan `T`.
    /// Ini benar jika `U` adalah `T`.
    /// Perhatikan bahawa jika `U` bukan `T` tetapi mempunyai ukuran dan penjajaran yang sama, ini pada dasarnya seperti menghantar rujukan dari pelbagai jenis.
    /// Lihat [`mem::transmute`][transmute] untuk maklumat lebih lanjut mengenai sekatan apa yang berlaku dalam kes ini.
    ///
    /// Pengguna `from_raw` harus memastikan nilai `T` tertentu hanya dijatuhkan sekali.
    ///
    /// Fungsi ini tidak selamat kerana penggunaan yang tidak betul boleh menyebabkan memori tidak selamat, walaupun `Arc<T>` yang dikembalikan tidak pernah diakses.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Tukar kembali ke `Arc` untuk mengelakkan kebocoran.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Panggilan lebih lanjut ke `Arc::from_raw(x_ptr)` akan menjadi memori yang tidak selamat.
    /// }
    ///
    /// // Memori itu dibebaskan ketika `x` keluar dari ruang lingkup di atas, jadi `x_ptr` sekarang tergantung!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Balikkan ofset untuk mencari ArcInner yang asal.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Membuat penunjuk [`Weak`] baru untuk peruntukan ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Relaxed ini OK kerana kami sedang memeriksa nilai di CAS di bawah.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // periksa sama ada pembilang lemah "locked" pada masa ini;jika ya, putar.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: kod ini pada masa ini mengabaikan kemungkinan limpahan
            // ke dalam usize::MAX;secara amnya Rc dan Arc perlu disesuaikan untuk mengatasi limpahan.
            //

            // Tidak seperti dengan Clone(), kami memerlukan ini untuk menjadi Acquire read untuk diselaraskan dengan tulisan yang berasal dari `is_unique`, supaya peristiwa sebelum penulisan itu berlaku sebelum pembacaan ini.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Pastikan kita tidak membuat Lemah yang menggantung
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Mendapat bilangan penunjuk [`Weak`] ke peruntukan ini.
    ///
    /// # Safety
    ///
    /// Kaedah ini dengan sendirinya selamat, tetapi menggunakannya dengan betul memerlukan penjagaan tambahan.
    /// Benang lain dapat mengubah kiraan lemah pada bila-bila masa, termasuk berpotensi antara memanggil kaedah ini dan bertindak berdasarkan hasilnya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Penegasan ini bersifat deterministik kerana kami belum berkongsi `Arc` atau `Weak` antara utas.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Sekiranya kiraan lemah saat ini dikunci, nilai kiraan adalah 0 sebelum mengambil kunci.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Mendapat bilangan penunjuk (`Arc`) yang kuat untuk peruntukan ini.
    ///
    /// # Safety
    ///
    /// Kaedah ini dengan sendirinya selamat, tetapi menggunakannya dengan betul memerlukan penjagaan tambahan.
    /// Benang lain dapat mengubah kiraan kuat pada bila-bila masa, termasuk berpotensi antara memanggil kaedah ini dan bertindak berdasarkan hasilnya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Tegasan ini bersifat deterministik kerana kami belum berkongsi `Arc` antara utas.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Meningkatkan jumlah rujukan kuat pada `Arc<T>` yang berkaitan dengan penunjuk yang diberikan oleh satu.
    ///
    /// # Safety
    ///
    /// Penunjuk mesti diperoleh melalui `Arc::into_raw`, dan contoh `Arc` yang berkaitan mesti sah (iaitu
    /// kiraan kuat mestilah sekurang-kurangnya 1) selama kaedah ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Tegasan ini bersifat deterministik kerana kami belum berkongsi `Arc` antara utas.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Kekalkan Arc, tetapi jangan sentuh refcount dengan membungkus secara manual
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Sekarang tingkatkan jumlah pengiraan semula, tetapi jangan juga menjatuhkan jumlah semula
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Mengurangkan jumlah rujukan yang kuat pada `Arc<T>` yang berkaitan dengan penunjuk yang diberikan oleh satu.
    ///
    /// # Safety
    ///
    /// Penunjuk mesti diperoleh melalui `Arc::into_raw`, dan contoh `Arc` yang berkaitan mesti sah (iaitu
    /// kiraan kuat mesti sekurang-kurangnya 1) semasa menggunakan kaedah ini.
    /// Kaedah ini dapat digunakan untuk melepaskan `Arc` akhir dan backing storage, tetapi **tidak boleh** dipanggil setelah `Arc` akhir dilepaskan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Penegasan tersebut bersifat deterministik kerana kami belum berkongsi `Arc` antara utas.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ketidakamanan ini baik kerana semasa busur ini masih hidup, kami dijamin penunjuk dalamannya sah.
        // Selain itu, kita tahu bahawa struktur `ArcInner` itu sendiri adalah `Sync` kerana data dalamannya juga `Sync`, jadi kita ok meminjamkan penunjuk yang tidak berubah kepada kandungan ini.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Bahagian `drop` yang tidak sebaris.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Hancurkan data pada masa ini, walaupun kami mungkin tidak membebaskan peruntukan kotak itu sendiri (mungkin masih ada petunjuk lemah yang ada di sekitarnya).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Jatuhkan ref yang lemah secara kolektif yang dipegang oleh semua rujukan kuat
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Mengembalikan `true` jika kedua-dua `Arc` menunjukkan peruntukan yang sama (dalam urat yang serupa dengan [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Memperuntukkan `ArcInner<T>` dengan ruang yang mencukupi untuk nilai dalaman yang mungkin tidak bersaiz di mana nilainya mempunyai susun atur yang disediakan.
    ///
    /// Fungsi `mem_to_arcinner` dipanggil dengan penunjuk data dan mesti mengembalikan penunjuk (berpotensi gemuk) untuk `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Kira susun atur menggunakan susun atur nilai yang diberikan.
        // Sebelumnya, susun atur dihitung pada ungkapan `&*(ptr as* const ArcInner<T>)`, tetapi ini membuat rujukan yang tidak sejajar (lihat #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Memperuntukkan `ArcInner<T>` dengan ruang yang cukup untuk nilai dalaman yang mungkin tidak berukuran di mana nilainya mempunyai susun atur yang disediakan, mengembalikan ralat jika peruntukan gagal.
    ///
    ///
    /// Fungsi `mem_to_arcinner` dipanggil dengan penunjuk data dan mesti mengembalikan penunjuk (berpotensi gemuk) untuk `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Kira susun atur menggunakan susun atur nilai yang diberikan.
        // Sebelumnya, susun atur dihitung pada ungkapan `&*(ptr as* const ArcInner<T>)`, tetapi ini membuat rujukan yang tidak sejajar (lihat #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Memulakan ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Memperuntukkan `ArcInner<T>` dengan ruang yang mencukupi untuk nilai dalaman yang tidak bersaiz.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Peruntukkan `ArcInner<T>` menggunakan nilai yang diberikan.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nilai salin sebagai bait
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Bebaskan peruntukan tanpa membuang isinya
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Memperuntukkan `ArcInner<[T]>` dengan panjang yang diberikan.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Salin elemen dari slice ke Arc <\[T\]> yang baru diperuntukkan
    ///
    /// Tidak selamat kerana pemanggil mesti mengambil hak milik atau mengikat `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Membina `Arc<[T]>` dari iterator yang diketahui mempunyai ukuran tertentu.
    ///
    /// Tingkah laku tidak ditentukan sekiranya ukurannya salah.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Pengawal Panic sambil mengklon elemen T.
        // Sekiranya panic, elemen yang telah ditulis ke dalam ArcInner baru akan dijatuhkan, maka memori akan dibebaskan.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Penunjuk ke elemen pertama
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Semua siap.Lupakan pengawal sehingga tidak membebaskan ArcInner baru.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Pengkhususan trait digunakan untuk `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Membuat klon penunjuk `Arc`.
    ///
    /// Ini menjadikan penunjuk lain kepada peruntukan yang sama, meningkatkan jumlah rujukan yang kuat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Menggunakan pesanan yang santai adalah baik-baik saja di sini, kerana pengetahuan tentang rujukan asal menghalang utas lain daripada menghapus objek secara salah.
        //
        // Seperti yang dijelaskan dalam [Boost documentation][1], Menambah penghitung rujukan selalu dapat dilakukan dengan memory_order_relaxed: Rujukan baru ke objek hanya dapat dibentuk dari rujukan yang ada, dan menyampaikan rujukan yang ada dari satu utas ke utas yang lain mesti sudah menyediakan penyegerakan yang diperlukan.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Walau bagaimanapun, kita perlu berjaga-jaga daripada jumlah yang besar sekiranya seseorang `mem: : lupa`ing Arcs.
        // Sekiranya kita tidak melakukan ini, jumlahnya dapat melimpah dan pengguna akan menggunakan selepas penggunaan secara percuma.
        // Kami merendahkan `isize::MAX` dengan andaian bahawa tidak ada benang ~2 bilion yang menambah jumlah rujukan sekaligus.
        //
        // branch ini tidak akan diambil dalam program yang realistik.
        //
        // Kami batalkan kerana program seperti ini sangat merosot, dan kami tidak peduli untuk menyokongnya.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Membuat rujukan yang boleh berubah ke `Arc` yang diberikan.
    ///
    /// Sekiranya terdapat petunjuk `Arc` atau [`Weak`] lain ke peruntukan yang sama, maka `make_mut` akan membuat peruntukan baru dan memanggil [`clone`][clone] pada nilai dalaman untuk memastikan pemilikan yang unik.
    /// Ini juga disebut sebagai clone-on-write.
    ///
    /// Perhatikan bahawa ini berbeza dengan tingkah laku [`Rc::make_mut`] yang melepaskan setiap petunjuk `Weak` yang tinggal.
    ///
    /// Lihat juga [`get_mut`][get_mut], yang akan gagal dan bukannya pengklonan.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Tidak akan mengklon apa-apa
    /// let mut other_data = Arc::clone(&data); // Tidak akan mengklon data dalaman
    /// *Arc::make_mut(&mut data) += 1;         // Data dalaman klon
    /// *Arc::make_mut(&mut data) += 1;         // Tidak akan mengklon apa-apa
    /// *Arc::make_mut(&mut other_data) *= 2;   // Tidak akan mengklon apa-apa
    ///
    /// // Sekarang `data` dan `other_data` menunjukkan peruntukan yang berbeza.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Perhatikan bahawa kami mempunyai rujukan kuat dan rujukan lemah.
        // Oleh itu, melepaskan rujukan kuat kami sahaja tidak akan menyebabkan memori akan dialihkan.
        //
        // Gunakan Acquire untuk memastikan bahawa kita melihat penulisan ke `weak` yang berlaku sebelum pelepasan menulis (iaitu, pengurangan) hingga `strong`.
        // Oleh kerana kami mempunyai jumlah yang lemah, tidak mungkin ArcInner itu sendiri dapat disingkirkan.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Penunjuk kuat lain ada, jadi kita mesti mengklon.
            // Pra-peruntukkan memori untuk membolehkan menulis nilai klon secara langsung.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Cukup santai di atas kerana ini pada dasarnya adalah pengoptimuman: kita selalu berlumba dengan penunjuk lemah yang dijatuhkan.
            // Perkara terburuk, akhirnya kami memperuntukkan Arc baru tanpa perlu.
            //

            // Kami membuang ref yang kuat terakhir, tetapi masih ada baki ref yang lemah.
            // Kami akan memindahkan kandungannya ke Arc baru, dan membatalkan rujukan lemah yang lain.
            //

            // Perhatikan bahawa tidak mungkin pembacaan `weak` menghasilkan usize::MAX (iaitu, terkunci), kerana kiraan lemah hanya dapat dikunci oleh utas dengan rujukan yang kuat.
            //
            //

            // Wujudkan penunjuk lemah tersirat kita sendiri, sehingga dapat membersihkan ArcInner seperti yang diperlukan.
            //
            let _weak = Weak { ptr: this.ptr };

            // Hanya boleh mencuri data, yang tinggal hanyalah Kelemahan
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Kami adalah satu-satunya rujukan bagi kedua-dua jenis ini;menaikkan kembali kiraan ref yang kuat.
            //
            this.inner().strong.store(1, Release);
        }

        // Seperti `get_mut()`, ketidakcukupan itu baik kerana rujukan kami unik untuk bermula, atau menjadi salah satu setelah mengklon kandungannya.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Mengembalikan rujukan yang dapat diubah ke `Arc` yang diberikan, jika tidak ada penunjuk `Arc` atau [`Weak`] lain ke peruntukan yang sama.
    ///
    ///
    /// Mengembalikan [`None`] sebaliknya, kerana tidak dapat mengubah nilai bersama.
    ///
    /// Lihat juga [`make_mut`][make_mut], yang akan [`clone`][clone] nilai dalaman apabila ada petunjuk lain.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ketidakamanan ini baik kerana kami dijamin bahawa penunjuk yang dikembalikan adalah penunjuk *only* yang akan dikembalikan ke T.
            // Jumlah rujukan kami dijamin 1 pada ketika ini, dan kami memerlukan Arc itu sendiri menjadi `mut`, jadi kami mengembalikan satu-satunya rujukan yang mungkin untuk data dalaman.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Mengembalikan rujukan yang dapat diubah ke dalam `Arc` yang diberikan, tanpa sebarang pemeriksaan.
    ///
    /// Lihat juga [`get_mut`], yang selamat dan melakukan pemeriksaan yang sesuai.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Sebarang petunjuk `Arc` atau [`Weak`] lain untuk peruntukan yang sama tidak boleh ditangguhkan sepanjang tempoh pinjaman yang dikembalikan.
    ///
    /// Ini adalah perkara kecil jika tidak ada petunjuk seperti itu, contohnya sejurus selepas `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Kami berhati-hati untuk *tidak* membuat rujukan yang merangkumi bidang "count", kerana ini juga dengan akses serentak ke jumlah rujukan (mis.
        // oleh `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Tentukan sama ada ini adalah rujukan unik (termasuk rujukan lemah) kepada data yang mendasari.
    ///
    ///
    /// Perhatikan bahawa ini memerlukan penguncian bilangan ref yang lemah.
    fn is_unique(&mut self) -> bool {
        // mengunci jumlah penunjuk lemah jika kita nampaknya satu-satunya pemegang penunjuk lemah.
        //
        // Label pemerolehan di sini memastikan hubungan yang berlaku sebelum berlaku dengan penulisan ke `strong` (khususnya di `Weak::upgrade`) sebelum pengurangan jumlah `weak` (melalui `Weak::drop`, yang menggunakan pelepasan).
        // Sekiranya ref yang lemah yang ditingkatkan tidak pernah dijatuhkan, CAS di sini akan gagal jadi kami tidak peduli untuk menyegerakkan.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Ini perlu menjadi `Acquire` untuk diselaraskan dengan penurunan kaunter `strong` di `drop`-satu-satunya akses yang berlaku apabila ada tetapi rujukan terakhir dijatuhkan.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Tulisan keluaran di sini diselaraskan dengan bacaan di `downgrade`, dengan berkesan menghalang pembacaan `strong` di atas daripada berlaku selepas penulisan.
            //
            //
            self.inner().weak.store(1, Release); // lepaskan kunci
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Turunkan `Arc`.
    ///
    /// Ini akan mengurangkan jumlah rujukan yang kuat.
    /// Sekiranya kiraan rujukan kuat mencapai sifar maka satu-satunya rujukan lain (jika ada) adalah [`Weak`], jadi kami `drop` nilai dalaman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Tidak mencetak apa-apa
    /// drop(foo2);   // Cetakan "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Oleh kerana `fetch_sub` sudah atomik, kita tidak perlu menyegerakkan dengan utas lain kecuali kita akan menghapus objek tersebut.
        // Logik yang sama ini berlaku untuk kiraan `fetch_sub` hingga `weak` di bawah.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Pagar ini diperlukan untuk mencegah penyusunan semula penggunaan data dan penghapusan data.
        // Oleh kerana ia ditandai `Release`, penurunan jumlah rujukan akan diselaraskan dengan pagar `Acquire` ini.
        // Ini bermaksud penggunaan data berlaku sebelum menurunkan jumlah rujukan, yang berlaku sebelum pagar ini, yang berlaku sebelum penghapusan data.
        //
        // Seperti yang dijelaskan dalam [Boost documentation][1],
        //
        // > Penting untuk menegakkan kemungkinan akses ke objek dalam satu
        // > utas (melalui rujukan yang ada) untuk *berlaku sebelum* menghapus
        // > objek dalam utas yang berbeza.Ini dicapai oleh "release"
        // > operasi setelah menjatuhkan rujukan (sebarang akses ke objek
        // > melalui rujukan ini semestinya berlaku sebelum ini), dan
        // > "acquire" operasi sebelum memadam objek.
        //
        // Khususnya, walaupun kandungan Arc biasanya tidak berubah, ada kemungkinan menulis dalaman untuk sesuatu seperti Mutex<T>.
        // Oleh kerana Mutex tidak diperoleh ketika dihapuskan, kita tidak boleh bergantung pada logik penyegerakannya untuk membuat penulisan di utas A yang dapat dilihat oleh pemusnah yang berjalan di benang B.
        //
        //
        // Perhatikan juga bahawa pagar Acquire di sini mungkin dapat diganti dengan beban Acquire, yang dapat meningkatkan prestasi dalam situasi yang sangat disukai.Lihat [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Percubaan untuk menurunkan `Arc<dyn Any + Send + Sync>` ke jenis konkrit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Membina `Weak<T>` baru, tanpa memperuntukkan memori.
    /// Memanggil [`upgrade`] pada nilai pengembalian selalu memberikan [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Jenis pembantu untuk membolehkan mengakses jumlah rujukan tanpa membuat penegasan mengenai bidang data.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Mengembalikan penunjuk mentah ke objek `T` yang ditunjukkan oleh `Weak<T>` ini.
    ///
    /// Penunjuk hanya berlaku jika terdapat beberapa rujukan yang kuat.
    /// Penunjuk mungkin menggantung, tidak sejajar atau bahkan [`null`] sebaliknya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Kedua-duanya menunjuk ke objek yang sama
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Yang kuat di sini menjadikannya hidup, jadi kita masih dapat mengakses objek.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Tetapi tidak lagi.
    /// // Kita boleh melakukan weak.as_ptr(), tetapi mengakses penunjuk akan menyebabkan tingkah laku yang tidak ditentukan.
    /// // assert_eq! ("hello", tidak selamat {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Sekiranya penunjuk digantung, kami mengembalikan sentinel secara langsung.
            // Ini bukan alamat muatan yang sah, kerana muatan sekurang-kurangnya sejajar dengan ArcInner (usize).
            ptr as *const T
        } else {
            // KESELAMATAN: jika is_dangling kembali palsu, maka penunjuk tidak dapat ditanggalkan.
            // Muatan mungkin turun pada tahap ini, dan kita harus menjaga ketahanan, jadi gunakan manipulasi penunjuk mentah.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Menggunakan `Weak<T>` dan mengubahnya menjadi penunjuk mentah.
    ///
    /// Ini mengubah pointer lemah menjadi pointer mentah, sementara masih mengekalkan pemilikan satu rujukan lemah (kiraan lemah tidak diubah oleh operasi ini).
    /// Ia boleh diubah menjadi `Weak<T>` dengan [`from_raw`].
    ///
    /// Sekatan yang sama untuk mencapai sasaran penunjuk seperti dengan [`as_ptr`] berlaku.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Menukar penunjuk mentah yang sebelumnya dibuat oleh [`into_raw`] kembali ke `Weak<T>`.
    ///
    /// Ini boleh digunakan untuk mendapatkan rujukan kuat dengan selamat (dengan menghubungi [`upgrade`] kemudian) atau untuk mengalihkan kiraan lemah dengan menjatuhkan `Weak<T>`.
    ///
    /// Memerlukan satu rujukan yang lemah (dengan pengecualian petunjuk yang dibuat oleh [`new`], kerana ini tidak memiliki apa-apa; kaedah masih berfungsi).
    ///
    /// # Safety
    ///
    /// Penunjuk mesti berasal dari [`into_raw`] dan masih mesti mempunyai rujukan lemah yang berpotensi.
    ///
    /// Dibolehkan untuk kiraan kuat adalah 0 pada saat memanggil ini.
    /// Walaupun begitu, ini memerlukan satu rujukan lemah yang kini ditunjukkan sebagai penunjuk mentah (kiraan lemah tidak diubah oleh operasi ini) dan oleh itu ia mesti dipasangkan dengan panggilan sebelumnya ke [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Kurangkan kiraan lemah terakhir.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Lihat Weak::as_ptr untuk konteks bagaimana penunjuk input dihasilkan.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ini adalah Lemah yang menggantung.
            ptr as *mut ArcInner<T>
        } else {
            // Jika tidak, kami dijamin penunjuknya berasal dari Lemah yang tidak larut.
            // KESELAMATAN: data_offset selamat dipanggil, kerana ptr merujuk T. yang sebenar (berpotensi jatuh)
            let offset = unsafe { data_offset(ptr) };
            // Oleh itu, kami membalikkan ofset untuk mendapatkan keseluruhan RcBox.
            // KESELAMATAN: penunjuk berasal dari Lemah, jadi pengimbangan ini selamat.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // KESELAMATAN: sekarang kita telah mendapatkan penunjuk Lemah yang asli, jadi boleh membuat yang Lemah.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Percubaan untuk meningkatkan penunjuk `Weak` ke [`Arc`], menunda penurunan nilai dalaman jika berjaya.
    ///
    ///
    /// Mengembalikan [`None`] jika nilai dalaman telah dijatuhkan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Hancurkan semua petunjuk yang kuat.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Kami menggunakan gelung CAS untuk meningkatkan kiraan kuat dan bukannya fetch_add kerana fungsi ini tidak boleh mengambil kiraan rujukan dari sifar hingga satu.
        //
        //
        let inner = self.inner()?;

        // Beban santai kerana sebarang penulisan 0 yang dapat kita amati meninggalkan medan dalam keadaan sifar kekal (jadi bacaan "stale" 0 baik-baik saja), dan nilai lain disahkan melalui CAS di bawah.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Lihat komen di `Arc::clone` mengapa kami melakukan ini (untuk `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Santai baik-baik saja untuk kes kegagalan kerana kita tidak mempunyai harapan mengenai keadaan baru.
            // Perlu diambil untuk kes kejayaan diselaraskan dengan `Arc::new_cyclic`, apabila nilai dalaman dapat diinisialisasi setelah rujukan `Weak` telah dibuat.
            // Dalam kes ini, kami menjangkakan akan memerhatikan nilai yang diinisialisasi sepenuhnya.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null diperiksa di atas
                Err(old) => n = old,
            }
        }
    }

    /// Mendapat bilangan penunjuk (`Arc`) yang kuat yang menunjukkan peruntukan ini.
    ///
    /// Sekiranya `self` dibuat menggunakan [`Weak::new`], ini akan mengembalikan 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Mendapat perkiraan bilangan penunjuk `Weak` yang menunjukkan peruntukan ini.
    ///
    /// Sekiranya `self` dibuat menggunakan [`Weak::new`], atau jika tidak ada penunjuk kuat yang tersisa, ini akan mengembalikan 0.
    ///
    /// # Accuracy
    ///
    /// Oleh kerana perincian pelaksanaan, nilai yang dikembalikan dapat dimatikan oleh 1 pada kedua arah ketika utas lain memanipulasi mana-mana `Arc`s atau` Lemah yang menunjukkan peruntukan yang sama.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Oleh kerana kita memerhatikan bahawa terdapat sekurang-kurangnya satu penunjuk yang kuat setelah membaca kiraan lemah, kita tahu bahawa rujukan lemah yang tersirat (ada bila ada rujukan kuat masih hidup) masih ada ketika kita melihat kiraan lemah, dan oleh itu dapat mengurangkannya dengan selamat.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Mengembalikan `None` ketika penunjuk digantung dan tidak ada `ArcInner` yang diperuntukkan, (iaitu, ketika `Weak` ini dibuat oleh `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Kami berhati-hati untuk *tidak* membuat rujukan yang meliputi bidang "data", kerana medan tersebut dapat dimutasi secara serentak (contohnya, jika `Arc` terakhir dijatuhkan, bidang data akan digugurkan di tempat).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Mengembalikan `true` jika kedua-dua `Lemah menunjukkan peruntukan yang sama (serupa dengan [`ptr::eq`]), atau jika kedua-duanya tidak menunjukkan peruntukan apa pun (kerana dibuat dengan `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Oleh kerana ini membandingkan petunjuk, ini bermaksud bahawa `Weak::new()` akan sama antara satu sama lain, walaupun mereka tidak menunjukkan peruntukan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Membandingkan `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Membuat klon penunjuk `Weak` yang menunjukkan peruntukan yang sama.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Lihat komen di Arc::clone() mengapa ini santai.
        // Ini boleh menggunakan fetch_add (mengabaikan kunci) kerana jumlah lemah hanya terkunci di mana *tidak ada* petunjuk lain yang lemah.
        //
        // (Oleh itu, kita tidak dapat menjalankan kod ini).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Lihat komen di Arc::clone() mengapa kami melakukan ini (untuk mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Membina `Weak<T>` baru, tanpa memperuntukkan memori.
    /// Memanggil [`upgrade`] pada nilai pengembalian selalu memberikan [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Turunkan penunjuk `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Tidak mencetak apa-apa
    /// drop(foo);        // Cetakan "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Sekiranya kita mengetahui bahawa kita adalah penunjuk lemah terakhir, maka sudah waktunya untuk membuang semua data sepenuhnya.Lihat perbincangan di Arc::drop() mengenai susunan memori
        //
        // Tidak perlu memeriksa keadaan terkunci di sini, kerana kiraan lemah hanya dapat dikunci jika ada tepat satu rujukan lemah, yang bermaksud penurunan itu hanya dapat berjalan di sebelah kiri yang lemah, yang hanya dapat terjadi setelah kunci dilepaskan.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Kami melakukan pengkhususan ini di sini, dan bukan sebagai pengoptimuman yang lebih umum pada `&T`, kerana jika tidak, ia akan menambahkan kos untuk semua pemeriksaan kesetaraan pada rujukan.
/// Kami menganggap bahawa `Arc`s digunakan untuk menyimpan nilai-nilai besar, yang lambat diklon, tetapi juga berat untuk memeriksa kesetaraan, menyebabkan kos ini lebih mudah dilunasi.
///
/// Ia juga cenderung mempunyai dua klon `Arc`, yang menunjukkan nilai yang sama, daripada dua `&T`s.
///
/// Kami hanya dapat melakukan ini apabila `T: Eq` sebagai `PartialEq` mungkin sengaja tidak merefleksikan.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Persamaan untuk dua `Arc`s.
    ///
    /// Dua `Arc` sama jika nilai dalamannya sama, walaupun disimpan dalam peruntukan yang berbeza.
    ///
    /// Sekiranya `T` juga menerapkan `Eq` (menyiratkan refleksiviti persamaan), dua `Arc` yang menunjukkan peruntukan yang sama selalu sama.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ketidaksamaan untuk dua `Arc`s.
    ///
    /// Dua `Arc`s tidak sama jika nilai dalamannya tidak sama.
    ///
    /// Sekiranya `T` juga menerapkan `Eq` (menyiratkan refleksiviti persamaan), dua `Arc` yang menunjukkan nilai yang sama tidak akan sama.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Perbandingan separa untuk dua `Arc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `partial_cmp()` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Kurang daripada perbandingan untuk dua `Arc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `<` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Perbandingan 'Kurang daripada atau sama dengan' untuk dua `Arc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `<=` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Perbandingan lebih hebat daripada dua `Arc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `>` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Perbandingan 'Lebih besar daripada atau sama dengan' untuk dua `Arc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `>=` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Perbandingan untuk dua `Arc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `cmp()` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Membuat `Arc<T>` baru, dengan nilai `Default` untuk `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Peruntukkan potongan yang dikira rujukan dan isi dengan mengklon item `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Peruntukkan `str` yang dikira rujukan dan salin `v` ke dalamnya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Peruntukkan `str` yang dikira rujukan dan salin `v` ke dalamnya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Pindahkan objek berkotak ke peruntukan baru yang dikira rujukan.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Alihkan potongan yang dikira rujukan dan pindahkan item `v` ke dalamnya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Benarkan Vec untuk membebaskan ingatannya, tetapi tidak menghancurkan isinya
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Mengambil setiap elemen dalam `Iterator` dan mengumpulkannya menjadi `Arc<[T]>`.
    ///
    /// # Ciri prestasi
    ///
    /// ## Kes umum
    ///
    /// Dalam kes umum, pengumpulan menjadi `Arc<[T]>` dilakukan dengan pengumpulan pertama menjadi `Vec<T>`.Iaitu, semasa menulis perkara berikut:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ini berkelakuan seolah-olah kita menulis:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Kumpulan peruntukan pertama berlaku di sini.
    ///     .into(); // Peruntukan kedua untuk `Arc<[T]>` berlaku di sini.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ini akan memperuntukkan sebanyak yang diperlukan untuk membina `Vec<T>` dan kemudian akan diperuntukkan sekali untuk mengubah `Vec<T>` menjadi `Arc<[T]>`.
    ///
    ///
    /// ## Pengulangan panjang yang diketahui
    ///
    /// Apabila `Iterator` anda menggunakan `TrustedLen` dan mempunyai ukuran yang tepat, satu peruntukan akan dibuat untuk `Arc<[T]>`.Sebagai contoh:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Hanya satu peruntukan berlaku di sini.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Pengkhususan trait digunakan untuk mengumpulkan menjadi `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Ini adalah kes untuk iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // KESELAMATAN: Kita perlu memastikan bahawa iterator mempunyai panjang yang tepat dan yang kita miliki.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Kembali ke pelaksanaan normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Dapatkan pengimbangan dalam `ArcInner` untuk muatan di belakang penunjuk.
///
/// # Safety
///
/// Penunjuk mesti menunjukkan (dan mempunyai metadata yang sah untuk) contoh T yang sah sebelumnya, tetapi T dibenarkan untuk dijatuhkan.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Sejajarkan nilai yang tidak bersaiz hingga akhir ArcInner.
    // Kerana RcBox adalah repr(C), ia akan selalu menjadi medan terakhir dalam memori.
    // KESELAMATAN: kerana satu-satunya jenis yang tidak diukur adalah kepingan, objek trait,
    // dan jenis luaran, syarat keselamatan input pada masa ini cukup untuk memenuhi syarat align_of_val_raw;ini adalah perincian pelaksanaan bahasa yang mungkin tidak boleh dipercayai di luar std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}