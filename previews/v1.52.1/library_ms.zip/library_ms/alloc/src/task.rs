#![stable(feature = "wake_trait", since = "1.51.0")]
//! Jenis dan Traits untuk bekerja dengan tugas tak segerak.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Pelaksanaan membangunkan tugas pada pelaksana.
///
/// trait ini boleh digunakan untuk membuat [`Waker`].
/// Seorang pelaksana dapat menentukan pelaksanaan trait ini, dan menggunakannya untuk membangun Waker untuk meneruskan tugas-tugas yang dilaksanakan pada pelaksana tersebut.
///
/// trait ini adalah alternatif yang selamat untuk memori dan ergonomik untuk membina [`RawWaker`].
/// Ini menyokong reka bentuk pelaksana umum di mana data yang digunakan untuk membangunkan tugas disimpan dalam [`Arc`].
/// Beberapa pelaksana (terutama yang untuk sistem tertanam) tidak dapat menggunakan API ini, sebab itulah [`RawWaker`] wujud sebagai alternatif untuk sistem tersebut.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Fungsi `block_on` asas yang mengambil future dan menjalankannya hingga selesai pada utas semasa.
///
/// **Note:** Contoh ini menukar kebenaran untuk kesederhanaan.
/// Untuk mengelakkan kebuntuan, pelaksanaan kelas pengeluaran juga perlu menangani panggilan pertengahan ke `thread::unpark` dan juga pemanggilan bersarang.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Pembangun yang membangunkan benang semasa ketika dipanggil.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Jalankan future hingga selesai pada utas semasa.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Sematkan future supaya boleh diundi.
///     let mut fut = Box::pin(fut);
///
///     // Buat konteks baru untuk diteruskan ke future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Jalankan future hingga selesai.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Bangunlah tugas ini.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Jalankan tugas ini tanpa memakan waker.
    ///
    /// Sekiranya seorang pelaksana menyokong cara bangun yang lebih murah tanpa memakan alat pembangun, ia harus mengatasi kaedah ini.
    /// Secara lalai, ia mengklon [`Arc`] dan memanggil [`wake`] pada klon.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // KESELAMATAN: Ini selamat kerana raw_waker selamat dibina
        // seorang RawWaker dari Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Fungsi peribadi ini untuk membina RawWaker digunakan, bukan
// memasukkan ini ke dalam implan `From<Arc<W>> for RawWaker`, untuk memastikan keselamatan `From<Arc<W>> for Waker` tidak bergantung pada penghantaran trait yang betul, sebaliknya kedua-dua implan memanggil fungsi ini secara langsung dan eksplisit.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Tingkatkan kiraan rujukan arka untuk mengklonnya.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Bangun dengan nilai, memindahkan Arc ke fungsi Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Bangun dengan menggunakan rujukan, bungkus waker tersebut secara manual agar tidak menjatuhkannya
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Turunkan jumlah rujukan Arc pada penurunan
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}