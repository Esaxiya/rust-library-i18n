//! Peruntukkan Prelude
//!
//! Tujuan modul ini adalah untuk mengurangkan import item yang biasa digunakan dari `alloc` crate dengan menambahkan import glob ke bahagian atas modul:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;