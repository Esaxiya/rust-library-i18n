use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Pengkhususan trait digunakan untuk Vec::from_iter
///
/// ## Graf perwakilan:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Kes biasa ialah memasukkan vector ke fungsi yang segera dikumpulkan semula menjadi vector.
        // Kita boleh membuat pintasan ini sekiranya IntoIter sama sekali tidak maju.
        // Bila sudah maju, kita juga dapat menggunakan kembali memori dan memindahkan data ke depan.
        // Tetapi kami hanya melakukannya apabila Vec yang dihasilkan tidak akan mempunyai kapasitas yang lebih tidak terpakai daripada membuatnya melalui pelaksanaan FromIterator generik.
        //
        // Batasan itu tidak begitu diperlukan kerana tingkah laku peruntukan Vec sengaja tidak ditentukan.
        // Tetapi ia adalah pilihan yang konservatif.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // mesti mewakilkan ke spec_extend() kerana extend() sendiri mewakilkan ke spec_from untuk Vec kosong
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ini menggunakan `iterator.as_slice().to_vec()` kerana spec_extend mesti mengambil lebih banyak langkah untuk menentukan kapasiti akhir + panjang dan dengan demikian melakukan lebih banyak kerja.
// `to_vec()` secara langsung memperuntukkan jumlah yang betul dan mengisinya dengan tepat.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): dengan cfg(test) kaedah `[T]::to_vec` yang wujud, yang diperlukan untuk definisi kaedah ini, tidak tersedia.
    // Sebaliknya gunakan fungsi `slice::to_vec` yang hanya tersedia dengan cfg(test) NB lihat modul slice::hack di slice.rs untuk maklumat lebih lanjut
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}