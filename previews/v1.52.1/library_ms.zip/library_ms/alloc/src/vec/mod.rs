//! Jenis susunan yang boleh ditanam bersebelahan dengan kandungan yang diperuntukkan timbunan, ditulis `Vec<T>`
//!
//! Vectors mempunyai pengindeksan `O(1)`, tolakan `O(1)` dilunaskan (hingga akhir) dan pop `O(1)` (dari akhir).
//!
//!
//! Vectors memastikan mereka tidak akan memperuntukkan lebih daripada `isize::MAX` bait.
//!
//! # Examples
//!
//! Anda boleh membuat [`Vec`] dengan [`Vec::new`] secara eksplisit:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... atau dengan menggunakan makro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // sepuluh sifar
//! ```
//!
//! Anda boleh nilai [`push`] ke hujung vector (yang akan mengembangkan vector mengikut keperluan):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Nilai muncul berfungsi dengan cara yang sama:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors juga menyokong pengindeksan (melalui [`Index`] dan [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Jenis susunan yang boleh ditanam yang berdekatan, ditulis sebagai `Vec<T>` dan diucapkan 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Makro [`vec!`] disediakan untuk membuat permulaan lebih mudah:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Ia juga dapat menginisialisasi setiap elemen `Vec<T>` dengan nilai tertentu.
/// Ini mungkin lebih cekap daripada melakukan peruntukan dan inisialisasi dalam langkah terpisah, terutamanya ketika memulakan vector sifar:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Yang berikut adalah setara, tetapi berpotensi lebih perlahan:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Untuk maklumat lebih lanjut, lihat [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Gunakan `Vec<T>` sebagai timbunan yang cekap:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Cetakan 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Jenis `Vec` memungkinkan untuk mengakses nilai mengikut indeks, kerana menerapkan [`Index`] trait.Contohnya akan lebih jelas:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // ia akan memaparkan '2'
/// ```
///
/// Tetapi berhati-hatilah: jika anda cuba mengakses indeks yang tidak ada di `Vec`, perisian anda akan panic!Anda tidak boleh melakukan ini:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Gunakan [`get`] dan [`get_mut`] jika anda ingin memeriksa sama ada indeks berada di `Vec`.
///
/// # Slicing
///
/// `Vec` boleh berubah.Sebaliknya, potongan adalah objek yang hanya boleh dibaca.
/// Untuk mendapatkan [slice][prim@slice], gunakan [`&`].Contoh:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... dan itu sahaja!
/// // anda juga boleh melakukannya seperti ini:
/// let u: &[usize] = &v;
/// // atau seperti ini:
/// let u: &[_] = &v;
/// ```
///
/// Di Rust, adalah lebih biasa untuk memasukkan slice sebagai argumen daripada vectors ketika anda hanya mahu memberikan akses baca.Perkara yang sama berlaku untuk [`String`] dan [`&str`].
///
/// # Kapasiti dan peruntukan semula
///
/// Kapasiti vector adalah jumlah ruang yang diperuntukkan untuk sebarang elemen future yang akan ditambahkan ke vector.Ini tidak boleh dikelirukan dengan *panjang* vector, yang menentukan bilangan elemen sebenar dalam vector.
/// Sekiranya panjang vector melebihi kapasitinya, kapasitinya akan meningkat secara automatik, tetapi elemennya harus dialokasikan semula.
///
/// Sebagai contoh, vector dengan kapasiti 10 dan panjang 0 akan menjadi vector kosong dengan ruang untuk 10 elemen lagi.Mendorong 10 atau lebih sedikit elemen ke vector tidak akan mengubah kapasitinya atau menyebabkan peruntukan semula berlaku.
/// Walau bagaimanapun, jika panjang vector dinaikkan menjadi 11, ia mesti diagihkan semula, yang boleh menjadi perlahan.Atas sebab ini, disarankan untuk menggunakan [`Vec::with_capacity`] seboleh-bolehnya untuk menentukan seberapa besar vector yang diharapkan dapat diperoleh.
///
/// # Guarantees
///
/// Kerana sifatnya yang sangat mendasar, `Vec` memberikan banyak jaminan mengenai reka bentuknya.Ini memastikan bahawa ia adalah overhead serendah mungkin dalam kes umum, dan dapat dimanipulasi dengan betul dengan cara primitif dengan kod yang tidak selamat.Perhatikan bahawa jaminan ini merujuk kepada `Vec<T>` yang tidak memenuhi syarat.
/// Sekiranya parameter jenis tambahan ditambahkan (misalnya, untuk menyokong peruntukan khusus), mengesampingkan lalai mereka dapat mengubah tingkah laku.
///
/// Secara asasnya, `Vec` adalah dan selalu akan menjadi (penunjuk, kapasiti, panjang) triplet.Tidak lebih, tidak kurang.Urutan bidang ini sama sekali tidak ditentukan, dan anda harus menggunakan kaedah yang sesuai untuk mengubahnya.
/// Penunjuk tidak akan pernah kosong, jadi jenis ini dioptimumkan untuk penunjuk-nol.
///
/// Walau bagaimanapun, penunjuk mungkin tidak menunjukkan memori yang diperuntukkan.
/// Khususnya, jika anda membina `Vec` dengan kapasiti 0 melalui [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], atau dengan memanggil [`shrink_to_fit`] pada Vec kosong, ia tidak akan memperuntukkan memori.Begitu juga, jika anda menyimpan jenis bersaiz sifar di dalam `Vec`, ia tidak akan memperuntukkan ruang untuknya.
/// *Perhatikan bahawa dalam kes ini `Vec` mungkin tidak melaporkan [`capacity`] 0*.
/// `Vec` akan memperuntukkan jika dan hanya jika [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Secara umum, perincian alokasi `Vec` sangat halus-jika anda berhasrat untuk memperuntukkan memori menggunakan `Vec` dan menggunakannya untuk sesuatu yang lain (sama ada untuk meneruskan kod yang tidak selamat, atau untuk membina koleksi yang disokong memori anda sendiri), pastikan untuk membuang memori ini dengan menggunakan `from_raw_parts` untuk memulihkan `Vec` dan kemudian menjatuhkannya.
///
/// Sekiranya `Vec`*mempunyai* memori yang diperuntukkan, maka memori yang ditunjuknya berada di timbunan (seperti yang ditentukan oleh pengedar Rust dikonfigurasikan untuk digunakan secara lalai), dan penunjuknya menunjuk ke elemen [`len`] yang diinisialisasi, bersebelahan (apa yang anda mahu lihat apakah anda memaksanya ke slice), diikuti oleh [`kapasitas`]`,`[`len`] elemen logik yang tidak dimulakan, bersebelahan.
///
///
/// vector yang mengandungi unsur `'a'` dan `'b'` dengan kapasiti 4 dapat dilihat seperti di bawah.Bahagian atas adalah struktur `Vec`, ia mengandungi penunjuk ke kepala peruntukan dalam timbunan, panjang dan kapasiti.
/// Bahagian bawah adalah peruntukan di timbunan, blok memori bersebelahan.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** mewakili memori yang tidak diinisialisasi, lihat [`MaybeUninit`].
/// - Note: ABI tidak stabil dan `Vec` tidak memberi jaminan mengenai susun atur ingatannya (termasuk susunan bidang).
///
/// `Vec` tidak akan pernah melakukan "small optimization" di mana elemen sebenarnya disimpan di timbunan kerana dua sebab:
///
/// * Lebih sukar bagi kod yang tidak selamat untuk memanipulasi `Vec` dengan betul.Isi `Vec` tidak akan mempunyai alamat yang stabil jika hanya dipindahkan, dan akan lebih sukar untuk menentukan apakah `Vec` benar-benar mengalokasikan memori.
///
/// * Ini akan menghukum kes umum, dengan tambahan branch pada setiap akses.
///
/// `Vec` tidak akan mengecil sendiri secara automatik, walaupun kosong sepenuhnya.Ini memastikan tidak ada peruntukan atau penyingkiran yang tidak diperlukan.Mengosongkan `Vec` dan kemudian mengisinya kembali ke [`len`] yang sama tidak akan memerlukan panggilan ke pengedar.Sekiranya anda ingin membebaskan memori yang tidak digunakan, gunakan [`shrink_to_fit`] atau [`shrink_to`].
///
/// [`push`] dan [`insert`] tidak akan pernah (kembali) memperuntukkan jika kapasiti yang dilaporkan mencukupi.[`push`] dan [`insert`]*akan*(kembali) memperuntukkan jika [`len`]`==`[`kapasiti`].Iaitu, kapasiti yang dilaporkan benar-benar tepat, dan dapat diandalkan.Ia bahkan boleh digunakan untuk membebaskan secara manual memori yang diperuntukkan oleh `Vec` jika dikehendaki.
/// Kaedah penyisipan pukal *mungkin* dialokasikan semula, walaupun tidak diperlukan.
///
/// `Vec` tidak menjamin strategi pertumbuhan tertentu ketika mengalokasikan semula ketika penuh, juga ketika [`reserve`] dipanggil.Strategi semasa adalah asas dan mungkin terbukti wajar menggunakan faktor pertumbuhan yang tidak berterusan.Apa sahaja strategi yang digunakan tentu akan menjamin *O*(1) dilunaskan [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, dan [`Vec::with_capacity(n)`][`Vec::with_capacity`], semuanya akan menghasilkan `Vec` dengan kapasiti yang diminta.
/// Jika [`len`]`==`[`kapasitas`], (seperti halnya makro [`vec!`]), maka `Vec<T>` dapat ditukar ke dan dari [`Box<[T]>`][owned slice] tanpa mengalokasikan semula atau memindahkan elemen.
///
/// `Vec` tidak akan secara khusus menimpa data yang dikeluarkan daripadanya, tetapi juga tidak akan menyimpannya secara khusus.Ingatannya yang belum dimulakan adalah ruang calar yang mungkin digunakan sesuka hati.Secara amnya, ia akan melakukan apa sahaja yang paling berkesan atau senang dilaksanakan.Jangan bergantung pada data yang dikeluarkan untuk dihapus untuk tujuan keselamatan.
/// Walaupun anda menjatuhkan `Vec`, penyangga itu hanya boleh digunakan semula oleh `Vec` yang lain.
/// Walaupun anda mengimbas memori `Vec` terlebih dahulu, itu mungkin tidak berlaku kerana pengoptimum tidak menganggap ini sebagai kesan sampingan yang mesti dijaga.
/// Terdapat satu kes yang tidak akan kami pecahkan: bagaimanapun, menggunakan kod `unsafe` untuk menuliskan kelebihan kapasiti, dan kemudian menambah panjang yang sesuai, selalu berlaku.
///
/// Pada masa ini, `Vec` tidak menjamin urutan penurunan elemen.
/// Urutan telah berubah pada masa lalu dan mungkin akan berubah lagi.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Kaedah melekat
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Membina `Vec<T>` kosong yang baru.
    ///
    /// vector tidak akan diperuntukkan sehingga elemen didorong ke atasnya.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Membina `Vec<T>` kosong baru dengan kapasiti yang ditentukan.
    ///
    /// vector akan dapat menahan unsur `capacity` tepat tanpa meletakkan semula.
    /// Sekiranya `capacity` adalah 0, vector tidak akan memperuntukkan.
    ///
    /// Penting untuk diperhatikan bahawa walaupun vector yang dikembalikan mempunyai *kapasiti* yang ditentukan, vector akan mempunyai panjang *sifar*.
    ///
    /// Untuk penjelasan mengenai perbezaan antara panjang dan kapasiti, lihat *[Kapasiti dan pengagihan semula]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector tidak mengandungi item, walaupun ia mempunyai kapasiti lebih banyak
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ini semua dilakukan tanpa mengalokasikan semula ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... tetapi ini mungkin menjadikan vector dialokasikan semula
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Membuat `Vec<T>` terus dari komponen mentah vector yang lain.
    ///
    /// # Safety
    ///
    /// Ini sangat tidak selamat, kerana bilangan invarian yang tidak diperiksa:
    ///
    /// * `ptr` perlu diperuntukkan sebelum ini melalui [`String`]/` Vec<T>(sekurang-kurangnya, kemungkinan besar tidak betul jika tidak).
    /// * `T` perlu mempunyai ukuran dan keselarasan yang sama dengan yang diperuntukkan `ptr`.
    ///   (`T` yang mempunyai penjajaran yang lebih ketat tidak mencukupi, penjajarannya benar-benar sama untuk memenuhi syarat [`dealloc`] bahawa memori mesti dialokasikan dan dialihkan dengan susun atur yang sama.)
    ///
    /// * `length` perlu kurang daripada atau sama dengan `capacity`.
    /// * `capacity` perlu kapasiti yang ditunjukkan oleh penunjuk.
    ///
    /// Melanggar ini boleh menyebabkan masalah seperti merosakkan struktur data dalaman pengagihan.Contohnya **tidak** selamat untuk membina `Vec<u8>` dari penunjuk ke susunan C `char` dengan panjang `size_t`.
    /// Ia juga tidak selamat untuk membuatnya dari `Vec<u16>` dan panjangnya, kerana peruntukan mengambil berat penjajaran, dan kedua jenis ini mempunyai penjajaran yang berbeza.
    /// Penyangga diperuntukkan dengan penjajaran 2 (untuk `u16`), tetapi setelah mengubahnya menjadi `Vec<u8>`, ia akan dialihkan dengan penjajaran 1.
    ///
    /// Kepemilikan `ptr` secara efektif dipindahkan ke `Vec<T>` yang kemudian dapat menyahpindah, mengalokasikan semula atau mengubah isi memori yang ditunjukkan oleh penunjuk sesuka hati.
    /// Pastikan tiada yang lain menggunakan penunjuk selepas memanggil fungsi ini.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Kemas kini ini apabila vec_into_raw_parts distabilkan.
    ///     // Cegah menjalankan pemusnah `v` sehingga kita dapat mengawal peruntukan sepenuhnya.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Keluarkan pelbagai maklumat penting mengenai `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Menimpa memori dengan 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Masukkan semula semuanya menjadi Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Membina `Vec<T, A>` kosong yang baru.
    ///
    /// vector tidak akan diperuntukkan sehingga elemen didorong ke atasnya.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Membina `Vec<T, A>` kosong baru dengan kapasiti yang ditentukan dengan peruntukan yang disediakan.
    ///
    /// vector akan dapat menahan unsur `capacity` tepat tanpa meletakkan semula.
    /// Sekiranya `capacity` adalah 0, vector tidak akan memperuntukkan.
    ///
    /// Penting untuk diperhatikan bahawa walaupun vector yang dikembalikan mempunyai *kapasiti* yang ditentukan, vector akan mempunyai panjang *sifar*.
    ///
    /// Untuk penjelasan mengenai perbezaan antara panjang dan kapasiti, lihat *[Kapasiti dan pengagihan semula]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector tidak mengandungi item, walaupun ia mempunyai kapasiti lebih banyak
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ini semua dilakukan tanpa mengalokasikan semula ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... tetapi ini mungkin menjadikan vector dialokasikan semula
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Membuat `Vec<T, A>` terus dari komponen mentah vector yang lain.
    ///
    /// # Safety
    ///
    /// Ini sangat tidak selamat, kerana bilangan invarian yang tidak diperiksa:
    ///
    /// * `ptr` perlu diperuntukkan sebelum ini melalui [`String`]/` Vec<T>(sekurang-kurangnya, kemungkinan besar tidak betul jika tidak).
    /// * `T` perlu mempunyai ukuran dan keselarasan yang sama dengan yang diperuntukkan `ptr`.
    ///   (`T` yang mempunyai penjajaran yang lebih ketat tidak mencukupi, penjajarannya benar-benar sama untuk memenuhi syarat [`dealloc`] bahawa memori mesti dialokasikan dan dialihkan dengan susun atur yang sama.)
    ///
    /// * `length` perlu kurang daripada atau sama dengan `capacity`.
    /// * `capacity` perlu kapasiti yang ditunjukkan oleh penunjuk.
    ///
    /// Melanggar ini boleh menyebabkan masalah seperti merosakkan struktur data dalaman pengagihan.Contohnya **tidak** selamat untuk membina `Vec<u8>` dari penunjuk ke susunan C `char` dengan panjang `size_t`.
    /// Ia juga tidak selamat untuk membuatnya dari `Vec<u16>` dan panjangnya, kerana peruntukan mengambil berat penjajaran, dan kedua jenis ini mempunyai penjajaran yang berbeza.
    /// Penyangga diperuntukkan dengan penjajaran 2 (untuk `u16`), tetapi setelah mengubahnya menjadi `Vec<u8>`, ia akan dialihkan dengan penjajaran 1.
    ///
    /// Kepemilikan `ptr` secara efektif dipindahkan ke `Vec<T>` yang kemudian dapat menyahpindah, mengalokasikan semula atau mengubah isi memori yang ditunjukkan oleh penunjuk sesuka hati.
    /// Pastikan tiada yang lain menggunakan penunjuk selepas memanggil fungsi ini.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Kemas kini ini apabila vec_into_raw_parts distabilkan.
    ///     // Cegah menjalankan pemusnah `v` sehingga kita dapat mengawal peruntukan sepenuhnya.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Keluarkan pelbagai maklumat penting mengenai `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Menimpa memori dengan 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Masukkan semula semuanya menjadi Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Menguraikan `Vec<T>` ke dalam komponen mentahnya.
    ///
    /// Mengembalikan penunjuk mentah ke data yang mendasari, panjang vector (dalam elemen), dan kapasiti data yang diperuntukkan (dalam elemen).
    /// Ini adalah argumen yang sama dalam urutan yang sama dengan argumen untuk [`from_raw_parts`].
    ///
    /// Setelah memanggil fungsi ini, pemanggil bertanggungjawab untuk memori yang sebelumnya dikendalikan oleh `Vec`.
    /// Satu-satunya cara untuk melakukan ini adalah dengan menukar pointer mentah, panjang, dan kapasiti kembali menjadi `Vec` dengan fungsi [`from_raw_parts`], yang memungkinkan pemusnah melakukan pembersihan.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Kita sekarang boleh membuat perubahan pada komponen, seperti mentransmisikan penunjuk mentah ke jenis yang serasi.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Menguraikan `Vec<T>` ke dalam komponen mentahnya.
    ///
    /// Mengembalikan penunjuk mentah ke data yang mendasari, panjang vector (dalam elemen), kapasiti data yang diperuntukkan (dalam elemen), dan pengagihan.
    /// Ini adalah argumen yang sama dalam urutan yang sama dengan argumen untuk [`from_raw_parts_in`].
    ///
    /// Setelah memanggil fungsi ini, pemanggil bertanggungjawab untuk memori yang sebelumnya dikendalikan oleh `Vec`.
    /// Satu-satunya cara untuk melakukan ini adalah dengan menukar pointer mentah, panjang, dan kapasiti kembali menjadi `Vec` dengan fungsi [`from_raw_parts_in`], yang memungkinkan pemusnah melakukan pembersihan.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Kita sekarang boleh membuat perubahan pada komponen, seperti mentransmisikan penunjuk mentah ke jenis yang serasi.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Mengembalikan bilangan elemen yang dapat dipegang oleh vector tanpa meletakkan semula.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Menyimpan kapasiti untuk sekurang-kurangnya `additional` lebih banyak elemen yang akan dimasukkan ke dalam `Vec<T>` yang diberikan.
    /// Koleksi mungkin menyimpan lebih banyak ruang untuk mengelakkan penempatan semula yang kerap.
    /// Setelah memanggil `reserve`, kapasiti akan lebih besar daripada atau sama dengan `self.len() + additional`.
    /// Tidak ada apa-apa jika kapasiti sudah mencukupi.
    ///
    /// # Panics
    ///
    /// Panics jika kapasiti baru melebihi `isize::MAX` bait.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Memastikan kapasiti minimum untuk `additional` lebih banyak elemen yang akan dimasukkan ke dalam `Vec<T>` yang diberikan.
    ///
    /// Setelah memanggil `reserve_exact`, kapasiti akan lebih besar daripada atau sama dengan `self.len() + additional`.
    /// Tidak ada apa-apa jika kapasiti sudah mencukupi.
    ///
    /// Perhatikan bahawa pengagihan mungkin memberikan koleksi lebih banyak ruang daripada yang diminta.
    /// Oleh itu, kapasiti tidak dapat diandalkan dengan tepat.
    /// Lebih suka `reserve` jika diharapkan penyisipan future.
    ///
    /// # Panics
    ///
    /// Panics jika kapasiti baru melimpah `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Mencuba untuk menyimpan kapasiti sekurang-kurangnya `additional` lebih banyak elemen yang akan dimasukkan ke dalam `Vec<T>` yang diberikan.
    /// Koleksi mungkin menyimpan lebih banyak ruang untuk mengelakkan penempatan semula yang kerap.
    /// Setelah memanggil `try_reserve`, kapasiti akan lebih besar daripada atau sama dengan `self.len() + additional`.
    /// Tidak ada apa-apa jika kapasiti sudah mencukupi.
    ///
    /// # Errors
    ///
    /// Sekiranya kapasiti meluap, atau pengagihan melaporkan kegagalan, maka ralat dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pra-simpanan memori, keluar jika kita tidak dapat
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Sekarang kita tahu ini tidak dapat dilakukan OOM di tengah-tengah kerja kita yang kompleks
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sangat rumit
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Mencuba untuk menyimpan kapasiti minimum untuk elemen `additional` yang tepat untuk dimasukkan ke dalam `Vec<T>` yang diberikan.
    /// Setelah memanggil `try_reserve_exact`, kapasiti akan lebih besar daripada atau sama dengan `self.len() + additional` jika mengembalikan `Ok(())`.
    ///
    /// Tidak ada apa-apa jika kapasiti sudah mencukupi.
    ///
    /// Perhatikan bahawa pengagihan mungkin memberikan koleksi lebih banyak ruang daripada yang diminta.
    /// Oleh itu, kapasiti tidak dapat diandalkan dengan tepat.
    /// Lebih suka `reserve` jika diharapkan penyisipan future.
    ///
    /// # Errors
    ///
    /// Sekiranya kapasiti meluap, atau pengagihan melaporkan kegagalan, maka ralat dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pra-simpanan memori, keluar jika kita tidak dapat
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Sekarang kita tahu ini tidak dapat dilakukan OOM di tengah-tengah kerja kita yang kompleks
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sangat rumit
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Mengecilkan kapasiti vector sebanyak mungkin.
    ///
    /// Ia akan turun sedekat mungkin dengan panjang tetapi pengagihan masih boleh memberitahu vector bahawa terdapat ruang untuk beberapa elemen lagi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Kapasiti tidak pernah kurang dari panjangnya, dan tidak ada hubungannya ketika mereka sama, jadi kita dapat menghindari sarung panic di `RawVec::shrink_to_fit` dengan hanya memanggilnya dengan kapasitas yang lebih besar.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Mengecilkan kapasiti vector dengan had bawah.
    ///
    /// Kapasiti akan kekal sekurang-kurangnya sebesar kedua dan nilai yang dibekalkan.
    ///
    ///
    /// Sekiranya kapasiti semasa kurang dari had bawah, ini adalah op-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Menukar vector menjadi [`Box<[T]>`][owned slice].
    ///
    /// Perhatikan bahawa ini akan menurunkan kelebihan kapasiti.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Sebilangan kapasiti berlebihan dikeluarkan:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Memendekkan vector, mengekalkan elemen `len` pertama dan menurunkan selebihnya.
    ///
    /// Sekiranya `len` lebih besar daripada panjang semasa vector, ini tidak akan memberi kesan.
    ///
    /// Kaedah [`drain`] dapat meniru `truncate`, tetapi menyebabkan lebihan elemen dikembalikan dan bukannya dijatuhkan.
    ///
    ///
    /// Perhatikan bahawa kaedah ini tidak mempengaruhi kapasiti vector yang diperuntukkan.
    ///
    /// # Examples
    ///
    /// Memotong lima elemen vector kepada dua elemen:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Tidak ada pemotongan berlaku apabila `len` lebih besar daripada panjang semasa vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Memotong ketika `len == 0` sama dengan memanggil kaedah [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Ini selamat kerana:
        //
        // * potongan yang dihantar ke `drop_in_place` adalah sah;kes `len > self.len` mengelakkan daripada membuat slice yang tidak sah, dan
        // * `len` dari vector dikecilkan sebelum memanggil `drop_in_place`, sehingga tidak ada nilai yang akan dijatuhkan dua kali sekiranya `drop_in_place` ke panic sekali (jika panics dua kali, program berhenti).
        //
        //
        //
        unsafe {
            // Note: Dengan sengaja ini adalah `>` dan bukan `>=`.
            //       Menukarnya ke `>=` mempunyai implikasi prestasi negatif dalam beberapa kes.
            //       Lihat #78884 untuk lebih banyak lagi.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Ekstrak kepingan yang mengandungi keseluruhan vector.
    ///
    /// Setaraf dengan `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Mengeluarkan kepingan yang boleh berubah dari keseluruhan vector.
    ///
    /// Setaraf dengan `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Mengembalikan penunjuk mentah ke penyangga vector.
    ///
    /// Pemanggil mesti memastikan bahawa vector hidup daripada penunjuk fungsi ini kembali, jika tidak, ia akhirnya akan menunjuk sampah.
    /// Mengubah vector boleh menyebabkan penyangganya dialokasikan semula, yang juga akan menjadikan petunjuk tidak sah.
    ///
    /// Pemanggil juga mesti memastikan bahawa memori yang ditunjukkan oleh penunjuk (non-transitively) tidak akan pernah ditulis (kecuali di dalam `UnsafeCell`) menggunakan penunjuk ini atau mana-mana penunjuk yang berasal darinya.
    /// Sekiranya anda perlu mengubah isi kandungan potongan, gunakan [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Kami membayang-bayangkan kaedah potongan dengan nama yang sama untuk mengelakkan `deref`, yang membuat rujukan perantaraan.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Mengembalikan penunjuk yang tidak dapat diubah yang tidak selamat ke penyangga vector.
    ///
    /// Pemanggil mesti memastikan bahawa vector hidup daripada penunjuk fungsi ini kembali, jika tidak, ia akhirnya akan menunjuk sampah.
    ///
    /// Mengubah vector boleh menyebabkan penyangganya dialokasikan semula, yang juga akan menjadikan petunjuk tidak sah.
    ///
    /// # Examples
    ///
    /// ```
    /// // Peruntukkan vector cukup besar untuk 4 elemen.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Permulaan elemen melalui penulisan mentah mentah, kemudian tetapkan panjang.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Kami membayang-bayangkan kaedah potongan dengan nama yang sama untuk mengelakkan `deref_mut`, yang membuat rujukan perantaraan.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Mengembalikan rujukan ke alokasi pendasar.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Memaksa panjang vector hingga `new_len`.
    ///
    /// Ini adalah operasi peringkat rendah yang tidak mengekalkan invarian normal jenis ini.
    /// Biasanya mengubah panjang vector dilakukan dengan menggunakan salah satu operasi yang selamat, seperti [`truncate`], [`resize`], [`extend`], atau [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` mestilah kurang daripada atau sama dengan [`capacity()`].
    /// - Elemen pada `old_len..new_len` mesti diinisialisasi.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Kaedah ini boleh berguna untuk situasi di mana vector berfungsi sebagai penyangga untuk kod lain, terutamanya melalui FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Ini hanyalah kerangka minimum untuk contoh dokumen;
    /// # // jangan gunakan ini sebagai titik permulaan perpustakaan sebenar.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Menurut dokumen kaedah FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // KESELAMATAN: Apabila `deflateGetDictionary` mengembalikan `Z_OK`, ia menyatakan bahawa:
    ///     // 1. `dict_length` elemen dimulakan.
    ///     // 2.
    ///     // `dict_length` <=kapasiti (32_768) yang menjadikan `set_len` selamat dipanggil.
    ///     unsafe {
    ///         // Buat panggilan FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... dan kemas kini panjangnya ke apa yang dimulakan.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Walaupun contoh berikut adalah baik, terdapat kebocoran memori kerana vectors dalaman tidak dibebaskan sebelum panggilan `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` kosong sehingga tidak ada unsur yang perlu diinisialisasi.
    /// // 2. `0 <= capacity` sentiasa memegang apa sahaja `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Biasanya, di sini, seseorang akan menggunakan [`clear`] sebagai ganti untuk menjatuhkan kandungan dengan betul dan dengan itu tidak membocorkan memori.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Mengeluarkan elemen dari vector dan mengembalikannya.
    ///
    /// Elemen yang dikeluarkan digantikan oleh elemen terakhir vector.
    ///
    /// Ini tidak mengekalkan pesanan, tetapi O(1).
    ///
    /// # Panics
    ///
    /// Panics jika `index` berada di luar batas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Kami mengganti [indeks] diri dengan elemen terakhir.
            // Perhatikan bahawa jika pemeriksaan had di atas berjaya, pasti ada elemen terakhir (yang boleh menjadi indeks sendiri).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Memasukkan elemen pada kedudukan `index` dalam vector, mengalihkan semua elemen selepasnya ke kanan.
    ///
    ///
    /// # Panics
    ///
    /// Panics jika `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // ruang untuk elemen baru
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // sempurna untuk meletakkan nilai baru
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Alihkan segalanya untuk memberi ruang.
                // (Menduplikasi elemen `index` ke dua tempat berturut-turut.)
                ptr::copy(p, p.offset(1), len - index);
                // Tuliskannya, ganti salinan pertama elemen `index`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Mengeluarkan dan mengembalikan elemen pada kedudukan `index` di dalam vector, mengalihkan semua elemen setelahnya ke kiri.
    ///
    ///
    /// # Panics
    ///
    /// Panics jika `index` berada di luar batas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // tempat yang kita ambil.
                let ptr = self.as_mut_ptr().add(index);
                // salin, salinan nilai yang tidak selamat pada timbunan dan pada vector pada masa yang sama.
                //
                ret = ptr::read(ptr);

                // Alihkan segalanya ke bawah untuk mengisi tempat itu.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Hanya mengekalkan unsur-unsur yang ditentukan oleh predikat.
    ///
    /// Dengan kata lain, keluarkan semua elemen `e` sehingga `f(&e)` mengembalikan `false`.
    /// Kaedah ini beroperasi di tempat, melawat setiap elemen tepat sekali dalam urutan asal, dan mengekalkan susunan elemen yang dipertahankan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Kerana elemen dikunjungi tepat sekali dalam urutan asal, keadaan luaran dapat digunakan untuk menentukan elemen mana yang harus disimpan.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Elakkan penurunan berganda jika pelindung jatuh tidak dijalankan, kerana kita mungkin membuat beberapa lubang selama prosesnya.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-len diproses-> |^-di sebelah untuk diperiksa
        //                  | <-dihapus cnt-> |
        //      | <-original_len-> |Disimpan: Unsur-unsur yang predikat kembali benar.
        //
        // Lubang: Slot elemen yang dipindahkan atau dijatuhkan.
        // Tidak dicentang: Elemen sah yang tidak dicentang.
        //
        // Drop guard ini akan dipanggil semasa predikat atau `drop` elemen panik.
        // Ia mengalihkan elemen yang tidak diperiksa untuk menutup lubang dan `set_len` ke panjang yang betul.
        // Sekiranya predikat dan `drop` tidak pernah panik, ia akan dioptimumkan.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // KESELAMATAN: Mengikuti item yang tidak dicentang mestilah sah kerana kami tidak pernah menyentuhnya.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // KESELAMATAN: Setelah mengisi lubang, semua item dalam memori bersambung.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // KESELAMATAN: Elemen yang tidak dicentang mestilah sah.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Maju lebih awal untuk mengelakkan penurunan berganda jika `drop_in_place` panik.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // KESELAMATAN: Kami tidak pernah menyentuh elemen ini lagi setelah dijatuhkan.
                unsafe { ptr::drop_in_place(cur) };
                // Kami sudah memajukan kaunter.
                continue;
            }
            if g.deleted_cnt > 0 {
                // KESELAMATAN: `deleted_cnt`> 0, jadi slot lubang tidak boleh bertindih dengan elemen semasa.
                // Kami menggunakan salinan untuk bergerak, dan tidak pernah menyentuh elemen ini lagi.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Semua item diproses.Ini dapat dioptimumkan ke `set_len` oleh LLVM.
        drop(g);
    }

    /// Membuang semua kecuali unsur pertama berturut-turut dalam vector yang berpegang pada kekunci yang sama.
    ///
    ///
    /// Sekiranya vector disusun, ini akan membuang semua pendua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Membuang semua kecuali unsur pertama berturut-turut dalam vector yang memuaskan hubungan persamaan yang diberikan.
    ///
    /// Fungsi `same_bucket` diteruskan merujuk kepada dua elemen dari vector dan mesti menentukan sama ada unsur tersebut sama.
    /// Unsur-unsur diteruskan dalam urutan yang berlawanan dari susunannya dalam irisan, jadi jika `same_bucket(a, b)` mengembalikan `true`, `a` dikeluarkan.
    ///
    ///
    /// Sekiranya vector disusun, ini akan membuang semua pendua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Menambah elemen di bahagian belakang koleksi.
    ///
    /// # Panics
    ///
    /// Panics jika kapasiti baru melebihi `isize::MAX` bait.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Ini akan panic atau dibatalkan sekiranya kita memperuntukkan> isize::MAX bait atau jika kenaikan panjang akan melimpah untuk jenis bersaiz sifar.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Mengeluarkan elemen terakhir dari vector dan mengembalikannya, atau [`None`] jika kosong.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Memindahkan semua elemen `other` ke `Self`, membiarkan `other` kosong.
    ///
    /// # Panics
    ///
    /// Panics jika bilangan elemen dalam vector melimpah `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Menambah elemen ke `Self` dari penyangga lain.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Membuat iterator pengeringan yang membuang julat yang ditentukan di vector dan menghasilkan item yang dikeluarkan.
    ///
    /// Apabila iterator **dijatuhkan**, semua elemen dalam julat dikeluarkan dari vector, walaupun iterator tidak habis digunakan sepenuhnya.
    /// Sekiranya iterator **tidak** dijatuhkan (dengan [`mem::forget`] misalnya), tidak ditentukan berapa banyak elemen yang dikeluarkan.
    ///
    /// # Panics
    ///
    /// Panics jika titik permulaan lebih besar daripada titik akhir atau jika titik akhir lebih besar daripada panjang vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Julat penuh membersihkan vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Keselamatan ingatan
        //
        // Apabila Drain pertama kali dibuat, ia memendekkan panjang sumber vector untuk memastikan tidak ada elemen yang tidak diinisiasi atau dipindahkan sama sekali jika pemusnah Drain tidak dapat dijalankan.
        //
        //
        // Drain akan ptr::read mengeluarkan nilai untuk dikeluarkan.
        // Setelah selesai, baki vec yang tersisa disalin kembali untuk menutup lubang, dan panjang vector dikembalikan ke panjang yang baru.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // tetapkan panjang self.vec untuk memulakan, agar selamat sekiranya Drain bocor
            self.set_len(start);
            // Gunakan pinjaman di IterMut untuk menunjukkan kelakuan meminjam keseluruhan iterator Drain (seperti &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Membersihkan vector, membuang semua nilai.
    ///
    /// Perhatikan bahawa kaedah ini tidak mempengaruhi kapasiti vector yang diperuntukkan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Mengembalikan bilangan elemen dalam vector, juga disebut sebagai 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Mengembalikan `true` jika vector tidak mengandungi unsur.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Membahagi koleksi menjadi dua pada indeks yang diberikan.
    ///
    /// Mengembalikan vector yang baru diperuntukkan yang mengandungi unsur-unsur dalam julat `[at, len)`.
    /// Selepas panggilan, vector yang asli akan dibiarkan mengandungi unsur `[0, at)` dengan kapasiti sebelumnya tidak berubah.
    ///
    ///
    /// # Panics
    ///
    /// Panics jika `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // vector baru boleh mengambil alih penyangga asal dan mengelakkan salinannya
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` dan salin item ke `other` dengan tidak selamat.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Ubah saiz `Vec` di tempat sehingga `len` sama dengan `new_len`.
    ///
    /// Sekiranya `new_len` lebih besar daripada `len`, `Vec` dilanjutkan dengan perbezaannya, dengan setiap slot tambahan diisi dengan hasil memanggil penutupan `f`.
    ///
    /// Nilai kembali dari `f` akan berakhir pada `Vec` mengikut urutan yang dihasilkan.
    ///
    /// Sekiranya `new_len` kurang dari `len`, `Vec` hanya akan dipotong.
    ///
    /// Kaedah ini menggunakan penutup untuk membuat nilai baru pada setiap tolakan.Sekiranya anda lebih suka [`Clone`] nilai tertentu, gunakan [`Vec::resize`].
    /// Sekiranya anda ingin menggunakan [`Default`] trait untuk menghasilkan nilai, anda boleh meneruskan [`Default::default`] sebagai argumen kedua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Mengkonsumsi dan membocorkan `Vec`, mengembalikan rujukan yang boleh berubah kepada kandungannya, `&'a mut [T]`.
    /// Perhatikan bahawa jenis `T` mesti melebihi `'a` sepanjang hayat yang dipilih.
    /// Sekiranya jenis ini hanya mempunyai rujukan statik, atau tidak sama sekali, maka ini boleh dipilih menjadi `'static`.
    ///
    /// Fungsi ini serupa dengan fungsi [`leak`][Box::leak] pada [`Box`] kecuali bahawa tidak ada cara untuk memulihkan memori yang bocor.
    ///
    ///
    /// Fungsi ini terutama berguna untuk data yang tinggal sepanjang hayat program.
    /// Melepaskan rujukan yang dikembalikan akan menyebabkan kebocoran memori.
    ///
    /// # Examples
    ///
    /// Penggunaan mudah:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Mengembalikan kapasiti ganti vector yang tersisa sebagai kepingan `MaybeUninit<T>`.
    ///
    /// Potongan yang dikembalikan boleh digunakan untuk mengisi vector dengan data (mis
    /// dengan membaca dari fail) sebelum menandakan data sebagai permulaan menggunakan kaedah [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Peruntukkan vector cukup besar untuk 10 elemen.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Isi 3 elemen pertama.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Tandakan 3 elemen pertama vector sebagai permulaan.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Kaedah ini tidak dilaksanakan dari segi `split_at_spare_mut`, untuk mengelakkan pembatalan penunjuk ke penyangga.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Mengembalikan kandungan vector sebagai potongan `T`, bersama dengan baki kapasiti ganti vector sebagai kepingan `MaybeUninit<T>`.
    ///
    /// Potongan kapasiti ganti yang dikembalikan boleh digunakan untuk mengisi vector dengan data (misalnya dengan membaca dari fail) sebelum menandakan data sebagai permulaan menggunakan kaedah [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Perhatikan bahawa ini adalah API peringkat rendah, yang harus digunakan dengan hati-hati untuk tujuan pengoptimuman.
    /// Sekiranya anda perlu menambahkan data ke `Vec`, anda dapat menggunakan [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] atau [`resize_with`], bergantung pada keperluan tepat anda.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Cadangan ruang tambahan yang cukup besar untuk 10 elemen.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Isi 4 elemen seterusnya.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Tandakan 4 elemen vector sebagai permulaan.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len tidak diendahkan dan jadi tidak pernah berubah
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Keselamatan: menukar dikembalikan .2 (penggunaan &mut) dianggap sama dengan memanggil `.set_len(_)`.
    ///
    /// Kaedah ini digunakan untuk memiliki akses unik ke semua bahagian vec sekaligus di `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` dijamin sah untuk elemen `len`
        // - `spare_ptr` menunjukkan satu elemen melewati penyangga, sehingga tidak bertindih dengan `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Ubah saiz `Vec` di tempat sehingga `len` sama dengan `new_len`.
    ///
    /// Sekiranya `new_len` lebih besar daripada `len`, `Vec` dilanjutkan dengan perbezaannya, dengan setiap slot tambahan diisi dengan `value`.
    ///
    /// Sekiranya `new_len` kurang dari `len`, `Vec` hanya akan dipotong.
    ///
    /// Kaedah ini memerlukan `T` untuk menerapkan [`Clone`], agar dapat mengkloning nilai lulus.
    /// Sekiranya anda memerlukan lebih banyak fleksibiliti (atau mahu bergantung pada [`Default`] dan bukannya [`Clone`]), gunakan [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klon dan tambahkan semua elemen dalam kepingan ke `Vec`.
    ///
    /// Mengulangi kepingan `other`, mengklon setiap elemen, dan kemudian menambahkannya ke `Vec` ini.
    /// `other` vector dilalui mengikut urutan.
    ///
    /// Perhatikan bahawa fungsi ini sama dengan [`extend`] kecuali yang khusus untuk bekerja dengan irisan sebagai gantinya.
    ///
    /// Sekiranya dan ketika Rust mendapat pengkhususan fungsi ini kemungkinan akan usang (tetapi masih ada).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Menyalin elemen dari jarak `src` hingga akhir vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` menjamin bahawa julat yang diberikan adalah sah untuk mengindeks diri
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Kod ini menyamaratakan `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Panjangkan nilai vector dengan `n`, menggunakan penjana yang diberikan.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Gunakan SetLenOnDrop untuk mengatasi bug di mana penyusun mungkin tidak menyedari kedai melalui `ptr` hingga self.set_len() tidak alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Tulis semua elemen kecuali yang terakhir
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Tingkatkan panjang dalam setiap langkah sekiranya next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Kita boleh menulis elemen terakhir secara langsung tanpa pengklonan tanpa perlu
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len ditetapkan oleh pengawal skop
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Mengeluarkan elemen berulang berturut-turut dalam vector mengikut pelaksanaan [`PartialEq`] trait.
    ///
    ///
    /// Sekiranya vector disusun, ini akan membuang semua pendua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Kaedah dan fungsi dalaman
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` perlu ada indeks yang sah
    /// - `self.capacity() - self.len()` mesti `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len dinaikkan hanya setelah memulakan elemen
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - caller guaratees bahawa src adalah indeks yang sah
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Elemen baru dimulakan dengan `MaybeUninit::write`, jadi lebih baik untuk menambah len
            // - len ditingkatkan selepas setiap elemen untuk mengelakkan kebocoran (lihat isu #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - pemanggil memberi jaminan bahawa `src` adalah indeks yang sah
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Kedua-dua pointer dibuat dari rujukan slice yang unik (`&mut [_]`) sehingga ia sah dan tidak bertindih.
            //
            // - Elemen-elemennya ialah: Salin jadi tidak mustahil untuk menyalinnya, tanpa melakukan apa-apa dengan nilai asalnya
            // - `count` sama dengan len `source`, jadi sumbernya sah untuk bacaan `count`
            // - `.reserve(count)` menjamin bahawa `spare.len() >= count` jadi cadangan sah untuk penulisan `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Unsur-unsur itu baru dimulakan oleh `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Pelaksanaan trait biasa untuk Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): dengan cfg(test) kaedah `[T]::to_vec` yang wujud, yang diperlukan untuk definisi kaedah ini, tidak tersedia.
    // Sebaliknya gunakan fungsi `slice::to_vec` yang hanya tersedia dengan cfg(test) NB lihat modul slice::hack di slice.rs untuk maklumat lebih lanjut
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // jatuhkan apa sahaja yang tidak akan ditimpa
        self.truncate(other.len());

        // self.len <= other.len kerana pemotongan di atas, jadi potongan di sini selalu tidak terhad.
        //
        let (init, tail) = other.split_at(self.len());

        // gunakan semula nilai yang terkandung allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Membuat iterator yang memakan masa, iaitu yang memindahkan setiap nilai keluar dari vector (dari awal hingga akhir).
    /// vector tidak dapat digunakan setelah memanggilnya.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s mempunyai jenis String, bukan &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // kaedah daun di mana pelbagai pelaksanaan SpecFrom/SpecExtend mendelegasikan apabila mereka tidak mempunyai pengoptimuman lebih lanjut untuk diterapkan
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Ini adalah perkara untuk iterator umum.
        //
        // Fungsi ini harus setara dengan moral:
        //
        //      untuk item dalam iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB tidak dapat meluap kerana kita harus memperuntukkan ruang alamat
                self.set_len(len + 1);
            }
        }
    }

    /// Membuat iterator splicing yang menggantikan julat yang ditentukan di vector dengan iterator `replace_with` yang diberikan dan menghasilkan item yang dikeluarkan.
    ///
    /// `replace_with` tidak perlu sama panjangnya dengan `range`.
    ///
    /// `range` dikeluarkan walaupun iterator tidak habis digunakan sehingga akhir.
    ///
    /// Tidak ditentukan berapa banyak elemen yang dikeluarkan dari vector jika nilai `Splice` bocor.
    ///
    /// Iterator input `replace_with` hanya digunakan apabila nilai `Splice` dijatuhkan.
    ///
    /// Ini optimum jika:
    ///
    /// * Ekor (elemen dalam vector selepas `range`) kosong,
    /// * atau `replace_with` menghasilkan elemen yang lebih sedikit atau sama daripada panjang `range '
    /// * atau batas bawah `size_hint()` nya adalah tepat.
    ///
    /// Jika tidak, vector sementara diperuntukkan dan ekornya dipindahkan dua kali.
    ///
    /// # Panics
    ///
    /// Panics jika titik permulaan lebih besar daripada titik akhir atau jika titik akhir lebih besar daripada panjang vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Membuat iterator yang menggunakan penutupan untuk menentukan sama ada elemen harus dikeluarkan.
    ///
    /// Sekiranya penutupan kembali benar, elemen tersebut dikeluarkan dan dihasilkan.
    /// Sekiranya penutupan kembali salah, elemen akan tetap berada di vector dan tidak akan dihasilkan oleh iterator.
    ///
    /// Menggunakan kaedah ini sama dengan kod berikut:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // kod anda di sini
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Tetapi `drain_filter` lebih senang digunakan.
    /// `drain_filter` juga lebih cekap, kerana dapat mengubah elemen susunan secara pukal.
    ///
    /// Perhatikan bahawa `drain_filter` juga memungkinkan anda mengubah setiap elemen dalam penutupan penapis, tidak kira sama ada anda memilih untuk menyimpan atau menghapusnya.
    ///
    ///
    /// # Examples
    ///
    /// Memisahkan array menjadi evens dan odds, menggunakan semula peruntukan asal:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Jaga agar kita tidak bocor (penguat kebocoran)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Panjangkan pelaksanaan yang menyalin elemen daripada rujukan sebelum mendorongnya ke Vec.
///
/// Pelaksanaan ini dikhususkan untuk iterator slice, di mana ia menggunakan [`copy_from_slice`] untuk menambahkan keseluruhan slice sekaligus.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Melaksanakan perbandingan vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Melaksanakan pesanan vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // gunakan drop untuk [T] gunakan potongan mentah untuk merujuk kepada elemen vector sebagai jenis yang paling lemah;
            //
            // dapat mengelakkan persoalan kesahihan dalam kes-kes tertentu
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec menangani penyahpindahan
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Membuat `Vec<T>` kosong.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: ujian menarik dalam libstd, yang menyebabkan kesilapan di sini
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: ujian menarik dalam libstd, yang menyebabkan kesilapan di sini
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Mendapat keseluruhan kandungan `Vec<T>` sebagai array, jika ukurannya sama persis dengan array yang diminta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Sekiranya panjangnya tidak sepadan, inputnya kembali dalam `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Sekiranya anda baik dengan hanya mendapatkan awalan `Vec<T>`, anda boleh menghubungi [`.truncate(N)`](Vec::truncate) terlebih dahulu.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // KESELAMATAN: `.set_len(0)` sentiasa baik.
        unsafe { vec.set_len(0) };

        // KESELAMATAN: Penunjuk `Vec` selalu diselaraskan dengan betul, dan
        // penjajaran yang diperlukan oleh array sama dengan item.
        // Kami telah memeriksa lebih awal bahawa kami mempunyai barang yang mencukupi.
        // Item tidak akan turun dua kali kerana `set_len` memberitahu `Vec` untuk tidak menjatuhkannya juga.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}