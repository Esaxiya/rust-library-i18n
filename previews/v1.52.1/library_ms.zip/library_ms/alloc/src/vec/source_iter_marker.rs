use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Penanda pengkhususan untuk mengumpulkan saluran paip iterator ke dalam Vec sambil menggunakan semula peruntukan sumber, iaitu
/// melaksanakan saluran paip di tempat.
///
/// Induk SourceIter trait diperlukan untuk fungsi pengkhususan untuk mengakses peruntukan yang akan digunakan semula.
/// Tetapi pengkhususan itu tidak mencukupi.
/// Lihat had tambahan pada impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-SourceIter/InPlaceIterable traits dalaman hanya dilaksanakan oleh rantai Adaptor <Adapter<Adapter<IntoIter>>> (semua dimiliki oleh core/std).
// Batasan tambahan pada pelaksanaan penyesuai (melebihi `impl<I: Trait> Trait for Adapter<I>`) hanya bergantung pada traits lain yang sudah ditandakan sebagai pengkhususan traits (Salin, TrustedRandomAccess, FusedIterator).
//
// I.e. penanda tidak bergantung pada jangka hayat jenis yang dibekalkan pengguna.Modulo the Copy hole, yang sudah banyak bergantung pada pengkhususan lain.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Keperluan tambahan yang tidak dapat dinyatakan melalui trait bounds.Kami bergantung pada const eval sebagai gantinya:
        // a) tidak ada ZST kerana tidak akan ada peruntukan untuk menggunakan semula dan aritmetik penunjuk akan panic b) padanan ukuran seperti yang dikehendaki oleh kontrak Alloc c) penjajaran sesuai dengan yang dikehendaki oleh kontrak Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // kejatuhan kepada pelaksanaan yang lebih umum
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // gunakan try-fold sejak
        // - ia lebih baik untuk beberapa penyesuai iterator
        // - tidak seperti kebanyakan kaedah lelaran dalaman, ia hanya memerlukan &mut sendiri
        // - ia membolehkan kita memasukkan penunjuk penulisan ke dalam jaringnya dan mendapatkannya kembali pada akhirnya
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // lelaran berjaya, jangan tertipu
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // periksa sama ada kontrak SourceIter ditegakkan: jika tidak, kita mungkin tidak sampai ke tahap ini
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // semak kontrak InPlaceIterable.Ini hanya mungkin dilakukan jika iterator memajukan penunjuk sumber sama sekali.
        // Sekiranya ia menggunakan akses yang tidak dicentang melalui TrustedRandomAccess maka penunjuk sumber akan tetap berada di posisi awal dan kami tidak dapat menggunakannya sebagai rujukan
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // jatuhkan sebarang nilai yang tersisa di ekor sumber tetapi cegah penurunan peruntukan itu sendiri setelah IntoIter keluar dari ruang lingkup jika penurunan panics maka kita juga membocorkan sebarang elemen yang dikumpulkan ke dalam dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // kontrak InPlaceIterable tidak dapat disahkan dengan tepat di sini kerana try_fold mempunyai rujukan eksklusif untuk pointer sumber yang boleh kita lakukan adalah memeriksa sama ada ia masih dalam jangkauan
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}