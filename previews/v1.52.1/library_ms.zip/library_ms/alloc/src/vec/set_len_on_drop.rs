// Tetapkan panjang vec apabila nilai `SetLenOnDrop` di luar ruang lingkup.
//
// Ideanya adalah: Medan panjang di SetLenOnDrop adalah pemboleh ubah tempatan yang akan dilihat oleh pengoptimum tidak sama dengan kedai mana pun melalui penunjuk data Vec.
// Ini adalah penyelesaian untuk analisis alias isu #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}