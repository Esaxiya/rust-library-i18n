//! Baris keutamaan dilaksanakan dengan timbunan binari.
//!
//! Memasukkan dan memasukkan elemen terbesar mempunyai kerumitan masa *O*(log(*n*)).
//! Memeriksa elemen terbesar ialah *O*(1).Menukar vector ke timbunan binari boleh dilakukan di tempat, dan mempunyai kerumitan *O*(*n*).
//! Tumpukan binari juga boleh ditukarkan ke vector yang disusun di tempat, membolehkannya digunakan untuk heaport di tempat *O*(*n*\*log(* n*)).
//!
//! # Examples
//!
//! Ini adalah contoh yang lebih besar yang menerapkan [Dijkstra's algorithm][dijkstra] untuk menyelesaikan [shortest path problem][sssp] pada [directed graph][dir_graph].
//!
//! Ini menunjukkan cara menggunakan [`BinaryHeap`] dengan jenis tersuai.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Baris keutamaan bergantung pada `Ord`.
//! // Laksanakan trait secara eksplisit supaya barisan menjadi timbunan min dan bukannya timbunan maksimum.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Perhatikan bahawa kami membatalkan pesanan dengan kos.
//!         // Sekiranya berlaku seri, kami membandingkan kedudukan, langkah ini diperlukan untuk membuat pelaksanaan `PartialEq` dan `Ord` konsisten.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` perlu dilaksanakan juga.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Setiap node ditunjukkan sebagai `usize`, untuk pelaksanaan yang lebih pendek.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Algoritma jalan terpendek Dijkstra.
//!
//! // Mulakan di `start` dan gunakan `dist` untuk mengesan jarak terpendek semasa ke setiap nod.Pelaksanaan ini tidak cekap memori kerana mungkin meninggalkan node pendua dalam barisan.
//! //
//! // Ia juga menggunakan `usize::MAX` sebagai nilai sentinel, untuk pelaksanaan yang lebih sederhana.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=jarak terpendek semasa dari `start` hingga `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Kami berada di `start`, dengan kos sifar
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Teliti sempadan dengan simpul kos rendah (min-heap) pertama
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Sebagai alternatif kita boleh terus mencari semua jalan terpendek
//!         if position == goal { return Some(cost); }
//!
//!         // Penting kerana kita mungkin telah menemui jalan yang lebih baik
//!         if cost > dist[position] { continue; }
//!
//!         // Untuk setiap simpul yang dapat kita jangkau, lihat apakah kita dapat mencari jalan dengan kos yang lebih rendah melalui simpul ini
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Sekiranya ada, tambahkan ke bahagian depan dan teruskan
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Tenang, kita sekarang telah menemui jalan yang lebih baik
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Matlamat tidak dapat dicapai
//!     None
//! }
//!
//! fn main() {
//!     // Ini adalah graf terarah yang akan kami gunakan.
//!     // Nombor nod sesuai dengan keadaan yang berbeza, dan berat edge melambangkan kos bergerak dari satu nod ke nod yang lain.
//!     //
//!     // Perhatikan bahawa bahagian tepi adalah sehala.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Grafik ditunjukkan sebagai daftar adjacency di mana setiap indeks, yang sesuai dengan nilai nod, mempunyai senarai tepi keluar.
//!     // Terpilih untuk kecekapannya.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Node 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Node 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Node 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Node 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nod 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Baris keutamaan dilaksanakan dengan timbunan binari.
///
/// Ini akan menjadi timbunan maksimum.
///
/// Ini adalah kesalahan logik untuk item diubah sedemikian rupa sehingga pesanan item berkenaan dengan item lain, seperti yang ditentukan oleh `Ord` trait, berubah semasa berada di timbunan.
///
/// Ini biasanya hanya boleh dilakukan melalui kod `Cell`, `RefCell`, keadaan global, I/O, atau tidak selamat.
/// Tingkah laku yang disebabkan oleh kesalahan logik seperti itu tidak dinyatakan, tetapi tidak akan menghasilkan tingkah laku yang tidak ditentukan.
/// Ini boleh merangkumi panics, hasil yang tidak betul, pengguguran, kebocoran memori, dan penamatan.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Jenis inferensi membolehkan kita menghilangkan tandatangan jenis eksplisit (yang akan menjadi `BinaryHeap<i32>` dalam contoh ini).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Kita boleh menggunakan mengintip untuk melihat item seterusnya di timbunan.
/// // Dalam kes ini, belum ada item di dalamnya sehingga kami dapat Tidak Ada.
/// assert_eq!(heap.peek(), None);
///
/// // Mari tambah beberapa markah ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Sekarang mengintip menunjukkan item yang paling penting di timbunan.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Kita boleh memeriksa panjang timbunan.
/// assert_eq!(heap.len(), 3);
///
/// // Kami dapat mengulangi item di timbunan, walaupun barang-barang tersebut dikembalikan dalam urutan rawak.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Sekiranya kita memilih skor ini, mereka harus kembali mengikut urutan.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Kami dapat membersihkan timbunan barang yang tinggal.
/// heap.clear();
///
/// // Tumpukan sekarang mesti kosong.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `std::cmp::Reverse` atau implementasi `Ord` khusus dapat digunakan untuk menjadikan `BinaryHeap` sebagai timbunan min.
/// Ini menjadikan `heap.pop()` mengembalikan nilai terkecil dan bukan yang terbesar.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Nilai bungkus dalam `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Sekiranya kita memperoleh skor ini sekarang, skor tersebut harus kembali mengikut urutan terbalik.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Kerumitan masa
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Nilai untuk `push` adalah kos yang diharapkan;dokumentasi kaedah memberikan analisis yang lebih terperinci.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struktur membungkus rujukan yang boleh berubah untuk item terhebat pada `BinaryHeap`.
///
///
/// `struct` ini dibuat dengan kaedah [`peek_mut`] pada [`BinaryHeap`].
/// Lihat dokumentasinya untuk lebih lanjut.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // KESELAMATAN: PeekMut hanya dibuat untuk timbunan kosong.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SELAMAT: PeekMut hanya dibuat untuk timbunan kosong
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SELAMAT: PeekMut hanya dibuat untuk timbunan kosong
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Mengeluarkan nilai mengintip dari timbunan dan mengembalikannya.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Membuat `BinaryHeap<T>` kosong.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Membuat `BinaryHeap` kosong sebagai timbunan maksimum.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Membuat `BinaryHeap` kosong dengan kapasiti tertentu.
    /// Ini mengalokasikan memori yang mencukupi untuk elemen `capacity`, sehingga `BinaryHeap` tidak perlu dialokasikan semula sehingga mengandungi sekurang-kurangnya banyak nilai.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Mengembalikan rujukan yang boleh berubah ke item terhebat dalam timbunan binari, atau `None` jika kosong.
    ///
    /// Note: Sekiranya nilai `PeekMut` bocor, timbunan mungkin dalam keadaan tidak konsisten.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Kerumitan masa
    ///
    /// Sekiranya item diubah suai, maka kerumitan masa terburuk adalah *O*(log(*n*)), jika tidak, ia adalah *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Mengeluarkan item terhebat dari timbunan binari dan mengembalikannya, atau `None` jika kosong.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Kerumitan masa
    ///
    /// Kos kes terburuk `pop` pada timbunan yang mengandungi elemen *n* ialah *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // KESELAMATAN: !self.is_empty() bermaksud bahawa self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Menolak item ke timbunan binari.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Kerumitan masa
    ///
    /// Kos jangkaan `push`, rata-rata setiap kemungkinan susunan elemen yang didorong, dan jumlah tolakan yang cukup banyak, adalah *O*(1).
    ///
    /// Ini adalah metrik kos yang paling bermakna semasa mendorong elemen yang *belum* sudah ada dalam corak yang disusun.
    ///
    /// Kerumitan masa merosot jika unsur-unsur didorong mengikut urutan menaik.
    /// Dalam keadaan terburuk, elemen didorong dalam urutan tertib menaik dan kos pelunasan yang dilunaskan adalah *O*(log(*n*)) berbanding timbunan yang mengandungi elemen *n*.
    ///
    /// Kos terburuk panggilan *tunggal* ke `push` ialah *O*(*n*).Kes terburuk berlaku apabila kapasiti habis dan memerlukan ukuran semula.
    /// Kos perubahan saiz telah dilunaskan dalam angka sebelumnya.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // KESELAMATAN: Oleh kerana kami menolak item baru, ini bermakna
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Menggunakan `BinaryHeap` dan mengembalikan vector dalam urutan (ascending) yang disusun.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // KESELAMATAN: `end` bermula dari `self.len() - 1` hingga 1 (kedua-duanya termasuk),
            //  jadi selalu ada indeks yang sah untuk diakses.
            //  Adalah selamat untuk mengakses indeks 0 (iaitu `ptr`), kerana
            //  1 <=akhir <self.len(), yang bermaksud self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // KESELAMATAN: `end` bermula dari `self.len() - 1` hingga 1 (kedua-duanya termasuk) jadi:
            //  0 <1 <=akhir <= self.len(), 1 <self.len() Yang bermaksud 0 <akhir dan akhir <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Pelaksanaan sift_up dan sift_down menggunakan blok yang tidak selamat untuk memindahkan elemen keluar dari vector (meninggalkan lubang), beralih sepanjang yang lain dan memindahkan elemen yang dikeluarkan kembali ke vector di lokasi akhir lubang.
    //
    // Jenis `Hole` digunakan untuk menggambarkan ini, dan pastikan lubang diisi kembali di hujung ruang lingkupnya, walaupun pada panic.
    // Menggunakan lubang mengurangkan faktor malar berbanding dengan menggunakan pertukaran, yang melibatkan dua kali lebih banyak pergerakan.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Pemanggil mesti menjamin bahawa `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Keluarkan nilainya pada `pos` dan buat lubang.
        // KESELAMATAN: Pemanggil menjamin bahawa pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // KESELAMATAN: hole.pos()> mula>=0, yang bermaksud hole.pos()> 0
            //  dan hole.pos(), 1 tidak dapat mengalir keluar.
            //  Ini menjamin ibu bapa <hole.pos() jadi indeks yang sah dan juga!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // KESELAMATAN: Sama seperti di atas
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Ambil elemen pada `pos` dan gerakkan ke bawah timbunan, sementara anak-anaknya lebih besar.
    ///
    ///
    /// # Safety
    ///
    /// Pemanggil mesti menjamin bahawa `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // KESELAMATAN: Pemanggil menjamin bahawa pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Gelung tidak berubah: anak==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // bandingkan dengan yang lebih besar dari dua kanak-kanak KESELAMATAN: anak <akhir, 1 <self.len() dan anak + 1 <akhir <= self.len(), jadi mereka adalah indeks yang sah.
            //
            //  anak==2 *hole.pos() + 1!= hole.pos() dan anak + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 atau 2* hole.pos() + 2 boleh melimpah jika T adalah ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // jika kita sudah teratur, berhenti.
            // KESELAMATAN: anak sekarang adalah anak tua atau anak tua +1
            //  Kami telah membuktikan bahawa kedua-duanya <self.len() dan!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // KESELAMATAN: sama seperti di atas.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // KESELAMATAN: &&litar pintas, yang bermaksud bahawa di
        //  syarat kedua sudah benar bahawa anak==akhir, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // KESELAMATAN: anak sudah terbukti sebagai indeks yang sah dan
            //  anak==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Pemanggil mesti menjamin bahawa `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // KESELAMATAN: pos <len dijamin oleh pemanggil dan
        //  jelas len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Ambil elemen pada `pos` dan pindahkan ke bawah timbunan, kemudian angkat ke kedudukannya.
    ///
    ///
    /// Note: Ini lebih pantas apabila elemen tersebut diketahui besar/seharusnya lebih dekat ke bawah.
    ///
    /// # Safety
    ///
    /// Pemanggil mesti menjamin bahawa `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // KESELAMATAN: Pemanggil menjamin bahawa pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Gelung tidak berubah: anak==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // KESELAMATAN: anak <akhir, 1 <self.len() dan
            //  anak + 1 <akhir <= self.len(), jadi mereka adalah indeks yang sah.
            //  anak==2 *hole.pos() + 1!= hole.pos() dan anak + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 atau 2* hole.pos() + 2 boleh melimpah jika T adalah ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // KESELAMATAN: Sama seperti di atas
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // KESELAMATAN: anak==akhir, 1 <self.len(), jadi ini adalah indeks yang sah
            //  dan anak==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // KESELAMATAN: pos adalah kedudukan di dalam lubang dan sudah terbukti
        //  menjadi indeks yang sah.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // KESELAMATAN: n bermula dari self.len()/2 dan turun ke 0.
            //  Satu-satunya kes apabila! (N <self.len()) adalah jika self.len() ==0, tetapi dikesampingkan oleh keadaan gelung.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Memindahkan semua elemen `other` ke `self`, membiarkan `other` kosong.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` mengambil operasi O(len1 + len2) dan kira-kira 2 *(len1 + len2) perbandingan dalam keadaan terburuk sementara `extend` mengambil operasi O(len2* log(len1)) dan kira-kira 1 *len2* log_2(len1) perbandingan dalam keadaan terburuk, dengan andaian len1>= len2.
        // Untuk timbunan yang lebih besar, titik silang tidak lagi mengikuti penaakulan ini dan ditentukan secara empirik.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Mengembalikan iterator yang mengambil elemen dalam susunan timbunan.
    /// Unsur yang diambil dikeluarkan dari timbunan asal.
    /// Elemen yang tinggal akan dikeluarkan mengikut susunan timbunan.
    ///
    /// Note:
    /// * `.drain_sorted()` adalah *O*(*n*\*log(* n*)); jauh lebih perlahan daripada `.drain()`.
    ///   Anda harus menggunakan yang terakhir untuk kebanyakan kes.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // membuang semua elemen mengikut susunan timbunan
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Hanya mengekalkan unsur-unsur yang ditentukan oleh predikat.
    ///
    /// Dengan kata lain, keluarkan semua elemen `e` sehingga `f(&e)` mengembalikan `false`.
    /// Elemen dikunjungi dalam urutan yang tidak disusun (dan tidak ditentukan).
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // hanya menyimpan nombor genap
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Mengembalikan iterator yang mengunjungi semua nilai dalam vector yang mendasarinya, mengikut urutan sewenang-wenangnya.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Cetak 1, 2, 3, 4 mengikut urutan sewenang-wenangnya
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Mengembalikan iterator yang mengambil elemen dalam susunan timbunan.
    /// Kaedah ini memakan timbunan asli.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Mengembalikan item terhebat dalam timbunan binari, atau `None` jika kosong.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Kerumitan masa
    ///
    /// Kos adalah *O*(1) dalam keadaan terburuk.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Mengembalikan bilangan elemen yang boleh dipegang oleh timbunan binari tanpa mengagihkan semula.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Memastikan kapasiti minimum untuk `additional` lebih banyak elemen yang akan dimasukkan ke dalam `BinaryHeap` yang diberikan.
    /// Tidak ada apa-apa jika kapasiti sudah mencukupi.
    ///
    /// Perhatikan bahawa pengagihan mungkin memberikan koleksi lebih banyak ruang daripada yang diminta.
    /// Oleh itu kapasiti tidak dapat diandalkan dengan tepat.
    /// Lebih suka [`reserve`] jika diharapkan penyisipan future.
    ///
    /// # Panics
    ///
    /// Panics jika kapasiti baru melimpah `usize`.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Menyimpan kapasiti untuk sekurang-kurangnya `additional` lebih banyak elemen yang akan dimasukkan ke dalam `BinaryHeap`.
    /// Koleksi mungkin menyimpan lebih banyak ruang untuk mengelakkan penempatan semula yang kerap.
    ///
    /// # Panics
    ///
    /// Panics jika kapasiti baru melimpah `usize`.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Buang kapasiti tambahan sebanyak mungkin.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Membuang kapasiti dengan batas bawah.
    ///
    /// Kapasiti akan kekal sekurang-kurangnya sebesar kedua dan nilai yang dibekalkan.
    ///
    ///
    /// Sekiranya kapasiti semasa kurang dari had bawah, ini adalah op-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Menggunakan `BinaryHeap` dan mengembalikan vector yang mendasarinya mengikut urutan sewenang-wenangnya.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Akan dicetak mengikut beberapa pesanan
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Mengembalikan panjang timbunan binari.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Periksa sama ada timbunan binari kosong.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Membersihkan timbunan binari, mengembalikan lelaran ke atas elemen yang dikeluarkan.
    ///
    /// Unsur-unsur tersebut dikeluarkan mengikut urutan sewenang-wenangnya.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Menjatuhkan semua item dari timbunan binari.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Lubang mewakili lubang dalam potongan iaitu, indeks tanpa nilai yang sah (kerana ia dipindahkan atau digandakan).
///
/// Secara drop, `Hole` akan memulihkan potongan dengan mengisi kedudukan lubang dengan nilai yang pada awalnya dikeluarkan.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Buat `Hole` baru di indeks `pos`.
    ///
    /// Tidak selamat kerana pos mesti berada dalam bahagian data.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SELAMAT: pos mesti berada di dalam kepingan
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Mengembalikan rujukan ke elemen yang dikeluarkan.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Mengembalikan rujukan ke elemen di `index`.
    ///
    /// Tidak selamat kerana indeks mesti berada dalam bahagian data dan tidak sama dengan pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Pindahkan lubang ke lokasi baru
    ///
    /// Tidak selamat kerana indeks mesti berada dalam bahagian data dan tidak sama dengan pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // isi lubang lagi
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Pengulangan ke atas elemen `BinaryHeap`.
///
/// `struct` ini dicipta oleh [`BinaryHeap::iter()`].
/// Lihat dokumentasinya untuk lebih lanjut.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Keluarkan memihak kepada `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Pengulangan yang dimiliki atas unsur `BinaryHeap`.
///
/// `struct` ini dicipta oleh [`BinaryHeap::into_iter()`] (disediakan oleh `IntoIterator` trait).
/// Lihat dokumentasinya untuk lebih lanjut.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Iterator pengeringan ke atas elemen `BinaryHeap`.
///
/// `struct` ini dicipta oleh [`BinaryHeap::drain()`].
/// Lihat dokumentasinya untuk lebih lanjut.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Iterator pengeringan ke atas elemen `BinaryHeap`.
///
/// `struct` ini dicipta oleh [`BinaryHeap::drain_sorted()`].
/// Lihat dokumentasinya untuk lebih lanjut.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Mengeluarkan unsur timbunan mengikut urutan timbunan.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Menukar `Vec<T>` menjadi `BinaryHeap<T>`.
    ///
    /// Penukaran ini berlaku di tempat, dan mempunyai kerumitan masa *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Menukar `BinaryHeap<T>` menjadi `Vec<T>`.
    ///
    /// Penukaran ini tidak memerlukan pergerakan atau peruntukan data, dan mempunyai kerumitan masa yang berterusan.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Membuat iterator yang memakan masa, iaitu nilai yang memindahkan setiap nilai dari timbunan binari mengikut urutan sewenang-wenangnya.
    /// Timbunan binari tidak dapat digunakan setelah memanggilnya.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Cetak 1, 2, 3, 4 mengikut urutan sewenang-wenangnya
    /// for x in heap.into_iter() {
    ///     // x mempunyai jenis i32, bukan &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}