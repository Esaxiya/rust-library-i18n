// Ini adalah usaha pelaksanaan yang sesuai dengan ideal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Oleh kerana Rust sebenarnya tidak mempunyai jenis bergantung dan rekursi polimorfik, kami membuat banyak keselamatan.
//

// Matlamat utama modul ini adalah untuk mengelakkan kerumitan dengan menganggap pokok itu sebagai bekas generik (jika berbentuk pelik) dan mengelakkan berurusan dengan kebanyakan invarian B-Tree.
//
// Oleh itu, modul ini tidak peduli sama ada entri disusun, node mana yang boleh menjadi kurang lengkap, atau apa maksudnya underfull.Walau bagaimanapun, kami bergantung pada beberapa invarian:
//
// - Pokok mesti mempunyai depth/height yang seragam.Ini bermaksud bahawa setiap jalan ke daun dari simpul tertentu mempunyai panjang yang sama.
// - Node panjang `n` mempunyai kekunci `n`, nilai `n`, dan tepi `n + 1`.
//   Ini menunjukkan bahawa walaupun simpul kosong mempunyai sekurang-kurangnya satu edge.
//   Untuk simpul daun, "having an edge" hanya bermaksud kita dapat mengenal pasti kedudukan di simpul, kerana tepi daun kosong dan tidak memerlukan perwakilan data.
// Dalam nod dalaman, edge sama-sama mengenal pasti kedudukan dan mengandungi penunjuk ke simpul anak.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Perwakilan node daun yang mendasari dan sebahagian perwakilan nod dalaman.
struct LeafNode<K, V> {
    /// Kami mahu menjadi covarian dalam `K` dan `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Indeks nod ini ke dalam array `edges` nod induk.
    /// `*node.parent.edges[node.parent_idx]` semestinya sama dengan `node`.
    /// Ini hanya dijamin akan dimulakan apabila `parent` tidak sifar.
    parent_idx: MaybeUninit<u16>,

    /// Bilangan kunci dan nilai yang disimpan oleh nod ini.
    len: u16,

    /// Susunan yang menyimpan data sebenar nod.
    /// Hanya elemen `len` pertama bagi setiap array yang dimulakan dan sah.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Memulakan `LeafNode` baru di tempat.
    unsafe fn init(this: *mut Self) {
        // Sebagai dasar umum, kami membiarkan bidang tidak diinisialisasi jika boleh, kerana ini mestilah sedikit lebih cepat dan lebih mudah untuk dijejaki di Valgrind.
        //
        unsafe {
            // parent_idx, kunci dan nilai semuanya MungkinUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Membuat `LeafNode` kotak baru.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Perwakilan nod dalaman yang mendasari.Seperti `LeafNode`s, ini harus disembunyikan di belakang`BoxedNode`s untuk mengelakkan penurunan kunci dan nilai yang belum dimulakan.
/// Mana-mana penunjuk ke `InternalNode` secara langsung dapat dilemparkan ke penunjuk ke bahagian `LeafNode` yang mendasari nod, yang membolehkan kod bertindak pada daun dan nod dalaman secara umum tanpa perlu memeriksa mana satu dari kedua titik penunjuk itu.
///
/// Harta ini diaktifkan dengan penggunaan `repr(C)`.
///
#[repr(C)]
// gdb_providers.py menggunakan nama jenis ini untuk introspeksi.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Petunjuk kepada anak-anak nod ini.
    /// `len + 1` ini dianggap diinisialisasi dan sah, kecuali pada akhir, sementara pokok dipegang melalui jenis pinjaman `Dying`, beberapa petunjuk ini tergantung.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Membuat `InternalNode` kotak baru.
    ///
    /// # Safety
    /// Invarian dari nod dalaman adalah bahawa mereka mempunyai sekurang-kurangnya satu edge yang dimulakan dan sah.
    /// Fungsi ini tidak menyediakan edge seperti itu.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Kita hanya perlu menginisialisasi data;pinggirnya MungkinUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Penunjuk yang diurus dan tidak kosong ke nod.Ini adalah penunjuk yang dimiliki ke `LeafNode<K, V>` atau penunjuk yang dimiliki ke `InternalNode<K, V>`.
///
/// Walau bagaimanapun, `BoxedNode` tidak mengandungi maklumat mengenai dua jenis nod yang sebenarnya mengandungi, dan, sebahagiannya kerana kekurangan maklumat ini, bukan jenis yang terpisah dan tidak mempunyai pemusnah.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Node akar pokok yang dimiliki.
///
/// Perhatikan bahawa ini tidak mempunyai alat pemusnah, dan mesti dibersihkan secara manual.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Mengembalikan pokok milik baru, dengan simpul akarnya sendiri yang pada mulanya kosong.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` tidak boleh sifar.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Meminjam simpul akar yang dimiliki secara bergantian.
    /// Tidak seperti `reborrow_mut`, ini selamat kerana nilai kembali tidak dapat digunakan untuk memusnahkan akar, dan tidak ada rujukan lain ke pohon.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Meminjam sedikit simpul akar yang dimiliki secara perlahan-lahan.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Peralihan tidak dapat dipulihkan ke rujukan yang membenarkan melintasi dan menawarkan kaedah yang merosakkan dan sedikit lagi.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Menambah nod dalaman baru dengan edge tunggal yang menunjuk ke simpul akar sebelumnya, buat simpul baru itu sebagai simpul akar, dan kembalikannya.
    /// Ini meningkatkan ketinggian sebanyak 1 dan bertentangan dengan `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, kecuali bahawa kita lupa bahawa kita dalaman sekarang:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Membuang node akar dalaman, menggunakan anak pertamanya sebagai simpul akar baru.
    /// Seperti yang dimaksudkan hanya disebut ketika simpul akar hanya memiliki satu anak, pembersihan tidak dilakukan pada salah satu kunci, nilai dan anak-anak lain.
    ///
    /// Ini menurunkan ketinggian sebanyak 1 dan bertentangan dengan `push_internal_level`.
    ///
    /// Memerlukan akses eksklusif ke objek `Root` tetapi tidak ke simpul root;
    /// ia tidak akan membatalkan pengendalian lain atau rujukan ke simpul akar.
    ///
    /// Panics jika tidak ada tahap dalaman, iaitu, jika simpul akar adalah daun.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // KESELAMATAN: kami menegaskan sebagai dalaman.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // KESELAMATAN: kami meminjam `self` secara eksklusif dan jenis pinjamannya adalah eksklusif.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // KESELAMATAN: edge pertama selalu dimulakan.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` selalu kovarian dalam `K` dan `V`, walaupun `BorrowType` adalah `Mut`.
// Ini secara teknikalnya salah, tetapi tidak dapat mengakibatkan ketidakamanan kerana penggunaan dalaman `NodeRef` kerana kami tetap sepenuhnya generik melebihi `K` dan `V`.
//
// Namun, setiap kali jenis umum membungkus `NodeRef`, pastikan ia mempunyai varians yang betul.
//
/// Rujukan pada nod.
///
/// Jenis ini mempunyai sebilangan parameter yang mengawal bagaimana ia bertindak:
/// - `BorrowType`: Jenis dummy yang menggambarkan jenis pinjaman dan membawa seumur hidup.
///    - Apabila ini adalah `Immut<'a>`, `NodeRef` bertindak kasar seperti `&'a Node`.
///    - Apabila ini adalah `ValMut<'a>`, `NodeRef` bertindak kasar seperti `&'a Node` berkenaan dengan kunci dan struktur pokok, tetapi juga memungkinkan banyak rujukan yang dapat berubah pada nilai-nilai di seluruh pokok untuk wujud bersama.
///    - Apabila ini adalah `Mut<'a>`, `NodeRef` bertindak kasar seperti `&'a mut Node`, walaupun kaedah sisipan membolehkan penunjuk yang dapat berubah menjadi nilai wujud bersama.
///    - Apabila ini adalah `Owned`, `NodeRef` bertindak kasar seperti `Box<Node>`, tetapi tidak mempunyai alat pemusnah, dan mesti dibersihkan secara manual.
///    - Apabila ini adalah `Dying`, `NodeRef` masih bertindak kasar seperti `Box<Node>`, tetapi mempunyai kaedah untuk memusnahkan pokok sedikit demi sedikit, dan kaedah biasa, walaupun tidak ditandakan sebagai tidak selamat untuk dipanggil, boleh memanggil UB jika disebut dengan tidak betul.
///
///   Oleh kerana mana-mana `NodeRef` membolehkan menavigasi melalui pokok, `BorrowType` berkesan berlaku pada keseluruhan pokok, bukan hanya pada simpul itu sendiri.
/// - `K` dan `V`: Ini adalah jenis kunci dan nilai yang disimpan dalam nod.
/// - `Type`: Ini boleh menjadi `Leaf`, `Internal`, atau `LeafOrInternal`.
/// Ketika ini adalah `Leaf`, `NodeRef` menunjuk ke simpul daun, ketika ini adalah `Internal`, `NodeRef` menunjuk ke simpul dalaman, dan ketika ini adalah `LeafOrInternal`, `NodeRef` dapat menunjuk ke salah satu jenis nod.
///   `Type` dinamakan `NodeType` apabila digunakan di luar `NodeRef`.
///
/// Kedua-dua `BorrowType` dan `NodeType` membatasi kaedah apa yang kami laksanakan, untuk memanfaatkan keselamatan jenis statik.Terdapat batasan dalam cara kita menerapkan sekatan seperti itu:
/// - Untuk setiap parameter jenis, kita hanya dapat menentukan kaedah sama ada secara umum atau untuk satu jenis tertentu.
/// Sebagai contoh, kita tidak dapat menentukan kaedah seperti `into_kv` secara umum untuk semua `BorrowType`, atau sekali untuk semua jenis yang seumur hidup, kerana kita mahu ia mengembalikan rujukan `&'a`.
///   Oleh itu, kami menentukannya hanya untuk jenis `Immut<'a>` yang paling lemah.
/// - Kami tidak boleh mendapatkan paksaan secara tersirat dari mengatakan `Mut<'a>` hingga `Immut<'a>`.
///   Oleh itu, kita harus memanggil `reborrow` secara eksplisit pada `NodeRef` yang lebih kuat untuk mencapai kaedah seperti `into_kv`.
///
/// Semua kaedah di `NodeRef` yang mengembalikan sebilangan rujukan, sama ada:
/// - Ambil nilai `self`, dan kembalikan jangka hayat yang dibawa oleh `BorrowType`.
///   Kadang kala, untuk menggunakan kaedah sedemikian, kita perlu memanggil `reborrow_mut`.
/// - Ambil `self` dengan rujukan, dan (implicitly) mengembalikan jangka hayat rujukan itu, bukannya jangka hayat yang dibawa oleh `BorrowType`.
/// Dengan cara itu, penyemak pinjaman menjamin bahawa `NodeRef` tetap dipinjam selagi rujukan yang dikembalikan digunakan.
///   Kaedah yang menyokong memasukkan bengkokkan peraturan ini dengan mengembalikan penunjuk mentah, iaitu, rujukan tanpa seumur hidup.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Bilangan tahap yang simpul dan tahap daun terpisah, pemalar nod yang tidak dapat digambarkan sepenuhnya oleh `Type`, dan simpul itu sendiri tidak disimpan.
    /// Kita hanya perlu menyimpan ketinggian simpul akar, dan memperoleh ketinggian setiap nod lain darinya.
    /// Mesti sifar jika `Type` adalah `Leaf` dan bukan sifar jika `Type` adalah `Internal`.
    ///
    ///
    height: usize,
    /// Penunjuk ke daun atau nod dalaman.
    /// Definisi `InternalNode` memastikan bahawa penunjuk itu berlaku sama ada.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Buka rujukan nod yang dibungkus sebagai `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Mendedahkan data nod dalaman.
    ///
    /// Mengembalikan ptr mentah untuk mengelakkan pembatalan rujukan lain ke nod ini.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // KESELAMATAN: jenis nod statik ialah `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Meminjam akses eksklusif ke data nod dalaman.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Mencari panjang nod.Ini adalah bilangan kunci atau nilai.
    /// Bilangan tepi adalah `len() + 1`.
    /// Perhatikan bahawa, walaupun selamat, memanggil fungsi ini boleh memberi kesan sampingan dari membatalkan rujukan berubah-ubah yang telah dibuat oleh kod yang tidak selamat.
    ///
    pub fn len(&self) -> usize {
        // Yang penting, kami hanya mengakses medan `len` di sini.
        // Sekiranya BorrowType adalah marker::ValMut, mungkin terdapat rujukan yang boleh berubah yang tidak dapat disangkal.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Mengembalikan bilangan tahap di mana simpul dan daunnya terpisah.
    /// Ketinggian sifar bermaksud simpul adalah daun itu sendiri.
    /// Sekiranya anda membayangkan pokok dengan akar di atas, nombor tersebut menyatakan ketinggian node muncul.
    /// Sekiranya anda membayangkan pokok dengan daun di atas, bilangannya akan menyatakan seberapa tinggi pokok itu memanjang di atas simpul.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Buat sementara waktu, rujukan lain yang tidak berubah untuk nod yang sama.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Mendedahkan bahagian daun dari mana-mana daun atau nod dalaman.
    ///
    /// Mengembalikan ptr mentah untuk mengelakkan pembatalan rujukan lain ke nod ini.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Node mesti sah untuk sekurang-kurangnya bahagian LeafNode.
        // Ini bukan rujukan dalam jenis NodeRef kerana kami tidak tahu apakah itu mesti unik atau dikongsi.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Mencari induk nod semasa.
    /// Mengembalikan `Ok(handle)` jika nod semasa sebenarnya mempunyai induk, di mana `handle` menunjuk ke edge ibu bapa yang menunjuk ke nod semasa.
    ///
    /// Mengembalikan `Err(self)` jika nod semasa tidak mempunyai induk, memberikan kembali `NodeRef` yang asal.
    ///
    /// Nama kaedah menganggap anda menggambarkan pokok dengan simpul akar di atas.
    ///
    /// `edge.descend().ascend().unwrap()` dan `node.ascend().unwrap().descend()` semestinya kedua-duanya, setelah berjaya, tidak melakukan apa-apa.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Kita perlu menggunakan penunjuk mentah untuk nod kerana, jika BorrowType adalah marker::ValMut, mungkin ada rujukan yang dapat berubah yang tidak dapat disangkal.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Perhatikan bahawa `self` mestilah tidak mudah.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Perhatikan bahawa `self` mestilah tidak mudah.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Menampakkan bahagian daun dari daun atau simpul dalaman pada pokok yang tidak berubah.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // KESELAMATAN: tidak ada rujukan yang boleh berubah ke dalam pohon ini yang dipinjam sebagai `Immut`.
        unsafe { &*ptr }
    }

    /// Meminjam pandangan ke kunci yang disimpan di nod.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Mirip dengan `ascend`, mendapat rujukan ke simpul induk nod, tetapi juga menyahpindah nod semasa dalam proses.
    /// Perkara ini tidak selamat kerana node semasa masih dapat diakses walaupun disahpindah.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Tidak selamat menyatakan kepada penyusun maklumat statik bahawa nod ini adalah `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Dengan tidak selamat menegaskan kepada penyusun maklumat statik bahawa nod ini adalah `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Buat sementara waktu, rujukan lain yang boleh berubah untuk nod yang sama.Hati-hati, kerana kaedah ini sangat berbahaya, dua kali ganda kerana kaedah ini mungkin tidak akan langsung berbahaya.
    ///
    /// Oleh kerana penunjuk yang berubah-ubah dapat berkeliaran di mana sahaja di sekitar pohon, penunjuk yang dikembalikan dapat dengan mudah digunakan untuk membuat penunjuk yang asli menggantung, di luar batas, atau tidak sah di bawah peraturan pinjaman bertumpuk.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) pertimbangkan untuk menambahkan lagi parameter jenis ke `NodeRef` yang menyekat penggunaan kaedah navigasi pada petunjuk yang ditarik balik, mencegah ini tidak selamat.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Meminjam akses eksklusif ke bahagian daun mana-mana daun atau nod dalaman.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // KESELAMATAN: kami mempunyai akses eksklusif ke seluruh nod.
        unsafe { &mut *ptr }
    }

    /// Menawarkan akses eksklusif ke bahagian daun mana-mana daun atau simpul dalaman.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // KESELAMATAN: kami mempunyai akses eksklusif ke seluruh nod.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Meminjam akses eksklusif ke elemen kawasan penyimpanan kunci.
    ///
    /// # Safety
    /// `index` berada dalam had 0..KAPASITI
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // KESELAMATAN: pemanggil tidak akan dapat memanggil kaedah lebih lanjut mengenai diri
        // sehingga rujukan kunci terpendam, kerana kami mempunyai akses unik sepanjang hayat pinjaman.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Meminjam akses eksklusif ke elemen atau bahagian kawasan penyimpanan nilai nod.
    ///
    /// # Safety
    /// `index` berada dalam had 0..KAPASITI
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // KESELAMATAN: pemanggil tidak akan dapat memanggil kaedah lebih lanjut mengenai diri
        // sehingga rujukan slice nilai dijatuhkan, kerana kami mempunyai akses unik sepanjang hayat pinjaman.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Meminjam akses eksklusif ke elemen atau bahagian kawasan penyimpanan nod untuk kandungan edge.
    ///
    /// # Safety
    /// `index` berada dalam had 0..KAPASITI + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // KESELAMATAN: pemanggil tidak akan dapat memanggil kaedah lebih lanjut mengenai diri
        // sehingga rujukan potongan edge diturunkan, kerana kami mempunyai akses unik sepanjang hayat pinjaman.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Node mempunyai lebih daripada elemen permulaan `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Kami hanya membuat rujukan pada satu elemen yang kami minati, untuk mengelakkan penyebutan dengan rujukan yang luar biasa pada elemen lain, khususnya elemen yang dikembalikan kepada pemanggil dalam lelaran sebelumnya.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Kita mesti memaksa penunjuk array yang tidak berukuran kerana Rust terbitan #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Meminjam akses eksklusif ke panjang nod.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Menetapkan pautan nod ke induknya edge, tanpa membatalkan rujukan lain ke nod.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Membersihkan pautan root ke induknya edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Menambah pasangan nilai-kunci ke hujung nod.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Setiap item yang dikembalikan oleh `range` adalah indeks edge yang sah untuk nod.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Menambah pasangan nilai-kunci, dan edge untuk pergi ke sebelah kanan pasangan itu, ke hujung nod.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Memeriksa sama ada nod adalah nod `Internal` atau nod `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Rujukan untuk pasangan kunci-nilai tertentu atau edge dalam nod.
/// Parameter `Node` mestilah `NodeRef`, sementara `Type` boleh berupa `KV` (menandakan pegangan pada pasangan nilai kunci) atau `Edge` (menandakan pegangan pada edge).
///
/// Perhatikan bahawa nod `Leaf` walaupun boleh mempunyai pemegang `Edge`.
/// Daripada mewakili penunjuk ke simpul anak, ini mewakili ruang di mana penunjuk kanak-kanak akan pergi di antara pasangan nilai-kunci.
/// Sebagai contoh, dalam nod dengan panjang 2, akan terdapat 3 kemungkinan lokasi edge, satu di sebelah kiri nod, satu di antara dua pasang, dan satu di sebelah kanan nod.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Kami tidak memerlukan keseluruhan `#[derive(Clone)]` sepenuhnya, kerana satu-satunya masa `Node` akan `Clone`able adalah ketika ia adalah rujukan yang tidak berubah dan oleh itu `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Mengambil nod yang mengandungi edge atau pasangan nilai kunci yang ditunjukkan oleh pemegang ini.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Mengembalikan kedudukan pemegang ini di nod.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Membuat pegangan baru untuk pasangan nilai-kunci dalam `node`.
    /// Tidak selamat kerana pemanggil mesti memastikan bahawa `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Mungkin merupakan implementasi umum dari PartialEq, tetapi hanya digunakan dalam modul ini.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Untuk sementara mengambil pegangan lain yang tidak berubah pada lokasi yang sama.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Kami tidak dapat menggunakan Handle::new_kv atau Handle::new_edge kerana kami tidak tahu jenis kami
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Tidak selamat menyatakan kepada pengkompil maklumat statik bahawa nod pemegangnya adalah `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Untuk sementara mengambil pegangan lain yang boleh diubah pada lokasi yang sama.
    /// Hati-hati, kerana kaedah ini sangat berbahaya, dua kali ganda kerana kaedah ini mungkin tidak akan langsung berbahaya.
    ///
    ///
    /// Untuk perincian, lihat `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Kami tidak dapat menggunakan Handle::new_kv atau Handle::new_edge kerana kami tidak tahu jenis kami
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Membuat pemegang baru ke edge di `node`.
    /// Tidak selamat kerana pemanggil mesti memastikan bahawa `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Memandangkan indeks edge di mana kita ingin memasukkan ke dalam nod yang diisi dengan kapasiti, menghitung indeks KV yang masuk akal dari titik pemisah dan di mana untuk melakukan penyisipan.
///
/// Matlamat titik perpecahan adalah agar kunci dan nilainya berakhir dalam nod induk;
/// kunci, nilai dan tepi di sebelah kiri titik perpecahan menjadi anak kiri;
/// kunci, nilai dan tepi di sebelah kanan titik perpecahan menjadi anak yang betul.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Isu Rust #74834 cuba menerangkan peraturan simetri ini.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Memasukkan pasangan kunci-nilai baru antara pasangan nilai-kunci di sebelah kanan dan kiri edge ini.
    /// Kaedah ini mengandaikan bahawa terdapat cukup ruang di simpul untuk pasangan baru sesuai.
    ///
    /// Penunjuk yang dikembalikan menunjukkan nilai yang dimasukkan.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Memasukkan pasangan kunci-nilai baru antara pasangan nilai-kunci di sebelah kanan dan kiri edge ini.
    /// Kaedah ini membahagi simpul jika tidak ada cukup ruang.
    ///
    /// Penunjuk yang dikembalikan menunjukkan nilai yang dimasukkan.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Memperbaiki penunjuk induk dan indeks di simpul anak yang dipautkan oleh edge ini.
    /// Ini berguna apabila susunan tepi telah diubah,
    fn correct_parent_link(self) {
        // Buat backpointer tanpa membatalkan rujukan lain ke nod.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Memasukkan pasangan nilai kunci baru dan edge yang akan menuju ke sebelah kanan pasangan baru antara edge ini dan pasangan nilai kunci di sebelah kanan edge ini.
    /// Kaedah ini mengandaikan bahawa terdapat cukup ruang di simpul untuk pasangan baru sesuai.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Memasukkan pasangan nilai kunci baru dan edge yang akan menuju ke sebelah kanan pasangan baru antara edge ini dan pasangan nilai kunci di sebelah kanan edge ini.
    /// Kaedah ini membahagi simpul jika tidak ada cukup ruang.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Memasukkan pasangan kunci-nilai baru antara pasangan nilai-kunci di sebelah kanan dan kiri edge ini.
    /// Kaedah ini membelah simpul jika tidak ada cukup ruang, dan cuba memasukkan bahagian pemisah ke dalam nod induk secara berulang, sehingga akarnya tercapai.
    ///
    ///
    /// Sekiranya hasil yang dikembalikan adalah `Fit`, nod pemegangnya boleh menjadi simpul edge ini atau nenek moyang.
    /// Sekiranya hasil yang dikembalikan adalah `Split`, medan `left` akan menjadi simpul akar.
    /// Penunjuk yang dikembalikan menunjukkan nilai yang dimasukkan.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Mencari nod yang ditunjukkan oleh edge ini.
    ///
    /// Nama kaedah menganggap anda menggambarkan pokok dengan simpul akar di atas.
    ///
    /// `edge.descend().ascend().unwrap()` dan `node.ascend().unwrap().descend()` semestinya kedua-duanya, setelah berjaya, tidak melakukan apa-apa.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Kita perlu menggunakan penunjuk mentah untuk nod kerana, jika BorrowType adalah marker::ValMut, mungkin ada rujukan yang dapat berubah yang tidak dapat disangkal.
        // Tidak perlu risau memasuki medan ketinggian kerana nilai itu disalin.
        // Berhati-hatilah bahawa, setelah penunjuk simpul tidak dirujuk, kita mengakses array tepi dengan rujukan (Rust terbitan #73987) dan membatalkan rujukan lain ke dalam atau di dalam array, sekiranya ada.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Kami tidak dapat memanggil kaedah kunci dan nilai yang terpisah, kerana memanggil yang kedua membatalkan rujukan yang dikembalikan oleh yang pertama.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Ganti kunci dan nilai yang dimaksudkan oleh pemegang KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Membantu pelaksanaan `split` untuk `NodeType` tertentu, dengan menjaga data daun.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Membahagi nod yang mendasari menjadi tiga bahagian:
    ///
    /// - Node dipotong untuk hanya mengandungi pasangan nilai-kunci di sebelah kiri pemegang ini.
    /// - Kunci dan nilai yang ditunjukkan oleh pemegang ini diambil.
    /// - Semua pasangan nilai-kunci di sebelah kanan pemegang ini dimasukkan ke dalam nod yang baru diperuntukkan.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Mengeluarkan pasangan nilai-kunci yang ditunjukkan oleh pegangan ini dan mengembalikannya, bersama dengan edge tempat pasangan kunci-kunci itu jatuh.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Membahagi nod yang mendasari menjadi tiga bahagian:
    ///
    /// - Node dipotong untuk hanya mengandungi tepi dan pasangan kunci-nilai di sebelah kiri pemegang ini.
    /// - Kunci dan nilai yang ditunjukkan oleh pemegang ini diambil.
    /// - Semua tepi dan pasangan nilai-kunci di sebelah kanan pemegang ini dimasukkan ke dalam nod yang baru diperuntukkan.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Merupakan sesi untuk menilai dan melakukan operasi pengimbangan di sekitar pasangan kunci-nilai dalaman.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Memilih konteks keseimbangan yang melibatkan simpul sebagai anak, sehingga antara KV segera ke kiri atau ke kanan di simpul induk.
    /// Mengembalikan `Err` jika tidak ada ibu bapa.
    /// Panics jika ibu bapa kosong.
    ///
    /// Lebih suka sebelah kiri, menjadi optimum jika simpul yang diberikan entah bagaimana kurang sempurna, yang bermaksud di sini hanya bahawa ia mempunyai unsur yang lebih sedikit daripada saudara kirinya dan daripada saudara kanannya, jika ada.
    /// Dalam kes itu, penggabungan dengan saudara kiri lebih cepat, kerana kita hanya perlu memindahkan elemen N nod, bukannya mengalihkannya ke kanan dan bergerak lebih banyak daripada elemen N di depan.
    /// Mencuri dari saudara kiri juga biasanya lebih cepat, kerana kita hanya perlu menggeser elemen N simpul ke kanan, bukannya mengalihkan sekurang-kurangnya N unsur saudara ke kiri.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Mengembalikan sama ada penggabungan adalah mungkin, iaitu, sama ada terdapat ruang yang cukup dalam nod untuk menggabungkan KV pusat dengan kedua-dua nod anak yang berdekatan.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Melakukan penggabungan dan membiarkan penutupan memutuskan apa yang akan dikembalikan.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // KESELAMATAN: ketinggian nod yang digabungkan adalah satu di bawah ketinggian
                // nod edge ini, dengan itu di atas sifar, jadi ia adalah dalaman.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Menggabungkan pasangan kunci-nilai ibu bapa dan kedua-dua nod anak yang berdekatan ke simpul anak kiri dan mengembalikan nod ibu bapa yang menyusut.
    ///
    ///
    /// Panics kecuali kita `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Menggabungkan pasangan kunci-nilai ibu bapa dan kedua-dua nod anak yang berdekatan ke nod anak kiri dan mengembalikan nod anak itu.
    ///
    ///
    /// Panics kecuali kita `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Menggabungkan pasangan nilai kunci ibu bapa dan kedua-dua nod anak yang berdekatan ke simpul anak kiri dan mengembalikan pemegang edge di nod anak di mana anak edge yang dijejaki berakhir,
    ///
    ///
    /// Panics kecuali kita `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Mengeluarkan pasangan nilai kunci dari anak kiri dan meletakkannya di simpanan nilai kunci ibu bapa, sambil mendorong pasangan nilai kunci ibu bapa lama ke anak kanan.
    ///
    /// Mengembalikan pemegang ke edge pada anak kanan yang sesuai dengan tempat edge asal yang ditentukan oleh `track_right_edge_idx` berakhir.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Mengeluarkan pasangan nilai kunci dari anak kanan dan meletakkannya di simpanan nilai kunci ibu bapa, sambil menolak pasangan nilai kunci ibu bapa lama ke anak kiri.
    ///
    /// Mengembalikan pemegang ke edge di sebelah kiri anak yang ditentukan oleh `track_left_edge_idx`, yang tidak bergerak.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Ini mencuri sama dengan `steal_left` tetapi mencuri banyak elemen sekaligus.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Pastikan bahawa kita mungkin mencuri dengan selamat.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Pindahkan data daun.
            {
                // Beri ruang untuk unsur curi pada anak yang betul.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Gerakkan elemen dari anak kiri ke kanan.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Pindahkan pasangan paling kiri yang dicuri ke ibu bapa.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Pindahkan pasangan nilai kunci ibu bapa ke anak yang betul.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Buat ruang untuk tepi yang dicuri.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Curi tepi.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Klon simetri `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Pastikan bahawa kita mungkin mencuri dengan selamat.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Pindahkan data daun.
            {
                // Pindahkan pasangan paling kanan dicuri ke ibu bapa.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Pindahkan pasangan nilai kunci ibu bapa ke anak kiri.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Gerakkan elemen dari anak kanan ke kiri.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Isi jurang di mana unsur curi dulu.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Curi tepi.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Isi jurang di mana tepi dicuri dulu.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Mengeluarkan maklumat statik yang menyatakan bahawa simpul ini adalah nod `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Membuang sebarang maklumat statik yang menyatakan bahawa simpul ini adalah nod `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Memeriksa sama ada nod yang mendasari adalah nod `Internal` atau nod `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Pindahkan akhiran selepas `self` dari satu nod ke yang lain.`right` mesti kosong.
    /// edge pertama `right` tidak berubah.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Hasil penyisipan, apabila simpul perlu dikembangkan melebihi kemampuannya.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nod berubah pada pokok yang ada dengan unsur dan tepi yang berada di sebelah kiri `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Beberapa kunci dan nilai dipisahkan, untuk dimasukkan ke tempat lain.
    pub kv: (K, V),
    // Memiliki, tidak terpasang, simpul baru dengan elemen dan tepi yang berada di sebelah kanan `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Sama ada rujukan nod jenis peminjaman ini membolehkan melintasi nod lain di pokok.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal tidak diperlukan, ia berlaku dengan menggunakan hasil `borrow_mut`.
        // Dengan melumpuhkan traversal, dan hanya membuat rujukan baru ke akar, kita tahu bahawa setiap rujukan jenis `Owned` adalah ke simpul root.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Memasukkan nilai ke dalam kepingan elemen yang diinisialisasi diikuti oleh satu elemen yang tidak dimulakan.
///
/// # Safety
/// Bahagian ini mempunyai lebih daripada unsur `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Mengalih keluar dan mengembalikan nilai dari potongan semua elemen yang diinisialisasi, meninggalkan satu elemen yang belum dimulakan.
///
///
/// # Safety
/// Bahagian ini mempunyai lebih daripada unsur `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Menggeser elemen dalam kedudukan `distance` ke kiri.
///
/// # Safety
/// Potongan mempunyai sekurang-kurangnya unsur `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Menggeser elemen dalam kedudukan `distance` ke kanan.
///
/// # Safety
/// Potongan mempunyai sekurang-kurangnya unsur `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Memindahkan semua nilai dari kepingan elemen yang diinisialisasi ke kepingan elemen yang tidak dimulakan, meninggalkan `src` kerana semua yang belum dimulakan.
///
/// Berfungsi seperti `dst.copy_from_slice(src)` tetapi tidak memerlukan `T` menjadi `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;