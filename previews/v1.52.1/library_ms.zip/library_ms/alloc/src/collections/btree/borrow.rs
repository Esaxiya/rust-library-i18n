use core::marker::PhantomData;
use core::ptr::NonNull;

/// Memodelkan pengulangan semula dari sebilangan rujukan unik, apabila anda mengetahui bahawa penukaran semula dan semua keturunannya (iaitu, semua petunjuk dan rujukan yang berasal daripadanya) tidak akan digunakan lagi pada satu ketika, selepas itu anda ingin menggunakan rujukan unik yang semula .
///
///
/// Pemeriksa pinjaman biasanya menangani susunan peminjaman ini untuk anda, tetapi beberapa aliran kawalan yang menyelesaikan susunan ini terlalu rumit untuk diikuti oleh penyusun.
/// `DormantMutRef` membolehkan anda memeriksa pinjaman sendiri, sambil tetap menyatakan sifatnya yang tersusun, dan merangkumi kod penunjuk mentah yang diperlukan untuk melakukan ini tanpa tingkah laku yang tidak ditentukan.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Tangkap pinjaman unik, dan segera pinjam semula.
    /// Untuk penyusun, jangka hayat rujukan baru adalah sama dengan jangka hayat rujukan asal, tetapi anda promise untuk menggunakannya untuk jangka masa yang lebih pendek.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // KESELAMATAN: kami menahan pinjaman sepanjang 'a melalui `_marker`, dan kami mendedahkan
        // hanya rujukan ini, jadi unik.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Kembali ke pinjaman unik yang mula-mula ditangkap.
    ///
    /// # Safety
    ///
    /// Pembayaran balik mesti berakhir, iaitu, rujukan yang dikembalikan oleh `new` dan semua petunjuk dan rujukan yang berasal daripadanya, tidak boleh digunakan lagi.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // KESELAMATAN: keadaan keselamatan kita sendiri menunjukkan bahawa rujukan ini sekali lagi unik.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;