use core::intrinsics;
use core::mem;
use core::ptr;

/// Ini menggantikan nilai di sebalik rujukan unik `v` dengan memanggil fungsi yang berkaitan.
///
///
/// Sekiranya panic berlaku pada penutupan `change`, keseluruhan proses akan dibatalkan.
#[allow(dead_code)] // simpan sebagai ilustrasi dan untuk penggunaan future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Ini menggantikan nilai di sebalik rujukan unik `v` dengan memanggil fungsi yang relevan, dan mengembalikan hasil yang diperoleh selama ini.
///
///
/// Sekiranya panic berlaku pada penutupan `change`, keseluruhan proses akan dibatalkan.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}