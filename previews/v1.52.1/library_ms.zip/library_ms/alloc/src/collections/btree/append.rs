use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Menambah semua pasangan nilai-kunci dari penyatuan dua iterator menaik, menaikkan pemboleh ubah `length` sepanjang perjalanan.Yang terakhir ini memudahkan pemanggil untuk mengelakkan kebocoran ketika pengendali drop panik.
    ///
    /// Sekiranya kedua-dua iterator menghasilkan kunci yang sama, kaedah ini menjatuhkan pasangan dari iterator kiri dan menambahkan pasangan dari iterator kanan.
    ///
    /// Sekiranya anda mahu pokok berakhir dengan urutan menaik yang tegas, seperti `BTreeMap`, kedua-dua iterator harus menghasilkan kunci dalam urutan menaik yang tegas, masing-masing lebih besar daripada semua kunci di pokok, termasuk kunci yang sudah ada di pokok semasa masuk.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Kami bersiap untuk menggabungkan `left` dan `right` ke dalam urutan yang disusun mengikut masa linear.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Sementara itu, kami membina pokok dari urutan yang disusun mengikut masa linear.
        self.bulk_push(iter, length)
    }

    /// Menolak semua pasangan nilai-kunci ke hujung pokok, menaikkan pemboleh ubah `length` sepanjang perjalanan.
    /// Yang terakhir ini memudahkan pemanggil untuk mengelakkan kebocoran ketika iterator panik.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Ulangi melalui semua pasangan nilai-kunci, mendorongnya ke nod pada tahap yang betul.
        for (key, value) in iter {
            // Cuba tolak pasangan kunci-nilai ke simpul daun semasa.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Tidak ada ruang yang tersisa, naik dan tolak ke sana.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Menjumpai nod dengan ruang yang tinggal, tekan di sini.
                                open_node = parent;
                                break;
                            } else {
                                // Naik lagi.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Kami berada di puncak, buat simpul akar baru dan tekan ke sana.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Tolak pasangan nilai-kunci dan subtree kanan baru.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Turun ke daun paling kanan sekali lagi.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Tingkatkan panjang setiap lelaran, untuk memastikan peta menjatuhkan elemen yang dilampirkan walaupun memajukan panik iterator.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iterator untuk menggabungkan dua urutan yang disusun menjadi satu
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Sekiranya dua kunci sama, kembalikan pasangan nilai-kunci dari sumber yang betul.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}