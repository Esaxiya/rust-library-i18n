use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Rangka tindakan untuk kejadian dummy test crash yang memantau peristiwa tertentu.
/// Beberapa contoh mungkin dikonfigurasi ke panic pada satu ketika.
/// Acara adalah `clone`, `drop` atau sebilangan `query` tanpa nama.
///
/// Dummy crash test dikenal pasti dan disusun berdasarkan id, sehingga dapat digunakan sebagai kunci dalam BTreeMap.
/// Pelaksanaan yang sengaja digunakan tidak bergantung pada apa-apa yang ditentukan dalam crate, selain dari `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Membuat reka bentuk dummy test crash.`id` menentukan ketertiban dan kesamaan keadaan.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Membuat contoh dummy test crash yang merekodkan peristiwa apa yang dialaminya dan pilihan panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Mengembalikan berapa kali kejadian dummy telah diklon.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Mengembalikan berapa kali kejadian dummy diturunkan.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Mengembalikan berapa kali kejadian dummy meminta anggota `query` mereka.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Sebilangan pertanyaan tanpa nama, hasilnya sudah diberikan.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}