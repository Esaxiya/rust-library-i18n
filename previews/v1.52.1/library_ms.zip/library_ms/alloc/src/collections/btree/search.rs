use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Ikatan inklusif untuk dicari, sama seperti `Bound::Included(T)`.
    Included(T),
    /// Ikatan eksklusif untuk dicari, sama seperti `Bound::Excluded(T)`.
    Excluded(T),
    /// Ikatan inklusif tanpa syarat, seperti `Bound::Unbounded`.
    AllIncluded,
    /// Had eksklusif tanpa syarat.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Mencari kunci yang diberikan dalam (sub) pokok yang diketuai oleh nod, secara berulang.
    /// Mengembalikan `Found` dengan pemegang KV yang sepadan, jika ada.
    /// Jika tidak, mengembalikan `GoDown` dengan pemegang daun edge di mana kuncinya berada.
    ///
    /// Hasilnya hanya bermakna jika pokok itu disusun mengikut kunci, seperti pokok dalam `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Menuju ke node terdekat di mana edge yang sepadan dengan batas bawah julat adalah berbeza dari edge yang sepadan dengan batas atas, iaitu, nod terdekat yang mempunyai sekurang-kurangnya satu kunci yang terdapat dalam julat.
    ///
    ///
    /// Sekiranya dijumpai, mengembalikan `Ok` dengan simpul tersebut, pasangan indeks edge di dalamnya membatasi julat, dan sepasang batasan yang sesuai untuk meneruskan pencarian di nod anak, sekiranya simpul itu bersifat dalaman.
    ///
    /// Sekiranya tidak dijumpai, kembalikan `Err` dengan daun edge sepadan dengan keseluruhan julat.
    ///
    /// Hasilnya hanya bermakna jika pokok itu disusun mengikut kunci.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Menyenaraikan pemboleh ubah ini harus dielakkan.
        // Kami menganggap had yang dilaporkan oleh `range` tetap sama, tetapi pelaksanaan lawan dapat berubah antara panggilan (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Mencari edge di nod yang membatasi had bawah julat.
    /// Juga mengembalikan batas bawah yang akan digunakan untuk meneruskan pencarian di simpul anak yang sesuai, jika `self` adalah nod dalaman.
    ///
    ///
    /// Hasilnya hanya bermakna jika pokok itu disusun mengikut kunci.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Klon `find_lower_bound_edge` untuk bahagian atas.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Mencari kunci yang diberikan dalam nod, tanpa berulang.
    /// Mengembalikan `Found` dengan pemegang KV yang sepadan, jika ada.
    /// Jika tidak, mengembalikan `GoDown` dengan pegangan edge di mana kunci mungkin dijumpai (jika simpul itu dalaman) atau di mana kunci boleh dimasukkan.
    ///
    ///
    /// Hasilnya hanya bermakna jika pokok itu disusun mengikut kunci, seperti pokok dalam `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Mengembalikan sama ada indeks KV di nod di mana kunci (atau setara) wujud, atau indeks edge di mana kunci berada.
    ///
    ///
    /// Hasilnya hanya bermakna jika pokok itu disusun mengikut kunci, seperti pokok dalam `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Mencari indeks edge di nod yang membatasi had bawah julat.
    /// Juga mengembalikan batas bawah yang akan digunakan untuk meneruskan pencarian di simpul anak yang sesuai, jika `self` adalah nod dalaman.
    ///
    ///
    /// Hasilnya hanya bermakna jika pokok itu disusun mengikut kunci.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Klon `find_lower_bound_index` untuk bahagian atas.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}