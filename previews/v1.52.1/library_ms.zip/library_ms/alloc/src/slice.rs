//! Pandangan bersaiz dinamik ke urutan bersebelahan, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Slice adalah pandangan ke dalam blok memori yang dilambangkan sebagai penunjuk dan panjang.
//!
//! ```
//! // memotong Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // memaksa susunan ke bahagian
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Potongan boleh ubah atau dikongsi.
//! Jenis irisan bersama adalah `&[T]`, sementara jenis irisan yang boleh berubah adalah `&mut [T]`, di mana `T` mewakili jenis elemen.
//! Sebagai contoh, anda boleh mengubah blok memori yang ditunjukkan oleh irisan yang boleh berubah:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Berikut adalah beberapa perkara yang mengandungi modul ini:
//!
//! ## Structs
//!
//! Terdapat beberapa struktur yang berguna untuk potongan, seperti [`Iter`], yang mewakili lelaran berbanding potongan.
//!
//! ## Pelaksanaan Trait
//!
//! Terdapat beberapa pelaksanaan traits biasa untuk potongan.Beberapa contoh merangkumi:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], untuk kepingan yang jenis elemennya adalah [`Eq`] atau [`Ord`].
//! * [`Hash`] - untuk kepingan yang jenis elemennya adalah [`Hash`].
//!
//! ## Iteration
//!
//! Potongan menggunakan `IntoIterator`.Iterator menghasilkan rujukan pada elemen irisan.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Potongan yang dapat diubah menghasilkan rujukan yang boleh berubah kepada elemen:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Iterator ini menghasilkan rujukan yang dapat berubah pada elemen slice, jadi sementara jenis elemen slice adalah `i32`, jenis elemen iterator adalah `&mut i32`.
//!
//!
//! * [`.iter`] dan [`.iter_mut`] adalah kaedah eksplisit untuk mengembalikan iterator lalai.
//! * Kaedah selanjutnya yang mengembalikan iterator adalah [`.split`], [`.splitn`], [`.chunks`], [`.windows`] dan banyak lagi.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Sebilangan besar penggunaan dalam modul ini hanya digunakan dalam konfigurasi ujian.
// Lebih mudah untuk mematikan amaran_import yang tidak digunakan daripada memperbaikinya.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Kaedah penyambungan slice asas
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) diperlukan untuk pelaksanaan makro `vec!` semasa menguji NB, lihat modul `hack` dalam fail ini untuk maklumat lebih lanjut.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) diperlukan untuk pelaksanaan `Vec::clone` semasa menguji NB, lihat modul `hack` dalam fail ini untuk maklumat lebih lanjut.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Dengan cfg(test) `impl [T]` tidak tersedia, ketiga fungsi ini sebenarnya adalah kaedah yang ada di `impl [T]` tetapi tidak di `core::slice::SliceExt`, kita perlu menyediakan fungsi-fungsi ini untuk ujian `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Kita tidak boleh menambahkan atribut sebaris untuk ini kerana ini digunakan dalam makro `vec!` kebanyakannya dan menyebabkan kemerosotan perf.
    // Lihat #71204 untuk hasil perbincangan dan keputusan.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // item ditandai diinisialisasi dalam gelung di bawah
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) adalah mustahak bagi LLVM untuk membuang pemeriksaan had dan mempunyai codegen yang lebih baik daripada zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec diperuntukkan dan dimulakan di atas sekurang-kurangnya sepanjang ini.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // diperuntukkan di atas dengan kapasiti `s`, dan memulakan ke `s.len()` di ptr::copy_to_non_overlapping di bawah.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Isih kepingan.
    ///
    /// Jenis ini stabil (iaitu, tidak menyusun semula elemen yang sama) dan *O*(*n*\*log(* n*)) terburuk.
    ///
    /// Apabila berlaku, penyortiran tidak stabil lebih disukai kerana pada umumnya lebih cepat daripada penyortiran stabil dan tidak memperuntukkan memori tambahan.
    /// Lihat [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Pelaksanaan semasa
    ///
    /// Algoritma semasa adalah jenis penggabungan berulang yang adaptif yang diilhamkan oleh [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Ia dirancang agar sangat cepat dalam keadaan di mana potongan hampir disusun, atau terdiri daripada dua atau lebih urutan yang disusun secara bersatu satu demi satu.
    ///
    ///
    /// Juga, ia memperuntukkan penyimpanan sementara separuh ukuran `self`, tetapi untuk potongan pendek, jenis penyisipan yang tidak diperuntukkan digunakan sebagai gantinya.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Susun bahagian dengan fungsi pembanding.
    ///
    /// Jenis ini stabil (iaitu, tidak menyusun semula elemen yang sama) dan *O*(*n*\*log(* n*)) terburuk.
    ///
    /// Fungsi pembanding mesti menentukan susunan total untuk elemen dalam slice.Sekiranya susunan tidak total, susunan elemen tidak ditentukan.
    /// Pesanan adalah jumlah pesanan sekiranya (untuk semua `a`, `b` dan `c`):
    ///
    /// * jumlah dan antisimetri: betul salah satu `a < b`, `a == b` atau `a > b` adalah benar, dan
    /// * transitif, `a < b` dan `b < c` menyiratkan `a < c`.Perkara yang sama mesti berlaku untuk `==` dan `>`.
    ///
    /// Sebagai contoh, sementara [`f64`] tidak menerapkan [`Ord`] kerana `NaN != NaN`, kita dapat menggunakan `partial_cmp` sebagai fungsi penguraian kita ketika kita mengetahui slice tidak mengandung `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Apabila berlaku, penyortiran tidak stabil lebih disukai kerana pada umumnya lebih cepat daripada penyortiran stabil dan tidak memperuntukkan memori tambahan.
    /// Lihat [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Pelaksanaan semasa
    ///
    /// Algoritma semasa adalah jenis penggabungan berulang yang adaptif yang diilhamkan oleh [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Ia dirancang agar sangat cepat dalam keadaan di mana potongan hampir disusun, atau terdiri daripada dua atau lebih urutan yang disusun secara bersatu satu demi satu.
    ///
    /// Juga, ia memperuntukkan penyimpanan sementara separuh ukuran `self`, tetapi untuk potongan pendek, jenis penyisipan yang tidak diperuntukkan digunakan sebagai gantinya.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // menyusun terbalik
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Susun bahagian dengan fungsi pengekstrakan kunci.
    ///
    /// Jenis ini stabil (iaitu, tidak menyusun semula elemen yang sama) dan *O*(*m*\* * n *\* log(*n*)) terburuk, di mana fungsi utama adalah *O*(*m*).
    ///
    /// Untuk fungsi utama yang mahal (mis
    /// fungsi yang bukan akses harta benda sederhana atau operasi asas), [`sort_by_cached_key`](slice::sort_by_cached_key) cenderung menjadi lebih cepat, kerana ia tidak mengira semula kunci elemen.
    ///
    ///
    /// Apabila berlaku, penyortiran tidak stabil lebih disukai kerana pada umumnya lebih cepat daripada penyortiran stabil dan tidak memperuntukkan memori tambahan.
    /// Lihat [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Pelaksanaan semasa
    ///
    /// Algoritma semasa adalah jenis penggabungan berulang yang adaptif yang diilhamkan oleh [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Ia dirancang agar sangat cepat dalam keadaan di mana potongan hampir disusun, atau terdiri daripada dua atau lebih urutan yang disusun secara bersatu satu demi satu.
    ///
    /// Juga, ia memperuntukkan penyimpanan sementara separuh ukuran `self`, tetapi untuk potongan pendek, jenis penyisipan yang tidak diperuntukkan digunakan sebagai gantinya.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Susun bahagian dengan fungsi pengekstrakan kunci.
    ///
    /// Semasa menyusun, fungsi utama dipanggil hanya sekali setiap elemen.
    ///
    /// Jenis ini stabil (iaitu, tidak menyusun semula elemen yang sama) dan *O*(*m*\* * n *+* n *\* log(*n*)) terburuk, di mana fungsi utama adalah *O*(*m*) .
    ///
    /// Untuk fungsi kunci sederhana (contohnya, fungsi yang merupakan akses harta benda atau operasi asas), [`sort_by_key`](slice::sort_by_key) cenderung lebih pantas.
    ///
    /// # Pelaksanaan semasa
    ///
    /// Algoritma semasa didasarkan pada [pattern-defeating quicksort][pdqsort] oleh Orson Peters, yang menggabungkan kes cepat cepat rawak cepat dengan kes heaport terburuk yang paling cepat, sambil mencapai masa linier pada potongan dengan corak tertentu.
    /// Ia menggunakan beberapa pengacakan untuk mengelakkan kes merosot, tetapi dengan seed tetap untuk selalu memberikan tingkah laku deterministik.
    ///
    /// Dalam keadaan terburuk, algoritma memperuntukkan penyimpanan sementara dalam `Vec<(K, usize)>` sepanjang kepingan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Pembantu makro untuk mengindeks vector kami dengan jenis sekecil mungkin, untuk mengurangkan peruntukan.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Unsur `indices` unik, kerana diindeks, jadi apa-apa jenis akan stabil sehubungan dengan kepingan asalnya.
                // Kami menggunakan `sort_unstable` di sini kerana ia memerlukan peruntukan memori yang lebih sedikit.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Menyalin `self` ke `Vec` baru.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Di sini, `s` dan `x` boleh diubah suai secara bebas.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Menyalin `self` ke `Vec` baru dengan peruntukan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Di sini, `s` dan `x` boleh diubah suai secara bebas.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, lihat modul `hack` dalam fail ini untuk maklumat lebih lanjut.
        hack::to_vec(self, alloc)
    }

    /// Menukar `self` menjadi vector tanpa klon atau peruntukan.
    ///
    /// vector yang dihasilkan dapat ditukarkan kembali ke dalam kotak melalui `Vec<T>kaedah `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` tidak dapat digunakan lagi kerana telah ditukar menjadi `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, lihat modul `hack` dalam fail ini untuk maklumat lebih lanjut.
        hack::into_vec(self)
    }

    /// Membuat vector dengan mengulang potongan `n` kali.
    ///
    /// # Panics
    ///
    /// Fungsi ini akan panic jika kapasiti akan meluap.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic semasa limpahan:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Sekiranya `n` lebih besar daripada sifar, ia boleh dibahagi sebagai `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` adalah nombor yang ditunjukkan oleh bit '1' paling kiri `n`, dan `rem` adalah bahagian `n` yang tinggal.
        //
        //

        // Menggunakan `Vec` untuk mengakses `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` pengulangan dilakukan dengan menggandakan `buf` `expn`-kali.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Sekiranya `m > 0`, masih ada bits hingga '1' paling kiri.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` mempunyai kapasiti `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` Pengulangan (`=n, 2 ^ expn`) dilakukan dengan menyalin pengulangan `rem` pertama dari `buf` itu sendiri.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Ini tidak bertindih sejak `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` sama dengan `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Meratakan kepingan `T` menjadi nilai tunggal `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Meratakan potongan `T` menjadi nilai tunggal `Self::Output`, meletakkan pemisah yang diberikan di antara masing-masing.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Meratakan potongan `T` menjadi nilai tunggal `Self::Output`, meletakkan pemisah yang diberikan di antara masing-masing.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Mengembalikan vector yang mengandungi salinan potongan ini di mana setiap bait dipetakan ke setara huruf besar ASCII.
    ///
    ///
    /// Huruf ASCII 'a' hingga 'z' dipetakan ke 'A' hingga 'Z', tetapi huruf bukan ASCII tidak berubah.
    ///
    /// Untuk huruf besar nilai di tempat, gunakan [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Mengembalikan vector yang mengandungi salinan potongan ini di mana setiap bait dipetakan ke setara huruf kecil ASCII.
    ///
    ///
    /// Huruf ASCII 'A' hingga 'Z' dipetakan ke 'a' hingga 'z', tetapi huruf bukan ASCII tidak berubah.
    ///
    /// Untuk mengecilkan nilai di tempat, gunakan [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sambungan traits untuk kepingan melebihi jenis data tertentu
////////////////////////////////////////////////////////////////////////////////

/// Helper trait untuk [`[T]: : concat`](slice::concat).
///
/// Note: parameter jenis `Item` tidak digunakan dalam trait ini, tetapi ia membolehkan implikasinya menjadi lebih generik.
/// Tanpa itu, kami mendapat ralat ini:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Ini kerana mungkin ada jenis `V` dengan beberapa implan `Borrow<[_]>`, sehingga beberapa jenis `T` akan berlaku:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Jenis yang dihasilkan selepas penggabungan
    type Output;

    /// Pelaksanaan [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait untuk [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Jenis yang dihasilkan selepas penggabungan
    type Output;

    /// Pelaksanaan [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Pelaksanaan trait standard untuk slice
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // jatuhkan apa-apa sasaran yang tidak akan ditimpa
        target.truncate(self.len());

        // target.len <= self.len kerana pemotongan di atas, jadi potongan di sini selalu tidak terhad.
        //
        let (init, tail) = self.split_at(target.len());

        // gunakan semula nilai yang terkandung allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Memasukkan `v[0]` ke dalam urutan pra-disusun `v[1..]` sehingga keseluruhan `v[..]` menjadi disusun.
///
/// Ini adalah subrutin terpadu jenis penyisipan.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Terdapat tiga cara untuk melaksanakan penyisipan di sini:
            //
            // 1. Tukar elemen bersebelahan sehingga yang pertama sampai ke tujuan akhir.
            //    Namun, dengan cara ini kita menyalin data lebih dari yang diperlukan.
            //    Sekiranya elemen adalah struktur besar (mahal untuk disalin), kaedah ini akan perlahan.
            //
            // 2. Berulang sehingga tempat yang tepat untuk elemen pertama dijumpai.
            // Kemudian alihkan elemen-elemen yang menggantikannya untuk memberi ruang kepadanya dan akhirnya letakkan ke lubang yang tinggal.
            // Ini adalah kaedah yang baik.
            //
            // 3. Salin elemen pertama ke pemboleh ubah sementara.Turunkan sehingga tempat yang sesuai dijumpai.
            // Semasa kami meneruskan, salin setiap elemen yang dilalui ke dalam slot yang mendahuluinya.
            // Akhirnya, salin data dari pemboleh ubah sementara ke lubang yang tinggal.
            // Kaedah ini sangat bagus.
            // Penanda aras menunjukkan prestasi yang sedikit lebih baik daripada dengan kaedah ke-2.
            //
            // Semua kaedah ditanda aras, dan yang ketiga menunjukkan hasil terbaik.Oleh itu, kami memilih yang satu.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Keadaan pertengahan proses penyisipan selalu dijejaki oleh `hole`, yang melayani dua tujuan:
            // 1. Melindungi integriti `v` dari panics di `is_less`.
            // 2. Isi baki lubang `v` pada akhirnya.
            //
            // Keselamatan Panic:
            //
            // Sekiranya `is_less` panics pada satu ketika semasa proses, `hole` akan jatuh dan mengisi lubang di `v` dengan `tmp`, sehingga memastikan bahawa `v` masih memegang setiap objek yang pada awalnya dipegangnya tepat sekali.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` jatuh dan dengan itu menyalin `tmp` ke dalam lubang yang tinggal di `v`.
        }
    }

    // Apabila dijatuhkan, salinan dari `src` ke `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Penggabungan tanpa penurunan berjalan `v[..mid]` dan `v[mid..]` menggunakan `buf` sebagai penyimpanan sementara, dan menyimpan hasilnya menjadi `v[..]`.
///
/// # Safety
///
/// Kedua-dua keping mestilah tidak kosong dan `mid` mesti bersempadan.
/// Buffer `buf` mestilah cukup panjang untuk menyimpan salinan potongan yang lebih pendek.
/// Juga, `T` mestilah bukan jenis berukuran sifar.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Proses penggabungan pertama kali menyalin jangka pendek menjadi `buf`.
    // Kemudian ia mengesan larian yang baru disalin dan jangka masa yang lebih panjang ke depan (atau ke belakang), membandingkan unsur-unsur mereka yang tidak digunakan seterusnya dan menyalin yang lebih rendah (atau lebih besar) ke `v`.
    //
    // Sebaik sahaja jangka pendek habis digunakan, prosesnya selesai.Sekiranya jangka masa panjang habis digunakan, maka kita mesti menyalin apa sahaja yang tersisa dari jangka pendek ke lubang yang tersisa di `v`.
    //
    // Keadaan pertengahan proses selalu dijejaki oleh `hole`, yang melayani dua tujuan:
    // 1. Melindungi integriti `v` dari panics di `is_less`.
    // 2. Isi baki lubang di `v` jika jangka masa panjang habis digunakan terlebih dahulu.
    //
    // Keselamatan Panic:
    //
    // Sekiranya `is_less` panics pada bila-bila masa semasa proses, `hole` akan jatuh dan mengisi lubang di `v` dengan julat yang tidak habis digunakan di `buf`, sehingga memastikan `v` masih memegang setiap objek yang pada awalnya dipegangnya tepat sekali.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Larian kiri lebih pendek.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Pada mulanya, petunjuk ini menunjukkan permulaan susunan mereka.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Ambil bahagian yang kurang.
            // Sekiranya sama, pilih larian kiri untuk mengekalkan kestabilan.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Larian yang betul lebih pendek.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Pada mulanya, petunjuk ini melepasi hujung susunan mereka.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Ambil bahagian yang lebih besar.
            // Sekiranya sama, pilih jalan yang betul untuk mengekalkan kestabilan.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Akhirnya, `hole` jatuh.
    // Sekiranya larian yang lebih pendek tidak habis digunakan, apa sahaja yang tinggal sekarang akan disalin ke dalam lubang di `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Apabila dijatuhkan, salin julat `start..end` ke `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` bukan jenis berukuran sifar, jadi boleh dibahagi dengan ukurannya.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Penggabungan ini meminjam beberapa (tetapi tidak semua) idea dari TimSort, yang dijelaskan secara terperinci [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algoritma mengenal pasti susunan turun dan tidak menurun dengan tegas, yang disebut larian semula jadi.Terdapat timbunan yang belum selesai digabungkan.
/// Setiap larian yang baru dijumpai ditolak ke tumpukan, dan kemudian beberapa pasang larian bersebelahan digabungkan sehingga kedua invarian ini berpuas hati:
///
/// 1. untuk setiap `i` di `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. untuk setiap `i` di `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Invarian memastikan bahawa jumlah masa berjalan adalah *O*(*n*\*log(* n*)) terburuk.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Potongan hingga panjang ini disusun menggunakan penyisipan.
    const MAX_INSERTION: usize = 20;
    // Larian yang sangat pendek dilanjutkan menggunakan penyisipan untuk merangkumi sekurang-kurangnya banyak elemen ini.
    const MIN_RUN: usize = 10;

    // Menyusun tidak mempunyai tingkah laku yang bermakna pada jenis bersaiz sifar.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Susunan pendek disusun di tempat melalui penyisipan untuk mengelakkan peruntukan.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Peruntukkan penyangga untuk digunakan sebagai memori awal.Kami menyimpan panjang 0 sehingga kami dapat menyimpan salinan cetek kandungan `v` tanpa mempertaruhkan dtor yang terdapat pada salinan jika `is_less` panics.
    //
    // Semasa menggabungkan dua larian yang disusun, penyangga ini menyimpan salinan larian yang lebih pendek, yang akan panjangnya paling banyak `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Untuk mengenal pasti larian semula jadi di `v`, kami melintasi ke belakang.
    // Itu mungkin merupakan keputusan yang pelik, tetapi pertimbangkan fakta bahawa penggabungan lebih kerap berlaku ke arah yang berlawanan (forwards).
    // Menurut tanda aras, penggabungan ke hadapan sedikit lebih cepat daripada penggabungan ke belakang.
    // Sebagai kesimpulan, mengenal pasti larian dengan melintasi ke belakang akan meningkatkan prestasi.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Cari larian semula jadi seterusnya, dan terbalik jika ia betul-betul turun.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Masukkan beberapa elemen lagi dalam jangka masa jika terlalu pendek.
        // Jenis penyisipan lebih cepat daripada penggabungan urutan pada urutan pendek, jadi ini meningkatkan prestasi dengan ketara.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Tolak larian ini ke timbunan.
        runs.push(Run { start, len: end - start });
        end = start;

        // Gabungkan beberapa pasang larian bersebelahan untuk memuaskan invarian.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Akhirnya, tepat satu larian mesti kekal di timbunan.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Meneliti timbunan larian dan mengenal pasti pasangan larian seterusnya untuk bergabung.
    // Lebih khusus lagi, jika `Some(r)` dikembalikan, itu bermaksud `runs[r]` dan `runs[r + 1]` mesti digabungkan seterusnya.
    // Sekiranya algoritma terus membina jangka baru, `None` akan dikembalikan.
    //
    // TimSort terkenal dengan implementasi kereta, seperti yang dijelaskan di sini:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Inti ceritanya adalah: kita mesti menerapkan invarian pada empat larian teratas di timbunan.
    // Memaksakan mereka hanya di tiga teratas tidak mencukupi untuk memastikan bahawa invarian akan tetap bertahan untuk *semua* berjalan di timbunan.
    //
    // Fungsi ini memeriksa invarian dengan betul untuk empat larian teratas.
    // Selain itu, jika larian teratas bermula pada indeks 0, ia akan selalu menuntut operasi penggabungan sehingga timbunannya runtuh sepenuhnya, untuk menyelesaikan penguraian.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}