//! Utiliti untuk memformat dan mencetak `String`s.
//!
//! Modul ini mengandungi sokongan jangka masa untuk peluasan sintaks [`format!`].
//! Makro ini dilaksanakan dalam penyusun untuk mengeluarkan panggilan ke modul ini untuk memformat argumen pada waktu runtime menjadi rentetan.
//!
//! # Usage
//!
//! Makro [`format!`] dimaksudkan untuk tidak asing lagi bagi mereka yang berasal dari fungsi `printf`/`fprintf` C atau fungsi `str.format` Python.
//!
//! Beberapa contoh peluasan [`format!`] adalah:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" dengan sifar terkemuka
//! ```
//!
//! Dari ini, anda dapat melihat bahawa argumen pertama adalah rentetan format.Ia diperlukan oleh penyusun agar ini menjadi rentetan literal;tidak boleh menjadi pemboleh ubah yang dilewatkan (untuk melakukan pemeriksaan kesahan).
//! Penyusun kemudian akan menguraikan rentetan format dan menentukan apakah senarai argumen yang disediakan sesuai untuk diteruskan ke rentetan format ini.
//!
//! Untuk menukar satu nilai menjadi rentetan, gunakan kaedah [`to_string`].Ini akan menggunakan format [`Display`] trait.
//!
//! ## Parameter kedudukan
//!
//! Setiap argumen pemformatan dibenarkan untuk menentukan argumen nilai mana yang menjadi rujukannya, dan jika dihilangkan dianggap "the next argument".
//! Sebagai contoh, rentetan format `{} {} {}` akan mengambil tiga parameter, dan formatnya akan mengikut urutan yang sama seperti yang diberikan.
//! String format `{2} {1} {0}`, bagaimanapun, akan memformat argumen dalam urutan terbalik.
//!
//! Perkara boleh menjadi sedikit rumit apabila anda mula mencampurkan dua jenis penentu kedudukan.Penentu "next argument" boleh dianggap sebagai iterator atas hujah.
//! Setiap kali penentu "next argument" dilihat, iterator maju.Ini membawa kepada tingkah laku seperti ini:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iterator dalaman untuk argumen belum dimajukan pada saat `{}` pertama dilihat, jadi ia mencetak argumen pertama.Kemudian setelah mencapai `{}` kedua, iterator telah maju ke argumen kedua.
//! Pada asasnya, parameter yang secara jelas menamakan argumen mereka tidak mempengaruhi parameter yang tidak menamakan argumen dari segi penentu kedudukan.
//!
//! String format diperlukan untuk menggunakan semua argumennya, jika tidak, ini adalah kesilapan waktu kompilasi.Anda boleh merujuk kepada argumen yang sama lebih dari sekali dalam rentetan format.
//!
//! ## Parameter dinamakan
//!
//! Rust sendiri tidak mempunyai parameter yang serupa dengan Python untuk fungsi, tetapi makro [`format!`] adalah lanjutan sintaks yang memungkinkannya memanfaatkan parameter bernama.
//! Parameter dinamakan disenaraikan di akhir senarai argumen dan mempunyai sintaks:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Sebagai contoh, ungkapan [`format!`] berikut semua menggunakan argumen bernama:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Tidak betul meletakkan parameter kedudukan (yang tanpa nama) selepas argumen yang mempunyai nama.Seperti parameter kedudukan, tidak sah untuk memberikan parameter bernama yang tidak digunakan oleh rentetan format.
//!
//! # Memformat Parameter
//!
//! Setiap argumen yang diformat dapat diubah oleh sejumlah parameter pemformatan (sesuai dengan `format_spec` di [the syntax](#syntax)). Parameter ini mempengaruhi representasi rentetan dari apa yang sedang diformat.
//!
//! ## Width
//!
//! ```
//! // Semua cetakan "Hello x !" ini
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ini adalah parameter untuk "minimum width" yang seharusnya diambil formatnya.
//! Sekiranya rentetan nilai tidak mengisi sebilangan besar aksara ini, maka padding yang ditentukan oleh fill/alignment akan digunakan untuk mengambil ruang yang diperlukan (lihat di bawah).
//!
//! Nilai untuk lebar juga dapat diberikan sebagai [`usize`] dalam daftar parameter dengan menambahkan postfix `$`, yang menunjukkan bahawa argumen kedua adalah [`usize`] yang menentukan lebarnya.
//!
//! Merujuk kepada argumen dengan sintaks dolar tidak mempengaruhi pembilang "next argument", jadi biasanya idea yang baik adalah merujuk kepada argumen berdasarkan kedudukan, atau menggunakan argumen bernama.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Karakter dan penjajaran pengisian pilihan disediakan secara normal bersamaan dengan parameter [`width`](#width).Ia mesti ditentukan sebelum `width`, tepat selepas `:`.
//! Ini menunjukkan bahawa jika nilai yang diformat lebih kecil daripada `width`, beberapa watak tambahan akan dicetak di sekitarnya.
//! Pengisian terdapat dalam varian berikut untuk penjajaran yang berbeza:
//!
//! * `[fill]<` - argumen diselaraskan kiri dalam lajur `width`
//! * `[fill]^` - argumen itu sejajar tengah pada lajur `width`
//! * `[fill]>` - argumen diselaraskan tepat pada lajur `width`
//!
//! [fill/alignment](#fillalignment) lalai untuk bukan angka adalah ruang dan penjajaran kiri.Lalai untuk pemformat numerik juga watak ruang tetapi dengan penjajaran kanan.
//! Sekiranya bendera `0` (lihat di bawah) ditentukan untuk angka, maka watak isian tersirat adalah `0`.
//!
//! Perhatikan bahawa penjajaran mungkin tidak dilaksanakan oleh beberapa jenis.Secara khusus, ia tidak dilaksanakan secara amnya untuk `Debug` trait.
//! Cara yang baik untuk memastikan padding diterapkan adalah dengan memformat input anda, kemudian pad string yang dihasilkan ini untuk mendapatkan output anda:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Helo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Ini semua bendera yang mengubah tingkah laku pembuat format.
//!
//! * `+` - Ini ditujukan untuk jenis angka dan menunjukkan bahawa tanda mesti dicetak.Tanda positif tidak pernah dicetak secara lalai, dan tanda negatif hanya dicetak secara lalai untuk `Signed` trait.
//! Bendera ini menunjukkan bahawa tanda yang betul (`+` atau `-`) harus selalu dicetak.
//! * `-` - Pada masa ini tidak digunakan
//! * `#` - Bendera ini menunjukkan bahawa bentuk pencetakan "alternate" harus digunakan.Bentuk gantian adalah:
//!     * `#?` - cantikkan format [`Debug`]
//!     * `#x` - mendahului hujah dengan `0x`
//!     * `#X` - mendahului hujah dengan `0x`
//!     * `#b` - mendahului hujah dengan `0b`
//!     * `#o` - mendahului hujah dengan `0o`
//! * `0` - Ini digunakan untuk menunjukkan untuk format bilangan bulat bahawa padding ke `width` harus dilakukan dengan karakter `0` dan juga sedar.
//! Format seperti `{:08}` akan menghasilkan `00000001` untuk bilangan bulat `1`, sementara format yang sama akan menghasilkan `-0000001` untuk bilangan bulat `-1`.
//! Perhatikan bahawa versi negatif mempunyai satu sifar yang lebih sedikit daripada versi positif.
//!         Perhatikan bahawa sifar padding selalu diletakkan selepas tanda (jika ada) dan sebelum angka.Apabila digunakan bersama dengan bendera `#`, peraturan serupa berlaku: sifar padding dimasukkan setelah awalan tetapi sebelum angka.
//!         Awalan dimasukkan dalam lebar keseluruhan.
//!
//! ## Precision
//!
//! Untuk jenis bukan angka, ini boleh dianggap "maximum width".
//! Sekiranya rentetan yang dihasilkan lebih panjang daripada lebar ini, maka terpotong menjadi banyak watak ini dan nilai terpotong itu dipancarkan dengan `fill`, `alignment` dan `width` yang tepat jika parameter tersebut ditetapkan.
//!
//! Untuk jenis kamiran, ini tidak diambil kira.
//!
//! Untuk jenis titik terapung, ini menunjukkan berapa digit selepas titik perpuluhan yang harus dicetak.
//!
//! Terdapat tiga cara yang mungkin untuk menentukan `precision` yang diinginkan:
//!
//! 1. `.N` integer:
//!
//!    integer `N` itu sendiri adalah ketepatan.
//!
//! 2. Bilangan bulat atau nama diikuti dengan tanda dolar `.N$`:
//!
//!    gunakan format *argumen*`N` (yang mestilah `usize`) sebagai ketepatan.
//!
//! 3. Asterisk `.*`:
//!
//!    `.*` bermaksud bahawa `{...}` ini dikaitkan dengan input format *dua* daripada satu: input pertama memegang ketepatan `usize`, dan yang kedua menyimpan nilai untuk dicetak.
//!    Perhatikan bahawa dalam kes ini, jika seseorang menggunakan string format `{<arg>:<spec>.*}`, maka bahagian `<arg>` merujuk pada* nilai * untuk dicetak, dan `precision` mesti masuk dalam input sebelum `<arg>`.
//!
//! Sebagai contoh, panggilan berikut semua mencetak `Hello x is 0.01000` yang sama:
//!
//! ```
//! // Hello {arg 0 ("x")} ialah {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hello {arg 1 ("x")} ialah {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hello {arg 0 ("x")} ialah {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} ialah {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} ialah {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} ialah {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Walaupun ini:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! mencetak tiga perkara yang berbeza:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Dalam beberapa bahasa pengaturcaraan, tingkah laku fungsi pemformatan rentetan bergantung pada pengaturan lokal sistem operasi.
//! Fungsi format yang disediakan oleh pustaka standard Rust tidak mempunyai konsep lokal dan akan menghasilkan hasil yang sama pada semua sistem tanpa mengira konfigurasi pengguna.
//!
//! Sebagai contoh, kod berikut akan selalu mencetak `1.5` walaupun lokasi sistem menggunakan pemisah perpuluhan selain titik.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Aksara literal `{` dan `}` mungkin dimasukkan dalam rentetan dengan mendahului mereka dengan watak yang sama.Contohnya, watak `{` dilarikan dengan `{{` dan watak `}` dilarikan dengan `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Untuk meringkaskan, di sini anda boleh menemui tatabahasa lengkap rentetan format.
//! Sintaks untuk bahasa pemformatan yang digunakan diambil dari bahasa lain, jadi seharusnya tidak terlalu asing.Hujah diformat dengan sintaks seperti Python, yang bermaksud bahawa argumen dikelilingi oleh `{}` dan bukannya `%` seperti C.
//! Tatabahasa sebenar untuk sintaks format adalah:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Dalam tatabahasa di atas, `text` mungkin tidak mengandungi aksara `'{'` atau `'}'`.
//!
//! # Memformat traits
//!
//! Semasa meminta agar argumen diformat dengan jenis tertentu, anda sebenarnya meminta argumen tersebut untuk trait tertentu.
//! Ini membolehkan pelbagai jenis sebenar diformat melalui `{:x}` (seperti [`i8`] dan juga [`isize`]).Pemetaan jenis sekarang ke traits adalah:
//!
//! * *tiada apa-apa* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] dengan bilangan bulat heksadesimal huruf kecil
//! * `X?` ⇒ [`Debug`] dengan bilangan bulat heksadesimal huruf besar
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Apa maksudnya adalah bahawa semua jenis argumen yang menerapkan [`fmt::Binary`][`Binary`] trait kemudian dapat diformat dengan `{:b}`.Pelaksanaan disediakan untuk traits ini untuk sebilangan jenis primitif oleh pustaka standard juga.
//!
//! Sekiranya tidak ada format yang ditentukan (seperti dalam `{}` atau `{:6}`), maka format trait yang digunakan adalah [`Display`] trait.
//!
//! Semasa melaksanakan format trait untuk jenis anda sendiri, anda perlu melaksanakan kaedah tandatangan:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // jenis tersuai kami
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Jenis anda akan diteruskan sebagai rujukan `self`, dan kemudian fungsi tersebut akan mengeluarkan output ke aliran `f.buf`.Terpulang pada setiap format implementasi trait untuk mematuhi parameter pemformatan yang diminta dengan betul.
//! Nilai parameter ini akan disenaraikan dalam bidang struktur [`Formatter`].Untuk membantu ini, struktur [`Formatter`] juga menyediakan beberapa kaedah penolong.
//!
//! Selain itu, nilai pengembalian fungsi ini adalah [`fmt::Result`] yang merupakan alias jenis [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Pelaksanaan pemformatan harus memastikan bahawa mereka menyebarkan kesalahan dari [`Formatter`] (misalnya, ketika memanggil [`write!`]).
//! Namun, mereka tidak boleh mengembalikan kesalahan secara tidak sengaja.
//! Maksudnya, pelaksanaan pemformatan mesti dan hanya dapat mengembalikan kesalahan jika [`Formatter`] yang disahkan mengembalikan kesalahan.
//! Ini kerana, bertentangan dengan apa yang mungkin disarankan oleh tandatangan fungsi, pemformatan tali adalah operasi yang tidak sempurna.
//! Fungsi ini hanya mengembalikan hasil kerana menulis ke aliran yang mendasari mungkin gagal dan mesti menyediakan cara untuk menyebarkan fakta bahawa ralat telah berlaku di atas timbunan.
//!
//! Contoh pelaksanaan pemformatan traits akan kelihatan seperti:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Nilai `f` menerapkan `Write` trait, itulah yang ditulis!makro menjangkakan.
//!         // Perhatikan bahawa pemformatan ini mengabaikan pelbagai bendera yang disediakan untuk rentetan format.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits yang berbeza membenarkan pelbagai bentuk output dari jenis.
//! // Makna format ini adalah untuk mencetak besarnya vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Hormati bendera pemformatan dengan menggunakan kaedah helper `pad_integral` pada objek Formatter.
//!         // Lihat dokumentasi kaedah untuk perincian, dan fungsi `pad` dapat digunakan untuk memasukkan tali.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Kedua format traits ini mempunyai tujuan yang berbeza:
//!
//! - [`fmt::Display`][`Display`] pelaksanaan menegaskan bahawa jenis itu dapat diwakili dengan setia sebagai rentetan UTF-8 setiap masa.**Tidak** dijangka semua jenis menerapkan [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] pelaksanaan harus dilaksanakan untuk **semua** jenis awam.
//!   Output biasanya akan mewakili keadaan dalaman setepat mungkin.
//!   Tujuan [`Debug`] trait adalah untuk memudahkan penyahpepijatan kod Rust.Dalam kebanyakan kes, penggunaan `#[derive(Debug)]` adalah mencukupi dan disyorkan.
//!
//! Beberapa contoh output dari kedua traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Makro berkaitan
//!
//! Terdapat sebilangan makro yang berkaitan dalam keluarga [`format!`].Yang sedang dilaksanakan ialah:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ini dan [`writeln!`] adalah dua makro yang digunakan untuk mengeluarkan rentetan format ke aliran yang ditentukan.Ini digunakan untuk mengelakkan peruntukan rentetan format antara dan menulis secara langsung outputnya.
//! Di bawah tudung, fungsi ini sebenarnya memanggil fungsi [`write_fmt`] yang ditentukan pada [`std::io::Write`] trait.
//! Contoh penggunaan adalah:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Ini dan [`println!`] mengeluarkan output mereka ke stdout.Sama seperti makro [`write!`], tujuan makro ini adalah untuk mengelakkan peruntukan pertengahan ketika mencetak output.Contoh penggunaan adalah:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makro [`eprint!`] dan [`eprintln!`] sama dengan [`print!`] dan [`println!`], masing-masing, kecuali mereka mengeluarkan outputnya ke stderr.
//!
//! ### `format_args!`
//!
//! Ini adalah makro ingin tahu yang digunakan untuk menyebarkan objek legap dengan selamat menerangkan rentetan format.Objek ini tidak memerlukan peruntukan timbunan untuk dibuat, dan hanya merujuk maklumat pada timbunan.
//! Di bawahnya, semua makro yang berkaitan dilaksanakan dalam hal ini.
//! Pertama, beberapa contoh penggunaan adalah:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Hasil makro [`format_args!`] adalah nilai jenis [`fmt::Arguments`].
//! Struktur ini kemudian dapat diteruskan ke fungsi [`write`] dan [`format`] di dalam modul ini untuk memproses string format.
//! Matlamat makro ini adalah untuk lebih jauh mencegah peruntukan pertengahan ketika berurusan dengan rentetan pemformatan.
//!
//! Sebagai contoh, perpustakaan pembalakan boleh menggunakan sintaks pemformatan standard, tetapi secara dalaman akan menyebarkan struktur ini sehingga ia ditentukan di mana output harus pergi.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Fungsi `format` mengambil struktur [`Arguments`] dan mengembalikan rentetan berformat yang dihasilkan.
///
///
/// Contoh [`Arguments`] dapat dibuat dengan makro [`format_args!`].
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Harap maklum bahawa penggunaan [`format!`] mungkin lebih disukai.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}