#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Kandungan memori baru tidak dimulakan.
    Uninitialized,
    /// Memori baru dijamin sifar.
    Zeroed,
}

/// Utiliti tahap rendah untuk pengalokasian, pengalokasian semula, dan penyahpindahan memori yang lebih ergonomik di timbunan tanpa perlu risau tentang semua kes sudut yang terlibat.
///
/// Jenis ini sangat baik untuk membina struktur data anda sendiri seperti Vec dan VecDeque.
/// Khususnya:
///
/// * Menghasilkan `Unique::dangling()` pada jenis bersaiz sifar.
/// * Menghasilkan `Unique::dangling()` pada peruntukan panjang sifar.
/// * Elakkan membebaskan `Unique::dangling()`.
/// * Menangkap semua limpahan dalam pengiraan kapasiti (mempromosikannya ke "capacity overflow" panics).
/// * Menjaga sistem 32-bit yang memperuntukkan lebih daripada isize::MAX bait.
/// * Menjaga agar tidak meluap panjang.
/// * Memanggil `handle_alloc_error` untuk peruntukan yang salah.
/// * Mengandungi `ptr::Unique` dan dengan itu memberi pengguna semua faedah yang berkaitan.
/// * Menggunakan lebihan yang dikembalikan dari peruntukan untuk menggunakan kapasiti terbesar yang ada.
///
/// Jenis ini sama sekali tidak memeriksa memori yang dikendalikannya.Apabila dijatuhkan,*akan* membebaskan ingatannya, tetapi *tidak* akan mencuba untuk menjatuhkan kandungannya.
/// Terserah kepada pengguna `RawVec` untuk menangani perkara sebenar *yang tersimpan* di dalam `RawVec`.
///
/// Perhatikan bahawa kelebihan jenis berukuran sifar selalu tidak terbatas, jadi `capacity()` selalu mengembalikan `usize::MAX`.
/// Ini bermaksud bahawa anda perlu berhati-hati ketika melakukan perjalanan balik jenis ini dengan `Box<[T]>`, kerana `capacity()` tidak akan menghasilkan panjang.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Ini wujud kerana `#[unstable]` `const fn`s tidak sesuai dengan `min_const_fn` dan oleh itu ia juga tidak boleh dipanggil dalam`min_const_fn`s.
    ///
    /// Sekiranya anda menukar `RawVec<T>::new` atau dependensi, berhati-hatilah untuk tidak memperkenalkan sesuatu yang benar-benar melanggar `min_const_fn`.
    ///
    /// NOTE: Kami dapat mengelakkan peretasan ini dan memeriksa kesesuaian dengan beberapa atribut `#[rustc_force_min_const_fn]` yang memerlukan kesesuaian dengan `min_const_fn` tetapi tidak semestinya membenarkan memanggilnya dalam kod `stable(...) const fn`/pengguna yang tidak membolehkan `foo` ketika `#[rustc_const_unstable(feature = "foo", issue = "01234")]` hadir.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Membuat `RawVec` terbesar (di timbunan sistem) tanpa memperuntukkan.
    /// Sekiranya `T` mempunyai ukuran positif, maka ini menjadikan `RawVec` dengan kapasiti `0`.
    /// Sekiranya `T` bersaiz sifar, maka ia menjadikan `RawVec` dengan kapasiti `usize::MAX`.
    /// Berguna untuk melaksanakan peruntukan tertunda.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Membuat `RawVec` (pada timbunan sistem) dengan keperluan kapasiti dan penjajaran yang tepat untuk `[T; capacity]`.
    /// Ini sama dengan memanggil `RawVec::new` apabila `capacity` adalah `0` atau `T` berukuran sifar.
    /// Perhatikan bahawa jika `T` berukuran sifar ini bermakna anda *tidak* akan mendapat `RawVec` dengan kapasiti yang diminta.
    ///
    /// # Panics
    ///
    /// Panics jika kapasiti yang diminta melebihi `isize::MAX` bait.
    ///
    /// # Aborts
    ///
    /// Berkurang di OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Seperti `with_capacity`, tetapi menjamin penyangga disifatkan.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Membentuk semula `RawVec` dari penunjuk dan kapasiti.
    ///
    /// # Safety
    ///
    /// `ptr` mesti diperuntukkan (pada timbunan sistem), dan dengan `capacity` yang diberikan.
    /// `capacity` tidak boleh melebihi `isize::MAX` untuk jenis bersaiz.(hanya perhatian pada sistem 32-bit).
    /// ZST vectors mungkin mempunyai kapasiti hingga `usize::MAX`.
    /// Sekiranya `ptr` dan `capacity` berasal dari `RawVec`, maka ini dijamin.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecs kecil bodoh.Langkau ke:
    // - 8 jika ukuran elemen adalah 1, kerana mana-mana pembahagi timbunan cenderung mengumpulkan permintaan kurang dari 8 bait hingga sekurang-kurangnya 8 bait.
    //
    // - 4 jika elemen bersaiz sederhana (<=1 KiB).
    // - Jika tidak, untuk mengelakkan membuang terlalu banyak ruang untuk Vec yang sangat pendek.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Seperti `new`, tetapi berdasarkan parameter pilihan bagi `RawVec` yang dikembalikan.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` bermaksud "unallocated".jenis bersaiz sifar tidak diambil kira.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Seperti `with_capacity`, tetapi berdasarkan parameter pilihan bagi `RawVec` yang dikembalikan.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Seperti `with_capacity_zeroed`, tetapi berdasarkan parameter pilihan bagi `RawVec` yang dikembalikan.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Menukar `Box<[T]>` menjadi `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Menukar keseluruhan penyangga menjadi `Box<[MaybeUninit<T>]>` dengan `len` yang ditentukan.
    ///
    /// Perhatikan bahawa ini akan menyusun semula perubahan `cap` yang mungkin telah dilakukan.(Lihat keterangan jenis untuk perincian.)
    ///
    /// # Safety
    ///
    /// * `len` mestilah lebih besar daripada atau sama dengan kapasiti yang paling baru diminta, dan
    /// * `len` mestilah kurang daripada atau sama dengan `self.capacity()`.
    ///
    /// Perhatikan, bahawa kapasiti yang diminta dan `self.capacity()` mungkin berbeza, kerana peruntukan dapat secara keseluruhan mengalokasikan dan mengembalikan blok memori yang lebih besar daripada yang diminta.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Periksa kewarasan satu setengah dari syarat keselamatan (kita tidak dapat memeriksa separuh yang lain).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Kami mengelakkan `unwrap_or_else` di sini kerana ia meningkatkan jumlah LLVM IR yang dihasilkan.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Menyusun semula `RawVec` dari penunjuk, kapasiti, dan peruntukan.
    ///
    /// # Safety
    ///
    /// `ptr` mesti diperuntukkan (melalui alokator `alloc` yang diberikan), dan dengan `capacity` yang diberikan.
    /// `capacity` tidak boleh melebihi `isize::MAX` untuk jenis bersaiz.
    /// (hanya perhatian pada sistem 32-bit).
    /// ZST vectors mungkin mempunyai kapasiti hingga `usize::MAX`.
    /// Sekiranya `ptr` dan `capacity` berasal dari `RawVec` yang dibuat melalui `alloc`, maka ini dijamin.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Mendapat pointer mentah ke permulaan peruntukan.
    /// Perhatikan bahawa ini adalah `Unique::dangling()` jika `capacity == 0` atau `T` berukuran sifar.
    /// Dalam kes sebelumnya, anda mesti berhati-hati.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Mendapat kapasiti peruntukan.
    ///
    /// Ini akan selalu menjadi `usize::MAX` jika `T` bersaiz sifar.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Mengembalikan rujukan bersama kepada alokasi yang menyokong `RawVec` ini.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Kami mempunyai sebahagian memori yang diperuntukkan, jadi kami dapat memotong pemeriksaan runtime untuk mendapatkan susun atur kami sekarang.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Memastikan penyangga mengandungi sekurang-kurangnya ruang yang cukup untuk menahan elemen `len + additional`.
    /// Sekiranya tidak mempunyai kapasiti yang mencukupi, akan mengalokasikan semula ruang yang cukup ditambah dengan ruang kendur yang selesa untuk melunaskan tingkah laku *O*(1).
    ///
    /// Akan mengehadkan tingkah laku ini sekiranya tidak perlu menyebabkan panic.
    ///
    /// Sekiranya `len` melebihi `self.capacity()`, ini mungkin gagal untuk benar-benar memperuntukkan ruang yang diminta.
    /// Ini sebenarnya tidak selamat, tetapi kod yang tidak selamat *anda* tulis yang bergantung pada tingkah laku fungsi ini mungkin rosak.
    ///
    /// Ini sangat sesuai untuk melaksanakan operasi penekanan pukal seperti `extend`.
    ///
    /// # Panics
    ///
    /// Panics jika kapasiti baru melebihi `isize::MAX` bait.
    ///
    /// # Aborts
    ///
    /// Berkurang di OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // cadangan akan dibatalkan atau panik sekiranya len melebihi `isize::MAX` jadi ini selamat untuk dicentang sekarang.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Sama seperti `reserve`, tetapi mengembalikan kesalahan dan bukannya panik atau batal.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Memastikan penyangga mengandungi sekurang-kurangnya ruang yang cukup untuk menahan elemen `len + additional`.
    /// Sekiranya belum, akan mengalokasikan semula jumlah memori minimum yang diperlukan.
    /// Secara amnya, ini adalah jumlah memori yang diperlukan, tetapi pada prinsipnya pengagihan bebas memberikan lebih banyak daripada yang kita minta.
    ///
    ///
    /// Sekiranya `len` melebihi `self.capacity()`, ini mungkin gagal untuk benar-benar memperuntukkan ruang yang diminta.
    /// Ini sebenarnya tidak selamat, tetapi kod yang tidak selamat *anda* tulis yang bergantung pada tingkah laku fungsi ini mungkin rosak.
    ///
    /// # Panics
    ///
    /// Panics jika kapasiti baru melebihi `isize::MAX` bait.
    ///
    /// # Aborts
    ///
    /// Berkurang di OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Sama seperti `reserve_exact`, tetapi mengembalikan kesalahan dan bukannya panik atau batal.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Mengecilkan peruntukan ke jumlah yang ditentukan.
    /// Sekiranya jumlah yang diberikan adalah 0, benar-benar menyahpindah sepenuhnya.
    ///
    /// # Panics
    ///
    /// Panics jika jumlah yang diberikan *lebih besar* daripada kapasiti semasa.
    ///
    /// # Aborts
    ///
    /// Berkurang di OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Kembali jika penyangga perlu tumbuh untuk memenuhi kapasiti tambahan yang diperlukan.
    /// Terutama digunakan untuk membuat panggilan masuk sebaris mungkin tanpa menggunakan `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Kaedah ini biasanya dibuat berkali-kali.Oleh itu, kami menginginkannya sekecil mungkin, untuk memperbaiki masa penyusunan.
    // Tetapi kami juga mahu sebilangan besar kandungannya dapat dikira secara statik mungkin, agar kod yang dihasilkan berjalan lebih cepat.
    // Oleh itu, kaedah ini ditulis dengan teliti sehingga semua kod yang bergantung pada `T` ada di dalamnya, sementara sebilangan besar kod yang tidak bergantung pada `T` mungkin ada dalam fungsi yang tidak generik lebih dari `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Ini dipastikan oleh konteks panggilan.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Oleh kerana kita mengembalikan kapasiti `usize::MAX` ketika `elem_size`
            // 0, masuk ke sini semestinya bermaksud `RawVec` terlalu banyak.
            return Err(CapacityOverflow);
        }

        // Tidak ada yang dapat kami lakukan mengenai pemeriksaan ini.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Ini menjamin pertumbuhan pesat.
        // Penggandaan tidak boleh melimpah kerana `cap <= isize::MAX` dan jenis `cap` adalah `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` tidak generik melebihi `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Kekangan dalam kaedah ini hampir sama dengan yang ada pada `grow_amortized`, tetapi kaedah ini biasanya kurang kerap dibuat sehingga kurang kritikal.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Oleh kerana kami mengembalikan kapasiti `usize::MAX` apabila ukuran jenisnya
            // 0, masuk ke sini semestinya bermaksud `RawVec` terlalu banyak.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` tidak generik melebihi `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Fungsi ini berada di luar `RawVec` untuk meminimumkan masa kompilasi.Lihat komen di atas `RawVec::grow_amortized` untuk keterangan.
// (Parameter `A` tidak signifikan, kerana jumlah jenis `A` yang berbeza yang dilihat dalam praktiknya jauh lebih kecil daripada jumlah jenis `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Periksa ralat di sini untuk meminimumkan ukuran `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Peruntukan memeriksa kesamaan penjajaran
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Membebaskan memori yang dimiliki oleh `RawVec`*tanpa* cuba menjatuhkan kandungannya.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Fungsi pusat untuk pengendalian ralat rizab.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Kita perlu menjamin perkara berikut:
// * Kami tidak pernah memperuntukkan objek berukuran byte `> isize::MAX`.
// * Kami tidak melimpah `usize::MAX` dan sebenarnya memperuntukkan terlalu sedikit.
//
// Pada 64-bit kita hanya perlu memeriksa limpahan kerana cuba memperuntukkan byte `> isize::MAX` pasti akan gagal.
// Pada 32-bit dan 16-bit kita perlu menambahkan pelindung tambahan untuk ini sekiranya kita berjalan di platform yang dapat menggunakan semua 4GB di ruang pengguna, misalnya, PAE atau x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Salah satu fungsi pusat yang bertanggungjawab untuk melaporkan limpahan keupayaan
// Ini akan memastikan bahawa penjanaan kod yang berkaitan dengan panics ini adalah minimum kerana hanya ada satu lokasi yang panics dan bukannya sekumpulan seluruh modul.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}