//! Petunjuk pengiraan rujukan tunggal.'Rc' bermaksud 'Rujukan
//! Counted'.
//!
//! Jenis [`Rc<T>`][`Rc`] memberikan kepemilikan bersama bagi nilai jenis `T`, yang diperuntukkan dalam timbunan.
//! Memohon [`clone`][clone] pada [`Rc`] menghasilkan penunjuk baru untuk peruntukan yang sama di timbunan.
//! Apabila penunjuk [`Rc`] terakhir ke peruntukan tertentu dimusnahkan, nilai yang tersimpan dalam peruntukan tersebut (sering disebut sebagai "inner value") juga akan dijatuhkan.
//!
//! Rujukan bersama dalam Rust tidak membenarkan mutasi secara lalai, dan [`Rc`] tidak terkecuali: anda tidak dapat memperoleh rujukan yang dapat diubah suai pada sesuatu di dalam [`Rc`].
//! Sekiranya anda memerlukan kebolehubahan, masukkan [`Cell`] atau [`RefCell`] di dalam [`Rc`];lihat [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] menggunakan pengiraan rujukan bukan atom.
//! Ini bermaksud bahawa overhead sangat rendah, tetapi [`Rc`] tidak dapat dihantar antara benang, dan akibatnya [`Rc`] tidak menerapkan [`Send`][send].
//! Akibatnya, penyusun Rust akan memeriksa *pada waktu kompilasi* bahawa anda tidak menghantar [`Rc`] antara benang.
//! Sekiranya anda memerlukan pengiraan rujukan atom pelbagai utas, gunakan [`sync::Arc`][arc].
//!
//! Kaedah [`downgrade`][downgrade] boleh digunakan untuk membuat penunjuk [`Weak`] yang tidak dimiliki.
//! Penunjuk [`Weak`] boleh menjadi [`upgrade`][upgrade] d ke [`Rc`], tetapi ini akan mengembalikan [`None`] jika nilai yang tersimpan dalam peruntukan telah dijatuhkan.
//! Dengan kata lain, penunjuk `Weak` tidak mengekalkan nilai di dalam peruntukan;namun, mereka *menyimpan* peruntukan (kedai sokongan untuk nilai dalaman) tetap hidup.
//!
//! Kitaran antara penunjuk [`Rc`] tidak akan pernah dialihkan.
//! Atas sebab ini, [`Weak`] digunakan untuk memecahkan kitaran.
//! Sebagai contoh, pokok boleh mempunyai penunjuk [`Rc`] yang kuat dari nod ibu bapa kepada anak-anak, dan penunjuk [`Weak`] dari anak-anak kembali ke ibu bapa mereka.
//!
//! `Rc<T>` penghapusan secara automatik ke `T` (melalui [`Deref`] trait), jadi anda boleh memanggil kaedah `T` pada nilai jenis [`Rc<T>`][`Rc`].
//! Untuk mengelakkan pertembungan nama dengan kaedah `T`, kaedah [`Rc<T>`][`Rc`] itu sendiri adalah fungsi yang berkaitan, disebut menggunakan [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Pelaksanaan traits seperti `Clone` juga boleh dipanggil menggunakan sintaks yang berkelayakan sepenuhnya.
//! Sebilangan orang lebih suka menggunakan sintaks yang memenuhi syarat sepenuhnya, sementara yang lain lebih suka menggunakan sintaks kaedah panggilan.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaks kaedah-panggilan
//! let rc2 = rc.clone();
//! // Sintaks yang berkelayakan sepenuhnya
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] tidak memberikan penghapusan automatik kepada `T`, kerana nilai dalamannya mungkin sudah jatuh.
//!
//! # Rujukan pengklonan
//!
//! Membuat rujukan baru untuk peruntukan yang sama dengan penunjuk yang dikira rujukan yang ada dilakukan menggunakan `Clone` trait yang dilaksanakan untuk [`Rc<T>`][`Rc`] dan [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Dua sintaksis di bawah adalah setara.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a dan b kedua-duanya menunjuk ke lokasi memori yang sama dengan foo.
//! ```
//!
//! Sintaks `Rc::clone(&from)` adalah yang paling idiomatik kerana menyampaikan makna kod dengan lebih jelas.
//! Dalam contoh di atas, sintaks ini mempermudah untuk melihat bahawa kod ini membuat rujukan baru daripada menyalin keseluruhan kandungan foo.
//!
//! # Examples
//!
//! Pertimbangkan senario di mana satu set `Gadget` dimiliki oleh `Owner` tertentu.
//! Kami ingin agar Gadget kami menunjukkan `Owner` mereka.Kami tidak dapat melakukan ini dengan pemilikan yang unik, kerana lebih daripada satu alat mungkin milik `Owner` yang sama.
//! [`Rc`] membolehkan kami berkongsi `Owner` antara beberapa `Gadget`s, dan `Owner` tetap diperuntukkan selagi mana-mana titik `Gadget` di dalamnya.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... bidang lain
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... bidang lain
//! }
//!
//! fn main() {
//!     // Buat `Owner` yang dikira rujukan.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Buat `Gadget` milik `gadget_owner`.
//!     // Mengklonkan `Rc<Owner>` memberi kita penunjuk baru untuk peruntukan `Owner` yang sama, meningkatkan jumlah rujukan dalam prosesnya.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Buangkan pemboleh ubah tempatan kami `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Walaupun menjatuhkan `gadget_owner`, kami masih dapat mencetak nama `Owner` dari `Gadget`s.
//!     // Ini kerana kami hanya menjatuhkan `Rc<Owner>` tunggal, bukan `Owner` yang ditunjukkannya.
//!     // Selagi ada `Rc<Owner>` lain yang menunjukkan peruntukan `Owner` yang sama, ia akan terus disiarkan.
//!     // Unjuran lapangan `gadget1.owner.name` berfungsi kerana `Rc<Owner>` secara automatik tidak merujuk kepada `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Pada akhir fungsi, `gadget1` dan `gadget2` dimusnahkan, dan bersama-sama rujukan terakhir yang dihitung untuk `Owner` kami.
//!     // Man Gadget kini hancur juga.
//!     //
//! }
//! ```
//!
//! Sekiranya keperluan kita berubah, dan kita juga mesti dapat melintasi dari `Owner` ke `Gadget`, kita akan menghadapi masalah.
//! Penunjuk [`Rc`] dari `Owner` hingga `Gadget` memperkenalkan kitaran.
//! Ini bermaksud bahawa jumlah rujukan mereka tidak boleh mencapai 0, dan peruntukan tidak akan hancur:
//! kebocoran memori.Untuk mengatasi ini, kita boleh menggunakan petunjuk [`Weak`].
//!
//! Rust sebenarnya menjadikannya agak sukar untuk menghasilkan gelung ini sejak awal.Untuk berakhir dengan dua nilai yang saling menunjuk, salah satu daripadanya perlu diubah.
//! Ini sukar kerana [`Rc`] menegakkan keselamatan memori dengan hanya memberikan rujukan bersama mengenai nilai yang dibungkus, dan ini tidak membenarkan mutasi langsung.
//! Kita perlu membungkus bahagian nilai yang ingin kita mutasi dalam [`RefCell`], yang memberikan *kebolehubahan dalaman*: kaedah untuk mencapai kebolehubahan melalui rujukan bersama.
//! [`RefCell`] menguatkuasakan peraturan peminjaman Rust pada waktu runtime.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... bidang lain
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... bidang lain
//! }
//!
//! fn main() {
//!     // Buat `Owner` yang dikira rujukan.
//!     // Perhatikan bahawa kami telah meletakkan vector `Gadget` milik Owner di dalam `RefCell` sehingga kami dapat mengubahnya melalui rujukan bersama.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Buat `Gadget` milik `gadget_owner`, seperti sebelumnya.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Tambahkan `Gadget`s ke `Owner` mereka.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` pinjaman dinamik berakhir di sini.
//!     }
//!
//!     // Berulang-ulang pada `Gadget` kami, mencetak butirannya.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` adalah `Weak<Gadget>`.
//!         // Oleh kerana penunjuk `Weak` tidak dapat menjamin peruntukan masih ada, kita perlu memanggil `upgrade`, yang mengembalikan `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Dalam kes ini kita tahu peruntukan masih ada, jadi kita hanya `unwrap` `Option`.
//!         // Dalam program yang lebih rumit, anda mungkin memerlukan pengendalian ralat yang baik untuk hasil `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Pada akhir fungsi, `gadget_owner`, `gadget1`, dan `gadget2` dimusnahkan.
//!     // Kini tidak ada petunjuk (`Rc`) yang kuat ke alat, jadi ia hancur.
//!     // Ini menunjukkan jumlah rujukan pada Gadget Man, sehingga dia juga hancur.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ini adalah bukti repr(C) hingga future terhadap kemungkinan penyusunan semula medan, yang akan mengganggu [into|from]_raw() jika tidak selamat dari jenis dalaman yang dapat dipindah.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Penunjuk penghitung rujukan tunggal.'Rc' bermaksud 'Rujukan
/// Counted'.
///
/// Lihat [module-level documentation](./index.html) untuk maklumat lebih lanjut.
///
/// Kaedah `Rc` yang melekat adalah semua fungsi yang berkaitan, yang bermaksud anda harus memanggilnya sebagai contoh, [`Rc::get_mut(&mut value)`][get_mut] dan bukannya `value.get_mut()`.
/// Ini mengelakkan konflik dengan kaedah jenis dalaman `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ketidakamanan ini baik kerana semasa Rc ini masih hidup, kami dijamin bahawa penunjuk dalamannya sah.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Membina `Rc<T>` baru.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Terdapat penunjuk lemah tersirat yang dimiliki oleh semua penunjuk kuat, yang memastikan bahawa pemusnah lemah tidak akan melepaskan peruntukan semasa pemusnah kuat sedang berjalan, walaupun penunjuk lemah disimpan di dalam yang kuat.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Membina `Rc<T>` baru menggunakan rujukan yang lemah untuk dirinya sendiri.
    /// Mencuba untuk meningkatkan rujukan yang lemah sebelum fungsi ini kembali akan menghasilkan nilai `None`.
    ///
    /// Walau bagaimanapun, rujukan yang lemah dapat diklon secara bebas dan disimpan untuk digunakan di lain waktu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... lebih banyak bidang
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Bentukkan bahagian dalam dalam keadaan "uninitialized" dengan satu rujukan lemah.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Penting agar kita tidak melepaskan kepemilikan pointer yang lemah, jika tidak, memori mungkin akan dibebaskan pada saat `data_fn` kembali.
        // Sekiranya kita benar-benar ingin melepaskan hak milik, kita dapat membuat penunjuk lemah tambahan untuk diri kita sendiri, tetapi ini akan menghasilkan kemas kini tambahan pada jumlah rujukan lemah yang mungkin tidak diperlukan sebaliknya.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Rujukan kuat secara kolektif harus memiliki rujukan lemah bersama, jadi jangan jalankan pemusnah untuk rujukan lemah lama kami.
        //
        mem::forget(weak);
        strong
    }

    /// Membina `Rc` baru dengan kandungan yang tidak dimulakan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Permulaan tertunda:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Membina `Rc` baru dengan kandungan yang tidak dimulakan, dengan memori diisi dengan bait `0`.
    ///
    ///
    /// Lihat [`MaybeUninit::zeroed`][zeroed] untuk contoh penggunaan kaedah ini dengan betul dan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Membina `Rc<T>` baru, mengembalikan ralat jika peruntukan gagal
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Terdapat penunjuk lemah tersirat yang dimiliki oleh semua penunjuk kuat, yang memastikan bahawa pemusnah lemah tidak akan melepaskan peruntukan semasa pemusnah kuat sedang berjalan, walaupun penunjuk lemah disimpan di dalam yang kuat.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Membina `Rc` baru dengan kandungan yang tidak dimulakan, mengembalikan ralat jika peruntukan gagal
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Permulaan tertunda:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Membina `Rc` baru dengan kandungan yang tidak dimulakan, dengan memori diisi dengan bait `0`, mengembalikan ralat jika peruntukan gagal
    ///
    ///
    /// Lihat [`MaybeUninit::zeroed`][zeroed] untuk contoh penggunaan kaedah ini dengan betul dan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Membina `Pin<Rc<T>>` baru.
    /// Sekiranya `T` tidak melaksanakan `Unpin`, maka `value` akan disematkan dalam memori dan tidak dapat dipindahkan.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Mengembalikan nilai dalaman, jika `Rc` mempunyai tepat satu rujukan kuat.
    ///
    /// Jika tidak, [`Err`] dikembalikan dengan `Rc` yang sama yang diteruskan.
    ///
    ///
    /// Ini akan berjaya walaupun terdapat rujukan lemah yang luar biasa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // salin objek yang terdapat

                // Nyatakan kepada Lemah bahawa mereka tidak dapat dipromosikan dengan mengurangi jumlah yang kuat, dan kemudian keluarkan penunjuk "strong weak" yang tersirat sambil menangani logik penurunan dengan hanya membuat Lemah palsu.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Membina irisan dikira rujukan baru dengan kandungan yang tidak dimulakan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Permulaan tertunda:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Membina irisan yang dikira rujukan baru dengan kandungan yang tidak dimulakan, dengan memori diisi dengan bait `0`.
    ///
    ///
    /// Lihat [`MaybeUninit::zeroed`][zeroed] untuk contoh penggunaan kaedah ini dengan betul dan salah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Menukar kepada `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Seperti [`MaybeUninit::assume_init`], terserah kepada pemanggil untuk menjamin bahawa nilai dalaman benar-benar berada dalam keadaan yang diinisialisasi.
    ///
    /// Menyebutnya ketika kandungan belum diinisialisasi sepenuhnya menyebabkan tingkah laku tidak ditentukan langsung.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Permulaan tertunda:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Menukar kepada `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Seperti [`MaybeUninit::assume_init`], terserah kepada pemanggil untuk menjamin bahawa nilai dalaman benar-benar berada dalam keadaan yang diinisialisasi.
    ///
    /// Menyebutnya ketika kandungan belum diinisialisasi sepenuhnya menyebabkan tingkah laku tidak ditentukan langsung.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Permulaan tertunda:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Menggunakan `Rc`, mengembalikan penunjuk yang dibungkus.
    ///
    /// Untuk mengelakkan kebocoran memori, penunjuk mesti ditukar kembali ke `Rc` menggunakan [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Menyediakan penunjuk mentah ke data.
    ///
    /// Kiraan tidak akan terjejas dengan cara apa pun dan `Rc` tidak habis.
    /// Penunjuk berlaku selagi terdapat jumlah yang kuat di `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // KESELAMATAN: Ini tidak boleh melalui Deref::deref atau Rc::inner kerana
        // ini diperlukan untuk mengekalkan asalnya raw/mut seperti misalnya
        // `get_mut` boleh menulis melalui penunjuk selepas Rc dipulihkan melalui `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Membina `Rc<T>` dari penunjuk mentah.
    ///
    /// Penunjuk mentah mesti dikembalikan sebelumnya dengan panggilan ke [`Rc<U>::into_raw`][into_raw] di mana `U` mesti mempunyai ukuran dan penjajaran yang sama dengan `T`.
    /// Ini benar jika `U` adalah `T`.
    /// Perhatikan bahawa jika `U` bukan `T` tetapi mempunyai ukuran dan penjajaran yang sama, ini pada dasarnya seperti menghantar rujukan dari pelbagai jenis.
    /// Lihat [`mem::transmute`][transmute] untuk maklumat lebih lanjut mengenai sekatan apa yang berlaku dalam kes ini.
    ///
    /// Pengguna `from_raw` harus memastikan nilai `T` tertentu hanya dijatuhkan sekali.
    ///
    /// Fungsi ini tidak selamat kerana penggunaan yang tidak betul boleh menyebabkan memori tidak selamat, walaupun `Rc<T>` yang dikembalikan tidak pernah diakses.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Tukar kembali ke `Rc` untuk mengelakkan kebocoran.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Panggilan lebih lanjut ke `Rc::from_raw(x_ptr)` akan menjadi memori yang tidak selamat.
    /// }
    ///
    /// // Memori itu dibebaskan ketika `x` keluar dari ruang lingkup di atas, jadi `x_ptr` sekarang tergantung!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Balikkan ofset untuk mencari RcBox yang asal.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Membuat penunjuk [`Weak`] baru untuk peruntukan ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Pastikan kita tidak membuat Lemah yang menggantung
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Mendapat bilangan penunjuk [`Weak`] ke peruntukan ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Mendapat bilangan penunjuk (`Rc`) yang kuat untuk peruntukan ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Mengembalikan `true` jika tidak ada penunjuk `Rc` atau [`Weak`] lain ke peruntukan ini.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Mengembalikan rujukan yang dapat diubah ke `Rc` yang diberikan, jika tidak ada penunjuk `Rc` atau [`Weak`] yang lain ke peruntukan yang sama.
    ///
    ///
    /// Mengembalikan [`None`] sebaliknya, kerana tidak dapat mengubah nilai bersama.
    ///
    /// Lihat juga [`make_mut`][make_mut], yang akan [`clone`][clone] nilai dalaman apabila ada petunjuk lain.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Mengembalikan rujukan yang boleh berubah ke `Rc` yang diberikan, tanpa sebarang tanda semak.
    ///
    /// Lihat juga [`get_mut`], yang selamat dan melakukan pemeriksaan yang sesuai.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Sebarang petunjuk `Rc` atau [`Weak`] lain untuk peruntukan yang sama tidak boleh ditangguhkan sepanjang tempoh pinjaman yang dikembalikan.
    ///
    /// Ini adalah perkara kecil jika tidak ada petunjuk seperti itu, contohnya sejurus selepas `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Kami berhati-hati untuk *tidak* membuat rujukan yang meliputi bidang "count", kerana ini akan bertentangan dengan akses ke jumlah rujukan (mis.
        // oleh `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Mengembalikan `true` jika dua `Rc` menunjukkan peruntukan yang sama (dalam urat yang serupa dengan [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Membuat rujukan yang boleh berubah ke `Rc` yang diberikan.
    ///
    /// Sekiranya terdapat penunjuk `Rc` lain untuk peruntukan yang sama, maka `make_mut` akan [`clone`] nilai dalaman menjadi peruntukan baru untuk memastikan pemilikan yang unik.
    /// Ini juga disebut sebagai clone-on-write.
    ///
    /// Sekiranya tidak ada penunjuk `Rc` lain untuk peruntukan ini, maka penunjuk [`Weak`] ke peruntukan ini akan dipisahkan.
    ///
    /// Lihat juga [`get_mut`], yang akan gagal dan bukannya pengklonan.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Tidak akan mengklon apa-apa
    /// let mut other_data = Rc::clone(&data);    // Tidak akan mengklon data dalaman
    /// *Rc::make_mut(&mut data) += 1;        // Data dalaman klon
    /// *Rc::make_mut(&mut data) += 1;        // Tidak akan mengklon apa-apa
    /// *Rc::make_mut(&mut other_data) *= 2;  // Tidak akan mengklon apa-apa
    ///
    /// // Sekarang `data` dan `other_data` menunjukkan peruntukan yang berbeza.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] penunjuk akan dipisahkan:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Harus mengkloning data, ada Rcs lain.
            // Pra-peruntukkan memori untuk membolehkan menulis nilai klon secara langsung.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Hanya boleh mencuri data, yang tinggal hanyalah Kelemahan
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Keluarkan rujukan kuat-lemah yang tersirat (tidak perlu membuat Lemah palsu di sini-kita tahu Kelemahan lain dapat membersihkan kita)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ketidakamanan ini baik kerana kami dijamin bahawa penunjuk yang dikembalikan adalah penunjuk *only* yang akan dikembalikan ke T.
        // Jumlah rujukan kami dijamin menjadi 1 pada ketika ini, dan kami memerlukan `Rc<T>` itu sendiri menjadi `mut`, jadi kami mengembalikan satu-satunya rujukan yang mungkin untuk peruntukan tersebut.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Percubaan untuk menurunkan `Rc<dyn Any>` ke jenis konkrit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Memperuntukkan `RcBox<T>` dengan ruang yang mencukupi untuk nilai dalaman yang mungkin tidak bersaiz di mana nilainya mempunyai susun atur yang disediakan.
    ///
    /// Fungsi `mem_to_rcbox` dipanggil dengan penunjuk data dan mesti mengembalikan penunjuk (berpotensi gemuk) untuk `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Kira susun atur menggunakan susun atur nilai yang diberikan.
        // Sebelumnya, susun atur dihitung pada ungkapan `&*(ptr as* const RcBox<T>)`, tetapi ini membuat rujukan yang tidak sejajar (lihat #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Memperuntukkan `RcBox<T>` dengan ruang yang cukup untuk nilai dalaman yang mungkin tidak berukuran di mana nilainya mempunyai susun atur yang disediakan, mengembalikan ralat jika peruntukan gagal.
    ///
    ///
    /// Fungsi `mem_to_rcbox` dipanggil dengan penunjuk data dan mesti mengembalikan penunjuk (berpotensi gemuk) untuk `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Kira susun atur menggunakan susun atur nilai yang diberikan.
        // Sebelumnya, susun atur dihitung pada ungkapan `&*(ptr as* const RcBox<T>)`, tetapi ini membuat rujukan yang tidak sejajar (lihat #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Peruntukkan susun atur.
        let ptr = allocate(layout)?;

        // Memulakan RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Memperuntukkan `RcBox<T>` dengan ruang yang mencukupi untuk nilai dalaman yang tidak bersaiz
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Peruntukkan `RcBox<T>` menggunakan nilai yang diberikan.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nilai salin sebagai bait
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Bebaskan peruntukan tanpa membuang isinya
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Memperuntukkan `RcBox<[T]>` dengan panjang yang diberikan.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Salin elemen dari slice ke Rc yang baru diperuntukkan <\[T\]>
    ///
    /// Tidak selamat kerana pemanggil mesti mengambil hak milik atau mengikat `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Membina `Rc<[T]>` dari iterator yang diketahui mempunyai ukuran tertentu.
    ///
    /// Tingkah laku tidak ditentukan sekiranya ukurannya salah.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Pengawal Panic sambil mengklon elemen T.
        // Sekiranya panic, elemen yang telah ditulis ke dalam RcBox baru akan dijatuhkan, maka memori akan dibebaskan.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Penunjuk ke elemen pertama
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Semua siap.Lupakan penjaga supaya tidak membebaskan RcBox baru.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Pengkhususan trait digunakan untuk `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Turunkan `Rc`.
    ///
    /// Ini akan mengurangkan jumlah rujukan yang kuat.
    /// Sekiranya kiraan rujukan kuat mencapai sifar maka satu-satunya rujukan lain (jika ada) adalah [`Weak`], jadi kami `drop` nilai dalaman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Tidak mencetak apa-apa
    /// drop(foo2);   // Cetakan "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // memusnahkan objek yang terkandung
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // keluarkan penunjuk "strong weak" yang tersirat sekarang kerana kami telah menghancurkan kandungannya.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Membuat klon penunjuk `Rc`.
    ///
    /// Ini menjadikan penunjuk lain kepada peruntukan yang sama, meningkatkan jumlah rujukan yang kuat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Membuat `Rc<T>` baru, dengan nilai `Default` untuk `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack untuk membolehkan pengkhususan `Eq` walaupun `Eq` mempunyai kaedah.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Kami melakukan pengkhususan ini di sini, dan bukan sebagai pengoptimuman yang lebih umum pada `&T`, kerana jika tidak, ia akan menambahkan kos untuk semua pemeriksaan kesetaraan pada rujukan.
/// Kami menganggap bahawa `Rc`s digunakan untuk menyimpan nilai-nilai besar, yang lambat untuk diklon, tetapi juga berat untuk memeriksa kesetaraan, menyebabkan kos ini dapat dilunaskan dengan lebih mudah.
///
/// Ia juga cenderung mempunyai dua klon `Rc`, yang menunjukkan nilai yang sama, daripada dua `&T`s.
///
/// Kami hanya dapat melakukan ini apabila `T: Eq` sebagai `PartialEq` mungkin sengaja tidak merefleksikan.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Persamaan untuk dua `Rc`s.
    ///
    /// Dua `Rc` sama jika nilai dalamannya sama, walaupun disimpan dalam peruntukan yang berbeza.
    ///
    /// Sekiranya `T` juga menerapkan `Eq` (menyiratkan refleksiviti persamaan), dua `Rc yang menunjukkan peruntukan yang sama selalu sama.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ketaksamaan untuk dua `Rc`s.
    ///
    /// Dua `Rc`s tidak sama jika nilai dalamannya tidak sama.
    ///
    /// Sekiranya `T` juga menerapkan `Eq` (menyiratkan refleksiviti persamaan), dua `Rc yang menunjukkan peruntukan yang sama tidak akan sama.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Perbandingan separa untuk dua `Rc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `partial_cmp()` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Kurang daripada perbandingan untuk dua `Rc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `<` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Perbandingan 'Kurang daripada atau sama dengan' untuk dua `Rc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `<=` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Perbandingan lebih besar daripada dua `Rc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `>` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Perbandingan 'Lebih besar daripada atau sama dengan' untuk dua `Rc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `>=` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Perbandingan untuk dua `Rc`s.
    ///
    /// Keduanya dibandingkan dengan memanggil `cmp()` pada nilai dalaman mereka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Peruntukkan potongan yang dikira rujukan dan isi dengan mengklon item `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Peruntukkan potongan rentetan yang dikira rujukan dan salin `v` ke dalamnya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Peruntukkan potongan rentetan yang dikira rujukan dan salin `v` ke dalamnya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Pindahkan objek berkotak ke peruntukan yang baru, dihitung rujukan.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Alihkan potongan yang dikira rujukan dan pindahkan item `v` ke dalamnya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Benarkan Vec untuk membebaskan ingatannya, tetapi tidak menghancurkan isinya
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Mengambil setiap elemen dalam `Iterator` dan mengumpulkannya menjadi `Rc<[T]>`.
    ///
    /// # Ciri prestasi
    ///
    /// ## Kes umum
    ///
    /// Dalam kes umum, pengumpulan menjadi `Rc<[T]>` dilakukan dengan pengumpulan pertama menjadi `Vec<T>`.Iaitu, semasa menulis perkara berikut:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ini berkelakuan seolah-olah kita menulis:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Kumpulan peruntukan pertama berlaku di sini.
    ///     .into(); // Peruntukan kedua untuk `Rc<[T]>` berlaku di sini.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ini akan memperuntukkan sebanyak yang diperlukan untuk membina `Vec<T>` dan kemudian akan diperuntukkan sekali untuk mengubah `Vec<T>` menjadi `Rc<[T]>`.
    ///
    ///
    /// ## Pengulangan panjang yang diketahui
    ///
    /// Apabila `Iterator` anda menggunakan `TrustedLen` dan mempunyai ukuran yang tepat, satu peruntukan akan dibuat untuk `Rc<[T]>`.Sebagai contoh:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Hanya satu peruntukan berlaku di sini.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Pengkhususan trait digunakan untuk mengumpulkan menjadi `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ini adalah kes untuk iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // KESELAMATAN: Kita perlu memastikan bahawa iterator mempunyai panjang yang tepat dan yang kita miliki.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Kembali ke pelaksanaan normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` adalah versi [`Rc`] yang menyimpan rujukan bukan milik terhadap peruntukan yang diuruskan.Peruntukan diakses dengan memanggil [`upgrade`] pada penunjuk `Weak`, yang mengembalikan ["Option"] "<" [`Rc"] "<T>>`
///
/// Oleh kerana rujukan `Weak` tidak termasuk dalam pemilikan, ia tidak akan menghalang nilai yang tersimpan dalam peruntukan dijatuhkan, dan `Weak` sendiri tidak memberikan jaminan mengenai nilai yang masih ada.
/// Oleh itu ia mungkin mengembalikan [`None`] ketika [`upgrade`] d.
/// Walau bagaimanapun, perhatikan bahawa rujukan `Weak` * menghalang peruntukan itu sendiri (kedai penyokong) daripada dinyahalokasikan.
///
/// Penunjuk `Weak` berguna untuk menyimpan rujukan sementara terhadap peruntukan yang dikendalikan oleh [`Rc`] tanpa menghalang nilai dalamannya jatuh.
/// Ia juga digunakan untuk mencegah rujukan pekeliling antara penunjuk [`Rc`], kerana rujukan yang dimiliki sendiri tidak akan membenarkan [`Rc`] dijatuhkan.
/// Sebagai contoh, pokok boleh mempunyai penunjuk [`Rc`] yang kuat dari nod ibu bapa kepada anak-anak, dan penunjuk `Weak` dari anak-anak kembali ke ibu bapa mereka.
///
/// Cara khas untuk mendapatkan penunjuk `Weak` adalah memanggil [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ini adalah `NonNull` untuk membolehkan mengoptimumkan ukuran jenis ini dalam enum, tetapi tidak semestinya penunjuk yang sah.
    //
    // `Weak::new` menetapkan ini ke `usize::MAX` sehingga tidak perlu memperuntukkan ruang di timbunan.
    // Itu bukan nilai yang dapat dimiliki penunjuk sebenar kerana RcBox mempunyai penjajaran sekurang-kurangnya 2.
    // Ini hanya boleh dilakukan apabila `T: Sized`;`T` yang tidak bersaiz tidak pernah menjuntai.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Membina `Weak<T>` baru, tanpa memperuntukkan memori.
    /// Memanggil [`upgrade`] pada nilai pengembalian selalu memberikan [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Jenis pembantu untuk membolehkan mengakses jumlah rujukan tanpa membuat penegasan mengenai bidang data.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Mengembalikan penunjuk mentah ke objek `T` yang ditunjukkan oleh `Weak<T>` ini.
    ///
    /// Penunjuk hanya berlaku jika terdapat beberapa rujukan yang kuat.
    /// Penunjuk mungkin menggantung, tidak sejajar atau bahkan [`null`] sebaliknya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Kedua-duanya menunjuk ke objek yang sama
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Yang kuat di sini menjadikannya hidup, jadi kita masih dapat mengakses objek.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Tetapi tidak lagi.
    /// // Kita boleh melakukan weak.as_ptr(), tetapi mengakses penunjuk akan menyebabkan tingkah laku yang tidak ditentukan.
    /// // assert_eq! ("hello", tidak selamat {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Sekiranya penunjuk digantung, kami mengembalikan sentinel secara langsung.
            // Ini bukan alamat muatan yang sah, kerana muatan sekurang-kurangnya sejajar dengan RcBox (usize).
            ptr as *const T
        } else {
            // KESELAMATAN: jika is_dangling kembali palsu, maka penunjuk tidak dapat ditanggalkan.
            // Muatan mungkin turun pada tahap ini, dan kita harus menjaga ketahanan, jadi gunakan manipulasi penunjuk mentah.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Menggunakan `Weak<T>` dan mengubahnya menjadi penunjuk mentah.
    ///
    /// Ini mengubah pointer lemah menjadi pointer mentah, sementara masih mengekalkan pemilikan satu rujukan lemah (kiraan lemah tidak diubah oleh operasi ini).
    /// Ia boleh diubah menjadi `Weak<T>` dengan [`from_raw`].
    ///
    /// Sekatan yang sama untuk mencapai sasaran penunjuk seperti dengan [`as_ptr`] berlaku.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Menukar penunjuk mentah yang sebelumnya dibuat oleh [`into_raw`] kembali ke `Weak<T>`.
    ///
    /// Ini boleh digunakan untuk mendapatkan rujukan kuat dengan selamat (dengan menghubungi [`upgrade`] kemudian) atau untuk mengalihkan kiraan lemah dengan menjatuhkan `Weak<T>`.
    ///
    /// Memerlukan satu rujukan yang lemah (dengan pengecualian petunjuk yang dibuat oleh [`new`], kerana ini tidak memiliki apa-apa; kaedah masih berfungsi).
    ///
    /// # Safety
    ///
    /// Penunjuk mesti berasal dari [`into_raw`] dan masih mesti mempunyai rujukan lemah yang berpotensi.
    ///
    /// Dibolehkan untuk kiraan kuat adalah 0 pada saat memanggil ini.
    /// Walaupun begitu, ini memerlukan satu rujukan lemah yang kini ditunjukkan sebagai penunjuk mentah (kiraan lemah tidak diubah oleh operasi ini) dan oleh itu ia mesti dipasangkan dengan panggilan sebelumnya ke [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Kurangkan kiraan lemah terakhir.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Lihat Weak::as_ptr untuk konteks bagaimana penunjuk input dihasilkan.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ini adalah Lemah yang menggantung.
            ptr as *mut RcBox<T>
        } else {
            // Jika tidak, kami dijamin penunjuknya berasal dari Lemah yang tidak larut.
            // KESELAMATAN: data_offset selamat dipanggil, kerana ptr merujuk T. yang sebenar (berpotensi jatuh)
            let offset = unsafe { data_offset(ptr) };
            // Oleh itu, kami membalikkan ofset untuk mendapatkan keseluruhan RcBox.
            // KESELAMATAN: penunjuk berasal dari Lemah, jadi pengimbangan ini selamat.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // KESELAMATAN: sekarang kita telah mendapatkan penunjuk Lemah yang asli, jadi boleh membuat yang Lemah.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Percubaan untuk meningkatkan penunjuk `Weak` ke [`Rc`], menunda penurunan nilai dalaman jika berjaya.
    ///
    ///
    /// Mengembalikan [`None`] jika nilai dalaman telah dijatuhkan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Hancurkan semua petunjuk yang kuat.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Mendapat bilangan penunjuk (`Rc`) yang kuat yang menunjukkan peruntukan ini.
    ///
    /// Sekiranya `self` dibuat menggunakan [`Weak::new`], ini akan mengembalikan 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Mendapat bilangan penunjuk `Weak` yang menunjukkan peruntukan ini.
    ///
    /// Sekiranya tidak ada penunjuk yang kuat, ini akan mengembalikan sifar.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // tolak ptr lemah yang tersirat
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Mengembalikan `None` ketika penunjuk digantung dan tidak ada `RcBox` yang diperuntukkan, (iaitu, ketika `Weak` ini dibuat oleh `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Kami berhati-hati untuk *tidak* membuat rujukan yang meliputi bidang "data", kerana medan tersebut dapat dimutasi secara serentak (contohnya, jika `Rc` terakhir dijatuhkan, bidang data akan digugurkan di tempat).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Mengembalikan `true` jika kedua-dua `Lemah menunjukkan peruntukan yang sama (serupa dengan [`ptr::eq`]), atau jika kedua-duanya tidak menunjukkan peruntukan apa pun (kerana dibuat dengan `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Oleh kerana ini membandingkan petunjuk, ini bermaksud bahawa `Weak::new()` akan sama antara satu sama lain, walaupun mereka tidak menunjukkan peruntukan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Membandingkan `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Turunkan penunjuk `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Tidak mencetak apa-apa
    /// drop(foo);        // Cetakan "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // kiraan lemah bermula pada 1, dan hanya akan menjadi sifar jika semua petunjuk kuat telah hilang.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Membuat klon penunjuk `Weak` yang menunjukkan peruntukan yang sama.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Membina `Weak<T>` baru, memperuntukkan memori untuk `T` tanpa memulakannya.
    /// Memanggil [`upgrade`] pada nilai pengembalian selalu memberikan [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Kami periksa_tambah di sini untuk menangani mem::forget dengan selamat.Khususnya
// jika anda mem::forget Rcs (atau Lemah), kiraan ref dapat meluap, dan kemudian anda dapat membebaskan peruntukan sementara Rcs (atau Lemah) yang ada masih ada.
//
// Kami membatalkan kerana ini adalah senario merosot sehingga kita tidak peduli dengan apa yang berlaku-tidak ada program yang semestinya dapat mengalami ini.
//
// Ini semestinya mempunyai overhead yang boleh diabaikan kerana anda sebenarnya tidak perlu mengkloningnya dalam Rust berkat pemilikan dan semantik bergerak.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Kami mahu membatalkan overflow dan bukannya menjatuhkan nilai.
        // Kiraan rujukan tidak akan menjadi sifar apabila disebut;
        // namun demikian, kami memasukkan batal di sini untuk mengisyaratkan LLVM pada pengoptimuman yang tidak dijawab.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Kami mahu membatalkan overflow dan bukannya menjatuhkan nilai.
        // Kiraan rujukan tidak akan menjadi sifar apabila disebut;
        // namun demikian, kami memasukkan batal di sini untuk mengisyaratkan LLVM pada pengoptimuman yang tidak dijawab.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Dapatkan pengimbangan dalam `RcBox` untuk muatan di belakang penunjuk.
///
/// # Safety
///
/// Penunjuk mesti menunjukkan (dan mempunyai metadata yang sah untuk) contoh T yang sah sebelumnya, tetapi T dibenarkan untuk dijatuhkan.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Sejajarkan nilai yang tidak bersaiz hingga akhir RcBox.
    // Kerana RcBox adalah repr(C), ia akan selalu menjadi medan terakhir dalam memori.
    // KESELAMATAN: kerana satu-satunya jenis yang tidak diukur adalah kepingan, objek trait,
    // dan jenis luaran, syarat keselamatan input pada masa ini cukup untuk memenuhi syarat align_of_val_raw;ini adalah perincian pelaksanaan bahasa yang mungkin tidak boleh dipercayai di luar std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}