//! Pelaksanaan Rust panics melalui proses membatalkan
//!
//! Jika dibandingkan dengan pelaksanaan melalui uninding, crate ini * jauh lebih mudah!Walaupun begitu, ini tidak serba boleh, tetapi begini!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" muatan dan perubahan kepada pengguguran yang berkaitan di platform yang dimaksudkan.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // panggil std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Pada Windows, gunakan mekanisme __ fastfail khusus pemproses.Pada Windows 8 dan lebih baru, ini akan menghentikan proses dengan segera tanpa menjalankan pengendali pengecualian dalam proses.
            // Pada versi Windows sebelumnya, urutan arahan ini akan dianggap sebagai pelanggaran akses, menghentikan proses tetapi tanpa harus melewati semua pengendali pengecualian.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ini adalah pelaksanaan yang sama seperti di `abort_internal` libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Ini ... agak aneh.Tl; dr;adakah ini diperlukan untuk menghubungkan dengan betul, penjelasan yang lebih panjang ada di bawah.
//
// Sekarang binari libcore/libstd yang kami kirim semuanya disusun dengan `-C panic=unwind`.Ini dilakukan untuk memastikan bahawa binari semaksimum mungkin sesuai dengan seberapa banyak situasi yang mungkin.
// Namun, penyusunnya memerlukan "personality function" untuk semua fungsi yang disusun dengan `-C panic=unwind`.Fungsi keperibadian ini dikodkan keras ke simbol `rust_eh_personality` dan ditentukan oleh item lang `eh_personality`.
//
// So...
// mengapa tidak hanya menentukan item lang di sini?Soalan yang baik!Cara sambungan runtime panic sebenarnya agak halus kerana ia "sort of" di kedai crate pengkompil, tetapi hanya dihubungkan jika yang lain sebenarnya tidak dipautkan.
//
// Ini akhirnya bermaksud bahawa kedua-dua crate dan panic_unwind crate ini boleh muncul di kedai crate penyusun, dan jika kedua-duanya menentukan item lang `eh_personality` maka itu akan berlaku ralat.
//
// Untuk mengatasinya, pengkompil hanya memerlukan `eh_personality` yang ditentukan sekiranya masa berjalan panic yang dihubungkan adalah waktu berjalan yang tidak bersuara, dan jika tidak, ia tidak perlu ditentukan (betul demikian).
// Walau bagaimanapun, dalam kes ini, perpustakaan ini hanya menentukan simbol ini sehingga sekurang-kurangnya terdapat keperibadian di suatu tempat.
//
// Pada dasarnya simbol ini hanya ditakrifkan untuk mendapatkan kabel hingga binari libcore/libstd, tetapi tidak boleh disebut kerana kita sama sekali tidak menghubungkannya dengan waktu operasi yang santai.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Pada x86_64-pc-windows-gnu kami menggunakan fungsi keperibadian kami sendiri yang perlu mengembalikan `ExceptionContinueSearch` ketika kami melewati semua bingkai kami.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Sama seperti di atas, ini sesuai dengan item lang `eh_catch_typeinfo` yang hanya digunakan di Emscripten saat ini.
    //
    // Oleh kerana panics tidak menghasilkan pengecualian dan pengecualian asing pada masa ini UB dengan -C panic=batalkan (walaupun ini mungkin berubah), sebarang panggilan catch_unwind tidak akan pernah menggunakan typeinfo ini.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Kedua-dua ini dipanggil oleh objek permulaan kami di i686-pc-windows-gnu, tetapi mereka tidak perlu melakukan apa-apa sehingga badannya tidak bergerak.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}