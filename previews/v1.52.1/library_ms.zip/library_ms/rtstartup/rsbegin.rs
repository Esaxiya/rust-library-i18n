// rsbegin.o dan rsend.o adalah "compiler runtime startup objects".
// Mereka mengandungi kod yang diperlukan untuk menginisialisasi jangka masa penyusun dengan betul.
//
// Apabila imej yang boleh dieksekusi atau dylib dihubungkan, semua kod pengguna dan perpustakaan adalah "sandwiched" di antara dua fail objek ini, jadi kod atau data dari rsbegin.o menjadi yang pertama di bahagian masing-masing gambar, sedangkan kod dan data dari rsend.o menjadi yang terakhir.
// Kesan ini boleh digunakan untuk meletakkan simbol pada awal atau akhir bahagian, serta memasukkan header atau footer yang diperlukan.
//
// Perhatikan bahawa titik masuk modul sebenarnya terletak di objek permulaan runtime C (biasanya disebut `crtX.o`), yang kemudiannya memanggil semula permulaan semula komponen runtime lain (didaftarkan melalui bahagian gambar khas lain).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Menandakan permulaan bahagian maklumat susun bingkai timbunan
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Ruang calar untuk penyimpanan buku dalaman para pengganggu.
    // Ini ditakrifkan sebagai `struct object` dalam $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Bersantai rutin maklumat registration/deregistration.
    // Lihat dokumen libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // daftar maklumat santai mengenai permulaan modul
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // nyah pendaftaran semasa ditutup
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Pendaftaran rutin init/uninit khusus MinGW
    pub mod mingw_init {
        // Objek permulaan MinGW (crt0.o/dllcrt0.o) akan memanggil pembangun global di bahagian .ctors dan .dtors semasa memulakan dan keluar.
        // Dalam kes DLL, ini dilakukan apabila DLL dimuat dan dibongkar.
        //
        // Pautan akan menyusun bahagian, yang memastikan bahawa panggilan balik kami terletak di hujung senarai.
        // Oleh kerana pembina dijalankan dalam urutan terbalik, ini memastikan bahawa panggilan balik kami adalah yang pertama dan terakhir dilaksanakan.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: Panggilan awal permulaan C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Panggilan penamatan C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}