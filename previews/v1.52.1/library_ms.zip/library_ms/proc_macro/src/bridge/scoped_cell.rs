//! `Cell` varian untuk jangka hayat eksistensial (scoped).

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// Taipkan aplikasi lambda, seumur hidup.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// Ketik lambda sepanjang hayat, iaitu, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) atasi had unjuran dengan newtype FIXME(#52812) ganti dengan `&'a mut <T as ApplyL<'b>>::Out`
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// Menetapkan nilai dalam `self` ke `replacement` semasa menjalankan `f`, yang mendapat nilai lama, secara bergantian.
    /// Nilai lama akan dipulihkan setelah `f` keluar, walaupun oleh panic, termasuk pengubahsuaian yang dibuat oleh `f`.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// Pembungkus yang memastikan sel sentiasa terisi (dengan keadaan asalnya, secara opsional diubah oleh `f`), walaupun `f` panik.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// Menetapkan nilai dalam `self` ke `value` semasa menjalankan `f`.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}