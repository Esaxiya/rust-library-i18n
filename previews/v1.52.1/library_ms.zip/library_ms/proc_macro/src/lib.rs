//! Perpustakaan sokongan untuk pengarang makro semasa menentukan makro baru.
//!
//! Perpustakaan ini, yang disediakan oleh distribusi standard, menyediakan jenis yang digunakan dalam antarmuka definisi makro yang ditentukan secara prosedur seperti makro seperti fungsi `#[proc_macro]`, atribut makro `#[proc_macro_attribute]` dan atribut turunan khas`#[proc_macro_derive]`.
//!
//!
//! Lihat [the book] untuk lebih banyak lagi.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Menentukan sama ada proc_macro telah diakses oleh program yang sedang berjalan.
///
/// Proc_macro crate hanya ditujukan untuk digunakan dalam pelaksanaan makro prosedur.Semua fungsi dalam crate panic ini jika dipanggil dari luar makro prosedur, seperti dari skrip binaan atau ujian unit atau binari Rust biasa.
///
/// Dengan pertimbangan untuk perpustakaan Rust yang dirancang untuk menyokong kes penggunaan makro dan bukan makro, `proc_macro::is_available()` menyediakan cara yang tidak panik untuk mengesan sama ada infrastruktur yang diperlukan untuk menggunakan API proc_macro tersedia sekarang.
/// Mengembalikan benar jika dipanggil dari dalam makro prosedur, salah jika dipanggil dari binari lain.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Jenis utama yang disediakan oleh crate ini, mewakili aliran abstrak tokens, atau, lebih khusus lagi, urutan pokok token.
/// Jenis ini menyediakan antara muka untuk mengulangi pokok token tersebut dan, sebaliknya, mengumpulkan sebilangan pokok token ke dalam satu aliran.
///
///
/// Ini adalah input dan output definisi `#[proc_macro]`, `#[proc_macro_attribute]` dan `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Ralat dikembalikan dari `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Mengembalikan `TokenStream` kosong yang tidak mengandungi pokok token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Periksa sama ada `TokenStream` ini kosong.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Percubaan untuk memecahkan rentetan menjadi tokens dan menguraikan tokens tersebut ke aliran token.
/// Mungkin gagal kerana beberapa sebab, misalnya, jika rentetan mengandungi pembatas yang tidak seimbang atau watak yang tidak ada dalam bahasa.
///
/// Semua tokens dalam aliran yang dihuraikan mendapat jarak `Span::call_site()`.
///
/// NOTE: beberapa kesilapan boleh menyebabkan panics dan bukannya mengembalikan `LexError`.Kami berhak mengubah kesilapan ini menjadi `LexError`s kemudian.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, jambatan itu hanya menyediakan `to_string`, melaksanakan `fmt::Display` berdasarkannya (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Mencetak aliran token sebagai rentetan yang seharusnya dapat dikembalikan tanpa kerugian menjadi aliran token yang sama (rentang modulo), kecuali kemungkinan `TokenTree: : Group`s dengan pembatas `Delimiter::None` dan literal numerik negatif.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Mencetak token dalam bentuk yang sesuai untuk penyahpepijatan.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Membuat aliran token yang mengandungi pokok token tunggal.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Mengumpulkan sebilangan pokok token ke dalam satu aliran.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Operasi "flattening" pada aliran token, mengumpulkan pokok token dari beberapa aliran token ke dalam satu aliran.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Gunakan kemungkinan pelaksanaan if/when yang dioptimumkan.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Perincian pelaksanaan awam untuk jenis `TokenStream`, seperti iterator.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Pengulangan mengenai TokenStream "TokenTree".
    /// Pengulangan adalah "shallow", misalnya, iterator tidak berulang menjadi kumpulan yang dibatasi, dan mengembalikan keseluruhan kumpulan sebagai pokok token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` menerima tokens sewenang-wenangnya dan berkembang menjadi `TokenStream` yang menerangkan inputnya.
/// Sebagai contoh, `quote!(a + b)` akan menghasilkan ungkapan, yang apabila dinilai, membina `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Tanda kutip dilakukan dengan `$`, dan berfungsi dengan menggunakan satu tanda seterusnya sebagai istilah tidak disebut.
/// Untuk memetik `$` itu sendiri, gunakan `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Kawasan kod sumber, bersama dengan maklumat pengembangan makro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Membuat `Diagnostic` baru dengan `message` yang diberikan pada jarak `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Jangka masa yang dapat diselesaikan di laman definisi makro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Jangka waktu pemakaian makro prosedur semasa.
    /// Pengecam yang dibuat dengan rentang ini akan diselesaikan seolah-olah ia ditulis secara langsung di lokasi panggilan makro (kebersihan laman panggilan) dan kod lain di laman panggilan makro akan dapat merujuknya juga.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Jangkauan yang mewakili kebersihan `macro_rules`, dan kadang kala diselesaikan di laman definisi makro (pemboleh ubah tempatan, label, `$crate`) dan kadang-kadang di laman panggilan makro (yang lain).
    ///
    /// Lokasi jarak diambil dari laman panggilan.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Fail sumber asal ke mana rentang ini menunjukkan.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` untuk tokens dalam pengembangan makro sebelumnya dari mana `self` dihasilkan, jika ada.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Jangka masa untuk kod sumber asal dari mana `self` dihasilkan.
    /// Sekiranya `Span` ini tidak dihasilkan dari pengembangan makro lain, maka nilai pengembaliannya sama dengan `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Mendapat line/column permulaan dalam fail sumber untuk jangka masa ini.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Mendapat line/column akhir dalam fail sumber untuk jangka masa ini.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Membuat rentang baru yang merangkumi `self` dan `other`.
    ///
    /// Mengembalikan `None` jika `self` dan `other` berasal dari fail yang berbeza.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Membuat rentang baru dengan maklumat line/column yang sama dengan `self` tetapi itu menyelesaikan simbol seolah-olah berada di `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Membuat rentang baru dengan tingkah laku resolusi nama yang sama dengan `self` tetapi dengan maklumat line/column `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Berbanding dengan jarak untuk melihat sama ada sama.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Mengembalikan teks sumber di belakang jangka masa.
    /// Ini mengekalkan kod sumber asal, termasuk ruang dan komen.
    /// Ia hanya memberikan hasil jika span sesuai dengan kod sumber sebenar.
    ///
    /// Note: Hasil makro yang dapat dilihat hanya bergantung pada tokens dan bukan pada teks sumber ini.
    ///
    /// Hasil fungsi ini adalah usaha terbaik untuk digunakan untuk diagnostik sahaja.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Mencetak rentang dalam bentuk yang sesuai untuk penyahpepijatan.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Pasangan lajur baris yang mewakili permulaan atau akhir `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Baris 1-indeks dalam fail sumber di mana jangka masa bermula atau berakhir (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Lajur 0-diindeks (dalam aksara UTF-8) dalam fail sumber di mana rentang bermula atau berakhir (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Fail sumber `Span` yang diberikan.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Mendapat jalan ke fail sumber ini.
    ///
    /// ### Note
    /// Sekiranya rentang kod yang dikaitkan dengan `SourceFile` ini dihasilkan oleh makro luaran, makro ini, ini mungkin bukan jalan sebenarnya pada sistem fail.
    /// Gunakan [`is_real`] untuk memeriksa.
    ///
    /// Perhatikan juga bahawa walaupun `is_real` mengembalikan `true`, jika `--remap-path-prefix` dilewatkan pada baris perintah, jalan seperti yang diberikan mungkin sebenarnya tidak sah.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Mengembalikan `true` jika fail sumber ini adalah fail sumber sebenar, dan tidak dihasilkan oleh pengembangan makro luaran.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Ini adalah peretasan sehingga rentang interkrit dilaksanakan dan kita dapat memiliki fail sumber sebenar untuk rentang yang dihasilkan dalam makro luaran.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token tunggal atau urutan had pokok token (contohnya, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Aliran token dikelilingi oleh pembatas pendakap.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Pengecam.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Watak tanda baca tunggal (`+`, `,`, `$`, dll.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Aksara literal (`'a'`), rentetan (`"hello"`), nombor (`2.3`), dll.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Mengembalikan rentang pokok ini, mewakilkan kepada kaedah `span` token yang terkandung atau aliran yang dipisahkan.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Mengkonfigurasi jangka masa untuk *hanya token* ini.
    ///
    /// Perhatikan bahawa jika token ini adalah `Group` maka kaedah ini tidak akan mengkonfigurasi rentang setiap tokens dalaman, ini hanya akan mewakilkan kepada kaedah `set_span` setiap varian.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Mencetak pokok token dalam bentuk yang sesuai untuk penyahpepijatan.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Masing-masing mempunyai nama dalam jenis struktur dalam debug yang diturunkan, jadi jangan repot-repot dengan lapisan pengarahan tambahan
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, jambatan itu hanya menyediakan `to_string`, melaksanakan `fmt::Display` berdasarkannya (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Mencetak pokok token sebagai rentetan yang seharusnya dapat diubah kembali menjadi pokok token (modulo span) yang sama, kecuali kemungkinan `TokenTree: : Group`s dengan pembatas `Delimiter::None` dan literal numerik negatif.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Aliran token yang dipisahkan.
///
/// `Group` secara dalaman mengandungi `TokenStream` yang dikelilingi oleh `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Menerangkan bagaimana urutan pokok token dibatasi.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Pembatas tersirat, yang mungkin, misalnya, muncul di sekitar tokens yang berasal dari "macro variable" `$var`.
    /// Penting untuk mengekalkan keutamaan pengendali dalam kes seperti `$var * 3` di mana `$var` adalah `1 + 2`.
    /// Pembatas yang tersirat mungkin tidak dapat bertahan dari perjalanan pusingan aliran token melalui rentetan.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Membuat `Group` baru dengan pembatas yang diberikan dan aliran token.
    ///
    /// Pembina ini akan menetapkan jangka masa untuk kumpulan ini ke `Span::call_site()`.
    /// Untuk menukar jangka masa anda boleh menggunakan kaedah `set_span` di bawah.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Mengembalikan pembatas `Group` ini
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Mengembalikan `TokenStream` tokens yang dibatasi dalam `Group` ini.
    ///
    /// Perhatikan bahawa aliran token yang dikembalikan tidak termasuk pembatas yang dikembalikan di atas.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Mengembalikan jangka masa bagi pembatas aliran token ini, merangkumi keseluruhan `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Mengembalikan rentang yang menunjukkan pembatas pembukaan kumpulan ini.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Mengembalikan rentang yang menunjuk ke pembatas penutup kumpulan ini.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Mengkonfigurasi jangka masa untuk pembatas Kumpulan ini, tetapi bukan tokens dalamannya.
    ///
    /// Kaedah ini **tidak** akan menetapkan rentang semua tokens dalaman yang dibentangkan oleh kumpulan ini, tetapi ia hanya akan menetapkan rentang pembatas tokens pada tahap `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, jambatan itu hanya menyediakan `to_string`, melaksanakan `fmt::Display` berdasarkannya (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Mencetak kumpulan sebagai rentetan yang boleh ditukar tanpa kerugian menjadi kumpulan yang sama (modulo span), kecuali kemungkinan `TokenTree: : Group`s dengan pembatas `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` adalah watak tanda baca tunggal seperti `+`, `-` atau `#`.
///
/// Pengendali pelbagai watak seperti `+=` ditunjukkan sebagai dua contoh `Punct` dengan bentuk `Spacing` yang berbeza dikembalikan.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Sama ada `Punct` diikuti dengan segera oleh `Punct` lain atau diikuti oleh token atau ruang kosong yang lain.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// contohnya, `+` adalah `Alone` dalam `+ =`, `+ident` atau `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// contohnya, `+` adalah `Joint` dalam `+=` atau `'#`.
    /// Selain itu, petikan tunggal `'` boleh bergabung dengan pengecam untuk membentuk jangka hayat `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Membuat `Punct` baru dari watak dan jarak yang diberikan.
    /// Argumen `ch` mestilah watak tanda baca yang sah yang dibenarkan oleh bahasa, jika tidak, fungsi tersebut akan panic.
    ///
    /// `Punct` yang dikembalikan akan mempunyai rentang lalai `Span::call_site()` yang dapat dikonfigurasi lebih lanjut dengan kaedah `set_span` di bawah.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Mengembalikan nilai watak tanda baca ini sebagai `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Mengembalikan jarak watak tanda baca ini, menunjukkan sama ada ia diikuti oleh `Punct` lain dalam aliran token, sehingga mereka berpotensi digabungkan menjadi pengendali (`Joint`) berbilang watak, atau diikuti oleh beberapa token atau ruang kosong (`Alone`) yang lain sehingga operator sudah tentu berakhir.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Mengembalikan jangka masa untuk tanda baca ini.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurasikan rentang untuk watak tanda baca ini.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, jambatan itu hanya menyediakan `to_string`, melaksanakan `fmt::Display` berdasarkannya (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Mencetak tanda baca sebagai rentetan yang seharusnya boleh ditukar semula menjadi watak yang sama.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Pengecam (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Membuat `Ident` baru dengan `string` yang diberikan serta `span` yang ditentukan.
    /// Argumen `string` mestilah pengecam yang sah yang dibenarkan oleh bahasa (termasuk kata kunci, misalnya `self` atau `fn`).Jika tidak, fungsi akan panic.
    ///
    /// Perhatikan bahawa `span`, yang kini berada di rustc, mengkonfigurasi maklumat kebersihan untuk pengecam ini.
    ///
    /// Pada masa ini `Span::call_site()` secara eksplisit memilih kebersihan "call-site" yang bermaksud bahawa pengecam yang dibuat dengan jangka masa ini akan diselesaikan seolah-olah ia ditulis secara langsung di lokasi panggilan makro, dan kod lain di laman panggilan makro akan dapat merujuk mereka juga.
    ///
    ///
    /// Jangkauan kemudian seperti `Span::def_site()` akan memungkinkan untuk memilih kebersihan "definition-site" yang bermaksud bahawa pengecam yang dibuat dengan jangka masa ini akan diselesaikan di lokasi definisi makro dan kod lain di laman panggilan makro tidak dapat merujuknya.
    ///
    /// Oleh kerana pentingnya kebersihan semasa, konstruktor ini, tidak seperti tokens yang lain, memerlukan `Span` ditentukan semasa pembinaan.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Sama dengan `Ident::new`, tetapi mencipta pengenal mentah (`r#ident`).
    /// Argumen `string` menjadi pengecam yang sah yang dibenarkan oleh bahasa (termasuk kata kunci, misalnya `fn`).
    /// Kata kunci yang boleh digunakan dalam segmen jalan (mis
    /// `self`, `super`) tidak disokong, dan akan menyebabkan panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Mengembalikan jangka masa `Ident` ini, merangkumi keseluruhan rentetan yang dikembalikan oleh [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Mengkonfigurasi jangka masa `Ident` ini, mungkin mengubah konteks kebersihannya.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, jambatan itu hanya menyediakan `to_string`, melaksanakan `fmt::Display` berdasarkannya (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Mencetak pengecam sebagai rentetan yang boleh ditukar tanpa kehilangan menjadi pengecam yang sama.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Rentetan literal (`"hello"`), rentetan bait (`b"hello"`), watak (`'a'`), watak bait (`b'a'`), nombor bulat atau bilangan terapung dengan atau tanpa akhiran (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Huruf Boolean seperti `true` dan `false` tidak termasuk di sini, mereka adalah `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Membuat literal integer akhiran baru dengan nilai yang ditentukan.
        ///
        /// Fungsi ini akan membuat integer seperti `1u32` di mana nilai integer yang ditentukan adalah bahagian pertama token dan integral juga akhiran di akhir.
        /// Literal yang dihasilkan dari nombor negatif mungkin tidak dapat bertahan dalam perjalanan pergi balik hingga `TokenStream` atau rentetan dan boleh dipecah menjadi dua tokens (`-` dan literal positif).
        ///
        ///
        /// Literal yang dibuat melalui kaedah ini memiliki rentang `Span::call_site()` secara lalai, yang dapat dikonfigurasi dengan kaedah `set_span` di bawah.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Membuat literal integer baru yang belum diselesaikan dengan nilai yang ditentukan.
        ///
        /// Fungsi ini akan membuat integer seperti `1` di mana nilai integer yang ditentukan adalah bahagian pertama token.
        /// Tidak ada akhiran yang ditentukan pada token ini, yang bermaksud bahawa doa seperti `Literal::i8_unsuffixed(1)` bersamaan dengan `Literal::u32_unsuffixed(1)`.
        /// Literal yang dibuat dari nombor negatif mungkin tidak dapat bertahan dari rountrips melalui `TokenStream` atau rentetan dan boleh dipecah menjadi dua tokens (`-` dan literal positif).
        ///
        ///
        /// Literal yang dibuat melalui kaedah ini memiliki rentang `Span::call_site()` secara lalai, yang dapat dikonfigurasi dengan kaedah `set_span` di bawah.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Membuat literal titik terapung yang belum diselesaikan.
    ///
    /// Pembina ini serupa dengan yang seperti `Literal::i8_unsuffixed` di mana nilai apungan dipancarkan terus ke token tetapi tidak ada akhiran yang digunakan, jadi mungkin disimpulkan sebagai `f64` kemudian di penyusun.
    ///
    /// Literal yang dibuat dari nombor negatif mungkin tidak dapat bertahan dari rountrips melalui `TokenStream` atau rentetan dan boleh dipecah menjadi dua tokens (`-` dan literal positif).
    ///
    /// # Panics
    ///
    /// Fungsi ini mensyaratkan bahawa apungan yang ditentukan adalah terhad, misalnya jika tidak terhingga atau NaN fungsi ini akan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Membuat literal titik terapung akhiran baru.
    ///
    /// Pembina ini akan membuat literal seperti `1.0f32` di mana nilai yang ditentukan adalah bahagian sebelumnya dari token dan `f32` adalah akhiran token.
    /// token ini akan selalu disimpulkan sebagai `f32` dalam penyusun.
    /// Literal yang dibuat dari nombor negatif mungkin tidak dapat bertahan dari rountrips melalui `TokenStream` atau rentetan dan boleh dipecah menjadi dua tokens (`-` dan literal positif).
    ///
    ///
    /// # Panics
    ///
    /// Fungsi ini mensyaratkan bahawa apungan yang ditentukan adalah terhad, misalnya jika tidak terhingga atau NaN fungsi ini akan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Membuat literal titik terapung yang belum diselesaikan.
    ///
    /// Pembina ini serupa dengan yang seperti `Literal::i8_unsuffixed` di mana nilai apungan dipancarkan terus ke token tetapi tidak ada akhiran yang digunakan, jadi mungkin disimpulkan sebagai `f64` kemudian di penyusun.
    ///
    /// Literal yang dibuat dari nombor negatif mungkin tidak dapat bertahan dari rountrips melalui `TokenStream` atau rentetan dan boleh dipecah menjadi dua tokens (`-` dan literal positif).
    ///
    /// # Panics
    ///
    /// Fungsi ini mensyaratkan bahawa apungan yang ditentukan adalah terhad, misalnya jika tidak terhingga atau NaN fungsi ini akan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Membuat literal titik terapung akhiran baru.
    ///
    /// Pembina ini akan membuat literal seperti `1.0f64` di mana nilai yang ditentukan adalah bahagian sebelumnya dari token dan `f64` adalah akhiran token.
    /// token ini akan selalu disimpulkan sebagai `f64` dalam penyusun.
    /// Literal yang dibuat dari nombor negatif mungkin tidak dapat bertahan dari rountrips melalui `TokenStream` atau rentetan dan boleh dipecah menjadi dua tokens (`-` dan literal positif).
    ///
    ///
    /// # Panics
    ///
    /// Fungsi ini mensyaratkan bahawa apungan yang ditentukan adalah terhad, misalnya jika tidak terhingga atau NaN fungsi ini akan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Huruf watak.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// String bait literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Mengembalikan jangka masa yang merangkumi literal ini.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Mengkonfigurasi jangka masa yang berkaitan untuk literal ini.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Mengembalikan `Span` yang merupakan subset `self.span()` yang hanya mengandungi bait sumber dalam julat `range`.
    /// Mengembalikan `None` jika jangka masa yang hendak dipangkas berada di luar batas `self`.
    ///
    // FIXME(SergioBenitez): periksa bahawa julat bait bermula dan berakhir pada had sumber UTF-8.
    // jika tidak, kemungkinan panic akan berlaku di tempat lain semasa teks sumber dicetak.
    // FIXME(SergioBenitez): tidak ada cara bagi pengguna untuk mengetahui peta `self.span()` sebenarnya, jadi kaedah ini pada masa ini hanya boleh disebut secara membuta tuli.
    // Contohnya, `to_string()` untuk watak 'c' mengembalikan "'\u{63}'";tidak ada cara bagi pengguna untuk mengetahui sama ada teks sumbernya adalah 'c' atau sama ada '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) sesuatu yang serupa dengan `Option::cloned`, tetapi untuk `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, jambatan itu hanya menyediakan `to_string`, melaksanakan `fmt::Display` berdasarkannya (kebalikan dari hubungan biasa antara keduanya).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Mencetak literal sebagai rentetan yang seharusnya dapat diubah kembali menjadi literal yang sama (kecuali kemungkinan pembundaran untuk literal floating point).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Akses yang dijejaki ke pemboleh ubah persekitaran.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Dapatkan pemboleh ubah persekitaran dan tambahkan untuk membina maklumat ketergantungan.
    /// Sistem binaan yang melaksanakan penyusun akan mengetahui bahawa pemboleh ubah telah diakses semasa penyusunan, dan akan dapat menjalankan kembali binaan apabila nilai pemboleh ubah tersebut berubah.
    ///
    /// Selain bergantung pada fungsi ini fungsi harus setara dengan `env::var` dari pustaka standard, kecuali bahawa argumennya mestilah UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}