#![feature(no_core)]
#![no_core]

// Lihat rustc-std-ruang kerja-teras untuk mengapa crate ini diperlukan.

// Namakan semula crate untuk mengelakkan percanggahan dengan modul peruntukan di liballoc.
extern crate alloc as foo;

pub use foo::*;