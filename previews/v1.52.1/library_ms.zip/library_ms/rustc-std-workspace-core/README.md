# The `rustc-std-workspace-core` crate

crate ini adalah crate yang kosong dan kosong yang hanya bergantung pada `libcore` dan mengeksport semula semua kandungannya.
crate adalah asas memperkasakan perpustakaan standard untuk bergantung pada crates dari crates.io

Crates pada crates.io yang bergantung pada pustaka standard perlu bergantung pada `rustc-std-workspace-core` crate dari crates.io, yang kosong.

Kami menggunakan `[patch]` untuk menimpanya ke crate ini di repositori ini.
Hasilnya, crates pada crates.io akan menarik ketergantungan edge ke `libcore`, versi yang ditentukan dalam repositori ini.
Itu mesti menarik semua kebergantungan untuk memastikan Cargo membina crates dengan jayanya!

Perhatikan bahawa crates pada crates.io perlu bergantung pada crate ini dengan nama `core` agar semuanya berfungsi dengan betul.Untuk melakukan itu mereka boleh menggunakan:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Melalui penggunaan kunci `package`, crate dinamakan semula menjadi `core`, yang bermaksud ia akan kelihatan seperti

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

apabila Cargo memanggil pengkompil, memenuhi arahan `extern crate core` tersirat yang disuntik oleh penyusun.




