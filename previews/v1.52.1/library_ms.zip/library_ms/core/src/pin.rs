//! Jenis yang menyematkan data ke lokasinya dalam memori.
//!
//! Kadang-kadang berguna untuk memiliki objek yang dijamin tidak dapat bergerak, dalam arti penempatannya dalam memori tidak berubah, dan dengan demikian dapat diandalkan.
//! Contoh utama senario seperti itu adalah membangun struktur referensi diri, kerana memindahkan objek dengan petunjuk ke dirinya sendiri akan membatalkannya, yang boleh menyebabkan tingkah laku yang tidak ditentukan.
//!
//! Pada tahap tinggi, [`Pin<P>`] memastikan bahawa pointee dari mana-mana jenis penunjuk `P` mempunyai lokasi yang stabil dalam memori, yang bermaksud ia tidak dapat dipindahkan ke tempat lain dan ingatannya tidak dapat dialihkan sehingga ia jatuh.Kami mengatakan bahawa pointee adalah "pinned".Perkara menjadi lebih halus ketika membincangkan jenis yang menggabungkan data yang disematkan dengan data yang tidak disematkan;[see below](#projections-and-structural-pinning) untuk maklumat lebih lanjut.
//!
//! Secara lalai, semua jenis dalam Rust boleh bergerak.
//! Rust membolehkan melepasi semua jenis dengan nilai, dan jenis penunjuk pintar biasa seperti [`Box<T>`] dan `&mut T` memungkinkan untuk mengganti dan memindahkan nilai yang ada di dalamnya: anda boleh keluar dari [`Box<T>`], atau anda boleh menggunakan [`mem::swap`].
//! [`Pin<P>`] membungkus pointer jenis `P`, jadi [`Pin`]`<`[`Box`] `<T>> berfungsi seperti biasa
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Kotak`] `<T>>"dijatuhkan, begitu juga kandungannya, dan ingatannya bertambah
//!
//! menyahpindah.Begitu juga, [`Pin`]`<&mut T>`sama seperti `&mut T`.Namun, [`Pin<P>`] tidak membiarkan klien benar-benar memperoleh [`Box<T>`] atau `&mut T` ke data yang disematkan, yang menunjukkan bahawa anda tidak dapat menggunakan operasi seperti [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` memerlukan `&mut T`, tetapi kami tidak dapat mendapatkannya.
//!     // Kami buntu, kami tidak dapat menukar isi rujukan ini.
//!     // Kami boleh menggunakan `Pin::get_unchecked_mut`, tetapi itu tidak selamat kerana:
//!     // kami tidak dibenarkan menggunakannya untuk mengeluarkan barang dari `Pin`.
//! }
//! ```
//!
//! Perlu dinyatakan bahawa [`Pin<P>`] tidak *mengubah hakikat bahawa penyusun Rust menganggap semua jenis boleh bergerak.[`mem::swap`] tetap boleh dipanggil untuk mana-mana `T`.Sebaliknya, [`Pin<P>`] menghalang* nilai * tertentu (ditunjukkan oleh penunjuk yang dibungkus [`Pin<P>`]) daripada dipindahkan dengan menjadikan kaedah yang tidak memerlukan panggilan `&mut T` tidak mustahil (seperti [`mem::swap`]).
//!
//! [`Pin<P>`] boleh digunakan untuk membungkus pointer jenis `P`, dan dengan itu ia berinteraksi dengan [`Deref`] dan [`DerefMut`].[`Pin<P>`] di mana `P: Deref` harus dianggap sebagai "`P`-style pointer" ke `P::Target` yang disematkan-jadi, ["Pin"] "<" ["Kotak"] "<T>>`adalah penunjuk yang dimiliki ke `T` yang disematkan, dan [`Pin`] `<` [`Rc`]`<T>>`adalah penunjuk yang dikira rujukan ke `T` yang disematkan.
//! Untuk kebenaran, [`Pin<P>`] bergantung pada implementasi [`Deref`] dan [`DerefMut`] untuk tidak keluar dari parameter `self` mereka, dan hanya untuk mengembalikan pointer ke data yang disematkan ketika mereka dipanggil pada pointer yang disematkan.
//!
//! # `Unpin`
//!
//! Banyak jenis selalu bergerak bebas, walaupun disematkan, kerana tidak bergantung pada alamat yang stabil.Ini merangkumi semua jenis asas (seperti [`bool`], [`i32`], dan rujukan) serta jenis yang hanya terdiri daripada jenis ini.Jenis yang tidak peduli dengan pemasangan pin menerapkan [`Unpin`] auto-trait, yang membatalkan kesan [`Pin<P>`].
//! Untuk `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`dan [`Box<T>`] berfungsi sama, seperti halnya [`Pin`] `<&mut T>` dan `&mut T`.
//!
//! Perhatikan bahawa penyematan dan [`Unpin`] hanya mempengaruhi jenis `P::Target` yang runcing, bukan jenis penunjuk `P` itu sendiri yang dibungkus [`Pin<P>`].Contohnya, sama ada [`Box<T>`] adalah [`Unpin`] atau tidak tidak mempengaruhi tingkah laku [`Pin`]`<`[`Box`] `<T>> (di sini, `T` adalah jenis runcing).
//!
//! # Contoh: struktur rujukan diri
//!
//! Sebelum kita membahas lebih terperinci untuk menjelaskan jaminan dan pilihan yang berkaitan dengan `Pin<T>`, kita membincangkan beberapa contoh bagaimana ia boleh digunakan.
//! Jangan ragu untuk [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ini adalah struktur rujukan diri kerana medan slice menunjuk ke medan data.
//! // Kami tidak dapat memberitahu penyusun mengenai hal itu dengan rujukan biasa, kerana corak ini tidak dapat dijelaskan dengan peraturan peminjaman biasa.
//! //
//! // Sebagai gantinya, kami menggunakan penunjuk mentah, walaupun salah satu yang diketahui tidak batal, seperti yang kita tahu, ia menunjuk pada tali.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Untuk memastikan data tidak bergerak ketika fungsinya kembali, kami meletakkannya di timbunan di mana ia akan bertahan sepanjang hayat objek, dan satu-satunya cara untuk mengaksesnya adalah melalui penunjuk ke sana.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // kami hanya membuat penunjuk setelah data berada di tempat lain jika tidak, data tersebut sudah dapat dipindahkan sebelum kami memulakannya
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // kita tahu ini selamat kerana mengubah medan tidak dapat menggerakkan keseluruhan struktur
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Penunjuk harus menunjukkan lokasi yang betul, selagi strukturnya tidak bergerak.
//! //
//! // Sementara itu, kami bebas menggerakkan penunjuk.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Oleh kerana jenis kami tidak melaksanakan Unpin, ini akan gagal disusun:
//! // biarkan mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Contoh: senarai berangkai dua yang mengganggu
//!
//! Dalam senarai dua kali ganda yang mengganggu, koleksi itu sebenarnya tidak memperuntukkan memori untuk elemen itu sendiri.
//! Peruntukan dikendalikan oleh pelanggan, dan elemen dapat hidup pada kerangka tumpukan yang hidup lebih pendek dari koleksi.
//!
//! Untuk membuat karya ini, setiap elemen mempunyai petunjuk kepada pendahulunya dan penggantinya dalam senarai.Elemen hanya dapat ditambahkan ketika disematkan, kerana memindahkan elemen di sekitar akan membatalkan petunjuk.Lebih-lebih lagi, pelaksanaan [`Drop`] elemen senarai terpaut akan menambal petunjuk pendahulunya dan penggantinya untuk mengeluarkan dirinya dari senarai.
//!
//! Yang penting, kita mesti bergantung pada panggilan [`drop`].Sekiranya elemen dapat dialokasikan atau dibatalkan tanpa memanggil [`drop`], penunjuk ke dalamnya dari elemen tetangganya akan menjadi tidak sah, yang akan memecahkan struktur data.
//!
//! Oleh itu, penyematan juga disertakan dengan jaminan yang berkaitan dengan [`drop`].
//!
//! # `Drop` guarantee
//!
//! Tujuan penyematan adalah untuk dapat bergantung pada penempatan beberapa data dalam memori.
//! Untuk membuat ini berfungsi, tidak hanya memindahkan data yang dibatasi;menyekat, menyusun semula, atau membatalkan memori yang digunakan untuk menyimpan data juga dibatasi.
//! Secara konkrit, untuk data yang disematkan, anda harus mengekalkan invarian yang *ingatannya tidak akan dibatalkan atau diubah dari saat ia disematkan sehingga ketika [`drop`] dipanggil*.Hanya sekali [`drop`] kembali atau panics, memori boleh digunakan semula.
//!
//! Memori boleh menjadi "invalidated" dengan deallokasi, tetapi juga dengan menggantikan [`Some(v)`] dengan [`None`], atau memanggil [`Vec::set_len`] ke "kill" beberapa elemen dari vector.Ia boleh diubah dengan menggunakan [`ptr::write`] untuk menimpanya tanpa memanggil pemusnah terlebih dahulu.Tiada satu pun yang dibenarkan untuk data yang disematkan tanpa memanggil [`drop`].
//!
//! Ini adalah jenis jaminan bahawa senarai pautan yang mengganggu dari bahagian sebelumnya perlu berfungsi dengan betul.
//!
//! Perhatikan bahawa jaminan ini *tidak* bermaksud bahawa memori tidak bocor!Masih baik-baik saja untuk tidak memanggil [`drop`] pada elemen yang disematkan (contohnya, anda masih boleh memanggil [`mem::forget`] pada [`Pin`]`<`[`Box ']`<T>> `).Dalam contoh senarai berangkai dua kali, elemen itu akan kekal dalam senarai.Walau bagaimanapun, anda mungkin tidak membebaskan atau menggunakan semula storan *tanpa memanggil [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Sekiranya jenis anda menggunakan pinning (seperti dua contoh di atas), anda harus berhati-hati semasa melaksanakan [`Drop`].Fungsi [`drop`] memerlukan `&mut self`, tetapi ini dipanggil *walaupun jenis anda sebelumnya disematkan*!Seolah-olah penyusun dipanggil [`Pin::get_unchecked_mut`] secara automatik.
//!
//! Ini tidak akan pernah menyebabkan masalah dalam kod selamat kerana menerapkan jenis yang bergantung pada pin memerlukan kod yang tidak selamat, tetapi perlu diketahui bahawa memutuskan untuk menggunakan pin pada jenis anda (misalnya dengan melaksanakan beberapa operasi pada [`Pin`]`<&Self>`atau [`Pin`] `<&mut Self>`) mempunyai akibat untuk pelaksanaan [`Drop`] anda juga: jika elemen jenis anda mungkin telah disematkan, anda mesti menganggap [`Drop`] secara tidak langsung mengambil [`Pin`]`<&mut Diri>`.
//!
//!
//! Sebagai contoh, anda boleh melaksanakan `Drop` seperti berikut:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` tidak mengapa kerana kita tahu nilai ini tidak akan digunakan lagi setelah dijatuhkan.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Kod penurunan yang sebenarnya ada di sini.
//!         }
//!     }
//! }
//! ```
//!
//! Fungsi `inner_drop` mempunyai jenis yang seharusnya dimiliki oleh [`drop`] *, jadi ini memastikan bahawa anda tidak menggunakan `self`/`this` secara tidak sengaja dengan cara yang bertentangan dengan pin.
//!
//! Lebih-lebih lagi, jika jenis anda adalah `#[repr(packed)]`, penyusun akan memindahkan medan secara automatik untuk dapat menjatuhkannya.Ia mungkin berlaku untuk bidang yang selaras cukup.Akibatnya, anda tidak boleh menggunakan pin dengan jenis `#[repr(packed)]`.
//!
//! # Unjuran dan Pemasangan Pin
//!
//! Ketika bekerja dengan struktur tersemat, timbul pertanyaan bagaimana seseorang dapat mengakses bidang struktur tersebut dengan metode yang hanya memerlukan [`Pin`]`<&mut Struct>`.
//! Pendekatan yang biasa dilakukan adalah menulis kaedah pembantu (disebut *unjuran*) yang menjadikan [`Pin`]`<&mut Struct>`menjadi rujukan ke lapangan, tetapi jenis apa yang harus dimiliki oleh rujukan itu?Adakah [`Pin`]`<&mut Field>`atau `&mut Field`?
//! Soalan yang sama timbul dengan bidang `enum`, dan juga ketika mempertimbangkan jenis container/wrapper seperti [`Vec<T>`], [`Box<T>`], atau [`RefCell<T>`].
//! (Soalan ini berlaku untuk rujukan yang dapat diubah dan dikongsi, kami hanya menggunakan contoh rujukan yang dapat diubah yang lebih biasa di sini sebagai gambaran.)
//!
//! Ternyata itu sebenarnya bergantung kepada pengarang struktur data untuk memutuskan sama ada unjuran yang disematkan untuk bidang tertentu berubah menjadi [`Pin`]`<&mut Struct>`menjadi [`Pin`] `<&mut Field>` atau `&mut Field`.Terdapat beberapa kekangan, dan kekangan yang paling penting adalah *ketekalan*:
//! setiap bidang dapat *baik* diproyeksikan ke rujukan yang disematkan,*atau* telah dihapus sebagai bagian dari unjuran.
//! Sekiranya kedua-duanya dilakukan untuk bidang yang sama, itu mungkin tidak masuk akal!
//!
//! Sebagai pengarang struktur data, anda boleh memutuskan untuk setiap bidang sama ada menyematkan "propagates" ke bidang ini atau tidak.
//! Pin yang disebarkan juga disebut "structural", kerana mengikut struktur jenisnya.
//! Dalam subseksyen berikut, kami menerangkan pertimbangan yang harus dibuat untuk salah satu pilihan.
//!
//! ## Menyematkan *bukan* struktur untuk `field`
//!
//! Nampaknya bertentangan intuitif bahawa bidang struktur yang disematkan mungkin tidak disematkan, tetapi sebenarnya itu adalah pilihan paling mudah: jika ["Pin"] <&mut Field> "tidak pernah dibuat, tidak ada yang salah!Oleh itu, jika anda memutuskan bahawa beberapa bidang tidak mempunyai penyematan struktur, yang harus anda pastikan ialah anda tidak pernah membuat rujukan yang disematkan ke medan tersebut.
//!
//! Medan tanpa penyematan struktur mungkin mempunyai kaedah unjuran yang mengubah [`Pin`]`<&mut Struct>`menjadi `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Ini tidak mengapa kerana `field` tidak pernah dianggap disematkan.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Anda juga mungkin `impl Unpin for Struct`*walaupun* jenis `field` bukan [`Unpin`].Apa yang difikirkan oleh jenis itu mengenai pin tidak relevan apabila tidak ada [`Pin`]`<&mut Field>`yang pernah dibuat.
//!
//! ## Pinning *adalah* struktur untuk `field`
//!
//! Pilihan lain adalah memutuskan bahawa menyematkan adalah "structural" untuk `field`, yang bermaksud bahawa jika struktur disematkan maka begitu juga bidangnya.
//!
//! Ini membolehkan menulis unjuran yang membuat [`Pin`]`<&mut Field>`, sehingga menyaksikan bahawa bidang disematkan:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Ini tidak mengapa kerana `field` disematkan semasa `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Walau bagaimanapun, pemasangan struktur dilengkapi dengan beberapa syarat tambahan:
//!
//! 1. Struktur mestilah hanya [`Unpin`] jika semua medan struktur adalah [`Unpin`].Ini adalah lalai, tetapi [`Unpin`] adalah trait yang selamat, jadi sebagai pengarang strukturnya adalah tanggungjawab anda *bukan* untuk menambahkan sesuatu seperti `impl<T> Unpin for Struct<T>`.
//! (Perhatikan bahawa menambahkan operasi unjuran memerlukan kod yang tidak selamat, jadi hakikat bahawa [`Unpin`] adalah trait yang selamat tidak melanggar prinsip bahawa anda hanya perlu bimbang tentang perkara ini jika anda menggunakan `tidak selamat '.)
//! 2. Pemusnah struktur tidak boleh mengeluarkan medan struktur daripada hujahnya.Ini adalah titik tepat yang dibangkitkan dalam [previous section][drop-impl]: `drop` mengambil `&mut self`, tetapi struktur (dan karenanya bidangnya) mungkin telah disematkan sebelumnya.
//!     Anda harus menjamin bahawa anda tidak memindahkan medan di dalam pelaksanaan [`Drop`] anda.
//!     Khususnya, seperti yang dijelaskan sebelumnya, ini bermaksud bahawa struktur anda tidak boleh `#[repr(packed)]`.
//!     Lihat bahagian itu untuk menulis [`drop`] dengan cara penyusun dapat membantu anda untuk tidak mematikan pin.
//! 3. Anda mesti memastikan bahawa anda menegakkan [`Drop` guarantee][drop-guarantee]:
//!     setelah struktur anda disematkan, memori yang mengandungi kandungan tidak akan ditimpa atau dialihkan tanpa memanggil pemusnah kandungan.
//!     Ini boleh menjadi sukar, seperti yang disaksikan oleh [`VecDeque<T>`]: pemusnah [`VecDeque<T>`] boleh gagal memanggil [`drop`] pada semua elemen jika salah satu pemusnah panics.Ini melanggar jaminan [`Drop`], kerana ia dapat menyebabkan unsur-unsur dinyahalokasi tanpa dipanggil pemusnahnya.([`VecDeque<T>`] tidak mempunyai unjuran penyematan, jadi ini tidak menyebabkan tidak masuk akal.)
//! 4. Anda tidak boleh menawarkan operasi lain yang boleh menyebabkan data dipindahkan dari medan struktur ketika jenis anda disematkan.Sebagai contoh, jika struktur mengandungi [`Option<T>`] dan terdapat operasi seperti "take" dengan jenis `fn(Pin<&mut Struct<T>>) -> Option<T>`, operasi itu dapat digunakan untuk memindahkan `T` dari `Struct<T>` yang disematkan-yang bermaksud menyematkan tidak boleh bersifat struktural untuk bidang yang memegang ini data.
//!
//!     Untuk contoh memindahkan data yang lebih kompleks dari jenis yang disematkan, bayangkan jika [`RefCell<T>`] mempunyai kaedah `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Kemudian kami dapat melakukan perkara berikut:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Ini adalah malapetaka, ini bermaksud kita dapat pertama kali menyisipkan kandungan [`RefCell<T>`] (menggunakan `RefCell::get_pin_mut`) dan kemudian memindahkan kandungan tersebut menggunakan rujukan yang dapat kita ubah kemudian.
//!
//! ## Examples
//!
//! Untuk jenis seperti [`Vec<T>`], kedua-dua kemungkinan (pemasangan struktur atau tidak) masuk akal.
//! [`Vec<T>`] dengan penyematan struktur boleh mempunyai kaedah `get_pin`/`get_pin_mut` untuk mendapatkan rujukan yang disematkan pada elemen.Namun,*tidak* membenarkan panggilan [`pop`][Vec::pop] pada [`Vec<T>`] yang disematkan kerana itu akan memindahkan kandungan (tersemat secara struktur)!Ia juga tidak boleh membenarkan [`push`][Vec::push], yang mungkin mengalokasikan semula dan juga memindahkan kandungannya.
//!
//! [`Vec<T>`] tanpa penyematan struktur boleh `impl<T> Unpin for Vec<T>`, kerana isinya tidak pernah disematkan dan [`Vec<T>`] itu sendiri baik untuk dipindahkan juga.
//! Pada ketika itu pin tidak sama sekali mempengaruhi vector.
//!
//! Di perpustakaan standard, jenis penunjuk pada umumnya tidak mempunyai penyematan struktur, dan dengan itu mereka tidak menawarkan unjuran penyematan.Inilah sebabnya mengapa `Box<T>: Unpin` berlaku untuk semua `T`.
//! Adalah wajar untuk melakukan ini untuk jenis penunjuk, kerana memindahkan `Box<T>` sebenarnya tidak menggerakkan `T`: [`Box<T>`] dapat digerakkan secara bebas (aka `Unpin`) walaupun `T` tidak.Malah, malah [`Pin`]`<`[`Box`] `<T>>`dan [`Pin`] `<&mut T>` selalu [`Unpin`] sendiri, dengan alasan yang sama: kandungannya (`T`) disematkan, tetapi penunjuk itu sendiri dapat dipindahkan tanpa memindahkan data yang disematkan.
//! Untuk kedua-dua [`Box<T>`] dan [`Pin`]`<`[`Box`] `<T>>, sama ada kandungan disematkan sepenuhnya tidak bergantung sama ada penunjuk disematkan, yang bermaksud menyematkan adalah *bukan* struktur.
//!
//! Semasa melaksanakan kombinator [`Future`], anda biasanya memerlukan penyematan struktur untuk futures bersarang, kerana anda perlu mendapatkan rujukan yang disematkan kepada mereka untuk memanggil [`poll`].
//! Tetapi jika kombinator anda mengandungi data lain yang tidak perlu disematkan, anda boleh menjadikan medan tersebut tidak struktur dan dengan itu bebas mengaksesnya dengan rujukan yang dapat diubah walaupun anda hanya mempunyai ["Pin"] <&mut Self> "(seperti seperti dalam pelaksanaan [`poll`] anda sendiri).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Penunjuk yang disematkan.
///
/// Ini adalah pembungkus sekitar jenis penunjuk yang menjadikan penunjuk "pin" nilainya pada tempatnya, mencegah nilai yang dirujuk oleh penunjuk itu dipindahkan kecuali ia menerapkan [`Unpin`].
///
///
/// *Lihat dokumentasi [`pin` module] untuk penjelasan mengenai penyematan.*
///
/// [`pin` module]: self
///
// Note: turunan `Clone` di bawah ini menyebabkan tidak masuk akal kerana kemungkinan untuk dilaksanakan
// `Clone` untuk rujukan yang boleh berubah.
// Lihat <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> untuk maklumat lebih lanjut.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Pelaksanaan berikut tidak diturunkan untuk mengelakkan masalah kesihatan.
// `&self.pointer` tidak boleh diakses untuk pelaksanaan trait yang tidak dipercayai.
//
// Lihat <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> untuk maklumat lebih lanjut.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Bina `Pin<P>` baru di sekitar penunjuk ke beberapa data jenis yang menerapkan [`Unpin`].
    ///
    /// Tidak seperti `Pin::new_unchecked`, kaedah ini selamat kerana penunjuk `P` tidak merujuk kepada jenis [`Unpin`], yang membatalkan jaminan penyematan.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // KESELAMATAN: nilai yang ditunjukkan adalah `Unpin`, sehingga tidak mempunyai syarat
        // sekitar menyematkan.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Buka bungkus `Pin<P>` ini yang mengembalikan penunjuk yang mendasari.
    ///
    /// Ini memerlukan bahawa data di dalam `Pin` ini adalah [`Unpin`] sehingga kita dapat mengabaikan invarian penyematkan ketika membongkarnya.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Bentukkan `Pin<P>` baru di sekitar rujukan ke beberapa data dari jenis yang mungkin atau mungkin tidak menerapkan `Unpin`.
    ///
    /// Sekiranya `pointer` tidak merujuk kepada jenis `Unpin`, `Pin::new` harus digunakan sebagai gantinya.
    ///
    /// # Safety
    ///
    /// Pembina ini tidak selamat kerana kami tidak dapat menjamin bahawa data yang ditunjukkan oleh `pointer` disematkan, yang bermaksud bahawa data tidak akan dipindahkan atau penyimpanannya tidak sah sehingga ia dijatuhkan.
    /// Sekiranya `Pin<P>` yang dibina tidak menjamin bahawa data yang ditunjukkan `P` disematkan, itu adalah pelanggaran kontrak API dan boleh menyebabkan tingkah laku yang tidak ditentukan dalam operasi (safe) kemudian.
    ///
    /// Dengan menggunakan kaedah ini, anda membuat promise mengenai pelaksanaan `P::Deref` dan `P::DerefMut`, jika ada.
    /// Yang paling penting, mereka tidak boleh keluar dari argumen `self` mereka: `Pin::as_mut` dan `Pin::as_ref` akan memanggil `DerefMut::deref_mut` dan `Deref::deref`*pada penunjuk yang disematkan* dan mengharapkan kaedah ini dapat menyokong invarian yang disematkan.
    /// Lebih-lebih lagi, dengan memanggil kaedah ini, anda promise bahawa rujukan `P` tidak akan dipindahkan lagi;khususnya, tidak boleh mendapatkan `&mut P::Target` dan kemudian keluar dari rujukan tersebut (menggunakan, misalnya [`mem::swap`]).
    ///
    ///
    /// Sebagai contoh, memanggil `Pin::new_unchecked` pada `&'a mut T` tidak selamat kerana semasa anda dapat menyematkannya untuk `'a` sepanjang hayat yang diberikan, anda tidak mempunyai kawalan sama ada ia tetap disematkan setelah `'a` berakhir:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Ini bermaksud pointee `a` tidak boleh bergerak lagi.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Alamat `a` berubah menjadi slot tumpukan `b`, jadi `a` berpindah walaupun sebelumnya kami telah menyematkannya!Kami telah melanggar kontrak pemasangan pin.
    /////
    /// }
    /// ```
    ///
    /// Nilai, setelah disematkan, mesti tetap disematkan selama-lamanya (kecuali jika jenisnya menggunakan `Unpin`).
    ///
    /// Begitu juga, memanggil `Pin::new_unchecked` pada `Rc<T>` tidak selamat kerana mungkin ada alias untuk data yang sama yang tidak dikenakan sekatan pin:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Ini bermaksud pointee tidak boleh bergerak lagi.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Sekarang, jika satu-satunya rujukan `x`, kami memiliki rujukan yang dapat diubah untuk data yang kami pasangkan di atas, yang dapat kami gunakan untuk memindahkannya seperti yang telah kami lihat pada contoh sebelumnya.
    ///     // Kami telah melanggar kontrak pemasangan pin.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Mendapat rujukan bersama yang disematkan dari penunjuk yang disematkan ini.
    ///
    /// Ini adalah kaedah generik untuk pergi dari `&Pin<Pointer<T>>` ke `Pin<&T>`.
    /// Ia selamat kerana, sebagai sebahagian daripada kontrak `Pin::new_unchecked`, pointee tidak dapat bergerak setelah `Pin<Pointer<T>>` dibuat.
    ///
    /// "Malicious" pelaksanaan `Pointer::Deref` juga dikesampingkan oleh kontrak `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // KESELAMATAN: lihat dokumentasi mengenai fungsi ini
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Buka bungkus `Pin<P>` ini yang mengembalikan penunjuk yang mendasari.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat.Anda mesti menjamin bahawa anda akan terus memperlihatkan penunjuk `P` seperti disematkan setelah anda memanggil fungsi ini, agar invarian pada jenis `Pin` dapat ditegakkan.
    /// Sekiranya kod yang menggunakan `P` yang dihasilkan tidak terus mengekalkan invarian penyematkan yang merupakan pelanggaran kontrak API dan boleh menyebabkan tingkah laku yang tidak ditentukan dalam operasi (safe) kemudian.
    ///
    ///
    /// Sekiranya data yang mendasari adalah [`Unpin`], [`Pin::into_inner`] harus digunakan sebagai gantinya.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Mendapat rujukan yang dapat disatukan yang disematkan dari penunjuk yang disematkan ini.
    ///
    /// Ini adalah kaedah generik untuk pergi dari `&mut Pin<Pointer<T>>` ke `Pin<&mut T>`.
    /// Ia selamat kerana, sebagai sebahagian daripada kontrak `Pin::new_unchecked`, pointee tidak dapat bergerak setelah `Pin<Pointer<T>>` dibuat.
    ///
    /// "Malicious" pelaksanaan `Pointer::DerefMut` juga dikesampingkan oleh kontrak `Pin::new_unchecked`.
    ///
    /// Kaedah ini berguna semasa melakukan beberapa panggilan ke fungsi yang menggunakan jenis pin.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // lakukan sesuatu
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` menggunakan `self`, jadi pulihkan `Pin<&mut Self>` melalui `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // KESELAMATAN: lihat dokumentasi mengenai fungsi ini
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Menetapkan nilai baru ke memori di sebalik rujukan yang disematkan.
    ///
    /// Ini menimpa data yang disematkan, tetapi tidak apa-apa: pemusnahnya dijalankan sebelum ditimpa, jadi tidak ada jaminan penyisipan yang dilanggar.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Membina pin baru dengan memetakan nilai dalaman.
    ///
    /// Sebagai contoh, jika anda ingin mendapatkan `Pin` bidang sesuatu, anda boleh menggunakannya untuk mendapatkan akses ke medan tersebut dalam satu baris kod.
    /// Walau bagaimanapun, terdapat beberapa gotchas dengan "pinning projections" ini;
    /// lihat dokumentasi [`pin` module] untuk keterangan lebih lanjut mengenai topik itu.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat.
    /// Anda mesti menjamin bahawa data yang anda kembalikan tidak akan bergerak selagi nilai argumen tidak bergerak (misalnya, kerana ia adalah salah satu bidang nilai itu), dan juga bahawa anda tidak keluar dari argumen yang anda terima fungsi dalaman.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // KESELAMATAN: kontrak keselamatan untuk `new_unchecked` mestilah
        // ditegakkan oleh pemanggil.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Mendapat rujukan bersama dari pin.
    ///
    /// Ini selamat kerana tidak mustahil untuk keluar dari rujukan bersama.
    /// Nampaknya ada masalah di sini mengenai kebolehubahan dalaman: sebenarnya, * adalah mungkin untuk memindahkan `T` dari `&RefCell<T>`.
    /// Namun, ini tidak menjadi masalah selagi tidak ada `Pin<&T>` yang menunjuk ke data yang sama, dan `RefCell<T>` tidak membiarkan anda membuat rujukan yang disematkan untuk kandungannya.
    ///
    /// Lihat perbincangan mengenai ["pinning projections"] untuk keterangan lebih lanjut.
    ///
    /// Note: `Pin` juga menerapkan `Deref` ke sasaran, yang dapat digunakan untuk mengakses nilai batin.
    /// Walau bagaimanapun, `Deref` hanya memberikan rujukan yang bertahan selama meminjam `Pin`, bukan jangka hayat `Pin` itu sendiri.
    /// Kaedah ini membolehkan menjadikan `Pin` menjadi rujukan dengan jangka hayat yang sama dengan `Pin` yang asli.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Menukar `Pin<&mut T>` ini menjadi `Pin<&T>` dengan jangka hayat yang sama.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Mendapat rujukan yang dapat berubah pada data di dalam `Pin` ini.
    ///
    /// Ini memerlukan bahawa data di dalam `Pin` ini adalah `Unpin`.
    ///
    /// Note: `Pin` juga menerapkan `DerefMut` ke data, yang dapat digunakan untuk mengakses nilai batin.
    /// Walau bagaimanapun, `DerefMut` hanya memberikan rujukan yang bertahan selama meminjam `Pin`, bukan jangka hayat `Pin` itu sendiri.
    ///
    /// Kaedah ini membolehkan menjadikan `Pin` menjadi rujukan dengan jangka hayat yang sama dengan `Pin` yang asli.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Mendapat rujukan yang dapat berubah pada data di dalam `Pin` ini.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat.
    /// Anda mesti menjamin bahawa anda tidak akan memindahkan data dari rujukan berubah yang anda terima semasa anda memanggil fungsi ini, sehingga invarian pada jenis `Pin` dapat ditegakkan.
    ///
    ///
    /// Sekiranya data yang mendasari adalah `Unpin`, `Pin::get_mut` harus digunakan sebagai gantinya.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Bentukkan pin baru dengan memetakan nilai dalaman.
    ///
    /// Sebagai contoh, jika anda ingin mendapatkan `Pin` bidang sesuatu, anda boleh menggunakannya untuk mendapatkan akses ke medan tersebut dalam satu baris kod.
    /// Walau bagaimanapun, terdapat beberapa gotchas dengan "pinning projections" ini;
    /// lihat dokumentasi [`pin` module] untuk keterangan lebih lanjut mengenai topik itu.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat.
    /// Anda mesti menjamin bahawa data yang anda kembalikan tidak akan bergerak selagi nilai argumen tidak bergerak (misalnya, kerana ia adalah salah satu bidang nilai itu), dan juga bahawa anda tidak keluar dari argumen yang anda terima fungsi dalaman.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // KESELAMATAN: pemanggil bertanggungjawab untuk tidak memindahkan
        // nilai daripada rujukan ini.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // KESELAMATAN: kerana nilai `this` dijamin tidak akan ada
        // dipindahkan, panggilan ke `new_unchecked` ini selamat.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Dapatkan rujukan yang disematkan dari rujukan statik.
    ///
    /// Ini selamat, kerana `T` dipinjam untuk jangka hayat `'static`, yang tidak pernah berakhir.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // KESELAMATAN: Pinjaman statik menjamin data tidak akan berlaku
        // moved/invalidated sehingga jatuh (yang tidak pernah).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Dapatkan rujukan boleh ubah yang disematkan dari rujukan boleh ubah statik.
    ///
    /// Ini selamat, kerana `T` dipinjam untuk jangka hayat `'static`, yang tidak pernah berakhir.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // KESELAMATAN: Pinjaman statik menjamin data tidak akan berlaku
        // moved/invalidated sehingga jatuh (yang tidak pernah).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: ini bermaksud bahawa setiap implan `CoerceUnsized` yang membolehkan pemaksaan dari
// jenis yang mengisyaratkan `Deref<Target=impl !Unpin>` ke jenis yang membayangkan `Deref<Target=Unpin>` tidak betul.
// Sebarang implan semacam itu mungkin tidak masuk akal untuk alasan lain, jadi, kita hanya perlu berhati-hati agar tidak membiarkan impl tersebut mendarat di std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}