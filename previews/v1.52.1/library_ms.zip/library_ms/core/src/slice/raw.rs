//! Fungsi percuma untuk membuat `&[T]` dan `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Membentuk kepingan dari penunjuk dan panjang.
///
/// Argumen `len` adalah bilangan **elemen**, bukan bilangan bait.
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `data` mestilah [valid] untuk bacaan untuk `len * mem::size_of::<T>()` banyak bait, dan mestilah sejajar dengan betul.Ini bermaksud:
///
///     * Keseluruhan rentang memori slice ini mesti terdapat dalam satu objek yang diperuntukkan!
///       Potongan tidak boleh menjangkau pelbagai objek yang diperuntukkan.Lihat [below](#incorrect-usage) untuk contoh yang salah dengan tidak mengambil kira perkara ini.
///     * `data` mestilah tidak kosong dan sejajar walaupun untuk kepingan panjang sifar.
///     Salah satu sebabnya adalah bahawa pengoptimuman susun atur enum mungkin bergantung pada rujukan (termasuk potongan panjang) yang diselaraskan dan tidak kosong untuk membezakannya dari data lain.
///     Anda boleh mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk potongan panjang sifar menggunakan [`NonNull::dangling()`].
///
/// * `data` mesti menunjukkan nilai `len` berturut-turut yang diinisialisasi dengan betul dari jenis `T`.
///
/// * Memori yang dirujuk oleh potongan yang dikembalikan tidak boleh dimutasi selama `'a` sepanjang hayat, kecuali di dalam `UnsafeCell`.
///
/// * Ukuran keseluruhan potongan `len * mem::size_of::<T>()` tidak boleh lebih besar daripada `isize::MAX`.
///   Lihat dokumentasi keselamatan [`pointer::offset`].
///
/// # Caveat
///
/// Jangka hayat untuk kepingan yang dikembalikan disimpulkan dari penggunaannya.
/// Untuk mengelakkan penyalahgunaan yang tidak disengajakan, disarankan untuk mengaitkan jangka hayat dengan jangka hayat sumber mana pun yang selamat dalam konteks, seperti dengan menyediakan fungsi pembantu yang mengambil jangka hayat nilai hos untuk slice, atau dengan penjelasan eksplisit.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // mewujudkan kepingan untuk satu elemen
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Penggunaan yang tidak betul
///
/// Fungsi `join_slices` berikut adalah **tidak sedap** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Penegasan di atas memastikan `fst` dan `snd` bersebelahan, tetapi mungkin masih terdapat dalam _different allocated objects_, dalam hal ini membuat slice ini adalah tingkah laku yang tidak ditentukan.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` dan `b` adalah objek yang diperuntukkan berbeza ...
///     let a = 42;
///     let b = 27;
///     // ... yang tetap dapat dilampirkan dalam memori: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Melakukan fungsi yang sama seperti [`from_raw_parts`], kecuali potongan yang dapat diubah dikembalikan.
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `data` mestilah [valid] untuk kedua-dua bacaan dan penulisan untuk `len * mem::size_of::<T>()` banyak bait, dan mestilah sejajar dengan betul.Ini bermaksud:
///
///     * Keseluruhan rentang memori slice ini mesti terdapat dalam satu objek yang diperuntukkan!
///       Potongan tidak boleh menjangkau pelbagai objek yang diperuntukkan.
///     * `data` mestilah tidak kosong dan sejajar walaupun untuk kepingan panjang sifar.
///     Salah satu sebabnya adalah bahawa pengoptimuman susun atur enum mungkin bergantung pada rujukan (termasuk potongan panjang) yang diselaraskan dan tidak kosong untuk membezakannya dari data lain.
///
///     Anda boleh mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk potongan panjang sifar menggunakan [`NonNull::dangling()`].
///
/// * `data` mesti menunjukkan nilai `len` berturut-turut yang diinisialisasi dengan betul dari jenis `T`.
///
/// * Memori yang dirujuk oleh potongan yang dikembalikan tidak boleh diakses melalui penunjuk lain (tidak berasal dari nilai pengembalian) untuk sepanjang hayat `'a`.
///   Akses membaca dan menulis dilarang.
///
/// * Ukuran keseluruhan potongan `len * mem::size_of::<T>()` tidak boleh lebih besar daripada `isize::MAX`.
///   Lihat dokumentasi keselamatan [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Menukarkan rujukan ke T menjadi kepingan panjang 1 (tanpa menyalin).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Menukarkan rujukan ke T menjadi kepingan panjang 1 (tanpa menyalin).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}