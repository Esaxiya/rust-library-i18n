//! Operasi pada ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Memeriksa apakah semua bait dalam irisan ini berada dalam julat ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Memeriksa bahawa dua potongan adalah padanan tidak sensitif huruf ASCII.
    ///
    /// Sama seperti `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, tetapi tanpa memperuntukkan dan menyalin sementara.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Menukarkan potongan ini kepada huruf besar ASCII yang setara di tempatnya.
    ///
    /// Huruf ASCII 'a' hingga 'z' dipetakan ke 'A' hingga 'Z', tetapi huruf bukan ASCII tidak berubah.
    ///
    /// Untuk mengembalikan nilai huruf besar baru tanpa mengubah nilai yang ada, gunakan [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Menukarkan potongan ini ke setara huruf kecil ASCII di tempatnya.
    ///
    /// Huruf ASCII 'A' hingga 'Z' dipetakan ke 'a' hingga 'z', tetapi huruf bukan ASCII tidak berubah.
    ///
    /// Untuk mengembalikan nilai huruf kecil yang baru tanpa mengubah nilai yang ada, gunakan [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Mengembalikan `true` jika ada bait dalam perkataan `v` adalah nonascii (>=128).
/// Snarfed dari `../str/mod.rs`, yang melakukan sesuatu yang serupa untuk pengesahan utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Ujian ASCII yang dioptimumkan yang akan menggunakan operasi usize-at-a-time dan bukannya operasi byte-at-a-time (bila mungkin).
///
/// Algoritma yang kami gunakan di sini cukup mudah.Sekiranya `s` terlalu pendek, kami hanya memeriksa setiap bait dan selesai dengannya.Jika tidak:
///
/// - Baca perkataan pertama dengan beban yang tidak selaras.
/// - Sejajarkan penunjuk, baca kata-kata berikutnya hingga akhir dengan beban selaras.
/// - Baca `usize` terakhir dari `s` dengan beban yang tidak selaras.
///
/// Sekiranya salah satu daripada beban ini menghasilkan sesuatu yang `contains_nonascii` (above) kembali benar, maka kita tahu jawapannya adalah salah.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Sekiranya kita tidak memperoleh apa-apa dari pelaksanaan kata-pada-satu-masa, kembali ke lingkaran skalar.
    //
    // Kami juga melakukan ini untuk seni bina di mana `size_of::<usize>()` tidak cukup untuk `usize`, kerana ini adalah kes edge yang pelik.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Kami selalu membaca perkataan pertama yang tidak selaras, yang bermaksud `align_offset` adalah
    // 0, kami akan membaca nilai yang sama sekali lagi untuk bacaan selaras.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // KESELAMATAN: Kami mengesahkan `len < USIZE_SIZE` di atas.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Kami memeriksa perkara di atas, agak tersirat.
    // Perhatikan bahawa `offset_to_aligned` adalah `align_offset` atau `USIZE_SIZE`, kedua-duanya diperiksa secara eksplisit di atas.
    //
    debug_assert!(offset_to_aligned <= len);

    // KESELAMATAN: word_ptr adalah ptr pemakai (sejajar dengan betul) yang kita gunakan untuk membaca
    // bahagian tengah hirisan.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` adalah indeks byte `word_ptr`, digunakan untuk pemeriksaan akhir gelung.
    let mut byte_pos = offset_to_aligned;

    // Paranoia memeriksa penjajaran, kerana kita akan melakukan banyak beban yang tidak selaras.
    // Dalam praktiknya, ini mustahil untuk menghadirkan bug pada `align_offset` sekalipun.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Bacalah kata-kata berikutnya hingga kata yang selaras terakhir, tidak termasuk kata yang selaras terakhir dengan sendirinya yang harus dilakukan dalam pemeriksaan ekor kemudian, untuk memastikan bahawa ekor selalu satu `usize` paling banyak hingga tambahan branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Kewarasan memastikan pembacaannya tidak terhad
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Dan andaian kami mengenai `byte_pos` berlaku.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // KESELAMATAN: Kami tahu `word_ptr` diselaraskan dengan betul (kerana
        // `align_offset`), dan kami tahu bahawa kami mempunyai cukup bait antara `word_ptr` dan akhir
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // KESELAMATAN: Kami tahu bahawa `byte_pos <= len - USIZE_SIZE`, yang bermaksud itu
        // selepas `add` ini, `word_ptr` akan paling banyak sekali.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Pemeriksaan kebersihan untuk memastikan hanya ada satu `usize` yang tersisa.
    // Ini harus dijamin oleh keadaan gelung kami.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // KESELAMATAN: Ini bergantung pada `len >= USIZE_SIZE`, yang kami periksa pada awalnya.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}