//! Menyusun kepingan
//!
//! Modul ini mengandungi algoritma penyortiran berdasarkan kumpulan cepat mengalahkan corak Orson Peters, yang diterbitkan di: <https://github.com/orlp/pdqsort>
//!
//!
//! Pengisihan tidak stabil serasi dengan libcore kerana tidak memperuntukkan memori, tidak seperti pelaksanaan penyusun stabil kami.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Apabila dijatuhkan, salinan dari `src` ke `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // KESELAMATAN: Ini adalah kelas pembantu.
        //          Sila rujuk penggunaannya untuk kebenaran.
        //          Yaitu, seseorang mesti yakin bahawa `src` dan `dst` tidak bertindih seperti yang dikehendaki oleh `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Menggeser elemen pertama ke kanan sehingga menemui unsur yang lebih besar atau sama.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // KESELAMATAN: Operasi tidak selamat di bawah melibatkan pengindeksan tanpa cek terikat (`get_unchecked` dan `get_unchecked_mut`)
    // dan menyalin memori (`ptr::copy_nonoverlapping`).
    //
    // a.Pengindeksan:
    //  1. Kami memeriksa ukuran array ke>=2.
    //  2. Semua pengindeksan yang akan kami lakukan selalu antara {0 <= index < len} paling banyak.
    //
    // b.Penyalinan memori
    //  1. Kami memperoleh petunjuk mengenai rujukan yang dijamin sah.
    //  2. Mereka tidak boleh bertindih kerana kami memperoleh petunjuk untuk membezakan indeks potongan.
    //     Yaitu, `i` dan `i-1`.
    //  3. Sekiranya irisan diselaraskan dengan betul, unsur-unsurnya sejajar dengan betul.
    //     Menjadi tanggungjawab pemanggil untuk memastikan potongannya diselaraskan dengan betul.
    //
    // Lihat komen di bawah untuk keterangan lebih lanjut.
    unsafe {
        // Sekiranya dua elemen pertama tidak berfungsi ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Baca elemen pertama ke dalam pemboleh ubah yang diagihkan.
            // Sekiranya operasi perbandingan berikut panics, `hole` akan dijatuhkan dan secara automatik menulis semula elemen tersebut ke dalam slice.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Gerakkan elemen `i`-th satu tempat ke kiri, sehingga mengalihkan lubang ke kanan.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` jatuh dan dengan itu menyalin `tmp` ke dalam lubang yang tinggal di `v`.
        }
    }
}

/// Menggeser elemen terakhir ke kiri sehingga ia menemui unsur yang lebih kecil atau sama.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // KESELAMATAN: Operasi tidak selamat di bawah melibatkan pengindeksan tanpa cek terikat (`get_unchecked` dan `get_unchecked_mut`)
    // dan menyalin memori (`ptr::copy_nonoverlapping`).
    //
    // a.Pengindeksan:
    //  1. Kami memeriksa ukuran array ke>=2.
    //  2. Semua pengindeksan yang akan kami lakukan selalu antara `0 <= index < len-1` paling banyak.
    //
    // b.Penyalinan memori
    //  1. Kami memperoleh petunjuk mengenai rujukan yang dijamin sah.
    //  2. Mereka tidak boleh bertindih kerana kami memperoleh petunjuk untuk membezakan indeks potongan.
    //     Yaitu, `i` dan `i+1`.
    //  3. Sekiranya irisan diselaraskan dengan betul, unsur-unsurnya sejajar dengan betul.
    //     Menjadi tanggungjawab pemanggil untuk memastikan potongannya diselaraskan dengan betul.
    //
    // Lihat komen di bawah untuk keterangan lebih lanjut.
    unsafe {
        // Sekiranya dua elemen terakhir tidak berfungsi ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Baca elemen terakhir ke pemboleh ubah yang diagihkan.
            // Sekiranya operasi perbandingan berikut panics, `hole` akan dijatuhkan dan secara automatik menulis semula elemen tersebut ke dalam slice.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Gerakkan elemen `i`-th satu tempat ke kanan, sehingga mengalihkan lubang ke kiri.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` jatuh dan dengan itu menyalin `tmp` ke dalam lubang yang tinggal di `v`.
        }
    }
}

/// Sebahagiannya menyusun sepotong dengan mengalihkan beberapa elemen yang tidak berfungsi di sekitar.
///
/// Mengembalikan `true` jika irisan disusun di hujungnya.Fungsi ini adalah *O*(*n*) terburuk.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Bilangan maksimum pasangan luar pesanan yang berdekatan yang akan beralih.
    const MAX_STEPS: usize = 5;
    // Sekiranya potongan lebih pendek daripada ini, jangan memindahkan elemen apa pun.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // KESELAMATAN: Kami sudah secara eksplisit melakukan pemeriksaan terikat dengan `i < len`.
        // Semua pengindeksan seterusnya kami hanya berada dalam julat `0 <= index < len`
        unsafe {
            // Cari pasangan elemen luar pesanan yang seterusnya.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Adakah kita sudah selesai?
        if i == len {
            return true;
        }

        // Jangan mengalihkan elemen pada susunan pendek, yang mempunyai kos prestasi.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Tukar pasangan elemen yang dijumpai.Ini meletakkan mereka dalam susunan yang betul.
        v.swap(i - 1, i);

        // Alihkan elemen yang lebih kecil ke kiri.
        shift_tail(&mut v[..i], is_less);
        // Alihkan elemen yang lebih besar ke kanan.
        shift_head(&mut v[i..], is_less);
    }

    // Tidak berjaya menyusun potongan dalam jumlah langkah yang terhad.
    false
}

/// Menyusun kepingan menggunakan penyisipan, iaitu *O*(*n*^ 2) terburuk.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Susun `v` menggunakan heapsort, yang menjamin *O*(*n*\*log(* n*)) terburuk.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Timbunan binari ini menghormati `parent >= child` invarian.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Kanak-kanak `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Pilih anak yang lebih hebat.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Berhenti jika invarian berlaku pada `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Tukar `node` dengan anak yang lebih besar, gerakkan selangkah ke bawah, dan terus mengayak.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Bina timbunan dalam masa linear.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop elemen maksimum dari timbunan.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partisi `v` menjadi elemen yang lebih kecil daripada `pivot`, diikuti oleh elemen yang lebih besar daripada atau sama dengan `pivot`.
///
///
/// Mengembalikan bilangan elemen yang lebih kecil daripada `pivot`.
///
/// Partition dilakukan secara blok demi blok untuk mengurangkan kos operasi percabangan.
/// Idea ini dikemukakan dalam kertas [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Bilangan elemen dalam blok khas.
    const BLOCK: usize = 128;

    // Algoritma partition mengulangi langkah-langkah berikut sehingga selesai:
    //
    // 1. Jejaki blok dari sebelah kiri untuk mengenal pasti unsur yang lebih besar daripada atau sama dengan pangsi.
    // 2. Jejaki blok dari sebelah kanan untuk mengenal pasti elemen yang lebih kecil daripada pangsi.
    // 3. Tukar elemen yang dikenal pasti antara kiri dan kanan.
    //
    // Kami menyimpan pemboleh ubah berikut untuk sekumpulan elemen:
    //
    // 1. `block` - Bilangan elemen dalam blok.
    // 2. `start` - Mulakan penunjuk ke dalam array `offsets`.
    // 3. `end` - Tamatkan penunjuk ke dalam array `offsets`.
    // 4. "ofset, Indeks elemen tidak teratur dalam blok.

    // Blok semasa di sebelah kiri (dari `l` hingga `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Blok semasa di sebelah kanan (dari `r.sub(block_r)` to `r`).
    // KESELAMATAN: Dokumentasi untuk .add() secara khusus menyebutkan bahawa `vec.as_ptr().add(vec.len())` sentiasa selamat '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Apabila kita mendapat VLA, cuba buat satu susunan panjang `min(v.len(), 2 * BLOCK) `
    // daripada dua tatasusunan bersaiz tetap panjang `BLOCK`.VLA mungkin lebih cekap cache.

    // Mengembalikan bilangan elemen antara penunjuk `l` (inclusive) dan `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Kami selesai membuat partisi blok demi blok ketika `l` dan `r` hampir hampir.
        // Kemudian kami melakukan beberapa kerja penambahbaikan untuk membahagikan unsur-unsur yang tinggal di antara mereka.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Bilangan elemen yang tinggal (masih tidak dibandingkan dengan pangsi).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Sesuaikan ukuran blok supaya blok kiri dan kanan tidak bertindih, tetapi sejajar dengan sempurna untuk menutup keseluruhan jurang yang tinggal.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Jejak elemen `block_l` dari sebelah kiri.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // KESELAMATAN: Operasi tidak selamat di bawah melibatkan penggunaan `offset`.
                //         Mengikut syarat yang diperlukan oleh fungsi, kami memuaskannya kerana:
                //         1. `offsets_l` ditumpuk tumpukan, dan dengan itu dianggap sebagai objek yang diperuntukkan secara berasingan.
                //         2. Fungsi `is_less` mengembalikan `bool`.
                //            Menghantar `bool` tidak akan melebihi `isize`.
                //         3. Kami telah menjamin bahawa `block_l` akan menjadi `<= BLOCK`.
                //            Plus, `end_l` pada awalnya ditetapkan ke titik awal `offsets_` yang dinyatakan pada timbunan.
                //            Oleh itu, kita tahu bahawa walaupun dalam keadaan terburuk (semua pemanggilan `is_less` mengembalikan palsu) kita hanya akan mendapat paling banyak 1 bait akhir.
                //        Operasi lain yang tidak selamat di sini adalah membatalkan `elem`.
                //        Walau bagaimanapun, `elem` pada awalnya merupakan penunjuk permulaan ke slice yang selalu berlaku.
                unsafe {
                    // Perbandingan tanpa cabang.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Jejak elemen `block_r` dari sebelah kanan.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // KESELAMATAN: Operasi tidak selamat di bawah melibatkan penggunaan `offset`.
                //         Mengikut syarat yang diperlukan oleh fungsi, kami memuaskannya kerana:
                //         1. `offsets_r` ditumpuk tumpukan, dan dengan itu dianggap sebagai objek yang diperuntukkan secara berasingan.
                //         2. Fungsi `is_less` mengembalikan `bool`.
                //            Menghantar `bool` tidak akan melebihi `isize`.
                //         3. Kami telah menjamin bahawa `block_r` akan menjadi `<= BLOCK`.
                //            Plus, `end_r` pada awalnya ditetapkan ke titik awal `offsets_` yang dinyatakan pada timbunan.
                //            Oleh itu, kita tahu bahawa walaupun dalam keadaan terburuk (semua pemanggilan `is_less` kembali benar) kita hanya akan mendapat paling banyak 1 bait akhir.
                //        Operasi lain yang tidak selamat di sini adalah membatalkan `elem`.
                //        Walau bagaimanapun, `elem` pada mulanya `1 *sizeof(T)` berakhir dan kami mengurangkannya dengan `1* sizeof(T)` sebelum mengaksesnya.
                //        Selain itu, `block_r` ditegaskan kurang dari `BLOCK` dan `elem` paling banyak akan menunjukkan awal potongan.
                unsafe {
                    // Perbandingan tanpa cabang.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Bilangan elemen yang tidak teratur untuk bertukar antara sisi kiri dan kanan.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Daripada menukar satu pasangan pada masa itu, lebih berkesan melakukan permutasi siklik.
            // Ini tidak sama dengan pertukaran, tetapi menghasilkan hasil yang serupa dengan menggunakan operasi memori yang lebih sedikit.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Semua elemen yang tidak tersusun di blok kiri dipindahkan.Pindah ke blok seterusnya.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Semua elemen yang tidak tersusun di blok kanan dipindahkan.Pindah ke blok sebelumnya.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Yang tinggal sekarang adalah paling banyak satu blok (sama ada kiri atau kanan) dengan unsur-unsur tidak teratur yang perlu dipindahkan.
    // Unsur-unsur yang tersisa itu hanya boleh dialihkan ke hujung dalam blok mereka.
    //

    if start_l < end_l {
        // Blok kiri kekal.
        // Gerakkan unsur-unsurnya yang tidak tersusun ke kanan paling kanan.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Blok kanan tetap ada.
        // Pindahkan unsur-unsurnya yang tidak tersusun ke kiri paling kiri.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Tiada perkara lain yang perlu dilakukan, kami sudah selesai
        width(v.as_mut_ptr(), l)
    }
}

/// Partisi `v` menjadi elemen yang lebih kecil daripada `v[pivot]`, diikuti oleh elemen yang lebih besar daripada atau sama dengan `v[pivot]`.
///
///
/// Mengembalikan tupel dari:
///
/// 1. Bilangan elemen lebih kecil daripada `v[pivot]`.
/// 2. Benar jika `v` sudah dipartisi.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Letakkan pangsi di awal hirisan.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Baca pivot menjadi pemboleh ubah yang diperuntukkan untuk kecekapan.
        // Sekiranya operasi perbandingan berikut panics, pivot akan ditulis semula secara automatik ke dalam slice.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Cari pasangan elemen pertama yang tidak sesuai.
        let mut l = 0;
        let mut r = v.len();

        // KESELAMATAN: Ketidakamanan di bawah melibatkan pengindeksan array.
        // Untuk yang pertama: Kami sudah melakukan pemeriksaan batas di sini dengan `l < r`.
        // Untuk yang kedua: Pada mulanya kami mempunyai `l == 0` dan `r == v.len()` dan kami memeriksa `l < r` pada setiap operasi pengindeksan.
        //                     Dari sini kita tahu bahawa `r` mestilah sekurang-kurangnya `r == l` yang terbukti sah dari yang pertama.
        unsafe {
            // Cari elemen pertama yang lebih besar daripada atau sama dengan pangsi.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Cari elemen terakhir yang lebih kecil daripada pangsi.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` keluar dari ruang lingkup dan menulis pivot (yang merupakan pemboleh ubah yang diperuntukkan tumpukan) kembali ke slice di mana asalnya.
        // Langkah ini sangat penting dalam memastikan keselamatan!
        //
    };

    // Letakkan pangsi di antara dua partisi.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Membahagi `v` ke dalam unsur yang sama dengan `v[pivot]` diikuti oleh unsur yang lebih besar daripada `v[pivot]`.
///
/// Mengembalikan bilangan elemen sama dengan pangsi.
/// Diandaikan bahawa `v` tidak mengandungi elemen yang lebih kecil daripada pangsi.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Letakkan pangsi di awal hirisan.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Baca pivot menjadi pemboleh ubah yang diperuntukkan untuk kecekapan.
    // Sekiranya operasi perbandingan berikut panics, pivot akan ditulis semula secara automatik ke dalam slice.
    // KESELAMATAN: Penunjuk di sini adalah sah kerana ia diperoleh dari rujukan ke bahagian.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Sekarang bahagikan kepingan.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // KESELAMATAN: Ketidakamanan di bawah melibatkan pengindeksan array.
        // Untuk yang pertama: Kami sudah melakukan pemeriksaan batas di sini dengan `l < r`.
        // Untuk yang kedua: Pada mulanya kami mempunyai `l == 0` dan `r == v.len()` dan kami memeriksa `l < r` pada setiap operasi pengindeksan.
        //                     Dari sini kita tahu bahawa `r` mestilah sekurang-kurangnya `r == l` yang terbukti sah dari yang pertama.
        unsafe {
            // Cari elemen pertama yang lebih besar daripada pangsi.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Cari elemen terakhir yang sama dengan pangsi.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Adakah kita sudah selesai?
            if l >= r {
                break;
            }

            // Tukar pasangan elemen yang tidak sesuai.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Kami menjumpai unsur `l` sama dengan pangsi.Tambah 1 untuk mengira pangsi itu sendiri.
    l + 1

    // `_pivot_guard` keluar dari ruang lingkup dan menulis pivot (yang merupakan pemboleh ubah yang diperuntukkan tumpukan) kembali ke slice di mana asalnya.
    // Langkah ini sangat penting dalam memastikan keselamatan!
}

/// Menyebarkan beberapa elemen dalam usaha untuk memecahkan corak yang mungkin menyebabkan partisi tidak seimbang dalam pintasan.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Penjana nombor pseudorandom dari kertas "Xorshift RNGs" oleh George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Ambil nombor rawak modulo nombor ini.
        // Nombor itu sesuai dengan `usize` kerana `len` tidak lebih besar daripada `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Beberapa calon pivot akan berada di dekat indeks ini.Mari rawak mereka.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Hasilkan nombor rawak modulo `len`.
            // Namun, untuk mengelakkan operasi yang mahal, pertama-tama kita menggunakan modul itu dengan kekuatan dua, dan kemudian turun sebanyak `len` hingga sesuai dengan julat `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` dijamin kurang dari `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Memilih pivot dalam `v` dan mengembalikan indeks dan `true` jika slice kemungkinan sudah disusun.
///
/// Elemen dalam `v` mungkin disusun semula dalam prosesnya.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Panjang minimum untuk memilih kaedah median-of-medians.
    // Potongan yang lebih pendek menggunakan kaedah median-of-tiga yang sederhana.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Jumlah pertukaran maksimum yang dapat dilakukan dalam fungsi ini.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tiga indeks berhampiran yang akan kita pilih pangsi.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Mengira jumlah pertukaran yang akan kami laksanakan semasa menyusun indeks.
    let mut swaps = 0;

    if len >= 8 {
        // Tukar indeks sehingga `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Tukar indeks sehingga `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Cari median `v[a - 1], v[a], v[a + 1]` dan simpan indeks ke `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Cari orang tengah di kawasan sekitar `a`, `b` dan `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Cari median antara `a`, `b` dan `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Jumlah pertukaran maksimum dilakukan.
        // Kemungkinan potongannya turun atau kebanyakannya menurun, jadi membalikkan kemungkinan akan membantu menyusunnya lebih cepat.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Susun `v` secara berulang.
///
/// Sekiranya slice mempunyai pendahulu dalam susunan asal, ia ditentukan sebagai `pred`.
///
/// `limit` ialah bilangan partisi tidak seimbang yang dibenarkan sebelum beralih ke `heapsort`.
/// Sekiranya sifar, fungsi ini akan segera beralih ke heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Potongan hingga panjang ini disusun menggunakan penyisipan.
    const MAX_INSERTION: usize = 20;

    // Benar jika partition terakhir cukup seimbang.
    let mut was_balanced = true;
    // Benar jika partition terakhir tidak mengacak elemen (slice sudah dipartisi).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Potongan yang sangat pendek disusun menggunakan penyisipan.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Sekiranya terlalu banyak pilihan pivot buruk dibuat, kembalilah ke heaport untuk menjamin `O(n * log(n))` terburuk.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Sekiranya partition terakhir tidak seimbang, cuba pecahkan corak di slice dengan mengacak beberapa elemen di sekitarnya.
        // Semoga kita memilih pangsi yang lebih baik kali ini.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Pilih pangsi dan cuba meneka sama ada irisan sudah disusun.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Sekiranya partition terakhir seimbang dan tidak mengacak elemen, dan jika pemilihan pivot meramalkan potongan mungkin sudah disusun ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Cuba kenal pasti beberapa elemen yang tidak sesuai dan ubahnya ke kedudukan yang betul.
            // Sekiranya irisan akhirnya disusun sepenuhnya, kita sudah selesai.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Sekiranya pivot yang dipilih sama dengan pendahulunya, maka itu adalah elemen terkecil dalam slice.
        // Bahagikan bahagian menjadi unsur yang sama dengan unsur yang lebih besar daripada pangsi.
        // Kes ini biasanya dipukul ketika potongan mengandungi banyak unsur pendua.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Teruskan menyusun elemen yang lebih besar daripada pangsi.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Bahagikan kepingan.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Pisahkan kepingan menjadi `left`, `pivot`, dan `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Berulang ke sisi yang lebih pendek hanya untuk mengurangkan jumlah panggilan berulang dan menggunakan ruang tumpukan yang lebih sedikit.
        // Kemudian teruskan dengan sisi yang lebih panjang (ini serupa dengan pengulangan ekor).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Susun `v` menggunakan corak cepat mengalahkan corak, iaitu *O*(*n*\*log(* n*)) terburuk.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Menyusun tidak mempunyai tingkah laku yang bermakna pada jenis bersaiz sifar.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Hadkan bilangan partisi yang tidak seimbang hingga `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Untuk kepingan sehingga panjang ini mungkin lebih pantas untuk menyusunnya.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Pilih pangsi
        let (pivot, _) = choose_pivot(v, is_less);

        // Sekiranya pivot yang dipilih sama dengan pendahulunya, maka itu adalah elemen terkecil dalam slice.
        // Bahagikan bahagian menjadi unsur yang sama dengan unsur yang lebih besar daripada pangsi.
        // Kes ini biasanya dipukul ketika potongan mengandungi banyak unsur pendua.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Sekiranya kita berjaya melepasi indeks kita, maka kita bagus.
                if mid > index {
                    return;
                }

                // Jika tidak, teruskan menyusun elemen yang lebih besar daripada pangsi.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Pisahkan kepingan menjadi `left`, `pivot`, dan `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Sekiranya indeks pertengahan==, maka kita sudah selesai, kerana partition() dijamin bahawa semua elemen selepas pertengahan lebih besar daripada atau sama dengan pertengahan.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Menyusun tidak mempunyai tingkah laku yang bermakna pada jenis bersaiz sifar.Tidak buat apa-apa.
    } else if index == v.len() - 1 {
        // Cari elemen maksimum dan letakkan di kedudukan terakhir array.
        // Kami bebas menggunakan `unwrap()` di sini kerana kami tahu v tidak boleh kosong.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Cari elemen min dan letakkan di kedudukan pertama array.
        // Kami bebas menggunakan `unwrap()` di sini kerana kami tahu v tidak boleh kosong.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}