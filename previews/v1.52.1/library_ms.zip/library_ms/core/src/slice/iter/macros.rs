//! Makro yang digunakan oleh iterator slice.

// Melekatkan is_empty dan len membuat perbezaan prestasi yang besar
macro_rules! is_empty {
    // Cara kita mengekod panjang iterator ZST, ini berfungsi baik untuk ZST dan bukan ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Untuk menghilangkan beberapa pemeriksaan had (lihat `position`), kami mengira panjangnya dengan cara yang agak tidak dijangka.
// (Diuji oleh `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // kita kadang-kadang digunakan dalam blok yang tidak selamat

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ ini menggunakan `unchecked_sub` kerana kami bergantung pada pembungkus untuk mewakili panjang iterator potongan ZST panjang.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Kami tahu bahawa `start <= end`, boleh jadi lebih baik daripada `offset_from`, yang perlu ditangani secara masuk.
            // Dengan menetapkan bendera yang sesuai di sini kita dapat memberitahu LLVM ini, yang membantunya menghilangkan pemeriksaan batas.
            // KESELAMATAN: Mengikut jenis invarian, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Dengan juga memberitahu LLVM bahawa penunjuk dipisahkan dengan tepat dari pelbagai ukuran, ia dapat mengoptimumkan `len() == 0` hingga `start == end` dan bukannya `(end - start) < size`.
            //
            // KESELAMATAN: Mengikut jenis invarian, penunjuk diselaraskan sehingga
            //         jarak di antara mereka mestilah gandaan ukuran pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Definisi bersama bagi iterator `Iter` dan `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Mengembalikan elemen pertama dan menggerakkan permulaan iterator ke hadapan dengan 1.
        // Meningkatkan prestasi berbanding fungsi sebaris.
        // Pengulangan tidak boleh kosong.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Mengembalikan elemen terakhir dan menggerakkan hujung iterator ke belakang dengan 1.
        // Meningkatkan prestasi berbanding fungsi sebaris.
        // Pengulangan tidak boleh kosong.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Mengecilkan iterator ketika T adalah ZST, dengan menggerakkan hujung iterator ke belakang dengan `n`.
        // `n` tidak boleh melebihi `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Fungsi pembantu untuk membuat potongan dari iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // KESELAMATAN: iterator dibuat dari slice dengan pointer
                // `self.ptr` dan panjang `len!(self)`.
                // Ini menjamin bahawa semua prasyarat untuk `from_raw_parts` dipenuhi.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Fungsi pembantu untuk menggerakkan permulaan iterator ke hadapan dengan elemen `offset`, mengembalikan permulaan lama.
            //
            // Tidak selamat kerana ofset tidak boleh melebihi `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // KESELAMATAN: pemanggil menjamin bahawa `offset` tidak melebihi `self.len()`,
                    // jadi penunjuk baru ini terdapat di dalam `self` dan dengan itu dijamin tidak kosong.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Fungsi pembantu untuk menggerakkan hujung iterator ke belakang dengan elemen `offset`, mengembalikan hujung baru.
            //
            // Tidak selamat kerana ofset tidak boleh melebihi `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // KESELAMATAN: pemanggil menjamin bahawa `offset` tidak melebihi `self.len()`,
                    // yang dijamin tidak akan melimpah `isize`.
                    // Juga, penunjuk yang dihasilkan berada dalam batas `slice`, yang memenuhi syarat lain untuk `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // boleh diimplementasikan dengan potongan, tetapi ini mengelakkan pemeriksaan yang tidak terhad

                // KESELAMATAN: Panggilan `assume` selamat sejak penunjuk permulaan
                // mestilah tidak kosong, dan kepingan di atas bukan ZST juga mesti mempunyai penunjuk hujung yang tidak kosong.
                // Panggilan ke `next_unchecked!` selamat kerana kami memeriksa apakah iterator kosong terlebih dahulu.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Pengulangan ini kini kosong.
                    if mem::size_of::<T>() == 0 {
                        // Kita harus melakukannya dengan cara ini kerana `ptr` mungkin tidak pernah 0, tetapi `end` mungkin (kerana pembungkus).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // KESELAMATAN: akhir tidak boleh menjadi 0 jika T bukan ZST kerana ptr bukan 0 dan akhir>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // KESELAMATAN: Kami berada dalam batas.`post_inc_start` melakukan perkara yang betul walaupun untuk ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Kami mengatasi pelaksanaan lalai, yang menggunakan `try_fold`, kerana pelaksanaan sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat disusun.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Kami mengatasi pelaksanaan lalai, yang menggunakan `try_fold`, kerana pelaksanaan sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat disusun.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Kami mengatasi pelaksanaan lalai, yang menggunakan `try_fold`, kerana pelaksanaan sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat disusun.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Kami mengatasi pelaksanaan lalai, yang menggunakan `try_fold`, kerana pelaksanaan sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat disusun.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Kami mengatasi pelaksanaan lalai, yang menggunakan `try_fold`, kerana pelaksanaan sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat disusun.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Kami mengatasi pelaksanaan lalai, yang menggunakan `try_fold`, kerana pelaksanaan sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat disusun.
            // Juga, `assume` mengelakkan pemeriksaan had.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // KESELAMATAN: kita dijamin akan diikat oleh gelung yang tidak berubah:
                        // apabila `i >= n`, `self.next()` mengembalikan `None` dan gelung putus.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Kami mengatasi pelaksanaan lalai, yang menggunakan `try_fold`, kerana pelaksanaan sederhana ini menghasilkan IR LLVM yang lebih sedikit dan lebih cepat disusun.
            // Juga, `assume` mengelakkan pemeriksaan had.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // KESELAMATAN: `i` mesti lebih rendah daripada `n` kerana ia bermula pada `n`
                        // dan hanya berkurang.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // KESELAMATAN: pemanggil mesti menjamin bahawa `i` berada dalam batas
                // slice yang mendasari, jadi `i` tidak dapat melimpah `isize`, dan rujukan yang dikembalikan dijamin merujuk pada elemen slice dan dengan itu dijamin sah.
                //
                // Perhatikan juga bahawa pemanggil juga menjamin bahawa kami tidak akan dipanggil lagi dengan indeks yang sama, dan bahawa tidak ada kaedah lain yang akan mengakses subslice ini dipanggil, jadi sah untuk rujukan yang dikembalikan dapat berubah dalam kes
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // boleh diimplementasikan dengan potongan, tetapi ini mengelakkan pemeriksaan yang tidak terhad

                // KESELAMATAN: Panggilan `assume` selamat kerana penunjuk permulaan slice mestilah tidak kosong,
                // dan kepingan di atas bukan ZST juga mesti mempunyai penunjuk akhir yang tidak kosong.
                // Panggilan ke `next_back_unchecked!` selamat kerana kami memeriksa apakah iterator kosong terlebih dahulu.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Pengulangan ini kini kosong.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // KESELAMATAN: Kami berada dalam batas.`pre_dec_end` melakukan perkara yang betul walaupun untuk ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}