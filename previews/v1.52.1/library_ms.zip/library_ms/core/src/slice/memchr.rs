// Pelaksanaan asal diambil dari rust-memchr.
// Hak Cipta 2015 Andrew Gallant, bluss dan Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Gunakan pemotongan.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Mengembalikan `true` jika `x` mengandungi bait sifar.
///
/// Dari *Matters Computational*, J. Arndt:
///
/// Ideanya adalah untuk mengurangkan satu dari setiap bait dan kemudian mencari bait di mana pinjaman disebarkan hingga ke yang paling signifikan
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Mengembalikan indeks pertama yang sepadan dengan bait `x` di `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Jalan pantas untuk kepingan kecil
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Imbas nilai bait tunggal dengan membaca dua perkataan `usize` pada satu masa.
    //
    // Bahagikan `text` dalam tiga bahagian
    // - bahagian awal yang tidak selaras, sebelum alamat yang diselaraskan dengan kata pertama dalam teks
    // - badan, imbasan dengan 2 perkataan pada satu masa
    // - bahagian terakhir yang tinggal, <2 ukuran perkataan

    // cari hingga batas yang selaras
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // cari isi teks
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // KESELAMATAN: predikat sementara menjamin jarak sekurang-kurangnya 2 * usize_bytes
        // antara ofset dan hujung hirisan.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // rehat jika terdapat bait yang sepadan
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Cari bait setelah titik gelung badan berhenti.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Mengembalikan indeks terakhir yang sepadan dengan bait `x` di `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Imbas nilai bait tunggal dengan membaca dua perkataan `usize` pada satu masa.
    //
    // Pisahkan `text` dalam tiga bahagian:
    // - ekor yang tidak sejajar, setelah alamat yang diselaraskan dengan kata terakhir dalam teks,
    // - badan, diimbas dengan 2 perkataan pada satu masa,
    // - bait pertama yang tinggal, <2 ukuran perkataan.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Kami menyebutnya hanya untuk mendapatkan panjang awalan dan akhiran.
        // Di tengah-tengah kita selalu memproses dua bahagian sekaligus.
        // KESELAMATAN: penghantaran `[u8]` ke `[usize]` adalah selamat kecuali perbezaan ukuran yang ditangani oleh `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Cari isi teks, pastikan kami tidak melintasi min_aligned_offset.
    // ofset selalu diselaraskan, jadi hanya menguji `>` mencukupi dan mengelakkan kemungkinan limpahan.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // KESELAMATAN: ofset bermula pada len, suffix.len(), asalkan lebih besar daripada
        // min_aligned_offset (prefix.len()) jarak yang tinggal sekurang-kurangnya 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Rehat jika ada bait yang sepadan.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Cari bait sebelum titik gelung badan berhenti.
    text[..offset].iter().rposition(|elt| *elt == x)
}