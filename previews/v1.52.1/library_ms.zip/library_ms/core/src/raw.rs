#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Mengandungi definisi struktur untuk susun atur jenis penyusun terbina dalam.
//!
//! Mereka boleh digunakan sebagai sasaran transmute dalam kod yang tidak selamat untuk memanipulasi representasi mentah secara langsung.
//!
//!
//! Definisi mereka harus selalu sesuai dengan ABI yang ditentukan dalam `rustc_middle::ty::layout`.
//!

/// Perwakilan objek trait seperti `&dyn SomeTrait`.
///
/// Struktur ini mempunyai susun atur yang sama dengan jenis seperti `&dyn SomeTrait` dan `Box<dyn AnotherTrait>`.
///
/// `TraitObject` dijamin sesuai dengan susun atur, tetapi ia bukan jenis objek trait (misalnya, medan tidak dapat diakses secara langsung pada `&dyn SomeTrait`) dan juga tidak mengawal susun atur itu (mengubah definisi tidak akan mengubah susun atur `&dyn SomeTrait`).
///
/// Ia hanya dirancang untuk digunakan oleh kod tidak selamat yang perlu memanipulasi perincian tahap rendah.
///
/// Tidak ada cara untuk merujuk ke semua objek trait secara umum, jadi satu-satunya cara untuk membuat nilai jenis ini adalah dengan fungsi seperti [`std::mem::transmute`][transmute].
/// Begitu juga, satu-satunya cara untuk membuat objek trait sebenar dari nilai `TraitObject` adalah dengan `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Mensintesis objek trait dengan jenis yang tidak sesuai-objek di mana vtable tidak sesuai dengan jenis nilai yang ditunjukkan oleh penunjuk data-sangat mungkin menyebabkan tingkah laku yang tidak ditentukan.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // contoh trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // biarkan penyusun membuat objek trait
/// let object: &dyn Foo = &value;
///
/// // lihat perwakilan mentah
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // penunjuk data adalah alamat `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // bina objek baru, menunjuk ke `i32` yang lain, berhati-hati menggunakan vtable `i32` dari `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ia harus berfungsi sama seperti kita telah membina objek trait dari `other_value` secara langsung
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}