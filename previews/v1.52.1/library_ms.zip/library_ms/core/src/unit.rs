use crate::iter::FromIterator;

/// Meruntuhkan semua item unit dari iterator menjadi satu.
///
/// Ini lebih berguna apabila digabungkan dengan abstraksi tahap lebih tinggi, seperti mengumpulkan ke `Result<(), E>` di mana anda hanya mengambil berat tentang kesilapan:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}