/// Iterator yang mengetahui panjang tepatnya.
///
/// Sebilangan besar [`Iterator`] tidak tahu berapa kali mereka akan berulang, tetapi ada yang mengetahuinya.
/// Sekiranya iterator tahu berapa kali ia dapat berulang, memberikan akses kepada maklumat tersebut akan berguna.
/// Contohnya, jika anda mahu berulang kali ke belakang, permulaan yang baik adalah mengetahui di mana akhirnya.
///
/// Semasa melaksanakan `ExactSizeIterator`, anda juga mesti melaksanakan [`Iterator`].
/// Apabila melakukannya, pelaksanaan [`Iterator::size_hint`]*mesti* mengembalikan ukuran iterator yang tepat.
///
/// Kaedah [`len`] mempunyai implementasi lalai, jadi biasanya Anda tidak harus menerapkannya.
/// Namun, anda mungkin dapat memberikan pelaksanaan yang lebih baik daripada yang default, jadi menimpanya dalam hal ini masuk akal.
///
///
/// Perhatikan bahawa trait ini adalah trait yang selamat dan dengan itu *tidak* dan *tidak* dapat menjamin bahawa panjang yang dikembalikan adalah betul.
/// Ini bermaksud bahawa kod `unsafe`**tidak boleh** bergantung pada ketepatan [`Iterator::size_hint`].
/// [`TrustedLen`](super::marker::TrustedLen) trait yang tidak stabil dan tidak selamat memberikan jaminan tambahan ini.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// // julat terhingga tahu berapa kali ia akan berulang
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Di [module-level docs], kami menerapkan [`Iterator`], `Counter`.
/// Mari kita laksanakan `ExactSizeIterator` juga:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Kita dapat mengira bilangan lelaran yang tinggal dengan mudah.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Dan sekarang kita boleh menggunakannya!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Mengembalikan panjang iterator yang tepat.
    ///
    /// Pelaksanaannya memastikan bahawa iterator akan kembali tepat `len()` lebih banyak kali nilai [`Some(T)`], sebelum mengembalikan [`None`].
    ///
    /// Kaedah ini mempunyai pelaksanaan lalai, jadi biasanya anda tidak harus menerapkannya secara langsung.
    /// Namun, jika anda dapat memberikan pelaksanaan yang lebih efisien, anda dapat melakukannya.
    /// Lihat contoh [trait-level].
    ///
    /// Fungsi ini mempunyai jaminan keselamatan yang sama dengan fungsi [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // julat terhingga tahu berapa kali ia akan berulang
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Penegasan ini terlalu defensif, tetapi ia memeriksa invarian
        // dijamin oleh trait.
        // Sekiranya trait ini adalah rust-dalaman, kita boleh menggunakan debug_assert !;tegaskan_eq!akan memeriksa semua pelaksanaan pengguna Rust juga.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Mengembalikan `true` jika iterator kosong.
    ///
    /// Kaedah ini mempunyai pelaksanaan lalai menggunakan [`ExactSizeIterator::len()`], jadi Anda tidak perlu menerapkannya sendiri.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}