/// Iterator yang selalu terus menghasilkan `None` apabila habis.
///
/// Memanggil seterusnya pada iterator yang menyatu yang telah mengembalikan `None` sekali dijamin akan mengembalikan [`None`] sekali lagi.
/// trait ini harus dilaksanakan oleh semua iterator yang berkelakuan seperti ini kerana memungkinkan mengoptimumkan [`Iterator::fuse()`].
///
///
/// Note: Secara amnya, anda tidak boleh menggunakan `FusedIterator` dalam batas generik jika anda memerlukan iterator yang menyatu.
/// Sebaliknya, anda hanya perlu memanggil [`Iterator::fuse()`] di iterator.
/// Sekiranya iterator sudah menyatu, pembungkus [`Fuse`] tambahan akan menjadi no-op tanpa penalti prestasi.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterator yang melaporkan panjang yang tepat menggunakan size_hint.
///
/// Iterator melaporkan petunjuk ukuran di mana tepat (batas bawah sama dengan batas atas), atau batas atas adalah [`None`].
///
/// Bahagian atas mesti hanya [`None`] jika panjang iterator sebenarnya lebih besar daripada [`usize::MAX`].
/// Dalam kes itu, batas bawah mestilah [`usize::MAX`], menghasilkan [`Iterator::size_hint()`] `(usize::MAX, None)`.
///
/// Iterator mesti menghasilkan bilangan elemen yang dilaporkan atau berbeza sebelum mencapai akhir.
///
/// # Safety
///
/// trait ini hanya boleh dilaksanakan apabila kontrak itu dipegang.
/// Pengguna trait ini mesti memeriksa bahagian atas [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Pengulangan bahawa ketika menghasilkan item akan mengambil sekurang-kurangnya satu elemen dari [`SourceIter`] yang mendasarinya.
///
/// Memanggil kaedah apa pun yang memajukan iterator, mis
/// [`next()`] atau [`try_fold()`], menjamin bahawa untuk setiap langkah sekurang-kurangnya satu nilai sumber yang mendasari iterator telah dipindahkan dan hasil dari rantai iterator dapat dimasukkan ke tempatnya, dengan anggapan kekangan struktur sumber membenarkan penyisipan sedemikian.
///
/// Dengan kata lain trait ini menunjukkan bahawa saluran paip iterator dapat dikumpulkan di tempatnya.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}